/*****************************************
 Copyright 2001-2007
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   callbacks.c
  @brief  This file provides with sample code for implementing RMFP's callbacks

	  This file is part of the test_rmfp suite

  @author Sebastian Frias Feltrer
  @date   2007-10-29
*/

/*
  **********************************************
  DISCLAIMER:

  - THIS IS TEST CODE, provided as sample code
  to help you understand what you should do to
  develop your own application based in RMFP.

  - This is NOT production grade code; It is not
  even a library, so any API defined here, CAN
  and WILL CHANGE without notice.

  **********************************************
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>

#define ALLOW_OS_CODE 1

#if 0
#define LOCALDBG ENABLE
#else
#define LOCALDBG DISABLE
#endif

#if 0
#define CRASHDBG ENABLE
#else
#define CRASHDBG DISABLE
#endif

#include "callbacks.h"
#include <dcc/include/dcc_macros.h>
#include "get_key.h"
#include "test_rmfp.h"

#ifdef	SRC_FILE_NAME
#undef	SRC_FILE_NAME
#endif	//SRC_FILE_NAME
#define	SRC_FILE_NAME		"callbacks.c"
#include <ErrPrintHelper.h>
#include <DateTime.h>
#include "DbgLogSwitchDef.h"

#define TIMEOUT_US (500 * 1000)
#define RETRY_THRESHOLD (16)

// if set to zero the bound checking for some commands will be disabled
#define USE_BOUNDS_CHECKING 1

// if set to one callbacks that trigger a message will always print it, else it'll be printed when appropiate
#define SHOW_ALL_NOTIFICATIONS 0

#define SHOW_PROGRESS_INCREMENT_THRESHOLD 7
#define SHOW_UNKNOWN_PROGRESS_TIME_THRESHOLD (10 * 1000)

#define RMFP_DOUBLEBUFFER_OSD_VERSION	1
#define RMFP_PICTURE_PROFILE_VERSION	1
#define RMFP_OSD_PROFILE_VERSION	1

#define PRINT_MASK_VIDEO	(1<<0)
#define PRINT_MASK_AUDIO	(1<<1)
#define PRINT_MASK_SUBS		(1<<2)
#define PRINT_MASK_PMT		(1<<3)
#define PRINT_MASK_VARIANT	(1<<4)

#define MAX(a,b) ((a) > (b) ? a : b)

RMbool run_hdmi = TRUE;
RMthread hdmi_thread;
RMsemaphore hdmi_semaphore;

/*
 * Local prototypes
 */
static RMstatus show_available_commands(struct rmfp_main_thread_context_type *pMainContext);
static RMstatus apply_scaler_window(struct rmfp_main_thread_context_type *pMainContext, RMuint32 scaler_ID, RMuint32 mixer, struct EMhwlibDisplayWindow *window);

static struct RMFPStreamMetadataSPUStreamEntry* get_current_subs_metadata(struct rmfp_main_thread_context_type *pMainContext, RMbool defaults);
static RMstatus print_stream_metadata(struct rmfp_main_thread_context_type *pMainContext);
static RMstatus print_information(struct rmfp_main_thread_context_type *pMainContext);
static void print_current_streams_properties(struct rmfp_main_thread_context_type *pMainContext, RMuint32 mask);
static void print_time(struct rmfp_main_thread_context_type *pMainContext);
static void print_current_pat(struct rmfp_main_thread_context_type *pMainContext);
static void print_current_pmt(struct rmfp_main_thread_context_type *pMainContext);

static RMstatus print_track_bounds(struct rmfp_main_thread_context_type *pMainContext, RMuint32 mask);
static RMstatus check_track_bounds(struct rmfp_main_thread_context_type *pMainContext, RMint32 TrackID, RMuint32 mask);

static RMstatus print_seek_bounds(struct rmfp_main_thread_context_type *pMainContext);
static RMstatus check_seek_bounds(struct rmfp_main_thread_context_type *pMainContext, RMint32 input);

static RMstatus _get_command(struct rmfp_main_thread_context_type *pMainContext, RMuint32 AvailableCommandsMask, struct RMFPPlaybackCommand *pCommand, RMuint32 TimeOutInMicroSeconds);
static RMascii* get_progress_name(RMuint32 type);

static void fill_output_osd_size(struct rmfp_main_thread_context_type *pHandle, struct RMFPOSDProfile *pOSDProfile, RMuint32 mixer);

static RMstatus parse_magazinePacketAddress(RMuint32 * pageNumber, RMuint32 * magazineNumber, RMuint32 magazinePageNumber);

struct commands {
	RMuint32 special_char;
	RMuint8 key;
	RMascii *description;
	RMuint32 mask;
};

struct commands command_table[] = {
	{ 0, KEY_COMMAND_QUIT_ALL,		"Quit all",				0},
	{ 0, KEY_COMMAND_QUIT,			"Quit",					RMFP_ENABLE_COMMAND_QUIT },
	{ 0, KEY_COMMAND_PLAY,			"Play (1x)",				RMFP_ENABLE_COMMAND_PLAY },
	{ 0, KEY_COMMAND_PAUSE,			"Pause",				RMFP_ENABLE_COMMAND_PAUSE },
	{ 0, KEY_COMMAND_RESUME,		"Resume (from Pause)",			RMFP_ENABLE_COMMAND_RESUME },
	{ 0, KEY_COMMAND_STOP,			"Stop",					RMFP_ENABLE_COMMAND_STOP },
	{ 0, KEY_COMMAND_SEEK_TO_TIME,		"Seek to time",				RMFP_ENABLE_COMMAND_SEEK_TO_TIME },
	{ 0, KEY_COMMAND_SEEK_TO_PERCENT,	"Seek to percentage",			RMFP_ENABLE_COMMAND_SEEK_TO_PERCENTAGE },
	{ 0, KEY_COMMAND_NEXT_PICT,		"Next Picture (must be Paused)",	RMFP_ENABLE_COMMAND_NEXTPICTURE },
	{ 0, KEY_COMMAND_FAST_FWD_ALL_FRAMES,	"Fast FWD all frames (4x)",		RMFP_ENABLE_COMMAND_FASTFWD },
	{ 0, KEY_COMMAND_FAST_FWD_WITH_AUDIO,	"Fast FWD all frames with audio (1.2x)",RMFP_ENABLE_COMMAND_FASTFWD },
	{ 0, KEY_COMMAND_SLOW_FWD_ALL_FRAMES,	"Slow FWD all frames (1/4x)",		RMFP_ENABLE_COMMAND_SLOWFWD },
	{ 0, KEY_COMMAND_SLOW_FWD_WITH_AUDIO,	"Slow FWD all frames with audio (0.8x)",RMFP_ENABLE_COMMAND_SLOWFWD },
	{ 0, KEY_COMMAND_IFRAMES_FWD,		"IFrame FWD (4x)",			RMFP_ENABLE_COMMAND_IFORWARD },
	{ 0, KEY_COMMAND_IFRAMES_BWD,		"IFrame BWD (4x)",			RMFP_ENABLE_COMMAND_IBACKWARD },
	{ 0, KEY_COMMAND_SILENT_FWD,		"Silent FWD (2x)",			RMFP_ENABLE_COMMAND_SILENTFORWARD },
	{ 0, KEY_COMMAND_SILENT_BWD,		"Silent BWD (2x)",			RMFP_ENABLE_COMMAND_SILENTBACKWARD },
	{ 0, KEY_COMMAND_SWITCH_VIDEO,		"Switch video stream",			RMFP_ENABLE_COMMAND_SWITCHVIDEO },
	{ 0, KEY_COMMAND_SWITCH_AUDIO,		"Switch audio stream",			RMFP_ENABLE_COMMAND_SWITCHAUDIO },
	{ 0, KEY_COMMAND_SWITCH_PROGRAM,	"Switch program stream",		RMFP_ENABLE_COMMAND_SWITCHPROGRAM },
	{ 0, KEY_COMMAND_SWITCH_SUBS,		"Switch SPU stream",			RMFP_ENABLE_COMMAND_SWITCHSPU },
	{ 0, KEY_COMMAND_SWITCH_MULTICAST,	 "Switch multicast source",		RMFP_ENABLE_COMMAND_SWITCHMULTICAST },
	{ 0, KEY_COMMAND_APPLY_AV_DELAY,	"Apply delay (v=1s;a=3s)",		RMFP_ENABLE_COMMAND_APPLYDELAYTOOUTPUTS },
	{ 0, KEY_COMMAND_SUBS_CHANGE_DELAY,	"Change external subs delay (ms)",	RMFP_ENABLE_COMMAND_SUBS_PARAMETERS },
	{ 0, KEY_COMMAND_SUBS_INCREASE_FONT_SIZE, "Increase subs font size",		RMFP_ENABLE_COMMAND_SUBS_PARAMETERS },
	{ 0, KEY_COMMAND_SUBS_DECREASE_FONT_SIZE,"Decrease subs font size",		RMFP_ENABLE_COMMAND_SUBS_PARAMETERS },
	{ 0, KEY_COMMAND_SUBS_INCREASE_POS_Y,	"Increase subs Y position",		RMFP_ENABLE_COMMAND_SUBS_PARAMETERS },
	{ 0, KEY_COMMAND_SUBS_DECREASE_POS_Y,	"Decrease subs Y position",		RMFP_ENABLE_COMMAND_SUBS_PARAMETERS },
	{ 0, KEY_COMMAND_SUBS_SWITCH_ENCODING,	"Switch encoding",			RMFP_ENABLE_COMMAND_SUBS_PARAMETERS },
	{ 0, KEY_COMMAND_SUBS_RESET_ALL,	"Reset subs style",			RMFP_ENABLE_COMMAND_SUBS_PARAMETERS },
	{ 0, KEY_COMMAND_SUBS_CHANGE_COLOR,	"Change subs color",			RMFP_ENABLE_COMMAND_SUBS_PARAMETERS },
	{ 0, KEY_COMMAND_DEBUG,			"Debug command",			RMFP_ENABLE_COMMAND_DEBUG },
	{ 0, KEY_COMMAND_PRINT_INFO,		"Print information",			RMFP_ENABLE_COMMAND_PRINT_INFORMATION },
	{ 0, KEY_COMMAND_PRINT_TXT,		"Print teletext",			RMFP_ENABLE_COMMAND_PRINT_TELETEXT },
	{ 0, KEY_COMMAND_SWITCH_VARIANT, "Switch playlist variant", RMFP_ENABLE_COMMAND_SWITCHVARIANT},
	{ 0, KEY_COMMAND_PLAY_IFRAME, "Play I frames only", RMFP_ENABLE_COMMAND_PLAY},

	/* SPECIAL CASE: because 'h' is treated internally */
	{ 0, KEY_COMMAND_HELP,			"Help (this screen)", 0 },
	{ 0, KEY_COMMAND_STANDBY,		"System Standby", 0 },
	{ 0, KEY_COMMAND_WAKEUP,		"System Wakeup", 0 },
	/* Scaler options */
	{ 0, KEY_COMMAND_FULL_SCREEN,		"Full screen scaler size",		0},
	{ 0, KEY_COMMAND_HALF_SCREEN,		"Half screen scaler size",		0},
	{ 0, KEY_COMMAND_INCREASE_SIZE,		"Increase size",			0},
	{ 0, KEY_COMMAND_DECREASE_SIZE,		"Decrease size",			0},
	{ 0, KEY_COMMAND_MOVE_LEFT,		"Move left scaler window",		0},
	{ 0, KEY_COMMAND_MOVE_RIGHT,		"Move right scaler window",		0},
	{ 0, KEY_COMMAND_MOVE_TOP,		"Move top scaler window",		0},
	{ 0, KEY_COMMAND_MOVE_BOTTOM,		"Move bottom scaler window",		0},
	{ 0, KEY_COMMAND_NONLINEAR_WIDTH,	"Change non-linear width",		0},
	{ 0, KEY_COMMAND_NONLINEAR_LEVEL,	"Change non-linear level",		0},
	{ 0, KEY_COMMAND_SWITCH_SCALER,		"Switch to video, osd or all scaler",	0},

	/* Special keys */
	{ 1, SPECIAL_KEY_COMMAND_IFRAMES_FWD,	"IFrame FWD (5x)",			RMFP_ENABLE_COMMAND_IFORWARD },
	{ 1, SPECIAL_KEY_COMMAND_IFRAMES_BWD,	"IFrame BWD (5x)",			RMFP_ENABLE_COMMAND_IBACKWARD },
	{ 1, SPECIAL_KEY_COMMAND_NEXT_AUDIO,	"Next audio track",			RMFP_ENABLE_COMMAND_SWITCHAUDIO },
	{ 1, SPECIAL_KEY_COMMAND_NEXT_SUBS,	"Next subtitles track",			RMFP_ENABLE_COMMAND_SWITCHSPU },
};

/**************************************************************************************************/

RMstatus get_command(void *pContext, struct RMFPPlaybackCommand *pCommand, RMuint32 TimeOutInMicroSeconds)
{
	struct rmfp_main_thread_context_type *pMainContext = NULL;

	ASSERT_NULL_POINTER(pContext);
	ASSERT_NULL_POINTER(pCommand);

	pMainContext = (struct rmfp_main_thread_context_type *)pContext;

	if (pMainContext->ReceivedCECStandby) {
		pCommand->command = RMFP_Playback_command_Quit;
		return RM_OK;
	}
	if (pMainContext->EOS) {
		if ((pMainContext->AppOptions.Playback.loop) && (!pMainContext->quit)) {
			fprintf(NORMALMSG, "Sending play command (Loop mode)\n");

			pMainContext->playback_started = FALSE;

			pCommand->command = RMFP_Playback_command_Play;
			pCommand->params.speed.N = 1;
			pCommand->params.speed.M = 1;
		}
		else
			pCommand->command = RMFP_Playback_command_Quit;

		pMainContext->EOS = FALSE;
		return RM_OK;
	}

	if (0){
		RMuint32 time;
		RMFPGetPlaybackTime(pMainContext->pHandle, &time);

#if 1
		if ((time / 1000 >= pMainContext->LastPlaybackTime + 1)
		    || (time / 1000 <= pMainContext->LastPlaybackTime - 1)) {
			RMDBGLOG((ENABLE, "time %lu.%lu\n", time / 1000, time % 1000));
			pMainContext->LastPlaybackTime = time / 1000;
		}
#else
		RMDBGLOG((ENABLE, "time %lu.%lu\n", time / 1000, time % 1000));
#endif

	}

	return _get_command(pMainContext, pMainContext->availableCommandsMask, pCommand, TimeOutInMicroSeconds);
}

/**************************************************************************************************/

RMstatus notify_available_commands(void *pContext, RMuint32 mask)
{
	struct rmfp_main_thread_context_type *pMainContext = NULL;

	ASSERT_NULL_POINTER(pContext);


	pMainContext = (struct rmfp_main_thread_context_type *)pContext;
	pMainContext->availableCommandsMask = mask;

	/*
	   show_available_commands() will be called from within notify_playback_start callback, this
	   allow us to handle several notify_available_commands() calls and only show the message once.
	   However, once we called show_available_commands() in notify_playback_start, we'll call it
	   each time we get a notify_available_commands() callback
	*/

	if (pMainContext->playback_started && SHOW_ALL_NOTIFICATIONS)
	{
		show_available_commands(pMainContext);
	}

	return RM_OK;
}


/**************************************************************************************************/

RMstatus notify_command_status(void *pContext, struct RMFPCommandStatus *pStatus)
{
	ASSERT_NULL_POINTER(pContext);
	ASSERT_NULL_POINTER(pStatus);

	RMDBGLOG((LOCALDBG, "command status notification\n"));

	switch (pStatus->lastCommand.command) {
	case RMFP_Playback_command_Play:
		fprintf(NORMALMSG, "Command: play %ld/%lu", pStatus->lastCommand.params.speed.N, pStatus->lastCommand.params.speed.M);
		break;
	case RMFP_Playback_command_Pause:
		fprintf(NORMALMSG, "Command: pause");
		break;
	case RMFP_Playback_command_Resume:
		fprintf(NORMALMSG, "Command: resume");
		break;
	case RMFP_Playback_command_Stop:
		fprintf(NORMALMSG, "Command: stop");
		break;
	case RMFP_Playback_command_Seek:
		switch(pStatus->lastCommand.params.seek.type) {
		case RMFP_seek_to_time:
			fprintf(NORMALMSG, "Command: seek to time: %lu", pStatus->lastCommand.params.seek.to.time);
			break;
		case RMFP_seek_to_percentage:
			fprintf(NORMALMSG, "Command: seek to percentage: %lu", pStatus->lastCommand.params.seek.to.percentage);
			break;
		}
		break;
	case RMFP_Playback_command_NextPicture:
		fprintf(NORMALMSG, "Command: next");
		break;
	case RMFP_Playback_command_IForward:
		fprintf(NORMALMSG, "Command: ifwd %ld/%lu", pStatus->lastCommand.params.speed.N, pStatus->lastCommand.params.speed.M);
		break;
	case RMFP_Playback_command_IBackward:
		fprintf(NORMALMSG, "Command: ibwd %ld/%lu", pStatus->lastCommand.params.speed.N, pStatus->lastCommand.params.speed.M);
		break;
	case RMFP_Playback_command_SilentForward:
		fprintf(NORMALMSG, "Command: silentfwd %ld/%lu", pStatus->lastCommand.params.speed.N, pStatus->lastCommand.params.speed.M);
		break;
	case RMFP_Playback_command_SilentBackward:
		fprintf(NORMALMSG, "Command: silentbwd %ld/%lu", pStatus->lastCommand.params.speed.N, pStatus->lastCommand.params.speed.M);
		break;
	case RMFP_Playback_command_Quit:
		fprintf(NORMALMSG, "Command: quit");
		break;
	case RMFP_Playback_command_SwitchVideo:
		fprintf(NORMALMSG, "Command: switch video: %ld", pStatus->lastCommand.params.switchVideo.stream);
		break;
	case RMFP_Playback_command_SwitchAudio:
		fprintf(NORMALMSG, "Command: switch audio: %ld", pStatus->lastCommand.params.switchAudio.stream);
		break;
	case RMFP_Playback_command_SwitchSPU:
		fprintf(NORMALMSG, "Command: switch spu: %ld", pStatus->lastCommand.params.switchSPU.stream);
		break;
	case RMFP_Playback_command_SwitchProgram:
		fprintf(NORMALMSG, "Command: switch program: %ld", pStatus->lastCommand.params.switchProgram.stream);
		break;
	case RMFP_Playback_command_Debug:
		fprintf(NORMALMSG, "Command: debug: %ld/%ld", pStatus->lastCommand.params.debug.type, pStatus->lastCommand.params.debug.param);
		break;
	case RMFP_Playback_command_Print_Information:
		fprintf(NORMALMSG, "Command: print information: %ld/%ld", pStatus->lastCommand.params.printInfo.type, pStatus->lastCommand.params.printInfo.param);
		break;

	case RMFP_Playback_command_Print_Teletext:
		fprintf(NORMALMSG, "Command: print teletext: %ld/%ld", pStatus->lastCommand.params.printInfo.type, pStatus->lastCommand.params.printInfo.param);
		break;


	case RMFP_Playback_command_SwitchMulticast:
		fprintf(NORMALMSG, "Command: switch multicast");
		break;
	case RMFP_Playback_command_ReconfigureOutports:
		fprintf(NORMALMSG, "Command: reconfigure outports");
		break;
	case RMFP_Playback_command_ApplyDelayToOutputs:
		fprintf(NORMALMSG, "Command: apply delay to outputs (v:%ld a:%ld)", pStatus->lastCommand.params.outputDelay.Video, pStatus->lastCommand.params.outputDelay.Audio);
		break;
	case RMFP_Playback_command_SubsParams:
		fprintf(NORMALMSG, "Command: change subs params");
		break;
	case RMFP_Playback_command_SwitchVariant:
		fprintf(NORMALMSG, "Command: switch playlist variant");
		break;
	case RMFP_Playback_command_Play_Iframe:
		fprintf(NORMALMSG, "Command: play I frame %ld/%lu", pStatus->lastCommand.params.speed.N, pStatus->lastCommand.params.speed.M);
		break;
	default:
		break;
	};

	if (pStatus->lastCommandStatus == RM_OK)
		fprintf(NORMALMSG, " %s\n", RMstatusToString(pStatus->lastCommandStatus));
	else
		fprintf(NORMALMSG, " ERROR: %s\n", RMstatusToString(pStatus->lastCommandStatus));

	return RM_OK;
}

/**************************************************************************************************/

RMstatus notify_playback_status(void *pContext, struct RMFPPlaybackStatus *pStatus)
{
	struct rmfp_main_thread_context_type *pMainContext = pContext;

	ASSERT_NULL_POINTER(pContext);
	ASSERT_NULL_POINTER(pStatus);

	RMDBGLOG((LOCALDBG, "playback status notification\n"));

	/* Store status */
	pMainContext->current_status = *pStatus;

	if(Sw_LogPlaybackStatus)
	{
		switch (pStatus->playbackState.state) {
		case RMFP_Playback_state_Playing:
				fprintf(NORMALMSG, "State: Playing, speed: %ld/%lu\n", pStatus->playbackState.speed.N, pStatus->playbackState.speed.M);
			break;
		case RMFP_Playback_state_Paused:
			fprintf(NORMALMSG, "State: Paused\n");
			break;
		case RMFP_Playback_state_Stopped:
			fprintf(NORMALMSG, "State: Stopped\n");
			break;
		case RMFP_Playback_state_NextPic:
			fprintf(NORMALMSG, "State: Next picture...\n");
			break;
		case RMFP_Playback_state_IForward:
			fprintf(NORMALMSG, "State: Iframe fwd, speed: %ld/%lu\n", pStatus->playbackState.speed.N, pStatus->playbackState.speed.M);
			break;
		case RMFP_Playback_state_IBackward:
			fprintf(NORMALMSG, "State: Iframe rwd, speed: %ld/%lu\n", pStatus->playbackState.speed.N, pStatus->playbackState.speed.M);
			break;
		case RMFP_Playback_state_IPaused:
		case RMFP_Playback_state_INextPic:
			fprintf(NORMALMSG, "State: ????\n");
			break;
		case RMFP_Playback_state_SilentForward:
			fprintf(NORMALMSG, "State: Silent fwd, speed: %ld/%lu\n", pStatus->playbackState.speed.N, pStatus->playbackState.speed.M);
			break;
		case RMFP_Playback_state_SilentBackward:
			fprintf(NORMALMSG, "State: Silent rwd, speed: %ld/%lu\n", pStatus->playbackState.speed.N, pStatus->playbackState.speed.M);
			break;
		case RMFP_Playback_state_Buffering:
			fprintf(NORMALMSG, "State: Buffering...\n");
			break;
		case RMFP_Playback_state_Quitting:
			fprintf(NORMALMSG, "State: Quitting...\n");
			break;
		case RMFP_Playback_state_PlayingIFrame:
			fprintf(NORMALMSG, "State: Playing Iframe, speed: %ld/%lu\n", pStatus->playbackState.speed.N, pStatus->playbackState.speed.M);
			break;
		};
	}

	return RM_OK;
}

/**************************************************************************************************/

RMstatus notify_playback_start(void *pContext)
{
	struct rmfp_main_thread_context_type *pMainContext = NULL;
	RMstatus status;

	ASSERT_NULL_POINTER(pContext);
	pMainContext = (struct rmfp_main_thread_context_type *)pContext;

	/*we can apply video options on scaler at this time of the code
	  because that's only now that know for sure if a scaler is dedicated to video
	  and we need to configure it. however, we must apply this only once at start of stream
	  else it would be applied after trick modes (accurate seek for instance)
	  and cause a visual glitch */

	if (! pMainContext->video_scaler_options_applied) {
		status = apply_video_scaler_option(pMainContext);
		if (status != RM_OK) {
			fprintf(ERRORMSG, "Cannot apply video scaler options\n");
			return status;
		}

		if (pMainContext->ActiveScalers & VIDEO_SCALER_ACTIVE)
			pMainContext->video_scaler_options_applied = TRUE;
		else
			RMDBGLOG((ENABLE, "video scaler not marked as active yet\n"));
	}

	pMainContext->EOS = FALSE;

	if (!pMainContext->playback_started) {

		if (pMainContext->AppOptions.Playback.start_in_pause) {
			RMstatus status;
			RMuint32 Mask;
			struct RMFPPlaybackCommand Command = { 0, };

			// in order to avoid a race between the code below and
			// "test_rmfp.c:rmfp_key_management_thread()" we need to grab the CS
			ENTER_CS(pMainContext->GetKeyCS);

			fprintf(NORMALMSG, "Press 'p' to start playing\n");
			fprintf(NORMALMSG, "Press 'q' or 'Q' to quit\n");

			do {
				Mask = (RMFP_ENABLE_COMMAND_PLAY | RMFP_ENABLE_COMMAND_QUIT);
				RMMemset(&Command, 0, sizeof(Command));

				status = _get_command(pMainContext, Mask, &Command, 10000);
				if (status == RM_OK) {
					if (Command.command == RMFP_Playback_command_Play) {
						RMDBGLOG((ENABLE, "play requested\n"));
						break;
					}
					else if (Command.command == RMFP_Playback_command_Quit) {
						RMDBGLOG((ENABLE, "quit requested\n"));

						// release the CS
						LEAVE_CS(pMainContext->GetKeyCS);

						return RM_ERROR;
					}
				}

			} while (1);

			// release the CS
			LEAVE_CS(pMainContext->GetKeyCS);
		}

		if (SHOW_ALL_NOTIFICATIONS)
		{
			show_available_commands(pMainContext);
		}
	}

	pMainContext->playback_started = TRUE;
#if 0
	fprintf(NORMALMSG, "Wait\n");
	RMMicroSecondSleep(2 * 1000 * 1000);
#endif

	//fprintf(NORMALMSG, "\nPlayback has started...\n");
	
	if (pMainContext->pOptions->demux_options.save_input_file_handle) {
		fprintf(NORMALMSG, "\n=================================================\n");
		fprintf(NORMALMSG, "=      RECORDING FULL TS INPUT FROM SPI         =\n");
		fprintf(NORMALMSG, "=    THE STREAM WILL NOT BE DECODED/DISPLAYED   =\n");
		fprintf(NORMALMSG, "=================================================\n\n");
	}
	return RM_OK;
}

/**************************************************************************************************/

RMstatus notify_playback_eos(void *pContext)
{
	struct rmfp_main_thread_context_type *pMainContext = NULL;

	ASSERT_NULL_POINTER(pContext);

	pMainContext = (struct rmfp_main_thread_context_type *)pContext;

	//fprintf(NORMALMSG, "End of file...\n");

	if (pMainContext->pOptions->playback_options.WaitExit) {
		RMstatus status;
		RMuint32 Mask;
		struct RMFPPlaybackCommand Command = { 0, };

		// in order to avoid a race between the code below and
		// "test_rmfp.c:rmfp_key_management_thread()" we need to grab the CS
		ENTER_CS(pMainContext->GetKeyCS);

		if (pMainContext->AppOptions.Playback.loop)
			fprintf(NORMALMSG, "Press 'q' to continue or 'Q' to exit loop mode\n");
		else
		{
			//fprintf(NORMALMSG, "Press 'q' to quit\n");
		}

		do {
			Mask = RMFP_ENABLE_COMMAND_QUIT;
			RMMemset(&Command, 0, sizeof(Command));

			status = _get_command(pMainContext, Mask, &Command, (10*1000));
			if ((status == RM_OK) && (Command.command == RMFP_Playback_command_Quit)) {
				break;
			}
		} while (1);

		// release the CS
		LEAVE_CS(pMainContext->GetKeyCS);
	}

	pMainContext->EOS = TRUE;

	return RM_OK;
}

/**************************************************************************************************/

RMstatus notify_current_streams_properties(void *pContext, struct RMFPStreamProperties *pStreamProperties)
{
	struct rmfp_main_thread_context_type *pMainContext = NULL;

	ASSERT_NULL_POINTER(pContext);
	ASSERT_NULL_POINTER(pStreamProperties);

	pMainContext = (struct rmfp_main_thread_context_type *)pContext;

	// Store them in local context
	if (pStreamProperties->valid_properties_mask & RMFP_STREAM_PROPERTIES_MASK_VIDEO) {
		pMainContext->stream_properties.valid_properties_mask |= RMFP_STREAM_PROPERTIES_MASK_VIDEO;
		pMainContext->stream_properties.video = pStreamProperties->video;
	}

	if (pStreamProperties->valid_properties_mask & RMFP_STREAM_PROPERTIES_MASK_AUDIO) {
		pMainContext->stream_properties.valid_properties_mask |= RMFP_STREAM_PROPERTIES_MASK_AUDIO;
		pMainContext->stream_properties.audio = pStreamProperties->audio;
	}

	if (pStreamProperties->valid_properties_mask & RMFP_STREAM_PROPERTIES_MASK_SUBTITLES) {
		pMainContext->stream_properties.valid_properties_mask |= RMFP_STREAM_PROPERTIES_MASK_SUBTITLES;
		pMainContext->stream_properties.subtitles = pStreamProperties->subtitles;
	}

	if (pStreamProperties->valid_properties_mask & RMFP_STREAM_PROPERTIES_MASK_PICTURE) {
		pMainContext->stream_properties.valid_properties_mask |= RMFP_STREAM_PROPERTIES_MASK_PICTURE;
		pMainContext->stream_properties.picture = pStreamProperties->picture;
	}

	if(Sw_LogMediaFileInfo)
	{
		// print them
		print_current_streams_properties(pMainContext, pStreamProperties->valid_properties_mask);
	}

	return RM_OK;
}

/**************************************************************************************************/

RMstatus notify_pat(void *pContext, struct RMFPPAT *pPAT)
{
	struct rmfp_main_thread_context_type *pMainContext = NULL;

	ASSERT_NULL_POINTER(pContext);
	ASSERT_NULL_POINTER(pPAT);
	ASSERT_NULL_POINTER(pPAT->pContent);

	pMainContext = (struct rmfp_main_thread_context_type *)pContext;

	// Store it in local context
	pMainContext->current_pat = *(pPAT->pContent);

	if(Sw_LogMediaFileInfo)
	{
		// Print PAT
		print_current_pat(pMainContext);
	}

	return RM_OK;
}

/**************************************************************************************************/

RMstatus notify_pmt(void *pContext, struct RMFPPMT *pPMT)
{
	struct rmfp_main_thread_context_type *pMainContext = NULL;

	ASSERT_NULL_POINTER(pContext);
	ASSERT_NULL_POINTER(pPMT);
	ASSERT_NULL_POINTER(pPMT->pContent);

	pMainContext = (struct rmfp_main_thread_context_type *)pContext;

	// Store it in local context
	pMainContext->current_pmt = *(pPMT->pContent);

	if(Sw_LogMediaFileInfo)
	{
		// Print PMT
		print_current_pmt(pMainContext);
	}

	return RM_OK;
}

/**************************************************************************************************/

static RMascii* get_progress_name(RMuint32 type)
{
	switch (type)
	{
		/* RMFP progress type */
		case RMFP_progress_type_buffering: return "buffering";
		case RMFP_progress_type_detection: return "detection";
		case RMFP_progress_type_index_creation: return "index creation";
		case RMFP_progress_type_wait_for_new_picture: return "wait for picture";
		case RMFP_progress_type_file_reading: return "file reading";
		case RMFP_progress_type_extracting_attachment: return "attachment extraction";

		/* TEST_RMFP progress type */
		case TEST_RMFP_progress_type_scanning_subs: return "scanning subs";

		default: return "unknown";
	}
}

/**************************************************************************************************/

RMstatus notify_progress(void *pContext, struct RMFPProgress* pProgress, RMbool *pAbort)
{
	RMstatus status;
	struct RMFPPlaybackCommand Command = { 0, };
	struct rmfp_main_thread_context_type *pMainContext = NULL;
	RMbool ShowProgress = TRUE;
	UINT64_t CurUpTimeMs;

	ASSERT_NULL_POINTER(pContext);
	ASSERT_NULL_POINTER(pProgress);

	pMainContext = (struct rmfp_main_thread_context_type *)pContext;

	if (pMainContext->AppOptions.Playback.detect_only)
		ShowProgress = FALSE;

	if (ShowProgress){

		switch (pProgress->info_type)
		{
			case RMFP_progress_info_type_percentage:

				if (pProgress->progress.percentage == 100) {
					RMuint64 Now = RMGetTimeInMicroSeconds();
					CurUpTimeMs = GetSysUpTimeMs();
					if(Sw_LogPlaybackStatus)
					{
						printf("End of [%s] (time spent %llu ms),Time: %llu ms\n",
							get_progress_name(pProgress->progress_type),
							(Now - pMainContext->StartOfProgressTime)/(RMuint64) 1000,
							CurUpTimeMs);
					}
				}
				else if (pProgress->progress.percentage == -1) {
					RMuint64 Time = RMGetTimeInMicroSeconds();
					if (Time >= pMainContext->LastUnknownProgressTime + SHOW_UNKNOWN_PROGRESS_TIME_THRESHOLD) {
						//fprintf(NORMALMSG, ".");
						pMainContext->LastUnknownProgressTime = Time;
					}
				}
				else if (pProgress->progress.percentage < 100) {

					if (pProgress->progress.percentage == 0) {
						pMainContext->LastUnknownProgressTime = RMGetTimeInMicroSeconds();
						pMainContext->StartOfProgressTime = pMainContext->LastUnknownProgressTime;
						pMainContext->LastProgress = pProgress->progress.percentage;
						CurUpTimeMs = GetSysUpTimeMs();						
						if(Sw_LogPlaybackStatus)
						{
							printf("Start of [%s],Time: %llu ms\n", get_progress_name(pProgress->progress_type), CurUpTimeMs);
						}
					}

					if (pProgress->progress.percentage >= pMainContext->LastProgress + SHOW_PROGRESS_INCREMENT_THRESHOLD) {
						//fprintf(NORMALMSG, "[%s] %ld%%\n", get_progress_name(pProgress->progress_type), pProgress->progress.percentage);
						pMainContext->LastProgress = pProgress->progress.percentage;
					}
				}

				break;

			case RMFP_progress_info_type_size:
				fprintf(NORMALMSG, "[%s] %lld bytes\n", get_progress_name(pProgress->progress_type), pProgress->progress.size);
				break;
		}

	}

	if (pAbort) {
		RMuint32 Mask = RMFP_ENABLE_COMMAND_QUIT;
		/*
		   only check for a 'quit' command if the task signaling its progress
		   reported it can be interrupted
		*/

		*pAbort = FALSE;

		status = _get_command(pMainContext, Mask, &Command, 0);
		if ((status == RM_OK) && (Command.command == RMFP_Playback_command_Quit)) {
			fprintf(NORMALMSG, "\nSignaling 'abort'...\n");

			*pAbort = TRUE;
		}
	}

	//fflush(NORMALMSG);

	return RM_OK;
}

/**************************************************************************************************/

RMstatus disk_control(void *pContext, enum RMFPDiskControl_action action)
{
	RMuint64 t;
	RMuint64 diff;

	struct rmfp_main_thread_context_type *pMainContext = NULL;

	ASSERT_NULL_POINTER(pContext);

	pMainContext = (struct rmfp_main_thread_context_type *)pContext;


	t = RMGetTimeInMicroSeconds();

	if(!pMainContext->DiskControlLastTimerValue)
		pMainContext->DiskControlLastTimerValue = t;

	diff = t - pMainContext->DiskControlLastTimerValue;

	fprintf(NORMALMSG, "---------------------------------------\n");

	if (action == RMFPDiskControl_action_Sleep) {
		pMainContext->HDrunTime += diff;
		fprintf(NORMALMSG, "SLEEP!! SLEEP!! SLEEP!! SLEEP!! SLEEP!!\n");
		fprintf(NORMALMSG, " Wakeup time       %10llu us\n\n", diff);
	}
	else {
		pMainContext->HDsleepTime += diff;
		fprintf(NORMALMSG, "WAKE UP!! WAKE UP!! WAKE UP!! WAKE UP!!\n");
		fprintf(NORMALMSG, " Sleep time        %10llu us\n\n", diff);
	}

	fprintf(NORMALMSG, " Total wakeup time %10llu us\n", pMainContext->HDrunTime);
	fprintf(NORMALMSG, " Total sleep time  %10llu us\n", pMainContext->HDsleepTime);

	if (pMainContext->HDrunTime)
		fprintf(NORMALMSG, " Sleep/run ratio   %10llu\n", pMainContext->HDsleepTime / pMainContext->HDrunTime);

	fprintf(NORMALMSG, "---------------------------------------\n");

	fflush(NORMALMSG);

	pMainContext->DiskControlLastTimerValue = t;

	return RM_OK;
}

/* common code helper func */
RMstatus apply_common_scaler_option(struct rmfp_main_thread_context_type *pMainContext, struct DisplayOptions * pDisplayOptions, RMuint32 scaler_ID)
{

	RMstatus status = RM_OK;

	if (scaler_ID == (RMuint32)-1) {
		RMDBGLOG((ENABLE, "No scaler, don't apply common scaler options\n"));
		return RM_OK;
	}

	/* if we're on 8644, hardware Video Plane and hardware GFX scalers are sharing the same mixer input.
	   we choose  which of these two scalers should be refreshed by the mixer */

#if (defined(RMFEATURE_VIDEO_PLANE_HAS_MIXER_INDEX_0) && defined (RMFEATURE_HAS_HARD_GFX_SCALER)) //8644 specific
	{
		RMuint32 allowedHWGFXScalerSWModuleID;
#ifdef RMFEATURE_SOFT_CRT_SCALER_IS_HARD_GFX_SCALER //if this software trick is used (should always be true  but tested for flexility)
		allowedHWGFXScalerSWModuleID = DispCRTMultiScaler;
#else
		allowedHWGFXScalerSWModuleID = DispGFXMultiScaler;
#endif
		if (scaler_ID == DispVideoPlane || scaler_ID == allowedHWGFXScalerSWModuleID) {
			DCCSP(pMainContext->pRUA, DispMainMixer, RMGenericPropertyID_MixerChoiceBetweenVideoPlaneAndDispCRTMultiScaler,&(scaler_ID),sizeof(scaler_ID));
			DCCSP(pMainContext->pRUA, DispMainMixer, RMGenericPropertyID_Validate,NULL, 0);
		}
	}
#endif //8644 specific

	{
		UINT64_t uiStartTimeMs = GetSysUpTimeMs();
		while(TRUE)
		{
			status = RUASetProperty(pMainContext->pRUA, scaler_ID, RMGenericPropertyID_BlackStripMode,
						&(pDisplayOptions->blackstrip), sizeof(pDisplayOptions->blackstrip), 0);
			if(RMSUCCEEDED(status))
			{
				break;
			}
			else if(RM_PENDING == status)
			{
				if((1*1000) > (GetSysUpTimeMs() - uiStartTimeMs))
				{
					usleep(5*1000);
				}
				else	//timeout
				{
					break;
				}
			}
			else	//RMFAILED
			{
				break;
			}
		}
	}

	if (status != RM_OK && status != RM_INVALIDMODE) {
		RMNOTIFY((NULL, status, "Cannot set blackstrip mode to scaler\n"));
		return status;
	} else if (status == RM_INVALIDMODE) {
		RMDBGLOG((ENABLE, "WARNING: blackstrip not supported by scaler %d\n", scaler_ID));
	}

	status = RUASetProperty(pMainContext->pRUA, scaler_ID, RMGenericPropertyID_CutStripMode,
				&(pDisplayOptions->cutstrip), sizeof(pDisplayOptions->cutstrip), 0);
	if (status != RM_OK && status != RM_INVALIDMODE) {
		RMNOTIFY((NULL, status, "Cannot set cutstrip mode to scaler\n"));
		return status;
	} else if (status == RM_INVALIDMODE) {
		RMDBGLOG((ENABLE, "WARNING: cutstrip not supported by scaler %d\n", scaler_ID));
	}

	status = RUASetProperty(pMainContext->pRUA, scaler_ID, RMGenericPropertyID_ScalingMode,
				&(pDisplayOptions->scalingmode), sizeof(pDisplayOptions->scalingmode), 0);
	if (status != RM_OK && status != RM_INVALIDMODE) {
		RMNOTIFY((NULL, status, "Cannot set scaling mode to scaler\n"));
		return status;
	} else if (status == RM_INVALIDMODE) {
		RMDBGLOG((ENABLE, "WARNING: scalingmode not supported by scaler %d\n", scaler_ID));
	}

	status = RUASetProperty(pMainContext->pRUA, scaler_ID, RMGenericPropertyID_BlackStripColor,
				&(pDisplayOptions->strip_color), sizeof(pDisplayOptions->strip_color), 0);
	if (status != RM_OK && status != RM_INVALIDMODE) {
		RMNOTIFY((NULL, status, "Cannot set strip color to scaler\n"));
		return status;
	} else if (status == RM_INVALIDMODE) {
		RMDBGLOG((ENABLE, "WARNING: blackstripcolor not supported by scaler %d\n", scaler_ID));
	}

	/* apply bcssh if any */

	status = RUASetProperty(pMainContext->pRUA, scaler_ID, RMGenericPropertyID_Contrast, &(pDisplayOptions->contrast), sizeof(pDisplayOptions->contrast), 0);
	if (status != RM_OK && status != RM_INVALIDMODE) {
		RMNOTIFY((NULL, status, "Cannot set contrast %d on scaler %d\n", pDisplayOptions->contrast, scaler_ID));
		return status;
	} else if (status == RM_INVALIDMODE) {
		RMDBGLOG((ENABLE, "WARNING: contrast not supported by scaler %d\n", scaler_ID));
	}

	status = RUASetProperty(pMainContext->pRUA, scaler_ID, RMGenericPropertyID_CbSaturation, &(pDisplayOptions->saturation_blue), sizeof(pDisplayOptions->saturation_blue), 0);

	if (status != RM_OK && status != RM_INVALIDMODE) {
		RMNOTIFY((NULL, status, "Cannot set cbsaturation %d on scaler %d\n", pDisplayOptions->saturation_blue, scaler_ID));
		return status;
	} else if (status == RM_INVALIDMODE) {
		RMDBGLOG((ENABLE, "WARNING: cbsaturation not supported by scaler %d\n", scaler_ID));
	}

	status = RUASetProperty(pMainContext->pRUA, scaler_ID, RMGenericPropertyID_CrSaturation, &(pDisplayOptions->saturation_red), sizeof(pDisplayOptions->saturation_red), 0);

	if (status != RM_OK && status != RM_INVALIDMODE) {
		RMNOTIFY((NULL, status, "Cannot set crsaturation %d on scaler %d\n", pDisplayOptions->saturation_red, scaler_ID));
		return status;
	} else if (status == RM_INVALIDMODE) {
		RMDBGLOG((ENABLE, "WARNING: crsaturation not supported by scaler %d\n", scaler_ID));
	}

	status = RUASetProperty(pMainContext->pRUA, scaler_ID, RMGenericPropertyID_Brightness, &(pDisplayOptions->brightness), sizeof(pDisplayOptions->brightness), 0);

	if (status != RM_OK && status != RM_INVALIDMODE) {
		RMNOTIFY((NULL, status, "Cannot set brightness %d on scaler %d\n", pDisplayOptions->brightness, scaler_ID));
		return status;
	} else if (status == RM_INVALIDMODE) {
		RMDBGLOG((ENABLE, "WARNING: brightness not supported by scaler %d\n", scaler_ID));
	}

	/* apply nonlinear if any */
	status = RUASetProperty(pMainContext->pRUA, scaler_ID, RMGenericPropertyID_NonLinearScalingMode,
				&(pDisplayOptions->nonlinearmode), sizeof(pDisplayOptions->nonlinearmode), 0);

	if (status != RM_OK && status != RM_INVALIDMODE) {
		RMNOTIFY((NULL, status, "Cannot set nonlinear mode on scaler %d\n", scaler_ID));
		return status;
	} else if (status == RM_INVALIDMODE) {
		RMDBGLOG((ENABLE, "WARNING: nonlinear not supported by scaler %d\n", scaler_ID));
	}

	return status;
}


/**************************************************************************************************/
/*******************************	   Exported function	 ******************************/
/**************************************************************************************************/

RMstatus apply_video_scaler_option(struct rmfp_main_thread_context_type *pMainContext)
{
	RMstatus status;
	RMuint32 mixer;
	enum EMhwlibMixerSourceState state;
	RMuint32 src_index, mixer_src = 0;
	RMuint32 scaler_ID;
#ifdef RMFEATURE_HAS_DEDICATED_DEINTERLACING
	RMbool enable;
#endif
	struct DisplayOptions * pDisplayOptions = &(pMainContext->AppOptions.Display);

	scaler_ID = pDisplayOptions->scaler_ID;

	if (scaler_ID == (RMuint32)-1) {
		RMDBGLOG((ENABLE, "No scaler, don't apply scaler options\n"));
		return RM_OK;
	}

	/* Get the right mixer respect to route */
	switch (pDisplayOptions->route) {
	case RMFPRoute_Main: mixer = DispMainMixer; break;
	case RMFPRoute_Secondary: mixer = DispVCRMixer; break;
	case RMFPRoute_ColorBars: mixer = DispColorBars; break;
	default:
		RMNOTIFY((NULL, RM_ERROR, "Invalid route %d\n", pDisplayOptions->route));
		return RM_ERROR;
	}

	if (pMainContext->ActiveScalers & VIDEO_SCALER_ACTIVE) {
		apply_common_scaler_option(pMainContext, pDisplayOptions, scaler_ID);

		DCCSP(pMainContext->pRUA, scaler_ID, RMGenericPropertyID_ScalerInputWindow, &(pDisplayOptions->source_window), sizeof(pDisplayOptions->source_window));

		status = RUASetProperty(pMainContext->pRUA, scaler_ID, RMGenericPropertyID_ScalerFieldSelection,
					&(pDisplayOptions->field_selection), sizeof(pDisplayOptions->field_selection), 0);

		if (status != RM_OK && status != RM_INVALIDMODE) {
			RMNOTIFY((NULL, status, "Cannot set field selection to scaler\n"));
			return status;
		}

		/* down scaling for main and crt vct gfx only */
		{
			enum RMcategoryID surface_category = EMHWLIB_MODULE_CATEGORY(scaler_ID);
			if( surface_category==DispMainVideoScaler
			    || surface_category==DispVCRMultiScaler
			    || surface_category==DispCRTMultiScaler
			    || surface_category==DispGFXMultiScaler ) {
				status = RUASetProperty(pMainContext->pRUA, scaler_ID, RMGenericPropertyID_DownScalingMode, &(pDisplayOptions->downscalingmode), sizeof(pDisplayOptions->downscalingmode), 0);
				if (status != RM_OK) {
					RMNOTIFY((NULL, status, "Cannot set downscaling mode on scaler\n"));
					return status;
				}
			}
		}

		/* Deinterlacing */
#ifdef RMFEATURE_HAS_DEDICATED_DEINTERLACING
		if ((pDisplayOptions->deinterlacingmode == EMhwlibDeinterlacingMode_MotionAdaptative ||
		     pDisplayOptions->deinterlacingmode == EMhwlibDeinterlacingMode_MotionAdaptative_4field) &&
		    scaler_ID == DispMainVideoScaler && mixer == DispMainMixer) {
#else
		if (pDisplayOptions->deinterlacingmode == EMhwlibDeinterlacingMode_MotionAdaptative &&
		    scaler_ID == DispMainVideoScaler && mixer == DispMainMixer) {
#endif


			struct DispMainMixer_LayerOrder_type layer;
			RMuint32 deinterlacing_scaler;
			RMbool enable = TRUE;

			layer.Layer0SourceModuleID = EMHWLIB_MODULE(DispCRTMultiScaler, 0);
			layer.Layer1SourceModuleID = EMHWLIB_MODULE(DispVCRMultiScaler, 0);
			layer.Layer2SourceModuleID = EMHWLIB_MODULE(DispMainVideoScaler, 0);
			layer.Layer3SourceModuleID = EMHWLIB_MODULE(DispGFXMultiScaler, 0);
			layer.Layer4SourceModuleID = EMHWLIB_MODULE(DispOSDScaler, 0);
			layer.Layer5SourceModuleID = EMHWLIB_MODULE(DispSubPictureScaler, 0);
			layer.Layer6SourceModuleID = EMHWLIB_MODULE(DispGraphicInput, 0);
			DCCSP(pMainContext->pRUA, DispMainMixer, RMDispMainMixerPropertyID_LayerOrder, &layer, sizeof(layer));

#ifdef RMFEATURE_HAS_VCR_SCALER
			deinterlacing_scaler = EMHWLIB_MODULE(DispVCRMultiScaler, 0);
#else
			deinterlacing_scaler = EMHWLIB_MODULE(DispGFXMultiScaler, 0);
#endif

			status = RUASetProperty(pMainContext->pRUA, deinterlacing_scaler, RMGenericPropertyID_Enable, &enable, sizeof(enable), 0);
			if (status != RM_OK) {
				RMNOTIFY((NULL, status, "Cannot enable deinterlacing scaler\n"));
				return status;
			}

			status = RUAExchangeProperty(pMainContext->pRUA, mixer, RMGenericPropertyID_MixerSourceIndex, &(deinterlacing_scaler), sizeof(deinterlacing_scaler), &src_index, sizeof(src_index));
			if (status != RM_OK) {
				RMNOTIFY((NULL, status, "Cannot get scaler index\n"));
				return status;
			}
			mixer_src = EMHWLIB_TARGET_MODULE(EMHWLIB_MODULE_CATEGORY(mixer), 0 , src_index);

			/* the deinterlacing scaler MUST be set as slave in the mixer */
			state = EMhwlibMixerSourceState_Slave;

			status = RUASetProperty(pMainContext->pRUA, mixer_src, RMGenericPropertyID_MixerSourceState, &state, sizeof(state), 0);
			if (status != RM_OK) {
				RMNOTIFY((NULL, status, "Cannot set scaler's state on mixer\n"));
				return status;
			}

			status = RUASetProperty(pMainContext->pRUA, mixer_src, RMGenericPropertyID_Validate, NULL, 0, 0);
			if (status != RM_OK) {
				RMNOTIFY((NULL, status, "Cannot validate mixer\n"));
				return status;
			}

			status = RUASetProperty(pMainContext->pRUA, scaler_ID, RMDispMainVideoScalerPropertyID_DeinterlacingMotionScaler, &(deinterlacing_scaler), sizeof(deinterlacing_scaler), 0);
			if (status != RM_OK) {
				RMNOTIFY((NULL, status, "Cannot set deinterlacing scaler\n"));
				return status;
			}

#ifdef RMFEATURE_HAS_DEDICATED_DEINTERLACING
			status = RUASetProperty(pMainContext->pRUA, DispDeinterlacer, RMDispDeinterlacerPropertyID_MotionAdaptativeConfig, &(pDisplayOptions->deinterlacing_motion_config), sizeof(pDisplayOptions->deinterlacing_motion_config), 0);
#else
			status = RUASetProperty(pMainContext->pRUA, scaler_ID, RMDispMainVideoScalerPropertyID_DeinterlacingMotionConfig, &(pDisplayOptions->deinterlacing_motion_config), sizeof(pDisplayOptions->deinterlacing_motion_config), 0);
#endif
			if (status != RM_OK) {
				RMNOTIFY((NULL, status, "Cannot config motion adaptive deinterlacing\n"));
				return status;
			}

			status = RUASetProperty(pMainContext->pRUA, deinterlacing_scaler, RMGenericPropertyID_Validate, NULL, 0, 0);
			if (status != RM_OK) {
				RMNOTIFY((NULL, status, "Cannot validate deinterlacing scaler\n"));
				return status;
			}

		}

#ifdef RMFEATURE_HAS_DEDICATED_DEINTERLACING
		/* tango3 platform : deinterlacing proportion only applies for constant blend */
		if ((pDisplayOptions->deinterlacingmode == EMhwlibDeinterlacingMode_ConstantBlend) &&
		    scaler_ID == DispMainVideoScaler && mixer == DispMainMixer) {
#else
		/* tango2 platform: deinterlacing proprotion applies on adaptive deinterlace AND constant blend */
		if ((pDisplayOptions->deinterlacingmode == EMhwlibDeinterlacingMode_MotionAdaptative ||
		     pDisplayOptions->deinterlacingmode == EMhwlibDeinterlacingMode_ConstantBlend) &&
		    scaler_ID == DispMainVideoScaler && mixer == DispMainMixer) {

#endif
			status = RUASetProperty(pMainContext->pRUA, DispMainVideoScaler, RMDispMainVideoScalerPropertyID_DeinterlacingProportion, &(pDisplayOptions->deinterlacing_proportion), sizeof(pDisplayOptions->deinterlacing_proportion), 0);
			if (status != RM_OK) {
				RMNOTIFY((NULL, status, "Cannot set deinterlacing proportion\n"));
				return status;
			}
		}

		status = RUASetProperty(pMainContext->pRUA, scaler_ID, RMDispMainVideoScalerPropertyID_DeinterlacingMode, &(pDisplayOptions->deinterlacingmode), sizeof(pDisplayOptions->deinterlacingmode), 0);
		if (status != RM_OK && status != RM_INVALIDMODE) {
			RMNOTIFY((NULL, status, "Cannot set deinterlacing mode\n"));
			return status;
		}

#ifdef RMFEATURE_HAS_DEDICATED_DEINTERLACING
		if (pDisplayOptions->deinterlacingmode == EMhwlibDeinterlacingMode_MotionAdaptative_4field)
			enable = TRUE;
		else
			enable = FALSE;

		status = RUASetProperty(pMainContext->pRUA, DispDeinterlacer, RMDispDeinterlacerPropertyID_FourFieldMode, &enable, sizeof(enable), 0);
		if (status != RM_OK && status != RM_INVALIDMODE) {
			RMNOTIFY((NULL, status, "Cannot set deinterlacing mode\n"));
			return status;
		}

		status = RUASetProperty(pMainContext->pRUA, DispDeinterlacer, RMDispDeinterlacerPropertyID_Window0, &(pDisplayOptions->deinterlacing_window0), sizeof(pDisplayOptions->deinterlacing_window0), 0);
		if (status != RM_OK && status != RM_INVALIDMODE) {
			RMNOTIFY((NULL, status, "Cannot set deinterlacing window 0\n"));
			return status;
		}

		status = RUASetProperty(pMainContext->pRUA, DispDeinterlacer, RMDispDeinterlacerPropertyID_Window1, &(pDisplayOptions->deinterlacing_window1), sizeof(pDisplayOptions->deinterlacing_window1), 0);
		if (status != RM_OK && status != RM_INVALIDMODE) {
			RMNOTIFY((NULL, status, "Cannot set deinterlacing window 1\n"));
			return status;
		}

		enable = FALSE;
		status = RUASetProperty(pMainContext->pRUA, DispDeinterlacer, RMDispDeinterlacerPropertyID_Window0OnTop, &enable, sizeof(enable), 0);
		if (status != RM_OK && status != RM_INVALIDMODE) {
			RMNOTIFY((NULL, status, "Cannot set window 1 on top\n"));
			return status;
		}

		status = RUASetProperty(pMainContext->pRUA, DispDeinterlacer, RMGenericPropertyID_Validate, NULL, 0, 0);
		if (status != RM_OK && status != RM_INVALIDMODE) {
			RMNOTIFY((NULL, status, "Cannot validate deinterlacing\n"));
			return status;
		}

#endif
		status = RUASetProperty(pMainContext->pRUA, scaler_ID, RMGenericPropertyID_Alpha0, &(pDisplayOptions->video_alpha), sizeof(pDisplayOptions->video_alpha), 0);
		if (status != RM_OK) {
			RMNOTIFY((NULL, status, "Cannot set video alpha\n"));
			return status;
		}

		status = RUASetProperty(pMainContext->pRUA, scaler_ID, RMGenericPropertyID_LumaKeying, &(pDisplayOptions->luma_key), sizeof(pDisplayOptions->luma_key), 0);
		if ((status != RM_OK) && (status != RM_INVALIDMODE) && (status != RM_NOT_SUPPORTED)) {
			RMNOTIFY((NULL, status, "Cannot set luma keying\n"));
			return status;
		}

		status = RUASetProperty(pMainContext->pRUA, scaler_ID, RMDispMainVideoScalerPropertyID_Enable_3_2_PullDownDetection, &(pDisplayOptions->do_pulldown), sizeof(pDisplayOptions->do_pulldown), 0);
		if (status != RM_OK && status != RM_INVALIDMODE) {
			RMNOTIFY((NULL, status, "Cannot enable 3:2 pulldown detection\n"));
			return status;
		}


		status = RUASetProperty(pMainContext->pRUA, scaler_ID, RMGenericPropertyID_DisplayTimeInterval, &(pDisplayOptions->time_interval), sizeof(pDisplayOptions->time_interval), 0);
		if (status != RM_OK && status != RM_INVALIDMODE) {
			RMNOTIFY((NULL, status, "Cannot set time interval\n"));
			return status;
		}

		status = RUASetProperty(pMainContext->pRUA, scaler_ID, RMDispMainVideoScalerPropertyID_FilterSelection, &(pDisplayOptions->filtermode), sizeof(pDisplayOptions->filtermode), 0);
		if (status != RM_OK && status != RM_INVALIDMODE) {
			RMNOTIFY((NULL, status, "Cannot set filter mode\n"));
			return status;
		}


		status = RUASetProperty(pMainContext->pRUA, scaler_ID, RMDispMainVideoScalerPropertyID_WideBandwidthFilterBoundary, &(pDisplayOptions->wide_bw_filter_boundary), sizeof(pDisplayOptions->wide_bw_filter_boundary), 0);
		if (status != RM_OK && status != RM_INVALIDMODE) {
			RMNOTIFY((NULL, status, "Cannot set wide bw filter boundary\n"));
			return status;
		}

		RMDBGLOG((ENABLE, "Time Interval: %d %lu %lu\n", pDisplayOptions->time_interval.Mode, pDisplayOptions->time_interval.StartPTSLo, pDisplayOptions->time_interval.EndPTSLo));


		status = RUASetProperty(pMainContext->pRUA, scaler_ID, RMGenericPropertyID_Validate, NULL, 0, 0);
		if (status != RM_OK) {
			RMNOTIFY((NULL, status, "Cannot validate scaler\n"));
			return status;
		}

		if (pDisplayOptions->force_mixer_color_space == TRUE) {

			struct EMhwlibColor YCbCrFull_black    = {128,   0, 128};
			struct EMhwlibColor YCbCrLimited_black = {128,  16, 128};
			struct EMhwlibColor RGBFull_black      = {  0,   0,   0};
			struct EMhwlibColor RGBLimited_black   = { 16,  16,  16};
			struct EMhwlibColor *black = NULL;
			RMbool enable = FALSE;
			status = RUASetProperty(pMainContext->pRUA, mixer, RMGenericPropertyID_ColorSpace, &(pDisplayOptions->mixer_color_space), sizeof(pDisplayOptions->mixer_color_space), 0);
			if (status != RM_OK) {
				RMNOTIFY((NULL, status, "Cannot force mixer colorspace to %p\n",pDisplayOptions->mixer_color_space));
				return status;
			}

			switch (pDisplayOptions->mixer_color_space) {
			case EMhwlibColorSpace_None:
				break;
			case EMhwlibColorSpace_RGB_16_235:
				black = &RGBLimited_black;
				break;
			case EMhwlibColorSpace_RGB_0_255:
				black = &RGBFull_black;
				break;
			case EMhwlibColorSpace_YUV_601:
			case EMhwlibColorSpace_YUV_709:
			case EMhwlibColorSpace_xvYCC_601:
			case EMhwlibColorSpace_xvYCC_709:
				black = &YCbCrLimited_black;
				break;
			case EMhwlibColorSpace_YUV_601_0_255:
			case EMhwlibColorSpace_YUV_709_0_255:
			case EMhwlibColorSpace_xvYCC_601_0_255:
			case EMhwlibColorSpace_xvYCC_709_0_255:
				black = &YCbCrFull_black;
				break;
			}
			if (black) {
				status = RUASetProperty(pMainContext->pRUA, mixer, RMGenericPropertyID_BackgroundColor, black, sizeof(struct EMhwlibColor), 0);
				if (status != RM_OK) {
					RMNOTIFY((NULL, status, "Can not set property BackGroundColor on mixer\n"));
					return status;
				}
				enable = TRUE;
			} else {
				enable = FALSE;
			}

			status =  RUASetProperty(pMainContext->pRUA, mixer, RMGenericPropertyID_ForceBackGround, &enable, sizeof(enable), 0);
			if (status != RM_OK) {
				RMNOTIFY((NULL, status, "Can not set property ForceBackGround on mixer\n"));
			}
		}

		if (mixer == DispMainMixer) {

			status = RUAExchangeProperty(pMainContext->pRUA, mixer, RMGenericPropertyID_MixerSourceIndex, &(scaler_ID), sizeof(scaler_ID), &src_index, sizeof(src_index));
			if (status != RM_OK) {
				RMNOTIFY((NULL, status, "Cannot get scaler index\n"));
				return status;
			}
			mixer_src = EMHWLIB_TARGET_MODULE(EMHWLIB_MODULE_CATEGORY(mixer), 0 , src_index);

			state = EMhwlibMixerSourceState_Master;
			DCCSP(pMainContext->pRUA, mixer_src, RMGenericPropertyID_MixerSourceState,&(state), sizeof(state));
			/*
			{
				RMuint32 RetryCount = 0;
				struct RUAEvent event = { 0, };

				while (RM_PENDING == (status = RUASetProperty(pMainContext->pRUA, mixer_src, RMGenericPropertyID_MixerSourceState, &state, sizeof(state), 0))) {
					RUAWaitForMultipleEvents(pMainContext->pRUA, &event, 1, TIMEOUT_US, NULL);
					RMDBGPRINT((LOCALDBG, "."));

					if (RetryCount++ > RETRY_THRESHOLD) {
						RMNOTIFY((NULL, RM_TIMEOUT, "Cannot set scaler's state on mixer\n"));
						break;
					}
				};
			}
			*/
			status = RUASetProperty(pMainContext->pRUA, mixer_src, RMGenericPropertyID_Validate, NULL, 0, 0);
			if (status != RM_OK) {
				RMNOTIFY((NULL, status, "Cannot validate mixer\n"));
				return status;
			}
			DCCSP(pMainContext->pRUA, mixer_src, RMGenericPropertyID_MixerSourceWindow,&(pDisplayOptions->output_window), sizeof(pDisplayOptions->output_window));
			/*
			{
				RMuint32 RetryCount = 0;
				struct RUAEvent event = { 0, };

				while (RM_PENDING == (status = RUASetProperty(pMainContext->pRUA, mixer_src, RMGenericPropertyID_MixerSourceWindow, &(pDisplayOptions->output_window), sizeof(pDisplayOptions->output_window), 0))) {
					RUAWaitForMultipleEvents(pMainContext->pRUA, &event, 1, TIMEOUT_US, NULL);
					RMDBGPRINT((LOCALDBG, "."));

					if (RetryCount++ > RETRY_THRESHOLD) {
						RMNOTIFY((NULL, RM_TIMEOUT, "Cannot set deinterlacing mode\n"));
						break;
					}
				};

				if (RMFAILED(status)) {
					RMNOTIFY((NULL, status, "Cannot set mixer source window\n"));
					return status;
				}
			}
			*/

			status = RUASetProperty(pMainContext->pRUA, mixer_src, RMGenericPropertyID_LockMixerSourceScalingMode, &(pDisplayOptions->lock_scaler), sizeof(pDisplayOptions->lock_scaler), 0);
			if (status != RM_OK) {
				RMNOTIFY((NULL, status, "Cannot set lock scaler\n"));
				return status;
			}

			status = RUASetProperty(pMainContext->pRUA, mixer_src, RMGenericPropertyID_Validate, NULL, 0, 0);
			if (status != RM_OK) {
				RMNOTIFY((NULL, status, "Cannot validate mixer\n"));
				return status;
			}

		}
		else{

			status = RUAExchangeProperty(pMainContext->pRUA, DispMainMixer, RMGenericPropertyID_MixerSourceIndex, &(scaler_ID), sizeof(scaler_ID), &src_index, sizeof(src_index));
			if (status != RM_OK) {
				RMNOTIFY((NULL, status, "Cannot get scaler index\n"));
				return status;
			}
			mixer_src = EMHWLIB_TARGET_MODULE(EMHWLIB_MODULE_CATEGORY(DispMainMixer), 0 , src_index);

			state = EMhwlibMixerSourceState_Slave;
			DCCSP(pMainContext->pRUA, mixer_src, RMGenericPropertyID_MixerSourceState, &(state), sizeof(state));

			status = RUASetProperty(pMainContext->pRUA, mixer_src, RMGenericPropertyID_Validate, NULL, 0, 0);
			if (status != RM_OK) {
				RMNOTIFY((NULL, status, "Cannot validate mixer\n"));
				return status;
			}
		}

	}

	RMDBGLOG((CRASHDBG, "leave %s\n", __FUNCTION__));
		
	return RM_OK;
}

void local_hdmi_update_loop(void *c)
{
	RMstatus err;
	struct rmfp_main_thread_context_type *context = (struct rmfp_main_thread_context_type *)c;
	struct rmoutput_edid_target_options resolution_target_orig = context->display_opt->resolution_target;  // backup of user request
	RMuint32 VideoDecoderModuleID = 0;

	do {
		if (context->dh_info == NULL) continue;

		if (hdmi_thread && hdmi_semaphore) {
			err = RMTryWaitForSemaphore(hdmi_semaphore);
			if (RMFAILED(err)) {
				RMNOTIFY((NULL, err, "Failed to wait for thread lock!\n"));
				continue;
			}
		}
		
		/* Handle HDMI events: HotPlug, HDCP, etc. */
		rmoutput_display_update(context->pHWLib, context->dh_info, context->display_opt, context->display_conf);

		if (context->dh_info->CEC.Update) {
			if (context->dh_info->CEC.Standby) {
				fprintf(stderr, "CEC REQUEST:      ---   S T A N D B Y   ---\n");
				context->ReceivedCECStandby = TRUE;
				context->dh_info->CEC.Standby = FALSE;
			}
			if (context->dh_info->CEC.Wakeup) {
				fprintf(stderr, "CEC REQUEST:      ---   W A K E U P   ---\n");
				context->dh_info->CEC.Wakeup = FALSE;
			}
			context->dh_info->CEC.Update = FALSE;
		}

		/* xvYCC (extended gamut color) setup */
		/* if (context->pHandle) { */
		/*	 VideoDecoderModuleID = context->pHandle->video_resources.decoder_module_ID; */
		if (context->pOptions) {
			VideoDecoderModuleID = EMHWLIB_MODULE(VideoDecoder, context->pOptions->video_options.DecoderIndex);
		} else {
			VideoDecoderModuleID = 0;
		}
		if (VideoDecoderModuleID) {  // TODO: utilize callback after user data event from video decoder
			struct EMhwlibAVCHDColorInf AVCHDColorInf;

			err = context->pHWLib->get_prop(context->pHWLib->context,
				VideoDecoderModuleID,
				RMGenericPropertyID_AVCHDColorInf,
				&AVCHDColorInf, sizeof(AVCHDColorInf));
			if (RMSUCCEEDED(err) && AVCHDColorInf.New) {
				enum EMhwlibColorSpace InputColorSpace, OutputColorSpace;
				RMuint8 ColorimetrySupportMask = 0;
				struct VideoDecoder_ForceColorSpace_type ForceColorSpace;
				struct EMhwlibVideoFrameDescription InputFrameInfo;
				struct EMhwlibVideoFrameDescriptionForce FrameInfoForce;
				struct hdmi_InfoFrame GamutMetaData;
				RMbool Enable = TRUE, Repeat = TRUE;
				RMbool EDIDGamutSupport = FALSE;

				/* Determine xv color space of video */
				err = context->pHWLib->get_prop(context->pHWLib->context,
					VideoDecoderModuleID,
					RMGenericPropertyID_FrameInfo,
					&InputFrameInfo, sizeof(InputFrameInfo));
				if (RMSUCCEEDED(err)) {
					InputColorSpace = InputFrameInfo.ColorSpace;
					switch (InputColorSpace) {
					case EMhwlibColorSpace_YUV_601:
						InputColorSpace = EMhwlibColorSpace_xvYCC_601;
						break;
					case EMhwlibColorSpace_YUV_709:
						InputColorSpace = EMhwlibColorSpace_xvYCC_709;
						break;
					case EMhwlibColorSpace_YUV_601_0_255:
						InputColorSpace = EMhwlibColorSpace_xvYCC_601_0_255;
						break;
					case EMhwlibColorSpace_YUV_709_0_255:
						InputColorSpace = EMhwlibColorSpace_xvYCC_709_0_255;
						break;
					case EMhwlibColorSpace_xvYCC_601:
					case EMhwlibColorSpace_xvYCC_601_0_255:
					case EMhwlibColorSpace_xvYCC_709:
					case EMhwlibColorSpace_xvYCC_709_0_255:
						/* already xv color */
						break;
					case EMhwlibColorSpace_RGB_16_235:
					case EMhwlibColorSpace_RGB_0_255:
						/* When video is RGB, xvYCC is not possible. */
						AVCHDColorInf.Valid = FALSE;
						break;
					default:
						switch (context->pOptions->video_options.cs_algo) {
						case EMhwlibDefaultColorSpaceAlgoritm_601:
							InputColorSpace = EMhwlibColorSpace_xvYCC_601;
							break;
						case EMhwlibDefaultColorSpaceAlgoritm_709:
							InputColorSpace = EMhwlibColorSpace_xvYCC_709;
							break;
						case EMhwlibDefaultColorSpaceAlgoritm_SD601_HD709:
						default:
							InputColorSpace = (InputFrameInfo.BarInfo.FrameSizeX <= 720) ? EMhwlibColorSpace_xvYCC_601 : EMhwlibColorSpace_xvYCC_709;
						}
					}
				} else {
					InputColorSpace = EMhwlibColorSpace_xvYCC_709;
				}

				/* Determine xv color space of HDMI output */
				OutputColorSpace = context->display_conf->dig_config.FrameInfoForce.FrameInfo.ColorSpace;
				switch (OutputColorSpace) {
				case EMhwlibColorSpace_YUV_601:
					OutputColorSpace = EMhwlibColorSpace_xvYCC_601;
					ColorimetrySupportMask = CEA861_COLORIMETRY_XVYCC601;
					break;
				case EMhwlibColorSpace_YUV_709:
					OutputColorSpace = EMhwlibColorSpace_xvYCC_709;
					ColorimetrySupportMask = CEA861_COLORIMETRY_XVYCC709;
					break;
				case EMhwlibColorSpace_YUV_601_0_255:
					OutputColorSpace = EMhwlibColorSpace_xvYCC_601_0_255;
					ColorimetrySupportMask = CEA861_COLORIMETRY_XVYCC601;
					break;
				case EMhwlibColorSpace_YUV_709_0_255:
					OutputColorSpace = EMhwlibColorSpace_xvYCC_709_0_255;
					ColorimetrySupportMask = CEA861_COLORIMETRY_XVYCC709;
					break;
				case EMhwlibColorSpace_xvYCC_601:
				case EMhwlibColorSpace_xvYCC_601_0_255:
					/* already xv color */
					ColorimetrySupportMask = CEA861_COLORIMETRY_XVYCC601;
					break;
				case EMhwlibColorSpace_xvYCC_709:
				case EMhwlibColorSpace_xvYCC_709_0_255:
					/* already xv color */
					ColorimetrySupportMask = CEA861_COLORIMETRY_XVYCC709;
					break;
				case EMhwlibColorSpace_RGB_16_235:
				case EMhwlibColorSpace_RGB_0_255:
					/* When HDMI output is RGB, xvYCC is not possible. */
					Enable = FALSE;
					break;
				default:
					OutputColorSpace = EMhwlibColorSpace_xvYCC_709;  // TODO select 601 for SDTV/EDTV material (picture width <= 720)
					ColorimetrySupportMask = CEA861_COLORIMETRY_XVYCC709;
				}

				/* Set up Gamut Metadata packet */
				RMMemset(&GamutMetaData, 0, sizeof(GamutMetaData));
				GamutMetaData.HeaderByte[0] = hdmi_PacketType_GamutMetadata;

				/* Update EDID request, for HotPlug cycles (future HDMI displays) */
				if (AVCHDColorInf.Valid) {
					/* construct Gamut Metadata packet from color_inf */
					GamutMetaData.HeaderByte[1] = 0x00; // GBD Profile P0
					GamutMetaData.HeaderByte[2] = 0x30; // only packet, affects current video
					RMMemcpy(GamutMetaData.PacketByte, AVCHDColorInf.color_inf, 10);

					/* remember xv color space as EDID selection target */
					context->display_opt->resolution_target.target_cs = OutputColorSpace;

					/* remember GamutMetaData packet */
					RMMemcpy(&(context->display_opt->hdmi_options.GamutMetaData), &GamutMetaData, sizeof(GamutMetaData));
				} else {
					/* revert EDID selection target */
					context->display_opt->resolution_target.target_cs = resolution_target_orig.target_cs;

					/* revert GamutMetaData packet */
					context->display_opt->hdmi_options.GamutMetaData.HeaderByte[0] = 0;

					/* disable GamutMetaData packet */
					Enable = FALSE;
				}

				// Check for xv.Color support in current EDID */
				if (context->dh_info->hdmi && context->dh_info->hdmi->EDIDParsed) {
					RMuint32 i;
					for (i = 0; i < context->dh_info->hdmi->nDBC; i++) {
						if (context->dh_info->hdmi->DBC[i].ColorimetryValid) {
							if (
								(context->dh_info->hdmi->DBC[i].ColorimetrySupport & ColorimetrySupportMask) &&
								(context->dh_info->hdmi->DBC[i].MetaDataProfile & CEA861_METADATAPROFILE_MD0)
							) {
								fprintf(stderr, "EDID support for requested gamut meta data profile 0\n");
								EDIDGamutSupport = TRUE;
							}
						}
					}
				}
				if (! EDIDGamutSupport) {
					if (ColorimetrySupportMask) fprintf(stderr, "EDID does not support the requested gamut meta data profile!\n");
					Enable = FALSE;
				}

				/* Apply xv.Color, or not, to current HDMI display */
				if (AVCHDColorInf.Valid && EDIDGamutSupport) {
					/* force xvYCC color space on digital output */
					FrameInfoForce.FrameInfo.ColorSpace = OutputColorSpace;
				} else {
					/* revert color space on digital output */
					FrameInfoForce.FrameInfo.ColorSpace = context->display_conf->dig_config.FrameInfoForce.FrameInfo.ColorSpace;
					OutputColorSpace = context->display_conf->avi_config.FrameInfoForce.FrameInfo.ColorSpace;
				}

				/* Apply surface color space */
				if (AVCHDColorInf.Valid) {
					/* force xvYCC surface color space */
					ForceColorSpace.Enable = TRUE;
					ForceColorSpace.ColorSpace = InputColorSpace;
				} else {
					/* revert surface color space */
					//ForceColorSpace.Enable = context->pHandle->video_options.force_input_color_space;
					//ForceColorSpace.ColorSpace = context->pHandle->video_options.input_color_space;
					ForceColorSpace.Enable = context->pOptions->video_options.force_input_color_space;
					ForceColorSpace.ColorSpace = context->pOptions->video_options.input_color_space;
				}
				err = context->pHWLib->set_prop(context->pHWLib->context,
					VideoDecoderModuleID,
					RMVideoDecoderPropertyID_ForceColorSpace,
					&ForceColorSpace, sizeof(ForceColorSpace));
				if (RMFAILED(err)) RMNOTIFY((NULL, err, "Can not set Input Color Space\n"));

				/* Apply digital output color space */
				FrameInfoForce.ClearMask = 0;
				FrameInfoForce.ForceMask = EMHWLIB_FRAMEINFO_MASK_ColorSpace;
				err = context->pHWLib->set_pending_prop(context->pHWLib->context,
					context->display_conf->dig_config.OutputModuleID,
					RMGenericPropertyID_FrameInfoForce,
					&FrameInfoForce, sizeof(FrameInfoForce));
				if (RMFAILED(err)) RMNOTIFY((NULL, err, "Can not set FrameInfoForce"));
				err = context->pHWLib->set_pending_prop(context->pHWLib->context,
					context->display_conf->dig_config.OutputModuleID,
					RMGenericPropertyID_Validate, NULL, 0);
				if (RMFAILED(err)) RMNOTIFY((NULL, err, "Can not validate Digital Output"));

				/* Apply HDMI color space */
				if (context->dh_info->hdmi) {
					/* set color space in HDMI AVI InfoFrame */
					err = hdmi_packet_AVI_ColorSpace(context->dh_info->hdmi->pHDMI,
						OutputColorSpace,
						context->display_conf->avi_config.FrameInfoForce.FrameInfo.SamplingMode);
					if (RMFAILED(err)) RMNOTIFY((NULL, err, "Can not set HDMI color space\n"));

					err = hdmi_packet(context->dh_info->hdmi->pHDMI, Enable, Repeat, &GamutMetaData, 0);
					if (RMFAILED(err)) RMNOTIFY((NULL, err, "Can not enable Gamut MetaData packet\n"));
				}
			}
		}
		if (hdmi_thread && hdmi_semaphore) {
			RMReleaseSemaphore(hdmi_semaphore, 1);
		}
		RMMicroSecondSleep(50*1000);
	} while (run_hdmi);
}


/**************************************************************************************************/
/*******************************	    Static functions	 ******************************/
/**************************************************************************************************/

static RMstatus _get_command(struct rmfp_main_thread_context_type *pMainContext, RMuint32 AvailableCommandsMask, 
	struct RMFPPlaybackCommand *pCommand, RMuint32 TimeOutInMicroSeconds)
{
	RMuint32 elements_in_command_table = sizeof(command_table) / sizeof (struct commands);
	RMascii key = '\0';
	RMuint32 i,j;
	RMstatus status;
	RMbool is_special_char = FALSE;
	RMbool InjectCommand = FALSE;
	struct dh_context *dh_info;

	ASSERT_NULL_POINTER(pMainContext);
	ASSERT_NULL_POINTER(pCommand);

	dh_info = pMainContext->dh_info;
	/* Reset command */
	RMMemset(pCommand,0,sizeof(struct RMFPPlaybackCommand));

	if (dh_info && dh_info->CEC.PlayModeUpdate) {  // Handle CEC PlayMode changes
		switch (dh_info->CEC.PlayMode) {
		case CEC_PlayMode_PlayForward:
			RMDBGLOG((ENABLE, "[CEC] ===Play===\n"));
			//if (*pStandby) {
			//	wakeup_local(dh_info);
			//	dh_info->CEC.PowerStatus = CEC_PowerStatus_On;
			//	*pStandby = FALSE;
			//}
			InjectCommand = TRUE;
			key = KEY_COMMAND_PLAY;
			break;
		case CEC_PlayMode_PlayReverse:
			RMDBGLOG((ENABLE, "[CEC] ===PlayReverse===\n"));
			pCommand->command = RMFP_Playback_command_IBackward;
			pCommand->params.speed.N = -1;
			pCommand->params.speed.M = 1;
			pMainContext->iframing = TRUE;
			if (dh_info) dh_info->CEC.DeckInfo = CEC_DeckInfo_PlayReverse;
			dh_info->CEC.PlayModeUpdate = FALSE;
			goto COMMAND_PROCESSED;
		case CEC_PlayMode_PlayStill:
			RMDBGLOG((ENABLE, "[CEC] ===Still===\n"));
			InjectCommand = TRUE;
			key = KEY_COMMAND_PAUSE;
			break;
		case CEC_PlayMode_FastForwardMinSpeed:
			pCommand->params.speed.N = 2;
			if (0)
		case CEC_PlayMode_FastForwardMediumSpeed:
			pCommand->params.speed.N = 8;
			if (0)
		case CEC_PlayMode_FastForwardMaxSpeed:
			pCommand->params.speed.N = 30;
			RMDBGLOG((ENABLE, "[CEC] ===FastForward===\n"));
			pCommand->command = RMFP_Playback_command_IForward;
			pCommand->params.speed.M = 1;
			pMainContext->iframing = TRUE;
			if (dh_info) dh_info->CEC.DeckInfo = CEC_DeckInfo_FastForward;
			dh_info->CEC.PlayModeUpdate = FALSE;
			goto COMMAND_PROCESSED;
		case CEC_PlayMode_FastReverseMinSpeed:
			pCommand->params.speed.N = -2;
			if (0)
		case CEC_PlayMode_FastReverseMediumSpeed:
			pCommand->params.speed.N = -8;
			if (0)
		case CEC_PlayMode_FastReverseMaxSpeed:
			pCommand->params.speed.N = -30;
			RMDBGLOG((ENABLE, "[CEC] ===FastReverse===\n"));
			pCommand->command = RMFP_Playback_command_IBackward;
			pCommand->params.speed.M = 1;
			pMainContext->iframing = TRUE;
			if (dh_info) dh_info->CEC.DeckInfo = CEC_DeckInfo_FastReverse;
			dh_info->CEC.PlayModeUpdate = FALSE;
			goto COMMAND_PROCESSED;
		case CEC_PlayMode_SlowForwardMinSpeed:
			pCommand->params.speed.M = 30;
			if (0)
		case CEC_PlayMode_SlowForwardMediumSpeed:
			pCommand->params.speed.M = 8;
			if (0)
		case CEC_PlayMode_SlowForwardMaxSpeed:
			pCommand->params.speed.M = 2;
			RMDBGLOG((ENABLE, "[CEC] ===Slow===\n"));
			pCommand->command = RMFP_Playback_command_Play;
			pCommand->params.speed.N = 1;
			if (dh_info) dh_info->CEC.DeckInfo = CEC_DeckInfo_Slow;
			dh_info->CEC.PlayModeUpdate = FALSE;
			goto COMMAND_PROCESSED;
		case CEC_PlayMode_SlowReverseMinSpeed:
			pCommand->params.speed.M = 30;
			if (0)
		case CEC_PlayMode_SlowReverseMediumSpeed:
			pCommand->params.speed.M = 8;
			if (0)
		case CEC_PlayMode_SlowReverseMaxSpeed:
			pCommand->params.speed.M = 2;
			RMDBGLOG((ENABLE, "[CEC] ===SlowReverse===\n"));
			pCommand->command = RMFP_Playback_command_IBackward;
			pCommand->params.speed.N = -1;
			pMainContext->iframing = TRUE;
			if (dh_info) dh_info->CEC.DeckInfo = CEC_DeckInfo_SlowReverse;
			dh_info->CEC.PlayModeUpdate = FALSE;
			goto COMMAND_PROCESSED;
		}
		dh_info->CEC.PlayModeUpdate = FALSE;
	} else if (dh_info && dh_info->CEC.DeckControlModeUpdate) {  // Handle CEC DeckControl
		switch (dh_info->CEC.DeckControlMode) {
		case CEC_DeckControlMode_SkipForwardWind:
			RMDBGLOG((ENABLE, "[CEC] ===SkipForwardWind===\n"));
			InjectCommand = TRUE;
			key = KEY_COMMAND_IFRAMES_FWD;
			break;
		case CEC_DeckControlMode_SkipReverseRewind:
			RMDBGLOG((ENABLE, "[CEC] ====SkipReverseRewind==\n"));
			InjectCommand = TRUE;
			key = KEY_COMMAND_IFRAMES_BWD;
			break;
		case CEC_DeckControlMode_Stop:
			RMDBGLOG((ENABLE, "[CEC] ===Stop===\n"));
			InjectCommand = TRUE;
			key = KEY_COMMAND_STOP;
			break;
		case CEC_DeckControlMode_Eject:
			RMDBGLOG((ENABLE, "[CEC] ===Eject===\n"));
			InjectCommand = TRUE;
			key = KEY_COMMAND_QUIT_ALL;
			//if (*pStandby) {
			//	wakeup_local(dh_info);
			//	dh_info->CEC.PowerStatus = CEC_PowerStatus_On;
			//	*pStandby = FALSE;
			//}
			break;
		}
		dh_info->CEC.DeckControlModeUpdate = FALSE;
	} else if (RMKeyAvailable(TimeOutInMicroSeconds)) {
		key = RMGetKeyExtended(&is_special_char);

		// rmoutput debugger
		if (pMainContext->pDebug && (! is_special_char)) {
			// in initial state: consumes '?Ig%#$@', passes all others with RM_PENDING
			status = rmoutput_debugger(pMainContext->pDebug, key);
			if (RMSUCCEEDED(status)) {
				return RM_PENDING;  // everything is done already, no further processing
			}
		}

		InjectCommand = TRUE;
	} else if (dh_info) {
		RMbool Pressed;
		enum CEC_LogicalAddress Addr;
		enum CEC_UICommand Command;

		status = rmoutput_cec_received_user_command(dh_info,
			&Pressed, &Addr, &Command);
		if (RMFAILED(status)) return RM_PENDING;
		if (Pressed) {
			RMDBGLOG((ENABLE, "[CEC] UICommand 0x%02X from %u Pressed\n", Command, Addr));
			// TODO: react to commands, change playback state and CEC.DeckInfo accordingly
			switch (Command) {
			case CEC_UICommand_Play:
			case CEC_UICommand_PlayFunction:
				RMDBGLOG((ENABLE, "[CEC] ===Play===\n"));
				//if (*pStandby) {
				//	wakeup_local(dh_info);
				//	dh_info->CEC.PowerStatus = CEC_PowerStatus_On;
				//	*pStandby = FALSE;
				//}
				InjectCommand = TRUE;
				key = KEY_COMMAND_PLAY;
				break;
			case CEC_UICommand_Pause:
				RMDBGLOG((ENABLE, "[CEC] ===Pause===\n"));
				InjectCommand = TRUE;
				key = KEY_COMMAND_PAUSE;
				break;
			case CEC_UICommand_PausePlayFunction:
				if (dh_info->CEC.DeckInfo == CEC_DeckInfo_Play) {
					RMDBGLOG((ENABLE, "[CEC] ===Pause===\n"));
					InjectCommand = TRUE;
					key = KEY_COMMAND_PAUSE;
				} else {
					RMDBGLOG((ENABLE, "[CEC] ===Play===\n"));
					InjectCommand = TRUE;
					key = KEY_COMMAND_PLAY;
				}
				break;
			case CEC_UICommand_Stop:
			case CEC_UICommand_StopFunction:
				RMDBGLOG((ENABLE, "[CEC] ===Stop===\n"));
				InjectCommand = TRUE;
				key = KEY_COMMAND_STOP;
				break;
			case CEC_UICommand_Rewind:
				RMDBGLOG((ENABLE, "[CEC] ====Rewind==\n"));
				pCommand->command = RMFP_Playback_command_IBackward;
				pCommand->params.speed.N = -4;
				pCommand->params.speed.M = 1;
				pMainContext->iframing = TRUE;
				if (dh_info) dh_info->CEC.DeckInfo = CEC_DeckInfo_FastReverse;
				goto COMMAND_PROCESSED;
			case CEC_UICommand_FastForward:
				RMDBGLOG((ENABLE, "[CEC] ===FastForward===\n"));
				InjectCommand = TRUE;
				key = KEY_COMMAND_FAST_FWD_ALL_FRAMES;
				dh_info->CEC.DeckInfo = CEC_DeckInfo_FastForward; // SkipForwardWind?
				break;
			case CEC_UICommand_Eject:
				RMDBGLOG((ENABLE, "[CEC] ===Eject/Quit===\n"));
				InjectCommand = TRUE;
				key = KEY_COMMAND_QUIT_ALL;
				//if (*pStandby) {
				//	wakeup_local(dh_info);
				//	dh_info->CEC.PowerStatus = CEC_PowerStatus_On;
				//	*pStandby = FALSE;
				//}
				break;
			case CEC_UICommand_Forward:
				RMDBGLOG((ENABLE, "[CEC] ===Forward===\n"));
				InjectCommand = TRUE;
				if (dh_info->CEC.DeckInfo == CEC_DeckInfo_Still) {
					key = KEY_COMMAND_NEXT_PICT;
				} else {
					key = KEY_COMMAND_PLAY;
				}
				break;
			case CEC_UICommand_Backward:
				RMDBGLOG((ENABLE, "[CEC] ===Backward===\n"));
				InjectCommand = TRUE;
				is_special_char = TRUE;
				key = SPECIAL_KEY_COMMAND_IFRAMES_BWD;
				break;
			case CEC_UICommand_Power:
			case CEC_UICommand_PowerToggleFunction:
				//if (*pStandby) {
				//	wakeup_local(dh_info);
				//	dh_info->CEC.PowerStatus = CEC_PowerStatus_On;
				//} else {
				//	standby_local(dh_info);
				//	dh_info->CEC.PowerStatus = CEC_PowerStatus_Standby;
				//}
				//*pStandby = ! *pStandby;
				break;
			case CEC_UICommand_PowerOffFunction:
				//if (! *pStandby) {
				//	standby_local(dh_info);
				//	dh_info->CEC.PowerStatus = CEC_PowerStatus_Standby;
				//	*pStandby = TRUE;
				//}
				break;
			case CEC_UICommand_PowerOnFunction:
				//if (*pStandby) {
				//	wakeup_local(dh_info);
				//	dh_info->CEC.PowerStatus = CEC_PowerStatus_On;
				//	*pStandby = FALSE;
				//}
				break;
			case CEC_UICommand_Select:
			case CEC_UICommand_Up:
			case CEC_UICommand_Down:
			case CEC_UICommand_Left:
			case CEC_UICommand_Right:
			case CEC_UICommand_RightUp:
			case CEC_UICommand_RightDown:
			case CEC_UICommand_LeftUp:
			case CEC_UICommand_LeftDown:
			case CEC_UICommand_RootMenu:
			case CEC_UICommand_SetupMenu:
			case CEC_UICommand_ContentsMenu:
			case CEC_UICommand_FavoriteMenu:
			case CEC_UICommand_Exit:
			case CEC_UICommand_MediaTopMenu:
			case CEC_UICommand_MediaContextSensitiveMenu:
			case CEC_UICommand_NumberEntryMode:
			case CEC_UICommand_Number11:
			case CEC_UICommand_Number12:
			case CEC_UICommand_Number0:
			case CEC_UICommand_Number1:
			case CEC_UICommand_Number2:
			case CEC_UICommand_Number3:
			case CEC_UICommand_Number4:
			case CEC_UICommand_Number5:
			case CEC_UICommand_Number6:
			case CEC_UICommand_Number7:
			case CEC_UICommand_Number8:
			case CEC_UICommand_Number9:
			case CEC_UICommand_Dot:
			case CEC_UICommand_Enter:
			case CEC_UICommand_Clear:
			case CEC_UICommand_NextFavorite:
			case CEC_UICommand_ChannelUp:
			case CEC_UICommand_ChannelDown:
			case CEC_UICommand_PreviousChannel:
			case CEC_UICommand_SoundSelect:
			case CEC_UICommand_InputSelect:
			case CEC_UICommand_DisplayInformation:
			case CEC_UICommand_Help:
			case CEC_UICommand_PageUp:
			case CEC_UICommand_PageDown:
			case CEC_UICommand_VolumeUp:
			case CEC_UICommand_VolumeDown:
			case CEC_UICommand_Mute:
			case CEC_UICommand_Record:
			case CEC_UICommand_StopRecord:
			case CEC_UICommand_PauseRecord:
			case CEC_UICommand_Reserved:
			case CEC_UICommand_Angle:
			case CEC_UICommand_SubPicture:
			case CEC_UICommand_VideoOnDemand:
			case CEC_UICommand_ElectronicProgramGuide:
			case CEC_UICommand_TimerProgramming:
			case CEC_UICommand_InitialConfiguration:
			case CEC_UICommand_SelectBroadcastType:
			case CEC_UICommand_SelectSoundPresentation:
			case CEC_UICommand_RecordFunction:
			case CEC_UICommand_PauseRecordFunction:
			case CEC_UICommand_MuteFunction:
			case CEC_UICommand_RestoreVolumeFunction:
			case CEC_UICommand_TuneFunction:
			case CEC_UICommand_SelectMediaFunction:
			case CEC_UICommand_SelectAVInputFunction:
			case CEC_UICommand_SelectAudioInputFunction:
			case CEC_UICommand_F1Blue:
			case CEC_UICommand_F2Red:
			case CEC_UICommand_F3Green:
			case CEC_UICommand_F4Yellow:
			case CEC_UICommand_F5:
			case CEC_UICommand_Data:
				// not handled
				dh_info->CEC.FeatureAbortReason = CEC_AbortReason_UnrecognizedOpcode;
				dh_info->CEC.FeatureAbortAddr = Addr;
				dh_info->CEC.FeatureAbortOpcode = CEC_Opcode_UserControlPressed;
				dh_info->CEC.RequestFeatureAbort = TRUE;
				break;
			}
		} else {
			RMDBGLOG((ENABLE, "[CEC] UICommand from %u Released\n", Command, Addr));
			switch (dh_info->CEC.DeckInfo) {
			case CEC_DeckInfo_FastReverse:
			case CEC_DeckInfo_FastForward:
				RMDBGLOG((ENABLE, "[CEC] ===Play===\n"));
				InjectCommand = TRUE;
				key = KEY_COMMAND_PLAY;
				break;
			default:
				break;
			}
		}
	}
	if (! InjectCommand) return RM_PENDING;

	for (i = 0; i < elements_in_command_table; i++) {
		if ((key == command_table[i].key) && (is_special_char == command_table[i].special_char)) {

			RMint32 input;
			/* Check command mask */
			if (command_table[i].mask && !(AvailableCommandsMask & command_table[i].mask)) {
				//fprintf(NORMALMSG, "Key '%c' not allowed\n", key);
				return RM_PENDING;
			}
			if (is_special_char) {
				switch (key) {
				case SPECIAL_KEY_COMMAND_IFRAMES_BWD:

					if (!pMainContext->AppOptions.Playback.allow_special_keys) {
						RMDBGLOG((ENABLE, "special command 'Left arrow' not enabled\n"));
						return RM_PENDING;
					}

					if (pMainContext->iframing) {
						pCommand->command = RMFP_Playback_command_Play;  // PlayReverse;
						pCommand->params.speed.N = 1; // -1;
						pCommand->params.speed.M = 1;
						pMainContext->iframing = FALSE;
						if (dh_info) dh_info->CEC.DeckInfo = CEC_DeckInfo_Play; // PlayReverse;
					}
					else {
						pCommand->command = RMFP_Playback_command_IBackward;
						pCommand->params.speed.N = -5;
						pCommand->params.speed.M = 1;
						pMainContext->iframing = TRUE;
						if (dh_info) dh_info->CEC.DeckInfo = CEC_DeckInfo_FastReverse;
					}
					goto COMMAND_PROCESSED;
				case SPECIAL_KEY_COMMAND_IFRAMES_FWD:

					if (!pMainContext->AppOptions.Playback.allow_special_keys) {
						RMDBGLOG((ENABLE, "special command 'Right arrow' not enabled\n"));
						return RM_PENDING;
					}

					if (pMainContext->iframing) {
						pCommand->command = RMFP_Playback_command_Play;
						pCommand->params.speed.N = 1;
						pCommand->params.speed.M = 1;
						pMainContext->iframing = FALSE;
						if (dh_info) dh_info->CEC.DeckInfo = CEC_DeckInfo_Play;
					}
					else {
						pCommand->command = RMFP_Playback_command_IForward;
						pCommand->params.speed.N = 5;
						pCommand->params.speed.M = 1;
						pMainContext->iframing = TRUE;
						if (dh_info) dh_info->CEC.DeckInfo = CEC_DeckInfo_FastForward;
					}
					goto COMMAND_PROCESSED;
				case SPECIAL_KEY_COMMAND_NEXT_AUDIO:
				{
					struct RMFPStreamMetadata *pStreamMetadata = &(pMainContext->metadata);
					struct RMFPStreamProperties *pStreamProperties = &(pMainContext->stream_properties);
					RMascii* pDesc;
					RMint32 old_id;
					RMint32 new_id;
					RMint32 old_id_idx;
					RMint32 new_id_idx;

					if (!pMainContext->AppOptions.Playback.allow_special_keys) {
						RMDBGLOG((ENABLE, "special command 'Up arrow' not enabled\n"));
						return RM_PENDING;
					}

					if (pStreamMetadata->AudioStreams <= 1)
						goto COMMAND_PROCESSED;

					for ( j = 0; j<pStreamMetadata->AudioStreams; j++) {
						if ((RMint32)pStreamMetadata->AudioStreamList[j].StreamID == pStreamProperties->audio.id)
							break;
					}

					if (j<pStreamMetadata->AudioStreams) {
						pDesc = pStreamMetadata->AudioStreamList[j].pDescription;
						old_id = pStreamMetadata->AudioStreamList[j].StreamID;
						old_id_idx = j;
					} else {
						pDesc = "unknown";
						old_id = -1;
						old_id_idx = -1;
					}

					fprintf(NORMALMSG, "\n============== Next audio track =================\n\n");
					fprintf(NORMALMSG, " Current audio is %ld [%s]\n",
								old_id,
								pDesc);

					new_id_idx = (old_id_idx+1) % pStreamMetadata->AudioStreams;

					pDesc = pStreamMetadata->AudioStreamList[new_id_idx].pDescription;
					new_id = pStreamMetadata->AudioStreamList[new_id_idx].StreamID;

					fprintf(NORMALMSG, " Swithing to audio %ld [%s]\n",
								new_id,
								pDesc);
					fprintf(NORMALMSG, "\n=================================================\n\n");

					pCommand->command = RMFP_Playback_command_SwitchAudio;
					pCommand->params.switchAudio.stream = new_id;

					goto COMMAND_PROCESSED;
				}
				case SPECIAL_KEY_COMMAND_NEXT_SUBS:
				{
					struct RMFPStreamMetadata *pStreamMetadata = &(pMainContext->metadata);
					struct RMFPStreamProperties *pStreamProperties = &(pMainContext->stream_properties);
					RMascii* pDesc;
					RMint32 old_id;
					RMint32 new_id;
					RMint32 old_id_idx;
					RMint32 new_id_idx;

					if (!pMainContext->AppOptions.Playback.allow_special_keys) {
						RMDBGLOG((ENABLE, "special command 'Down arrow' not enabled\n"));
						return RM_PENDING;
					}

					if (pStreamMetadata->SPUStreams < 1)
						goto COMMAND_PROCESSED;

					if (pStreamProperties->subtitles.id == -1) {
						pDesc = "none";
						old_id = -1;
						old_id_idx = -1;
					} else {
						for ( j = 0; j<pStreamMetadata->SPUStreams; j++) {
							if ((RMint32)pStreamMetadata->SPUStreamList[j].StreamID == pStreamProperties->subtitles.id)
								break;
						}

						if (j<pStreamMetadata->SPUStreams) {
							pDesc = pStreamMetadata->SPUStreamList[j].pDescription;
							old_id = pStreamMetadata->SPUStreamList[j].StreamID;
							old_id_idx = j;
						} else {
							pDesc = "unknown";
							old_id = -1;
							old_id_idx = -1;
						}
					}


					fprintf(NORMALMSG, "\n=========== Next subtitles track ================\n\n");
					fprintf(NORMALMSG, " Current subtitle is %ld [%s]\n",
								old_id,
								pDesc);

					if ((RMuint32)(old_id_idx+1) == pStreamMetadata->SPUStreams)
						new_id_idx = -1;
					else
						new_id_idx = old_id_idx +1;

					if (new_id_idx == -1) {
						pDesc = "none";
						new_id = -1;
						/* Update value */
						pStreamProperties->subtitles.id = -1;
					} else {
						pDesc = pStreamMetadata->SPUStreamList[new_id_idx].pDescription;
						new_id = pStreamMetadata->SPUStreamList[new_id_idx].StreamID;
					}


					fprintf(NORMALMSG, " Swithing to subtitle %ld [%s]\n",
								new_id,
								pDesc);
					fprintf(NORMALMSG, "\n=================================================\n\n");

					pCommand->command = RMFP_Playback_command_SwitchSPU;
					pCommand->params.switchSPU.stream = new_id;

					goto COMMAND_PROCESSED;
				}
				default:
					RMDBGLOG((ENABLE, "special command '%c' not handled\n", key));
					return RM_PENDING;
				}
			}
			else
			{
				switch (key) {
				case KEY_COMMAND_PLAY:
					pCommand->command = RMFP_Playback_command_Play;
					pCommand->params.speed.N = 1;
					pCommand->params.speed.M = 1;
					pMainContext->iframing = FALSE;
					if (dh_info) {
						if ((dh_info->CEC.DeckInfo != CEC_DeckInfo_Play) && (dh_info->CEC.DeckInfo != CEC_DeckInfo_Still)) {
							// "One Touch Play" feature
							dh_info->CEC.RequestImageViewOn = TRUE;
							dh_info->CEC.RequestActiveSource = TRUE;
						}
						dh_info->CEC.DeckInfo = CEC_DeckInfo_Play;
					}
					goto COMMAND_PROCESSED;
				case KEY_COMMAND_PAUSE:
					pCommand->command = RMFP_Playback_command_Pause;
					pCommand->params.pause.type = RMFP_pause_default;

					if (dh_info) dh_info->CEC.DeckInfo = CEC_DeckInfo_Still;
					goto COMMAND_PROCESSED;
				case KEY_COMMAND_RESUME:
					pCommand->command = RMFP_Playback_command_Resume;
					if (dh_info) dh_info->CEC.DeckInfo = CEC_DeckInfo_Play;
					goto COMMAND_PROCESSED;
				case KEY_COMMAND_STOP:
					pCommand->command = RMFP_Playback_command_Stop;
					pCommand->params.stop.type = RMFP_stop_type_blackframe;
					if (dh_info) {
						dh_info->CEC.DeckInfo = CEC_DeckInfo_Stop;
					}
					goto COMMAND_PROCESSED;
				case KEY_COMMAND_SEEK_TO_TIME:
					fprintf(NORMALMSG, "Enter seek time in seconds:\n");

					print_seek_bounds(pMainContext);

					RMTermGetInt32(&input);

					status = check_seek_bounds(pMainContext, input);
					if (status == RM_OK) {

						pCommand->command = RMFP_Playback_command_Seek;
						pCommand->params.seek.type = RMFP_seek_to_time;

						pCommand->params.seek.to.time = input;
						pCommand->params.seek.to.time *= 1000; // the time is in millisec

						RMDBGLOG((ENABLE, "%ld ms\n", pCommand->params.seek.to.time));

						pCommand->params.seek.stop_type = RMFP_seek_stop_new_frame;
						pCommand->params.seek.command_after_seek.command = RMFP_Playback_command_Resume;
						if (dh_info) dh_info->CEC.DeckInfo = CEC_DeckInfo_Play;

						goto COMMAND_PROCESSED;
					}
					else
						return RM_PENDING;

					break;
				case KEY_COMMAND_SEEK_TO_PERCENT:
					fprintf(NORMALMSG, "Enter seek position in percentage:\n");
					fprintf(NORMALMSG, "Valid range [0, 100]; Enter any invalid value to ignore the command\n");
					pCommand->command = RMFP_Playback_command_Seek;
					pCommand->params.seek.type = RMFP_seek_to_percentage;
					RMTermGetInt32(&input);

					if (((input >= 0) && (input < 100)) || !USE_BOUNDS_CHECKING) {
						pCommand->params.seek.to.percentage = input;

						RMDBGLOG((ENABLE, "%ld percent\n", pCommand->params.seek.to.percentage));

						pCommand->params.seek.stop_type = RMFP_seek_stop_new_frame;
						pCommand->params.seek.command_after_seek.command = RMFP_Playback_command_Resume;
						if (dh_info) dh_info->CEC.DeckInfo = CEC_DeckInfo_Play;

						goto COMMAND_PROCESSED;
					}
					else {
						fprintf(NORMALMSG, "Invalid value %ld\n", input);
						return RM_PENDING;
					}

					break;
				case KEY_COMMAND_NEXT_PICT:
					pCommand->command = RMFP_Playback_command_NextPicture;
					goto COMMAND_PROCESSED;
				case KEY_COMMAND_IFRAMES_FWD:
					pCommand->command = RMFP_Playback_command_IForward;
					pCommand->params.speed.N = 4;
					pCommand->params.speed.M = 1;
					pMainContext->iframing = TRUE;
					if (dh_info) dh_info->CEC.DeckInfo = CEC_DeckInfo_SkipForwardWind;
					goto COMMAND_PROCESSED;
				case KEY_COMMAND_IFRAMES_BWD:
					pCommand->command = RMFP_Playback_command_IBackward;
					pCommand->params.speed.N = -4;
					pCommand->params.speed.M = 1;
					pMainContext->iframing = TRUE;
					if (dh_info) dh_info->CEC.DeckInfo = CEC_DeckInfo_SkipReverseRewind;
					goto COMMAND_PROCESSED;
				case KEY_COMMAND_SILENT_FWD:
					pCommand->command = RMFP_Playback_command_SilentForward;
					pCommand->params.speed.N = 2;
					pCommand->params.speed.M = 1;
					if (dh_info) dh_info->CEC.DeckInfo = CEC_DeckInfo_SkipForwardWind;
					goto COMMAND_PROCESSED;
				case KEY_COMMAND_SILENT_BWD:
					pCommand->command = RMFP_Playback_command_SilentBackward;
					pCommand->params.speed.N = -2;
					pCommand->params.speed.M = 1;
					if (dh_info) dh_info->CEC.DeckInfo = CEC_DeckInfo_SkipReverseRewind;
					goto COMMAND_PROCESSED;
				case KEY_COMMAND_SWITCH_VIDEO:
					fprintf(NORMALMSG, "Enter video track:\n");

					print_track_bounds(pMainContext, PRINT_MASK_VIDEO);

					RMTermGetInt32(&input);

					status = check_track_bounds(pMainContext, input, PRINT_MASK_VIDEO);
					if (status == RM_OK) {

						pCommand->command = RMFP_Playback_command_SwitchVideo;
						pCommand->params.switchVideo.stream = input;
						RMDBGLOG((ENABLE, "%ld\n", pCommand->params.switchVideo.stream));

						goto COMMAND_PROCESSED;
					}
					return RM_PENDING;
				case KEY_COMMAND_SWITCH_AUDIO:
					fprintf(NORMALMSG, "Enter audio track:\n");

					print_track_bounds(pMainContext, PRINT_MASK_AUDIO);

					RMTermGetInt32(&input);

					status = check_track_bounds(pMainContext, input, PRINT_MASK_AUDIO);
					if (status == RM_OK) {

						pCommand->command = RMFP_Playback_command_SwitchAudio;
						pCommand->params.switchAudio.stream = input;
						RMDBGLOG((ENABLE, "%ld\n", pCommand->params.switchAudio.stream));

						goto COMMAND_PROCESSED;
					}
					return RM_PENDING;
				case KEY_COMMAND_SWITCH_SUBS:
					fprintf(NORMALMSG, "Enter spu track number:\n");

					print_track_bounds(pMainContext, PRINT_MASK_SUBS);

					RMTermGetInt32(&input);

					status = check_track_bounds(pMainContext, input, PRINT_MASK_SUBS);
					if (status == RM_OK) {

						pCommand->command = RMFP_Playback_command_SwitchSPU;
						pCommand->params.switchSPU.stream = input;
						RMDBGLOG((ENABLE, "%ld\n", pCommand->params.switchSPU.stream));

						goto COMMAND_PROCESSED;
					}
					return RM_PENDING;
				case KEY_COMMAND_SWITCH_PROGRAM:
					fprintf(NORMALMSG, "Enter PMT pid:\n");

					print_track_bounds(pMainContext, PRINT_MASK_PMT);

					RMTermGetInt32(&input);

					status = check_track_bounds(pMainContext, input, PRINT_MASK_PMT);
					if (status == RM_OK) {

						pCommand->command = RMFP_Playback_command_SwitchProgram;
						pCommand->params.switchProgram.stream = input;
						RMDBGLOG((ENABLE, "%ld\n", pCommand->params.switchProgram.stream));

						goto COMMAND_PROCESSED;
					}
					return RM_PENDING;
				case KEY_COMMAND_SWITCH_VARIANT:
					fprintf(NORMALMSG, "Enter Variant Id:\n");

					print_track_bounds(pMainContext, PRINT_MASK_VARIANT);

					RMTermGetInt32(&input);

					status = check_track_bounds(pMainContext, input, PRINT_MASK_VARIANT);
					if (status == RM_OK) {

						pCommand->command = RMFP_Playback_command_SwitchVariant;
						pCommand->params.switchVariant.stream = input;
						RMDBGLOG((ENABLE, "%ld\n", pCommand->params.switchVariant.stream));

						goto COMMAND_PROCESSED;
					}
					return RM_PENDING;
				case KEY_COMMAND_PLAY_IFRAME:
					pCommand->command = RMFP_Playback_command_Play_Iframe;
					pCommand->params.speed.N = 1;
					pCommand->params.speed.M = 1;
					goto COMMAND_PROCESSED;
				case KEY_COMMAND_FAST_FWD_ALL_FRAMES:
					pCommand->command = RMFP_Playback_command_Play;
					pCommand->params.speed.N = 4;
					pCommand->params.speed.M = 1;
					if (dh_info) dh_info->CEC.DeckInfo = CEC_DeckInfo_FastForward;
					goto COMMAND_PROCESSED;
				case KEY_COMMAND_FAST_FWD_WITH_AUDIO:
					pCommand->command = RMFP_Playback_command_Play;
					pCommand->params.speed.N = 20;
					pCommand->params.speed.M = 10;
					if (dh_info) dh_info->CEC.DeckInfo = CEC_DeckInfo_FastForward;
					goto COMMAND_PROCESSED;
				case KEY_COMMAND_SLOW_FWD_ALL_FRAMES:
					pCommand->command = RMFP_Playback_command_Play;
					pCommand->params.speed.N = 1;
					pCommand->params.speed.M = 4;
					if (dh_info) dh_info->CEC.DeckInfo = CEC_DeckInfo_Slow;
					goto COMMAND_PROCESSED;
				case KEY_COMMAND_SLOW_FWD_WITH_AUDIO:
					pCommand->command = RMFP_Playback_command_Play;
					pCommand->params.speed.N = 5;
					pCommand->params.speed.M = 10;
					if (dh_info) dh_info->CEC.DeckInfo = CEC_DeckInfo_Slow;
					goto COMMAND_PROCESSED;
				case KEY_COMMAND_QUIT:
					pCommand->command = RMFP_Playback_command_Quit;
					if (dh_info) {
						dh_info->CEC.DeckInfo = CEC_DeckInfo_NoMedia;
					}
					goto COMMAND_PROCESSED;
				case KEY_COMMAND_DEBUG:
					pCommand->command = RMFP_Playback_command_Debug;
					pCommand->params.debug.type = 0;
					pCommand->params.debug.param = 0;
					goto COMMAND_PROCESSED;
				case KEY_COMMAND_PRINT_INFO:
					pCommand->command = RMFP_Playback_command_Print_Information;
					pCommand->params.printInfo.type = 0;
					pCommand->params.printInfo.param = 0;
					// Also print local information
					print_information(pMainContext);
					goto COMMAND_PROCESSED;

				case KEY_COMMAND_PRINT_TXT:

					fprintf(NORMALMSG, "Enter page number to display (from 100 to 900, 1000 to exit teletext, 2000 to change mode mix/nonmix) \n");
					RMTermGetInt32(&input);
					if ( input >= 100 ) {
						parse_magazinePacketAddress(&pCommand->params.printTxt.page, &pCommand->params.printTxt.magazine, input);

						pCommand->command = RMFP_Playback_command_Print_Teletext;
					} else {
						RMDBGLOG((ENABLE, "page number is error\n"));
					}

					goto COMMAND_PROCESSED;

				case KEY_COMMAND_SWITCH_MULTICAST:
					pCommand->command = RMFP_Playback_command_SwitchMulticast;
					goto COMMAND_PROCESSED;
				case KEY_COMMAND_APPLY_AV_DELAY:
					pCommand->command = RMFP_Playback_command_ApplyDelayToOutputs;
					pCommand->params.outputDelay.Video = 1000;
					pCommand->params.outputDelay.Audio = 3000;
					goto COMMAND_PROCESSED;
				case KEY_COMMAND_SUBS_CHANGE_DELAY:
				{
					struct RMFPStreamMetadataSPUStreamEntry* pMetaData = get_current_subs_metadata(pMainContext, FALSE);

					if (!pMetaData || !(pMetaData->AllowedCommandsMask&RMFP_SUBS_ALLOW_CMD_SET_DELAY)) {
						RMNOTIFY((NULL, RM_ERROR, "Cannot change subs delay\n"));
						return RM_PENDING;
					}

					fprintf(NORMALMSG, "Enter new delay in ms (positive means later):\n");
					pCommand->command = RMFP_Playback_command_SubsParams;
					RMTermGetInt32(&input);
					pCommand->params.SubsParams.SetDelay = TRUE;
					pCommand->params.SubsParams.Delay_ms = input;
					goto COMMAND_PROCESSED;
				}
				case KEY_COMMAND_SUBS_INCREASE_FONT_SIZE:
				{
					struct RMFPStreamMetadataSPUStreamEntry* pMetaData = get_current_subs_metadata(pMainContext, FALSE);

					if (!pMetaData || !(pMetaData->AllowedCommandsMask&RMFP_SUBS_ALLOW_CMD_SET_FONTSIZE)) {
						RMNOTIFY((NULL, RM_ERROR, "Cannot change font size\n"));
						return RM_PENDING;
					}

					pCommand->command = RMFP_Playback_command_SubsParams;
					pMetaData->FontSize += 3;
					pCommand->params.SubsParams.SetFontSize = TRUE;
					pCommand->params.SubsParams.FontSize = pMetaData->FontSize;
					goto COMMAND_PROCESSED;
				}
				case KEY_COMMAND_SUBS_DECREASE_FONT_SIZE:
				{
					struct RMFPStreamMetadataSPUStreamEntry* pMetaData = get_current_subs_metadata(pMainContext, FALSE);
					if (!pMetaData || !(pMetaData->AllowedCommandsMask&RMFP_SUBS_ALLOW_CMD_SET_FONTSIZE)) {
						RMNOTIFY((NULL, RM_ERROR, "Cannot change font size\n"));
						return RM_PENDING;
					}
					if (pMetaData->FontSize <= 4) {
						RMNOTIFY((NULL, RM_ERROR, "Font already too small\n"));
						return RM_PENDING;
					}

					pCommand->command = RMFP_Playback_command_SubsParams;
					pMetaData->FontSize -= 3;
					pCommand->params.SubsParams.SetFontSize = TRUE;
					pCommand->params.SubsParams.FontSize = pMetaData->FontSize;
					goto COMMAND_PROCESSED;
				}
				case KEY_COMMAND_SUBS_INCREASE_POS_Y:
				{
					struct RMFPStreamMetadataSPUStreamEntry* pMetaData = get_current_subs_metadata(pMainContext, FALSE);

					if (!pMetaData || !(pMetaData->AllowedCommandsMask&RMFP_SUBS_ALLOW_CMD_SET_POSY)) {
						RMNOTIFY((NULL, RM_ERROR, "Cannot change Y position\n"));
						return RM_PENDING;
					}

					pCommand->command = RMFP_Playback_command_SubsParams;
					pMetaData->PosY += 10;
					pCommand->params.SubsParams.SetPosY = TRUE;
					pCommand->params.SubsParams.PosY = pMetaData->PosY;
					goto COMMAND_PROCESSED;
				}
				case KEY_COMMAND_SUBS_DECREASE_POS_Y:
				{
					struct RMFPStreamMetadataSPUStreamEntry* pMetaData = get_current_subs_metadata(pMainContext, FALSE);
					if (!pMetaData || !(pMetaData->AllowedCommandsMask&RMFP_SUBS_ALLOW_CMD_SET_POSY))
					{
						RMNOTIFY((NULL, RM_ERROR, "Cannot change Y position\n"));
						return RM_PENDING;
					}
					pCommand->command = RMFP_Playback_command_SubsParams;
					pMetaData->PosY -= 10;
					pCommand->params.SubsParams.SetPosY = TRUE;
					pCommand->params.SubsParams.PosY = pMetaData->PosY;
					goto COMMAND_PROCESSED;
				}
				case KEY_COMMAND_SUBS_SWITCH_ENCODING:
				{
					struct RMFPStreamMetadataSPUStreamEntry* pMetaData = get_current_subs_metadata(pMainContext, FALSE);
					if (!pMetaData || !(pMetaData->AllowedCommandsMask&RMFP_SUBS_ALLOW_CMD_SET_ENCODING)) {
						RMNOTIFY((NULL, RM_ERROR, "Cannot switch encoding\n"));
						return RM_PENDING;
					}

					pCommand->command = RMFP_Playback_command_SubsParams;

					if (pMetaData->Encoding == RMFPSubsEncoding_Latin) {
						fprintf(NORMALMSG, "Switching encoding to UTF8\n");
						pMetaData->Encoding = RMFPSubsEncoding_UTF8;
					}
					else {
						fprintf(NORMALMSG, "Switching encoding to latin1\n");
						pMetaData->Encoding = RMFPSubsEncoding_Latin;
					}
					pCommand->params.SubsParams.SetEncoding = TRUE;
					pCommand->params.SubsParams.Encoding = pMetaData->Encoding;
					goto COMMAND_PROCESSED;
				}
				case KEY_COMMAND_SUBS_RESET_ALL:
				{
					struct RMFPStreamMetadataSPUStreamEntry* pMetaData = get_current_subs_metadata(pMainContext, FALSE);
					struct RMFPStreamMetadataSPUStreamEntry* pDefaultsMetaData = get_current_subs_metadata(pMainContext, TRUE);

					if (!pMetaData || !pDefaultsMetaData) {
						RMNOTIFY((NULL, RM_ERROR, "Cannot reset subs defaults\n"));
						return RM_PENDING;
					}

					/* Restore backup */
					*pMetaData = *pDefaultsMetaData;

					pCommand->command = RMFP_Playback_command_SubsParams;
					pCommand->params.SubsParams.ResetToDefault = TRUE;
					goto COMMAND_PROCESSED;
				}
				case KEY_COMMAND_SUBS_CHANGE_COLOR:
				{
					struct RMFPStreamMetadataSPUStreamEntry* pMetaData = get_current_subs_metadata(pMainContext, FALSE);

					if (!pMetaData || !(pMetaData->AllowedCommandsMask&RMFP_SUBS_ALLOW_CMD_SET_FILLCOLOR)) {
						RMNOTIFY((NULL, RM_ERROR, "Cannot change color\n"));
						return RM_PENDING;
					}

					pCommand->command = RMFP_Playback_command_SubsParams;
					pCommand->params.SubsParams.SetFillColor = TRUE;
					pCommand->params.SubsParams.FillColor = RMGetTimeInMicroSeconds();
					pCommand->params.SubsParams.SetBorderColor = TRUE;
					pCommand->params.SubsParams.BorderColor = ~pCommand->params.SubsParams.FillColor;
					pCommand->params.SubsParams.FillColor |= 0xFF000000;
					pCommand->params.SubsParams.BorderColor |= 0xFF000000;

					goto COMMAND_PROCESSED;
				}
				case KEY_COMMAND_QUIT_ALL :
					pCommand->command = RMFP_Playback_command_Quit;
					pMainContext->quit = TRUE;
					if (dh_info) {
						dh_info->CEC.DeckInfo = CEC_DeckInfo_NoMedia;
					}
					goto COMMAND_PROCESSED;
				case KEY_COMMAND_FULL_SCREEN:
					if (pMainContext->ActiveScalers & pMainContext->ScalersOperationsMask & VIDEO_SCALER_ACTIVE) {
						pMainContext->AppOptions.Display.output_window.Width = 4096;
						pMainContext->AppOptions.Display.output_window.Height = 4096;

						pMainContext->AppOptions.Display.output_window.X = 2048;
						pMainContext->AppOptions.Display.output_window.Y = 2048;
						status = apply_scaler_window(pMainContext, pMainContext->AppOptions.Display.scaler_ID, DispMainMixer, &(pMainContext->AppOptions.Display.output_window));
						if (status != RM_OK) {
							RMNOTIFY((NULL, status, "Cannot apply video scaler options\n"));
							return status;
						}
					}
					if (pMainContext->ActiveScalers & pMainContext->ScalersOperationsMask & OSD_SCALER_ACTIVE) {
						/* Use stored info if available */
						if (pMainContext->OSDAvailable) {
							fill_output_osd_size(pMainContext, &pMainContext->OSDProfile, DispMainMixer);
						}
						else {
							pMainContext->applied_output_osd_window.Width = 4096 /* * 9 / 10 */ ;
							pMainContext->applied_output_osd_window.Height = 4096 /* * 9 / 10 */ ;
						}

						pMainContext->applied_output_osd_window.X = 2048;
						pMainContext->applied_output_osd_window.Y = 2048;

						status = apply_scaler_window(pMainContext, pMainContext->AppOptions.Display.osd_scaler_ID, DispMainMixer, &(pMainContext->applied_output_osd_window));
						if (status != RM_OK) {
							RMNOTIFY((NULL, status, "Cannot apply osd scaler options\n"));
							return status;
						}
					}

					return RM_PENDING;
				case KEY_COMMAND_HALF_SCREEN:
					if (pMainContext->ActiveScalers & pMainContext->ScalersOperationsMask & VIDEO_SCALER_ACTIVE) {
						pMainContext->AppOptions.Display.output_window.Width /= 2;
						pMainContext->AppOptions.Display.output_window.Height /= 2;

						status = apply_scaler_window(pMainContext, pMainContext->AppOptions.Display.scaler_ID, DispMainMixer, &(pMainContext->AppOptions.Display.output_window));
						if (status != RM_OK) {
							RMNOTIFY((NULL, status, "Cannot apply video scaler options\n"));
							return status;
						}
					}
					if (pMainContext->ActiveScalers & pMainContext->ScalersOperationsMask & OSD_SCALER_ACTIVE) {
						pMainContext->applied_output_osd_window.Width /= 2;
						pMainContext->applied_output_osd_window.Height /= 2;
						status = apply_scaler_window(pMainContext, pMainContext->AppOptions.Display.osd_scaler_ID, DispMainMixer, &(pMainContext->applied_output_osd_window));
						if (status != RM_OK) {
							RMNOTIFY((NULL, status, "Cannot apply osd scaler options\n"));
							return status;
						}
					}
					return RM_PENDING;
				case KEY_COMMAND_INCREASE_SIZE:
					if (pMainContext->ActiveScalers & pMainContext->ScalersOperationsMask & VIDEO_SCALER_ACTIVE) {
						pMainContext->AppOptions.Display.output_window.Width = pMainContext->AppOptions.Display.output_window.Width * 5 / 4;
						pMainContext->AppOptions.Display.output_window.Height = pMainContext->AppOptions.Display.output_window.Height * 5 / 4;
						status = apply_scaler_window(pMainContext, pMainContext->AppOptions.Display.scaler_ID, DispMainMixer, &(pMainContext->AppOptions.Display.output_window));
						if (status != RM_OK) {
							RMNOTIFY((NULL, status, "Cannot apply video scaler options\n"));
							return status;
						}
					}
					if (pMainContext->ActiveScalers & pMainContext->ScalersOperationsMask & OSD_SCALER_ACTIVE) {
						pMainContext->applied_output_osd_window.Width = pMainContext->applied_output_osd_window.Width * 5 / 4;
						pMainContext->applied_output_osd_window.Height = pMainContext->applied_output_osd_window.Height * 5 / 4;
						status = apply_scaler_window(pMainContext, pMainContext->AppOptions.Display.osd_scaler_ID, DispMainMixer, &(pMainContext->applied_output_osd_window));

						if (status != RM_OK) {
							RMNOTIFY((NULL, status, "Cannot apply osd scaler options\n"));
							return status;
						}
					}
					return RM_PENDING;
				case KEY_COMMAND_DECREASE_SIZE:
					if (pMainContext->ActiveScalers & pMainContext->ScalersOperationsMask & VIDEO_SCALER_ACTIVE) {
						pMainContext->AppOptions.Display.output_window.Width = pMainContext->AppOptions.Display.output_window.Width * 4 / 5;
						pMainContext->AppOptions.Display.output_window.Height = pMainContext->AppOptions.Display.output_window.Height * 4 / 5;
						status = apply_scaler_window(pMainContext, pMainContext->AppOptions.Display.scaler_ID, DispMainMixer, &(pMainContext->AppOptions.Display.output_window));
						if (status != RM_OK) {
							RMNOTIFY((NULL, status, "Cannot apply video scaler options\n"));
							return status;
						}
					}
					if (pMainContext->ActiveScalers & pMainContext->ScalersOperationsMask & OSD_SCALER_ACTIVE) {
						pMainContext->applied_output_osd_window.Width = pMainContext->applied_output_osd_window.Width * 4 / 5;
						pMainContext->applied_output_osd_window.Height = pMainContext->applied_output_osd_window.Height * 4 / 5;
						status = apply_scaler_window(pMainContext, pMainContext->AppOptions.Display.osd_scaler_ID, DispMainMixer, &(pMainContext->applied_output_osd_window));
						if (status != RM_OK) {
							RMNOTIFY((NULL, status, "Cannot apply osd scaler options\n"));
							return status;
						}

					}
					return RM_PENDING;
				case KEY_COMMAND_MOVE_LEFT:
					if (pMainContext->ActiveScalers & pMainContext->ScalersOperationsMask & VIDEO_SCALER_ACTIVE) {
						pMainContext->AppOptions.Display.output_window.X -= 128;
						status = apply_scaler_window(pMainContext, pMainContext->AppOptions.Display.scaler_ID, DispMainMixer, &(pMainContext->AppOptions.Display.output_window));
						if (status != RM_OK) {
							RMNOTIFY((NULL, status, "Cannot apply video scaler options\n"));
							return status;
						}

					}
					if (pMainContext->ActiveScalers & pMainContext->ScalersOperationsMask & OSD_SCALER_ACTIVE) {
						pMainContext->applied_output_osd_window.X -= 128;
						status = apply_scaler_window(pMainContext, pMainContext->AppOptions.Display.osd_scaler_ID, DispMainMixer, &(pMainContext->applied_output_osd_window));
						if (status != RM_OK) {
							RMNOTIFY((NULL, status, "Cannot apply osd scaler options\n"));
							return status;
						}

					}
					return RM_PENDING;
				case KEY_COMMAND_MOVE_RIGHT:
					if (pMainContext->ActiveScalers & pMainContext->ScalersOperationsMask & VIDEO_SCALER_ACTIVE) {
						pMainContext->AppOptions.Display.output_window.X += 128;
						status = apply_scaler_window(pMainContext, pMainContext->AppOptions.Display.scaler_ID, DispMainMixer, &(pMainContext->AppOptions.Display.output_window));
						if (status != RM_OK) {
							RMNOTIFY((NULL, status, "Cannot apply video scaler options\n"));
							return status;
						}

					}
					if (pMainContext->ActiveScalers & pMainContext->ScalersOperationsMask & OSD_SCALER_ACTIVE) {
						pMainContext->applied_output_osd_window.X += 128;
						status = apply_scaler_window(pMainContext, pMainContext->AppOptions.Display.osd_scaler_ID, DispMainMixer, &(pMainContext->applied_output_osd_window));
						if (status != RM_OK) {
							RMNOTIFY((NULL, status, "Cannot apply osd scaler options\n"));
							return status;
						}

					}
					return RM_PENDING;
				case KEY_COMMAND_MOVE_TOP:
					if (pMainContext->ActiveScalers & pMainContext->ScalersOperationsMask & VIDEO_SCALER_ACTIVE) {
						pMainContext->AppOptions.Display.output_window.Y -= 128;
						status = apply_scaler_window(pMainContext, pMainContext->AppOptions.Display.scaler_ID, DispMainMixer, &(pMainContext->AppOptions.Display.output_window));
						if (status != RM_OK) {
							RMNOTIFY((NULL, status, "Cannot apply video scaler options\n"));
							return status;
						}

					}
					if (pMainContext->ActiveScalers & pMainContext->ScalersOperationsMask & OSD_SCALER_ACTIVE) {

						pMainContext->applied_output_osd_window.Y -= 128;
						status = apply_scaler_window(pMainContext, pMainContext->AppOptions.Display.osd_scaler_ID, DispMainMixer, &(pMainContext->applied_output_osd_window));
						if (status != RM_OK) {
							RMNOTIFY((NULL, status, "Cannot apply osd scaler options\n"));
							return status;
						}

					}

					return RM_PENDING;
				case KEY_COMMAND_MOVE_BOTTOM:
					if (pMainContext->ActiveScalers & pMainContext->ScalersOperationsMask & VIDEO_SCALER_ACTIVE) {
						pMainContext->AppOptions.Display.output_window.Y += 128;
						status = apply_scaler_window(pMainContext, pMainContext->AppOptions.Display.scaler_ID, DispMainMixer, &(pMainContext->AppOptions.Display.output_window));
						if (status != RM_OK) {
							RMNOTIFY((NULL, status, "Cannot apply video scaler options\n"));
							return status;
						}

					}
					if (pMainContext->ActiveScalers & pMainContext->ScalersOperationsMask & OSD_SCALER_ACTIVE) {
						pMainContext->applied_output_osd_window.Y += 128;
						status = apply_scaler_window(pMainContext, pMainContext->AppOptions.Display.osd_scaler_ID, DispMainMixer, &(pMainContext->applied_output_osd_window));
						if (status != RM_OK) {
							RMNOTIFY((NULL, status, "Cannot apply osd scaler options\n"));
							return status;
						}

					}
					return RM_PENDING;
				case KEY_COMMAND_NONLINEAR_WIDTH:
					if (pMainContext->AppOptions.Display.nonlinearmode.Width >= 3)
						pMainContext->AppOptions.Display.nonlinearmode.Width = 0;
					else
						pMainContext->AppOptions.Display.nonlinearmode.Width ++;

					if (pMainContext->AppOptions.Display.blackstrip.Vertical == 4096 || pMainContext->AppOptions.Display.cutstrip.Horizontal == 4096) {

						RMDBGLOG((ENABLE, "blackstrip vertical = %d cutstrip horizontal = %d, changing non-linear scaling width may have no effect\n", pMainContext->AppOptions.Display.blackstrip.Vertical, pMainContext->AppOptions.Display.cutstrip.Horizontal ));
					}

					RMDBGLOG((ENABLE, "Non-linear scaling width: %ld\n", pMainContext->AppOptions.Display.nonlinearmode.Width));

					if (pMainContext->ActiveScalers & pMainContext->ScalersOperationsMask & VIDEO_SCALER_ACTIVE) {
						status = RUASetProperty(pMainContext->pRUA, pMainContext->AppOptions.Display.scaler_ID, RMGenericPropertyID_NonLinearScalingMode,&(pMainContext->AppOptions.Display.nonlinearmode), sizeof(pMainContext->AppOptions.Display.nonlinearmode), 0);
						if (status != RM_OK && status != RM_INVALIDMODE) {
							RMNOTIFY((NULL, status, "Cannot set non-linear selection to scaler\n"));
							return status;
						}
						status = RUASetProperty(pMainContext->pRUA, pMainContext->AppOptions.Display.scaler_ID, RMGenericPropertyID_Validate, NULL, 0, 0);
						if (status != RM_OK) {
							RMNOTIFY((NULL, status, "Cannot validate scaler\n"));
							return status;
						}
					}

					if (pMainContext->ActiveScalers & pMainContext->ScalersOperationsMask & OSD_SCALER_ACTIVE) {
						RMstatus status;
						status = RUASetProperty(pMainContext->pRUA, pMainContext->AppOptions.Display.osd_scaler_ID, RMGenericPropertyID_NonLinearScalingMode,&(pMainContext->AppOptions.Display.nonlinearmode), sizeof(pMainContext->AppOptions.Display.nonlinearmode), 0);
						if (status != RM_OK && status != RM_INVALIDMODE) {
							RMNOTIFY((NULL, status, "Cannot set non-linear selection to osd scaler\n"));
							return status;
						}
						status = RUASetProperty(pMainContext->pRUA, pMainContext->AppOptions.Display.osd_scaler_ID, RMGenericPropertyID_Validate, NULL, 0, 0);
						if (status != RM_OK) {
							RMNOTIFY((NULL, status, "Cannot validate osd scaler\n"));
							return status;
						}

					}

					return RM_PENDING;
				case KEY_COMMAND_NONLINEAR_LEVEL:
					if (pMainContext->AppOptions.Display.nonlinearmode.Level >= 3)
						pMainContext->AppOptions.Display.nonlinearmode.Level = 0;
					else
						pMainContext->AppOptions.Display.nonlinearmode.Level ++;

					if (pMainContext->AppOptions.Display.blackstrip.Vertical == 4096 || pMainContext->AppOptions.Display.cutstrip.Horizontal == 4096) {

						RMDBGLOG((ENABLE, "blackstrip vertical = %d cutstrip horizontal = %d, changing non-linear scaling level may have no effect\n", pMainContext->AppOptions.Display.blackstrip.Vertical, pMainContext->AppOptions.Display.cutstrip.Horizontal));
					}

					RMDBGLOG((ENABLE, "Non-linear scaling level: %ld\n", pMainContext->AppOptions.Display.nonlinearmode.Level));
					if (pMainContext->ActiveScalers & pMainContext->ScalersOperationsMask & VIDEO_SCALER_ACTIVE) {
						status = RUASetProperty(pMainContext->pRUA, pMainContext->AppOptions.Display.scaler_ID, RMGenericPropertyID_NonLinearScalingMode,&(pMainContext->AppOptions.Display.nonlinearmode), sizeof(pMainContext->AppOptions.Display.nonlinearmode), 0);
						if (status != RM_OK && status != RM_INVALIDMODE) {
							RMNOTIFY((NULL, status, "Cannot set non-linear selection to scaler\n"));
							return status;
						}
						status = RUASetProperty(pMainContext->pRUA, pMainContext->AppOptions.Display.scaler_ID, RMGenericPropertyID_Validate, NULL, 0, 0);
						if (status != RM_OK) {
							RMNOTIFY((NULL, status, "Cannot validate scaler\n"));
							return status;
						}
					}

					if (pMainContext->ActiveScalers & pMainContext->ScalersOperationsMask & OSD_SCALER_ACTIVE) {
						RMstatus status;
						status = RUASetProperty(pMainContext->pRUA, pMainContext->AppOptions.Display.osd_scaler_ID, RMGenericPropertyID_NonLinearScalingMode,&(pMainContext->AppOptions.Display.nonlinearmode), sizeof(pMainContext->AppOptions.Display.nonlinearmode), 0);
						if (status != RM_OK && status != RM_INVALIDMODE) {
							RMNOTIFY((NULL, status, "Cannot set non-linear selection to osd scaler\n"));
							return status;
						}
						status = RUASetProperty(pMainContext->pRUA, pMainContext->AppOptions.Display.osd_scaler_ID, RMGenericPropertyID_Validate, NULL, 0, 0);
						if (status != RM_OK) {
							RMNOTIFY((NULL, status, "Cannot validate osd scaler\n"));
							return status;
						}

					}

					return RM_PENDING;
				case KEY_COMMAND_SWITCH_SCALER:
					if ((pMainContext->ActiveScalers & VIDEO_SCALER_ACTIVE) && ( pMainContext->ActiveScalers & OSD_SCALER_ACTIVE)) {
						if (pMainContext->ScalersOperationsMask == pMainContext->ActiveScalers) {
							pMainContext->ScalersOperationsMask = VIDEO_SCALER_ACTIVE;
							RMDBGLOG((ENABLE, "Switch on VIDEO scaler\n"));
						}
						else if (pMainContext->ScalersOperationsMask == VIDEO_SCALER_ACTIVE) {
							pMainContext->ScalersOperationsMask = OSD_SCALER_ACTIVE;
							RMDBGLOG((ENABLE, "Switch on OSD scaler\n"));
						}
						else if (pMainContext->ScalersOperationsMask == OSD_SCALER_ACTIVE) {
							pMainContext->ScalersOperationsMask = pMainContext->ActiveScalers;
							RMDBGLOG((ENABLE, "Switch on BOTH scalers\n"));
						}

					}

					return RM_PENDING;
				case KEY_COMMAND_HELP:
					show_available_commands(pMainContext);
					return RM_PENDING;
				case KEY_COMMAND_STANDBY:
					run_hdmi = FALSE;
					if (hdmi_thread) {
						RMWaitForThreadToFinish(hdmi_thread);
						if (hdmi_semaphore) {
							RMDeleteSemaphore(hdmi_semaphore);
							hdmi_semaphore = NULL;
						}
						hdmi_thread = NULL;
					}
					if (! pMainContext->AppOptions.Playback.no_disp) {
						status = rmoutput_display_close(pMainContext->pHWLib, pMainContext->dh_info, pMainContext->display_opt, pMainContext->display_conf);
						if (RMFAILED(status)) {
							fprintf(stderr, "Can not close display! %s\n", RMstatusToString(status));
						}
					}
					system("echo standby > /proc/tangoxfreq/standby");
					return RM_PENDING;
				case KEY_COMMAND_WAKEUP:
					rmoutput_init_display_context(pMainContext->display_opt, pMainContext->display_conf, &(pMainContext->pHWLib), &(pMainContext->dh_info));
					// Connect RUA to rmoutput
					if (RMFAILED(status = rmoutput_rua_fill_callbacks(pMainContext->pRUA, pMainContext->pHWLib))) {
						fprintf(stderr, "Error creating rmoutput instance! %s\n", RMstatusToString(status));
						return RM_PENDING;
					}
					/* Initialize video and audio outputs */
					status = rmoutput_apply_display_options(pMainContext->pHWLib, pMainContext->dh_info, pMainContext->display_opt, pMainContext->display_conf);
					if (RMFAILED(status)) {
						fprintf(stderr, "Can not set display options! %s\n", RMstatusToString(status));
					}
					run_hdmi = TRUE;
					hdmi_semaphore = RMCreateSemaphore(1);
					hdmi_thread = RMCreateThreadWithPriority("HDMIUpdateThread",
						(RMfunc)local_hdmi_update_loop,
						(void *)(pMainContext),
						FALSE,
						pMainContext->AppOptions.Playback.hdmi_nice);
					return RM_PENDING;
				default:
					RMDBGLOG((ENABLE, "command '%c' not handled\n", key));
					return RM_PENDING;
				}
			}
		}
	}

	/* Not found in table */
	return RM_PENDING;

COMMAND_PROCESSED:
	return RM_OK;
}

/**************************************************************************************************/

static RMstatus show_available_commands(struct rmfp_main_thread_context_type *pMainContext)
{
	RMuint32 i;
	RMuint32 elements_in_command_table = sizeof(command_table) / sizeof (struct commands);
	RMuint32 mask;

	ASSERT_NULL_POINTER(pMainContext);

	mask = pMainContext->availableCommandsMask;

	fprintf(NORMALMSG, "\n============== Available Commands ===============\n");
	for (i = 0; i < elements_in_command_table; i++) {

		/* Do not print debug command */
		if (command_table[i].mask == RMFP_ENABLE_COMMAND_DEBUG)
			continue;

		/* Do not print special commands */
		if (command_table[i].special_char && !pMainContext->AppOptions.Playback.allow_special_keys)
			continue;

		if ((mask & command_table[i].mask) || (command_table[i].mask == 0))
			fprintf(NORMALMSG, "\t'%c' - %s\n", command_table[i].key, command_table[i].description);
	}
	fprintf(NORMALMSG, "\t'?' - Debugger help\n");
	fprintf(NORMALMSG, "=================================================\n");

	return RM_OK;
}

/**************************************************************************************************/

static RMstatus apply_scaler_window(struct rmfp_main_thread_context_type *pMainContext, RMuint32 scaler_ID, RMuint32 mixer, struct EMhwlibDisplayWindow *window)
{
	RMstatus status;
	RMuint32 src_index, mixer_src;

	if (scaler_ID == (RMuint32)-1) {
		RMDBGLOG((ENABLE, "No scaler, don't apply scaler window\n"));
		return RM_OK;
	}

	if (mixer) {
		status = RUAExchangeProperty(pMainContext->pRUA, mixer, RMGenericPropertyID_MixerSourceIndex, &(scaler_ID), sizeof(scaler_ID), &src_index, sizeof(src_index));
		if (status != RM_OK) {
			RMNOTIFY((NULL, status, "Cannot get scaler index\n"));
			return status;
		}
		mixer_src = EMHWLIB_TARGET_MODULE(EMHWLIB_MODULE_CATEGORY(mixer), 0 , src_index);
		DCCSP(pMainContext->pRUA, mixer_src, RMGenericPropertyID_MixerSourceWindow, window, sizeof(*window));
		/*
		{
			RMuint32 RetryCount = 0;
			struct RUAEvent event = { 0, };

			while (RM_PENDING == (status = RUASetProperty(pMainContext->pRUA, mixer_src, RMGenericPropertyID_MixerSourceWindow, window, sizeof(*window), 0))) {
				RUAWaitForMultipleEvents(pMainContext->pRUA, &event, 1, TIMEOUT_US, NULL);
				RMDBGPRINT((LOCALDBG, "."));

				if (RetryCount++ > RETRY_THRESHOLD) {
					RMNOTIFY((NULL, RM_TIMEOUT, "Cannot set deinterlacing mode\n"));
					break;
				}
			};

			if (RMFAILED(status)) {
				RMNOTIFY((NULL, status, "Cannot set mixer source window\n"));
				return status;
			}
		}
		*/

		status = RUASetProperty(pMainContext->pRUA, mixer_src, RMGenericPropertyID_Validate, NULL, 0, 0);
		if (status != RM_OK) {
			RMNOTIFY((NULL, status, "Cannot validate mixer\n"));
			return status;
		}

	}

	return RM_OK;
}

/**************************************************************************************************/

RMstatus open_osd(void *pContext, struct RMFPOSDProfile *pOSDProfile, struct RMFPOSDSource *pOSDSource)
{
	struct rmfp_main_thread_context_type *pHandle = NULL;
	enum EMhwlibMixerSourceState state;
	RMuint32 mixer, actual_mixer, scaler, src_index, mixer_src;
	RMstatus status;
	struct DisplayOptions * pDisplayOptions;

	RMDBGLOG((ENABLE, "Open Buffered OSD, size %lu x %lu\n", pOSDProfile->Profile.Width, pOSDProfile->Profile.Height));

	ASSERT_NULL_POINTER(pContext);
	ASSERT_NULL_POINTER(pOSDProfile);
	ASSERT_NULL_POINTER(pOSDSource);

	pHandle = (struct rmfp_main_thread_context_type *)pContext;
	pDisplayOptions = &(pHandle->AppOptions.Display);

	if (pOSDProfile->Version != RMFP_OSD_PROFILE_VERSION) {
		RMNOTIFY((NULL, RM_ERROR, "Got version 0x%lx, expected 0x%lx\n", pOSDProfile->Version, RMFP_OSD_PROFILE_VERSION));
		return RM_ERROR;
	}

	// TODO: if we get called several times, try to use a different scaler each time
	if (pHandle->osd_opened)
		return RM_ERROR;

	// Check if profile is ok
	status = RUASetProperty(pHandle->pRUA, pHandle->AppOptions.Display.osd_scaler_ID, RMGenericPropertyID_IsColorModeSupported,
							&(pOSDProfile->Profile.ColorMode), sizeof(pOSDProfile->Profile.ColorMode), 0);
	if (status != RM_OK) {
		RMNOTIFY((NULL, status, "Cannot open osd %d in color mode %d\n", pHandle->AppOptions.Display.osd_scaler_ID, pOSDProfile->Profile.ColorMode));
		return status;
	}

	// Store OSD profile in context
	pHandle->OSDAvailable = TRUE;
	pHandle->OSDProfile = *pOSDProfile;

	/* Get the right mixer respect to route */
	switch (pDisplayOptions->route) {
	case RMFPRoute_Main: mixer = DispMainMixer; actual_mixer = DispMainMixer; break;
	case RMFPRoute_Secondary: mixer = DispVCRMixer; actual_mixer = DispMainMixer; break;
	case RMFPRoute_ColorBars: mixer = DispColorBars; actual_mixer = DispColorBars; break;
	default:
		RMNOTIFY((NULL, RM_ERROR, "Invalid route %d\n", pDisplayOptions->route));
		return RM_ERROR;
	}

	scaler = pHandle->AppOptions.Display.osd_scaler_ID;
	RMDBGLOG((DISABLE, "%s on scaler %s (%d)\n", __FUNCTION__, (scaler == DispVCRMultiScaler)? "DispVCRMultiScaler": "OTHER!", scaler));

	while ((status = RUASetProperty(pHandle->pRUA,
					scaler,
					RMGenericPropertyID_Enable,
					&(pHandle->osd_opened),
					sizeof(pHandle->osd_opened),
					0)) == RM_PENDING);

	/* set a NULL surface, this will force a full register update when next surface is set */
	status = DCCSetSurfaceSource(pHandle->pDCC, scaler, NULL);
	if (status != RM_OK) {
		RMNOTIFY((NULL, status, "Cannot unset osd scaler's surface\n"));
		goto exit;
	}
	status = RUAExchangeProperty(pHandle->pRUA,
				     actual_mixer,
				     RMGenericPropertyID_MixerSourceIndex,
				     &scaler,
				     sizeof(scaler),
				     &src_index,
				     sizeof(src_index));
	if (status != RM_OK) {
		RMNOTIFY((NULL, status, "Cannot get scaler index\n"));
		goto exit;
	}

	mixer_src = EMHWLIB_TARGET_MODULE(actual_mixer, 0 , src_index);
	
	if (pDisplayOptions->route == RMFPRoute_Main ) {
		state = EMhwlibMixerSourceState_Master;
	} else if (pDisplayOptions->route == RMFPRoute_Secondary) {
		state = EMhwlibMixerSourceState_Slave;
	}

	RMDBGLOG((DISABLE, "%s: scaler %d route %d mixer %d actual_mixer %d state %d\n", __FUNCTION__, scaler, pDisplayOptions->route, mixer, actual_mixer, state));

	if (pDisplayOptions->route == RMFPRoute_Main) { // the following is only applicable to secondary route, since there is no mixer

		if (pOSDProfile->Profile.Width == 0 || pOSDProfile->Profile.Height == 0)  {
			RMNOTIFY((NULL, RM_ERROR, "Open OSD without size : Use default 1280x720\n"));
			pOSDProfile->Profile.Width = 1920;
			pOSDProfile->Profile.Height = 1080;
		}
		
		/* Adapt window size to outport aspect ratio */
		pHandle->applied_output_osd_window = pHandle->AppOptions.Display.output_osd_window;
		
		fill_output_osd_size(pContext, pOSDProfile, mixer);
		if (!pOSDProfile->ForcedOSDSize) {
			pOSDProfile->Profile.Width = (pHandle->applied_output_osd_window.Height * pHandle->AppOptions.Display.subtitles_osd_height / 4096) * pOSDProfile->Profile.Width / pOSDProfile->Profile.Height;
			pOSDProfile->Profile.Height = pHandle->applied_output_osd_window.Height * pHandle->AppOptions.Display.subtitles_osd_height / 4096;
			RMDBGLOG((ENABLE, "Buffered OSD real size is %lu x %lu\n", pOSDProfile->Profile.Width, pOSDProfile->Profile.Height));
		}
		
		while((status = RUASetProperty(pHandle->pRUA,
					       mixer_src,
					       RMGenericPropertyID_MixerSourceWindow,
					       &pHandle->applied_output_osd_window,
					       sizeof(pHandle->applied_output_osd_window),
					       0))
		      == RM_PENDING);
		if (status != RM_OK) {
			RMNOTIFY((NULL, status, "Cannot set output window\n"));
			goto exit;
		}

	}
	while((status = RUASetProperty(pHandle->pRUA,
				       scaler,
				       RMGenericPropertyID_ScalerInputWindow,
				       &pHandle->AppOptions.Display.source_window,
				       sizeof(pHandle->AppOptions.Display.source_window),
				       0)) == RM_PENDING);
	if (status != RM_OK) {
		RMNOTIFY((NULL, status, "Cannot set input window\n"));
		goto exit;
	}

	if (pHandle->AppOptions.Display.do_key_color == TRUE){
		while(( status =  RUASetProperty(pHandle->pRUA,
						  scaler,
						  RMGenericPropertyID_KeyColor,
						  &(pHandle->AppOptions.Display.key_color),
						  sizeof(pHandle->AppOptions.Display.key_color),
						  0)) == RM_PENDING);
		if (status != RM_OK) {
			RMNOTIFY((NULL, status, "Cannot enable color keying\n"));
			goto exit;
		}
	}

	apply_common_scaler_option(pHandle, &(pHandle->AppOptions.Display), scaler);

	while((status = RUASetProperty(pHandle->pRUA,
				       mixer_src,
				       RMGenericPropertyID_MixerSourceState,
				       &state,
				       sizeof(state),
				       0)) == RM_PENDING);
	if (status != RM_OK) {
		RMNOTIFY((NULL, status, "Cannot set scaler's state %d on mixer (mixer_src %p) \n", state, mixer_src));
		goto exit;
	}


	while ((status = RUASetProperty(pHandle->pRUA,
					mixer_src,
					RMGenericPropertyID_Validate,
					NULL, 0, 0)) == RM_PENDING);
	if (status != RM_OK) {
		RMNOTIFY((NULL, status, "Cannot validate mixer src\n"));
		goto exit;
	}

	while ((status = RUASetProperty(pHandle->pRUA,
					actual_mixer,
					RMGenericPropertyID_Validate,
					NULL, 0, 0)) == RM_PENDING);
	if (status != RM_OK) {
		RMNOTIFY((NULL, status, "Cannot validate mixer\n"));
		goto exit;
	}

	while ((status = RUASetProperty(pHandle->pRUA,
					scaler,
					RMGenericPropertyID_Validate, NULL, 0, 0)) == RM_PENDING);
	if (status != RM_OK) {
		RMNOTIFY((NULL, status, "Cannot validate scaler\n"));
		goto exit;
	}

	if (pDisplayOptions->do_key_color == TRUE) {
		/* it's ok to keep do_key_color bool:
		   when user doesn't want it, the colormode should remain truecolor
		   so even if keying registers have been previously programmed,
		   it won't interfere with subsequent, consecutive runs of rmfp
		*/

			if (pOSDProfile->Profile.ColorMode == EMhwlibColorMode_TrueColor) {
				/* change color format to enable color keying */
				pOSDProfile->Profile.ColorMode = EMhwlibColorMode_TrueColorWithKey;
			}
	}


	RMDBGPRINT((ENABLE, "Open osd with profile :\n"
			      "\tSamplingMode : %d\n"
			      "\tColorMode : %d\n"
			      "\tColorFormat : %d\n"
			      "\tWidth : %d\n"
			      "\tHeight : %d\n"
			      "\tColorSpace : %d\n",
			      pOSDProfile->Profile.SamplingMode,
			      pOSDProfile->Profile.ColorMode,
			      pOSDProfile->Profile.ColorFormat,
			      pOSDProfile->Profile.Width,
			      pOSDProfile->Profile.Height,
			      pOSDProfile->Profile.ColorSpace));

	if(pHandle->pOptions->playback_options.PTEnable && pHandle->pOptions->playback_options.PTInPlace)
	{
		struct DCCOSDResources osd_resources = {0,};
		RMuint32 width, height;

		/* Set square bufers */
		width = pOSDProfile->Profile.Width;
		height = pOSDProfile->Profile.Height;

		pOSDProfile->Profile.Width = MAX(pOSDProfile->Profile.Width, pOSDProfile->Profile.Height);
		pOSDProfile->Profile.Height = MAX(pOSDProfile->Profile.Width, pOSDProfile->Profile.Height);

		status = DCCGetOSDResourcesRequired(pHandle->pDCC, &pOSDProfile->Profile, &osd_resources, pOSDProfile->NumberOfPictures);
		if (status != RM_OK) {
			RMDBGLOG((ENABLE, "Cannot get resource requirements for osd (%s)\n", RMstatusToString(status)));
			goto exit;
		}

		if (osd_resources.SurfaceMemorySize) {
			osd_resources.SurfaceMemoryAddress = RUAMalloc(pHandle->pRUA, pHandle->pOptions->playback_options.DRAMIndex, RUA_DRAM_UNCACHED, osd_resources.SurfaceMemorySize);
			if (! osd_resources.SurfaceMemoryAddress) {
				RMDBGLOG((ENABLE, "ERROR: could not allocate 0x%08lX bytes in cached DRAM %lu!\n", osd_resources.SurfaceMemorySize, pHandle->pOptions->playback_options.DRAMIndex));
				goto exit;
			}
			RMDBGLOG((LOCALDBG, "Surface Memory: allocated %lu bytes at %p\n", osd_resources.SurfaceMemorySize, osd_resources.SurfaceMemoryAddress));
		}

		/* Restore the original dimensions */
		pOSDProfile->Profile.Width = width;
		pOSDProfile->Profile.Height = height;

		status = DCCOpenMultiplePictureOSDVideoSourceWithResources(pHandle->pDCC,  &pOSDProfile->Profile, &osd_resources, pOSDProfile->NumberOfPictures, &(pOSDSource->pSource), NULL);
		if (status != RM_OK){
			RMDBGLOG((ENABLE, "Cannot open osd video source with resources (%s)\n", RMstatusToString(status)));
			goto exit;
		}

	}
	else{
		status = DCCOpenMultiplePictureOSDVideoSource(pHandle->pDCC, &pOSDProfile->Profile, pOSDProfile->NumberOfPictures, &(pOSDSource->pSource), NULL);
		if (status != RM_OK) {
			RMNOTIFY((NULL, status, "Cannot open OSD decoder\n"));
			goto exit;
		}
	}

	/* Set color degradation boundary */

	if((pOSDProfile->Profile.ColorMode == EMhwlibColorMode_TrueColor) ||
	   (pOSDProfile->Profile.ColorMode ==  EMhwlibColorMode_TrueColorWithKey)){
		while ((status = RUASetProperty(pHandle->pRUA,
						scaler,
						RMGenericPropertyID_ColorDegradationBoundary,
						&(pHandle->AppOptions.Display.color_degradation_boundary),
						sizeof(pHandle->AppOptions.Display.color_degradation_boundary),
						0)) == RM_PENDING);

		if (RMFAILED(status) && status != RM_NOTIMPLEMENTED && status != RM_INVALIDMODE) {
			RMNOTIFY((NULL, status, "Cannot set color degradation boundary"));
			return status;
		}

	}


	// Set OSD Scaler Alpha

	{
		RMbool Fading = FALSE;
		RMbool SetAlpha1 = FALSE;

		RMuint32 Alpha0 = pHandle->AppOptions.Display.OSD_alpha;
		RMuint32 Alpha1 = Alpha0;

		switch (pOSDProfile->Profile.ColorMode) {
		case EMhwlibColorMode_LUT_1BPP:
		case EMhwlibColorMode_LUT_2BPP:
		case EMhwlibColorMode_LUT_4BPP:
		case EMhwlibColorMode_LUT_8BPP:
		case EMhwlibColorMode_TrueColor:
		case EMhwlibColorMode_TrueColorWithKey:
		case EMhwlibColorMode_16BPP_Alpha_LUT:

			switch (pOSDProfile->Profile.ColorFormat) {
			case EMhwlibColorFormat_32BPP_4444:
			case EMhwlibColorFormat_32BPP:
			case EMhwlibColorFormat_16BPP_4444:

				// Only the modes that support an alpha on DRAM support Fading.
				Fading = TRUE;
				SetAlpha1 = TRUE;
				break;

			case EMhwlibColorFormat_16BPP_1555:

				// No fading in this mode, though we have to set Alpha1
				SetAlpha1 = TRUE;
				break;

			case EMhwlibColorFormat_24BPP_565:
			case EMhwlibColorFormat_24BPP:
			case EMhwlibColorFormat_16BPP_565:

				break;
			};

			break;

		case EMhwlibColorMode_VideoInterleaved:
		case EMhwlibColorMode_VideoNonInterleaved:

			break;
		};

		if (Fading) {
			RMDBGLOG((ENABLE, "Enable Fading\n"));

			/*
			  With Fading alpha_out = alpha_in * alpha1 + (1 - alpha_in) * alpha0
			 */

			Alpha0 = 0;
		}
		else
			RMDBGLOG((ENABLE, "Disable Fading\n"));


		while ((status = RUASetProperty(pHandle->pRUA,
						scaler,
						RMGenericPropertyID_EnableFading,
						&(Fading),
						sizeof(Fading),
						0)) == RM_PENDING);
		if (status != RM_OK) {
			if ((status != RM_NOTIMPLEMENTED) && (status != RM_INVALIDMODE)) {
				RMNOTIFY((NULL, status, "Cannot validate scaler fading\n"));
				goto exit;
			}
			else
				RMDBGLOG((ENABLE, "WARNING (%s): fading not supported on scaler 0x%lx\n", RMstatusToString(status), scaler));
		}



		RMDBGLOG((ENABLE, "set alpha0 = 0x%lx\n", Alpha0));

		while ((status = RUASetProperty(pHandle->pRUA,
						scaler,
						RMGenericPropertyID_Alpha0,
						&(Alpha0),
						sizeof(Alpha0),
						0)) == RM_PENDING);
		if (status != RM_OK) {
			if ((status != RM_NOTIMPLEMENTED) && (status != RM_INVALIDMODE)) {
				RMNOTIFY((NULL, status, "Cannot validate scaler fading\n"));
				goto exit;
			}
			else
				RMDBGLOG((ENABLE, "WARNING (%s): alpha0 not supported on scaler 0x%lx\n", RMstatusToString(status), scaler));
		}


		/* some 16bpp .bmp files may set the alpha bit to 1.
		   Note however that Alpha1 is always equal to TargetAlpha */
		if (SetAlpha1) {

			RMDBGLOG((ENABLE, "set alpha1 = 0x%lx\n", Alpha1));

			while ((status = RUASetProperty(pHandle->pRUA,
							scaler,
							RMGenericPropertyID_Alpha1,
							&(Alpha1),
							sizeof(Alpha1),
							0)) == RM_PENDING);
			if (status != RM_OK) {
				if ((status != RM_NOTIMPLEMENTED) && (status != RM_INVALIDMODE)) {
					RMNOTIFY((NULL, status, "Cannot validate scaler fading\n"));
					goto exit;
				}
				else
					RMDBGLOG((ENABLE, "WARNING (%s): alpha1 not supported on scaler 0x%lx\n", RMstatusToString(status), scaler));
			}
		}
	}


	/*possibly clean it before this with a fill */

	RMDBGLOG((DISABLE, "about to SetSurfaceSourceWithRoute %d to scaler %d\n", pDisplayOptions->route, scaler ));
	{
		enum DCCRoute dcc_route;
		switch (pDisplayOptions->route) {
		case  RMFPRoute_Main:
			dcc_route = DCCRoute_Main;
			break;
		case  RMFPRoute_Secondary:
			dcc_route = DCCRoute_Secondary;
			break;
		case  RMFPRoute_ColorBars:
			dcc_route = DCCRoute_ColorBars;
			break;
		default: 
			status = RM_ERROR;
			RMNOTIFY((NULL, status, "invalid RMFP route!\n"));
			goto exit;
		}
		
		status = DCCSetSurfaceSourceWithRoute(pHandle->pDCC, scaler, pOSDSource->pSource, dcc_route);
	}
	if (status != RM_OK) {
		RMNOTIFY((NULL, status, "Cannot set the surface source\n"));
		goto exit;
	}




//	if (pOSDProfile->NumberOfPictures > 1) {
//		status = DCCEnableVideoSource(pOSDSource->pSource, TRUE);
//		if (status != RM_OK){
//			RMNOTIFY((NULL, status, "Error enabling OSD buffer\n"));
//			goto exit;
//		}
//	}

	while ((status = RUASetProperty(pHandle->pRUA,
					scaler,
					RMGenericPropertyID_Validate,
					NULL, 0, 0)) == RM_PENDING);
	if (status != RM_OK) {
		RMNOTIFY((NULL, status, "Cannot validate scaler input window\n"));
		goto exit;
	}

	pHandle->osd_opened = TRUE;

	while ((status = RUASetProperty(pHandle->pRUA,
					scaler,
					RMGenericPropertyID_Enable,
					&(pHandle->osd_opened),
						sizeof(pHandle->osd_opened),
						0)) == RM_PENDING);
	
	if (pHandle->pOptions->video_options.ForceAFD || pHandle->pOptions->video_options.ForceAsp || pHandle->pOptions->video_options.ForceBarInfo || pHandle->pOptions->video_options.ForceScanInfo || pHandle->pOptions->video_options.Force3D) {
		RMuint32 ModuleID, PropertyID;
#ifdef RMBUILD_USE_HWLIB_V2
		struct EMhwlibDispSurface_SurfaceFrameInfoForce_type SurfaceFrameInfoForce;
		ModuleID = EMHWLIB_MODULE(EMhwlibDispSurface, 0);
		PropertyID = RMPropertyID_SurfaceFrameInfoForce;
#else // RMBUILD_USE_HWLIB_V2
		struct DisplayBlock_SurfaceFrameInfoForce_type SurfaceFrameInfoForce;
		ModuleID = EMHWLIB_MODULE(DisplayBlock, 0);
		PropertyID = RMDisplayBlockPropertyID_SurfaceFrameInfoForce;
#endif // RMBUILD_USE_HWLIB_V2
		
		RMMemset(&SurfaceFrameInfoForce, 0, sizeof(SurfaceFrameInfoForce));
		DCCGetSurfaceSource(pHandle->pDCC, pOSDSource->pSource, &(SurfaceFrameInfoForce.surface));
		
		if (pHandle->pOptions->video_options.ForceAFD) {
			RMDBGLOG((ENABLE, "Forcing AFD on surface\n"));
			SurfaceFrameInfoForce.FrameInfoForce.ForceMask |= EMHWLIB_FRAMEINFO_MASK_ActiveFormat;
		}
		if (pHandle->pOptions->video_options.ForceAsp) {
			RMDBGLOG((ENABLE, "Forcing aspect ratio on surface\n"));
			SurfaceFrameInfoForce.FrameInfoForce.ForceMask |= EMHWLIB_FRAMEINFO_MASK_AspectRatio;
		}
		if (pHandle->pOptions->video_options.ForceBarInfo) {
			RMDBGLOG((ENABLE, "Forcing bar info on surface\n"));
			SurfaceFrameInfoForce.FrameInfoForce.ForceMask |= EMHWLIB_FRAMEINFO_MASK_BarData;
		}
		if (pHandle->pOptions->video_options.ForceScanInfo) {
			RMDBGLOG((ENABLE, "Forcing scan info on surface\n"));
			SurfaceFrameInfoForce.FrameInfoForce.ForceMask |= EMHWLIB_FRAMEINFO_MASK_ScanInfo;
		}
		if (pHandle->pOptions->video_options.Force3D) {
			RMDBGLOG((ENABLE, "Forcing 3D format on surface\n"));
			SurfaceFrameInfoForce.FrameInfoForce.ForceMask |= EMHWLIB_FRAMEINFO_MASK_Stereoscopic3D;
		}
		SurfaceFrameInfoForce.FrameInfoForce.FrameInfo.AFD = pHandle->pOptions->video_options.afd;
		SurfaceFrameInfoForce.FrameInfoForce.FrameInfo.BarInfo = pHandle->pOptions->video_options.BarInfo;
		SurfaceFrameInfoForce.FrameInfoForce.FrameInfo.ScanInfo = pHandle->pOptions->video_options.ScanInfo;
		SurfaceFrameInfoForce.FrameInfoForce.FrameInfo.Stereoscopic3D = pHandle->pOptions->video_options.Stereoscopic3D;
		
		status = RUASetProperty(pHandle->pRUA, ModuleID, PropertyID, &(SurfaceFrameInfoForce), sizeof(SurfaceFrameInfoForce), 0);
		if (RMFAILED(status)) {
			RMNOTIFY((NULL, status, "Can not set SurfaceFrameInfoForce\n"));
		}
	} else {
		RMDBGLOG((ENABLE, "Not forcing anything on surface\n"));
	}

 exit:
	if (status != RM_OK) {
		if (pOSDSource->pSource)
			DCCCloseVideoSource(pOSDSource->pSource);
			pOSDSource->pSource = NULL;
		return status;
	}
	pHandle->ActiveScalers |= OSD_SCALER_ACTIVE;
	pHandle->ScalersOperationsMask |= OSD_SCALER_ACTIVE;
	return RM_OK;
}

/**************************************************************************************************/

RMstatus close_osd(void *pContext, struct RMFPOSDSource *pOSDSource)
{
	RMstatus status;
	struct rmfp_main_thread_context_type *pHandle = NULL;

	ASSERT_NULL_POINTER(pContext);
	ASSERT_NULL_POINTER(pOSDSource);

	pHandle = (struct rmfp_main_thread_context_type *)pContext;

	pHandle->osd_opened = FALSE;

	if (pOSDSource->pSource) {
		RMDBGLOG((LOCALDBG, "close BufferOSD\n"));

		status = DCCCloseVideoSource(pOSDSource->pSource);
		pOSDSource->pSource = NULL;
	}

	return RM_OK;
}

/**************************************************************************************************/

RMstatus open_bdspu_decoder(void *pContext)
{
	struct rmfp_main_thread_context_type *pHandle = NULL;

	ASSERT_NULL_POINTER(pContext);

	pHandle = (struct rmfp_main_thread_context_type *)pContext;

	RMDBGLOG((ENABLE, "Fake opening of Bluray subtitles decoder\n"));

	return RM_OK;
}

/**************************************************************************************************/

RMstatus close_bdspu_decoder(void *pContext)
{
	struct rmfp_main_thread_context_type *pHandle = NULL;

	ASSERT_NULL_POINTER(pContext);

	pHandle = (struct rmfp_main_thread_context_type *)pContext;

	RMDBGLOG((ENABLE, "Fake closing of Bluray subtitles decoder\n"));

	return RM_OK;
}

/**************************************************************************************************/

RMstatus send_bdspu_decoder(void *pContext, RMuint8* pBuffer, RMuint32 Size)
{
	struct rmfp_main_thread_context_type *pHandle = NULL;

	ASSERT_NULL_POINTER(pContext);

	pHandle = (struct rmfp_main_thread_context_type *)pContext;

	RMDBGLOG((ENABLE, "Fake decoding %d bytes of Bluray subtitles decoder\n", Size));

	return RM_OK;
}

/**************************************************************************************************/

RMstatus flush_bdspu_decoder(void *pContext)
{
	struct rmfp_main_thread_context_type *pHandle = NULL;

	ASSERT_NULL_POINTER(pContext);

	pHandle = (struct rmfp_main_thread_context_type *)pContext;

	RMDBGLOG((ENABLE, "Fake flushing Bluray subtitles decoder\n"));

	return RM_OK;
}
/**************************************************************************************************/

RMstatus get_route_handler(void *pContext, struct RMFPRoute *pRoute)
{
	struct rmfp_main_thread_context_type *pHandle = NULL;

	ASSERT_NULL_POINTER(pContext);

	pHandle = (struct rmfp_main_thread_context_type *)pContext;

	/* Return the route from the parameters */
	pRoute->route = pHandle->AppOptions.Display.route;

	return RM_OK;

}

/**************************************************************************************************/

RMstatus hls_get_key( void* pContext, RMascii *url, RMuint8 *key, RMuint32 keylength)
{
	struct rmfp_main_thread_context_type *pHandle = NULL;
	RMuint8 test_key[] = {0xec, 0x74, 0xc7, 0xf2, 0xc6, 0x9e, 0xaa, 0x83, 0xd8, 0x21, 0x24, 0x07, 0x09, 0xa1, 0x73, 0x40};

	ASSERT_NULL_POINTER(pContext);

	pHandle = (struct rmfp_main_thread_context_type *)pContext;

	RMDBGLOG((ENABLE, "Fake opening key callback\n"));
	RMMemcpy(key, test_key, keylength);

	return RM_OK;
}

/**************************************************************************************************/

RMstatus notify_stream_metadata(void *pContext, struct RMFPStreamMetadata *pStreamMetadata)
{
	RMstatus eOutRMstatus = RM_OK;
	struct rmfp_main_thread_context_type *pHandle = NULL;

	ASSERT_NULL_POINTER(pContext);
	ASSERT_NULL_POINTER(pStreamMetadata);

	pHandle = (struct rmfp_main_thread_context_type *)pContext;

	pHandle->metadata = *pStreamMetadata;
	pHandle->defaults_metadata = *pStreamMetadata;

	if(Sw_LogMediaFileInfo)
	{
		eOutRMstatus = print_stream_metadata(pHandle);
	}

	return eOutRMstatus;
}

/**************************************************************************************************/

RMstatus open_dmapool_handler(void *pContext, struct RMFPDMAPoolProfile *pProfile, struct RUABufferPool **ppDMAPool)
{
	struct rmfp_main_thread_context_type *pHandle = NULL;
	RMstatus status;

	RMDBGLOG((LOCALDBG, "open_dmapool_handler()\n"));

	ASSERT_NULL_POINTER(pContext);
	ASSERT_NULL_POINTER(pProfile);
	ASSERT_NULL_POINTER(ppDMAPool);

	pHandle = (struct rmfp_main_thread_context_type *)pContext;

	RMDBGLOG((LOCALDBG, "input profile\n"));

	if (pHandle->AppOptions.Playback.dmapool_in_rua_mem) {
		// use externally allocated RUA Memory for DMAPool creation

		RMuint32 DMAPoolSize = pProfile->BufferCount << pProfile->BufferSize_log2;
		RMuint32 DRAMIndex = pHandle->pOptions->playback_options.DRAMIndex;
		RMuint32 RUAArea;

		RUAArea = RUAMalloc(pHandle->pRUA, DRAMIndex, RUA_DRAM_UNCACHED, DMAPoolSize);
		if (!RUAArea) {
			fprintf(ERRORMSG, "Cannot allocate %lu of RUA memory in DRAM %lu\n", DMAPoolSize, DRAMIndex);
			return RM_FATALOUTOFMEMORY;
		}

		RMDBGLOG((ENABLE, "RUAArea 0x%08lx, Size %lu\n", RUAArea, DMAPoolSize));

		status = RUAOpenPoolWithRUAArea(pHandle->pRUA,
						RUAArea,
						DMAPoolSize,
						pProfile->ModuleID,
						pProfile->BufferSize_log2,
						pProfile->Direction,
						ppDMAPool);
		if (status != RM_OK) {
			fprintf(ERRORMSG, "Cannot open DMA pool in RUAArea 0x%08lx\n", RUAArea);
			RUAFree(pHandle->pRUA, RUAArea);
			return status;
		}

	}
	else {
		status = RUAOpenPool(pHandle->pRUA,
				     pProfile->ModuleID,
				     pProfile->BufferCount,
				     pProfile->BufferSize_log2,
				     pProfile->Direction,
				     ppDMAPool);

		if (status != RM_OK) {
			fprintf(ERRORMSG, "Cannot open DMA pool\n");
			return status;
		}
	}

	return RM_OK;
}

/**************************************************************************************************/

RMstatus close_dmapool_handler(void *pContext, struct RUABufferPool *pDMAPool)
{
	struct rmfp_main_thread_context_type *pHandle = NULL;
	RMstatus status;

	RMDBGLOG((LOCALDBG, "close_dmapool_handler()\n"));

	ASSERT_NULL_POINTER(pContext);
	ASSERT_NULL_POINTER(pDMAPool);

	pHandle = (struct rmfp_main_thread_context_type *)pContext;

	if (pHandle->AppOptions.Playback.dmapool_in_rua_mem) {
		RMuint32 RUAArea;
		RMuint32 RUAAreaSize;

		RUAPoolGetRUAArea(pDMAPool, &RUAArea, &RUAAreaSize);

		RMDBGLOG((ENABLE, "DMAPoolRUAArea 0x%08lx size %lu\n", RUAArea, RUAAreaSize));

		if (RUAArea)
			RUAFree(pHandle->pRUA, RUAArea);

	}

	status = RUAClosePool(pDMAPool);

	return status;
}

/**************************************************************************************************/

RMstatus rmwmdrm_url_acquire_license(void *pContext, struct RMFPRMWMDRMURLHandle *pRMWMDRMURLHandle)
{
	struct rmfp_main_thread_context_type *pHandle = NULL;
	RMstatus status = RM_OK;


	RMDBGLOG((LOCALDBG, "%s()\n", __FUNCTION__));

	ASSERT_NULL_POINTER(pContext);
	ASSERT_NULL_POINTER(pRMWMDRMURLHandle);

	pHandle = (struct rmfp_main_thread_context_type *)pContext;

	// start of custom license acquisition code

	/*
	  the following functions would need to be called.
	  this callback allows easy customisation of the license acquisition process for custom servers implementation

	  RMWMDRM_url_bind_license
	  RMWMDRM_url_get_challenge_and_url_size
	  RMWMDRM_url_get_challenge_and_url
	  RMWMDRM_url_process_license
	  RMWMDRM_url_get_acknowledge_size
	  RMWMDRM_url_get_acknowledge
	  RMWMDRM_url_process_ack_and_bind_license


	 */


	return status;

}


/**************************************************************************************************/

static struct RMFPStreamMetadataSPUStreamEntry* get_current_subs_metadata(struct rmfp_main_thread_context_type *pMainContext, RMbool defaults)
{
	struct RMFPStreamProperties *pStreamProperties = &pMainContext->stream_properties;
	struct RMFPStreamMetadata *pStreamMetadata;
	RMuint32 cnt;


	if (defaults)
		pStreamMetadata = &pMainContext->defaults_metadata;
	else
		pStreamMetadata = &pMainContext->metadata;

	/* Check if a subtitle is on screen */
	if (pStreamProperties->subtitles.id == -1)
		return NULL;

	/* Find id in list */
	if (pStreamMetadata->SPUStreams)
	{
		for ( cnt = 0; cnt < pStreamMetadata->SPUStreams; cnt++)
		{
			if ((RMint32)pStreamMetadata->SPUStreamList[cnt].StreamID == pStreamProperties->subtitles.id)
				return &pStreamMetadata->SPUStreamList[cnt];
		}
	}

	/* Not found */
	return NULL;
}

/**************************************************************************************************/

static RMstatus print_stream_metadata(struct rmfp_main_thread_context_type *pMainContext)
{
	struct RMFPStreamMetadata *pStreamMetadata = NULL;
	RMuint32 i;

	ASSERT_NULL_POINTER(pMainContext);

	pStreamMetadata = &(pMainContext->metadata);

	//fprintf(NORMALMSG, "\n============== Stream Information ===============\n");

	if (pStreamMetadata->Duration)
		fprintf(NORMALMSG, "Duration: %lu ms\n", pStreamMetadata->Duration);


	if (pStreamMetadata->VideoStreams) {
		fprintf(NORMALMSG, "\nVideo Streams count: %lu\n", pStreamMetadata->VideoStreams);
		for (i = 0; i < pStreamMetadata->VideoStreams; i++) {
			fprintf(NORMALMSG, "\tID %lu (0x%lx): ", pStreamMetadata->VideoStreamList[i].StreamID, pStreamMetadata->VideoStreamList[i].StreamID);
			if (pStreamMetadata->VideoStreamList[i].pDescription)
			{
				fprintf(NORMALMSG, "'%s'", pStreamMetadata->VideoStreamList[i].pDescription);
			}
			else
			{
				fprintf(NORMALMSG, "No description available");
			}
			if (pStreamMetadata->VideoStreamList[i].Supported)
			{
				fprintf(NORMALMSG, "\n");
			}
			else
			{
				fprintf(NORMALMSG, " (codec not supported)\n");
			}
		}
	}

	if (pStreamMetadata->AudioStreams) {
		fprintf(NORMALMSG, "\nAudio Streams count: %lu\n", pStreamMetadata->AudioStreams);
		for (i = 0; i < pStreamMetadata->AudioStreams; i++) {
			fprintf(NORMALMSG, "\tID %lu (0x%lx): ", pStreamMetadata->AudioStreamList[i].StreamID, pStreamMetadata->AudioStreamList[i].StreamID);
			if (pStreamMetadata->AudioStreamList[i].pDescription)
				fprintf(NORMALMSG, "'%s'", pStreamMetadata->AudioStreamList[i].pDescription);
			else
				fprintf(NORMALMSG, "No description available");
			if (pStreamMetadata->AudioStreamList[i].Supported)
				fprintf(NORMALMSG, "\n");
			else
				fprintf(NORMALMSG, " (codec not supported)\n");
		}
	}

	if (pStreamMetadata->SPUStreams) {
		fprintf(NORMALMSG, "\nSubtitles Streams count: %lu\n", pStreamMetadata->SPUStreams);
		for ( i = 0; i < pStreamMetadata->SPUStreams; i++) {
			fprintf(NORMALMSG, "\tID %lu (0x%lx): ", pStreamMetadata->SPUStreamList[i].StreamID, pStreamMetadata->SPUStreamList[i].StreamID);
			if (pStreamMetadata->SPUStreamList[i].pDescription)
				fprintf(NORMALMSG, "'%s'", pStreamMetadata->SPUStreamList[i].pDescription);
			else
				fprintf(NORMALMSG, "No description available");

			fprintf(NORMALMSG, " [%s]", (pStreamMetadata->SPUStreamList[i].Encoding == RMFPSubsEncoding_UTF8)?"UTF8":"latin1");
			if (pStreamMetadata->SPUStreamList[i].Supported)
				fprintf(NORMALMSG, "\n");
			else
				fprintf(NORMALMSG, " (codec not supported)\n");
		}
	}

	//fprintf(NORMALMSG, "=================================================\n");

	switch (pStreamMetadata->MetadataType) {
	case RMFPStreamMetadataType_MP4:

		if (pStreamMetadata->data.mp4.isNero)
			fprintf(NORMALMSG, ">> isNero\n");

		if (pStreamMetadata->data.mp4.isPlayable) {
			if (pStreamMetadata->data.mp4.isNero)
				fprintf(NORMALMSG, ">> isPlayable\n");
		}
		else
			fprintf(NORMALMSG, ">> Nero DRM prevents playback\n");

		if (pStreamMetadata->data.mp4.Chapters) {
			fprintf(NORMALMSG, "\n=============== Available chapters ==============\n");

			for (i = 0; i < pStreamMetadata->data.mp4.Chapters; i++) {
				fprintf(NORMALMSG, "\tChapter %3lu @ %8lld ms: '%s'\n",
					i,
					pStreamMetadata->data.mp4.ChapterList[i].Time_ms,
					pStreamMetadata->data.mp4.ChapterList[i].pName
					);
			}
			fprintf(NORMALMSG, "=================================================\n\n");
		}


		break;
	case RMFPStreamMetadataType_MKV:

		if (pStreamMetadata->data.mkv.Chapters) {
			fprintf(NORMALMSG, "\n================ Available chapters ===============\n");

			for (i = 0; i < pStreamMetadata->data.mkv.Chapters; i++) {
				fprintf(NORMALMSG, "\tChapter %3lu @ %8lld ms: '%s'\n",
					i,
					pStreamMetadata->data.mkv.ChapterList[i].Time_ms,
					pStreamMetadata->data.mkv.ChapterList[i].pName);
			}
			fprintf(NORMALMSG, "=================================================\n\n");
		}

		if (pStreamMetadata->data.mkv.Attachments) {
			fprintf(NORMALMSG, "\n============= Available Attachments =============\n");

			for (i = 0; i < pStreamMetadata->data.mkv.Attachments; i++) {
				fprintf(NORMALMSG, "\tAttachment %3lu: '%s' [%s] - %llu bytes - %s\n",
					i,
					pStreamMetadata->data.mkv.AttachmentList[i].pName,
					pStreamMetadata->data.mkv.AttachmentList[i].pMimeType,
					pStreamMetadata->data.mkv.AttachmentList[i].Length,
					pStreamMetadata->data.mkv.AttachmentList[i].pDescription);
			}
			fprintf(NORMALMSG, "=================================================\n\n");
		}
		break;

	case RMFPStreamMetadataType_HLS:
		fprintf(NORMALMSG, ">> HLS playlist\n");
		fprintf(NORMALMSG, ">> Start date time %lu\n", pStreamMetadata->data.hls.startTimeDate);
		fprintf(NORMALMSG, "\n=============== Available Variants ===============\n");
		for (i = 0; i < pStreamMetadata->data.hls.variants; i++) {
			fprintf(NORMALMSG, "\tVariant %3lu: bandwidth %8lu bits/sec\n",
					i, pStreamMetadata->data.hls.variantBandwidth[i]);
		}
		fprintf(NORMALMSG, "=================================================\n\n");
		break;

	case RMFPStreamMetadataType_None:
		break;
	};

	return RM_OK;
}

RMstatus rmfp_getVideoScalerModuleId(void *pContext, RMuint32 * pVidScalerModuleId, enum DCCRoute * pDccRoute)
{
	RMstatus eOutRMstatus = RM_OK;
	struct rmfp_main_thread_context_type *pHandle = NULL;

	ASSERT_NULL_POINTER(pContext);

	pHandle = (struct rmfp_main_thread_context_type *)pContext;

	do
	{
		if(pVidScalerModuleId)
		{
			*pVidScalerModuleId = EMHWLIB_MODULE(pHandle->AppOptions.Display.scaler_ID, 0);
		}
		if(pDccRoute)
		{
			*pDccRoute = pHandle->AppOptions.Display.route;
		}
	}while(FALSE);

	return eOutRMstatus;
}

RMstatus Rmfp_AudioEngine_setSampleFreq(void *pContext, RMbool bUseCurCfg, 
	RMbool bAutoSetFromStream, RMuint32 audioSampleFreq)
{
	RMstatus eOutRMstatus = RM_OK, eRMstatus;
	struct rmfp_main_thread_context_type *pHandle = NULL;

	pHandle = (struct rmfp_main_thread_context_type *)pContext;
	if(NULL == pHandle)
	{
		eOutRMstatus = RM_INVALID_PARAMETER;
		goto EXIT_PROC;
	}

	if(bUseCurCfg)
	{
		bAutoSetFromStream = pHandle->pOptions->audio_options.afs;
		audioSampleFreq = pHandle->display_opt->audio_options.SampleRate;
	}

	eRMstatus = Rmoutput_AudioEngine_setSampleFreq(pHandle->pHWLib, &pHandle->display_opt->audio_options,
		bAutoSetFromStream, audioSampleFreq);
	if(RMFAILED(eRMstatus))
	{
		eOutRMstatus = eRMstatus;
		goto EXIT_PROC;
	}

EXIT_PROC:
	return eOutRMstatus;
}

/**************************************************************************************************/

static RMstatus print_track_bounds(struct rmfp_main_thread_context_type *pMainContext, RMuint32 mask)
{
	struct RMFPStreamProperties *pStreamProperties = NULL;
	struct RMFPStreamMetadata *pStreamMetadata = NULL;
	struct DCCPMTInfoType *pPMT = NULL;


	RMuint32 i;


	ASSERT_NULL_POINTER(pMainContext);

#if !USE_BOUNDS_CHECKING
	return RM_OK;
#endif

	pStreamMetadata   = &(pMainContext->metadata);
	pStreamProperties = &(pMainContext->stream_properties);
	pPMT              = &(pMainContext->current_pmt);


	if ((mask & PRINT_MASK_VIDEO) && pStreamMetadata->VideoStreams)
	{
		fprintf(NORMALMSG, "Choose from:\n");
		fprintf(NORMALMSG, "\tCurrent marked with *\n");
		/* Not possible yet: fprintf(NORMALMSG, "\t-1 to disable the Video\n");*/

		for ( i = 0; i < pStreamMetadata->VideoStreams; i++) {
			if (!pStreamMetadata->VideoStreamList[i].Supported)
				continue;

			if (pStreamMetadata->VideoStreamList[i].StreamID == (RMuint32)pStreamProperties->video.id)
				fprintf(NORMALMSG, "\t* ");
			else
				fprintf(NORMALMSG, "\t  ");

			fprintf(NORMALMSG, "%lu", pStreamMetadata->VideoStreamList[i].StreamID);

			if (pStreamMetadata->VideoStreamList[i].pDescription)
				fprintf(NORMALMSG, ": '%s'\n", pStreamMetadata->VideoStreamList[i].pDescription);
			else
				fprintf(NORMALMSG, "\n");
		}
	}

	else if ((mask & PRINT_MASK_AUDIO) && pStreamMetadata->AudioStreams)
	{
		fprintf(NORMALMSG, "Choose from:\n");
		fprintf(NORMALMSG, "\tCurrent marked with *\n");
		/* Not possible yet: fprintf(NORMALMSG, "\t-1 to disable the Audio\n");*/

		for ( i = 0; i < pStreamMetadata->AudioStreams; i++) {
			if (!pStreamMetadata->AudioStreamList[i].Supported)
				continue;

			if (pStreamMetadata->AudioStreamList[i].StreamID == (RMuint32)pStreamProperties->audio.id)
				fprintf(NORMALMSG, "\t* ");
			else
				fprintf(NORMALMSG, "\t  ");

			fprintf(NORMALMSG, "%lu", pStreamMetadata->AudioStreamList[i].StreamID);
			if (pStreamMetadata->AudioStreamList[i].pDescription)
				fprintf(NORMALMSG, ": '%s'\n", pStreamMetadata->AudioStreamList[i].pDescription);
			else
				fprintf(NORMALMSG, "\n");
		}
	}

	else if ((mask & PRINT_MASK_SUBS) && pStreamMetadata->SPUStreams)
	{
		fprintf(NORMALMSG, "Choose from:\n");
		fprintf(NORMALMSG, "\tCurrent marked with *\n");
		fprintf(NORMALMSG, "\t-1 to disable the SPU/Subtitles\n");

		for ( i = 0; i < pStreamMetadata->SPUStreams; i++) {
			if (!pStreamMetadata->SPUStreamList[i].Supported)
				continue;

			if (pStreamMetadata->SPUStreamList[i].StreamID == (RMuint32)pStreamProperties->subtitles.id)
				fprintf(NORMALMSG, "\t* ");
			else
				fprintf(NORMALMSG, "\t  ");

			fprintf(NORMALMSG, "%lu", pStreamMetadata->SPUStreamList[i].StreamID);
			if (pStreamMetadata->SPUStreamList[i].pDescription)
				fprintf(NORMALMSG, ": '%s'\n", pStreamMetadata->SPUStreamList[i].pDescription);
			else
				fprintf(NORMALMSG, "\n");
		}
	}

	else if (mask & PRINT_MASK_PMT)
	{
		fprintf(NORMALMSG, "Choose from:\n");
		fprintf(NORMALMSG, "\tCurrent marked with *\n");
		fprintf(NORMALMSG, "\t0 for next PMT in list\n");

		for ( i = 0; i < pMainContext->current_pat.count; i++) {

			if (pMainContext->current_pat.program_number[i] == pPMT->program_number)
				fprintf(NORMALMSG, "\t* ");
			else
				fprintf(NORMALMSG, "\t  ");

			fprintf(NORMALMSG, "%u (0x%x) [PMT #%d]\n",
				pMainContext->current_pat.program_map_pid[i],
				pMainContext->current_pat.program_map_pid[i],
				pMainContext->current_pat.program_number[i]);
		}

		fprintf(NORMALMSG, "\n");
	}

	else if (mask & PRINT_MASK_VARIANT)
	{
		fprintf(NORMALMSG, "Choose from:\n");
		fprintf(NORMALMSG, "\tCurrent marked with *\n");
		fprintf(NORMALMSG, "\t -1 to let the lib automatically choose the variant.\n");
		fprintf(NORMALMSG, "\t  0 for next variant in list\n");

		for (i=0; i < pStreamMetadata->data.hls.variants; i++) {
			if (pStreamMetadata->data.hls.currentVariant == i)
				fprintf(NORMALMSG, "\t* ");
			else
				fprintf(NORMALMSG, "\t  ");

			fprintf(NORMALMSG, "%lu (bandwidth %lu)\n",
					i+1, pStreamMetadata->data.hls.variantBandwidth[i]);
		}

		fprintf(NORMALMSG, "\n");
	}

	return RM_OK;

}

/**************************************************************************************************/

static RMstatus check_track_bounds(struct rmfp_main_thread_context_type *pMainContext, RMint32 TrackID, RMuint32 mask)
{

	struct RMFPStreamMetadata *pStreamMetadata = NULL;
	RMuint32 i;


	ASSERT_NULL_POINTER(pMainContext);

#if !USE_BOUNDS_CHECKING
	return RM_OK;
#endif

	pStreamMetadata = &(pMainContext->metadata);

	if ((mask & PRINT_MASK_VIDEO) && pStreamMetadata->VideoStreams)
	{
		for ( i = 0; i < pStreamMetadata->VideoStreams; i++) {
			if ((TrackID == (RMint32)pStreamMetadata->VideoStreamList[i].StreamID)
				&& pStreamMetadata->VideoStreamList[i].Supported)
				break;
		}
		if (i == pStreamMetadata->VideoStreams) {
			fprintf(NORMALMSG, "Invalid value %ld\n", TrackID);
			return RM_INVALID_PARAMETER;
		}
	}

	else if ((mask & PRINT_MASK_AUDIO) && pStreamMetadata->AudioStreams)
	{
		for ( i = 0; i < pStreamMetadata->AudioStreams; i++) {
			if ((TrackID == (RMint32)pStreamMetadata->AudioStreamList[i].StreamID)
				&& pStreamMetadata->AudioStreamList[i].Supported)
				break;
		}
		if (i == pStreamMetadata->AudioStreams) {
			fprintf(NORMALMSG, "Invalid value %ld\n", TrackID);
			return RM_INVALID_PARAMETER;
		}
	}

	else if ((mask & PRINT_MASK_SUBS) && pStreamMetadata->SPUStreams)
	{
		for ( i = 0; i < pStreamMetadata->SPUStreams; i++) {
			if ((TrackID == (RMint32)pStreamMetadata->SPUStreamList[i].StreamID)
				&& pStreamMetadata->SPUStreamList[i].Supported)
				break;
		}
		if ((i == pStreamMetadata->SPUStreams) && (TrackID != -1)) {
			fprintf(NORMALMSG, "Invalid value %ld\n", TrackID);
			return RM_INVALID_PARAMETER;
		}
	}

	else if (mask & PRINT_MASK_PMT)
	{
		for ( i = 0; i < pMainContext->current_pat.count; i++) {
			if (TrackID == (RMint32) pMainContext->current_pat.program_map_pid[i])
				break;
		}
		if ((i == pMainContext->current_pat.count) && (TrackID != 0)) {
			fprintf(NORMALMSG, "Invalid value %ld\n", TrackID);
			return RM_INVALID_PARAMETER;
		}
	}

	else if (mask & PRINT_MASK_VARIANT)
	{
		if (TrackID < -1 || TrackID > (RMint32)pStreamMetadata->data.hls.variants) {
			fprintf(NORMALMSG, "Invalid value %ld\n", TrackID);
			return RM_INVALID_PARAMETER;
		}
	}

	return RM_OK;
}

/**************************************************************************************************/

static RMstatus print_seek_bounds(struct rmfp_main_thread_context_type *pMainContext)
{
	struct RMFPStreamMetadata *pStreamMetadata = NULL;

	ASSERT_NULL_POINTER(pMainContext);

	pStreamMetadata = &(pMainContext->metadata);

#if !USE_BOUNDS_CHECKING
	return RM_OK;
#endif


	if (pStreamMetadata->Duration) {
		fprintf(NORMALMSG, "Valid range [0, %ld]; Enter any invalid value to ignore the command\n", pStreamMetadata->Duration / 1000);
	}
	else
		fprintf(NORMALMSG, "Valid range [0, unknown]\n");

	return RM_OK;

}

/**************************************************************************************************/

static RMstatus check_seek_bounds(struct rmfp_main_thread_context_type *pMainContext, RMint32 input)
{

	struct RMFPStreamMetadata *pStreamMetadata = NULL;

	ASSERT_NULL_POINTER(pMainContext);

#if !USE_BOUNDS_CHECKING
	return RM_OK;
#endif

	pStreamMetadata = &(pMainContext->metadata);

	if (pStreamMetadata->Duration) {

		if (((1000*input) > (RMint32)pStreamMetadata->Duration) || (input < 0)) {
			fprintf(NORMALMSG, "Invalid value %ld\n", input);
			return RM_INVALID_PARAMETER;
		}

	}


	return RM_OK;
}

/**************************************************************************************************/

static RMstatus print_information(struct rmfp_main_thread_context_type *pMainContext)
{

	ASSERT_NULL_POINTER(pMainContext);

	if (1) {
		RMuint32 time;
		RMFPGetPlaybackTime(pMainContext->pHandle, &time);

#if 0
		if ((time / 1000 >= pMainContext->LastPlaybackTime + 1)
		    || (time / 1000 <= pMainContext->LastPlaybackTime - 1)) {
			RMDBGPRINT((ENABLE, "\nTime: %lu.%lu\n", time / 1000, time % 1000));
			pMainContext->LastPlaybackTime = time / 1000;
		}
#else
		RMDBGPRINT((ENABLE, "\nTime: %lu.%lu secs\n", time / 1000, time % 1000));
#endif

	}


	print_stream_metadata(pMainContext);

	if(Sw_LogMediaFileInfo)
	{
		// Print streams properties
		print_current_streams_properties(pMainContext, pMainContext->stream_properties.valid_properties_mask);
	}

	// Print time
	print_time(pMainContext);

	return RM_OK;
}


/**************************************************************************************************/

static void print_current_streams_properties(struct rmfp_main_thread_context_type *pMainContext, RMuint32 mask)
{
	RMascii* codec = "\0";
	struct RMFPStreamProperties *pStreamProperties = &pMainContext->stream_properties;

	/*
	 * Video stream
	 */
	if (mask & RMFP_STREAM_PROPERTIES_MASK_VIDEO) {

		fprintf(NORMALMSG, "\n============== Current video stream =============\n\n");

		if (pStreamProperties->video.id != -1) {

			codec = "unknown?!";

			/* Print properties */
			fprintf(NORMALMSG, "Video stream ID %ld (0x%lx):\n", pStreamProperties->video.id, pStreamProperties->video.id);

			switch (pStreamProperties->video.codec) {
			case EMhwlibVideoCodec_MPEG2:         codec = "MPEG2"; break;
			case EMhwlibVideoCodec_MPEG4:         codec = "MPEG4"; break;
			case EMhwlibVideoCodec_MPEG4_Padding: codec = "MPEG4p"; break;
			case EMhwlibVideoCodec_DIVX3:         codec = "DIVX3"; break;
			case EMhwlibVideoCodec_VC1:           codec = "VC1"; break;
			case EMhwlibVideoCodec_WMV:           codec = "WMV"; break;
			case EMhwlibVideoCodec_H264:          codec = "H264"; break;
			case EMhwlibVideoCodec_AVS:           codec = "AVS"; break;
			case EMhwlibVideoCodec_H261:          codec = "H261"; break;
			case EMhwlibJPEGCodec:                codec = "JPEG"; break;
			case EMhwlibDVDSpuCodec:              codec = "DVDSPU"; break;
			case EMhwlibBDRLECodec:               codec = "BDRLE"; break;
			}

			fprintf(NORMALMSG,"\tCodec             %lu (%s)\n", (RMuint32)pStreamProperties->video.codec, codec);
			fprintf(NORMALMSG,"\tResolution        %lux%lu\n",
				pStreamProperties->video.picture_info.scaled_width,
				pStreamProperties->video.picture_info.scaled_height);
			fprintf(NORMALMSG,"\tFormat            %s\n",
				(pStreamProperties->video.picture_info.picture_display_data & 0x3)?"Interlaced":"Progressive");

		}
		else
			fprintf(NORMALMSG, "No video\n");

		fprintf(NORMALMSG, "\n=================================================\n\n");
	}

	/*
	 * Audio stream
	 */
	if (mask & RMFP_STREAM_PROPERTIES_MASK_AUDIO) {

		fprintf(NORMALMSG, "\n============== Current audio stream =============\n\n");

		if (pStreamProperties->audio.id != -1) {

			codec = "unknown?!";

			fprintf(NORMALMSG, "Audio stream ID %ld (0x%lx):\n", pStreamProperties->audio.id, pStreamProperties->audio.id);

			switch ((enum AudioDecoder_Codec_type)pStreamProperties->audio.audio_info.CodecID) {
			case AudioDecoder_Codec_AC3:          codec = "AC3"; break;
			case AudioDecoder_Codec_MPEG1:        codec = "MPEG"; break;
			case AudioDecoder_Codec_AAC:          codec = "AAC"; break;
			case AudioDecoder_Codec_DVDA:         codec = "DVDA"; break;
			case AudioDecoder_Codec_PCM:          codec = "PCM"; break;
			case AudioDecoder_Codec_DTS:          codec = "DTS"; break;
			case AudioDecoder_Codec_WMA:          codec = "WMA"; break;
			case AudioDecoder_Codec_WMAPRO:       codec = "WMAPRO"; break;
			case AudioDecoder_Codec_WMAPRO_SPDIF: codec = "WMAPRO_SPDIF"; break;
			case AudioDecoder_Codec_TTONE:        codec = "TTONE"; break;
			case AudioDecoder_Codec_DTSLBR:       codec = "DTSLBR"; break;

			case AudioDecoder_Codec_EXAC:         codec = "EXAC ??"; break;
			case AudioDecoder_Codec_PCMX:         codec = "PCMX ??"; break;
			case AudioDecoder_Codec_BSAC:         codec = "BSAC ??"; break;
			case AudioDecoder_Codec_ATX:          codec = "ATX ??"; break;
			case AudioDecoder_Codec_Speech:       codec = "Speech ??"; break;
			case AudioDecoder_Codec_DRA:          codec = "DRA ??"; break;
			case AudioDecoder_Codec_FLAC:         codec = "FLAC"; break;
			case AudioDecoder_Codec_AG711:        codec = "AG711 ??"; break;
			case AudioDecoder_Codec_VORBIS:	      codec = "OGG Vorbis"; break;
			case AudioDecoder_Codec_ADPCM:		codec = "ADPCM"; break;	
			}

			fprintf(NORMALMSG,"\tCodec             %lu (%s)\n", (RMuint32)pStreamProperties->audio.audio_info.CodecID, codec);
			fprintf(NORMALMSG,"\tSampleRate        %lu\n", (RMuint32)pStreamProperties->audio.audio_info.SampleRate);
			fprintf(NORMALMSG,"\tChannelNumber     %lu\n", (RMuint32)pStreamProperties->audio.audio_info.ChannelNumber);
			fprintf(NORMALMSG,"\tBassMode          %lu\n", (RMuint32)pStreamProperties->audio.audio_info.BassMode);
			fprintf(NORMALMSG,"\tSpeakerConfig     %lu\n", (RMuint32)pStreamProperties->audio.audio_info.SpeakerConfig);
			fprintf(NORMALMSG,"\tLFE               %lu\n", (RMuint32)pStreamProperties->audio.audio_info.lfe);
			fprintf(NORMALMSG,"\tDualMode          %lu\n", (RMuint32)pStreamProperties->audio.audio_info.DualMode);
			{
				char szSpdifMode[32];
				rmoutput_SpdifMode_getDesc2(pStreamProperties->audio.audio_info.SpdifMode, szSpdifMode, sizeof(szSpdifMode));
				fprintf(NORMALMSG,"\tSpdifMode         %s\n", szSpdifMode);
			}
			fprintf(NORMALMSG,"\tChannelAssignment %lu\n", (RMuint32)pStreamProperties->audio.audio_info.ChannelAssignment);
		}
		else
			fprintf(NORMALMSG, "No audio\n");

		fprintf(NORMALMSG, "\n=================================================\n\n");
	}

	/*
	 * Subtitles
	 */
	if (mask & RMFP_STREAM_PROPERTIES_MASK_SUBTITLES) {

		fprintf(NORMALMSG, "\n=========== Current subtitles stream ============\n\n");

		if (pStreamProperties->subtitles.id != -1)
			fprintf(NORMALMSG, "Subtitles stream ID %ld (0x%lx)\n", pStreamProperties->subtitles.id, pStreamProperties->subtitles.id);
		else
			fprintf(NORMALMSG, "No subtitles\n");

		fprintf(NORMALMSG, "\n=================================================\n\n");
	}

	/*
	 * Picture
	 */
	if (mask & RMFP_STREAM_PROPERTIES_MASK_PICTURE) {
		fprintf(NORMALMSG, "\n=========== Current picture stream ==============\n\n");

		if (pStreamProperties->picture.id != -1) {
			switch(pStreamProperties->picture.format) {
			case RMFPPictureFormat_BMP:
				fprintf(NORMALMSG, "\tType		BMP\n");
				break;
			case RMFPPictureFormat_JPEG:
				fprintf(NORMALMSG, "\tType		JPEG\n");
				break;
			case RMFPPictureFormat_GIF:
				fprintf(NORMALMSG, "\tType		GIF\n");
				break;
			case RMFPPictureFormat_PNG:
				fprintf(NORMALMSG, "\tType		PNG\n");
				break;
			case RMFPPictureFormat_YUV:
				fprintf(NORMALMSG, "\tType		YUV\n");
				break;
			case RMFPPictureFormat_TEST:
				fprintf(NORMALMSG, "\tType		Test\n");
				break;
			}

			fprintf(NORMALMSG, "\tSize		%lux%lu\n", pStreamProperties->picture.width, pStreamProperties->picture.height);
			fprintf(NORMALMSG, "\tPalette size	%lu\n", pStreamProperties->picture.palette_size);
		}
		else
			fprintf(NORMALMSG, "No picture\n");

		fprintf(NORMALMSG, "\n=================================================\n\n");

		//pMainContext->AppOptions.Playback.wait_exit = TRUE;
	}

}


/**************************************************************************************************/

static void print_time(struct rmfp_main_thread_context_type *pMainContext)
{
	struct RMFPStreamMetadata *pStreamMetadata = &(pMainContext->metadata);
	RMuint32 j;
	RMuint32 time;
	RMuint32 h, m, s;

	#define GET_TIME(my_time_ms)\
		h = my_time_ms / (1000*3600);\
		m = my_time_ms / (1000*60) - 60*h;\
		s = my_time_ms / 1000 - 60*m - 3600*h;\


	RMFPGetPlaybackTime(pMainContext->pHandle, &time);
	fprintf(NORMALMSG, "\n=========== Playback time information ===========\n\n");
	GET_TIME(pStreamMetadata->Duration);
	fprintf(NORMALMSG, " File duration :  %2lu hour %2lu min %2lu sec\n", h, m, s);
	GET_TIME(time);
	fprintf(NORMALMSG, " Elapsed time :   %2lu hour %2lu min %2lu sec\n", h, m, s);

	if (pStreamMetadata->Duration) {
//		GET_TIME((pStreamMetadata->Duration-time));
		GET_TIME((pStreamMetadata->Duration>=time?pStreamMetadata->Duration-time:0));
		fprintf(NORMALMSG, " Remaining time : %2lu hour %2lu min %02lu sec\n", h, m, s);
//		fprintf(NORMALMSG, " Remaining time : %2lu hour %2lu min %02lu sec(duration=%lu, time=%lu)\n", h, m, s, pStreamMetadata->Duration, time);
	}

	/* Show a bar */
	if (pStreamMetadata->Duration) {
		RMuint32 length;

		fprintf(NORMALMSG, "\n [");

		length = RMasciiLength("=============================================");

		for (j=0; j<length; j++) {

			if (j < ((time * length) / pStreamMetadata->Duration))
				fprintf(NORMALMSG, "#");
			else
				fprintf(NORMALMSG, "-");

		}
		fprintf(NORMALMSG, "]\n\n");
	}


	fprintf(NORMALMSG, "=================================================\n\n");
}

/**************************************************************************************************/

static void print_current_pat(struct rmfp_main_thread_context_type *pMainContext)
{
	RMuint32 i;
	struct DCCPATInfoType* pPAT =  &pMainContext->current_pat;

	/* Print PAT */
	fprintf(NORMALMSG, "\nPAT:  Number - PID (%lu PMT)\n", pPAT->count);
	for (i=0; i<pPAT->count; i++)
		fprintf(NORMALMSG, "    #%04d  - 0x%04x (%d)\n",
			pPAT->program_number[i], pPAT->program_map_pid[i], pPAT->program_map_pid[i]);
}

/**************************************************************************************************/

static void print_current_pmt(struct rmfp_main_thread_context_type *pMainContext)
{
	RMuint32 i;
	struct DCCPMTInfoType* pPMT =  &pMainContext->current_pmt;

	/* Print PMT */
	fprintf(NORMALMSG, "\nPMT:  Type    - PID #%d\n",
		pPMT->program_number);

	fprintf(NORMALMSG, "    pcr      - 0x%04x (%d)\n",
		pPMT->pcr_pid, pPMT->pcr_pid);

	for (i=0; i< pPMT->count; i++)
		fprintf(NORMALMSG, "    0x%04x   - 0x%04x (%d)\n",
			pPMT->stream_type[i], pPMT->elementary_pid[i], pPMT->elementary_pid[i]);
}

/**************************************************************************************************/

static void fill_output_osd_size(struct rmfp_main_thread_context_type *pHandle, struct RMFPOSDProfile *pOSDProfile, RMuint32 mixer)
{
	RMstatus status;

	/* Adapte window size to outport aspect ratio */
	if (!pOSDProfile->ForcedOSDSize) {
		struct EMhwlibAspectRatio Asp;

		status = RUAGetProperty(pHandle->pRUA, mixer, RMGenericPropertyID_DisplayAspectRatio, &Asp, sizeof(Asp));
		if (status != RM_OK) {
			RMNOTIFY((NULL, status, "Cannot get aspect ratio from mixer %d\n", mixer));
		}

		if (pOSDProfile->Profile.Width > (Asp.X * pOSDProfile->Profile.Height)/Asp.Y) {
			pHandle->applied_output_osd_window.Width = 4096;
			pHandle->applied_output_osd_window.Height = pOSDProfile->Profile.Height * 4096 * Asp.X / (pOSDProfile->Profile.Width * Asp.Y);
		} else {
			pHandle->applied_output_osd_window.Width = pOSDProfile->Profile.Width * 4096 * Asp.Y / (pOSDProfile->Profile.Height * Asp.X);
			pHandle->applied_output_osd_window.Height = 4096;
		}
	}
	else {
		pHandle->applied_output_osd_window.Width = pHandle->AppOptions.Display.output_osd_window.Width/* * 9 / 10 */ ;
		pHandle->applied_output_osd_window.Height = pHandle->AppOptions.Display.output_osd_window.Height/* * 9 / 10 */ ;
	}

}

/**************************************************************************************************/

static RMstatus parse_magazinePacketAddress(RMuint32 * pageNumber, RMuint32 * magazineNumber, RMuint32 magazinePageNumber)
{

	*magazineNumber = (RMuint32) magazinePageNumber/100;
	*pageNumber = (RMuint32) ( magazinePageNumber - ( (RMuint32) ( *magazineNumber * 100 ) ) );
	RMDBGLOG((DISABLE, "magazineNumber : %lu pageNumber : %lu \n",*magazineNumber, *pageNumber ));
	if ( *magazineNumber == 8 ){
		*magazineNumber = 0;
	}
	return RM_OK;

}


