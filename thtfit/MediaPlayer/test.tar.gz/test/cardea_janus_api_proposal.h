/********************************************************************
 *
 *  CARDEA/JANUS API PROPOSAL: David Bryson, Sebastian Frias Feltrer
 *
 ********************************************************************/

/*
  This file's structure:

  - Notes
  - Current Janus API
  - Notes regarding the current and future Janus API
  - Current Cardea API
  - Notes regarding the current and future Cardea API
  - The proposed Cardea/Janus API per se.
*/



/*
  NOTES:

  - JANUS requires ASF data packets to be contiguous for decryption. (see comment on
  readBitstream() in play_asf.c; we need a way to know if this is required.

  - CARDEA might not support seeking depending on the server version; we need a way
  to know if seeking is allowed.


  We know that we're using JANUS if the parser tell it to us (it initialised the library)
  -Since JANUS will support a handle we could also have a query call.

  We know that we're using CARDEA by querying the CARDEA library.

  What we'd like for MicroAVBrowser to do:

  - it communicates with the CARDEA server
  - it uses metadata to know more about the content
  - it initialises CARDEA for content requiring it
  - it opens the URL and passes a file handle to libsamples2
  - it communicates the CARDEA handle to libsamples2 

*/




/* CURRENT JANUS API */


// called from rmasfdemux
RMint32 WMDRM_init(void);
RMint32 WMDRM_term(void);
RMint32 WMDRM_process_header(RMuint8 *, RMuint32 , WMDRM_OPL *);

// called from play_asf
RMint32 WMDRM_decrypt_packet(RMuint8 *, RMuint32);




/* 
   CURRENT CODE FOR JANUS:

   play_asf opens the file and feed it to rmasfdemux;

   if JANUS, rmasfdemux will call WMDRM_init(), then WMDRM_process_header();

   play_asf checks if the content is encrypted, if it is it calls WMDRM_decrypt_packet;

   if JANUS WMDRM_term is called by rmasfdemux before its destruction;

*/

/* 
   FUTURE CODE FOR JANUS:
   
   main_asf will register its own ExtendedContentEncryption callback to prevent
   rmasfdemux from initialising the library by itself.
   
   main_asf opens the file and feed it to rmasfdemux;

   if JANUS, main_asf's callbacks will call:
   -RMWMDRM_open_drm(JANUS)
   -RMWMDRM_get_resources()
   -allocate the RUAMemory required
   -RMWMDRM_set_resources()

	-my_url = RMWMDRM_url_open(filename)
	-RMWMDRM_url_get_license(my_url)

	< decrypt packets >

	-RMWMDRM_url_close(my_url)
	-RMWMDRM_close()

   will call RMWMDRM_push_packets and RMWMDRM_pull_packets with it.

   when playback ends, main_asf will call RMWMDRM_get_resources to obtain
   the resources used by the library, then RMWMDRM_close the handle and release
   the RUAMemory of the resources

   *) main_asf is libsamples2's equivalent of play_asf.

*/




/* CURRENT CARDEA API */

//currenty unused (by play_asf, rmpfs or microavbrowser)
RMstatus release_cardea(void *);
void * init_cardea_url(struct ms_upnp_extension_s *ms_upnp, RMascii *url, RMascii *session_header);
RMstatus destroy_url_context(void *url_ctx);
RMstatus get_cardea_analog_opl(
		void * cardea_context,
		struct cardea_extended_analog_video_s *analog_opl,
		RMuint32 *analog_opl_size,
		RMuint32 *analog_opl_count);

//currently used by play_asf

RMint32 init_cardea(const RMascii *url);
void * find_cardea_url(RMascii *url);
void * find_cardea_device(RMascii *url);
RMbool should_decrypt(void *cardea_url);
RMstatus term_cardea(void);
void update_cardea_sample_id(
		void * cardea_context, 
		RMuint16 stream_index, 
		RMuint32 media_object_number, 
		RMuint8 *sample_id, 
		RMuint32 sample_id_size);
RMstatus decrypt_cardea_sample(
		void * cardea_context,
		RMuint16 stream_index,
		RMuint32 media_object_number,
		RMuint32 buf_phys,
		RMuint8 *buf,
		RMuint32 size);


RMstatus get_cardea_opl(
		void * cardea_context,
		struct cardea_opl_s *opl);
RMstatus get_cardea_cci( 
		void * cardea_context, 
		struct rmcci *cci_info );


// currently used by micravbrowser
RMstatus load_cardea(RMuint8 *certificate, RMint32 size);

// currently used by play_asf and rmpfs
RMascii * get_ms_session_header(const RMascii *url);
RMstatus destroy_cardea_license_data(void *cardea_context);



/* 
   CURRENT CODE FOR CARDEA:
   
   MicroAVBrowser calls load_cardea();
   
   MicroAVBrowser calls play_file(url) which calls find_cardea_url(url) to know
   if it's CARDEA protected or not. If it is, detection is bypassed and we call
   play_asf(url)

   play_asf(url) will call init_cardea(url), then find_cardea_device(url) and
   store the context in a variable 'context'. 
   If the context is non-NULL we call get_ms_session_header(url) and then
   find_cardea_url(url) and we store the result in the same 'context' variable (note
   that we loose the context returned by find_cardea_device)
   if the session is non-NULL we setup the http lib to use it. If this is successful
   CARDEA is required, else CARDEA is not required
   test_cci and get_cardea_opl with 'context' are called also

   (for rmpfs we do get_ms_session_header(url) and if non-NULL we setup the http lib
   when opening the url)

   if CARDEA enter linear playback mode

   if CARDEA call update_cardea_sample_id(context...) in payload extension callback

   if CARDEA call decrypt_cardea_sample(context...) in payload callback

   when playback ends, if CARDEA call destroy_cardea_license_data(context)


*/

/*
	NOTE: We have deprecated the opl code, in preference of a unified struct
	rmcci 
	FUTURE CODE FOR CARDEA:
  
  MicroAVBrowser setup RMFP (libsamples2):
  -RMFPInitProfile()
  -RMFPInitOptions()
  -RMFPInitStreamType()
  -open RUA and DCC
  -fill the RMFPprofile and do RMFPOpenHandle()

  MicroAVBrowser setup CARDEA:
  -WMDRM_open_drm(CARDEA)
  -WMDRM_get_resources();
  -allocate the RUAMemory required;
  -RMWMDRM_set_resources();
 	- my_url = RMWMDRM_url_open(url_path)
	- RMWMDRM_url_get_license(my_url)
	- RMWMDRM_url_set_options(my_url, options)

 
  MicroAVBrowser communicates with the server;

  (we'd need to handle rmpfs somehow, however in its next incarnation it should take
  file handles as parameters, that is, it will *not* open the URLs by itself, it should
  be able to hook itself in between.)

  MicroAVBrowser opens the stream(or streams if rmpfs is enabled):

  1) the URL selected is CARDEA protected:
  
  It is for sure ASF and we set the streamType to ASF. We call 
  RMWMDRM_is_seeking_enabled() if it is not enabled then set linear playback in the options.
  We set the RMWMDRMURLHandle in the options
  Call RMFPMain()

  main_asf will use RMWMDRMURLHandle to call RMWMDRM_push_packet and RMWMDRM_pull_packet
  
  RMFPMain returns after playback ends, then MicroAVBrowser calls RMWMDRM_clear_cardea()
  for this URL.
  
  2) the URL selected is not CARDEA protected:

  We don't know if it's ASF, so MicroAVBrowser uses the metadata to give hints to 
  RMFP's detection.

  Call RMFPMain() after detection.
  

*/


#include "rmdef/rmdef.h"
#include "rmcci/include/outputcci.h"

enum RMWMDRM_type {
	RMWMDRM_type_Janus = 33,
	RMWMDRM_type_Cardea,
};

struct RMWMDRMProfile {

	enum RMWMDRM_type Type; // required
	RMuint32 Slot;          // optional
	RMbool WithPreload;     // optional
	
	RMuint8 *PathToCertificates; // optional

	// maybe some specific handler information as well ?
	// it will be opaque to the caller, and they only need populate it
	// if they so desire.
	// including maybe paths for janus and cardea certificates ?

};


struct RMWMDRMResourcesProfile {
	RMuint32 PacketFIFOEntries;  // used to dimension the FIFO sizes; this is the max number of packets we can handle in the FIFO
};
	

// In this case, resources refers to fifo sizes
// the size is calculated according to RMWMDRMResourcesProfile.PacketFIFOEntries
// if the address is NULL it needs to be allocated
struct RMWMDRMResources {
	RMuint8 *pAddress;
	RMuint32 Size;
};



// for the most part this is opaque for libsamples, used internally for wmdrm
// this handle is common for JANUS and CARDEA
struct RMWMDRMHandle {
	RMuint8 *xrpc_address;
	RMuint32 xrpc_size;
	RMuint32 xrpc_state;
	struct XtaskAPI g_xapi;

	struct RMWMDRMResources xtask_resources;
};

/* this is a URL dependant context derived from a given RMWMDRMHandle
   returned by RMWMDRM_init_janus/cardea
   used mainly by RMWMDRM_push_packets() and RMWMDRM_pull_packets()
*/
// this handle is common for JANUS and CARDEA
struct RMWMDRMURLHandle {
	RMascii *url; // null terminated string

	RMuint8 *session_info; // for cardea this holds the session id
	RMuint32 session_size;

	RMWMDRM_type type;

	struct rmcci *wmdrm_cci;
	struct RMWMDRMHandle *drm_handler;  // points to parent drm handler
};

struct RMWMDRMPacket {
	RMuint8 *pAddress;
	RMuint32 Size;
};


/* begin RMWMDRM handle based functions */

/*
  equivalent to old load_cardea() and WMDRM_init()
  
  Loads specified windows media DRM xtask and calls initialization procedures
  
  @param struct RMRMWMDRMProfile *pProfile: populated profile information detailing information for starting a new DRM.
  @param struct RMWMDRMHandle **ppHandle: returns a pointer to the wmdrm handler for this particular session
    
*/
RMstatus RMWMDRM_init_drm(struct RMWMDRMProfile *pProfile, struct RMWMDRMHandle **ppHandle);

/*
  Requests a resources size specification from the wmdrm xtask.
  
  @param struct RMWMDRMHandle *pHandle: contains wmdrm session handler information for talking to the xtask.
  @param struct RMWMDRMResourcesProfile *pProfile: populated resource profile information.
  @param struct RMWMDRMResources *pResources: A query to the xtask asking for a certain number of 'decrypt' resources using the 'size' parameter.  The xtask modiefies the size attribute to denote how many bytes the CPU must allocate for the requested number of 'decrypt' resources.
*/
RMstatus RMWMDRM_get_resources(struct RMWMDRMHandle *pHandle, struct RMWMDRMResourcesProfile *pProfile, struct RMWMDRMResources *pResources);

/*
  Sets a resources size specification for the wmdrm xtask.
  
  @param struct RMWMDRMHandle *pHandle: contains wmdrm session handler information for talking to the xtask.
  @param struct RMWMDRMResourcesProfile *pProfile: populated resource profile information.
  @param struct RMWMDRMResources *pResources: This struct has the address and the size value set from the previous get_drm_resources call.
*/
RMstatus RMWMDRM_set_resources(struct RMWMDRMHandle *pHandle, struct RMWMDRMResourcesProfile *pProfile, struct RMWMDRMResources *pResources);


/*
  equivalent to old term_cardea() and WMDRM_term
  Terminates the WMDRM xtask and releases all resources controlled by the wmdrm layer for the passed handler.
  
  @param struct RMWMDRMHandle *pHandle: Contains wmdrm session handler information for talking to the xtask.
  
	
*/
RMstatus RMWMDRM_close_drm(struct RMWMDRMHandle *pHandle);


// used to obtain the DRM associated to this handle
RMstatus RMWMDRM_get_drm_type(struct RMWMDRMHandle *pHandle, enum RMWMDRM_type *pType);

/* END of RMWMDRM Handle based functions */

/* BEGIN url handle based functions */

// returns a URL context associated with a DRM for either
// 1) a file on the local FS
// 2) a network based url
RMstatus RMWMDRM_url_init(struct RMWMDRMHandle *pHandle, struct RMWMDRMURLHandle *pURLHandle, RMascii *url, RMuint8 *init_data, RMuint32 init_data_size);

// Acquires or attempts to Acquire a license from the given content handler
// for janus this means 'WMDRM_process_header'
// for cardea this means get_ms_license or try_get_ms_license
RMstatus RMWMDRM_url_get_license(struct RMWMDRMURLHandle *pURLHandle);

// for cardea, gets the sessionID from the url struct
RMstatus RMWMDRM_url_get_sessionID(struct RMWMDRMURLHandle *pURLHandle, RMuint8 *sessionID, RMuint32 *session_size);

// for cardea this replaces get_ms_session_header
// and sets the http options
// this is currently undefined for janus, but may be useful in future
RMstatus RMWMDRM_url_set_options(struct RMWMDRMURLHandle *pURLHandle, void *options);

// allows the application to know if seeking is available  
// returns true on all janus content
RMstatus RMWMDRM_is_seek_enabled(struct RMWMDRMURLHandle *pURLHandle, RMbool *pEnabled);

// allows the application to know the server version
// for janus this returns an non-fatal error
RMstatus RMWMDRM_get_server_version(struct RMWMDRMURLHandle *pURLHandle, RMuint32 *pVersion);

// frees resources held by the url handle
// is removed from list of valid handles for parent DRM handle
RMstauts RMWMDRM_url_close(struct RMWMDRMURLHandle *pURLHandle);

/*
	Pushes any number of RMWMDRMPacket decrypt requests to the XPU decrypt fifo.

        @param struct RMWMDRMHandle *pHandle: contains wmdrm session handler information for talking to the xtask.
        @param struct RMWMDRMPacket *pPackets: Some number of packet structs to be sent to the XPU for decryption.
        @param RMuint32 NumberOfPackets:  The number of packets to be sent to the XPU for decryption.
	@param RMuint32 *pNumberOfPacketsPushed: The number of packets that could be sent to the XPU

	returns RM_PENDING immediately if there's no more room in the FIFO

	(should we have events?)
*/
RMstatus RMWMDRM_push_packets(struct RMWMDRMURLHandle *pURLHandle, struct RMWMDRMPacket *pPackets, RMuint32 NumberOfPackets, RMuint32 *pNumberOfPacketsPushed);

/*
	Pulls any number of available decrypted RMWMDRMPacket requets from the XPU decrypt fifo.

        @param struct RMWMDRMHandle *pHandle: Contains wmdrm session handler information for talking to the xtask.
        @param struct RMWMDRMPacket *pPackets: pointer to a vector (size <= NumberOfPacketsWanted) of RMWMDRMPacket structs.
	@param RMuint32 NumberOfPacketsWanted: the number of packets we'd like.
        @param RMuint32 *pNumberOfPackets: The number of packets that were retreived from the xtask FIFO.

	return RM_PENDING immediately if there's nothing in the FIFO

	(should we have events?)
*/
RMstatus RMWMDRM_pull_packets(struct RMWMDRMURLHandle *pURLHandle, struct RMWMDRMPacket *pPackets, RMuint32 NumberOfPacketsWanted, RMuint32 *pNumberOfPackets);

/* END url handle based functions */
