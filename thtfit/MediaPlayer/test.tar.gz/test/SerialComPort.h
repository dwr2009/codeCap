#ifndef	_SERIAL_COM_PORT_H_
#define	_SERIAL_COM_PORT_H_

#include <BaseTypeDef.h>
#include <termios.h>
#include <FileDescriptorEventIf.h>
#include <Array.h>
#include <ByteArray2.h>
#include <WeakPtr.h>

using namespace CppBase;

#define	MP7XX_MAX_RECEIVE_BUF_SIZE		1024

class CSerialComPort : public IFileDescriptorEventIf
{
public:
	typedef enum
	{
		PARITY_NO,
		PARITY_EVEN,
		PARITY_ODD,
	}SERIAL_PARITY, *P_SERIAL_PARITY;
public:
	CSerialComPort();
	virtual ~CSerialComPort();
	virtual INT_t Open(LPCSTR pszSerialComDev);
	virtual VOID Close();
	virtual INT_t setComParameters(INT_t iBaudrate, SERIAL_PARITY eSerialParity, INT_t iDataBits, INT_t iStopBits);
	virtual INT_t getTermIosSpeed(INT_t iBaudrate, OUT speed_t & termBaudrate);
	virtual INT_t OnFdEvent(int iFd, CONST IFileDescriptorEventIf::FD_EVENT_FLAGS FdEvtFlags);
	virtual INT_t SendCommand(LPCSTR pszCmd);
	virtual INT_t ReadResult(OUT CByteArray2 & resultData);
protected:
public:
	WeakPtr <CSerialComPort> m_this_wp;
protected:
	int m_iDevFd;
	CByteArray2 m_ReceivedData;
};

#endif	//_SERIAL_COM_PORT_H_

