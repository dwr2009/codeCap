/*****************************************
 Copyright 2001-2007
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   rmfp_softcc_render.c
  @brief  This file provides software CloseCaption rendering thru rmscc


  @author Sebastian Frias Feltrer
  @date   2007-11-27
*/


#include "rmfp_internal.h"
#include "rmscc/include/rmscc.h"


#define LOCALDBG DISABLE


/*
   EIA708 can have 3 different sizes and since we're doing some hacks with
   the dimensions we need to store them in order to correct the drawing
   position.
*/
#define MAX_PEN_SIZES (3)


#define ENABLE_TIMING_DBG             (0)
#define ENABLE_DOUBLE_BUFFERED_RENDER (1)
#define ENABLE_BACKGROUND_RECTANGLE   (1)
#define FORCE_TRUECOLOR_MODE          (1)
#define USE_RMRTK                     (0)
#define DRAW_SHADOW_AND_BORDER        (0)


#define OFFSET_X (0)
#define OFFSET_Y (0)


/*
   HACK:
   RMRTK would return w15, h30 for size 27.
   However, with rmfontrender we get w14, h29

   Therefore we are applying a N/M factor of 1/1

   NOTE: now it is 1/1 but it used to be 3/2, we'll keep this code for a while
*/

#define HEIGHT_N (1)
#define HEIGHT_M (1)

#define APPLY_HEIGHT_CORRECTION(variable)	\
	do {					\
		variable *= HEIGHT_N;		\
		variable /= HEIGHT_M;		\
	} while(0)

/*
  HACK:
  Increase the width to improve legibility
*/

#define WIDTH_OFFSET (3)

#define APPLY_WIDTH_CORRECTION(variable)	\
	do {					\
		variable += WIDTH_OFFSET;	\
	} while (0)




#define PRINT_ELAPSED(t_i, t_f, msg)					\
	do {								\
		RMuint64 Ti = (RMuint64)t_i;				\
		RMuint64 Tf = (RMuint64)t_f;				\
									\
		RMDBGLOG((ENABLE, "%s took %lld us (Ti = %llu, Tf = %llu)\n", msg, Tf - Ti, Ti, Tf)); \
									\
	} while(0)







struct RMFPSoftCCRenderPenSize {
	RMuint32 CharSize;
	RMuint32 Height;
	RMuint32 Width;
};



struct RMFPSoftCCRenderHandle {

	RMscc pSCC;

	enum RMFPCloseCaptionType CCType;

	RMbool UseRMRTK;

	struct RMLibPlayOSDSource OSDSource;
	struct RMLibPlayOSDPicture CurrentOSDPicture;

	struct RMFontRenderSurface *pSurface;

	RMuint8 *pLumaBuffer;  // locked and mapped
	RMuint32 LumaSize;


	RMuint8  CCBuffer[256];
	RMuint32 CCSize;

	RMuint8  DTVBuffer[128];
	RMuint32 DTVSize;

	RMpalette_8BPP CCPalette;

	RMuint8 *pFontName;

	struct RMFPSoftCCRenderPenSize PenSizeList[MAX_PEN_SIZES];
	RMuint32 PenSizes;

	RMbool DisplayDirty;
	RMbool NewPicture;
};



static RMstatus softcc_get_string_size(void *pContext,
				       RMuint8 *pChars,
				       RMuint32 CharSize,
				       RMuint32 *pWidth,
				       RMuint32 *pHeight);

static RMstatus softcc_draw_string(void *pContext,
				   RMuint32 PosX,
				   RMuint32 PosY,
				   RMuint8 *pChars,
				   RMuint32 FGColor,
				   RMuint32 BGColor,
				   RMuint32 CharSize,
				   RMuint32 *pWidth,
				   RMuint32 *pHeight);

static RMstatus softcc_draw_rect(void *pContext,
				 RMuint32 PosX,
				 RMuint32 PosY,
				 RMuint32 Width,
				 RMuint32 Height,
				 RMuint32 Color);

static RMstatus softcc_prepare_to_draw(void *pContext);
static RMstatus softcc_draw_finished(void *pContext);


static RMstatus open_softcc_with_rmrtk(struct RMFPHandle *pHandle);
static RMstatus close_softcc_with_rmrtk(struct RMFPHandle *pHandle);

static RMstatus open_softcc_with_callbacks(struct RMFPHandle *pHandle);
static RMstatus close_softcc_with_callbacks(struct RMFPHandle *pHandle);


RMstatus rmfp_internal_open_softcc_render(struct RMFPHandle *pHandle)
{
	RMDBGLOG((LOCALDBG, "rmfp_internal_open_softcc_render()\n"));

	if (USE_RMRTK)
		return open_softcc_with_rmrtk(pHandle);
	else
		return open_softcc_with_callbacks(pHandle);

}

RMstatus rmfp_internal_close_softcc_render(struct RMFPHandle *pHandle)
{
	RMDBGLOG((LOCALDBG, "rmfp_internal_close_softcc_render()\n"));

	ASSERT_NULL_POINTER(pHandle);
	ASSERT_NULL_POINTER(pHandle->pSoftCCRenderHandle);

	if (pHandle->pSoftCCRenderHandle->UseRMRTK)
		return close_softcc_with_rmrtk(pHandle);
	else
		return close_softcc_with_callbacks(pHandle);
}

RMstatus rmfp_internal_process_close_caption_entry(void *pContext, struct CCFifo_CCEntry_type *pCloseCaptionEntry)
{


	struct RMFPHandle *pRMFPHandle = NULL;
	struct RMFPSoftCCRenderHandle *pHandle = NULL;
	enum rmscc_ccselect CloseCaptionSelect = rmscc_not_available;

#if ENABLE_TIMING_DBG
	RMuint64 t0, t1;

	t0 = RMGetTimeInMicroSeconds();
#endif

	RMDBGLOG((DISABLE, "got new CC entry\n"));

	ASSERT_NULL_POINTER(pContext);
	ASSERT_NULL_POINTER(pCloseCaptionEntry);

	pRMFPHandle = (struct RMFPHandle *)pContext;

	if (pRMFPHandle->video_options.CloseCaptionMode != RMFPCloseCaptionMode_ShowInOSD)
		return RM_OK;

	if (!pRMFPHandle->pSoftCCRenderHandle->pSCC) {
		RMNOTIFY((NULL, RM_FATALINVALIDPOINTER, "Invalid RMSCC handle\n"));
		return RM_FATALINVALIDPOINTER;
	}

	if (!pRMFPHandle->profile.pFontRenderHandle) {
		RMNOTIFY((NULL, RM_FATALINVALIDPOINTER, "Invalid RMFontRender handle\n"));
		return RM_FATALINVALIDPOINTER;
	}


	pHandle = pRMFPHandle->pSoftCCRenderHandle;


	CloseCaptionSelect = RMSCCGetDisplayCCType(pHandle->pSCC);


	if (pCloseCaptionEntry->Enable) {
		switch (pCloseCaptionEntry->Type) {
		case EMhwlibCCType_TopField:
		case EMhwlibCCType_BottomField:
			if ( (CloseCaptionSelect != rmscc_not_available) &&
			     (((RMuint32)CloseCaptionSelect & 0x2) >> 1 == pCloseCaptionEntry->Type) ) {
				if (pHandle->CCSize >= 128 - 2) {
					RMSCCDecode(pHandle->pSCC, pHandle->CCBuffer, pHandle->CCSize, RMGetTimeInMicroSeconds() );
					pHandle->CCSize = 0;
				}
				pHandle->CCBuffer[pHandle->CCSize++] = pCloseCaptionEntry->CC1;
				pHandle->CCBuffer[pHandle->CCSize++] = pCloseCaptionEntry->CC2;
			}

			break;

		case EMhwlibCCType_DTVCCHeader:
			if (pHandle->DTVSize)
				pHandle->DTVSize = 0;
			// seems to miss a break here??

		case EMhwlibCCType_DTVCCData:
			if (pHandle->DTVSize < 128 - 1) {
				pHandle->DTVBuffer[pHandle->DTVSize++] = pCloseCaptionEntry->CC1;
				pHandle->DTVBuffer[pHandle->DTVSize++] = pCloseCaptionEntry->CC2;
			}

			if(pHandle->DTVSize >= ((RMuint32)pHandle->DTVBuffer[0] & 0x3f) * 2 ) {
					RMSCCDecode(pHandle->pSCC, pHandle->DTVBuffer, pHandle->DTVSize, RMGetTimeInMicroSeconds() );
					pHandle->DTVSize = 0;
			}

			break;
		default:
			break;
		}
	}

	if (pHandle->CCSize) {
		RMSCCDecode(pHandle->pSCC, pHandle->CCBuffer, pHandle->CCSize, RMGetTimeInMicroSeconds() );
		pHandle->CCSize = 0;
	}

	if (pHandle->DTVSize >= 128) {
		RMNOTIFY((NULL, RM_ERROR, "More than 127 dtv bytes without a header?\n"));
		return RM_ERROR;
	}

#if ENABLE_TIMING_DBG
	t1 = RMGetTimeInMicroSeconds();
	PRINT_ELAPSED(t0, t1, "process_cc_entry");
#endif

	return RM_OK;
}

static RMstatus open_softcc_with_rmrtk(struct RMFPHandle *pHandle)
{
	return RM_NOTIMPLEMENTED;
}

static RMstatus close_softcc_with_rmrtk(struct RMFPHandle *pHandle)
{

	return RM_NOTIMPLEMENTED;
}

static RMstatus open_softcc_with_callbacks(struct RMFPHandle *pHandle)
{
	RMscc pSCC;

	struct RMSCCProfile SCCProfile;

	RMuint32 used_colors;

	enum RMFPCloseCaptionType CloseCaptionType;
	enum rmscc_ccselect CloseCaptionSelect = rmscc_not_available;
	RMstatus status;

	struct RMLibPlayOSDProfile OSDProfile;

	struct RMFontRenderFontInfo FontInfo;
	RMbool Found = FALSE;
	RMuint32 i;

	RMDBGLOG((LOCALDBG, "rmfp_internal_open_softcc_render()\n"));

	if (!pHandle->profile.pFontRenderHandle) {
		RMNOTIFY((NULL, RM_FATALINVALIDPOINTER, "Invalid RMFontRender handle\n"));
		return RM_FATALINVALIDPOINTER;
	}

	if(NULL == pHandle->pSoftCCRenderHandle)
	{
		pHandle->pSoftCCRenderHandle = (struct RMFPSoftCCRenderHandle *)RMMalloc(sizeof(struct RMFPSoftCCRenderHandle));
		if (!pHandle->pSoftCCRenderHandle) {
			RMNOTIFY((NULL, RM_FATALOUTOFMEMORY, "Not enough memory\n"));
			return RM_FATALOUTOFMEMORY;
		}
	}
	RMMemset((void*)pHandle->pSoftCCRenderHandle, 0, sizeof(struct RMFPSoftCCRenderHandle));

	if (USE_RMRTK)
		pHandle->pSoftCCRenderHandle->UseRMRTK = TRUE;
	else
		pHandle->pSoftCCRenderHandle->UseRMRTK = FALSE;

	// search a monospaced font

	i = 0;
	while (1) {

		status = RMFontRenderGetFontInfo(pHandle->profile.pFontRenderHandle, i, &FontInfo);
		if (status != RM_OK)
			break;

		if (FontInfo.FixedWidth) {
			RMDBGLOG((LOCALDBG, "Fixed!\n"));
			Found = TRUE;
			break;
		}
		else
			RMDBGLOG((LOCALDBG, "Variable\n"));

		i++;
	}

	if (!Found) {

		RMDBGLOG((LOCALDBG, "Couldn't find fixed width font\n"));

		if (pHandle->profile.pCCFontName) {

			RMDBGLOG((LOCALDBG, "using default CC font\n"));

			FontInfo.pFontName = pHandle->profile.pCCFontName;
		}
		else {
			RMDBGLOG((LOCALDBG, "using first font\n"));

			status = RMFontRenderGetFontInfo(pHandle->profile.pFontRenderHandle, 0, &FontInfo);
			if (status != RM_OK) {
				RMDBGLOG((ENABLE, "no suitable fonts found\n"));
				return status;
			}
		}
	}

	RMDBGLOG((LOCALDBG, "name '%s'\n", FontInfo.pFontName));

	pHandle->pSoftCCRenderHandle->pFontName = FontInfo.pFontName;
	pHandle->pSoftCCRenderHandle->CCType    = pHandle->video_options.CloseCaptionType;

	CloseCaptionType = pHandle->pSoftCCRenderHandle->CCType;

	switch (pHandle->video_options.CloseCaptionSelect) {
	case EMhwlibCCSelect_CC1:
		CloseCaptionSelect = rmscc_cc_1;
		break;
	case EMhwlibCCSelect_CC2:
		CloseCaptionSelect = rmscc_cc_2;
		break;

	case EMhwlibCCSelect_CC3:
		CloseCaptionSelect = rmscc_cc_3;
		break;

	case EMhwlibCCSelect_CC4:
		CloseCaptionSelect = rmscc_cc_4;
		break;
	};

	RMDBGLOG((LOCALDBG, "open SCC\n"));

	if (CloseCaptionType == RMFPCloseCaptionType_EIA608)
		SCCProfile.CCFormat = rmscc_eia_608;
	else if (CloseCaptionType == RMFPCloseCaptionType_EIA708)
		SCCProfile.CCFormat = rmscc_eia_708;

	SCCProfile.CCSelect = CloseCaptionSelect;

	SCCProfile.ResizeWindowCallback = NULL;
	SCCProfile.pResizeCallbackContext = NULL;


	SCCProfile.SurfaceWidth  = 640;
	SCCProfile.SurfaceHeight = 480;


	SCCProfile.pCallbackContext      = pHandle;
	SCCProfile.GetStringSizeCallback = softcc_get_string_size;
	SCCProfile.DrawStringCallback    = softcc_draw_string;
	SCCProfile.DrawRectangleCallback = softcc_draw_rect;
	SCCProfile.PrepareToDrawCallback = softcc_prepare_to_draw;
	SCCProfile.DrawFinishedCallback  = softcc_draw_finished;

	status = RMSCCOpenWithCallbacks(&SCCProfile, &(pSCC));
	if ((status != RM_OK) || (pSCC == NULL)) {
		if (status == RM_OK)
			status = RM_ERROR;

		RMNOTIFY((NULL, RM_ERROR, "Cannot open SCC\n"));
		return status;
	}

	RMDBGLOG((LOCALDBG, "get SCC palette\n"));

	status = RMSCCGetPalette(pSCC, &(pHandle->pSoftCCRenderHandle->CCPalette), &used_colors);
	if (status != RM_OK){
		RMNOTIFY((NULL, status, "Cannot get SCC palette\n"));

		goto exit_with_error;
	}

	RMDBGLOG((LOCALDBG, "open soft CC OSD\n"));

	if (ENABLE_DOUBLE_BUFFERED_RENDER)
		OSDProfile.NumberOfPictures = 2;
	else
		OSDProfile.NumberOfPictures = 1;


	if (SCCProfile.CCFormat == rmscc_eia_608)
		OSDProfile.Profile.ColorMode = EMhwlibColorMode_LUT_8BPP;
	else if (SCCProfile.CCFormat == rmscc_eia_708)
		OSDProfile.Profile.ColorMode = EMhwlibColorMode_TrueColor;


#if FORCE_TRUECOLOR_MODE
	OSDProfile.Profile.ColorMode = EMhwlibColorMode_TrueColor;
#endif

	OSDProfile.Profile.ColorFormat  = EMhwlibColorFormat_32BPP;
	OSDProfile.Profile.ColorSpace   = EMhwlibColorSpace_RGB_0_255;
	OSDProfile.Profile.SamplingMode = EMhwlibSamplingMode_444;

	OSDProfile.ForcedOSDSize  = TRUE;
	OSDProfile.Profile.Width  = SCCProfile.SurfaceWidth;
	OSDProfile.Profile.Height = SCCProfile.SurfaceHeight;

	OSDProfile.Profile.PixelAspectRatio.X = 1;
	OSDProfile.Profile.PixelAspectRatio.Y = 1;

	status = rmfp_internal_open_osd_handler((void*)pHandle, &OSDProfile, &(pHandle->pSoftCCRenderHandle->OSDSource));
	if (status != RM_OK) {
		RMNOTIFY((NULL, status, "Couldn't open OSD for soft close caption rendering\n"));

		goto exit_with_error;
	}

	status = rmfp_internal_get_osd_picture_handler((void*)pHandle,
						       &(pHandle->pSoftCCRenderHandle->OSDSource),
						       &(pHandle->pSoftCCRenderHandle->CurrentOSDPicture));
	if (status != RM_OK) {
		RMNOTIFY((NULL, status, "Couldn't get picture\n"));

		goto exit_with_error;
	}

	{
		RMuint32 LumaAddr, LumaSize;
		RMuint8 *luma_buf;

		LumaAddr = pHandle->pSoftCCRenderHandle->CurrentOSDPicture.LumaBufferAddress;
		LumaSize = pHandle->pSoftCCRenderHandle->CurrentOSDPicture.LumaBufferSize;

		pHandle->pSoftCCRenderHandle->CurrentOSDPicture.pPalette = (RMuint32*)&(pHandle->pSoftCCRenderHandle->CCPalette);

		status = RUALock(pHandle->profile.pRUA, LumaAddr, LumaSize);
		if (status != RM_OK) {
			RMNOTIFY((NULL, status, "Locking OSD buffer at 0x%08lX (0x%08lX bytes)\n", LumaAddr, LumaSize));

			goto exit_with_error;
		}

		luma_buf = RUAMap(pHandle->profile.pRUA, LumaAddr, LumaSize);
		if (!luma_buf) {
			RMNOTIFY((NULL, RM_ERROR, "Error mapping OSD buffer at 0x%08lX (0x%08lX bytes)\n", LumaAddr, LumaSize));
			status = RM_ERROR;

			goto exit_with_error;
		}

		RMMemset(luma_buf, 0, LumaSize);

		pHandle->pSoftCCRenderHandle->LumaSize    = LumaSize;
		pHandle->pSoftCCRenderHandle->pLumaBuffer = luma_buf;

		status = rmfp_internal_set_osd_picture_handler((void*)pHandle,
							       &(pHandle->pSoftCCRenderHandle->OSDSource),
							       &(pHandle->pSoftCCRenderHandle->CurrentOSDPicture));
		if (status != RM_OK) {
			RMNOTIFY((NULL, status, "Cannot set picture\n"));
			goto exit_with_error;
		}
	}

	pHandle->pSoftCCRenderHandle->pSCC     = pSCC;
	pHandle->pSoftCCRenderHandle->UseRMRTK = FALSE;
	pHandle->pSoftCCRenderHandle->CCSize   = 0;
	pHandle->pSoftCCRenderHandle->DTVSize  = 0;

	pHandle->pSoftCCRenderHandle->pSurface = (struct RMFontRenderSurface *)RMMalloc(sizeof(struct RMFontRenderSurface));
	if (!pHandle->pSoftCCRenderHandle->pSurface) {
		status = RM_FATALOUTOFMEMORY;
		RMNOTIFY((NULL, status, "Not enough memory\n"));
		goto exit_with_error;
	}

	pHandle->pSoftCCRenderHandle->pSurface->Width      = OSDProfile.Profile.Width;
	pHandle->pSoftCCRenderHandle->pSurface->Height     = OSDProfile.Profile.Height;

	pHandle->pSoftCCRenderHandle->pSurface->TotalWidth = OSDProfile.Profile.Width;

	pHandle->pSoftCCRenderHandle->pSurface->pPixelBuffer = pHandle->pSoftCCRenderHandle->pLumaBuffer;

	if (SCCProfile.CCFormat == rmscc_eia_608) {
		pHandle->pSoftCCRenderHandle->pSurface->ColorDepth = 8;
		pHandle->pSoftCCRenderHandle->pSurface->pPalette = (RMuint32 *)&(pHandle->pSoftCCRenderHandle->CCPalette);
	}
	else if (SCCProfile.CCFormat == rmscc_eia_708) {
		pHandle->pSoftCCRenderHandle->pSurface->ColorDepth = 32;
		pHandle->pSoftCCRenderHandle->pSurface->pPalette = NULL;
	}


#if FORCE_TRUECOLOR_MODE
	pHandle->pSoftCCRenderHandle->pSurface->ColorDepth = 32;
	pHandle->pSoftCCRenderHandle->pSurface->pPalette = NULL;
#endif

	pHandle->pSoftCCRenderHandle->DisplayDirty = FALSE;
	pHandle->pSoftCCRenderHandle->NewPicture   = FALSE;

	/*
	Note that this will perform a draw_rectangle, that's why we do it
	at the end so that pSoftCCRenderHandle is already setup
	*/

	RMSCCReset(pSCC);

	return RM_OK;

exit_with_error:

	rmfp_internal_close_softcc_render(pHandle);

	return status;
}

static RMstatus close_softcc_with_callbacks(struct RMFPHandle *pHandle)
{
	RMstatus status;

	RMDBGLOG((LOCALDBG, "close_softcc_with_callbacks(%p)\n", pHandle));

	ASSERT_NULL_POINTER(pHandle);

	if (!pHandle->profile.pFontRenderHandle)
		RMNOTIFY((NULL, RM_FATALINVALIDPOINTER, "Invalid RMFontRender handle\n"));


	if (pHandle->pSoftCCRenderHandle) {

		if (pHandle->pSoftCCRenderHandle->pSCC) {

			RMDBGLOG((LOCALDBG, "close SCC\n"));
			status = RMSCCClose(pHandle->pSoftCCRenderHandle->pSCC);
			if (status != RM_OK)
				RMNOTIFY((NULL, status, "Cannot close RMSCC\n"));

			pHandle->pSoftCCRenderHandle->pSCC = NULL;
		}

		if (pHandle->pSoftCCRenderHandle->OSDSource.pHandler) {

			RMDBGLOG((LOCALDBG, "close soft CC OSD\n"));

			if (pHandle->pSoftCCRenderHandle->pLumaBuffer)
			{
				RUAUnMap(pHandle->profile.pRUA,
					 pHandle->pSoftCCRenderHandle->pLumaBuffer,
					 pHandle->pSoftCCRenderHandle->LumaSize);
				pHandle->pSoftCCRenderHandle->pLumaBuffer = NULL;
			}

			if (pHandle->pSoftCCRenderHandle->CurrentOSDPicture.LumaBufferAddress) {
				status = RUAUnLock(pHandle->profile.pRUA,
						   pHandle->pSoftCCRenderHandle->CurrentOSDPicture.LumaBufferAddress,
						   pHandle->pSoftCCRenderHandle->CurrentOSDPicture.LumaBufferSize);
				if (status != RM_OK)
					RMNOTIFY((NULL, status, "Cannot unlock %p size %lu\n",
						    pHandle->pSoftCCRenderHandle->CurrentOSDPicture.LumaBufferAddress,
						    pHandle->pSoftCCRenderHandle->CurrentOSDPicture.LumaBufferSize));
				pHandle->pSoftCCRenderHandle->CurrentOSDPicture.LumaBufferAddress = NULL;
			}

			rmfp_internal_close_osd_handler((void*)pHandle, &(pHandle->pSoftCCRenderHandle->OSDSource));
		}

		if (pHandle->pSoftCCRenderHandle->pSurface) {
			RMFree(pHandle->pSoftCCRenderHandle->pSurface);
			pHandle->pSoftCCRenderHandle->pSurface = NULL;
		}

		RMFree(pHandle->pSoftCCRenderHandle);
		pHandle->pSoftCCRenderHandle = NULL;
	}

	return RM_OK;
}

static RMstatus softcc_get_string_size(void *pContext,
				       RMuint8 *pChars,
				       RMuint32 CharSize,
				       RMuint32 *pWidth,
				       RMuint32 *pHeight)
{
	struct RMFPHandle *pHandle = NULL;
	struct RMFontRenderHandle *pFontRenderHandle = NULL;
	struct RMFPSoftCCRenderHandle *pSoftCCRenderHandle = NULL;
	struct RMFontRenderStringStyle Style = { 0, };
	RMuint32 CharsCount;
	RMuint32 Width, Height;

	RMstatus status;


	RMDBGLOG((LOCALDBG, "softcc_get_string_size()\n"));
	RMDBGLOG((LOCALDBG, "string '%s' size %lu\n", pChars, CharSize));

	ASSERT_NULL_POINTER(pContext);
	ASSERT_NULL_POINTER(pChars);


	pHandle             = (struct RMFPHandle *)pContext;
	pSoftCCRenderHandle = pHandle->pSoftCCRenderHandle;
	pFontRenderHandle   = pHandle->profile.pFontRenderHandle;


	ASSERT_NULL_POINTER(pSoftCCRenderHandle);
	ASSERT_NULL_POINTER(pFontRenderHandle);


	CharsCount = RMasciiLength((RMascii*)pChars);


	// set style
	Style.Encoding = RMFontRenderCharEnconding_Latin;

	Style.pFontName = pSoftCCRenderHandle->pFontName;
	Style.EnableKerning = FALSE;
	Style.Style = RMFontRenderFontStyle_Normal;

	Style.FontHeight = CharSize;

	Style.FillColor = 0xFFFFFFFF;

#if DRAW_SHADOW_AND_BORDER
	Style.DrawBorder  = TRUE;
	Style.BorderSize  = 2;
	Style.BorderColor = 0xFF000000;

	Style.DrawShadow  = TRUE;
	Style.ShadowSize  = 4;
	Style.ShadowColor = 0x80101010;
#endif

	RMDBGLOG((DISABLE, "Font '%s'\n", Style.pFontName));


	status = RMFontRenderComputeCharsSize(pFontRenderHandle,
					      pChars,
					      CharsCount,
					      &Style,
					      &Width,
					      &Height);

	if (status != RM_OK)
		RMNOTIFY((NULL, status, "couldn't get chars size!\n"));


	RMDBGLOG((LOCALDBG, "Before correction: Width %ld Height %ld\n", Width, Height));

	// apply hacks
	APPLY_HEIGHT_CORRECTION(Height);

	if (pHandle->pSoftCCRenderHandle->CCType == RMFPCloseCaptionType_EIA608)
		APPLY_WIDTH_CORRECTION(Width);



	RMDBGLOG((LOCALDBG, "After correction: Width %ld Height %ld\n", Width, Height));

	if (pWidth)
		*pWidth = Width;

	if (pHeight)
		*pHeight = Height;



	if (pSoftCCRenderHandle->PenSizes < MAX_PEN_SIZES) {
		struct RMFPSoftCCRenderPenSize *pPenSize = &(pSoftCCRenderHandle->PenSizeList[pSoftCCRenderHandle->PenSizes]);

		pPenSize->CharSize = CharSize;
		pPenSize->Width    = Width;
		pPenSize->Height   = Height;

		pSoftCCRenderHandle->PenSizes++;
	}
	else
		RMDBGLOG((ENABLE, "Cannot track this size\n"));


	return status;
}

static RMstatus softcc_draw_string(void *pContext,
				   RMuint32 PosX,
				   RMuint32 PosY,
				   RMuint8 *pChars,
				   RMuint32 FGColor,
				   RMuint32 BGColor,
				   RMuint32 CharSize,
				   RMuint32 *pWidth,
				   RMuint32 *pHeight)
{
	struct RMFPHandle *pHandle = NULL;
	struct RMFontRenderHandle *pFontRenderHandle = NULL;
	struct RMFPSoftCCRenderHandle *pSoftCCRenderHandle = NULL;

	struct RMFontRenderStringStyle Style = { 0, };
	struct RMFontRenderPoint StartPoint = { 0, };
	struct RMFontRenderBox Box = { 0, };
	struct RMFontRenderBox OutBox = { 0, };

	struct RMFontRenderGlyphChain *pGlyphChain = NULL;

	RMuint32 CharsCount;

	RMuint32 Width;
	RMuint32 Height;

	RMuint32 AdjustedWidth;
	RMuint32 AdjustedHeight;

	RMstatus status = RM_OK;

	RMuint32 i;


	RMDBGLOG((LOCALDBG, "softcc_draw_string() [%lu, %lu] [0x%lx, 0x%lx, %lu] '%s'\n",
		  PosX,
		  PosY,
		  FGColor,
		  BGColor,
		  CharSize,
		  pChars));


	ASSERT_NULL_POINTER(pContext);
	ASSERT_NULL_POINTER(pChars);


	pHandle = (struct RMFPHandle *)pContext;
	pSoftCCRenderHandle = pHandle->pSoftCCRenderHandle;
	pFontRenderHandle = pHandle->profile.pFontRenderHandle;


	ASSERT_NULL_POINTER(pSoftCCRenderHandle);
	ASSERT_NULL_POINTER(pFontRenderHandle);


	if (pSoftCCRenderHandle->pSurface)
		RMDBGLOG((LOCALDBG, "using luma buffer %p\n", pSoftCCRenderHandle->pSurface->pPixelBuffer));

	pSoftCCRenderHandle->DisplayDirty = TRUE;


	CharsCount = RMasciiLength((RMascii*)pChars);

	// set style
	Style.Encoding = RMFontRenderCharEnconding_Latin;

	Style.pFontName     = pSoftCCRenderHandle->pFontName;
	Style.EnableKerning = FALSE;
	Style.Style         = RMFontRenderFontStyle_Normal;

	Style.FontHeight = CharSize;

	Style.FillColor = FGColor;

#if DRAW_SHADOW_AND_BORDER
	Style.DrawBorder  = TRUE;
	Style.BorderSize  = 2;
	Style.BorderColor = 0xFF000000;

	Style.DrawShadow  = TRUE;
	Style.ShadowSize  = 4;
	Style.ShadowColor = 0x80101010;
#endif

	RMDBGLOG((DISABLE, "Font '%s'\n", Style.pFontName));



	AdjustedWidth  = 0;
	AdjustedHeight = 0;

	for (i = 0; i < MAX_PEN_SIZES; i++) {
		struct RMFPSoftCCRenderPenSize *pPenSize = &(pSoftCCRenderHandle->PenSizeList[i]);

		if (pPenSize->CharSize == CharSize) {
			AdjustedWidth  = pPenSize->Width;
			AdjustedHeight = pPenSize->Height;
			break;
		}
	}


	PosX += OFFSET_X;
	PosY += OFFSET_Y;

	// start
	StartPoint.X = PosX;
	StartPoint.Y = PosY + AdjustedHeight;

	// background rectangle
	Box.X = PosX;
	Box.Y = PosY;



	for (i = 0; i < CharsCount; i++) {

		status = RMFontRenderCreateGlyphChain(pFontRenderHandle,
						      &(pChars[i]),
						      1,
						      &Style,
						      &Width,
						      &Height,
						      &pGlyphChain,
						      NULL);

		if (status == RM_NOT_FOUND) {
			RMDBGLOG((ENABLE, "Some chars in the string cannot be rendered with the selected font\n"));
			goto exit;
		}
		else if (status != RM_OK) {
			RMDBGLOG((ENABLE, "Couldn't create glyph chain\n"));
			goto exit;
		}


		APPLY_HEIGHT_CORRECTION(Height);

		APPLY_WIDTH_CORRECTION(Width);


		if (ENABLE_BACKGROUND_RECTANGLE) {

			RMuint32 Color;

			Box.Width  = AdjustedWidth + 5; // otherwise the shadow will be outside the rectangle
			Box.Height = AdjustedHeight;

			Color = 0xFF000000;

			RMFontRenderDrawBox(pFontRenderHandle,
					    pSoftCCRenderHandle->pSurface,
					    &Box,
					    Color);

			Box.X += AdjustedWidth;
		}



		status = RMFontRenderDrawGlyphChain(pFontRenderHandle,
						    pSoftCCRenderHandle->pSurface,
						    &StartPoint,
						    pGlyphChain,
						    &OutBox);


		if (status != RM_OK)
			RMNOTIFY((NULL, status, "Couldn't draw chars!\n"));
		else {

			StartPoint.X += AdjustedWidth;

		}

		if (pGlyphChain) {
			RMFontRenderDestroyGlyphChain(pFontRenderHandle, pGlyphChain);
			pGlyphChain = NULL;
		}
	}

 exit:

	if (pWidth)
		*pWidth = StartPoint.X - AdjustedWidth;

	if (pHeight)
		*pHeight = AdjustedHeight;

	RMDBGLOG((LOCALDBG, "OutBox [%lu, %lu] [%lu, %lu]\n",
		  OutBox.X,
		  OutBox.Y,
		  OutBox.Width,
		  OutBox.Height));

	RMDBGLOG((LOCALDBG, "Draw inside [%lu, %lu] [%lu, %lu]\n",
		  PosX,
		  PosY + AdjustedHeight,
		  StartPoint.X - AdjustedWidth,
		  AdjustedHeight));


	if (pGlyphChain)
		RMFontRenderDestroyGlyphChain(pFontRenderHandle, pGlyphChain);

	return status;
}


static RMstatus softcc_draw_rect(void *pContext,
				 RMuint32 PosX,
				 RMuint32 PosY,
				 RMuint32 Width,
				 RMuint32 Height,
				 RMuint32 Color)
{

	struct RMFPHandle *pHandle = NULL;
	struct RMFontRenderHandle *pFontRenderHandle = NULL;
	struct RMFPSoftCCRenderHandle *pSoftCCRenderHandle = NULL;
	struct RMFontRenderBox Box = { 0, };
	RMstatus status;


	RMDBGLOG((LOCALDBG, "softcc_draw_rect() [%lu, %lu] [%lu, %lu] Color 0x%lx\n",
		  PosX,
		  PosY,
		  Width,
		  Height,
		  Color));


	ASSERT_NULL_POINTER(pContext);

	pHandle = (struct RMFPHandle *)pContext;
	pSoftCCRenderHandle = pHandle->pSoftCCRenderHandle;
	pFontRenderHandle = pHandle->profile.pFontRenderHandle;

	ASSERT_NULL_POINTER(pSoftCCRenderHandle);
	ASSERT_NULL_POINTER(pFontRenderHandle);


	if (pSoftCCRenderHandle->pSurface)
		RMDBGLOG((LOCALDBG, "using luma buffer %p\n", pSoftCCRenderHandle->pSurface->pPixelBuffer));


	Box.X      = PosX;
	Box.Y      = PosY;
	Box.Width  = Width;
	Box.Height = Height;

#if 0
	if (Width != 640)
		Color = 0xFFFF0000;
	else
		Color = 0xFF0000FF;
#endif

	status = RMFontRenderDrawBox(pFontRenderHandle,
				     pSoftCCRenderHandle->pSurface,
				     &Box,
				     Color);


	return status;
}


static RMstatus softcc_prepare_to_draw(void *pContext)
{
	struct RMFPHandle *pHandle = NULL;
	RMstatus status = RM_OK;

	RMDBGLOG((LOCALDBG, "softcc_prepare_to_draw(%p)\n", pContext));


	ASSERT_NULL_POINTER(pContext);

	pHandle = (struct RMFPHandle *)pContext;

	if (!ENABLE_DOUBLE_BUFFERED_RENDER)
		return RM_OK;

	if (!pHandle->pSoftCCRenderHandle->DisplayDirty) {
		RMDBGLOG((DISABLE, "display is not dirty\n"));
		return RM_OK;
	}

	if (pHandle->pSoftCCRenderHandle->NewPicture) {
		RMDBGLOG((DISABLE, "already did this\n"));
		return RM_OK;
	}


	if (pHandle->pSoftCCRenderHandle->OSDSource.pHandler) {
		RMuint32 LumaAddr, LumaSize;
		RMuint8 *luma_buf;


		RMDBGLOG((LOCALDBG, "unmap/unlock current picture\n"));

		if (pHandle->pSoftCCRenderHandle->pLumaBuffer)
			RUAUnMap(pHandle->profile.pRUA,
				 pHandle->pSoftCCRenderHandle->pLumaBuffer,
				 pHandle->pSoftCCRenderHandle->LumaSize);

		if (pHandle->pSoftCCRenderHandle->CurrentOSDPicture.LumaBufferAddress) {
			status = RUAUnLock(pHandle->profile.pRUA,
					   pHandle->pSoftCCRenderHandle->CurrentOSDPicture.LumaBufferAddress,
					   pHandle->pSoftCCRenderHandle->CurrentOSDPicture.LumaBufferSize);

			if (status != RM_OK)
				RMNOTIFY((NULL, status, "Cannot unlock %p size %lu\n",
					    pHandle->pSoftCCRenderHandle->CurrentOSDPicture.LumaBufferAddress,
					    pHandle->pSoftCCRenderHandle->CurrentOSDPicture.LumaBufferSize));
		}



		RMDBGLOG((LOCALDBG, "get a new picture\n"));

		status = rmfp_internal_get_osd_picture_handler((void*)pHandle,
							       &(pHandle->pSoftCCRenderHandle->OSDSource),
							       &(pHandle->pSoftCCRenderHandle->CurrentOSDPicture));
		if (status != RM_OK) {
			RMNOTIFY((NULL, status, "Couldn't get picture\n"));

			goto exit_with_error;
		}


		LumaAddr = pHandle->pSoftCCRenderHandle->CurrentOSDPicture.LumaBufferAddress;
		LumaSize = pHandle->pSoftCCRenderHandle->CurrentOSDPicture.LumaBufferSize;

		pHandle->pSoftCCRenderHandle->CurrentOSDPicture.pPalette = (RMuint32*)pHandle->pSoftCCRenderHandle->pSurface->pPalette;

		status = RUALock(pHandle->profile.pRUA, LumaAddr, LumaSize);
		if (status != RM_OK) {
			RMNOTIFY((NULL, status, "Locking OSD buffer at 0x%08lX (0x%08lX bytes)\n", LumaAddr, LumaSize));

			goto exit_with_error;
		}

		luma_buf = RUAMap(pHandle->profile.pRUA, LumaAddr, LumaSize);
		if (!luma_buf) {
			RMNOTIFY((NULL, RM_ERROR, "Error mapping OSD buffer at 0x%08lX (0x%08lX bytes)\n", LumaAddr, LumaSize));
			status = RM_ERROR;

			goto exit_with_error;
		}

		RMMemset(luma_buf, 0, LumaSize);

		pHandle->pSoftCCRenderHandle->LumaSize    = LumaSize;
		pHandle->pSoftCCRenderHandle->pLumaBuffer = luma_buf;

		pHandle->pSoftCCRenderHandle->pSurface->pPixelBuffer = pHandle->pSoftCCRenderHandle->pLumaBuffer;

	}
	else {
		RMDBGLOG((ENABLE, "OSD not opened yet\n"));
		return RM_OK;
	}

	pHandle->pSoftCCRenderHandle->NewPicture = TRUE;

	return RM_OK;


exit_with_error:

	rmfp_internal_close_softcc_render(pHandle);

	return status;

}

static RMstatus softcc_draw_finished(void *pContext)
{
	struct RMFPHandle *pHandle = NULL;
	RMstatus status = RM_OK;

	RMDBGLOG((LOCALDBG, "softcc_draw_finished(%p)\n", pContext));

	ASSERT_NULL_POINTER(pContext);

	pHandle = (struct RMFPHandle *)pContext;

	if (!ENABLE_DOUBLE_BUFFERED_RENDER)
		return RM_OK;

	if (!pHandle->pSoftCCRenderHandle->NewPicture) {
		RMDBGLOG((DISABLE, "there is no new picture to set\n"));
		return RM_OK;
	}

	// set the new picture


	status = rmfp_internal_set_osd_picture_handler((void*)pHandle,
						       &(pHandle->pSoftCCRenderHandle->OSDSource),
						       &(pHandle->pSoftCCRenderHandle->CurrentOSDPicture));
	if (status != RM_OK) {
		RMNOTIFY((NULL, status, "Cannot set picture\n"));
		goto exit_with_error;
	}

	pHandle->pSoftCCRenderHandle->NewPicture = FALSE;

	return RM_OK;


exit_with_error:

	rmfp_internal_close_softcc_render(pHandle);

	return status;

}
