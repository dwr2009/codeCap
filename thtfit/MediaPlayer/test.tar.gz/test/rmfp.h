/*****************************************
 Copyright 2001-2007
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   rmfp.h
  @brief


  @author Sebastian Frias Feltrer
  @date   2007-08-07
*/


#ifndef __RMFP_H__
#define __RMFP_H__

#include <rmdef/rmdef.h>

#include <rmcore/include/rmcore.h>
#include <rmlibcw/include/rmlibcw.h>

// provides hardware access
#include <rua/include/rua.h>
#include <dcc/include/dcc.h>


#include <rmwmdrm/include/rmwmdrm.h>
#include <rmdtcpapi/include/rmdtcpapi.h>
#include <rmfontrender/include/rmfontrender.h>


// because this .h might be included in c++ code
RM_EXTERN_C_BLOCKSTART

#ifndef RM_TYPEDEF_FUNTION_PTR // guard against multiple definitions
#define RM_TYPEDEF_FUNCTION_PTR(return_value, name, params...) typedef return_value (*name)(params)
#endif

/*
 * Opaque handle of RMFP
 */
struct RMFPHandle;


/*

  Supported container formats:

  - ASF
  - MP4/MOV
  - MKV
  - M2T, M2P, VOB
  - RIFF (AVI and WAVE)
  - JPEG (HW and SW decoder)
  - PNG
  - GIF
  - BMP

  Supported audio codecs:

  - AC3
  - ADIF
  - ADTS
  - BDLPCM
  - DTS
  - LPCM
  - PCM
  - ADPCM uLaw
  - MPEG Audio
  - Vorbis
  - WMA
  - WMAPro
  - WMATS

  Supported video codecs:

  - MPEG1/2 Video
  - DiVX3
  - MPEG4 (DiVX4/5, XViD)
  - WMV9
  - VC1
  - H264
  - AVS

  Supported subtitles formats:

  - (VOB)SUB/IDX : External. Internal (MKV only)
  - ASS/SSA : External. Internal (MKV only)
  - SRT : External. Internal (MKV only)
  - SUB (microdvd) : External
  - NeroSPU : Internal (MP4 only)
  - TeletextSubs : Internal (M2T only)
  - DVBSubs : Internal (M2T only)


  Supported codecs by container format:

  - ASF
    Video: MPEG2, DiVX3, WMV9, VC1
    Audio: MPEG, WMA, WMAPro
    Subtitles: All external types

  - MP4/MOV
    Video: MPEG4, H264
    Audio: ADTS, AC3 (Nero only), ADPCM uLaw, MPEG-II audio layer 3 (mp3)
    Subtitles: All external types plus NeroSPU

  - MKV
    Video: MPEG2, MPEG4, H264, DiVX3, WMV9, VC1
    Audio: AC3, DTS, LPCM, ADTS
    Subtitles: All compatible types external and embedded.

  - M2T, M2P, VOB
    Video: MPEG2, MPEG4, H264, VC1
    Audio: ADTS, AC3, DTS, BDLPCM, MPEG, WMATS
    Subtitles: All external types plus TeletextSubs and DVBSubs

  - RIFF
    Video (AVI only): MPEG2, MPEG4, DiVX3, H264, VC1, WMV9, MJPEG
    Audio (AVI and WAVE): ADTS, AC3, DTS, MPEG, PCM, WMA
    Subtitles: All external types

  - Elementary
    Video: MPEG1/2, MPEG4, H264, VC1, MJPEG
    Audio: AC3, ADTS, ADIF, DTS, PCM, LPCM, MPEG Audio, Vorbis


 */



/*

  RMFPHandle is a struct detailing the config for the playback. This structure contains information
  like:

  - streams to play: the application will pass RMFPDetectedType along with a description of what streams
    to play, like "select stream 1 and 3". Libplayback will use RMFPDetectedType (which might have been
    modified/filled by the application) to translate "stream 1" into "pid m, video, h264", and so on.

  - resource allocation/configuration callbacks: if the callbacks are implemented, then they will be called

  - command and notification callbacks: if they are implemented they'll allow the application to control
    the playback by:
    - sending commands, OR
    - implementing rmfp_get_command callback

    Also, if the notification callbacks are implemented the application will be able to get notified about:
      - playback_start (just before playback start a notification will be issued)
      - EOS
      - command_received
      - warning: for example, the video codec is not supported but audio does, the playback will continue with
        audio only. Of course since the application will be notified of 'playback_start', it could decide to
        stop playback.
      - error: some types of errors, DRM protected file, etc. Fatal errors will trigger rfp_play_handle return
        with RM_ERROR_type
*/



/****************************************************************************************************************/
/****************************************************************************************************************/
/******************************************* RESOURCES MANAGEMENT ***********************************************/
/****************************************************************************************************************/
/****************************************************************************************************************/

/*
 * libplay will ask to rmfp for resources, a video decoder for a certain profile for example. Then
 * rmfp will query the hwlib in order to obtain what resources are required for that profile, it will construct
 * a RMFPVideoResourcesProfile and if the callback 'video_resources_callback' has been defined, the profile
 * will be presented to the application which will be free to modify the profile according to it's memory map.
 * After the callback (wheter it was called or not) the profile will be examined and every resource not specified
 * (that is, if *_address is NULL) then the corresponding DCCMalloc will be performed and a video decoder using
 * those resources will be retourned to libplay.
 * The same goes for audio and other resources.
 *
 * The callbacks are always called with a common parameter common_context which is in fact the Opaque RMFPHandle
 *
 * Each profile has a version which will changes with now releases of the library
 */

/***********************************************************
 * Video resources
 ***********************************************************/

struct RMFPVideoResourcesProfile {

	RMuint32 Version;

	/* READ/WRITE parameters */
	RMuint32 dram;				// which memory controller to use for allocation, default 0

	RMuint32 unprotected_memory_address;	// Address for unprotected memory
	RMuint32 unprotected_memory_size;	// Corresponding size to allocate

	RMuint32 engine_index;			// what video engine to use, default 0
	RMuint32 decoder_index;			// what video decoder to use, default 0

	RMuint32 scheduler_memory_address;	// Address for scheduler memory
	RMuint32 scheduler_memory_size;		// Corresponding size to allocate

	RMuint32 shared_memory_address;		// Address for shared memory
	RMuint32 shared_memory_size;		// Corresponding size to allocate

	RMuint32 picture_memory_address;	// Address for pictures
	RMuint32 picture_memory_size;		// Corresponding size to allocate

	RMuint32 bitstream_memory_address;	// Address for bitstream
	RMuint32 bitstream_memory_size;		// Corresponding size to allocate

	RMuint32 postprocessing_memory_address;	// Address for Post Processing memory
	RMuint32 postprocessing_memory_size;	// Corresponding size to allocate

	/* READ ONLY parameters */
	RMuint32 STC_index;			// What STC to use, default 0
};

RM_TYPEDEF_FUNCTION_PTR(RMstatus,
			rmfp_video_resources_callback_type,
			void *pContext,
			struct RMFPVideoResourcesProfile *pProfile);


/***********************************************************
 * Picture Transform resources
 ***********************************************************/

struct RMFPPictureTransformResourcesProfile {

	RMuint32 Version;

	/* READ/WRITE parameters */
	RMuint32 dram;				// which memory controller to use for allocation, default 0

	RMuint32 data_memory_address;		// Address for data memory
	RMuint32 data_memory_size;		// Corresponding size to allocate

	RMuint32 interface_memory_address;	// Address for interface memory
	RMuint32 interface_memory_size;		// Corresponding size to allocate

	RMuint32 engine_index;			// what video engine to use, default 0
	RMuint32 decoder_index;			// what video decoder to use, default 0

	/* READ ONLY parameters */
	RMuint32 STC_index;			// What STC to use, default 0
};

RM_TYPEDEF_FUNCTION_PTR(RMstatus,
			rmfp_picture_transform_resources_callback_type,
			void *pContext,
			struct RMFPPictureTransformResourcesProfile *pProfile);

/***********************************************************
 * PPF resources
 ***********************************************************/

struct RMFPPPFResourcesProfile {

	RMuint32 Version;

	/* READ/WRITE parameters */
	RMuint32 dram;				// which memory controller to use for allocation, default 0

	RMuint32 engine_memory_address;		// Address for gfx engine memory
	RMuint32 engine_memory_size;		// Corresponding size to allocate

	RMuint32 input_memory_address;		// Address for the input surface memory
	RMuint32 input_memory_size;		// Corresponding size to allocate

	RMuint32 output_memory_address;		// Address for the output surface memory
	RMuint32 output_memory_size;		// Corresponding size to allocate

	RMuint32 data_memory_address;		// Address for data memory
	RMuint32 data_memory_size;		// Corresponding size to allocate

	RMuint32 engine_index;			// what video engine to use, default 0
	RMuint32 decoder_index;			// what video decoder to use, default 0

	/* READ ONLY parameters */
	RMuint32 STC_index;			// What STC to use, default 0
};

RM_TYPEDEF_FUNCTION_PTR(RMstatus,
			rmfp_ppf_resources_callback_type,
			void *pContext,
			struct RMFPPPFResourcesProfile *pProfile);

/***********************************************************
 * Audio resources
 ***********************************************************/

struct RMFPMultipleAudioInstancesProfile
{
	RMuint32 Version;

	struct
	{
		/* READ/WRITE parameters */
		RMuint32 engine_index;			// what audio engine to use
		RMuint32 decoder_index;			// what audio decoder to use

	} instance[MAX_AUDIO_DECODER_INSTANCES];

	/* READ ONLY parameters */
	RMuint32 number_of_instances;			// Number of decoder instances: CANNOT BE CHANGED
};

struct RMFPMultipleAudioResourcesProfile
{
	RMuint32 Version;

	struct
	{
		/* READ/WRITE parameters */
		RMuint32 dram;				// which memory controller to use for allocation, default 0

		RMuint32 shared_memory_address;		// Address for shared memory
		RMuint32 shared_memory_size;		// Corresponding size to allocate

	} engine[MAX_AUDIO_ENGINE_INSTANCES];

	struct
	{
		/* READ/WRITE parameters */
		RMuint32 dram;				// which memory controller to use for allocation, default 0

		RMuint32 protected_memory_address;	// Address for protected memory
		RMuint32 protected_memory_size;		// Corresponding size to allocate

		RMuint32 unprotected_memory_address;	// Address for unprotected memory
		RMuint32 unprotected_memory_size;	// Corresponding size to allocate

		/* READ ONLY parameters */
		RMuint32 engine_index;			// what audio engine used: this parameters has been set by rmfp_audio_instances_callback_type
		RMuint32 decoder_index;			// what audio decoder to use: this parameters has been set by rmfp_audio_instances_callback_type

	} instance[MAX_AUDIO_DECODER_INSTANCES];

	/* READ ONLY parameters */
	RMuint32 number_of_instances;			// Number of decoder instances: CANNOT BE CHANGED
	RMuint32 number_of_engines;			// Number of engines: CANNOT BE CHANGED

	RMuint32 STC_index;				// What STC to use, default 0

};

/* The following 2 callbacks will be called successively:
 - rmfp_audio_instances_callback_type: to modify the instances engines and decoder indexes
 - rmfp_audio_resources_callback_type: for memory allocation
 */

RM_TYPEDEF_FUNCTION_PTR(RMstatus,
			rmfp_audio_instances_callback_type,
			void *pContext,
			struct RMFPMultipleAudioInstancesProfile *pProfile);

RM_TYPEDEF_FUNCTION_PTR(RMstatus,
			rmfp_audio_resources_callback_type,
			void *pContext,
			struct RMFPMultipleAudioResourcesProfile *pProfile);

/***********************************************************
 * Hardware Demux resources (PSFDEMUX)
 ***********************************************************/

struct RMFPDemuxResourcesProfile {

	RMuint32 Version;

	/* READ/WRITE parameters */
	RMuint32 dram;				// which memory controller to use for allocation, default 0

	RMuint32 protected_memory_address;	// Address for protected memory
	RMuint32 protected_memory_size;		// Corresponding size to allocate

	RMuint32 unprotected_memory_address;	// Address for unprotected memory
	RMuint32 unprotected_memory_size;	// Corresponding size to allocate

	RMuint32 engine_index;			// what demux engine to use, default 0
	RMuint32 task_index;			// what demux task to use, default 0

	RMuint32 STC_index;			// What STC to use, default 0
};

RM_TYPEDEF_FUNCTION_PTR(RMstatus,
			rmfp_demux_resources_callback_type,
			void *pContext,
			struct RMFPDemuxResourcesProfile *pProfile);

/************************************************************************
 * Hardware Demux cipher resources for
 ************************************************************************/

struct RMFPDemuxCipherResourcesProfile {

	RMuint32 Version;

	/* READ ONLY parameters */
	RMuint32 engine_index;			// what demux task will be used (may have been changed by rmfp_demux_resources_callback_type)
	RMuint32 task_index;			// what demux task will be used (may have been changed by rmfp_demux_resources_callback_type)
	RMuint32 demux_task;			// Module ID of the task that will be used

	/* Parameters to be filled by the application, the XTaskModuleId will be the only relevant parameter for the release call */
	RMuint32 XTaskModuleId;			// Module ID of the created Xtask, leave it to NULL for no cipher
	RMuint32 XTaskContext;			// Xtask context
	RMuint32 XTaskInbandFIFOCount;		// Xtask inband fifo count
};

RM_TYPEDEF_FUNCTION_PTR(RMstatus,
			rmfp_demux_cipher_resources_callback_type,
			void *pContext,
			struct RMFPDemuxCipherResourcesProfile *pProfile);

/************************************************************************
 * Hardware Demux output resources (will be called for each demux output)
 ************************************************************************/

struct RMFPDemuxOutputResourcesProfile {

	RMuint32 Version;

	/* READ/WRITE parameters */
	RMuint32 dram;				// which memory controller to use for allocation, default 0

	RMuint32 protected_memory_address;	// Address for protected memory
	RMuint32 protected_memory_size;		// Corresponding size to allocate

	RMuint32 unprotected_memory_address;	// Address for unprotected memory
	RMuint32 unprotected_memory_size;	// Corresponding size to allocate

	/* READ ONLY parameters */
	RMuint32 engine_index;			// what demux engine will be used
	RMuint32 task_index;			// what demux task will be used

	RMuint32 STC_index;			// What STC to use
};

RM_TYPEDEF_FUNCTION_PTR(RMstatus,
			rmfp_demux_output_resources_callback_type,
			void *pContext,
			struct RMFPDemuxOutputResourcesProfile *pProfile);

/***********************************************************
 * SPU resources
 ***********************************************************/

struct RMFPSPUResourcesProfile {

	RMuint32 Version;

	/* READ/WRITE parameters */
	RMuint32 dram;				// which memory controller to use for allocation, default 0

	RMuint32 unprotected_memory_address;	// Address for unprotected memory
	RMuint32 unprotected_memory_size;	// Corresponding size to allocate

	/* READ ONLY parameters */
	RMuint32 engine_index;			// what video engine to use, default 0
	RMuint32 decoder_index;			// what spu decoder to use, default 0

	RMuint32 STC_index;			// What STC to use, default 0
};

RM_TYPEDEF_FUNCTION_PTR(RMstatus,
			rmfp_spu_resources_callback_type,
			void *pContext,
			struct RMFPSPUResourcesProfile *pProfile);




/***********************************************************
 * Closecaption resources
 ***********************************************************/

struct RMFPCCFIFOResourcesProfile {

	RMuint32 Version;

	/* READ/WRITE parameters */
	RMuint32 dram;				// which memory controller to use for allocation, default 0

	RMuint32 unprotected_memory_address;	// Address for unprotected memory
	RMuint32 unprotected_memory_size;	// Corresponding size to allocate

	/* READ ONLY parameters */
	RMuint32 fifo_index;			// Closecaption fifo index

	RMuint32 STC_index;			// What STC to use, default 0
};

RM_TYPEDEF_FUNCTION_PTR(RMstatus,
			rmfp_ccfifo_resources_callback_type,
			void *pContext,
			struct RMFPCCFIFOResourcesProfile *pProfile);


/***********************************************************
 * Teletext resources
 ***********************************************************/

struct RMFPTTXResourcesProfile {

	RMuint32 Version;

	/* READ/WRITE parameters */
	RMuint32 dram;				// which memory controller to use for allocation, default 0

	RMuint32 unprotected_memory_address;	// Address for unprotected memory
	RMuint32 unprotected_memory_size;	// Corresponding size to allocate

	/* READ ONLY parameters */
	RMuint32 STC_index;			// What STC to use, default 0
};

RM_TYPEDEF_FUNCTION_PTR(RMstatus,
			rmfp_teletext_resources_callback_type,
			void *pContext,
			struct RMFPTTXResourcesProfile *pProfile);


/***********************************************************
 * RMWMDRM
 ***********************************************************/


struct RMFPRMWMDRMProfile {

	RMuint32 Version;

	RMuint32 PathToCertificatesMAXSIZE; // DO NOT copy more than this value into 'pPathToCertificates'

	const RMascii *pPathToCertificates;       /* This will point to a 'PathToCertificatesMAXSIZE' size memory zone,
					       you can either set it to NULL or copy at most 'PathToCertificatesMAXSIZE' bytes
					       inside
					    */

	enum RMWMDRM_flags Flags;
	RMuint32 Slot;
	RMbool WithPreload;
	RMint32 FlashSector;
};

struct RMFPRMWMDRMResourcesProfile {

	RMuint32 Version;

	RMuint32 Address;
	RMuint32 Size;
};

RM_TYPEDEF_FUNCTION_PTR(RMstatus,
			rmfp_get_rmwmdrm_profile_callback_type,
			void *pContext,
			enum RMWMDRM_type Type,
			struct RMFPRMWMDRMProfile *pProfile);

RM_TYPEDEF_FUNCTION_PTR(RMstatus,
			rmfp_rmwmdrm_resources_callback_type,
			void *pContext,
			struct RMFPRMWMDRMResourcesProfile *pProfile);

struct RMFPRMWMDRMURLHandle {
	struct RMWMDRMURLHandle *pURLHandle;
};

RM_TYPEDEF_FUNCTION_PTR(RMstatus,
			rmfp_rmwmdrm_url_acquire_license_callback_type,
			void *pContext,
			struct RMFPRMWMDRMURLHandle *pRMWMDRMURLHandle);



/****************************************************************************************************************/
/****************************************************************************************************************/
/********************************************** OTHER CALLBACKS *************************************************/
/****************************************************************************************************************/
/****************************************************************************************************************/

/* * Here is a list of the other available callbacks
 * The pContext is the caller's context pointer
 */


/*

  External handlers

 */

struct RMFPDMAPoolProfile {

	RMuint32 Version;

	/* READ ONLY parameters */
	RMuint32 ModuleID;
	enum RUAPoolDirection Direction;

	/* READ/WRITE parameters */
	RMuint32 BufferCount;
	RMuint32 BufferSize_log2;

};

RM_TYPEDEF_FUNCTION_PTR(RMstatus,
			rmfp_open_dmapool_callback_type,
			void *pContext,
			struct RMFPDMAPoolProfile *pProfile,
			struct RUABufferPool **ppDMAPool);

RM_TYPEDEF_FUNCTION_PTR(RMstatus,
			rmfp_close_dmapool_callback_type,
			void *pContext,
			struct RUABufferPool *pDMAPool);


/***********************************************************
 * Bluray subtitles rendering
 ***********************************************************/


RM_TYPEDEF_FUNCTION_PTR(RMstatus,
			rmfp_open_bdspu_decoder_callback_type,
			void *pContext);
RM_TYPEDEF_FUNCTION_PTR(RMstatus,
			rmfp_close_bdspu_decoder_callback_type,
			void *pContext);
RM_TYPEDEF_FUNCTION_PTR(RMstatus,
			rmfp_send_bdspu_decoder_callback_type,
			void *pContext,
			RMuint8* pBuffer,
			RMuint32 Size);
RM_TYPEDEF_FUNCTION_PTR(RMstatus,
			rmfp_flush_bdspu_decoder_callback_type,
			void *pContext);



struct RMFPOSDProfile {
	RMuint32 Version;

	RMuint32 NumberOfPictures;	// for example: 2 for double buffering

	RMbool ForcedOSDSize;		// If False, osd size can be change in callback (for exemple to use outport size)

	struct DCCOSDProfile Profile;
};


struct RMFPOSDSource {
	struct DCCVideoSource *pSource;
};


RM_TYPEDEF_FUNCTION_PTR(RMstatus,
			rmfp_open_osd_callback_type,
			void *pContext,
			struct RMFPOSDProfile *pOSDProfile,
			struct RMFPOSDSource *pOSDSource);

RM_TYPEDEF_FUNCTION_PTR(RMstatus,
			rmfp_close_osd_callback_type,
			void *pContext,
			struct RMFPOSDSource *pOSDSource);

/***********************************************************
 * RUA Events
 ***********************************************************/

/*
 * The following callback will be called each time a new event has been received
 */


RM_TYPEDEF_FUNCTION_PTR(RMstatus,
			rmfp_notify_event_callback_type,
			void *pContext,
			struct RUAEvent *pEvent);


/*
  when the event is catched by rmlibplay a callback will be called

  It must be clear that ADD/REMOVE events affects performance due to the
  fact that we need to copy the event lists

*/

RMstatus RMFPAddEvents(struct RMFPHandle *pHandle, struct RUAEvent *pEvents, RMuint32 eventCount);
RMstatus RMFPRemoveEvents(struct RMFPHandle *pHandle, struct RUAEvent *pEvents, RMuint32 eventCount);

/***********************************************************
 * Closecaption
 ***********************************************************/

enum RMFPCloseCaptionMode {
	RMFPCloseCaptionMode_Disabled = 12,            // Disable
	RMFPCloseCaptionMode_SendToTV,                 // CloseCaption will be sent to the TV
	RMFPCloseCaptionMode_ShowInOSD,                // CloseCaption will be decoded and shown in OSD without sending to the TV
	RMFPCloseCaptionMode_UseCallback,              // CloseCaption will not be sent to the TV nor decoded, but we'll call the callback
};

enum RMFPCloseCaptionType {
	RMFPCloseCaptionType_EIA608 = 12,
	RMFPCloseCaptionType_EIA708,
};


RM_TYPEDEF_FUNCTION_PTR(RMstatus,
			rmfp_ccfifo_entry_callback_type,
			void *pContext,
			struct CCFifo_CCEntry_type *pCloseCaptionEntry);

/***********************************************************
 * Teletext
 ***********************************************************/

/*
 * The following callback will be called each time a teletext picture must be displayed.
 * If the callback is left unimplemented, the teletext picture will decoded by the TV
 */

RM_TYPEDEF_FUNCTION_PTR(RMstatus,
			rmfp_teletext_entry_callback_type,
			void *pContext,
			struct EMhwlibTTXPicture *pTTXPicture);


enum RMFPTeletextMode {

	RMFPTeletextMode_Disabled = 42,               // Disable
	RMFPTeletextMode_SendToTV,                    // Teletext will be sent to the TV
	RMFPTeletextMode_ShowInOSD                    // Teletext will be decoded and shown in OSD without sending to the TV
};


/***********************************************************
 * Route
 ***********************************************************/

/*
 * This callback must return the route to be used
 * The main one will be used if the callback is not implemented
 */

enum RMFPRouteType {

	RMFPRoute_Main = 125,
	RMFPRoute_Secondary,
	RMFPRoute_ColorBars
};

struct RMFPRoute {
	enum RMFPRouteType route;
};

RM_TYPEDEF_FUNCTION_PTR(RMstatus,
			rmfp_get_route_callback_type,
			void *pContext,
			struct RMFPRoute *pRoute);

/***********************************************************
 * Surface
 ***********************************************************/

/*
 * The following callback must connect the surface to a scaler
 * and return a table of events
 */

#define RMFP_EVENT_INDEX_DISPLAY_EVENT	0
#define RMFP_EVENT_INDEX_EOS		1
#define RMFP_EVENT_INDEX_NEW_PICTURE	2
#define RMFP_NB_DISPLAY_EVENTS		3

struct RMFPSurfaceProfile {

	RMuint32 Version;

	struct EMhwlibSurface *surface;
};

struct RMFPSurfaceEventsSource {
	struct RUAEvent event[RMFP_NB_DISPLAY_EVENTS];
};

RM_TYPEDEF_FUNCTION_PTR(RMstatus,
			rmfp_get_surface_events_callback_type,
			void *pContext,
			struct RMFPSurfaceProfile *pSurfaceProfile,
			struct RMFPSurfaceEventsSource *pSurfaceEventsSource);

RM_TYPEDEF_FUNCTION_PTR(RMstatus,
			rmfp_disconnect_surface_callback_type,
			void *pContext,
			RMuint32 surface);

/***********************************************************
 * Outports
 ***********************************************************/

/*
 * The following  callback  will signal to the application that it is safe to apply the audio options
 * through "set_audio_outport" (the audio equivalent for set_outports)

 **********************************************
 NOT WORKING YET: WILL PROBABLY BECOME OBSOLETE
 **********************************************

 */

RM_TYPEDEF_FUNCTION_PTR(RMstatus,
			rmfp_notify_apply_audio_options_callback_type,
			void *pContext);

/***********************************************************
 * Disk control
 ***********************************************************/

enum RMFPDiskControl_action {
	RMFPDiskControl_action_Sleep = 69,
	RMFPDiskControl_action_Run,
	RMFPDiskControl_action_RunNoWait
};

RM_TYPEDEF_FUNCTION_PTR(RMstatus,
			rmfp_disk_control_callback_type,
			void *pContext,
			enum RMFPDiskControl_action action);

/***********************************************************
 * PAT/PMT callbacks
 ***********************************************************/

struct RMFPPAT {

	RMuint32 Version;

	struct DCCPATInfoType* pContent;
};

struct RMFPPMT {

	RMuint32 Version;

	struct DCCPMTInfoType* pContent;
};

/*
 * The following callback will be called each time a new PAT is detected
 */
RM_TYPEDEF_FUNCTION_PTR(RMstatus,
			rmfp_notify_pat_callback_type,
			void *pContext,
			struct RMFPPAT *pPAT);

/*
 * The following callback will be called each time a new PMT is detected
 */
RM_TYPEDEF_FUNCTION_PTR(RMstatus,
			rmfp_notify_pmt_callback_type,
			void *pContext,
			struct RMFPPMT *pPMT);

/***********************************************************
 * PIDS creation notification callback
 ***********************************************************/

struct RMFPPID {

	RMuint32 Version;

	struct DCCPidEntry *pDCCPidEntry; // handle to the DCC Pid entry
};

/*
 * The following callback will be called each time a new PID is created in the HW demux.
 * This should be used to add ciphers per PID
 */
RM_TYPEDEF_FUNCTION_PTR(RMstatus,
			rmfp_notify_pid_creation_callback_type,
			void *pContext,
			struct RMFPPID *pPID);

/***********************************************************
 * SendData notification callback
 ***********************************************************/

struct RMFPSendData {

	RMuint32 Version;

	RMuint32 byte_counter; // number of bytes already sent
	RMuint32 send_size; // number of bytes to be sent
};

/*
 * The following callback is called before RUASendData.
 * This could be used to insert inband commands.
 * The return value is treated in the same way as the return of RUASendData.
 * While the return value is RM_PENDING the thread remains in loop, without sending the data buffer.
 * If the return value is RM_OK the data buffer is sent.
 * Any other return value is considered as fatal error - quit.
 */
RM_TYPEDEF_FUNCTION_PTR(RMstatus,
			rmfp_notify_send_data_callback_type,
			void *pContext,
			struct RMFPSendData *pSendData);

/***********************************************************
 * Notify playback specific states
 ***********************************************************/

/*
 * The following callback will be called when the playback has started
 */
RM_TYPEDEF_FUNCTION_PTR(RMstatus,
			rmfp_notify_playback_start_callback_type,
			void *pContext);

/*
 * The following callback will be called when the end of the playbacked file is reached
 */
RM_TYPEDEF_FUNCTION_PTR(RMstatus,
			rmfp_notify_playback_EOS_callback_type,
			void *pContext);


/***********************************************************
 * HLS Callback
 ***********************************************************/
RM_TYPEDEF_FUNCTION_PTR(RMstatus,
			rmfp_hls_get_key_callback_type,
			void *pContext,
			RMascii *url,
			RMuint8 *key,
			RMuint32 keylength);


/****************************************************************************************************************/
/****************************************************************************************************************/
/********************************************** EXTERNAL COMMANDS ***********************************************/
/****************************************************************************************************************/
/****************************************************************************************************************/

/*
 * Here, you will find all the structures and callback to command RMFP
 */

/***********************************************************
 * Masks of available commands
 ***********************************************************/

#define RMFP_ENABLE_COMMAND_QUIT			(1<<0)
#define RMFP_ENABLE_COMMAND_PLAY			(1<<1)
#define RMFP_ENABLE_COMMAND_PAUSE			(1<<2)
#define RMFP_ENABLE_COMMAND_RESUME			(1<<3)
#define RMFP_ENABLE_COMMAND_STOP			(1<<4)
#define RMFP_ENABLE_COMMAND_SEEK_TO_TIME		(1<<5)
#define RMFP_ENABLE_COMMAND_SEEK_TO_PERCENTAGE		(1<<6)
#define RMFP_ENABLE_COMMAND_FASTFWD			(1<<7)
#define RMFP_ENABLE_COMMAND_SLOWFWD			(1<<8)
#define RMFP_ENABLE_COMMAND_NEXTPICTURE			(1<<9)
#define RMFP_ENABLE_COMMAND_IFORWARD			(1<<10)
#define RMFP_ENABLE_COMMAND_IBACKWARD			(1<<11)
#define RMFP_ENABLE_COMMAND_SILENTFORWARD		(1<<12)
#define RMFP_ENABLE_COMMAND_SILENTBACKWARD		(1<<13)
#define RMFP_ENABLE_COMMAND_SWITCHVIDEO			(1<<14)
#define RMFP_ENABLE_COMMAND_SWITCHAUDIO			(1<<15)
#define RMFP_ENABLE_COMMAND_SWITCHSPU			(1<<16)
#define RMFP_ENABLE_COMMAND_SWITCHPROGRAM		(1<<17)
#define RMFP_ENABLE_COMMAND_SWITCHMULTICAST		(1<<18)
#define RMFP_ENABLE_COMMAND_DEBUG			(1<<19)
#define RMFP_ENABLE_COMMAND_PRINT_INFORMATION           (1<<20)
#define RMFP_ENABLE_COMMAND_RECONFIGUREOUTPORTS		(1<<21)
#define RMFP_ENABLE_COMMAND_APPLYDELAYTOOUTPUTS         (1<<22)
#define RMFP_ENABLE_COMMAND_SUBS_PARAMETERS		(1<<23)
#define RMFP_ENABLE_COMMAND_PRINT_TELETEXT		(1<<24)
#define RMFP_ENABLE_COMMAND_SWITCHVARIANT		(1<<25)
#define RMFP_ENABLE_COMMAND_SDTPID_ENTRY		(1<<26)
#define RMFP_DISABLE_COMMAND_SDTPID_ENTRY		(1<<27)

/***********************************************************
 * List of available commands
 ***********************************************************/

enum RMFP_Playback_command {
	RMFP_Playback_command_Unknown,
	RMFP_Playback_command_Play = 55,	// Play the file (the 'speed' parameter field will indicate the speed)
	RMFP_Playback_command_Pause,		// Pause the playback
	RMFP_Playback_command_Resume,		// Resume playback from pause (go back to state before pause)
	RMFP_Playback_command_Stop,             // Stop playback and seekback to the start of the file

	RMFP_Playback_command_Seek,		// Seek to the requested time, timecode or percentage

	RMFP_Playback_command_NextPicture,	// Called after a pause, display next picture or Iframe (respect to state before pause)

	RMFP_Playback_command_IForward,		// Play the file in Iframe forward mode (the 'speed' parameter field will indicate the speed)
	RMFP_Playback_command_IBackward,	// Play the file in Iframe bacward mode (the 'speed' parameter field will indicate the speed)

	RMFP_Playback_command_SilentForward,	// Stop everything but the STC that runs forward
	RMFP_Playback_command_SilentBackward,	// Stop everything but the STC that runs backward

	RMFP_Playback_command_Quit,		// Quit playback and go back to RMFP

	RMFP_Playback_command_SwitchVideo,	// Switch video stream (with track ID or PID respect to system type)
	RMFP_Playback_command_SwitchAudio,	// Switch audio stream (with track ID or PID respect to system type)
	RMFP_Playback_command_SwitchSPU,	// Switch subtitles stream (with track ID or PID respect to system type)
	RMFP_Playback_command_SwitchProgram,	// Switch program stream (for demux only)
	RMFP_Playback_command_SwitchMulticast,	// Switch between multicast sources

	RMFP_Playback_command_Debug,		// Debug only

	RMFP_Playback_command_Print_Information,// Print information about stream

	RMFP_Playback_command_Print_Teletext,// Print teletext

	RMFP_Playback_command_ApplyDelayToOutputs, // Apply a delay on outputs
	RMFP_Playback_command_ReconfigureOutports, // Reconfigure outputs

	RMFP_Playback_command_SubsParams,	// Change external subs display delay (positive means later)

	RMFP_Playback_command_SwitchVariant, // Switch variant playlist (for http live streaming)

	RMFP_Playback_command_Play_Iframe,
};

/***********************************************************
 * Commands parameters, enums and structures
 ***********************************************************/

struct RMFPSpeedParameters {
	RMint32 N;				// Speed numerator (+/-)
	RMuint32 M;				// Speed denominator
};

enum RMFP_seek_type {
	RMFP_seek_to_time = 70,
	RMFP_seek_to_percentage,
};

enum RMFP_seek_stop_type {
	RMFP_seek_stop_black_frame,		// Display a black frame after seek
	RMFP_seek_stop_last_frame,		// Display the previous position frame after seek
	RMFP_seek_stop_new_frame,		// Display the new position first frame after seek
};

struct RMFPCommandAfterSeek {
	enum RMFP_Playback_command command;		// Command to execute after a seek (Only Play, IForward, IBackward and Resume are valid)
	struct RMFPSpeedParameters speed;
};

struct RMFPSeekCommandParameters {
	enum RMFP_seek_type type;		// Seek type
	enum RMFP_seek_stop_type stop_type;	// Stop type
	union {
		RMuint32 time;			// Seek time in milliseconds
		RMuint32 percentage;		// Seek percentage of the file
	} to;

	struct RMFPCommandAfterSeek command_after_seek;	// Command to execute after a seek to new frame (default is pause)
};

enum RMFP_stop_type {
	RMFP_stop_type_blackframe = 35,
	RMFP_stop_type_lastframe,
};

struct RMFPStopCommandParameters {
	enum RMFP_stop_type type;
};

struct RMFPSwitchVideoCommandParameters {
	RMint32 stream;				// Stream ID/PID
};

enum RMFP_pause_type {
	RMFP_pause_default = 0,
	RMFP_pause_rebuffering,
};

struct RMFPPauseCommandParameters {
	enum RMFP_pause_type type;
};

/* 
 * ts priority bit position in PID, for M2T only
 * ----------------------------------------------
 * |                    | PID ( 13 bits)        |
 * ----------------------------------------------
 */
#define RMFP_TSPRIORITY_BIT_POSITION_IN_PID 30

struct RMFPSwitchAudioCommandParameters {
	RMint32 stream;				// Stream ID/PID
};

#define RMFP_TEXT_SUBS_FIRST_STREAM	100000

struct RMFPSwitchSPUCommandParameters {
	RMint32 stream;				// Stream ID/PID (-1 to disable, >=RMFP_TEXT_SUBS_FIRST_STREAM for external text subs)
};

struct RMFPSwitchProgramCommandParameters {
	RMint32 stream;				// PID
};

struct RMFPPrintInfoCommandParameters {
	RMuint32 type;				// Info type
	RMuint32 param;				// For future use
};

struct RMFPPrintTxtCommandParameters {
	RMuint32 magazine;				// magazine
	RMuint32 page;				// page
};

struct RMFPDelayCommandParameters {
	RMint32 Video;				// Delays in milliseconds
	RMint32 Audio;				// Delays in milliseconds
};

struct RMFPDebugCommandParameters {
	RMuint32 type;
	RMuint32 param;
};

enum RMFPSubsEncoding {
	RMFPSubsEncoding_Latin = 42,
	RMFPSubsEncoding_UTF8,
};

struct RMFPSubsParamsCommandParameters {

	RMbool ResetToDefault;

	RMbool SetDelay;
	RMint32 Delay_ms;             // in millisec

	RMbool SetFontSize;
	RMuint32 FontSize;

	RMbool SetPosY;
	RMint32 PosY;

	RMbool SetFillColor;
	RMuint32 FillColor;
	RMuint32 FillAlpha;

	RMbool SetBorderColor;
	RMuint32 BorderColor;
	RMuint32 BorderAlpha;

	RMbool SetEncoding;
	enum RMFPSubsEncoding Encoding;
	
	/* Only works with RMFPTextSubs_SUB type */
	RMbool SetSUBFrameRate;
	RMuint32 SubFramerateNumerator;
	RMuint32 SubFramerateDenominator;
};

struct RMFPSwitchVariantCommandParameters {
	RMint32 stream;
};

struct RMFPPlaybackCommand {
	enum RMFP_Playback_command command;
	union {
		struct RMFPSeekCommandParameters seek;
		struct RMFPStopCommandParameters stop;
		struct RMFPSpeedParameters speed;
		struct RMFPSwitchVideoCommandParameters switchVideo;
		struct RMFPSwitchAudioCommandParameters switchAudio;
		struct RMFPSwitchSPUCommandParameters switchSPU;
		struct RMFPSwitchProgramCommandParameters switchProgram;
		struct RMFPDelayCommandParameters outputDelay;
		struct RMFPDebugCommandParameters debug;
		struct RMFPPrintInfoCommandParameters printInfo;
		struct RMFPPrintTxtCommandParameters printTxt;
		struct RMFPSubsParamsCommandParameters SubsParams;
		struct RMFPSwitchVariantCommandParameters switchVariant;
		struct RMFPPauseCommandParameters pause;
	} params;
};

/*
 * The following callback will be called to get new commands from the application
 */
RM_TYPEDEF_FUNCTION_PTR(RMstatus,
			rmfp_get_command_callback_type,
			void *pContext,
			struct RMFPPlaybackCommand *pCommand,
			RMuint32 TimeOutInMicroSeconds);

/*
 * The following callback will be called notify the application of the available commands
 * (using the masks defined at the beginning of the section).
 * NOTE: if this callack is not implemented, commands must be sent using the
 * RMFPSendCommand() function described below.
 */
RM_TYPEDEF_FUNCTION_PTR(RMstatus,
			rmfp_notify_available_commands_callback_type,
			void *pContext,
			RMuint32 mask);

/*
 * Command global status
 */
struct RMFPCommandStatus {
	struct RMFPPlaybackCommand lastCommand;		// Last executed command
	RMstatus lastCommandStatus;			// Last executed command return code
};

/*
 * The following callback will be called to give the command execution status
 */
RM_TYPEDEF_FUNCTION_PTR(RMstatus,
			rmfp_notify_command_status_callback_type,
			void *pContext,
			struct RMFPCommandStatus *pStatus);

/*
 * Send a command
*/
RMstatus RMFPSendCommand(struct RMFPHandle *pHandle,
			 struct RMFPPlaybackCommand *pCommand);

/*
 * Wait for the completion of the sent command
*/
RMstatus RMFPWaitForCommandCompletion(struct RMFPHandle *pHandle,
				      struct RMFPCommandStatus *pCommandStatus,
				      RMuint32 timeout_ms);

/****************************************************************************************************************/
/****************************************************************************************************************/
/************************************************ PLAYBACK STATE *************************************************/
/****************************************************************************************************************/
/****************************************************************************************************************/

/*
 * List of states
 */
enum RMFP_Playback_state {
	RMFP_Playback_state_Playing = 56,
	RMFP_Playback_state_Paused,
	RMFP_Playback_state_Stopped,

	RMFP_Playback_state_NextPic,

	RMFP_Playback_state_IForward,
	RMFP_Playback_state_IBackward,

	RMFP_Playback_state_IPaused,
	RMFP_Playback_state_INextPic,

	RMFP_Playback_state_SilentForward,
	RMFP_Playback_state_SilentBackward,

	RMFP_Playback_state_Buffering,
	RMFP_Playback_state_Quitting,

	RMFP_Playback_state_PlayingIFrame,
};

/*
 * State structure
 */
struct RMFPPlaybackState {
	enum RMFP_Playback_state state;
	struct RMFPSpeedParameters speed;
};

/*
 * Playback global status
 */
struct RMFPPlaybackStatus {
	struct RMFPPlaybackState playbackState;		// Current playback state
};

/*
 * The following callback will be called when the playback status has changed
 */
RM_TYPEDEF_FUNCTION_PTR(RMstatus,
			rmfp_notify_playback_status_callback_type,
			void *pContext,
			struct RMFPPlaybackStatus *pStatus);




/****************************************************************************************************************/
/****************************************************************************************************************/
/********************************************* RMFP PARAMETERS **************************************************/
/****************************************************************************************************************/
/****************************************************************************************************************/

/*
  Note that RMFP*Options are provided for some backward compatibility debug options but that
  since there might not be any more 'play_*' applications but just Mono, only a subset of
  libsamples1 cmdline options is here.
*/


/***********************************************************
 * Video options
 ***********************************************************/
struct RMFPVideoOptions {

	RMuint32 EngineIndex;					// Video engine (DSP) to be used
	RMuint32 DecoderIndex;					// Video decoder (DSP) to be used

	RMuint32 VideoScalerID;					// Scaler to use to display the video. WARNING: this parameter is used ONLY
								// if the callback rmfp_get_surface_events_callback is not defined

	RMuint32 fifo_size;					// Video decoder input fifo size
	RMuint32 xfer_count;					// Video decoder input fifo xfer count

	enum EMhwlibVideoCodec vcodec;				// If not NULL, the video codec will be forced to this value, else may be autodetected
	RMuint32 vcodec_max_width;				// Forced video codec max width
	RMuint32 vcodec_max_height;				// Forced video codec max height
	RMuint32 vcodec_profile;				// Forced video codec profile
	RMuint32 vcodec_level;					// Forced video codec level
	RMint32  vcodec_extra_pictures;				// Forced video codec extra pictures count
	RMuint32 vcodec_orientation;				// Forced video codec orientation

	RMint32 video_track;					// Force the video track number to play

	RMuint32 CCFIFOEntryCount;
	enum RMFPCloseCaptionMode CloseCaptionMode;
	enum RMFPCloseCaptionType CloseCaptionType;		// Close captions type
	enum EMhwlibCCSelect CloseCaptionSelect;		// Close captions type

	// this replaces 'struct VideoDecoder_VideoTimeScale_type'
	RMbool   ForcePTSTimeScale;				// Force PTS time scale for video
	RMuint32 PTSTimeScale;					// Forced PTS time scale for video

	// this replaces 'struct VideoDecoder_VopInfo_type'
	// NOTE: uses 'PTSTimeScale' as scale
	RMbool   ForceTiming;					// Force time increment for video
	RMuint32 PTSTimeIncrement;				// Forced time increment for video

	RMbool force_input_color_space;				// Force input colorspace
	enum EMhwlibColorSpace input_color_space;		// Forced input colorspace
	enum EMhwlibScanMode input_scan_mode;			// Forced input scan mode

	RMuint32 wmv9_seq;					// WMV9 sequence parameter
	RMbool MSflag;						// Microsoft flag

	RMuint32 display_error_threshold;			// Threshold to be reached to display video errors
	struct VideoDecoder_AnchorErrPropagation_type anchor_error_propagation; // Anchor error propagation
	RMuint32 interlaced_progressive_algorithm;		// Interlacing/progressive algo
	
	// surface frame info force values
	RMbool ForceAFD;					// Force AFD for source material
	struct EMhwlibActiveFormatDescription afd;		// active format descriptor

	RMbool skipNCP;						// Skip NotCoded P-frames

	RMbool pp_enabled;					// Enable Post Processing module (deblocking/deringing) (>= Tango3)

	RMuint32 h264_flags;					// H264 options
	RMuint32 common_flags;					// Common options
	
	enum EMhwlibDefaultColorSpaceAlgorithm cs_algo;  // Which YCbCr color space to select, if not specified by source

	RMuint32 rm_no_deblock;					// Disable RealMedia inloop deblocking
	RMuint32 rm_no_B_deblock;				// Disable RealMedia inloop deblocking for B frames

	RMbool ForceMaxMem;                                     // Forces the VideoDecoder to request the maximum memory (this allows to
								// play invalid streams, such as those that say they are Baseline but
								// which are really Main or Extended)

	RMuint32 custom_memunp;           			// Force unprotected video buffer size
	
	// more surface frame info force values
	RMbool ForceAsp;  // Force aspect ratio (in afd) for source material
	RMbool ForceBarInfo;  // Force black bar info for source material
	struct EMhwlibActiveFormatBarInfo BarInfo;  // Black bar info, when ForceBarInfo
	RMbool ForceScanInfo;  // Force over/under scan info for source material
	enum EMhwlibScanInfo ScanInfo;  // over/under scan info when ForceScanInfo
	RMbool Force3D;  // Force 3D stereoscopic format for source material
	struct EMhwlibStereoscopic3D Stereoscopic3D;  // 3D stereoscopic format when Force3D
};

/***********************************************************
 * Audio options
 ***********************************************************/
struct RMFPAudioOptions {

	RMuint32 EngineIndex;					// Audio engine (DSP) to be used
	RMuint32 DecoderIndex;					// Audio decoder (DSP) to be used
	RMuint32 ChannelServiceIndex;           // Channel service to be used - for itask realmedia

	RMuint32 fifo_size;					// Audio decoder input fifo size
	RMuint32 xfer_count;					// Audio decoder input fifo xfer count

	RMuint32 audio_track;					// Select audio track (for mp4)

	enum AudioDecoder_Codec_type Codec;			// If not NULL, the audio codec will be forced to this value, else may be autodetected
	RMuint32 SubCodec;					// Audio subcodec (if a codec is defined)

	RMuint32 ChannelAssign;					// Channels assignment (needed if codec is forced)

	RMbool DTS_CD;						// DTS CD mode

	RMbool sync_stc;					// STC synchro

	RMbool SignedPCM;					// Signed PCM are used (needed if codec is forced)
	RMbool DownSample;					// Downsample stream (needed if codec is forced)

	RMuint32 chconfig;					// Codec parameter
	RMuint32 drcenable;					// Codec parameter (needed if codec is forced)
	RMuint32 drcboost;					// Codec parameter (needed if codec is forced)
	RMuint32 drccut;					// Codec parameter (needed if codec is forced)
	RMint32 drcdialref;					// Codec parameter (needed if codec is forced)
	RMbool lossless;					// Codec parameter (needed if codec is forced)

	struct AudioDecoder_AudioPlayTime_type audio_play_time;	// Audio in and out control.

	// THESE will be deprecated sometime soon,
	// when RIFF/WAVE files have their own parser instead of using 'elementary'
	RMuint32 skip_first_n_bytes;				// WAVE file bytes to skip
	RMuint32 send_n_bytes;					// WAVE file bytes to send

	RMbool MsbFirst;					// PCM MSB first config (needed if codec is forced)
	RMuint32 bit_per_sample;				// PCM bits per sample (needed if codec is forced)
	RMuint32 PCMSamplingFrequency;				// PCM sampling frequency (needed if codec is forced)

	RMbool Acmod2DualMode;					// AC3 parameter (needed if codec is forced)
	enum Ac3CompMode_type CompMode;				// AC3 parameter (needed if codec is forced)
	RMuint32 DynScaleHi;					// AC3 parameter (needed if codec is forced)
	RMuint32 DynScaleLo;					// AC3 parameter (needed if codec is forced)
	RMuint32 PcmScale;					// AC3 parameter (needed if codec is forced)

	enum AudioChannelMask_type TToneChannelMask;		// TTone channel mask
	enum TestToneType TToneType;				// TTone type

	RMuint32 nb_audio_instances;				// Number of audio instances to open (1 to 4)

	RMbool MSflag;						// Microsoft flag

	RMuint32 audio_block_align;            // For ADPCM
	
	RMbool afs; // Audio Frequency from Stream
};

/***********************************************************
 * Playback options
 ***********************************************************/

enum RMFPPictureFormat {
	RMFPPictureFormat_BMP = 10,
	RMFPPictureFormat_JPEG,
	RMFPPictureFormat_GIF,
	RMFPPictureFormat_PNG,
	RMFPPictureFormat_YUV,
	RMFPPictureFormat_TEST
};

enum RMFPTextSubs {
	RMFPTextSubs_ASCII = 410,
	RMFPTextSubs_UTF8,
	RMFPTextSubs_SSA,
	RMFPTextSubs_ASS,
	RMFPTextSubs_SUB,
	RMFPTextSubs_SMI
};

enum RMFPHLSKeyEncoding {
	RMFPHLSKeyEncoding_NONE = 236,
	RMFPHLSKeyEncoding_AES_128_CBC,
};

enum RMFPHLSType {
	RMFPHLSType_UNKNOWN = 106,
	RMFPHLSType_VOD,
	RMFPHLSType_SLIDINGWINDOW,
	RMFPHLSType_EVENT,
};

enum RMFPRebufferingMode {
	RMFPRebufferingMode_DISABLED,
	RMFPRebufferingMode_FIFO_FULLNESS,
	RMFPRebufferingMode_BUFFER_DURATION,
};

enum RMFPStartOffset_type {
	RMFPStartOffset_none = 0,
	RMFPStartOffset_time_ms,
};

union RMFPStartOffset_value {
	RMuint32 time;		// Start playback at this time in ms
};


#define RMFP_MAX_MULTICAST_STREAMS	        (32)
#define RMFP_MAX_TEXT_SUBS	                (32)
#define RMFP_PLUGIN_PATH_SIZE                   (512)
#define RMFP_MAX_DESCRIPTION_SIZE		(511)
#define RMFP_MAX_ATTACHMENTS_DIRECTORY_SIZE	(511)

enum RMFPVcxoReset {

	RMFPVcxoReset_None,                     // don't change VCXO compensation and STC speed 
	RMFPVcxoReset_SpeedAndRegulation,       // Reset the VCXO compensation and set the STC speed back to 1 1
	RMFPVcxoReset_Regulation                // Reset the VCXO compensation and don't change the STC speed
};

struct RMFPPlayOptions {

	RMuint32 STCIndex;					// STC index to use for playback
	RMuint32 STCEngine;					// STC demux engine to use for playback
	RMuint32 DRAMIndex;					// DRAM index to use for resources allocation

	RMuint64 duration;					// File duration in ms (it can also be autodetected for some streams)

	RMint32 subtitles_track;				// Force the subtitles track number to play
	RMbool enable_spu;					// Enable subtitles from file

	RMbool send_video;					// Play video stream from file
	RMbool send_audio;					// Play audio stream from file
	RMbool send_spu;					// Play subtitles stream from file (if activated with enable_spu)

	RMbool send_video_pts;					// Send video PTS
	RMbool send_audio_pts;					// Send audio PTS
	RMbool send_spu_pts;					// Send subtitles PTS

	RMfile save_video_file_handle;				// File handle where to dump the video stream
	RMfile save_audio_file_handle;				// File handle where to dump the audio stream
	RMfile save_spu_file_handle;				// File handle where to dump the subtitles stream

	RMint32 speed_N;					// Playing speed numerator
	RMuint32 speed_M;					// Playing speed denominator

	RMint32 stc_offset_ms;					// Play STC with an offset

	RMuint32 dmapool_count;					// Number of DMA pools
	RMuint32 dmapool_log2size;				// Log2 size of a single DMA pool

	RMbool require_video_audio;				// Audio and video are required (not used for all stream types)

	RMbool enable_disk_control;				// Enable disk control
	RMuint32 disk_ctrl_low_level;				// Low threshold for HDD wakeup (in KBytes)
	RMuint32 disk_ctrl_buffer_size;                         // Size (in KBytes) of the Buffer used for disk control (this includes XFER FIFOs, so effective value will be lower)

	RMuint32 prebuf_max;					// Max prebufferization size in bytes

	RMbool send_audio_trickmode;				// Send audio during trick modes (not implemented yet)
	RMbool savems;						// Save files in MS format (not implemented yet)

	RMbool fast_audio_recovery;				// Enable fast audio recovery (seeks to the right position after a trick mode) (Default: ON)
	RMbool accurate_seek;					// Enable accurate seek (to seek to a given frame and not only an Iframe) (Default: ON)

	RMbool linear_mode;					// Limits the amount of seeking

	RMbool stc_compensation;				// Use a STC compensation algorithm regulate the STC according to the incoming flow (for multicast and SPI only)
	RMint32 vcxo_index;					// If STC compensation is enabled, regulate the corresponding VCXO accordingly (-1 to disable)

	enum RMFPVcxoReset reset_vcxo;				// VCXO compensation and STC speed reset mode

	struct RMWMDRMHandle *pCARDEAHandle;			// Cardea handle
	struct RMWMDRMURLHandle *pCARDEAURLHandle;		// Cardea URL handle

	struct RMDTCPAPIURLHandle *pDTCPURLHandle;              // DTCP URL Handle
	RMbool DTCPUseDemuxForDecryption;                       // Use demux DTCP decryption (not sure if this is the right name!!)

	struct {
		struct {
			RMfile file_handle;			// File handle of an external TEXT BASED subtitles file
			RMascii description[RMFP_MAX_DESCRIPTION_SIZE+1]; // Description of the sub file (usualy the file name)
			enum RMFPTextSubs type;			// Text subtitles format (SRT, SSA, ASS, SUB or SMI)
			RMuint32 framerate_numerator;		// Frame rate numerator mandatory for SUB text subtitles
			RMuint32 framerate_denominator;		// Frame rate denominator mandatory for SUB text subtitles
		} entry[RMFP_MAX_TEXT_SUBS];

		RMuint32 count;                                 // Number of external subs
	} text_subs;
	
	RMbool truecolor_subs;					// Don't use a palette for subs, use truecolor
	RMbool yuv_palette_subs;				// When truecolor_subs is disabled, use a YUV palette for subs (needed for the SPU scaler)
	
	RMbool no_prerendered_subs;				// Disable the prerendering in memory function for subtitles (to save memory)
	RMbool disable_ssa_animations;				// Disable the SSA special animations

	enum RMFPPictureFormat PictureFormat;			// Choose format of picture to display (seen enum)

	RMfile subidx_sub_file_handle;				// File handle of a binary sub file (AVI and ASF)
	RMfile subidx_idx_file_handle;				// File handle of the corresponding idx file (AVI and ASF)
	RMuint32 subidx_index;					// Index of the lang in the idx file (AVI and ASF)

	RMint64 external_subs_delayms;				// Add a delay in ms to the text or SUB/IDX subtitles display (positive means later)
	
	RMascii attachments_extraction_dir[RMFP_MAX_ATTACHMENTS_DIRECTORY_SIZE+1];	// Directory where to extract attachement (NULL for none)

	RMbool WaitExit;

	const RMascii *rtsp_url;					// RTSP url to use instead of file handle (for ASF only).

	//Picture Transform
	RMbool PTEnable;
	enum EMhwlibPictureOrientation PTOrientation;
	RMbool PTInPlace;

	//Watermark
	RMbool watermark;

	RMascii PlugInPath[RMFP_PLUGIN_PATH_SIZE];

	RMbool IgnoreEOS;
	RMbool ReindexMKV;					// Reindex MKV if there is no CUE inside the file

	const RMascii *url;

	RMbool cacheMP4Indexes;				// Will tell the mp4 lib to cache all the index
	RMbool force_linear_interleaving;	// Force the mp4 lib to read the data linearly

	RMbool unseekable_file;				// Force the app to disable the seek support for the media file

	RMascii *hls_key_url_options;       // Pass some option to the url of the hls key
	enum RMFPHLSKeyEncoding hls_key_encoding; // Define the encoding of the hls key
	RMascii *hls_key_key;               // The key to decoding the hls key (hex string)
	RMascii *hls_key_iv;                // The iv to decoding the hls key (hex string)
	RMbool hls_base64_key;              // A boolean saying that the (encrypted) key is stored as base64 instead of binary
	enum RMFPHLSType hls_type;          // Define the type of the live http stream
	RMuint32 hls_thread_cache_memory;   // The amount of memory that will be allowed to the thread for caching the file.
	RMbool hls_autoswitch_set_window;   // A boolean to say if the auto switch values are set or not.
	RMint32 hls_up_window_percentage;   // The upper limit of the window to choose when automaticaly switch variant in hls.
	RMint32 hls_down_window_percentage; // The lower limit of the window to choose when automaticaly switch variant in hls.

	enum RMFPRebufferingMode	rebuffering_type;	// Rebuffering mode. Use RMFPRebufferingMode_DISABLED if you wish
								// to implement your own rebuffering algorithm.
								// RMFP provides the RMFPRebufferingMode_FIFO_FULLNESS and
								// RMFPRebufferingMode_BUFFER_DURATION default algorithms

	/* Values in % for RMFPRebufferingMode_FIFO_FULLNESS, in ms for RMFPRebufferingMode_BUFFER_DURATION
	 *	- High watermark can be 0, which means don't restart playback automatically. In that case it will
	 *	wait for the calling application to send a Play command.
	 *	- Other than that, high watermarks must always be bigger than the corresponding low watermark for
	 *	obvious reasons.
	 *
	 * When using FIFO rebuffering the watermark should not be understood as a simple 'hard' watermark
	 * working on the FIFO fullness. The algorithm will actually consider those thresholds as a basis for
	 * and adapt their values based on various properties of the stream. For instance using the relative
	 * audio and video bitrates to avoid triggering a rebuffering is the audio fifo is almost empty while
	 * the video fifo appears to be close to fullness.
	 */
	RMuint32			rebuf_alow;		// Audio Low Watermark (default 10% / 500ms)
	RMuint32			rebuf_ahigh;		// Audio High Watermark (default 90% / 10000ms)
	RMuint32			rebuf_vlow;		// Video Low Watermark (default 10% / 500ms)
	RMuint32			rebuf_vhigh;		// Audio Low Watermark (default 90% / 10000ms)

	/* RMFPRebufferingMode_BUFFER_DURATION only : fullness limit in case buffer
	 * is too small to reach rebuf_vhigh/rebuf_ahigh */
	RMuint32			rebuf_fullness;		// default : 90%

	RMuint32			rebuf_timeout;		// Automatically stop rebuffering after rebuf_timeout secs
								// default: 90s

	RMuint32			read_timeout;		// Demuxes main loops will try to avoid blocking command processing
								// because of a long file read for more than read_timeout.
								// Support of this option is limited to specific transport protocols
								// such as HTTP (using libcurl). This option should be used to increase
								// rebuffering robustness.
								// Lower timeout means better responsiveness.
								// 0 = infinite timeout (blocking behaviour)
								// 400ms = default value
								// 1000m = maximum value, timeouts above 1s will be shorted down to 1s

	RMbool				liteindex_enable;	// Enable/Disable LiteIndex.
								// LiteIndex is a small footprint on the fly indexing engine
								// That allows to perform trickmodes without requiring the need
								// to compute a full (and therefore expensive) index.
								// LiteIndex only needs a few initial anchorpoints which do not need to
								// be iframes.
								//
								// LiteIndex is available for systems without native indexes namely :
								// SoftDemux, PSFDemux, OGM, and FLV (support of these last two is not
								// available yet)
								//
								// LiteIndex primarly target "Rips" file (BluRay .m2ts and DVD .vob)
								// Visual "quality" of trickmodes with liteidex is highly depends
								// on the regularity of iframe positions in the stream

	RMuint32			liteindex_kickstart;	// Number of initial LiteIndex anchor points.
								// An higher value means higher reliability right away,
								// at the expense of an increase in pre-buffering time.
								// A lower value means less resilience against PTS discontinuities
								// but limited to no effects on pre-buffering time.
								// Default value is 40 which is a good tradeoff.
								//
								// Current implementation of liteindex requires the file
								// size to be at least liteindex_kickstart*1024 kBytes to
								// work properly

	RMuint32			liteindex_trickfactor;	// The trickfactor is used to adjust the frame display rate in IFwd/IBwd mode with
								// with liteindex enabled. The factor is in miliseconds. A factor of 500ms for
								// instance means that whatever the requested playback speed the algorithm will
								// attempt to produce a picture every 500 miliseconds. Higher values will produce
								// more regular playback with less glitches (especially in backward mode). Lower
								// values will result in more pictures, but more frequent glitches and potentially
								// choppy playback

	// Generic start_offset
	enum RMFPStartOffset_type	start_offset_type;			// Type of start_offset
	RMbool				start_offset_use_accurate_seek;		// Use accurate seek ?

	union RMFPStartOffset_value	start_offset;
};

/***********************************************************
 * Demux options
 ***********************************************************/
struct RMFPDemuxOptions {
	RMsystemType system_type;				// Demux system type (m2t, ...)

	RMuint32 video_pid;					// Force video PID or streamID to play
	RMuint32 audio_pid;					// Force audio PID or streamID to play
	RMuint32 spu_pid;					// Force subtitles PID or streamID to play
	RMuint32 audio_subid;					// Set audio streamSubID for program streams
	RMuint32 spu_subid;					// Set subtitles streamSubID for program streams

	RMuint32 wait_for_pcr_time_ms;				// Wait for PCR time (Default: 0)
	RMuint32 pts_taken_as_pcr_offset_ms;			// Offset in ms to take PTS from PCR (Default: 0)

	/*
	 * Soft Demux specific options (RMFP_application_type_SOFTDEMUX)
	 */
	RMbool repack_sample;					// Repack samples in soft demux mode (SOFT DEMUX ONLY) (Default: ON)

	/*
	 * PSF Demux specific options (RMFP_application_type_PSFDEMUX)
	 */
	RMuint32 engine_id;					// PSF Demux engine ID
	RMuint32 task_id;					// PSF Demux task ID in engine

	RMuint32 fifo_size;					// PSF Demux input fifo size
	RMuint32 xfer_count;					// PSF Demux input fifo xfer count

	RMbool spi;						// Use SPI input instead of a file
	RMbool serial_spi;					// Use Serial SPI input instead of a file
	RMuint32 input_port;					// SPI input port
	RMuint32 input_protocol;				// SPI input protocol
	RMuint32 idle_port;					// SPI idle port
	RMuint32 flags;						// Set of flags to configure some demux special behaviours

	RMuint32 pcr_pid;					// Force PCR PID
	RMuint32 ttx_pid;					// Force telextext PID
	enum RMFPTeletextMode TeletextMode;                     // Teletext type
	RMbool ignore_pat;					// Tell the application not to create the PAT. Only the forced pids will work.
	RMuint32 pmt_pid;					// Force PMT pid
	RMuint32 pmt_index;					// Force PMT index
	RMuint32 default_pmt_pid;           // default pmt pid

	RMuint32 ts_skip;					// Force packets bytes skipping (4 for 192bytes packets, ...)

	RMuint32 sync_lock;					// Sync lock parameter
	RMuint32 pcr_disc;					// PCR disc paramter
	enum EMhwlibTransportPriority_type audio_ts_priority;	// Audio priority
	RMuint32 pes_pid_entry_input_type;			// Select PES/PID input type
	RMbool mpeg_multichannel;				// Use multichannels mpeg (to be tested)

	RMuint32 section_filter_based_on_new_version;		// Select if we want to process all PMT/PAT even if they do not change

	RMbool iterative_seek;					// Enabel iterative seek

	RMfile save_pmt_file_handle;				// File handle where to dump the PMT PID
	RMfile save_pat_file_handle;				// File handle where to dump the PAT PID
	RMfile save_custom_pid_file_handle;			// File handle where to dump the custom PID
	RMuint32 custom_pid;					// Custom PID to dump

	RMfile index_file_handle;				// File handle of the index file to use (created with the rmmpegsystemindex library)
	RMfile multicast_dump_file_handle;			// File handle where to dump the multicast stream
	RMfile tsdump_file_handle;				// File handle where to dump the transport file (for timeshifting)
	RMbool tsdump_is_192;					// Force use of 192 bytes (BDRIP and ATS streams) for the TS dump
	RMfile tsdump_index_file_handle;			// File handle of the dumped transport index file to create (for timeshifting)

	RMfile index2create_file_handle;			// File handle of the index to create
	RMfile second_file_handle;				// A second file handle of the read file in order to create the index
	
	RMfile save_input_file_handle;				// File handle where to dump the whole input in SPI mode

	RMbool load_previous_index_entries;		// Indicate that we want to load entries from a previous 'index2create_file_name' index file
	RMascii *index2create_file_name;		// Index file name

	struct
	{
		RMascii address[RMFP_MAX_MULTICAST_STREAMS][16];// Source addresses list
		RMuint16 port[RMFP_MAX_MULTICAST_STREAMS];	// Source ports list
		RMuint32 count;					// Number of sources

	} multicast;						// Can be used to join multicast sessions OR to listen
								// for streamed data on specific unicast addresses

	RMuint64 start_offset;					// Offset in byte where to start playing the file
								// PSFDemux specific-option

	/* Not implemented */
	RMint32 change_program_method;
	RMbool monitor;
};

struct RMFPPictureOptions {
	RMuint8 alpha;
	RMbool force_rgb;
	RMbool ignore_picture_alpha_channel;
	RMuint32 yuv_width;
	RMuint32 yuv_height;
	RMuint32 yuv_sampling_mode;
	RMbool yuv_has_alpha;
};

/***********************************************************
 * RMFP options
 ***********************************************************/
struct RMFPOptions {

	// trimmed versions of *_opt from libsamples1
	struct RMFPPlayOptions  playback_options;
	struct RMFPVideoOptions video_options;
	struct RMFPAudioOptions audio_options;

	// Containers specific options
	struct RMFPDemuxOptions demux_options;

	struct RMFPPictureOptions picture_options;
};

/*
 * Function to set default options
 */
RMstatus RMFPInitOptions(struct RMFPOptions *pOptions);


/****************************************************************************************************************/
/****************************************************************************************************************/
/********************************************* STREAM PROPERTIES ************************************************/
/****************************************************************************************************************/
/****************************************************************************************************************/

#define RMFP_STREAM_PROPERTIES_MASK_VIDEO	(1<<0)
#define RMFP_STREAM_PROPERTIES_MASK_AUDIO       (1<<1)
#define RMFP_STREAM_PROPERTIES_MASK_SUBTITLES   (1<<2)
#define RMFP_STREAM_PROPERTIES_MASK_PICTURE	(1<<3)

struct RMFPVideoStreamProperties {

	RMint32 id;
	enum EMhwlibVideoCodec codec;
	struct EMhwlibNewPicture picture_info;

};

struct RMFPAudioStreamProperties {

	RMint32 id;
	struct AudioDecoderInfo audio_info;
};

struct RMFPSubtitlesStreamProperties {

	RMint32 id;
};

struct RMFPPictureStreamProperties {

	RMint32 id;
	enum RMFPPictureFormat format;
	RMuint32 width;
	RMuint32 height;
	RMuint32 palette_size;
};

/*
 * The following structure describes the properties of the played stream
 */
struct RMFPStreamProperties {

	RMuint32 Version;

	RMuint32 valid_properties_mask;			// Mask of properties to take from the structure

	struct RMFPVideoStreamProperties video;
	struct RMFPAudioStreamProperties audio;
	struct RMFPSubtitlesStreamProperties subtitles;
	struct RMFPPictureStreamProperties picture;
};

/*
 * The following callback is called to notify to the application the properties of the stream.
 * It would be equivalent to RMFileStreamInfoCallback(...)
 */
RM_TYPEDEF_FUNCTION_PTR(RMstatus,
			rmfp_notify_current_streams_properties_callback_type,
			void *pContext,
			struct RMFPStreamProperties *pStreamProperties);



/****************************************************************************************************************/
/****************************************************************************************************************/
/************************************************ META DATA *****************************************************/
/****************************************************************************************************************/
/****************************************************************************************************************/

#define MAX_VIDEO_STREAMS 4
#define MAX_AUDIO_STREAMS 16
#define MAX_SPU_STREAMS   24
#define MAX_VARIANT_PLAYLIST 12
#define MAX_CHAPTER_LIST_SIZE 64
#define MAX_ATTACHMENT_LIST_SIZE 16

#define RMFP_SUBS_ALLOW_CMD_SET_DELAY		(1<<0)
#define RMFP_SUBS_ALLOW_CMD_SET_FONTSIZE	(1<<1)
#define RMFP_SUBS_ALLOW_CMD_SET_POSY		(1<<2)
#define RMFP_SUBS_ALLOW_CMD_SET_FILLCOLOR	(1<<3)
#define RMFP_SUBS_ALLOW_CMD_SET_BORDERCOLOR	(1<<4)
#define RMFP_SUBS_ALLOW_CMD_SET_ENCODING	(1<<5)

enum RMFPStreamMetadataType {
	RMFPStreamMetadataType_None = 32,
	RMFPStreamMetadataType_MP4,
	RMFPStreamMetadataType_MKV,
	RMFPStreamMetadataType_HLS,
};

struct RMFPMP4Metadata {

	RMbool   isNero;
	RMbool   isPlayable;

	// currently only supported for Nero files
	RMuint32 Chapters;

	struct RMFPMP4MetadataChapterEntry {
		RMascii *pName;
		RMuint64 Time_ms;
	} ChapterList[MAX_CHAPTER_LIST_SIZE];

};

struct RMFPMKVMetadata {

	// other metadata, like for example, the chapters...

	RMuint32 Chapters;

	struct RMFPMKVMetadataChapterEntry {
		RMascii *pName;
		RMuint64 Time_ms;
	} ChapterList[MAX_CHAPTER_LIST_SIZE];

	RMuint32 Attachments;

	struct RMFPMKVMetadataAttachmentEntry {
		RMascii	*pName;
		RMascii	*pDescription;
		RMascii	*pMimeType;
		RMuint64 Position;
		RMuint64 Length;
	} AttachmentList[MAX_CHAPTER_LIST_SIZE];
};

struct RMFPHLSMetadata {

	// Variant metadata
	RMuint32 variants;
	RMuint32 currentVariant;
	RMuint32 variantBandwidth[MAX_VARIANT_PLAYLIST];

	// Timestamp of the beginning of the playlist
	RMuint32 startTimeDate;
};

struct RMFPStreamAMetadataVideoStreamEntry {

	RMuint32 StreamID;
	RMbool Supported;
	RMascii *pDescription;
};

struct RMFPStreamMetadataAudioStreamEntry {

	RMuint32 StreamID;
	RMbool Supported;
	RMascii *pDescription;
};

struct RMFPStreamMetadataSPUStreamEntry {

	RMuint32 StreamID;
	RMbool Supported;
	RMascii *pDescription;

	/*
	 * This a mask of the allowed commands for this particular stream (among RMFP_SUBS_ALLOW_CMD_*)
	 */
	RMuint32 AllowedCommandsMask;

	/*
	 * These are the default parameters that can be changed following AllowedCommandsMask
	 */
	RMint32 Delay_ms;
	RMuint32 FontSize;
	RMuint32 PosY;
	RMuint32 FillColor;
	RMuint32 FillAlpha;
	RMuint32 BorderColor;
	RMuint32 BorderAlpha;
	enum RMFPSubsEncoding Encoding;
};



struct RMFPStreamMetadata {

	RMuint32 Version;

	RMuint32 Duration;

	RMuint32 VideoStreams;
	struct RMFPStreamAMetadataVideoStreamEntry VideoStreamList[MAX_VIDEO_STREAMS];

	RMuint32 AudioStreams;
	struct RMFPStreamMetadataAudioStreamEntry AudioStreamList[MAX_AUDIO_STREAMS];

	RMuint32 SPUStreams;
	struct RMFPStreamMetadataSPUStreamEntry SPUStreamList[MAX_SPU_STREAMS];


	enum RMFPStreamMetadataType MetadataType;

	union {

		struct RMFPMP4Metadata mp4;
		struct RMFPMKVMetadata mkv;
		struct RMFPHLSMetadata hls;

	} data;
};

RM_TYPEDEF_FUNCTION_PTR(RMstatus,
			rmfp_notify_stream_metadata_callback_type,
			void *pContext,
			struct RMFPStreamMetadata *pStreamMetadata);

/****************************************************************************************************************/
/****************************************************************************************************************/
/********************************************** STREAM INFO *****************************************************/
/****************************************************************************************************************/
/****************************************************************************************************************/

/*
 * This provides a simple description of the stream, whether is an ASF, an elementary AC3 audio or a M2T
 * for types where auto detection is possible, it will work, for example system streams.
 * for elementary streams, the codec will be required.
*/
enum RMFP_application_type {
	RMFP_application_type_UNKNOWN = 80,
	RMFP_application_type_ASF,
	RMFP_application_type_AVI,
	RMFP_application_type_MP4,
	RMFP_application_type_PSFDEMUX,
	RMFP_application_type_SOFTDEMUX,
	RMFP_application_type_VIDEO,
	RMFP_application_type_AUDIO,
	RMFP_application_type_PICTURE,
	RMFP_application_type_MKV,

	// might not be really necessary as long as the code is shared between libplay and the standalone apps
	RMFP_application_type_ASF_STREAMING,        //not done yet

	// This is a generic type for RIFF file
	RMFP_application_type_RIFF,

	RMFP_application_type_FLV,

	RMFP_application_type_HLS,

	RMFP_application_type_REALMEDIA,
	RMFP_application_type_OGG,
	RMFP_application_type_DTV,
	RMFP_application_type_CAPTURE,
};

struct RMFPStreamType {
	enum RMFP_application_type application_type;
};


/*

   **********************************************************************************

   IMPORTANT NOTE: the RMFPStreamInfo structs (below) are subject to change since its
   format is currently being reviewed.

   **********************************************************************************

*/


/*
 * This provides a more comprehensive description of the stream, it'll tell the system type as well
 * as the PID, codecs and other parameters for each stream (probably coming from a detection routine)
*/
struct RMFPStreamInfo_Video {

	RMuint32 Version;

	RMint32 StreamID;
	RMuint32 ParentStreamID;

	RMuint32 PID;			// If different from zero, then the info is valid
	RMuint32 SubID;
	RMuint32 PIDType;

	enum EMhwlibVideoCodec Codec;
	RMuint32 MaxWidth;
	RMuint32 MaxHeight;

	RMuint32 Profile;
	RMuint32 Level;
	RMuint32 ExtraPictureBufferCount;

	RMbool skipNCP;

	RMbool isSupported;
};

struct RMFPStreamInfo_Audio {

	RMuint32 Version;

	RMint32 StreamID;
	RMuint32 ParentStreamID;

	RMuint32 PID;			// If different from zero, then the info is valid
	RMuint32 SubID;
	RMuint32 PIDType;

	enum AudioDecoder_Codec_type Codec;
	RMuint32 SubCodec;

	RMuint32 TSPriority; // for M2T - 0 or 1

	/* used mainly for PCM because the parameters of other codecs can be detected as they are present in the bitstream

	   NOTE: BitsPerSample and MSBFirst is used also by DTS, this because the decoder cannot detect this yet.
	 */
	RMuint32 SampleRate;
	RMuint32 Channels;
	RMuint32 BitsPerSample;
	RMuint32 Bitrate;
	RMbool MSBFirst;

	RMbool isVBR;
	RMuint32 VBRDuration;	// Detected VBR duration if available

	RMbool isSupported;
};

struct RMFPStreamInfo_System {

	RMuint32 Version;

	RMint32 StreamID;
	RMuint32 ParentStreamID;

	RMuint32 DemuxMode;
	RMuint32 TSSkip;

	// used for WAVE playback with main_audio.c (NOTE this will be deprecated sometime soon)
	RMuint32 SkipFirstNBytes;
	RMuint32 SendNBytes;

	/* default PMT pid */
	RMuint32 default_pmt_pid;
};

enum RMFPPictureProfile {
	RMFPPictureProfile_UNKNOWN = 32,
	RMFPPictureProfile_Baseline,
	RMFPPictureProfile_Progressive,
};

enum RMFPPictureColorSampling {
	RMFPPictureColorSampling_UNKNOWN = 68,
	RMFPPictureColorSampling_RGB,
	RMFPPictureColorSampling_444,
	RMFPPictureColorSampling_420,
	RMFPPictureColorSampling_422,
	RMFPPictureColorSampling_422Half,
	RMFPPictureColorSampling_422Rotated,
	RMFPPictureColorSampling_422HalfRotated,
};

struct RMFPSteamInfoData_Picture {
	
	enum RMFPPictureFormat format;
	RMuint32 Width;
	RMuint32 Height;

	RMuint32 Precision;

	enum RMFPPictureProfile Profile;
	enum RMFPPictureColorSampling ColorSampling;

};

enum RMFPStreamInfoData_SPUType {

	RMFPStreamInfoData_SPUType_Bluray = 20,
	RMFPStreamInfoData_SPUType_DVD,
	RMFPStreamInfoData_SPUType_DVB,

};

struct RMFPStreamInfoData_SPU {

	enum RMFPStreamInfoData_SPUType Type;
	RMuint32 Lang; //, ENG, FRA, SPA, etc

};

enum RMFPStreamInfoData_Type {
	
	RMFPStreamInfoData_Unknown = 10,
	RMFPStreamInfoData_Picture,
	RMFPStreamInfoData_SPU,
};

struct RMFPStreamInfo_Data {
	RMuint32 Version;

	RMint32 StreamID;
	RMuint32 ParentStreamID;

	RMuint32 PID;			// If different from zero, then the info is valid
	RMuint32 SubID;
	RMuint32 PIDType;

	enum RMFPStreamInfoData_Type Type;
	union {
		struct RMFPSteamInfoData_Picture picture;
		struct RMFPStreamInfoData_SPU spu;
	} Parameters;

	RMbool isSupported;
};

struct RMFPStreamInfo {

	RMuint32 Version;

	RMuint32 VideoStreamCount;
	struct RMFPStreamInfo_Video *pVideo;

	RMuint32 AudioStreamCount;
	struct RMFPStreamInfo_Audio *pAudio;

	RMuint32 DataStreamCount;
	struct RMFPStreamInfo_Data *pData;

	/*
	   normally always one, it is provided here for expansion purposes:
	   ID3 might be considered system and can be carried inside MP3 or WAVE
	*/
	RMuint32 SystemStreamCount;
	struct RMFPStreamInfo_System *pSystem;
};

#if 1/*added by lxj 2012-11-6 for write to file*/
#define STRAMINFO_VIDEO_MAX  4
#define STRAMINFO_AUDIO_MAX  4
#define STRAMINFO_DATA_MAX   4
#define STRAMINFO_SYSTEM_MAX 4

struct RMFPStreamInfo2 {

	RMuint32 Version;

	RMuint32 VideoStreamCount;
	struct RMFPStreamInfo_Video Video[STRAMINFO_VIDEO_MAX];

	RMuint32 AudioStreamCount;
	struct RMFPStreamInfo_Audio Audio[STRAMINFO_AUDIO_MAX];

	RMuint32 DataStreamCount;
	struct RMFPStreamInfo_Data Data[STRAMINFO_DATA_MAX];

	/*
	   normally always one, it is provided here for expansion purposes:
	   ID3 might be considered system and can be carried inside MP3 or WAVE
	*/
	RMuint32 SystemStreamCount;
	struct RMFPStreamInfo_System System[STRAMINFO_SYSTEM_MAX];
};
#endif

/*
   DETECTION API:


   fileHandle: mandatory

   pFilename: optional, might be NULL

   ParsingLength: if zero, use the default value.
   if < 0 parse the whole stream.
   else parse the specified amount of data [in KB].

   AvoidSeeking: will avoid seeking, therefore the fileHandle pointer
   will be unknown at the end of the call. The application should handle
   that case.

   ** IMPORTANT NOTE **:
   if AvoidSeeking=1 then only basic information will be
   returned. Do not expect more than the system type with this option set
   to TRUE.

   pStreamType: mandatory, it returns the application type

   ppStreamInfo: mandatory, it contains more information about the stream

 */

RMstatus RMFPGetStreamInfo(struct RMFPHandle *pHandle,
			   RMfile fileHandle,
			   const RMascii *pFilename,
			   RMint32 ParsingLength,
			   RMbool AvoidSeeking,
			   struct RMFPStreamType *pStreamType,
			   struct RMFPStreamInfo **ppStreamInfo);


RMstatus RMFPApplyStreamInfoToOptions(struct RMFPHandle *pHandle,
				      RMfile fileHandle,
				      struct RMFPStreamType *pStreamType,
				      struct RMFPStreamInfo *pStreamInfo,
				      struct RMFPOptions *pOptions);

/*

   Given that pStreamInfo is allocated inside GetStreamInfo, you must call this in order to
   free the memory

*/

RMstatus RMFPReleaseStreamInfo(struct RMFPHandle *pHandle,
			       struct RMFPStreamInfo *pStreamInfo);
RMstatus RMFPReleaseStreamInfo2(struct RMFPStreamInfo *pStreamInfo);

/****************************************************************************************************************/
/****************************************************************************************************************/
/**************************************** PROGRESS CALLBACK *****************************************************/
/****************************************************************************************************************/
/****************************************************************************************************************/

/*
  Progress callback:

  The type of progress is an a value from enum RMFP_progress_type and is stored into progress_type.
  The kind of information about the progress is a value from enum RMFP_progress_info_type and is stored into info_type;
  The information itself is stored into the union.

  Information type:
  a) percentage
	This value is used to notify the percentage of the progress with 0 notifying the start and 100 notifying the end
  b) size
	This value is used to notify a size (for RMFP_progress_type_file_bytes_read for instance), in bytes

  - if the pointer pAbort is non-NULL then you could use it to abort the
  processing taking place, set it to TRUE to abort. The processing will
  be interrupted as soon as possible. The end will be signaled with a last
  call to progress with a value of 100 for a percentage.

*/

enum RMFP_progress_type {
	RMFP_progress_type_buffering = 98,
	RMFP_progress_type_detection,
	RMFP_progress_type_index_creation,
	RMFP_progress_type_wait_for_new_picture,
	RMFP_progress_type_file_reading, /* For future use */
	RMFP_progress_type_extracting_attachment
};

enum RMFP_progress_info_type {
	RMFP_progress_info_type_percentage = 44,
	RMFP_progress_info_type_size
};

struct RMFPProgress {

	RMuint32 Version;

	enum RMFP_progress_type progress_type;
	enum RMFP_progress_info_type info_type;

	union {
		RMint32 percentage;
		RMint64 size; /* For future use */
	} progress;
};


RM_TYPEDEF_FUNCTION_PTR(RMstatus,
			rmfp_notify_progress_callback_type,
			void *pContext,
			struct RMFPProgress* pProgress,
			RMbool *pAbort);

/****************************************************************************************************************/
/****************************************************************************************************************/
/******************************************** RMFP Profile, OPEN/CLOSE ******************************************/
/****************************************************************************************************************/
/****************************************************************************************************************/

#ifndef CREATEMAGIC
#define CREATEMAGIC(ch3, ch2, ch1, ch0) ( (RMint32)(RMint8)ch0 | ((RMint32)(RMint8) ch1 << 8) | ((RMint32)(RMint8)ch2 << 16) | ((RMint32)(RMint8)ch3 << 24))
#endif

#define RMFP_MAGIC_NUMBER CREATEMAGIC('f', 'p', '1', '0')

#include <rmfp/include/rmfp_ext.h>

/*
 * Function to send a RMFP profile default values
 */
RMstatus RMFPInitProfile(struct RMFPProfile *pProfile);


/*
 * Function to init stream type
 */
RMstatus RMFPInitStreamType(struct RMFPStreamType *pStreamType);

/*
 * Function to open a new RMFP handle
 * playbackHandle must have been setup previously
 * provided in case rmfp depends on other libraries that require initialisation
*/
RMstatus RMFPOpenHandle(struct RMFPProfile *pProfile, struct RMFPHandle **ppHandle);

/*
 * Once the playbackHandle has been opened we can start playback with options
 * this call won't return until playback ended (either by EOS, quitting or fatal error)
 * before returning all resources will be signalled as free (or unused)
*/
RMstatus RMFPMain(struct RMFPHandle *pHandle, RMfile fileHandle, struct RMFPStreamType *pStreamType, struct RMFPOptions *options);


RMstatus RMFPReleaseSource(struct RMFPHandle *pHandle);


/*
 * This will close the handle
 */
RMstatus RMFPCloseHandle(struct RMFPHandle *pHandle);

/****************************************************************************************************************/
/****************************************************************************************************************/
/*********************************************** OTHER USEFUL FUNCTIONS *****************************************/
/****************************************************************************************************************/
/****************************************************************************************************************/

/*

  RMFPOpenURL(handle, URL) - RMFPCloseURL(handle, fileHandle)

  handle: mandatory
  URL: mandatory


  TO BE REVIEWED BY: Glen, Thulasi, DavidBryson
  ******************

  if (DTCP) {
      DTCP will parse a given URL and if DTCP protected it'll setup some decryption hooks

      Please note that DTCP has two working modes:
      - the decryption will happen inplace inside the RMReadFile call by means of the hooks
      (this is the method used for most content, ASF, AVI, while detecting, etc...)
      - the decryption will be done directly by the psfdemux after reading
      (this method is used by the psfdemux)

      Therefore, we need to have a way to select the working mode after the open took place
  }

  I believe CARDEA handling should be straight forward.

*/

RMfile RMFPOpenURL(struct RMFPHandle *pHandle, const RMascii *pURL);
RMstatus RMFPCloseURL(struct RMFPHandle *pHandle, const RMfile fileHandle);

/*

  RMFPOpenURLWithDTCPSession(handle, URL, session)

  handle: mandatory
  URL: mandatory
  session: mandatory

  TO BE REVIEWED BY: Glen, Thulasi
  ******************

  we provide this functionality in order for DCTP to work with a session initiated
  by the application.

*/


/*!
 * \fn		RMstatus RMFPGetPlaybackTime(struct RMFPHandle *pHandle, RMuint32 *pTime)
 * \brief	This function give the current playback time from beginning of stream
 * \param	pHandle is pointer on rmlibplay handle
 * \param	pTime is pointer to write current playback time
 * \return	standart RMstatus
 */
RMstatus RMFPGetPlaybackTime(struct RMFPHandle *pHandle, RMuint32 *pTime);

/****************************************************************************************************************/
/****************************************************************************************************************/
/************************************************** PREFECTH API ************************************************/
/****************************************************************************************************************/
/****************************************************************************************************************/
/*
 * Equivalent to old RMPFS functionality
 */

struct RMFPPrefetchProfile {
	RMuint8 *pPrefetchArea;
	RMuint32 PrefetchAreaSize;
	RMuint32 PrefetchSlots;        // up to 32
};


struct RMFPPrefetchResources {
	RMuint8 *pPrefetchArea;
	RMbool Locked;                /* If locked is TRUE, it means that there are still some slots open
					 It is preferably to close all the slots before calling
					 RMFPPrefetchUninit()
				      */
};

/**
   Initialises the prefetch mechanism with the given profile.

   The amount of prefetching available for each slot is:

      SlotPrefetchSize = PrefetchAreaSize / PrefetchSlots

   @param pProfile

   @return
*/
RMstatus RMFPPrefetchInit(struct RMFPHandle *pHandle, struct RMFPPrefetchProfile *pProfile);


/**
   Used to obtain the resources in use by the prefetching mechanism


   @param pResources

   @return
*/
RMstatus RMFPPrefetchGetResources(struct RMFPHandle *pHandle, struct RMFPPrefetchResources *pResources);



/**
   Used to 'close' the prefetch mechanism. If the call succeds the resources used for
   prefetching can be freed by the application.

   @return
*/
RMstatus RMFPPrefetchUninit(struct RMFPHandle *pHandle);

/**
   Allocates a prefetch slot for a given fileHandle.

   @param InputFileHandle: a file handle to the URL to be prefetched

   @param pPrefetchedFileHandle: this is the prefetched file handle.

   PLEASE NOTE:
   - This is the filehandle that must be passed to RMFPMain() in
   order for prefetch to work.
   - After you RMCloseFile() this filehandle a prefetching slot will
   be released.


   @return
*/
RMstatus RMFPPrefetchOpenFile(struct RMFPHandle *pHandle, RMfile InputFileHandle, RMfile *pPrefetchedFileHandle);


/**
   Begin prefetch for the given prefetchedFileHandle. The function will return after
   prefetching completes. Any read error will stop prefetch. If, from another thread, a
   RMFPPrefetchStop(same prefetchedFileHandle) call succeds, prefetching will stop.

   If the RMfile passed as argument was not open with RMFPPrefetchOpenFile, the function
   will return error.

   @param PrefetchedFileHandle: a file handle opened with RMFPPrefetchOpenFile()

   @return
*/
RMstatus RMFPPrefetchStart(struct RMFPHandle *pHandle, RMfile PrefetchedFileHandle);

/**
   Does the same as RMFPPrefectStart, but adds a timeout.

   RMFPPrefectStart_WithTimeout will try to exit as soon as timeout (expressed in milliseconds)
   is reached or the prefect buffer is full.

   timeout does only provide a lower bound on how long this function will wait before
   exiting. Other than that there's no guarantee on the actual exit time, but using
   a non-blocking file handle it is safe to assume that it won't diverge much
   from timeout. Blocking handles however could take much more time and do not
   have a predictable behaviour regarding "exit time".

   Please refer to the documentation of the "Open" function you obtained your file
   handle from for more information on whether it supports non-blocking reads or not.

   A timeout value of 0 means no timeout, in this case this function behaves exactly as
   RMFPPrefetchStart

   When the timeout is reached but prefetch is not complete this function will return RM_PENDING.
   If you receive an RM_PENDING error you MUST deal with it one of the following way :
	* Either call RMFPPrefetchStart_WithTimeout again to continue prefetching
	* OR Call RMFPPrefetchStop to signal you wish to end prefetch and continue reading.

   Ignoring an RM_PENDING error will lead to unexpected consequences.

   @param PrefetchedFileHandle: a file handle opened with RMFPPrefetchOpenFile()
   @param Timeout: timeout value (in milliseconds)
   @return RM_PENDING if timeout was reached
*/
RMstatus RMFPPrefetchStart_WithTimeout(struct RMFPHandle *pHandle, RMfile PrefetchedFileHandle, RMuint32 timeout);


/**
   Stops prefetch for the given prefetchedFileHandle.

   If the RMfile passed as argument was not open with RMFPPrefetchOpenFile, the function
   will return error.

   @param PrefetchedFileHandle: a file handle opened with RMFPPrefetchOpenFile()

   @return
*/
RMstatus RMFPPrefetchStop(struct RMFPHandle *pHandle, RMfile PrefetchedFileHandle);

/****************************************************************************************************************/
/****************************************************************************************************************/
/*************************************** Custom PID Filter  *****************************************************/
/****************************************************************************************************************/
/****************************************************************************************************************/

enum RMFP_pid_type
{
	RMFP_pid_type_pat		= 123,
	RMFP_pid_type_pmt,
	RMFP_Pid_type_tvct,
	RMFP_Pid_type_cvct,
	RMFP_pid_type_video,
	RMFP_pid_type_audio,
	RMFP_pid_type_subpictures,
	RMFP_pid_type_pcr,
	RMFP_pid_type_bifs,
	RMFP_pid_type_od,
	RMFP_pid_type_ttx,
	RMFP_pid_type_ts,
	RMFP_pid_type_custom,
	RMFP_pid_type_input_record,
};

RM_TYPEDEF_FUNCTION_PTR(RMstatus,
			rmfp_demux_custom_pid_callback_type,
			RMuint8 *pBuffer1,
			RMuint32 size1,
			RMuint8 *pBuffer2,
			RMuint32 size2,
			void *pContext);
/*
 * PID filter parameters
 */
struct RMFPCustomPIDParameters {

	/*
	 * To create a new PID filter, all the following information must be passed
	 * To delete an existing PID filter, the PID and the callback only must be passed
	 */

	RMuint16 PID;					// PID to filter
	enum EMhwlibDataType_type	data_type;	// Data type

	rmfp_demux_custom_pid_callback_type callback;	// Callback to call with filtered data
	void* pCallbackContext;			// Context to be called in callback

	// Number of buffers and size to allocate for DMA pool. Also in this application the DemuxOutput has bts_fifo_size = buffer_count*(1<<buffer_size_log2)
	RMuint32			buffer_count;
	RMuint32			buffer_size_log2;

	// If partial_read is TRUE the microcode will signal event after one section/pes_packet is completed
	// If FALSE the event is signaled according to threshold's value
	RMbool				partial_read;
	RMuint32			threshold;

	// Number of pts and inband entries for the pts and inband fifos of the DemuxOutput
	RMuint32			pts_count;
	RMuint32			inband_count;

	enum DCCDemuxOutputType receive_data_type;
	union
	{
		enum DCCReceiveDataModeDma dma;
		enum DCCReceiveDataModeNoDma nodma;
	} receive_mode;
};

/*
 * Playback statistic
 */
struct RMFPPlaybackStatistic {
	RMuint64 dataRead;

	RMbool	 HasAudio;		// Has Valid Audio Stats
	RMbool	 HasVideo;		// Has Valid Video Stats

	RMuint64 VideoSent;		// Amount of elementary audio sent to decoder
	RMuint64 AudioSent;		// Amount of elementary video sent to decoder

	/* Corresponding instantaneous speeds in B/s */
	RMuint64 ReadSpeed;		// File read speed

	RMuint64 VideoSendSpeed;	// Elementary video send speed
	RMuint64 AudioSendSpeed;	// Elementary audio send speed

	/* Elementary Streams Bitrates in b/s */
	RMuint64 VideoInstantBitrate;
	RMuint64 VideoBitrate;

	RMuint64 AudioInstantBitrate;
	RMuint64 AudioBitrate;

	RMuint32 VideoFIFOFullness;	// Coarse Video FIFO Fullness in percent
	RMuint32 AudioFIFOFullness;	// Coarse Audio FIFO Fullness in percent

	RMuint32 VideoFIFOLength;	// Duration of bufferized Video Data
	RMuint32 AudioFIFOLength;	// Duration of bufferized Audio Data

	RMuint32 mVideoFIFOFullness;	// VideoFIFOFullness in milipercent (VideoFIFOFullness = mVideoFIFOFullness / 1000)
	RMuint32 mAudioFIFOFullness;	// AudioFIFOFullness in milipercent

	/* Interlaving ratios provide a measurement of the relative amounts of
	   audio/video data in the FIFOs over the last ten seconds of data.

	   Fullness Interleaving ratio "r" basically tells you that if the Video FIFO is full
	   then due to the audio bitrate, the Audio FIFO fullness can't be higher than 100/r

	   The regular Interlaving Ratio works using Audio/Video data size (instead of FIFO fullness)
	   and therefore is a good indicator of the ratio between the Video Birate and the Audio
	   Bitrate when these are not directly available.

	   The ratios are given on a 10^-3 scale.

	   You should expect this ratio stand between 1 to 1000, note that values below 1 would
	   be unusual but no unexpected.

	   If the file does not have video/audio, or the ratio is not available
	   these values are set to 0
	*/
	RMuint32 InterleavingRatio;
	RMuint32 FullnessInterleavingRatio;
};

/**
   Get playback statistic

   @param pHandle Library handle
   @param pStat   return playback statistic

   @return RMstatus
*/
RMstatus RMFPGetPlaybackStatistic(struct RMFPHandle *pHandle, struct RMFPPlaybackStatistic* pStat);
 

/**
   Create a custom PID filter.

   @param pHandle Library handle
   @param pParams PID filter parameters
   @param pPidHandle Returned handle to use to access the custom PID

   @return RMstatus
*/
RMstatus RMFPCreateCustomPIDFilter(struct RMFPHandle *pHandle, struct RMFPCustomPIDParameters* pParams, RMuint32 *pPidHandle);

/**
   Delete a custom PID filter.

   @param pHandle Library handle
   @param pPidHandle Custom PID handle to delete

   @return RMstatus
*/
RMstatus RMFPDeleteCustomPIDFilter(struct RMFPHandle *pHandle, RMuint32 PidHandle);

/**
   Add a section to a custom PID filter.

   @param pHandle Library handle
   @param pPidHandle Custom PID handle to modify
   @param pSection Section to add

   @return RMstatus
*/
RMstatus RMFPAddCustomPIDFilterSection(struct RMFPHandle *pHandle, RMuint32 PidHandle, struct PSFMatchSection_type* pSection);

/**
   Remove one of all sections from a custom PID filter.

   @param pHandle Library handle
   @param pPidHandle Custom PID handle to modify
   @param pSection Section to remove, passing NULL will remove all sections

   @return RMstatus
*/
RMstatus RMFPDeleteCustomPIDFilterSection(struct RMFPHandle *pHandle, RMuint32 PidHandle, struct PSFMatchSection_type* pSection);

RMstatus Rmfp_getAllowedCmdMask(const struct RMFPHandle *pRmfpHandle, RMuint32 * const pAllowedCmdMask);
RMstatus Rmfp_getPlaybackStatus(const struct RMFPHandle *pRmfpHandle, 
	struct RMFPPlaybackStatus * pRmfpPlaybackStatus);
RMstatus Rmfp_setRmlibplayPlaybackOpt_PrebufMax(struct RMFPHandle *pRmfpHandle, RMuint32 PrebufMaxSize);
RMstatus Rmfp_setRequestQuitPlay(struct RMFPHandle *pRmfpHandle, const RMbool bRequestQuitPlay);
#if 1/*added by lxj 2013-1-8*/
RMstatus Rmfp_setPauseAfterBuffering(struct RMFPHandle *pRmfpHandle, const RMbool bPauseAfterBuffering);
#endif

RM_EXTERN_C_BLOCKEND

#endif // __RMFP_H__
