#include <stdlib.h>
#include <unistd.h>
#include <math.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <assert.h>
#include "MediaPlayerApp.h"
#include <BaseErrDef.h>
#include <ErrPrintHelper.h>
#include <SignalInfo.h>
#include <signal.h>
#include "LinuxSignalHandlerEx.h"
#include <InvArgException.h>
#include <BaseErrException.h>
#include <DateTime.h>
#include <GenericTimer.h>
#include "MPGenericMsgId.h"
#include "DBusMessage.h"
#include "TransactionMsgData.h"
#include <StackBufString.h>
#include "Rtc.h"
#include <SystemTimezone.h>
#include <sys/timeb.h>
#include <sys/time.h>
#include <SystemSrvApi.h>
#include <SysBaseSrvApi.h>
#include <ThreadData.h>
#include <DevConnectionStatus.h>
#include "Api/MediaPlayerApi.h"
#include <NetAddrUtils.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <dirent2.h>

#define	PLAY_PrebufMax_NORMAL				(16*1024)		//16KB
#define	PLAY_PrebufMax_VideoSync			(1*1024*1024)	//1MB

static dbus_bool_t DBusAddWatchCb(DBusWatch * pDbusWatch, void * pData);
static void DBusRemoveWatchCb(DBusWatch * pDbusWatch, void * pData);

static LPCSTR g_pszMediaPlayer_Introspect =
	DBUS_INTROSPECT_1_0_XML_DOCTYPE_DECL_NODE
	"<node name=\"" DBUS_MPLAYER_OBJECT_PATH "\">\n"
	"	<interface name=\"org.freedesktop.DBus.Introspectable\">\n"
	"		<method name=\"Introspect\">\n"
	"			<arg name=\"data\" direction=\"out\" type=\"s\"/>\n"
	"		</method>\n"
	"	</interface>\n"
	"	<interface name=\"" DBUS_MPLAYER_OBJECT_INTERFACE "\">\n"
	"		<method name=\"setDataSource\">\n"
	"			<arg name=\"Url\" type=\"s\" direction=\"in\" />\n"
	"			<arg name=\"iOutRet\" type=\"i\" direction=\"out\" />\n"
	"		</method>\n"
	"		<method name=\"Prepare\">\n"
	"			<arg name=\"iOutRet\" type=\"i\" direction=\"out\" />\n"
	"		</method>\n"
	"		<method name=\"Play\">\n"
	"			<arg name=\"iOutRet\" type=\"i\" direction=\"out\" />\n"
	"			<arg name=\"PlaybackId\" type=\"u\" direction=\"out\" />\n"
	"		</method>\n"
	"		<method name=\"Play2\">\n"
	"			<arg name=\"LoopCount\" type=\"i\" direction=\"in\" />\n"
	"			<arg name=\"iOutRet\" type=\"i\" direction=\"out\" />\n"
	"			<arg name=\"PlaybackId\" type=\"u\" direction=\"out\" />\n"
	"		</method>\n"
	"		<method name=\"Stop\">\n"
	"			<arg name=\"iOutRet\" type=\"i\" direction=\"out\" />\n"
	"			<arg name=\"url\" type=\"s\" direction=\"out\" />\n"
	"			<arg name=\"playbackId\" type=\"u\" direction=\"out\" />\n"
	"		</method>\n"
	"		<method name=\"setVideoPosition\">\n"
	"			<arg name=\"x\" type=\"i\" direction=\"in\" />\n"
	"			<arg name=\"y\" type=\"i\" direction=\"in\" />\n"
	"			<arg name=\"Width\" type=\"i\" direction=\"in\" />\n"
	"			<arg name=\"Height\" type=\"i\" direction=\"in\" />\n"
	"			<arg name=\"iOutRet\" type=\"i\" direction=\"out\" />\n"
	"		</method>\n"
	"		<method name=\"setVideoInputWindowSize\">\n"
	"			<arg name=\"x\" type=\"i\" direction=\"in\" />\n"
	"			<arg name=\"y\" type=\"i\" direction=\"in\" />\n"
	"			<arg name=\"Width\" type=\"i\" direction=\"in\" />\n"
	"			<arg name=\"Height\" type=\"i\" direction=\"in\" />\n"
	"			<arg name=\"iOutRet\" type=\"i\" direction=\"out\" />\n"
	"		</method>\n"
	"		<method name=\"setOsdPosition\">\n"
	"			<arg name=\"x\" type=\"i\" direction=\"in\" />\n"
	"			<arg name=\"y\" type=\"i\" direction=\"in\" />\n"
	"			<arg name=\"Width\" type=\"i\" direction=\"in\" />\n"
	"			<arg name=\"Height\" type=\"i\" direction=\"in\" />\n"
	"			<arg name=\"iOutRet\" type=\"i\" direction=\"out\" />\n"
	"		</method>\n"
	"		<method name=\"ChangeVideoOutputMode\">\n"
	"			<arg name=\"VideoOutputMode\" type=\"i\" direction=\"in\" />\n"
	"			<arg name=\"iOutRet\" type=\"i\" direction=\"out\" />\n"
	"			<arg name=\"NewVideoOutputMode\" type=\"i\" direction=\"out\" />\n"
	"		</method>\n"
	"		<method name=\"setVideoOutputModeAsync\">\n"
	"			<arg name=\"VideoOutputMode\" type=\"i\" direction=\"in\" />\n"
	"			<arg name=\"iOutRet\" type=\"i\" direction=\"out\" />\n"
	"			<arg name=\"NewVideoOutputMode\" type=\"i\" direction=\"out\" />\n"
	"		</method>\n"
	"		<method name=\"setHwRtcTime\">\n"
	"			<arg name=\"Year\" type=\"i\" direction=\"in\" />\n"
	"			<arg name=\"Month\" type=\"i\" direction=\"in\" />\n"
	"			<arg name=\"Date\" type=\"i\" direction=\"in\" />\n"
	"			<arg name=\"Hour\" type=\"i\" direction=\"in\" />\n"
	"			<arg name=\"Minute\" type=\"i\" direction=\"in\" />\n"
	"			<arg name=\"Second\" type=\"i\" direction=\"in\" />\n"
	"			<arg name=\"TimeZone\" type=\"s\" direction=\"in\" />\n"
	"			<arg name=\"iOutRet\" type=\"i\" direction=\"out\" />\n"
	"		</method>\n"
	"		<method name=\"getTimeZoneSetting\">\n"
	"			<arg name=\"iOutRet\" type=\"i\" direction=\"out\" />\n"
	"			<arg name=\"TimezoneHourOff\" type=\"i\" direction=\"out\" />\n"
	"		</method>\n"
	"		<method name=\"setTimeZoneSetting\">\n"
	"			<arg name=\"TimezoneHourOff\" type=\"i\" direction=\"in\" />\n"
	"			<arg name=\"iOutRet\" type=\"i\" direction=\"out\" />\n"
	"		</method>\n"
	"		<method name=\"setGpioLedStatus\">\n"
	"			<arg name=\"GpioLedStatus\" type=\"u\" direction=\"in\" />\n"
	"			<arg name=\"iOutRet\" type=\"i\" direction=\"out\" />\n"
	"			<arg name=\"ActualLedStatus\" type=\"u\" direction=\"out\" />\n"
	"		</method>\n"
	"		<method name=\"DisplayOnLedScreen\">\n"
	"			<arg name=\"ContentToDisp\" type=\"s\" direction=\"in\" />\n"
	"			<arg name=\"StartPos\" type=\"i\" direction=\"in\" />\n"
	"			<arg name=\"iOutRet\" type=\"i\" direction=\"out\" />\n"
	"		</method>\n"
	"		<method name=\"DispOnLedScrAsync\">\n"
	"			<arg name=\"ContentToDisp\" type=\"s\" direction=\"in\" />\n"
	"			<arg name=\"StartPos\" type=\"i\" direction=\"in\" />\n"
	"			<arg name=\"iOutRet\" type=\"i\" direction=\"out\" />\n"
	"		</method>\n"
	"		<method name=\"getMonitorInfo\">\n"
	"			<arg name=\"iOutRet\" type=\"i\" direction=\"out\" />\n"
	"			<arg name=\"MonitorType\" type=\"s\" direction=\"out\" />\n"
	"		</method>\n"
	"		<method name=\"setMonitorType\">\n"
	"			<arg name=\"eMonitorType\" type=\"i\" direction=\"in\" />\n"
	"			<arg name=\"iOutRet\" type=\"i\" direction=\"out\" />\n"
	"		</method>\n"
	"		<method name=\"getMonitorType\">\n"
	"			<arg name=\"iOutRet\" type=\"i\" direction=\"out\" />\n"
	"			<arg name=\"eMonitorType\" type=\"i\" direction=\"out\" />\n"
	"		</method>\n"
	"		<method name=\"setPlayMode\">\n"
	"			<arg name=\"PlayMode\" type=\"i\" direction=\"in\" />\n"
	"			<arg name=\"iOutRet\" type=\"i\" direction=\"out\" />\n"
	"		</method>\n"
	"		<method name=\"getPlayMode\">\n"
	"			<arg name=\"iOutRet\" type=\"i\" direction=\"out\" />\n"
	"			<arg name=\"PlayMode\" type=\"i\" direction=\"out\" />\n"
	"		</method>\n"
	"		<method name=\"setDisplayParam\">\n"
	"			<arg name=\"eDispParamType\" type=\"i\" direction=\"in\" />\n"
	"			<arg name=\"iValue\" type=\"i\" direction=\"in\" />\n"
	"			<arg name=\"bSaveCfg\" type=\"i\" direction=\"in\" />\n"
	"			<arg name=\"iOutRet\" type=\"i\" direction=\"out\" />\n"
	"		</method>\n"
	"		<method name=\"getDisplayParam\">\n"
	"			<arg name=\"eDispParamType\" type=\"i\" direction=\"in\" />\n"
	"			<arg name=\"iOutRet\" type=\"i\" direction=\"out\" />\n"
	"			<arg name=\"CurPercent\" type=\"i\" direction=\"out\" />\n"
	"		</method>\n"
	"		<method name=\"getDisplayPosition\">\n"
	"			<arg name=\"DisplayType\" type=\"i\" direction=\"in\" />\n"
	"			<arg name=\"iOutRet\" type=\"i\" direction=\"out\" />\n"
	"			<arg name=\"x\" type=\"i\" direction=\"out\" />\n"
	"			<arg name=\"y\" type=\"i\" direction=\"out\" />\n"
	"			<arg name=\"w\" type=\"i\" direction=\"out\" />\n"
	"			<arg name=\"h\" type=\"i\" direction=\"out\" />\n"
	"		</method>\n"
	"		<method name=\"setPlaySpeedCtrlAsync\">\n"
	"			<arg name=\"Speed\" type=\"i\" direction=\"in\" />\n"
	"			<arg name=\"iOutRet\" type=\"i\" direction=\"out\" />\n"
	"		</method>\n"
	"		<method name=\"getPlaySpeedCtrl\">\n"
	"			<arg name=\"iOutRet\" type=\"i\" direction=\"out\" />\n"
	"			<arg name=\"Speed\" type=\"i\" direction=\"out\" />\n"
	"		</method>\n"
	"		<method name=\"setCurClkTicks\">\n"
	"			<arg name=\"ClkTicks\" type=\"i\" direction=\"in\" />\n"
	"			<arg name=\"iOutRet\" type=\"i\" direction=\"out\" />\n"
	"		</method>\n"
	"		<method name=\"ChangeVolume\">\n"
	"			<arg name=\"PercentToChange\" type=\"i\" direction=\"in\" />\n"
	"			<arg name=\"iOutRet\" type=\"i\" direction=\"out\" />\n"
	"			<arg name=\"LastActualVolume\" type=\"i\" direction=\"out\" />\n"
	"		</method>\n"
	"		<method name=\"getCurClkTicks\">\n"
	"			<arg name=\"iOutRet\" type=\"i\" direction=\"out\" />\n"
	"			<arg name=\"ClkTicks\" type=\"i\" direction=\"out\" />\n"
	"		</method>\n"
	"		<method name=\"setConfigDateTime\">\n"
	"			<arg name=\"iReserved\" type=\"i\" direction=\"in\" />\n"
	"			<arg name=\"iOutRet\" type=\"i\" direction=\"out\" />\n"
	"		</method>\n"
	"		<method name=\"getConfigDateTime\">\n"
	"			<arg name=\"iOutRet\" type=\"i\" direction=\"out\" />\n"
	"			<arg name=\"iReserved\" type=\"i\" direction=\"out\" />\n"
	"		</method>\n"
	"		<method name=\"setVideoDispAspectRatio\">\n"
	"			<arg name=\"iDispAspectRatio\" type=\"i\" direction=\"in\" />\n"
	"			<arg name=\"OptFlag\" type=\"u\" direction=\"in\" />\n"
	"			<arg name=\"iOutRet\" type=\"i\" direction=\"out\" />\n"
	"		</method>\n"
	"		<method name=\"setOutputSpdifMode\">\n"
	"			<arg name=\"iOutputSpdifMode\" type=\"i\" direction=\"in\" />\n"
	"			<arg name=\"iOutRet\" type=\"i\" direction=\"out\" />\n"
	"		</method>\n"
	"		<method name=\"getOutputSpdifMode\">\n"
	"			<arg name=\"iOutRet\" type=\"i\" direction=\"out\" />\n"
	"			<arg name=\"iOutputSpdifMode\" type=\"i\" direction=\"out\" />\n"
	"		</method>\n"
#if 1/*added by lxj 2012-9-18*/
	"		<method name=\"getVideoDispAspectRatio\">\n"
	"			<arg name=\"iOutRet\" type=\"i\" direction=\"out\" />\n"
	"			<arg name=\"iDispAspectRatio\" type=\"i\" direction=\"out\" />\n"
	"		</method>\n"
#endif
	"		<method name=\"getCpuSerialNo\">\n"
	"			<arg name=\"iOutRet\" type=\"i\" direction=\"out\" />\n"
	"			<arg name=\"CpuSerialNo\" type=\"s\" direction=\"out\" />\n"
	"		</method>\n"
	"		<method name=\"setHdmi3DTvMode\">\n"
	"			<arg name=\"eHdmi3DTvMode\" type=\"i\" direction=\"in\" />\n"
	"			<arg name=\"iOutRet\" type=\"i\" direction=\"out\" />\n"
	"		</method>\n"
	"		<method name=\"setAnalogAudioMute\">\n"
	"			<arg name=\"bMute\" type=\"i\" direction=\"in\" />\n"
	"			<arg name=\"iOutRet\" type=\"i\" direction=\"out\" />\n"
	"		</method>\n"
	"		<signal name=\"PlaybackEos\">\n"
	"			<arg name=\"CurPlayUrl\" direction=\"out\" type=\"s\"/>\n"
	"			<arg name=\"PlaybackId\" direction=\"out\" type=\"u\"/>\n"
	"		</signal>\n"
	"		<signal name=\"PlaybackEos2\">\n"
	"			<arg name=\"CurPlayUrl\" direction=\"out\" type=\"s\"/>\n"
	"			<arg name=\"PlaybackId\" direction=\"out\" type=\"u\"/>\n"
	"			<arg name=\"CompletePlaybackEos\" direction=\"out\" type=\"i\"/>\n"
	"		</signal>\n"
	"		<signal name=\"PlayNextFile\">\n"
	"		<arg name=\"iOutRet\" type=\"i\" direction=\"out\" />\n"
	"		</signal>\n"
	"		<signal name=\"VidOutModeChanged\">\n"
	"			<arg name=\"CurMode\" direction=\"out\" type=\"i\"/>\n"
	"		</signal>\n"
#if 1/*added by lxj 2012-11-22*/
	"		<method name=\"getVideoSyncMode\">\n"
	"			<arg name=\"iOutRet\" type=\"i\" direction=\"out\" />\n"
	"			<arg name=\"eVideoSyncMode\" type=\"i\" direction=\"out\" />\n"
	"		</method>\n"
	"		<method name=\"getVideoSyncMaster\">\n"
	"			<arg name=\"iOutRet\" type=\"i\" direction=\"out\" />\n"
	"			<arg name=\"strVideoSyncMaster\" type=\"s\" direction=\"out\" />\n"
	"		</method>\n"
	"		<method name=\"setVideoSyncMode\">\n"
	"			<arg name=\"eVideoSyncMode\" type=\"i\" direction=\"in\" />\n"
	"			<arg name=\"iOutRet\" type=\"i\" direction=\"out\" />\n"
	"		</method>\n"
	"		<method name=\"setVideoSyncMaster\">\n"
	"			<arg name=\"strVideoSyncMaster\" type=\"s\" direction=\"in\" />\n"
	"			<arg name=\"iOutRet\" type=\"i\" direction=\"out\" />\n"
	"		</method>\n"
#endif
	"		<method name=\"setHdmiCecCtrl\">\n"
	"			<arg name=\"Command\" type=\"i\" direction=\"in\" />\n"
	"			<arg name=\"iOutRet\" type=\"i\" direction=\"out\" />\n"
	"		</method>\n"
#ifdef ENABLE_DTV
	"		<signal name=\"PlayTuner\">\n"
	"			<arg name=\"iOutRet\" type=\"i\" direction=\"out\" />\n"
	"			<arg name=\"PlaybackId\" type=\"u\" direction=\"out\" />\n"
	"		</signal>\n"
	"		<signal name=\"GetTunerChannelStrength\">\n"
	"			<arg name=\"Strength\" type=\"u\" direction=\"out\" />\n"
	"			<arg name=\"iOutRet\" type=\"i\" direction=\"out\" />\n"
	"		</signal>\n"
	"		<signal name=\"ResetDuration\">\n"
	"			<arg name=\"iOutRet\" type=\"i\" direction=\"out\" />\n"
	"		</signal>\n"
	"		<signal name=\"ChannelUp\">\n"
	"			<arg name=\"iOutRet\" type=\"i\" direction=\"out\" />\n"
	"		</signal>\n"
	"		<signal name=\"ChannelDown\">\n"
	"			<arg name=\"iOutRet\" type=\"i\" direction=\"out\" />\n"
	"		</signal>\n"
	"		<signal name=\"TunerMode\">\n"
	"			<arg name=\"iStandMode\" type=\"i\" direction=\"in\" />\n"
	"			<arg name=\"iOutRet\" type=\"i\" direction=\"out\" />\n"
	"		</signal>\n"
	"		<signal name=\"GetTunerMode\">\n"
	"			<arg name=\"OutStandMode\" type=\"i\" direction=\"out\" />\n"
	"			<arg name=\"iOutRet\" type=\"i\" direction=\"out\" />\n"
	"		</signal>\n"
	"		<signal name=\"TunerScan\">\n"
	"			<arg name=\"iOutRet\" type=\"i\" direction=\"out\" />\n"
	"		</signal>\n"
	"		<signal name=\"NotifyScanProgress\">\n"
	"			<arg name=\"PgmNum\" type=\"u\" direction=\"out\" />\n"
	"			<arg name=\"Progress\" type=\"u\" direction=\"out\" />\n"
	"		</signal>\n"
	"		<signal name=\"NotifyTuPlayerPropmtMsg\">\n"
	"			<arg name=\"MsgTag\" type=\"u\" direction=\"out\" />\n"
	"		</signal>\n"
	"		<signal name=\"Tuner_StartScan\">\n"
	"			<arg name=\"iOutRet\" type=\"i\" direction=\"out\" />\n"
	"		</signal>\n"
	"		<signal name=\"Tuner_StopScan\">\n"
	"			<arg name=\"iOutRet\" type=\"i\" direction=\"out\" />\n"
	"		</signal>\n"
	"		<signal name=\"Get_EntryChannelInfo\">\n"
	"			<arg name=\"iOutRet\" type=\"i\" direction=\"out\" />\n"
	"			<arg name=\"iEntryId\" type=\"i\" direction=\"in\" />\n"
	"			<arg name=\"channelNumer\" type=\"i\" direction=\"out\" />\n"
	"			<arg name=\"subChannelCount\" type=\"i\" direction=\"out\" />\n"
	"			<arg name=\"strProgramPids\" type=\"s\" direction=\"out\" />\n"
	"		</signal>\n"
	"		<signal name=\"GetFirstChNumber\">\n"
	"			<arg name=\"major\" type=\"u\" direction=\"out\" />\n"
	"			<arg name=\"minor\" type=\"u\" direction=\"out\" />\n"
	"			<arg name=\"iOutRet\" type=\"i\" direction=\"out\" />\n"
	"		</signal>\n"
	"		<signal name=\"GetForceTxMode\">\n"
	"			<arg name=\"iOutRet\" type=\"i\" direction=\"out\" />\n"
	"			<arg name=\"bEnableTuner\" type=\"i\" direction=\"out\" />\n"
	"		</signal>\n"
	"		<signal name=\"setTunerChannelMode\">\n"
	"			<arg name=\"iOutRet\" type=\"i\" direction=\"out\" />\n"
	"			<arg name=\"iTunerChMode\" type=\"i\" direction=\"in\" />\n"
	"		</signal>\n"
	"		<signal name=\"getTunerChannelMode\">\n"
	"			<arg name=\"iOutRet\" type=\"i\" direction=\"out\" />\n"
	"			<arg name=\"iTunerChMode\" type=\"i\" direction=\"out\" />\n"
	"		</signal>\n"
#endif
	"		<method name=\"setShowClosedCaption\">\n"
	"			<arg name=\"iParamSelection\" type=\"i\" direction=\"in\" />\n"
	"			<arg name=\"iOutRet\" type=\"i\" direction=\"out\" />\n"
	"		</method>\n"
	"	</interface>\n"
	"</node>\n";

#define	TIMER_ChkVcrDefaultSurface_INTERVAL_MS		(2*1000)

CMediaPlayerApp::CPollingFdInfo::CPollingFdInfo()
{
	FD_ZERO(&m_FdsRead);
	FD_ZERO(&m_FdsWrite);
	FD_ZERO(&m_FdsExcept);
	m_iMaxFd = 0;
}

INT_t CMediaPlayerApp::CPollingFdInfo::FixPollingFdset(CIntArray & BadFd_Array)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet, iFdIndex;
	struct timeval TimeoutVal;

	TimeoutVal.tv_sec = 0;
	TimeoutVal.tv_usec = 0;

	do
	{
		BadFd_Array.RemoveAll();
		for(iFdIndex = 0; iFdIndex <= m_iMaxFd; iFdIndex++)
		{
			if(FD_ISSET(iFdIndex, &m_FdsRead) || FD_ISSET(iFdIndex, &m_FdsWrite) || FD_ISSET(iFdIndex, &m_FdsExcept))
			{
				fd_set fdsRead;
				FD_ZERO(&fdsRead);
				FD_SET(iFdIndex, &fdsRead);
				iRet = select(iFdIndex+1, &fdsRead, NULL, NULL, &TimeoutVal);
				if(0 > iRet)
				{
					LOG_BLINE("BadFd %d\n", iFdIndex);
					FD_CLR(iFdIndex, &m_FdsRead);
					FD_CLR(iFdIndex, &m_FdsWrite);
					FD_CLR(iFdIndex, &m_FdsExcept);
					iRet = BadFd_Array.Add(iFdIndex);
					if(ERROR_SUCCESS != iRet)
					{
						PRINT_BFILE_LINENO_IRET_STR;
					}
				}
			}
		}
	}while(FALSE);

	return iOutRet;
}

CMediaPlayerApp::CMediaPlayerApp(int argc, char * argv[]) :  CGeneralApp(argc, argv)
{
	INT_t iRet;

	m_bShouldExitApp = FALSE;
	m_pDBusConn = NULL;
	m_bDBusNeedShutdown = FALSE;
	m_HdmiHotplugChkTimerId = 0;	//invalid
	m_VolumeSaveTimerId = 0;
	m_DelayedSet_VcrDefaultSurface_TimerId = 0;
	m_VolumePercent = 0;
	m_bNotRunMainLoop = FALSE;
	SerialPortParamVal_Init(&m_SerialPortParam);
	FD_ZERO(&m_fdsDbusComm);

	m_AppCmdLineArgs_sp = SharedPtr <CCmdLineArgument> (new CCmdLineArgument(argc, argv));

	iRet = RegDbgLogSwitch();
	if(ERROR_SUCCESS != iRet)
	{
		PRINT_BFILE_LINENO_IRET_STR;
	}
}

CMediaPlayerApp::~CMediaPlayerApp()
{
	INT_t iRet;

	if(m_bDBusNeedShutdown)
	{
		m_bDBusNeedShutdown = FALSE;
		dbus_shutdown();
	}

	iRet = UnregDbgLogSwitch();
	if(ERROR_SUCCESS != iRet)
	{
		PRINT_BFILE_LINENO_IRET_STR;
	}
}

/* /proc/asound/devices
  2:        : timer
  3:        : sequencer
  4: [ 0- 0]: digital audio playback
  5: [ 0- 0]: digital audio capture
  6: [ 0]   : control
  7: [ 1- 0]: digital audio capture
  8: [ 1]   : control
  9: [ 2- 0]: digital audio playback
 10: [ 2]   : control
*/
static int IsE15Board()
{
	const char *devAudioPlayback =  "playback";
	const char *devAudioCapture  =  "capture";
	char buff[1024];
	int playback = 0, capture = 0;

    FILE *fp = fopen("/proc/asound/devices", "r");

    if (fp != NULL) {
        while (fgets(buff, sizeof(buff), fp)) {
			buff[sizeof(buff)-1] = '\0';
			const char *p;
            if ((buff[0] == '\0') || (buff[1] == '\0'))
                continue;

			p = strstr(buff, "digital audio ");
            if (p) {
				p += 14;
				if (strncmp(p, "playback", 8) == 0)
					playback++;
				else if (strncmp(p, "capture", 7) == 0)
					capture++;
			}
		}

        fclose(fp);
	}

	// LOG_BLINE("AudioDevice: playback=%d, capture=%d\n", playback, capture);
	return (playback >= 2 || capture >= 2) ? 1 : 0;
}

INT_t CMediaPlayerApp::InitInstance()
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	bool bRet;

	do
	{
		iRet = CLinuxSignalHandlerEx::HookSignal(SIGINT, SigHandler, (PVOID)(this));
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = ERR_HOOK_SIGNAL_FAIL;
			PRINT_BFILE_LINENO_IRET_STR;
			break;
		}
		iRet = CLinuxSignalHandlerEx::HookSignal(SIGTERM, SigHandler, (PVOID)(this));
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = ERR_HOOK_SIGNAL_FAIL;
			PRINT_BFILE_LINENO_IRET_STR;
			break;
		}
		iRet = CLinuxSignalHandlerEx::HookSignal(SIGQUIT, SigHandler, (PVOID)(this));
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = ERR_HOOK_SIGNAL_FAIL;
			PRINT_BFILE_LINENO_IRET_STR;
			break;
		}
		iRet = CLinuxSignalHandlerEx::HookSignal(SIGCHLD, SigHandler, (PVOID)(this));
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = ERR_HOOK_SIGNAL_FAIL;
			PRINT_BFILE_LINENO_IRET_STR;
			break;
		}
 		{
			sighandler_t pOldSigHandler = SIG_ERR;
			pOldSigHandler = signal(SIGRTMIN, SIG_IGN);
			if(SIG_ERR == pOldSigHandler)
			{
				PRINT_BFILE_LINENO_CRT_ERRINFO;
			}
		}

		m_oMediaSrv_sp = SharedPtr <CMediaSrv> (new CMediaSrv);
		if(m_oMediaSrv_sp.isNull())
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}
		m_oMediaSrv_sp->m_this_wp = m_oMediaSrv_sp;

		if(m_AppCmdLineArgs_sp->ExistArg(CMD_LINE_NotApplyDispOpt))
		{
			//LOG_BLINE("NotApplyDispOpt\n");
			m_oMediaSrv_sp->m_bNotApplyDispOpt = TRUE;
		}
		if(m_AppCmdLineArgs_sp->ExistArg(CMD_LINE_DisableVcrMixerSrc))
		{
			m_oMediaSrv_sp->m_bDisableVcrMixerSrc = TRUE;
		}
		if(m_AppCmdLineArgs_sp->ExistArg(CMD_LINE_NotRunMainLoop))
		{
			m_bNotRunMainLoop = TRUE;
		}
		if(m_AppCmdLineArgs_sp->ExistArg(CMD_LINE_DoInitForDualSplitDisp))
		{
			m_bOnlyDoInitForDualSplitDisp = TRUE;
		}

		m_SettingXmlDoc_sp = SharedPtr <TiXmlDocument2> (new TiXmlDocument2);
		if(m_SettingXmlDoc_sp.isNull())
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}

		//register event loop interface
		do
		{
			SharedPtr <CThreadData> ThreadData_sp = getThreadData();
			if(ThreadData_sp.isNull())
			{
				LOG_BLINE("getThreadData failed\n");
				break;
			}
			iRet = ThreadData_sp->setEvtLoopIf(m_this_wp);
			if(ERROR_SUCCESS != iRet)
			{
				PRINT_BFILE_LINENO_IRET_STR;
				break;
			}
		}while(FALSE);

		do
		{
			DECLARE_CLS_STACK_BUF_STRING(strSerialParameters, 64);
			iRet = SysProp_get(SysProp_KEY_SerialParameters, OUT strSerialParameters);
			if(ERROR_SUCCESS != iRet)
			{
				if(ERROR_NOT_FOUND != iRet)
				{
					PRINT_BFILE_LINENO_IRET_STR;
				}
				break;
			}
			iRet = SerialPortParamDesc_To_ParamValue(strSerialParameters, &m_SerialPortParam);
			if(ERROR_SUCCESS != iRet)
			{
				PRINT_BFILE_LINENO_IRET_STR;
				break;
			}
		}while(FALSE);
		//Open the ttyS1
		m_SerialComPort_sp = SharedPtr <CSerialComPort> (new CSerialComPort);
		if(m_SerialComPort_sp.isNull())
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}
		m_SerialComPort_sp->m_this_wp = m_SerialComPort_sp;
		do
		{
			iRet = m_SerialComPort_sp->Open(SerialComPort_DevPath);
			if(ERROR_SUCCESS != iRet)
			{
				PRINT_BFILE_LINENO_IRET_CRT_ERR;
				break;
			}
			//set baudrate, etc.
			iRet = m_SerialComPort_sp->setComParameters(m_SerialPortParam.iBaudrate,
				m_SerialPortParam.eSerialParity, m_SerialPortParam.iDataBits, m_SerialPortParam.iStopBits);
			if(ERROR_SUCCESS != iRet)
			{
				PRINT_BFILE_LINENO_IRET_CRT_ERR;
				break;
			}
		}while(FALSE);

		bRet = m_SettingXmlDoc_sp->LoadFile(MP_SETTING_XML_DOC_PATH);
		if(true == bRet)
		{
			CString strValue;
			DECLARE_CLS_STACK_BUF_STRING(strDefValue, 32);
			iRet = m_SettingXmlDoc_sp->getElementPropertyValue(XML_VOLUME_ELEMENT_PATH,
				AUD_ENG0_MASTER_NAME, OUT strValue, "30");
			if(ERROR_SUCCESS == iRet)
			{
				m_VolumePercent = atoi(strValue);
			}
			else
			{
				PRINT_BFILE_LINENO_IRET_STR;
			}
			//Video output mode
			iRet = strDefValue.Format("%d", VO_MODE_HDMI_720p50);
			if(ERROR_SUCCESS != iRet)
			{
				PRINT_BFILE_LINENO_IRET_STR;
			}
			iRet = m_SettingXmlDoc_sp->getElementPropertyValue(XML_DispParam_Ele_PATH, PropDesc_VoMode, OUT strValue, strDefValue);
			if(ERROR_SUCCESS == iRet)
			{
				VIDEO_OUTPUT_MODE eVoMode = (typeof(eVoMode))atoi(strValue);
				m_oMediaSrv_sp->m_eVoMode = eVoMode;
				//LOG_BLINE("strValue:%s\n", (LPCSTR)strValue);
			}
			else
			{
				PRINT_BFILE_LINENO_IRET_STR;
			}
		}
		else
		{
			LOG_BLINE("Failed to load %s\n", MP_SETTING_XML_DOC_PATH);
		}

		{
			if(FALSE == dbus_threads_init_default())
			{
				iOutRet = ERROR_OUT_OF_MEMORY;
				break;
			}
			m_bDBusNeedShutdown = TRUE;
		}

		{
			iRet = ConnectDBus();
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
				LOG("ConnectDBus err(%d)\n", iRet);
				break;
			}
			iRet = setDBusService();
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
				LOG("setDBusService err(%d)\n", iRet);
				break;
			}
		}

		iRet = UpdateDeviceMountStatusFromSysProp();
		if(ERROR_SUCCESS != iRet)
		{
			PRINT_BFILE_LINENO_IRET_STR;
		}

        if (IsE15Board()) {
            LOG("BoardName: e15-smp8671\n");

            // e15-board: gpio init
            CSmp86xxGpioCtrl gpioCtrl;
			do
			{
	            if (FALSE == gpioCtrl.ChkInit()) {
	                LOG_BLINE("gpioCtrl.Init() failed\n");
	                break;
	            }

	            // enable: loud speaker
	            iRet = gpioCtrl.setGpioDirection(GPIOId_Sys_9, GPIO_OUTPUT);
	            if (ERROR_SUCCESS != iRet) {
					PRINT_BFILE_LINENO_IRET_STR;
	                break;
	            }
	            iRet = gpioCtrl.setGpioData(GPIOId_Sys_9, 0);
	            if (ERROR_SUCCESS != iRet) {
					PRINT_BFILE_LINENO_IRET_STR;
	                break;
	            }
			}while(FALSE);
        }

		iRet = m_oMediaSrv_sp->InitInstance();
		if(ERROR_SUCCESS != iRet)
		{
            iOutRet = iRet;
            break;
		}

		iRet = m_oMediaSrv_sp->setEventListener((WeakPtr<IMediaSrvEventListener>)m_this_wp);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}
#ifdef ENABLE_DTV
		iRet = m_oMediaSrv_sp->SetScanProgressListner((WeakPtr<IMediaSrvScanProgressListener>)m_this_wp);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}
#endif
		//set the previous saved volume
		iRet = setVolume(m_VolumePercent);
		if(ERROR_SUCCESS != iRet)
		{
			PRINT_BFILE_LINENO_IRET_STR;
		}
		//Start the MediaSrv
		iRet = m_oMediaSrv_sp->StartThread();
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}

		iRet = m_GenericTimer.RegisterTimer((WeakPtr<ITimerListener>)m_this_wp, OUT m_HdmiHotplugChkTimerId, 150/*ms*/);
		if(ERROR_SUCCESS != iRet)
		{
			PRINT_BFILE_LINENO_IRET_STR;
		}

		iRet = m_GenericTimer.RegisterTimer((WeakPtr<ITimerListener>)m_this_wp, OUT m_DelayedSet_VcrDefaultSurface_TimerId, 
			TIMER_ChkVcrDefaultSurface_INTERVAL_MS/*ms*/);
		if(ERROR_SUCCESS != iRet)
		{
			PRINT_BFILE_LINENO_IRET_STR;
		}

		OnChk_DelayedSet_VcrDefaultSurface();

		m_GraphScreen_sp = SharedPtr <CGraphicsScreen> (new CGraphicsScreen);
		if(m_GraphScreen_sp.isNull())
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}

		//Load and apply DispParam from the config file
		applyDisplayParamsFromCfg();

#if 1/*added by lxj 2012-12-29*/
		m_VideoSync_sp = SharedPtr <CVideoSync> (new CVideoSync(m_oMediaSrv_sp));
		if(m_VideoSync_sp.isNull()){
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}else{
			m_VideoSync_sp->m_this_wp = m_VideoSync_sp;
			iRet = m_VideoSync_sp->InitInstance();
			if( ERROR_SUCCESS != iRet ){
				iOutRet = iRet;
				PRINT_BFILE_LINENO_IRET_CRT_ERR;
				break;
			}
		}
#endif
	}while(FALSE);

	return iOutRet;
}

INT_t CMediaPlayerApp::ExitInstance()
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;

	do
	{
#if 1/*added by lxj 2012-12-29*/
		if(m_VideoSync_sp.isValid()){
			m_VideoSync_sp->ExitInstance();
		}
#endif

		if(0 < m_HdmiHotplugChkTimerId)
		{
			iRet = m_GenericTimer.UnregisterTimer(m_HdmiHotplugChkTimerId);
			if(ERROR_SUCCESS != iRet)
			{
				LOG_BLINE("iRet=%d,TimerId=%u\n", iRet, m_HdmiHotplugChkTimerId);;
			}
			m_HdmiHotplugChkTimerId = 0;
		}

		if(0 < m_DelayedSet_VcrDefaultSurface_TimerId)
		{
			iRet = m_GenericTimer.UnregisterTimer(m_DelayedSet_VcrDefaultSurface_TimerId);
			if(ERROR_SUCCESS == iRet)
			{
				m_DelayedSet_VcrDefaultSurface_TimerId = 0;
			}
			else
			{
				LOG_BLINE("iRet=%d,TimerId=%u\n", iRet, m_DelayedSet_VcrDefaultSurface_TimerId);;
			}
		}

		if(m_oMediaSrv_sp.isValid())
		{
			//Stop the MediaSrv
			iRet = m_oMediaSrv_sp->StopThread();
			if(ERROR_SUCCESS != iRet)
			{
				PRINT_BFILE_LINENO_IRET_STR;
			}

			iRet = m_oMediaSrv_sp->ExitInstance();
			if(ERROR_SUCCESS != iRet)
			{
				PRINT_BFILE_LINENO_IRET_STR;
			}
		}

		if(m_SerialComPort_sp.isValid())
		{
			m_SerialComPort_sp->Close();
		}

		{
			iRet = unsetDBusService();
			if(ERROR_SUCCESS != iRet)
			{
				PRINT_BFILE_LINENO_IRET_STR;
			}
			iRet = disconnectDBus();
			if(ERROR_SUCCESS != iRet)
			{
				PRINT_BFILE_LINENO_IRET_STR;
			}
		}
		if(m_bDBusNeedShutdown)
		{
			m_bDBusNeedShutdown = FALSE;
			dbus_shutdown();
		}
	}while(FALSE);

	return iOutRet;
}

VOID CMediaPlayerApp::SigHandler(VOID * pCbContext, int SigNo)
{
	CMediaPlayerApp * pApp = (typeof(pApp))pCbContext;
	pApp->OnLinuxSignal(SigNo);
}

VOID CMediaPlayerApp::OnLinuxSignal(int SigNo)
{
	LOG("(%d)Signal:%s\n", getpid(), CSignalInfo::GetSingalDescFromSigNo(SigNo));
	if(SIGINT == SigNo || SIGTERM == SigNo || SIGQUIT == SigNo)
	{
		NotifyExitApp();
	}
}

INT_t CMediaPlayerApp::Run()
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;

	do
	{
		iRet = MainLoop();
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}
	}while(FALSE);

	return iOutRet;
}

VOID CMediaPlayerApp::OnTimer(UINT_t TimerId)
{
	INT_t iRet;

	if(TimerId == m_HdmiHotplugChkTimerId)
	{
		OnHdmiHotplugChk();
	}
	else if(m_VolumeSaveTimerId == TimerId)
	{
		if(0 < m_VolumeSaveTimerId)
		{
			iRet = m_GenericTimer.UnregisterTimer(m_VolumeSaveTimerId);
			if(ERROR_SUCCESS != iRet)
			{
				PRINT_BFILE_LINENO_IRET_STR;
			}
			m_VolumeSaveTimerId = 0;
		}
		OnSaveVolume();
	}
	else if(m_DelayedSet_VcrDefaultSurface_TimerId == TimerId)
	{
		OnChk_DelayedSet_VcrDefaultSurface();
	}
	else
	{
		LOG_BLINE("BUG,unprocessed timer id(%u)\n", TimerId);
	}
}

//Callback
/*
ThreadContext: PlayThread
*/
INT_t CMediaPlayerApp::PlaybackStart()
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	SharedPtr<CMessageQueueItem> MsgItem_sp(new CMessageQueueItem);
	SharedPtr <CGenericMsgData> MsgData_sp;
	SharedPtr <CMsgData_PlaybackStart> MsgData_PlaybackStart_sp(new CMsgData_PlaybackStart);

	do
	{
		if(MsgItem_sp.isNull() || MsgData_PlaybackStart_sp.isNull())
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}
		MsgData_PlaybackStart_sp->m_uiMsgId = MP_MSG_PLAYBACK_START;
		MsgData_sp = MsgData_PlaybackStart_sp;
		iRet = MsgItem_sp->SetMessageData(MsgData_sp);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}
		iRet = PostMessage(MsgItem_sp);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}
	}while(FALSE);

	return iOutRet;
}

#if 1/*added by lxj 2013-1-4*/
//Callback
/*
ThreadContext: PlayThread
*/
INT_t CMediaPlayerApp::PlaybackReadyToPlay()
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	SharedPtr<CMessageQueueItem> MsgItem_sp(new CMessageQueueItem);
	SharedPtr <CGenericMsgData> MsgData_sp;
	SharedPtr <CMsgData_PlaybackStart> MsgData_PlaybackStart_sp(new CMsgData_PlaybackStart);

	do
	{
		if(MsgItem_sp.isNull() || MsgData_PlaybackStart_sp.isNull())
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}
		MsgData_PlaybackStart_sp->m_uiMsgId = MP_MSG_PLAYBACK_READY_TO_PLAY;
		MsgData_sp = MsgData_PlaybackStart_sp;
		iRet = MsgItem_sp->SetMessageData(MsgData_sp);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}
		iRet = PostMessage(MsgItem_sp);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}
	}while(FALSE);

	return iOutRet;
}
#endif

//Callback
/*
ThreadContext: PlayThread
*/
INT_t CMediaPlayerApp::PlaybackEos(LPCSTR pszFileName, UINT32_t PlaybackId, BOOL_t bIsCompletePlaybackEos)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	SharedPtr<CMessageQueueItem> MsgItem_sp(new CMessageQueueItem);
	SharedPtr <CGenericMsgData> MsgData_sp;
	SharedPtr <CMsgData_PlaybackEos> MsgData_PlaybackEos_sp(new CMsgData_PlaybackEos);

	do
	{
		//LOG_BLINE("PlaybackEos,%s,%u\n", pszFileName, PlaybackId);
		if(MsgItem_sp.isNull() || MsgData_PlaybackEos_sp.isNull())
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}
		MsgData_PlaybackEos_sp->m_uiMsgId = MP_MSG_PLAYBACK_EOS;
		MsgData_PlaybackEos_sp->m_strCurPlayUrl = pszFileName;
		MsgData_PlaybackEos_sp->m_PlaybackId = PlaybackId;
		MsgData_PlaybackEos_sp->m_bIsCompletePlaybackEos = bIsCompletePlaybackEos;
		MsgData_sp = MsgData_PlaybackEos_sp;
		iRet = MsgItem_sp->SetMessageData(MsgData_sp);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}
		iRet = PostMessage(MsgItem_sp);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}
	}while(FALSE);

	return iOutRet;
}

INT_t CMediaPlayerApp::PlayNextFile()
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	SharedPtr<CMessageQueueItem> MsgItem_sp(new CMessageQueueItem);
	SharedPtr <CGenericMsgData> MsgData_sp(new CGenericMsgData);

	do{
		if(MsgItem_sp.isNull() || MsgData_sp.isNull())
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}

		MsgData_sp->m_uiMsgId = MP_MSG_PLAYBCAK_PLAYNEXTFILE;
		iRet = MsgItem_sp->SetMessageData(MsgData_sp);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}
		iRet = PostMessage(MsgItem_sp);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}
	}while(FALSE);

	return iOutRet;
}

/*
ThreadContext: other thread
*/
INT_t CMediaPlayerApp::HdmiStereoscopic3DFmt_Changed()
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;

	do
	{
		//schedule a display output update immediately
		{
			SharedPtr<CMessageQueueItem> MsgItem_sp(new CMessageQueueItem);
			SharedPtr <CGenericMsgData> MsgData_sp(new CGenericMsgData);
			if(MsgItem_sp.isNull() || MsgData_sp.isNull())
			{
				iOutRet = ERROR_OUT_OF_MEMORY;
				break;
			}
			MsgData_sp->m_uiMsgId = MP_MSG_DISP_OUT_UPDATE;
			iRet = MsgItem_sp->SetMessageData(MsgData_sp);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
				break;
			}
			iRet = PostMessage(MsgItem_sp);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
				break;
			}
		}
	}while(FALSE);

	return iOutRet;
}

/*
ThreadContext: other thread, callback
*/
INT_t CMediaPlayerApp::On_VideoOutputModeIsSet()
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;

	do
	{
		SharedPtr<CMessageQueueItem> MsgItem_sp(new CMessageQueueItem);
		SharedPtr <CGenericMsgData> MsgData_sp(new CGenericMsgData);
		if(MsgItem_sp.isNull() || MsgData_sp.isNull())
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}
		MsgData_sp->m_uiMsgId = MP_MSG_VIDEO_OUTPUT_MODE_IS_SET;
		iRet = MsgItem_sp->SetMessageData(MsgData_sp);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}
		iRet = PostMessage(MsgItem_sp);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}
	}while(FALSE);

	return iOutRet;
}

SharedPtr <TiXmlDocument2> CMediaPlayerApp::getXmlCfgDoc()
{
	CAutoLock AutoRangeLocker(&m_SharedDataMutex);

	return m_SettingXmlDoc_sp;
}

INT_t CMediaPlayerApp::OnFdEvent(int iFd, CONST IFileDescriptorEventIf::FD_EVENT_FLAGS FdEvtFlags)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	int TimeoutMs;

	do
	{
		if(FD_ISSET(iFd, &m_fdsDbusComm))
		{
			dbus_bool_t bDBusRet;
			DBusMessage * pDBusMsg = NULL;

			TimeoutMs = 0;
			bDBusRet = dbus_connection_read_write(m_pDBusConn, TimeoutMs);
			if(FALSE == bDBusRet)	//the connection is closed
			{
				iOutRet = ERR_SCK_CONN_CLOSED_BY_PEER;
				break;
			}
			while(TRUE)
			{
				pDBusMsg = dbus_connection_pop_message(m_pDBusConn);
				if(pDBusMsg)
				{
					/*
					LOG_BLINE("dbus_message,type:%d,path:%s,interface:%s,member:%s,errorname:%s,destination:%s,sender:%s\n",
						dbus_message_get_type(pDBusMsg), dbus_message_get_path(pDBusMsg),
						dbus_message_get_interface(pDBusMsg), dbus_message_get_member(pDBusMsg),
						dbus_message_get_error_name(pDBusMsg),	dbus_message_get_destination(pDBusMsg),
						dbus_message_get_sender(pDBusMsg));
					*/
					iRet = ProcessDBusMsg(pDBusMsg);
					if(ERROR_SUCCESS != iRet)
					{
						PRINT_BFILE_LINENO_IRET_STR;
					}
					dbus_message_unref(pDBusMsg);
					pDBusMsg = NULL;
				}
				else	//no more data
				{
					break;
				}
			}
		}
		else
		{
			LOG_BLINE("BUG,unprocessed fd(%d) event(0x%08x)\n", iFd, FdEvtFlags);
		}
	}while(FALSE);

	return iOutRet;
}

static dbus_bool_t DBusAddWatchCb(DBusWatch * pDbusWatch, void * pData)
{
	dbus_bool_t bDbusRet = TRUE;
	CMediaPlayerApp * pApp = (typeof(pApp))pData;

	do
	{
		if(NULL == pDbusWatch || NULL == pApp)
		{
			bDbusRet = FALSE;
			break;
		}
		bDbusRet = pApp->DBusAddWatch(pDbusWatch);
	}while(FALSE);

	return bDbusRet;
}

dbus_bool_t CMediaPlayerApp::DBusAddWatch(DBusWatch * pDbusWatch)
{
	dbus_bool_t bDbusRet = TRUE, bRet;
	int iFd;
	unsigned int WatchFlags;

	do
	{
		iFd =  dbus_watch_get_unix_fd(pDbusWatch);
		if(0 > iFd)
		{
			bDbusRet = FALSE;
			break;
		}
		bRet = dbus_watch_get_enabled(pDbusWatch);
		FD_CLR(iFd, &(m_PollingFdInfo.m_FdsRead));
		FD_CLR(iFd, &(m_PollingFdInfo.m_FdsWrite));
		FD_CLR(iFd, &(m_PollingFdInfo.m_FdsExcept));
		if(FALSE == bRet)
		{
			m_FdEventIfMap.erase(iFd);
			FD_CLR(iFd, &m_fdsDbusComm);
			break;
		}
		WatchFlags = dbus_watch_get_flags(pDbusWatch);
		if(WatchFlags & DBUS_WATCH_READABLE)
		{
			FD_SET(iFd, &(m_PollingFdInfo.m_FdsRead));
		}
		if(WatchFlags & DBUS_WATCH_WRITABLE)
		{
			FD_SET(iFd, &(m_PollingFdInfo.m_FdsWrite));
		}
		if(0 != WatchFlags)
		{
			m_FdEventIfMap[iFd] = m_this_wp;
			FD_SET(iFd, &m_fdsDbusComm);
		}
		else
		{
			m_FdEventIfMap.erase(iFd);
			FD_CLR(iFd, &m_fdsDbusComm);
		}
	}while(FALSE);

	m_PollingFdInfo.m_iMaxFd = CalcMaxFd();

	return bDbusRet;
}

static void DBusRemoveWatchCb(DBusWatch * pDbusWatch, void * pData)
{
	CMediaPlayerApp * pApp = (typeof(pApp))pData;

	do
	{
		if(NULL == pDbusWatch || NULL == pApp)
		{
			break;
		}
		pApp->DBusRemoveWatch(pDbusWatch);
	}while(FALSE);
}

void CMediaPlayerApp::DBusRemoveWatch(DBusWatch * pDbusWatch)
{
	int iFd;

	do
	{
		iFd =  dbus_watch_get_unix_fd(pDbusWatch);
		if(0 > iFd)
		{
			break;
		}
		m_FdEventIfMap.erase(iFd);
		FD_CLR(iFd, &(m_PollingFdInfo.m_FdsRead));
		FD_CLR(iFd, &(m_PollingFdInfo.m_FdsWrite));
		FD_CLR(iFd, &(m_PollingFdInfo.m_FdsExcept));
		FD_CLR(iFd, &m_fdsDbusComm);
	}while(FALSE);

	m_PollingFdInfo.m_iMaxFd = CalcMaxFd();
}

INT_t CMediaPlayerApp::RegisterFdNotify(CONST int iFd, CONST IFileDescriptorEventIf::FD_EVENT_FLAGS FdEvtFlags,
	CONST WeakPtr <IFileDescriptorEventIf> FdEvtIf_wp)
{
	INT_t iOutRet = ERROR_SUCCESS;

	do
	{
		FD_CLR(iFd, &(m_PollingFdInfo.m_FdsRead));
		FD_CLR(iFd, &(m_PollingFdInfo.m_FdsWrite));
		FD_CLR(iFd, &(m_PollingFdInfo.m_FdsExcept));
		if(IFileDescriptorEventIf::FD_EVT_READABLE & FdEvtFlags)
		{
			FD_SET(iFd, &(m_PollingFdInfo.m_FdsRead));
		}
		if(IFileDescriptorEventIf::FD_EVT_WRITABLE & FdEvtFlags)
		{
			FD_SET(iFd, &(m_PollingFdInfo.m_FdsWrite));
		}
		if(IFileDescriptorEventIf::FD_EVT_EXCEPTION & FdEvtFlags)
		{
			FD_SET(iFd, &(m_PollingFdInfo.m_FdsExcept));
		}
		if(IFileDescriptorEventIf::FD_EVT_NONE != FdEvtFlags)
		{
			m_FdEventIfMap[iFd] = FdEvtIf_wp;
		}
		else
		{
			m_FdEventIfMap.erase(iFd);
		}
	}while(FALSE);

	m_PollingFdInfo.m_iMaxFd = CalcMaxFd();

	return iOutRet;
}

INT_t CMediaPlayerApp::getFdNotifyInfo(CONST int iFd, OUT IFileDescriptorEventIf::FD_EVENT_FLAGS & FdEvtFlags,
	OUT WeakPtr <IFileDescriptorEventIf> & FdEvtIf_wp)
{
	INT_t iOutRet = ERROR_SUCCESS;
	FD_EventIf_MAP::iterator itFdEvtIf;

	do
	{
		itFdEvtIf = m_FdEventIfMap.find(iFd);
		if(m_FdEventIfMap.end() != itFdEvtIf)
		{
			FdEvtIf_wp = itFdEvtIf->second;
		}
		else
		{
			FdEvtIf_wp.Clear();
		}
		FdEvtFlags = IFileDescriptorEventIf::FD_EVT_NONE;
		if(FD_ISSET(iFd, &(m_PollingFdInfo.m_FdsRead)))
		{
			FdEvtFlags = (typeof(FdEvtFlags))(FdEvtFlags | FD_EVT_READABLE);
		}
		else if(FD_ISSET(iFd, &(m_PollingFdInfo.m_FdsWrite)))
		{
			FdEvtFlags = (typeof(FdEvtFlags))(FdEvtFlags | FD_EVT_WRITABLE);
		}
		else if(FD_ISSET(iFd, &(m_PollingFdInfo.m_FdsExcept)))
		{
			FdEvtFlags = (typeof(FdEvtFlags))(FdEvtFlags | FD_EVT_EXCEPTION);
		}
	}while(FALSE);

	return iOutRet;
}

INT_t CMediaPlayerApp::UnregisterFdNotify(CONST int iFd)
{
	INT_t iOutRet = ERROR_SUCCESS;

	do
	{
		m_FdEventIfMap.erase(iFd);
		FD_CLR(iFd, &(m_PollingFdInfo.m_FdsRead));
		FD_CLR(iFd, &(m_PollingFdInfo.m_FdsWrite));
		FD_CLR(iFd, &(m_PollingFdInfo.m_FdsExcept));
	}while(FALSE);

	m_PollingFdInfo.m_iMaxFd = CalcMaxFd();

	return iOutRet;
}

#if 1/*added by lxj 2013-1-4*/
INT_t CMediaPlayerApp::RegisterTimer(WeakPtr <CppBase::ITimerListener> TimerListener_wp, OUT UINT_t & TimerId, INT_t TimeoutMs)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;

	do
	{
		iRet = m_GenericTimer.RegisterTimer(TimerListener_wp, OUT TimerId, TimeoutMs);
		if(ERROR_SUCCESS != iRet){
			PRINT_BFILE_LINENO_IRET_STR;
			iOutRet = iRet;
			break;
		}
	}while(FALSE);

	return iOutRet;
}

INT_t CMediaPlayerApp::UnregisterTimer(CONST UINT_t TimerId)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;

	do
	{
		iRet = m_GenericTimer.UnregisterTimer(TimerId);
		if(ERROR_SUCCESS != iRet){
			PRINT_BFILE_LINENO_IRET_STR;
			iOutRet = iRet;
			break;
		}
	}while(FALSE);

	return iOutRet;
}
#endif

INT_t CMediaPlayerApp::MainLoop()
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	DBusError DBusErr;
	dbus_bool_t bDBusRet;
	DBusMessage * pDBusMsg = NULL;
	INT_t NextTimeoutMs;
	INT_t DefaultTimeoutMs = (2*1000);
	SharedPtr<CMessageQueueItem> MsgItem_sp;
	struct timeval TimeoutVal;
	fd_set fdsRead, fdsWrite, fdsExcept;

	do
	{
		if(m_bNotRunMainLoop)
		{
			break;
		}

		while(TRUE)
		{
			iRet = m_GenericTimer.getNextTimeoutMs(OUT NextTimeoutMs);
			//LOG_BLINE("NextTimeoutMs=%d\n", NextTimeoutMs);
			if(ERROR_SUCCESS == iRet)
			{
				if(0 > NextTimeoutMs)
				{
					NextTimeoutMs = DefaultTimeoutMs;
				}
			}
			else
			{
				PRINT_BFILE_LINENO_IRET_STR;
				NextTimeoutMs = DefaultTimeoutMs;
			}

			TimeoutVal.tv_sec = NextTimeoutMs/1000;
			TimeoutVal.tv_usec = (NextTimeoutMs % 1000) * 1000;
			fdsRead = m_PollingFdInfo.m_FdsRead;
			fdsWrite = m_PollingFdInfo.m_FdsWrite;
			fdsExcept = m_PollingFdInfo.m_FdsExcept;
			iRet = select(m_PollingFdInfo.m_iMaxFd+1, &fdsRead, &fdsWrite, &fdsExcept, &TimeoutVal);
			if(0 < iRet)
			{
				FD_EventIf_MAP::iterator itFdEventIf;
				SharedPtr <IFileDescriptorEventIf> FileDescEventIf_sp;
				for(itFdEventIf = m_FdEventIfMap.begin(); itFdEventIf != m_FdEventIfMap.end(); itFdEventIf++)
				{
					IFileDescriptorEventIf::FD_EVENT_FLAGS FdEventFlags = IFileDescriptorEventIf::FD_EVT_NONE;
					if(FD_ISSET(itFdEventIf->first, &fdsRead))
					{
						//LOG_BLINE("Fd %d R\n", itFdEventIf->first);
						FdEventFlags = (typeof(FdEventFlags))(FdEventFlags | (UINT_t)IFileDescriptorEventIf::FD_EVT_READABLE);
					}
					if(FD_ISSET(itFdEventIf->first, &fdsWrite))
					{
						//LOG_BLINE("Fd %d W\n", itFdEventIf->first);
						FdEventFlags = (typeof(FdEventFlags))(FdEventFlags | (UINT_t)IFileDescriptorEventIf::FD_EVT_WRITABLE);
					}
					if(FD_ISSET(itFdEventIf->first, &fdsExcept))
					{
						//LOG_BLINE("Fd %d E\n", itFdEventIf->first);
						FdEventFlags = (typeof(FdEventFlags))(FdEventFlags | (UINT_t)IFileDescriptorEventIf::FD_EVT_EXCEPTION);
					}
					FileDescEventIf_sp = itFdEventIf->second.Promote();
					if(IFileDescriptorEventIf::FD_EVT_NONE != FdEventFlags && FileDescEventIf_sp.isValid())
					{
						iRet = FileDescEventIf_sp->OnFdEvent(itFdEventIf->first, FdEventFlags);
						if(ERROR_SUCCESS != iRet)
						{
							PRINT_BFILE_LINENO_IRET_STR;
						}
					}
					else if(FileDescEventIf_sp.isNull())
					{
						iRet = UnregisterFdNotify(itFdEventIf->first);
						if(ERROR_SUCCESS != iRet)
						{
							PRINT_BFILE_LINENO_IRET_STR;
						}
					}
				}
			}
			else if(0 == iRet)	//timeout
			{
				//LOG_BLINE("Timeout,CurTimeMs=%llums\n", GetSysUpTimeMs());
				//timer msg
				iRet = m_GenericTimer.CheckAndTrig();
				if(ERROR_SUCCESS != iRet)
				{
					PRINT_BFILE_LINENO_IRET_STR;
				}
			}
			else
			{
				if(EINTR != errno)
				{
					PRINT_BFILE_LINENO_CRT_ERRINFO;
					CIntArray BadFd_Array;
					PRINT_BFILE_LINENO_CRT_ERRINFO;
					iRet = m_PollingFdInfo.FixPollingFdset(OUT BadFd_Array);
					if(ERROR_SUCCESS != iRet)
					{
						PRINT_BFILE_LINENO_IRET_STR;
					}
					{
						int iIndex, iFd;
						for(iIndex = 0; iIndex < BadFd_Array.GetSize(); iIndex++)
						{
							iFd = BadFd_Array[iIndex];
							m_FdEventIfMap.erase(iFd);
						}
					}
				}
			}

			if(m_bShouldExitApp)
			{
				break;
			}

			{
				iRet = GetMessageTimeout(OUT MsgItem_sp, 0);
				if(ERROR_SUCCESS == iRet)
				{
					if(FALSE == MsgItem_sp.isNull())
					{
						iRet = ProcessGenericMsg(MsgItem_sp);
						if(ERROR_SUCCESS != iRet)
						{
							PRINT_BFILE_LINENO_IRET_STR;
						}
					}
					else
					{
						PRINT_BFILE_LINENO_BUG_STR;
					}
				}
				else if(ERR_TIMEOUT != iRet)
				{
					PRINT_BFILE_LINENO_IRET_STR;
				}
			}

			if(m_bShouldExitApp)
			{
				break;
			}
		}
	}while(FALSE);

	return iOutRet;
}

INT_t CMediaPlayerApp::ProcessDBusMsg(DBusMessage * pDBusMsg)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	DBusError DBusErr;
	const char * pszInterfaceName = NULL;

	do
	{
		pszInterfaceName = dbus_message_get_interface(pDBusMsg);
		if(NULL == pszInterfaceName)
		{
			break;
		}
		//LOG_BLINE("DbusIfName=%s\n", pszInterfaceName);
		if(0 == strcmp(DBUS_MPLAYER_OBJECT_INTERFACE, pszInterfaceName))
		{
			iRet = ProcessDBusMsg_DefaultIfCall(pDBusMsg);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
			}
		}
		else if(0 == strcmp(DBUS_INTERFACE_INTROSPECTABLE, pszInterfaceName))
		{
			iRet = ProcessDBusMsg_DBusIntrospectableIfCall(pDBusMsg);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
			}
		}
		else if(0 == strcmp(DBUS_INTERFACE_DBUS, pszInterfaceName))
		{
			iRet = ProcessDBusMsg_DBusDBusIfCall(pDBusMsg);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
			}
		}
		else if(0 == strcmp(DBUS_SystemService_NetMgrSrv_If, pszInterfaceName))
		{
			iRet = ProcessDBusMsg_SysSrvNetMgrIfCall(pDBusMsg);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
			}
		}
		else if(0 == strcmp(DBUS_SysSrv_SysEvt_If, pszInterfaceName))
		{
			iRet = ProcessDBusMsg_SysSrvSysEvtIfCall(pDBusMsg);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
			}
		}
		else if(0 == strcmp(DbusIf_SysSrv_CfgMgr, pszInterfaceName))
		{
			iRet = ProcessDBusMsg_SysSrvCfgMgrIfCall(pDBusMsg);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
			}
		}
		else
		{
			iOutRet = CDBusMessage::SendErrReply(m_pDBusConn, pDBusMsg,
				DBUS_ERROR_UNKNOWN_INTERFACE, "Unsupported interface call");
		}
	}while(FALSE);

	return iOutRet;
}

/*
ThreadContext: main thread
*/
INT_t CMediaPlayerApp::ProcessGenericMsg(SharedPtr<CMessageQueueItem> & MsgItem_sp)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	SharedPtr <CGenericMsgData> MsgData_sp;

	do
	{
		MsgData_sp = MsgItem_sp->GetMessageData();
		if(MsgData_sp.isNull())
		{
			break;
		}
		if(MP_MSG_PLAYBACK_START == MsgData_sp->m_uiMsgId)
		{
			iRet = On_PlaybackStart(MsgData_sp);
		}
#if 1/*added by lxj 2013-1-4*/
		else if(MP_MSG_PLAYBACK_READY_TO_PLAY == MsgData_sp->m_uiMsgId)
		{
			iRet = On_PlaybackReadyToPlay(MsgData_sp);
		}
#endif
		else if(MP_MSG_PLAYBACK_EOS == MsgData_sp->m_uiMsgId)
		{
			iRet = On_PlaybackEos(MsgData_sp);
		}
		else if(MP_MSG_PLAYBCAK_PLAYNEXTFILE == MsgData_sp->m_uiMsgId)
		{
			iRet = On_PlayNextFile();
		}
		else if(MP_MSG_DISP_OUT_UPDATE == MsgData_sp->m_uiMsgId)
		{
			iRet = m_oMediaSrv_sp->OutputDisplayUpdate();;
			if(ERROR_SUCCESS != iRet)
			{
				PRINT_BFILE_LINENO_IRET_STR;
			}
		}
		else if(MP_MSG_VIDEO_OUTPUT_MODE_IS_SET == MsgData_sp->m_uiMsgId)
		{
			VIDEO_OUTPUT_MODE eCurVoMode=VO_MODE_NotSet;
			//LOG_BLINE("MP_MSG_VIDEO_OUTPUT_MODE_IS_SET\n");
			if(0 == m_DelayedSet_VcrDefaultSurface_TimerId)
			{
				//the timer interval must be more than or equal to 2000ms.
				iRet = m_GenericTimer.RegisterTimer((WeakPtr<ITimerListener>)m_this_wp, OUT m_DelayedSet_VcrDefaultSurface_TimerId, 
					TIMER_ChkVcrDefaultSurface_INTERVAL_MS);
				if(ERROR_SUCCESS != iRet)
				{
					PRINT_BFILE_LINENO_IRET_STR;
				}
			}
			OnChk_DelayedSet_VcrDefaultSurface();
#if 1 /*-----------------add by xuweiwei 2013-11-22 for Solve in 92 mode save error mode-------------------------*/
			iRet = m_oMediaSrv_sp->ChangeVidOutModeAsync(VO_MODE_NotSet, NULL, &eCurVoMode);
			if(ERROR_SUCCESS == iRet)
			{
				iRet = SaveVoMode(eCurVoMode);
				if(ERROR_SUCCESS != iRet)
				{
					PRINT_BFILE_LINENO_IRET_STR;
				}	
			}
			else
			{
				PRINT_BFILE_LINENO_IRET_STR;
			}
#endif
		}
#ifdef ENABLE_DTV
		else if(MP_MSG_STARTSCAN == MsgData_sp->m_uiMsgId)
		{
			iRet = On_StartTunerScan();
		}
		else if(MP_MSG_SCANPROGRESS == MsgData_sp->m_uiMsgId)
		{
			iRet = On_NotifyScanProgress(MsgData_sp);
		}
		else if(MP_MSG_SCANDONE == MsgData_sp->m_uiMsgId)
		{
			iRet = On_DoneTunerScan();
		}
		else if(MP_MSG_PROPMT_MSG_DONE == MsgData_sp->m_uiMsgId)
		{
			iRet = On_TuPlayerPropmtMsg(MsgData_sp);
		}
#endif
	}while(FALSE);

	iRet = MsgItem_sp->SetEvent();
	if(ERROR_SUCCESS != iRet)
	{
		PRINT_BFILE_LINENO_IRET_STR;
	}

	return iOutRet;
}

/*
ThreadContext: MainThread
*/
INT_t CMediaPlayerApp::On_PlaybackStart(SharedPtr <CGenericMsgData> & MsgData_sp)
{
	INT_t iOutRet = ERROR_SUCCESS;

	//LOG_BLINE("CMediaPlayerApp::On_PlaybackStart\n");
	OnHdmiHotplugChk();

	return iOutRet;
}

#if 1/*added by lxj 2013-1-4*/
/*
ThreadContext: MainThread
*/
INT_t CMediaPlayerApp::On_PlaybackReadyToPlay(SharedPtr <CGenericMsgData> & MsgData_sp)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;

	do{
		if( m_VideoSync_sp.isValid() ){
			iRet = m_VideoSync_sp->OnPlaybackReadyToPlay();
			if(ERROR_SUCCESS != iRet){
				iOutRet = iRet;
				break;
			}
		}else{
			iRet = m_oMediaSrv_sp->setPlayMode(PlayMode_Normal);
			if(ERROR_SUCCESS != iRet){
				iOutRet = iRet;
				break;
			}
		}
	}while(FALSE);

	return iOutRet;
}
#endif

/*
ThreadContext: MainThread
*/

INT_t CMediaPlayerApp::On_PlayNextFile()
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	UINT32_t PlaybackId = 0;
	do
	{
		iRet = m_oMediaSrv_sp->Prepare();
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}

		iRet = m_oMediaSrv_sp->Play(&PlaybackId);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}

	}while(FALSE);

	return iOutRet;
}

INT_t CMediaPlayerApp::On_PlaybackEos(SharedPtr <CGenericMsgData> & MsgData_sp)
{
	INT_t iOutRet = ERROR_SUCCESS;
	DBusMessage * pDBusMsg = NULL;
	dbus_bool_t bDBusRet;
	SharedPtr <CMsgData_PlaybackEos> MsgData_PlaybackEos_sp;
	SharedPtr <CDBusParameterList> DBusReplyParameterList_sp(new CDBusParameterList);

	do
	{
		OnHdmiHotplugChk();

#if 1/*modify by lxj 2012-1-3 for videosync*/
		if( m_VideoSync_sp.isValid() ){
			INT_t iRet = m_VideoSync_sp->OnPlaybackEos();
			if(ERROR_SUCCESS != iRet){
				PRINT_BFILE_LINENO_IRET_STR;
			}
		}
#endif

		if(NULL == m_pDBusConn)
		{
			iOutRet = ERROR_INVALID_STATE;
			break;
		}

		if(DBusReplyParameterList_sp.isNull())
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}

		MsgData_PlaybackEos_sp = MsgData_sp.DynamicCast<CMsgData_PlaybackEos>();
		if(MsgData_PlaybackEos_sp.isNull())
		{
			PRINT_BFILE_LINENO_BUG_STR;
			break;
		}
		//LOG_BLINE("SEND EOS %d\n",MsgData_PlaybackEos_sp->m_PlaybackId);
		//PlaybackEos
		pDBusMsg = dbus_message_new_signal(DBUS_MPLAYER_OBJECT_PATH, DBUS_MPLAYER_OBJECT_INTERFACE,
			MP_SIGNAL_PlaybackEos);
		if(NULL == pDBusMsg)
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}
		(*DBusReplyParameterList_sp) << MsgData_PlaybackEos_sp->m_strCurPlayUrl;
		(*DBusReplyParameterList_sp) << MsgData_PlaybackEos_sp->m_PlaybackId;
		(*DBusReplyParameterList_sp) >> pDBusMsg;
		bDBusRet = dbus_connection_send(m_pDBusConn, pDBusMsg, NULL);
		if(FALSE == bDBusRet)
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}
		if(pDBusMsg)
		{
			dbus_message_unref(pDBusMsg);
			pDBusMsg = NULL;
		}
		//PlaybackEos2
		pDBusMsg = dbus_message_new_signal(DBUS_MPLAYER_OBJECT_PATH, DBUS_MPLAYER_OBJECT_INTERFACE,
			MP_SIGNAL_PlaybackEos2);
		if(NULL == pDBusMsg)
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}
			//add the param m_bIsCompletePlaybackEos
		(*DBusReplyParameterList_sp) << MsgData_PlaybackEos_sp->m_bIsCompletePlaybackEos;
		(*DBusReplyParameterList_sp) >> pDBusMsg;
		bDBusRet = dbus_connection_send(m_pDBusConn, pDBusMsg, NULL);
		if(FALSE == bDBusRet)
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}
		if(pDBusMsg)
		{
			dbus_message_unref(pDBusMsg);
			pDBusMsg = NULL;
		}
	}while(FALSE);

	if(pDBusMsg)
	{
		dbus_message_unref(pDBusMsg);
		pDBusMsg = NULL;
	}

	return iOutRet;
}

INT_t CMediaPlayerApp::ProcessDBusMsg_DefaultIfCall(DBusMessage * pDBusMsg)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	DBusError DBusErr;
	int DBusMsgType;

	do
	{
		DBusMsgType = dbus_message_get_type(pDBusMsg);
		if(DBUS_MESSAGE_TYPE_METHOD_CALL == DBusMsgType)
		{
			iRet = ProcessDBusMsg_MethodCall(pDBusMsg);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
			}
		}
		else if(DBUS_MESSAGE_TYPE_SIGNAL == DBusMsgType)
		{
			const char * pszMethodame = NULL;
			pszMethodame = dbus_message_get_member(pDBusMsg);
			if(NULL == pszMethodame)
			{
				pszMethodame = "";
			}
			//LOG_BLINE("DbusSig,%s\n", pszMethodame);
		}
	}while(FALSE);

	return iOutRet;
}

INT_t CMediaPlayerApp::ProcessDBusMsg_DBusIntrospectableIfCall(DBusMessage * pDBusMsg)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	DBusError DBusErr;
	int DBusMsgType;
	const char * pszMethodame = NULL;

	do
	{
		DBusMsgType = dbus_message_get_type(pDBusMsg);
		if(DBUS_MESSAGE_TYPE_METHOD_CALL == DBusMsgType)
		{
			iRet = DBusIntrospectableIf_MethodCall(pDBusMsg);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
			}
		}
		else if(DBUS_MESSAGE_TYPE_SIGNAL == DBusMsgType)
		{
			const char * pszMethodame = NULL;
			pszMethodame = dbus_message_get_member(pDBusMsg);
			if(NULL == pszMethodame)
			{
				pszMethodame = "";
			}
			LOG_BLINE("DBUS_MESSAGE_TYPE_SIGNAL,%s\n", pszMethodame);
		}
	}while(FALSE);

	return iOutRet;
}

INT_t CMediaPlayerApp::ProcessDBusMsg_DBusDBusIfCall(DBusMessage * pDBusMsg)
{
	INT_t iOutRet = ERROR_SUCCESS;
	DBusError DBusErr;
	dbus_bool_t bDBusRet;
	int DBusMsgType;
	const char * pszMethodame = NULL;

	do
	{
		DBusMsgType = dbus_message_get_type(pDBusMsg);
		if(DBUS_MESSAGE_TYPE_SIGNAL == DBusMsgType)
		{
			const char * pszMethodame = NULL;
			pszMethodame = dbus_message_get_member(pDBusMsg);
			if(NULL == pszMethodame)
			{
				pszMethodame = "";
			}
			if(0 == strcmp("NameOwnerChanged", pszMethodame))
			{
				/*
				const char *pszArg0 = NULL, *pszArg1 = NULL, *pszArg2 = NULL;
				dbus_error_init(&DBusErr);
				bDBusRet =  dbus_message_get_args(pDBusMsg, &DBusErr, DBUS_TYPE_STRING, &pszArg0,
					DBUS_TYPE_STRING, &pszArg0, DBUS_TYPE_STRING, &pszArg1, DBUS_TYPE_STRING, &pszArg2,
					DBUS_TYPE_INVALID);
				if(false == bDBusRet)
				{
					if (dbus_error_is_set(&DBusErr))
					{
						dbus_error_free(&err);
					}
					//LOG_BLINE("can't get dbus_msg args\n");
				}
				//LOG_BLINE("DBUS_MESSAGE_TYPE_SIGNAL,%s,Args:%s,%s,%s\n", pszMethodame, pszArg0, pszArg1, pszArg2);
				*/
			}
			else if(0 == strcmp("NameAcquired", pszMethodame))
			{
			}
			else
			{
				LOG_BLINE("DBUS_MESSAGE_TYPE_SIGNAL,%s\n", pszMethodame);
			}
		}
		else if(DBUS_MESSAGE_TYPE_METHOD_CALL == DBusMsgType)
		{
			iOutRet = CDBusMessage::SendErrReply(m_pDBusConn, pDBusMsg,
				DBUS_ERROR_UNKNOWN_METHOD, "Unsupported method call");
		}
	}while(FALSE);

	return iOutRet;
}

INT_t CMediaPlayerApp::ProcessDBusMsg_SysSrvNetMgrIfCall(DBusMessage * pDBusMsg)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	DBusError DBusErr;
	dbus_bool_t bDBusRet;
	int DBusMsgType;
	const char * pszMethodame = NULL;

	do
	{
		DBusMsgType = dbus_message_get_type(pDBusMsg);
		if(DBUS_MESSAGE_TYPE_SIGNAL == DBusMsgType)
		{
			const char * pszMethodame = NULL;
			pszMethodame = dbus_message_get_member(pDBusMsg);
			if(NULL == pszMethodame)
			{
				pszMethodame = "";
			}
			if(0 == strcmp(NetMgrIf_SigName_SntpUpdatedSysTime, pszMethodame))
			{
				iRet = SyncSysTimeToHwRtc();
				if(ERROR_SUCCESS != iRet)
				{
					PRINT_BFILE_LINENO_IRET_STR;
				}
			}
			else
			{
				if(Sw_LogDbusCmd)
				{
					LOG_BLINE("DBUS_MESSAGE_TYPE_SIGNAL,%s\n", pszMethodame);
				}
			}
		}
		else if(DBUS_MESSAGE_TYPE_METHOD_CALL == DBusMsgType)
		{
			iOutRet = CDBusMessage::SendErrReply(m_pDBusConn, pDBusMsg,
				DBUS_ERROR_UNKNOWN_METHOD, "Unsupported method call");
		}
	}while(FALSE);

	return iOutRet;
}

INT_t CMediaPlayerApp::ProcessDBusMsg_SysSrvSysEvtIfCall(DBusMessage * pDBusMsg)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	DBusError DBusErr;
	dbus_bool_t bDBusRet;
	int DBusMsgType;
	const char * pszMethodame = NULL;

	do
	{
		DBusMsgType = dbus_message_get_type(pDBusMsg);
		if(DBUS_MESSAGE_TYPE_SIGNAL == DBusMsgType)
		{
			const char * pszMethodame = NULL;
			pszMethodame = dbus_message_get_member(pDBusMsg);
			if(NULL == pszMethodame)
			{
				pszMethodame = "";
			}
			if(0 == strcmp(SysEvtIf_SigName_Evt_SyncCacheToStorage, pszMethodame))
			{
				//LOG_BLINE("DBUS_MESSAGE_TYPE_SIGNAL,%s\n", SysEvtIf_SigName_Evt_SyncCacheToStorage);
				iRet = SyncCacheToFile();
				if(ERROR_SUCCESS != iRet)
				{
					PRINT_BFILE_LINENO_IRET_STR;
				}
			}
			else
			{
				if(Sw_LogDbusCmd)
				{
					LOG_BLINE("DbusSig,%s\n", pszMethodame);
				}
			}
		}
		else if(DBUS_MESSAGE_TYPE_METHOD_CALL == DBusMsgType)
		{
			iOutRet = CDBusMessage::SendErrReply(m_pDBusConn, pDBusMsg,
				DBUS_ERROR_UNKNOWN_METHOD, "Unsupported method call");
		}
	}while(FALSE);

	return iOutRet;
}

INT_t CMediaPlayerApp::ProcessDBusMsg_SysSrvCfgMgrIfCall(DBusMessage * pDBusMsg)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	DBusError DBusErr;
	dbus_bool_t bDBusRet;
	int DBusMsgType;
	const char * pszMethodame = NULL;

	do
	{
		DBusMsgType = dbus_message_get_type(pDBusMsg);

		if(DBUS_MESSAGE_TYPE_SIGNAL == DBusMsgType)
		{
			iOutRet = SysSrvCfgMgrIf_Signal(pDBusMsg);
		}
		else if(DBUS_MESSAGE_TYPE_METHOD_CALL == DBusMsgType)
		{
			iOutRet = CDBusMessage::SendErrReply(m_pDBusConn, pDBusMsg,
				DBUS_ERROR_UNKNOWN_METHOD, "Unsupported method call");
		}
	}while(FALSE);

	return iOutRet;
}

INT_t CMediaPlayerApp::ProcessDBusMsg_MethodCall(DBusMessage * pDBusMsg)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	DBusError DBusErr;
	const char * pszMethodame = NULL;
	SharedPtr <CDBusParameterList> DBusInParamList_sp(new CDBusParameterList);
	SharedPtr <CDBusParameterList> DBusOutParamList_sp(new CDBusParameterList);
	DBusMessage * pDBusMsgRet = NULL;
	dbus_bool_t bDBusRet;

	do
	{
		pDBusMsgRet = dbus_message_new_method_return(pDBusMsg);
		if(NULL == pDBusMsgRet)
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}

		if(NULL == DBusInParamList_sp.get() || NULL == DBusOutParamList_sp.get())
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}
		pszMethodame = dbus_message_get_member(pDBusMsg);
		if(NULL == pszMethodame)
		{
			break;
		}
		if(Sw_LogDbusCmd)
		{
			LOG("DbusM: %s\n", pszMethodame);
		}
#ifdef	__EXCEPTIONS
		try
#endif	//__EXCEPTIONS
		{
			(*DBusInParamList_sp) << pDBusMsg;
		}
#ifdef	__EXCEPTIONS
		catch(CInvArgException & InvArgEx)
		{
			iOutRet = ERROR_INVALID_PARAMETER;
			break;
		}
		catch(CBaseErrException & BaseErrEx)
		{
			iOutRet = BaseErrEx.getBaseErr();
			break;
		}
#endif	//__EXCEPTIONS

		if(0 == strcmp(METHOD_setDataSource, pszMethodame))
		{
			iRet = OnDBusCall_setDataSource(DBusInParamList_sp, DBusOutParamList_sp);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
			}
		}
		else if(0 == strcmp(METHOD_Prepare, pszMethodame))
		{
			iRet = OnDBusCall_Prepare(DBusInParamList_sp, DBusOutParamList_sp);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
			}
		}
		else if(0 == strcmp(METHOD_Play, pszMethodame))
		{
			iRet = OnDBusCall_Play(DBusInParamList_sp, DBusOutParamList_sp);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
			}
		}
		else if(0 == strcmp(METHOD_Play2, pszMethodame))
		{
			iRet = OnDBusCall_Play2(DBusInParamList_sp, DBusOutParamList_sp);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
			}
		}
		else if(0 == strcmp(METHOD_Stop, pszMethodame))
		{
			iRet = OnDBusCall_Stop(DBusInParamList_sp, DBusOutParamList_sp);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
			}
		}
		else if(0 == strcmp(METHOD_setVideoPosition, pszMethodame))
		{
			iRet = OnDBusCall_setVideoPosition(DBusInParamList_sp, DBusOutParamList_sp);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
			}
		}
		else if(0 == strcmp(METHOD_setVideoInputWindowSize, pszMethodame))
		{
			iRet = OnDBusCall_setVideoInputWindowSize(DBusInParamList_sp, DBusOutParamList_sp);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
			}
		}
		else if(0 == strcmp(METHOD_setOsdPosition, pszMethodame))
		{
			iRet = OnDBusCall_setOsdPosition(DBusInParamList_sp, DBusOutParamList_sp);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
			}
		}
		else if(0 == strcmp(METHOD_ChangeVideoOutputMode, pszMethodame))
		{
			iRet = OnDBusCall_ChangeVideoOutputMode(DBusInParamList_sp, DBusOutParamList_sp);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
			}
		}
		else if(0 == strcmp(METHOD_setVideoOutputModeAsync, pszMethodame))
		{
			iRet = OnDBusCall_setVideoOutputModeAsync(DBusInParamList_sp, DBusOutParamList_sp);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
			}
		}
		else if(0 == strcmp(METHOD_ChangeVolume, pszMethodame))
		{
			iRet = OnDBusCall_ChangeVolume(DBusInParamList_sp, DBusOutParamList_sp);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
			}
		}
		else if(0 == strcmp(METHOD_setHwRtcTime, pszMethodame))
		{
			iRet = OnDBusCall_setHwRtcTime(DBusInParamList_sp, DBusOutParamList_sp);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
			}
		}
		else if(0 == strcmp(METHOD_getTimeZoneSetting, pszMethodame))
		{
			iRet = OnDBusCall_getTimeZoneSetting(DBusInParamList_sp, DBusOutParamList_sp);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
			}
		}
		else if(0 == strcmp(METHOD_setTimeZoneSetting, pszMethodame))
		{
			iRet = OnDBusCall_setTimeZoneSetting(DBusInParamList_sp, DBusOutParamList_sp);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
			}
		}
		else if(0 == strcmp(METHOD_setGpioLedStatus, pszMethodame))
		{
			iRet = OnDBusCall_setGpioLedStatus(DBusInParamList_sp, DBusOutParamList_sp);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
			}
		}
		else if(0 == strcmp(METHOD_DisplayOnLedScreen, pszMethodame))
		{
			iRet = OnDBusCall_DisplayOnLedScreen(DBusInParamList_sp, DBusOutParamList_sp);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
			}
		}
		else if(0 == strcmp(METHOD_DispOnLedScrAsync, pszMethodame))
		{
			iRet = OnDBusCall_DispOnLedScrAsync(DBusInParamList_sp, DBusOutParamList_sp);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
			}
		}
		else if(0 == strcmp(METHOD_getMonitorInfo, pszMethodame))
		{
			iRet = OnDBusCall_getMonitorInfo(DBusInParamList_sp, DBusOutParamList_sp);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
			}
		}
		else if(0 == strcmp(METHOD_setPlayMode, pszMethodame))
		{
			iRet = OnDBusCall_setPlayMode(DBusInParamList_sp, DBusOutParamList_sp);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
			}
		}
		else if(0 == strcmp(METHOD_getPlayMode, pszMethodame))
		{
			iRet = OnDBusCall_getPlayMode(DBusInParamList_sp, DBusOutParamList_sp);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
			}
		}
		else if(0 == strcmp(METHOD_setDisplayParam, pszMethodame))
		{
			iRet = OnDBusCall_setDisplayParam(DBusInParamList_sp, DBusOutParamList_sp);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
			}
		}
		else if(0 == strcmp(METHOD_getDisplayParam, pszMethodame))
		{
			iRet = OnDBusCall_getDisplayParam(DBusInParamList_sp, DBusOutParamList_sp);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
			}
		}
		else if(0 == strcmp(METHOD_getDisplayPosition, pszMethodame))
		{
			iRet = OnDBusCall_getDisplayPosition(DBusInParamList_sp, DBusOutParamList_sp);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
			}
		}
		else if(0 == strcmp(METHOD_setMonitorType, pszMethodame))
		{
			iRet = OnDBusCall_setMonitorType(DBusInParamList_sp, DBusOutParamList_sp);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
			}
		}
		else if(0 == strcmp(METHOD_getMonitorType, pszMethodame))
		{
			iRet = OnDBusCall_getMonitorType(DBusInParamList_sp, DBusOutParamList_sp);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
			}
		}
		else if(0 == strcmp(METHOD_setPlaySpeedCtrlAsync, pszMethodame))
		{
			iRet = OnDBusCall_setPlaySpeedCtrlAsync(DBusInParamList_sp, DBusOutParamList_sp);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
			}
		}
		else if(0 == strcmp(METHOD_getPlaySpeedCtrl, pszMethodame))
		{
			iRet = OnDBusCall_getPlaySpeedCtrl(DBusInParamList_sp, DBusOutParamList_sp);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
			}
		}
		else if(0 == strcmp(METHOD_getCurClkTicks, pszMethodame))
		{
			iRet = OnDBusCall_getCurClkTicks(DBusInParamList_sp, DBusOutParamList_sp);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
			}
		}
		else if(0 == strcmp(METHOD_getConfigDateTime, pszMethodame))
		{
			iRet = OnDBusCall_getConfigDateTime(DBusInParamList_sp, DBusOutParamList_sp);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
			}
		}
		else if(0 == strcmp(METHOD_getCpuSerialNo, pszMethodame))
		{
			iRet = OnDBusCall_getCpuSerialNo(DBusInParamList_sp, DBusOutParamList_sp);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
			}
		}
		else if(0 == strcmp(METHOD_setHdmi3DTvMode, pszMethodame))
		{
			iRet = OnDBusCall_setHdmi3DTvMode(DBusInParamList_sp, DBusOutParamList_sp);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
			}
		}
		else if(0 == strcmp(METHOD_setCurClkTicks, pszMethodame))
		{
			iRet = OnDBusCall_setCurClkTicks(DBusInParamList_sp, DBusOutParamList_sp);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
			}
		}
		else if(0 == strcmp(METHOD_setConfigDateTime, pszMethodame))
		{
			iRet = OnDBusCall_setConfigDateTime(DBusInParamList_sp, DBusOutParamList_sp);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
			}
		}
		else if(0 == strcmp(METHOD_setOutputSpdifMode, pszMethodame))
		{
			iRet = OnDBusCall_setOutputSpdifMode(DBusInParamList_sp, DBusOutParamList_sp);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
			}
		}
		else if(0 == strcmp(METHOD_getOutputSpdifMode, pszMethodame))
		{
			iRet = OnDBusCall_getOutputSpdifMode(DBusInParamList_sp, DBusOutParamList_sp);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
			}
		}
		else if(0 == strcmp(METHOD_setVideoDispAspectRatio, pszMethodame))
		{
			iRet = OnDBusCall_setVideoDispAspectRatio(DBusInParamList_sp, DBusOutParamList_sp);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
			}
		}
#if 1/*added by lxj 2012-9-28*/
		else if(0 == strcmp(METHOD_getVideoDispAspectRatio, pszMethodame))
		{
			iRet = OnDBusCall_getVideoDispAspectRatio(DBusInParamList_sp, DBusOutParamList_sp);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
			}
		}
#endif
		else if(0 == strcmp(METHOD_setHdmiAudioOutput, pszMethodame))
		{
			iRet = OnDBusCall_setHdmiAudioOutput(DBusInParamList_sp, DBusOutParamList_sp);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
			}
		}
		else if(0 == strcmp(METHOD_setAnalogAudioMute, pszMethodame))
		{
			iRet = OnDBusCall_setAnalogAudioMute(DBusInParamList_sp, DBusOutParamList_sp);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
			}
		}
		else if(0 == strcmp(DBUS_METHOD_setSerialParameters, pszMethodame))
		{
			iRet = OnDBusCall_setSerialParameters(DBusInParamList_sp, DBusOutParamList_sp);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
			}
		}
		else if(0 == strcmp(DBUS_METHOD_getSerialParameters, pszMethodame))
		{
			iRet = OnDBusCall_getSerialParameters(DBusInParamList_sp, DBusOutParamList_sp);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
			}
		}
		else if(0 == strcmp(DBUS_METHOD_getSerialControlData, pszMethodame))
		{
			iRet = OnDBusCall_getSerialControlData(DBusInParamList_sp, DBusOutParamList_sp);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
			}
		}
		else if(0 == strcmp(DBUS_METHOD_setSerialControlData, pszMethodame))
		{
			iRet = OnDBusCall_setSerialControlData(DBusInParamList_sp, DBusOutParamList_sp);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
			}
		}
#ifdef ENABLE_DTV
		else if(0 == strcmp(METHOD_GetEntryChannelInfo,pszMethodame))
		{
			iRet = OnDBusCall_GetEntryChannelInfo(DBusInParamList_sp, DBusOutParamList_sp);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
			}
		}
		else if(0 == strcmp(METHOD_PlayTuner, pszMethodame))
		{
			iRet = OnDBusCall_PlayTuner(DBusInParamList_sp, DBusOutParamList_sp);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
			}
		}
		else if(0 == strcmp(METHOD_TunerScan,pszMethodame))
		{
			iRet = OnDBusCall_TunerScan(DBusInParamList_sp, DBusOutParamList_sp);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
			}
		}
		else if(0 == strcmp(METHOD_GetTunerChannelStrength,pszMethodame))
		{
			iRet = OnDBusCall_GetTunerChannelStrength(DBusInParamList_sp, DBusOutParamList_sp);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
			}
		}		
		else if(0 == strcmp(METHOD_ResetDuration,pszMethodame))
		{
			iRet = OnDBusCall_ResetDuration(DBusInParamList_sp, DBusOutParamList_sp);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
			}
		}
		else if(0 == strcmp(METHOD_SetTunerStandardMode,pszMethodame))
		{
			iRet = OnDBusCall_TunerMode(DBusInParamList_sp, DBusOutParamList_sp);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
			}
		}
		else if(0 == strcmp(METHOD_GetTunerMode,pszMethodame))
		{
			iRet = OnDBusCall_GetTunerMode(DBusInParamList_sp, DBusOutParamList_sp);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
			}
		}
		else if(0 == strcmp(METHOD_ChannelUp,pszMethodame))
		{
			iRet = OnDBusCall_ChannelUp(DBusInParamList_sp, DBusOutParamList_sp);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
			}
		}
		else if(0 == strcmp(METHOD_ChannelDown,pszMethodame))
		{
			iRet = OnDBusCall_ChannelDown(DBusInParamList_sp, DBusOutParamList_sp);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
			}
		}
		else if(0 == strcmp(METHOD_GetFirstChNumber,pszMethodame))
		{
			iRet = OnDBusCall_GetFirstChNumber(DBusInParamList_sp, DBusOutParamList_sp);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
			}
		}
		else if(0 == strcmp(METHOD_GetForceTxMode,pszMethodame))
		{
			iRet = OnDBusCall_GetForceTxMode(DBusInParamList_sp, DBusOutParamList_sp);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
			}
		}
		else if(0 == strcmp(METHOD_setTunerChannelMode,pszMethodame))
		{
			iRet = OnDBusCall_setTunerChannelMode(DBusInParamList_sp, DBusOutParamList_sp);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
			}
		}
		else if(0 == strcmp(METHOD_getTunerChannelMode,pszMethodame))
		{
			iRet = OnDBusCall_getTunerChannelMode(DBusInParamList_sp, DBusOutParamList_sp);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
			}
		}
#endif
#if 1/*added by lxj 2012-11-12*/
		else if(0 == strcmp(METHOD_getVideoSyncMode, pszMethodame))
		{
			iRet = OnDBusCall_getVideoSyncMode(DBusInParamList_sp, DBusOutParamList_sp);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
			}
		}
		else if(0 == strcmp(METHOD_setVideoSyncMode, pszMethodame))
		{
			iRet = OnDBusCall_setVideoSyncMode(DBusInParamList_sp, DBusOutParamList_sp);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
			}
		}
		else if(0 == strcmp(METHOD_getVideoSyncMaster, pszMethodame))
		{
			iRet = OnDBusCall_getVideoSyncMaster(DBusInParamList_sp, DBusOutParamList_sp);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
			}
		}
		else if(0 == strcmp(METHOD_setVideoSyncMaster, pszMethodame))
		{
			iRet = OnDBusCall_setVideoSyncMaster(DBusInParamList_sp, DBusOutParamList_sp);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
			}
		}
#endif
		else if(0 == strcmp(METHOD_setHdmiCecCtrl, pszMethodame))
		{
			iRet = OnDBusCall_setHdmiCecCtrl(DBusInParamList_sp, DBusOutParamList_sp);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
			}
		}
		else if(0 == strcmp(METHOD_setShowClosedCaption, pszMethodame))
		{
			iRet = OnDBusCall_setShowClosedCaption(DBusInParamList_sp, DBusOutParamList_sp);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
			}
		}
		else if(0 == strcmp(METHOD_getShowClosedCaption, pszMethodame))
		{
			iRet = OnDBusCall_getShowClosedCaption(DBusInParamList_sp, DBusOutParamList_sp);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
			}
		}
#if 1 /*------Add by xuweiwei 2014-2-18------*/
		else if(0 == strcmp(METHOD_setVideoRotation, pszMethodame))
		{
			iRet = OnDBusCall_setVideoRotation(DBusInParamList_sp, DBusOutParamList_sp);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
			}
		}
		else if(0 == strcmp(METHOD_getVideoRotation, pszMethodame))
		{
			iRet = OnDBusCall_getVideoRotation(DBusInParamList_sp, DBusOutParamList_sp);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
			}
		}
#endif
		else if(0 == strcmp(METHOD_setEnableAudio6Ch, pszMethodame))
		{
			iRet = OnDBusCall_enableAudio6Ch(DBusInParamList_sp, DBusOutParamList_sp);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
			}
		}
              else if(0 == strcmp(METHOD_getEnableAudio6Ch, pszMethodame))
		{
			iRet = OnDBusCall_getEnableAudio6Ch(DBusInParamList_sp, DBusOutParamList_sp);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
			}
		}
		else
		{
			iOutRet = CDBusMessage::SendErrReply(m_pDBusConn, pDBusMsg,
				DBUS_ERROR_UNKNOWN_METHOD, "Unsupported method call");
			break;
		}

#ifdef	__EXCEPTIONS
		try
#endif	//__EXCEPTIONS
		{
			(*DBusOutParamList_sp) >> pDBusMsgRet;
		}
#ifdef	__EXCEPTIONS
		catch(CInvArgException & InvArgEx)
		{
			iOutRet = ERROR_INVALID_PARAMETER;
			break;
		}
		catch(CBaseErrException & BaseErrEx)
		{
			iOutRet = BaseErrEx.getBaseErr();
			break;
		}
		catch(...)
		{
			LOG_BLINE("BUG,uncaught exception\n");
		}
#endif	//__EXCEPTIONS

		bDBusRet = dbus_connection_send(m_pDBusConn, pDBusMsgRet, NULL);
		if(TRUE != bDBusRet)
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}
	}while(FALSE);

	if(pDBusMsgRet)
	{
		dbus_message_unref(pDBusMsgRet);
		pDBusMsgRet = NULL;
	}

	return iOutRet;
}

INT_t CMediaPlayerApp::DBusIntrospectableIf_MethodCall(DBusMessage * pDBusMsg)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	DBusError DBusErr;
	const char * pszMethodame = NULL;
	SharedPtr <CDBusParameterList> DBusInParamList_sp(new CDBusParameterList);
	SharedPtr <CDBusParameterList> DBusOutParamList_sp(new CDBusParameterList);
	DBusMessage * pDBusMsgRet = NULL;
	dbus_bool_t bDBusRet;

	do
	{
		pDBusMsgRet = dbus_message_new_method_return(pDBusMsg);
		if(NULL == pDBusMsgRet)
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}

		if(NULL == DBusInParamList_sp.get() || NULL == DBusOutParamList_sp.get())
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}
		pszMethodame = dbus_message_get_member(pDBusMsg);
		if(NULL == pszMethodame)
		{
			break;
		}
		if(Sw_LogDbusCmd)
		{
			LOG("DbusM: %s\n", pszMethodame);
		}
#ifdef	__EXCEPTIONS
		try
#endif	//__EXCEPTIONS
		{
			(*DBusInParamList_sp) << pDBusMsg;
		}
#ifdef	__EXCEPTIONS
		catch(CInvArgException & InvArgEx)
		{
			iOutRet = ERROR_INVALID_PARAMETER;
			break;
		}
		catch(CBaseErrException & BaseErrEx)
		{
			iOutRet = BaseErrEx.getBaseErr();
			break;
		}
#endif	//__EXCEPTIONS

		if(0 == strcmp(METHOD_Introspect, pszMethodame))
		{
			iRet = DBusIntrospectableIf_Introspect(DBusInParamList_sp, DBusOutParamList_sp);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
			}
		}
		else
		{
			iOutRet = CDBusMessage::SendErrReply(m_pDBusConn, pDBusMsg,
				DBUS_ERROR_UNKNOWN_METHOD, "Unsupported method call");
			break;
		}

#ifdef	__EXCEPTIONS
		try
#endif	//__EXCEPTIONS
		{
			(*DBusOutParamList_sp) >> pDBusMsgRet;
		}
#ifdef	__EXCEPTIONS
		catch(CInvArgException & InvArgEx)
		{
			iOutRet = ERROR_INVALID_PARAMETER;
			break;
		}
		catch(CBaseErrException & BaseErrEx)
		{
			iOutRet = BaseErrEx.getBaseErr();
			break;
		}
#endif	//__EXCEPTIONS

		bDBusRet = dbus_connection_send(m_pDBusConn, pDBusMsgRet, NULL);
		if(TRUE != bDBusRet)
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}
	}while(FALSE);

	if(pDBusMsgRet)
	{
		dbus_message_unref(pDBusMsgRet);
		pDBusMsgRet = NULL;
	}

	return iOutRet;
}

INT_t CMediaPlayerApp::SysSrvCfgMgrIf_Signal(DBusMessage * pDBusMsg)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	DBusError DBusErr;
	const char * pszMethodame = NULL;
	SharedPtr <CDBusParameterList> DBusInParamList_sp(new CDBusParameterList);
	dbus_bool_t bDBusRet;

	do
	{
		if(NULL == DBusInParamList_sp.get())
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}
		pszMethodame = dbus_message_get_member(pDBusMsg);
		if(NULL == pszMethodame)
		{
			break;
		}
		if(Sw_LogDbusCmd)
		{
			LOG_BLINE("SysSrv_CfgMgr_Sig: %s\n", pszMethodame);
		}
#ifdef	__EXCEPTIONS
		try
#endif	//__EXCEPTIONS
		{
			(*DBusInParamList_sp) << pDBusMsg;
		}
#ifdef	__EXCEPTIONS
		catch(CInvArgException & InvArgEx)
		{
			iOutRet = ERROR_INVALID_PARAMETER;
			break;
		}
		catch(CBaseErrException & BaseErrEx)
		{
			iOutRet = BaseErrEx.getBaseErr();
			break;
		}
#endif	//__EXCEPTIONS

		if(0 == strcmp("NewSysCfgIsReady", pszMethodame))
		{
			iRet = SysSrvCfgMgrIf_NewSysCfgIsReady(DBusInParamList_sp);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
			}
		}
	}while(FALSE);

	return iOutRet;
}

#ifdef ENABLE_DTV
INT_t CMediaPlayerApp::On_TuPlayerPropmtMsg(SharedPtr <CGenericMsgData> & MsgData_sp)
{
	INT_t iOutRet = ERROR_SUCCESS;
	DBusMessage * pDBusMsg = NULL;
	dbus_bool_t bDBusRet;
	SharedPtr <CMsgData_PropmtMsg> MsgData_PropmtMsg_sp;
	SharedPtr <CDBusParameterList> DBusReplyParameterList_sp(new CDBusParameterList);
	INT32_t InputPara  = 0;

	do{
		if(NULL == m_pDBusConn)
		{
			iOutRet = ERROR_INVALID_STATE;
			break;
		}

		if(DBusReplyParameterList_sp.isNull())
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}

		MsgData_PropmtMsg_sp = MsgData_sp.DynamicCast<CMsgData_PropmtMsg>();
		if(MsgData_PropmtMsg_sp.isNull())
		{
			PRINT_BFILE_LINENO_BUG_STR;
			break;
		}

		pDBusMsg = dbus_message_new_signal(DBUS_MPLAYER_OBJECT_PATH, DBUS_MPLAYER_OBJECT_INTERFACE,
				MP_SIGNAL_TuPlayerPropmtMsg);
		if(NULL == pDBusMsg)
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}
		InputPara = MsgData_PropmtMsg_sp->m_ProMsgNum;
		(*DBusReplyParameterList_sp) <<InputPara;
		(*DBusReplyParameterList_sp) >> pDBusMsg;
		bDBusRet = dbus_connection_send(m_pDBusConn, pDBusMsg, NULL);
		if(FALSE == bDBusRet)
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}

	}while(FALSE);


	if(pDBusMsg)
	{
		dbus_message_unref(pDBusMsg);
		pDBusMsg = NULL;
	}

	return iOutRet;
}

INT_t CMediaPlayerApp::On_NotifyScanProgress(SharedPtr <CGenericMsgData> & MsgData_sp)
{
	INT_t iOutRet = ERROR_SUCCESS;
	DBusMessage * pDBusMsg = NULL;
	dbus_bool_t bDBusRet;
	SharedPtr <CMsgData_ScanProgress> MsgData_ScanProgress_sp;
	SharedPtr <CDBusParameterList> DBusReplyParameterList_sp(new CDBusParameterList);

	do
	{
		if(NULL == m_pDBusConn)
		{
			iOutRet = ERROR_INVALID_STATE;
			break;
		}

		if(DBusReplyParameterList_sp.isNull())
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}

		MsgData_ScanProgress_sp = MsgData_sp.DynamicCast<CMsgData_ScanProgress>();
		if(MsgData_ScanProgress_sp.isNull())
		{
			PRINT_BFILE_LINENO_BUG_STR;
			break;
		}

		pDBusMsg = dbus_message_new_signal(DBUS_MPLAYER_OBJECT_PATH, DBUS_MPLAYER_OBJECT_INTERFACE,
				MP_SIGNAL_NotifyScanProgress);
		if(NULL == pDBusMsg)
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}

		(*DBusReplyParameterList_sp) << MsgData_ScanProgress_sp->m_ProgramNum;
		(*DBusReplyParameterList_sp) << MsgData_ScanProgress_sp->m_ScanProgress;
		(*DBusReplyParameterList_sp) >> pDBusMsg;
		bDBusRet = dbus_connection_send(m_pDBusConn, pDBusMsg, NULL);
		if(FALSE == bDBusRet)
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}
	}while(FALSE);

	if(pDBusMsg)
	{
		dbus_message_unref(pDBusMsg);
		pDBusMsg = NULL;
	}

	return iOutRet;
}

INT_t CMediaPlayerApp::NotifyScanProgress(UINT32_t PgmNum,UINT32_t Progress)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	SharedPtr<CMessageQueueItem> MsgItem_sp(new CMessageQueueItem);
	SharedPtr <CGenericMsgData> MsgData_sp;
	SharedPtr <CMsgData_ScanProgress> MsgData_ScanProgress_sp(new CMsgData_ScanProgress);

	do{
		if(MsgItem_sp.isNull() || MsgData_ScanProgress_sp.isNull())
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}

		MsgData_ScanProgress_sp->m_uiMsgId = MP_MSG_SCANPROGRESS;
		MsgData_ScanProgress_sp->m_ProgramNum = PgmNum;
		MsgData_ScanProgress_sp->m_ScanProgress = Progress;
		MsgData_sp = MsgData_ScanProgress_sp;
		iRet = MsgItem_sp->SetMessageData(MsgData_sp);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}
		iRet = PostMessage(MsgItem_sp);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}

	}while(FALSE);

	return iOutRet;
}

INT_t CMediaPlayerApp::Tuner_StartScan()
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	SharedPtr<CMessageQueueItem> MsgItem_sp(new CMessageQueueItem);
	SharedPtr <CGenericMsgData> MsgData_sp(new CGenericMsgData);

	do{
		if(MsgItem_sp.isNull() || MsgData_sp.isNull())
		{
			iOutRet = ERROR_INVALID_PARAMETER;
			break;
		}

		MsgData_sp->m_uiMsgId = MP_MSG_STARTSCAN;

		iRet = MsgItem_sp->SetMessageData(MsgData_sp);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}
		iRet = PostMessage(MsgItem_sp);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}
	}while(FALSE);

	return iOutRet;
}

INT_t CMediaPlayerApp::On_StartTunerScan()
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	DBusMessage * pDBusMsg = NULL;
	dbus_bool_t bDBusRet;
	SharedPtr <CDBusParameterList> DBusReplyParameterList_sp(new CDBusParameterList);

	do{
		if(NULL == m_pDBusConn)
		{
			iOutRet = ERROR_INVALID_STATE;
			break;
		}

		if(DBusReplyParameterList_sp.isNull())
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}

		pDBusMsg = dbus_message_new_signal(DBUS_MPLAYER_OBJECT_PATH, DBUS_MPLAYER_OBJECT_INTERFACE,
				MP_SIGNAL_ShowBarForScan);
		if(NULL == pDBusMsg)
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}

		(*DBusReplyParameterList_sp) << 0x10;
		(*DBusReplyParameterList_sp) >> pDBusMsg;
		bDBusRet = dbus_connection_send(m_pDBusConn, pDBusMsg, NULL);
		if(FALSE == bDBusRet)
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}
	}while(FALSE);


	if(pDBusMsg)
	{
		dbus_message_unref(pDBusMsg);
		pDBusMsg = NULL;
	}

	return iOutRet;
}

INT_t CMediaPlayerApp::NotifyTuPlayerPropmtMsg(UINT32_t MsgTag)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	SharedPtr<CMessageQueueItem> MsgItem_sp(new CMessageQueueItem);
	SharedPtr <CGenericMsgData> MsgData_sp;
	SharedPtr <CMsgData_PropmtMsg> MsgData_PropmtMsg_sp(new CMsgData_PropmtMsg);


	do{
		if(MsgItem_sp.isNull() || MsgData_PropmtMsg_sp.isNull())
		{
			iOutRet = ERROR_INVALID_PARAMETER;
			break;
		}

		MsgData_PropmtMsg_sp->m_uiMsgId = MP_MSG_PROPMT_MSG_DONE;
		MsgData_PropmtMsg_sp->m_ProMsgNum = MsgTag;
		MsgData_sp = MsgData_PropmtMsg_sp;
		iRet = MsgItem_sp->SetMessageData(MsgData_sp);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}
		iRet = PostMessage(MsgItem_sp);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}

	}while(FALSE);

	return iOutRet;
}

INT_t CMediaPlayerApp::Tuner_StopScan()
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	SharedPtr<CMessageQueueItem> MsgItem_sp(new CMessageQueueItem);
	SharedPtr <CGenericMsgData> MsgData_sp(new CGenericMsgData);

	do{
		if(MsgItem_sp.isNull() || MsgData_sp.isNull())
		{
			iOutRet = ERROR_INVALID_PARAMETER;
			break;
		}

		MsgData_sp->m_uiMsgId = MP_MSG_SCANDONE;

		iRet = MsgItem_sp->SetMessageData(MsgData_sp);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}
		iRet = PostMessage(MsgItem_sp);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}
	}while(FALSE);

	return iOutRet;
}

INT_t CMediaPlayerApp::On_DoneTunerScan()
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	DBusMessage * pDBusMsg = NULL;
	dbus_bool_t bDBusRet;
	SharedPtr <CDBusParameterList> DBusReplyParameterList_sp(new CDBusParameterList);

	do{
		if(NULL == m_pDBusConn)
		{
			iOutRet = ERROR_INVALID_STATE;
			break;
		}

		if(DBusReplyParameterList_sp.isNull())
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}

		pDBusMsg = dbus_message_new_signal(DBUS_MPLAYER_OBJECT_PATH, DBUS_MPLAYER_OBJECT_INTERFACE,
				MP_SIGNAL_HideBarForScan);
		if(NULL == pDBusMsg)
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}

		(*DBusReplyParameterList_sp) << 0x11;
		(*DBusReplyParameterList_sp) >> pDBusMsg;
		bDBusRet = dbus_connection_send(m_pDBusConn, pDBusMsg, NULL);
		if(FALSE == bDBusRet)
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}
	}while(FALSE);


	if(pDBusMsg)
	{
		dbus_message_unref(pDBusMsg);
		pDBusMsg = NULL;
	}

	return iOutRet;
}

INT_t CMediaPlayerApp::OnDBusCall_TunerScan(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
	SharedPtr <CDBusParameterList> & DBusOutParamList_sp)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	DBusError DBusErr;
	SharedPtr <CDBusParameter_UINT32> DBusParamReplyRet_sp(new CDBusParameter_UINT32);
	INT_t iReplyRet = ERROR_SUCCESS;

	do
	{
		if(NULL == DBusParamReplyRet_sp.get())
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}
		{
			SharedPtr<CDBusParameter> DBusParam_sp = DBusParamReplyRet_sp;
			iRet = DBusOutParamList_sp->addParameter(DBusParam_sp);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
				break;
			}
		}
		
		{
			INT_t iCurrPlayStatus= PLAY_STAT_IDLE;
			iRet = getMpSrvPlayStatus(&iCurrPlayStatus);
			if(ERROR_SUCCESS != iRet) 
			{
				PRINT_BFILE_LINENO_IRET_CRT_ERR;
			}

			if(PLAY_STAT_TUNER_SCANNING == iCurrPlayStatus)
			{
				iOutRet = ERROR_INVALID_STATE;
				iReplyRet = iOutRet;
				break;
			}
		}
		
		iRet = m_oMediaSrv_sp->TunerScan();
		if(ERROR_SUCCESS != iRet)
		{
			iReplyRet = iRet;
		}
	}while(FALSE);

	if(NULL != DBusParamReplyRet_sp.get())
	{
		DBusParamReplyRet_sp->setValue((UINT32_t*)(&iReplyRet));
	}

	return iOutRet;
}


INT_t CMediaPlayerApp::OnDBusCall_GetTunerChannelStrength(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
	SharedPtr <CDBusParameterList> & DBusOutParamList_sp)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	INT_t iReplyRet = ERROR_SUCCESS;
	UINT32_t Strength = 0;

	do{
		iRet = m_oMediaSrv_sp->GetTunerChannelStrength(&Strength);
		if(ERROR_SUCCESS != iRet)
		{
			iReplyRet = iRet;
		}
	}while(FALSE);

	(*DBusOutParamList_sp) << iReplyRet;
	(*DBusOutParamList_sp) << Strength;

	return iOutRet;
}

INT_t CMediaPlayerApp::OnDBusCall_GetTunerMode(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
	SharedPtr <CDBusParameterList> & DBusOutParamList_sp)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	INT_t iReplyRet = ERROR_SUCCESS;
	INT_t iTunerMode = -1;

	do{
		iRet = m_oMediaSrv_sp->GetTunerMode(&iTunerMode);
		if(ERROR_SUCCESS != iRet)
		{
			iReplyRet = iRet;
		}
	}while(FALSE);

	(*DBusOutParamList_sp) << iReplyRet;
	(*DBusOutParamList_sp) << iTunerMode;
	
	return iOutRet;
}


INT_t CMediaPlayerApp::OnDBusCall_TunerMode(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
	SharedPtr <CDBusParameterList> & DBusOutParamList_sp)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	DBusError DBusErr;
	SharedPtr <CDBusParameter_UINT32> DBusParamReplyRet_sp(new CDBusParameter_UINT32);
	INT_t iReplyRet = ERROR_SUCCESS;
	SharedPtr <CDBusParameter> DBusParam_sp;
	SharedPtr <CDBusParameter_INT32> DBusParamTuMode_sp;

	do{
		if(NULL == DBusParamReplyRet_sp.get())
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}

		{
			SharedPtr<CDBusParameter> DBusParam_sp = DBusParamReplyRet_sp;
			iRet = DBusOutParamList_sp->addParameter(DBusParam_sp);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
				break;
			}
		}

		DBusParam_sp = (*DBusInParamList_sp)[0];
		DBusParamTuMode_sp = DBusParam_sp.DynamicCast<CDBusParameter_INT32>();
		if(NULL == DBusParamTuMode_sp.get())
		{
			iReplyRet = ERROR_INVALID_PARAMETER;
			break;
		}

		iRet = m_oMediaSrv_sp->TunerMode((INT32_t )*DBusParamTuMode_sp);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			iReplyRet = iRet;
		}
	}while(FALSE);

	if(NULL != DBusParamReplyRet_sp.get())
	{
		DBusParamReplyRet_sp->setValue((UINT32_t*)(&iReplyRet));
	}

	return iOutRet;
}

INT_t CMediaPlayerApp::OnDBusCall_ChannelDown(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
	SharedPtr <CDBusParameterList> & DBusOutParamList_sp)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	DBusError DBusErr;
	SharedPtr <CDBusParameter> DBusParam_sp;
	SharedPtr <CDBusParameter_UINT32> DBusParamReplyRet_sp(new CDBusParameter_UINT32);
	INT_t iReplyRet = ERROR_SUCCESS;

	do{
		if(NULL == DBusParamReplyRet_sp.get())
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}

		{
			SharedPtr<CDBusParameter> DBusParam_sp = DBusParamReplyRet_sp;
			iRet = DBusOutParamList_sp->addParameter(DBusParam_sp);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
				break;
			}
		}

		iRet = m_oMediaSrv_sp->SetChannelDown();
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			iReplyRet = iRet;
		}

		if(NULL != DBusParamReplyRet_sp.get())
		{
			DBusParamReplyRet_sp->setValue((UINT32_t*)(&iReplyRet));
		}
	}while(FALSE);

	return iOutRet;
}

INT_t CMediaPlayerApp::OnDBusCall_ChannelUp(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
	SharedPtr <CDBusParameterList> & DBusOutParamList_sp)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	DBusError DBusErr;
	SharedPtr <CDBusParameter> DBusParam_sp;
	SharedPtr <CDBusParameter_UINT32> DBusParamReplyRet_sp(new CDBusParameter_UINT32);
	INT_t iReplyRet = ERROR_SUCCESS;

	do{
		if(NULL == DBusParamReplyRet_sp.get())
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}

		{
			SharedPtr<CDBusParameter> DBusParam_sp = DBusParamReplyRet_sp;
			iRet = DBusOutParamList_sp->addParameter(DBusParam_sp);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
				break;
			}
		}

		iRet = m_oMediaSrv_sp->SetChannelUp();
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			iReplyRet = iRet;
		}

		if(NULL != DBusParamReplyRet_sp.get())
		{
			DBusParamReplyRet_sp->setValue((UINT32_t*)(&iReplyRet));
		}
	}while(FALSE);

	return iOutRet;
}

INT_t CMediaPlayerApp::OnDBusCall_ResetDuration(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
	SharedPtr <CDBusParameterList> & DBusOutParamList_sp)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	DBusError DBusErr;
	SharedPtr <CDBusParameter> DBusParam_sp;
	SharedPtr <CDBusParameter_UINT32> DBusParamReplyRet_sp(new CDBusParameter_UINT32);
	INT_t iReplyRet = ERROR_SUCCESS;

	do{
		if(NULL == DBusParamReplyRet_sp.get())
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}

		{
			SharedPtr<CDBusParameter> DBusParam_sp = DBusParamReplyRet_sp;
			iRet = DBusOutParamList_sp->addParameter(DBusParam_sp);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
				break;
			}
		}

		iRet = m_oMediaSrv_sp->ResetDuration();
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			iReplyRet = iRet;
		}

		if(NULL != DBusParamReplyRet_sp.get())
		{
			DBusParamReplyRet_sp->setValue((UINT32_t*)(&iReplyRet));
		}
	}while(FALSE);

	return iOutRet;
}

INT_t CMediaPlayerApp::OnDBusCall_GetEntryChannelInfo(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
	SharedPtr <CDBusParameterList> & DBusOutParamList_sp)
{
	INT_t iOutRet = ERROR_SUCCESS,iRet;
	INT32_t iReplyRet = ERROR_SUCCESS;
	//OUT
	INT32_t channelNumer = 0,subChannelCount = 0;
	DECLARE_CLS_STACK_BUF_STRING(strProgramPids, 64);
	//IN
	SharedPtr <CDBusParameter> DBusParam_sp;
	SharedPtr <CDBusParameter_INT32> DBusParamiEntryId_sp;

	do{
		DBusParam_sp = (*DBusInParamList_sp)[0];
		DBusParamiEntryId_sp = DBusParam_sp.DynamicCast<CDBusParameter_INT32>();
		if(NULL == DBusParamiEntryId_sp.get())
		{
			iReplyRet = ERROR_INVALID_PARAMETER;
			break;
		}

		iRet = m_oMediaSrv_sp->Get_EntryChannelInfo(IN(INT32_t)(*DBusParamiEntryId_sp),OUT &channelNumer,
			OUT &subChannelCount,OUT strProgramPids);
		if(ERROR_SUCCESS != iRet)
		{
			iReplyRet = iRet;
			break;
		}
	}while(FALSE);

	(*DBusOutParamList_sp)<<iReplyRet;
	(*DBusOutParamList_sp)<<channelNumer;
	(*DBusOutParamList_sp)<<subChannelCount;
	(*DBusOutParamList_sp)<<strProgramPids;

	return iOutRet;
}

INT_t CMediaPlayerApp::OnDBusCall_PlayTuner(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
	SharedPtr <CDBusParameterList> & DBusOutParamList_sp)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	DBusError DBusErr;
	SharedPtr <CDBusParameter> DBusParam_sp;
	SharedPtr <CDBusParameter_UINT32> DBusParamReplyRet_sp(new CDBusParameter_UINT32);
	INT_t iReplyRet = ERROR_SUCCESS;
	UINT32_t PlaybackId = 0;

	do{
		if(NULL == DBusParamReplyRet_sp.get())
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}

		{
			SharedPtr<CDBusParameter> DBusParam_sp = DBusParamReplyRet_sp;
			iRet = DBusOutParamList_sp->addParameter(DBusParam_sp);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
				break;
			}
		}

		iRet = m_oMediaSrv_sp->PlayTuner(&PlaybackId);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			iReplyRet = iRet;
		}

		(*DBusOutParamList_sp) << iReplyRet;
		(*DBusOutParamList_sp) << PlaybackId;

		
	}while(FALSE);

	if(NULL != DBusParamReplyRet_sp.get())
	{
		DBusParamReplyRet_sp->setValue((UINT32_t*)(&iReplyRet));
	}

	return iOutRet;
}

INT_t CMediaPlayerApp::OnDBusCall_GetForceTxMode(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
		SharedPtr <CDBusParameterList> & DBusOutParamList_sp)
{
	INT_t iOutRet = ERROR_SUCCESS;
	INT_t iReplyRet = ERROR_SUCCESS;
	INT32_t iEnableTuner = 1;

	do{
		(*DBusOutParamList_sp) << iReplyRet;
		(*DBusOutParamList_sp) << iEnableTuner;
	}while(FALSE);

	return iOutRet;
}

INT_t CMediaPlayerApp::OnDBusCall_GetFirstChNumber(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
		SharedPtr <CDBusParameterList> & DBusOutParamList_sp)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	INT_t iReplyRet = ERROR_SUCCESS;
	UINT32_t OMajor = 0,OMinor = 0;

	do{
		iRet = m_oMediaSrv_sp->GetFirstChNumber(&OMajor,&OMinor);
		if(ERROR_SUCCESS != iRet)
		{
			iReplyRet = iRet;
		}
	}while(FALSE);

	(*DBusOutParamList_sp) << iReplyRet;
	(*DBusOutParamList_sp) << OMajor;
	(*DBusOutParamList_sp) << OMinor;

	return iOutRet;
}

INT_t CMediaPlayerApp::OnDBusCall_setTunerChannelMode(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
		SharedPtr <CDBusParameterList> & DBusOutParamList_sp)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	INT_t iReplyRet = ERROR_SUCCESS;
	DBusError DBusErr;
	SharedPtr <CDBusParameter> DBusParam_sp;
	SharedPtr <CDBusParameter_UINT32> DBusParamReplyRet_sp(new CDBusParameter_UINT32);
	SharedPtr <CDBusParameter_INT32> DBusParamTuChannleMode_sp;

	do{
		if(NULL == DBusParamReplyRet_sp.get())
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}

		{
			SharedPtr<CDBusParameter> DBusParam_sp = DBusParamReplyRet_sp;
			iRet = DBusOutParamList_sp->addParameter(DBusParam_sp);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
				break;
			}
		}

		DBusParam_sp = (*DBusInParamList_sp)[0];
		DBusParamTuChannleMode_sp = DBusParam_sp.DynamicCast<CDBusParameter_INT32>();
		if(NULL == DBusParamTuChannleMode_sp.get())
		{
			iReplyRet = ERROR_INVALID_PARAMETER;
			break;
		}

		iRet = m_oMediaSrv_sp->setTunerChannelMode((INT32_t )*DBusParamTuChannleMode_sp);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			iReplyRet = iRet;
		}
		
	}while(FALSE);

	if(NULL != DBusParamReplyRet_sp.get())
	{
		DBusParamReplyRet_sp->setValue((UINT32_t*)(&iReplyRet));
	}

	return iOutRet;
}

INT_t CMediaPlayerApp::OnDBusCall_getTunerChannelMode(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
		SharedPtr <CDBusParameterList> & DBusOutParamList_sp)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	INT_t iReplyRet = ERROR_SUCCESS;
	INT_t iTunerChannleMode = 0;

	do{
		iRet = m_oMediaSrv_sp->getTunerChannelMode(&iTunerChannleMode);
		if(ERROR_SUCCESS != iRet)
		{
			iReplyRet = iRet;
		}
	}while(FALSE);

	(*DBusOutParamList_sp) << iReplyRet;
	(*DBusOutParamList_sp) << iTunerChannleMode;
	
	return iOutRet;	
}

#endif


INT_t CMediaPlayerApp::OnDBusCall_setDataSource(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
	SharedPtr <CDBusParameterList> & DBusOutParamList_sp)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	DBusError DBusErr;
	SharedPtr <CDBusParameter> DBusParam_sp;
	SharedPtr <CDBusParameter_STRING> DBusParamDataSrcUrl_sp;
	SharedPtr <CDBusParameter_UINT32> DBusParamReplyRet_sp(new CDBusParameter_UINT32);
	INT_t iReplyRet = ERROR_SUCCESS;

	do
	{
		if(NULL == DBusParamReplyRet_sp.get())
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}
		{
			SharedPtr<CDBusParameter> DBusParam_sp = DBusParamReplyRet_sp;
			iRet = DBusOutParamList_sp->addParameter(DBusParam_sp);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
				break;
			}
		}
		if(1 > DBusInParamList_sp->getSize())
		{
			iReplyRet = ERROR_INVALID_PARAMETER;
			break;
		}
		DBusParam_sp = (*DBusInParamList_sp)[0];
		DBusParamDataSrcUrl_sp = DBusParam_sp.DynamicCast<CDBusParameter_STRING>();
		if(NULL == DBusParamDataSrcUrl_sp.get())
		{
			iReplyRet = ERROR_INVALID_PARAMETER;
			break;
		}
		if(Sw_LogDbusCmd)
		{
			LOG("Url:%s\n", (LPCSTR)(*DBusParamDataSrcUrl_sp));
		}
#if 1/*modify by lxj 2012-1-3 for videosync*/
		if( m_VideoSync_sp.isValid() ){
			iRet = m_VideoSync_sp->OnUiSetDataSource((LPCSTR)(*DBusParamDataSrcUrl_sp));
			if(ERROR_SUCCESS != iRet){
				iReplyRet = iRet;
			}
			break;
		}
#endif
		iRet = m_oMediaSrv_sp->setDataSource((LPCSTR)(*DBusParamDataSrcUrl_sp));
		if(ERROR_SUCCESS != iRet)
		{
			iReplyRet = iRet;
		}
	}while(FALSE);

	if(NULL != DBusParamReplyRet_sp.get())
	{
		DBusParamReplyRet_sp->setValue((UINT32_t*)(&iReplyRet));
	}

	return iOutRet;
}


INT_t CMediaPlayerApp::OnDBusCall_Prepare(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
	SharedPtr <CDBusParameterList> & DBusOutParamList_sp)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	DBusError DBusErr;
	SharedPtr <CDBusParameter_UINT32> DBusParamReplyRet_sp(new CDBusParameter_UINT32);
	INT_t iReplyRet = ERROR_SUCCESS;

	do
	{
		if(NULL == DBusParamReplyRet_sp.get())
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}
		{
			SharedPtr<CDBusParameter> DBusParam_sp = DBusParamReplyRet_sp;
			iRet = DBusOutParamList_sp->addParameter(DBusParam_sp);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
				break;
			}
		}
#if 1/*modify by lxj 2012-1-3 for videosync*/
		if( m_VideoSync_sp.isValid() ){
			iRet = m_VideoSync_sp->OnUiPrepare();
			if(ERROR_SUCCESS != iRet){
				iReplyRet = iRet;
			}
			break;
		}
#endif
		iRet = m_oMediaSrv_sp->Prepare();
		if(ERROR_SUCCESS != iRet)
		{
			iReplyRet = iRet;
		}
	}while(FALSE);

	if(NULL != DBusParamReplyRet_sp.get())
	{
		DBusParamReplyRet_sp->setValue((UINT32_t*)(&iReplyRet));
	}

	return iOutRet;
}


INT_t CMediaPlayerApp::OnDBusCall_Play(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
	SharedPtr <CDBusParameterList> & DBusOutParamList_sp)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	DBusError DBusErr;
	SharedPtr <CDBusParameter_UINT32> DBusParamReplyRet_sp(new CDBusParameter_UINT32);
	INT_t iReplyRet = ERROR_SUCCESS;
	UINT32_t PlaybackId = 0;

	do
	{
		if(NULL == DBusParamReplyRet_sp.get())
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}
		{
			SharedPtr<CDBusParameter> DBusParam_sp = DBusParamReplyRet_sp;
			iRet = DBusOutParamList_sp->addParameter(DBusParam_sp);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
				break;
			}
		}
#if 1/*modify by lxj 2012-1-3 for videosync*/
		if( m_VideoSync_sp.isValid() ){
			iRet = m_VideoSync_sp->OnUiPlay(&PlaybackId);
			if(ERROR_SUCCESS != iRet){
				iReplyRet = iRet;
			}
			break;
		}
#endif
		iRet = m_oMediaSrv_sp->Play(&PlaybackId);
		if(ERROR_SUCCESS != iRet)
		{
			iReplyRet = iRet;
		}
	}while(FALSE);

	(*DBusOutParamList_sp) << PlaybackId;
	if(NULL != DBusParamReplyRet_sp.get())
	{
		DBusParamReplyRet_sp->setValue((UINT32_t*)(&iReplyRet));
	}

	return iOutRet;
}

INT_t CMediaPlayerApp::OnDBusCall_Play2(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
	SharedPtr <CDBusParameterList> & DBusOutParamList_sp)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	DBusError DBusErr;
	INT_t iReplyRet = ERROR_SUCCESS;
	UINT32_t PlaybackId = 0;
	CMediaSrv::PLAY_PARAMS PlayParams;

	do
	{
		if(1 > DBusInParamList_sp->getSize())
		{
			iReplyRet = ERROR_INVALID_PARAMETER;
			break;
		}
		PlayParams.LoopCount = (*DBusInParamList_sp)[0]->toInt32();
#if 1/*modify by lxj 2012-1-3 for videosync*/
		PlayParams.bPauseAfterBuffering = FALSE;
		if( m_VideoSync_sp.isValid() ){
			iRet = m_VideoSync_sp->OnUiPlay(&PlaybackId,&PlayParams);
			if(ERROR_SUCCESS != iRet){
				iReplyRet = iRet;
			}
			break;
		}
#endif
		iRet = m_oMediaSrv_sp->Play(&PlaybackId, &PlayParams);
		if(ERROR_SUCCESS != iRet)
		{
			iReplyRet = iRet;
			break;
		}
	}while(FALSE);

	(*DBusOutParamList_sp) << iReplyRet;
	(*DBusOutParamList_sp) << PlaybackId;

	if(Sw_LogDbusCmd)
	{
		LOG_BLINE("Dbus.Play2(Loop=%d) ret %d\n", PlayParams.LoopCount, iReplyRet);
	}

	return iOutRet;
}

INT_t CMediaPlayerApp::OnDBusCall_Stop(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
	SharedPtr <CDBusParameterList> & DBusOutParamList_sp)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	INT_t iReplyRet = ERROR_SUCCESS;
	UINT32_t playbackId = 0;
	DECLARE_CLS_STACK_BUF_STRING(strUrl, 4*1024);

	do
	{
#if 1/*modify by lxj 2012-1-3 for videosync*/
		if( m_VideoSync_sp.isValid() ){
			iRet = m_VideoSync_sp->OnUiStop(&playbackId, &strUrl);
			if(ERROR_SUCCESS != iRet){
				iReplyRet = iRet;
			}
			break;
		}
#endif
		iRet = m_oMediaSrv_sp->Stop(&playbackId, &strUrl);
		if(ERROR_SUCCESS != iRet)
		{
			iReplyRet = iRet;
			break;
		}
	}while(FALSE);

	OnHdmiHotplugChk();

	(*DBusOutParamList_sp) << iReplyRet;
	(*DBusOutParamList_sp) << playbackId;
	(*DBusOutParamList_sp) << strUrl;

	return iOutRet;
}

INT_t CMediaPlayerApp::OnDBusCall_setVideoPosition(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
	SharedPtr <CDBusParameterList> & DBusOutParamList_sp)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	SharedPtr <CDBusParameter_UINT32> DBusParamReplyRet_sp(new CDBusParameter_UINT32);
	INT_t iReplyRet = ERROR_SUCCESS;
	SharedPtr <CDBusParameter> DBusParam_sp;
	SharedPtr <CDBusParameter_INT32> DBusParamX_sp;
	SharedPtr <CDBusParameter_INT32> DBusParamY_sp;
	SharedPtr <CDBusParameter_INT32> DBusParamWidth_sp;
	SharedPtr <CDBusParameter_INT32> DBusParamHeight_sp;

	do
	{
		if(NULL == DBusParamReplyRet_sp.get())
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}
		{
			SharedPtr<CDBusParameter> DBusParam_sp = DBusParamReplyRet_sp;
			iRet = DBusOutParamList_sp->addParameter(DBusParam_sp);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
				break;
			}
		}

		DBusParam_sp = (*DBusInParamList_sp)[0];
		DBusParamX_sp = DBusParam_sp.DynamicCast<CDBusParameter_INT32>();
		if(NULL == DBusParamX_sp.get())
		{
			iReplyRet = ERROR_INVALID_PARAMETER;
			break;
		}
		DBusParam_sp = (*DBusInParamList_sp)[1];
		DBusParamY_sp = DBusParam_sp.DynamicCast<CDBusParameter_INT32>();
		if(NULL == DBusParamY_sp.get())
		{
			iReplyRet = ERROR_INVALID_PARAMETER;
			break;
		}
		DBusParam_sp = (*DBusInParamList_sp)[2];
		DBusParamWidth_sp = DBusParam_sp.DynamicCast<CDBusParameter_INT32>();
		if(NULL == DBusParamWidth_sp.get())
		{
			iReplyRet = ERROR_INVALID_PARAMETER;
			break;
		}
		DBusParam_sp = (*DBusInParamList_sp)[3];
		DBusParamHeight_sp = DBusParam_sp.DynamicCast<CDBusParameter_INT32>();
		if(NULL == DBusParamHeight_sp.get())
		{
			iReplyRet = ERROR_INVALID_PARAMETER;
			break;
		}

		iRet = m_oMediaSrv_sp->setVideoPositionAsync((INT32_t)(*DBusParamX_sp), (INT32_t)(*DBusParamY_sp),
			(INT32_t)(*DBusParamWidth_sp), (INT32_t)(*DBusParamHeight_sp));
		if(ERROR_SUCCESS != iRet)
		{
			iReplyRet = iRet;
		}
	}while(FALSE);

	if(NULL != DBusParamReplyRet_sp.get())
	{
		DBusParamReplyRet_sp->setValue((UINT32_t*)(&iReplyRet));
	}

	return iOutRet;
}

INT_t CMediaPlayerApp::OnDBusCall_setVideoInputWindowSize(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
	SharedPtr <CDBusParameterList> & DBusOutParamList_sp)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	INT_t iReplyRet = ERROR_SUCCESS;
	INT_t inWinX, inWinY, inWinW, inWinH;

	if(4 > DBusInParamList_sp->getSize())
	{
		iReplyRet = ERROR_INVALID_PARAMETER;
		goto EXIT_PROC;
	}

	inWinX = (((*DBusInParamList_sp)[0])->toInt32());
	inWinY = (((*DBusInParamList_sp)[1])->toInt32());
	inWinW = (((*DBusInParamList_sp)[2])->toInt32());
	inWinH = (((*DBusInParamList_sp)[3])->toInt32());

	if(m_oMediaSrv_sp.isNull())
	{
		iReplyRet = ERR_INVALID_STATE;
		goto EXIT_PROC;
	}
	iRet = m_oMediaSrv_sp->setVideoInputWindowSize(inWinX, inWinY, inWinW, inWinH);
	if(ERR_SUCCESS != iRet)
	{
		iReplyRet = iRet;
	}

EXIT_PROC:

	(*DBusOutParamList_sp) << iReplyRet;

	return iOutRet;
}

INT_t CMediaPlayerApp::OnDBusCall_setOsdPosition(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
	SharedPtr <CDBusParameterList> & DBusOutParamList_sp)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	INT_t iReplyRet = ERROR_SUCCESS;
	SharedPtr <CDBusParameter> DBusParam_sp;
	SharedPtr <CDBusParameter_INT32> DBusParamX_sp;
	SharedPtr <CDBusParameter_INT32> DBusParamY_sp;
	SharedPtr <CDBusParameter_INT32> DBusParamWidth_sp;
	SharedPtr <CDBusParameter_INT32> DBusParamHeight_sp;

	do
	{
		if(4 > DBusInParamList_sp->getSize())
		{
			iReplyRet = ERROR_INVALID_PARAMETER;
			break;
		}

		DBusParam_sp = (*DBusInParamList_sp)[0];
		DBusParamX_sp = DBusParam_sp.DynamicCast<CDBusParameter_INT32>();
		if(NULL == DBusParamX_sp.get())
		{
			iReplyRet = ERROR_INVALID_PARAMETER;
			break;
		}
		DBusParam_sp = (*DBusInParamList_sp)[1];
		DBusParamY_sp = DBusParam_sp.DynamicCast<CDBusParameter_INT32>();
		if(NULL == DBusParamY_sp.get())
		{
			iReplyRet = ERROR_INVALID_PARAMETER;
			break;
		}
		DBusParam_sp = (*DBusInParamList_sp)[2];
		DBusParamWidth_sp = DBusParam_sp.DynamicCast<CDBusParameter_INT32>();
		if(NULL == DBusParamWidth_sp.get())
		{
			iReplyRet = ERROR_INVALID_PARAMETER;
			break;
		}
		DBusParam_sp = (*DBusInParamList_sp)[3];
		DBusParamHeight_sp = DBusParam_sp.DynamicCast<CDBusParameter_INT32>();
		if(NULL == DBusParamHeight_sp.get())
		{
			iReplyRet = ERROR_INVALID_PARAMETER;
			break;
		}

		iRet = m_oMediaSrv_sp->setOsdPosition((INT32_t)(*DBusParamX_sp), (INT32_t)(*DBusParamY_sp),
			(INT32_t)(*DBusParamWidth_sp), (INT32_t)(*DBusParamHeight_sp));
		if(ERROR_SUCCESS != iRet)
		{
			iReplyRet = iRet;
		}
	}while(FALSE);

	(*DBusOutParamList_sp) << iReplyRet;

	return iOutRet;
}

INT_t CMediaPlayerApp::OnDBusCall_ChangeVideoOutputMode(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
	SharedPtr <CDBusParameterList> & DBusOutParamList_sp)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	INT32_t iReplyRet = ERROR_SUCCESS;
	VIDEO_OUTPUT_MODE eVoMode = VO_MODE_NotSet, eNewVoMode = VO_MODE_NotSet, eOldVoMode = VO_MODE_NotSet;

	do
	{
		if(1 > DBusInParamList_sp->getSize())
		{
			iReplyRet = ERROR_INVALID_PARAMETER;
			break;
		}
		eVoMode = (typeof(eVoMode))(((*DBusInParamList_sp)[0])->toInt32());
		iRet = m_oMediaSrv_sp->ChangeVidOutMode(eVoMode, &eNewVoMode, &eOldVoMode);
		if(ERROR_SUCCESS != iRet)
		{
			iReplyRet = iRet;
			break;
		}
		//Save the settings to file
		if(eNewVoMode != eOldVoMode)
		{
			iRet = SaveVoMode(eNewVoMode);
			if(ERROR_SUCCESS != iRet)
			{
				iReplyRet = iRet;
				break;
			}
		}
		if(VO_MODE_SPLIT_MODE_MIN_BOUNDARY < eVoMode && eVoMode < VO_MODE_SPLIT_MODE_MAX_BOUNDARY)
		{
			OnChk_DelayedSet_VcrDefaultSurface();
		}
	}while(FALSE);

	(*DBusOutParamList_sp) << iReplyRet;
	(*DBusOutParamList_sp) << eNewVoMode;

	if(Sw_LogDbusCmd)
	{
		LOG_BLINE("ChangeVideoOutputMode,eVoMode=%d,ret=%d\n", eVoMode, iReplyRet);
	}

	return iOutRet;
}

INT_t CMediaPlayerApp::OnDBusCall_setVideoOutputModeAsync(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
	SharedPtr <CDBusParameterList> & DBusOutParamList_sp)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	INT32_t iReplyRet = ERROR_SUCCESS;
	VIDEO_OUTPUT_MODE eVoMode = VO_MODE_NotSet, eNewVoMode = VO_MODE_NotSet, eOldVoMode = VO_MODE_NotSet;

	do
	{
		if(1 > DBusInParamList_sp->getSize())
		{
			iReplyRet = ERROR_INVALID_PARAMETER;
			break;
		}
		eVoMode = (typeof(eVoMode))(((*DBusInParamList_sp)[0])->toInt32());
		iRet = m_oMediaSrv_sp->ChangeVidOutModeAsync(eVoMode, &eNewVoMode, &eOldVoMode);
		if(ERROR_SUCCESS != iRet)
		{
			iReplyRet = iRet;
			break;
		}
#if 0  /*Modify by xuweiwei 2013-11-22 for in 92 mode save error mode*/
		//Save the settings to file
		if(eNewVoMode != eOldVoMode)
		{
			iRet = SaveVoMode(eNewVoMode);
			if(ERROR_SUCCESS != iRet)
			{
				iReplyRet = iRet;
				break;
			}
		}
#endif
		if(VO_MODE_SPLIT_MODE_MIN_BOUNDARY < eVoMode && eVoMode < VO_MODE_SPLIT_MODE_MAX_BOUNDARY)
		{
			OnChk_DelayedSet_VcrDefaultSurface();
		}
	}while(FALSE);

	(*DBusOutParamList_sp) << iReplyRet;
	(*DBusOutParamList_sp) << eNewVoMode;

	if(Sw_LogDbusCmd)
	{
		LOG_BLINE("setVideoOutputModeAsync(%d) ret %d\n", eVoMode, iReplyRet);
	}

	return iOutRet;
}

INT_t CMediaPlayerApp::OnDBusCall_ChangeVolume(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
	SharedPtr <CDBusParameterList> & DBusOutParamList_sp)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	INT32_t iReplyRet = ERROR_SUCCESS;
	INT32_t VolumePercentToChange = 0;
	INT32_t NewVolumePercent = 0;
	BOOL_t bVolChanged = FALSE;

	do
	{
		if(1 > DBusInParamList_sp->getSize())
		{
			iReplyRet = ERROR_INVALID_PARAMETER;
			break;
		}
		VolumePercentToChange = ((*DBusInParamList_sp)[0])->toInt32();
		iRet = m_oMediaSrv_sp->ChangeVolume(VolumePercentToChange, &NewVolumePercent, &bVolChanged);
		if(ERROR_SUCCESS != iRet)
		{
			iReplyRet = iRet;
		}
	}while(FALSE);

	(*DBusOutParamList_sp) << iReplyRet;
	(*DBusOutParamList_sp) << NewVolumePercent;

	if(ERROR_SUCCESS == iOutRet && ERROR_SUCCESS == iReplyRet)
	{
		m_VolumePercent = NewVolumePercent;
	}

	if(bVolChanged)
	{
		if(0 < m_VolumeSaveTimerId)
		{
			iRet = m_GenericTimer.UnregisterTimer(m_VolumeSaveTimerId);
			if(ERROR_SUCCESS != iRet)
			{
				PRINT_BFILE_LINENO_IRET_STR;
			}
			m_VolumeSaveTimerId = 0;
		}
		iRet = m_GenericTimer.RegisterTimer(m_this_wp, OUT m_VolumeSaveTimerId, VOLUME_SAVE_TIMEOUT_MS);
		if(ERROR_SUCCESS != iRet)
		{
			PRINT_BFILE_LINENO_IRET_STR;
		}
	}

	return iOutRet;
}

INT_t CMediaPlayerApp::OnDBusCall_setHwRtcTime(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
	SharedPtr <CDBusParameterList> & DBusOutParamList_sp)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	INT32_t iReplyRet = ERROR_SUCCESS;
	int Year, Month, Date, Hour, Minute, Second;
	DECLARE_CLS_STACK_BUF_STRING(strTimeZone, 128);

	do
	{
		if(7 > DBusInParamList_sp->getSize())
		{
			iReplyRet = ERROR_INVALID_PARAMETER;
			break;
		}
		Year = ((*DBusInParamList_sp)[0])->toInt32();
		Month = ((*DBusInParamList_sp)[1])->toInt32();
		Date = ((*DBusInParamList_sp)[2])->toInt32();
		Hour = ((*DBusInParamList_sp)[3])->toInt32();
		Minute = ((*DBusInParamList_sp)[4])->toInt32();
		Second = ((*DBusInParamList_sp)[5])->toInt32();
		strTimeZone = ((*DBusInParamList_sp)[6])->toString();

		iReplyRet = setHwRtcTime(Year, Month, Date, Hour, Minute, Second, strTimeZone);
	}while(FALSE);

	(*DBusOutParamList_sp) << iReplyRet;

	return iOutRet;
}

INT_t CMediaPlayerApp::OnDBusCall_getTimeZoneSetting(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
	SharedPtr <CDBusParameterList> & DBusOutParamList_sp)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	INT32_t iReplyRet = ERROR_SUCCESS;
	int TimezoneHourOff = 0;

	do
	{
		iReplyRet = getTimeZoneSetting(OUT TimezoneHourOff);
	}while(FALSE);

	(*DBusOutParamList_sp) << iReplyRet;
	(*DBusOutParamList_sp) << TimezoneHourOff;

	return iOutRet;
}

INT_t CMediaPlayerApp::OnDBusCall_setTimeZoneSetting(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
	SharedPtr <CDBusParameterList> & DBusOutParamList_sp)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	INT32_t iReplyRet = ERROR_SUCCESS;
	int TimezoneHourOff = 0;

	do
	{
		if(1 > DBusInParamList_sp->getSize())
		{
			iReplyRet = ERROR_INVALID_PARAMETER;
			break;
		}
		TimezoneHourOff = ((*DBusInParamList_sp)[0])->toInt32();
		iReplyRet = setTimeZoneSetting(TimezoneHourOff);
	}while(FALSE);

	(*DBusOutParamList_sp) << iReplyRet;

	return iOutRet;
}

INT_t CMediaPlayerApp::OnDBusCall_getMonitorInfo(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
	SharedPtr <CDBusParameterList> & DBusOutParamList_sp)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	INT32_t iReplyRet = ERROR_SUCCESS;
	CString strMonitorType;

	do
	{
		iReplyRet = m_oMediaSrv_sp->getMonitorInfo(OUT strMonitorType);
	}while(FALSE);

	(*DBusOutParamList_sp) << iReplyRet;
	(*DBusOutParamList_sp) << strMonitorType;

	return iOutRet;
}

INT_t CMediaPlayerApp::OnDBusCall_setPlayMode(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
	SharedPtr <CDBusParameterList> & DBusOutParamList_sp)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	INT32_t iReplyRet = ERROR_SUCCESS;

	do
	{
		if(1 > DBusInParamList_sp->getSize())
		{
			iReplyRet = ERROR_INVALID_PARAMETER;
			break;
		}
		iReplyRet = m_oMediaSrv_sp->setPlayMode((MediaPlayer::PlayMode)((*DBusInParamList_sp)[0])->toInt32());
	}while(FALSE);

	(*DBusOutParamList_sp) << iReplyRet;

	return iOutRet;
}

INT_t CMediaPlayerApp::OnDBusCall_getPlayMode(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
	SharedPtr <CDBusParameterList> & DBusOutParamList_sp)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	INT32_t iReplyRet = ERROR_SUCCESS;
	MediaPlayer::PlayMode ePlayMode;

	do
	{
		iReplyRet = m_oMediaSrv_sp->getPlayMode(OUT ePlayMode);
	}while(FALSE);

	(*DBusOutParamList_sp) << iReplyRet;
	(*DBusOutParamList_sp) << ePlayMode;

	return iOutRet;
}

INT_t CMediaPlayerApp::OnDBusCall_setDisplayParam(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
	SharedPtr <CDBusParameterList> & DBusOutParamList_sp)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	INT32_t iReplyRet = ERROR_SUCCESS;
	DISP_PARAM_TYPE eDispParamType;
	INT_t iValue;
	BOOL_t bSaveCfg = FALSE;

	do
	{
		if(3 > DBusInParamList_sp->getSize())
		{
			iReplyRet = ERROR_INVALID_PARAMETER;
			break;
		}
		eDispParamType = (DISP_PARAM_TYPE)((*DBusInParamList_sp)[0])->toInt32();
		iValue = ((*DBusInParamList_sp)[1])->toInt32();
		iReplyRet = m_oMediaSrv_sp->setDisplayParam(eDispParamType, iValue);
		if(ERROR_SUCCESS != iReplyRet)
		{
			break;
		}
		bSaveCfg = ((*DBusInParamList_sp)[2])->toInt32();
		if(bSaveCfg)
		{
			iReplyRet = SaveDisplayParam(eDispParamType, iValue);
			if(ERROR_SUCCESS != iReplyRet)
			{
				break;
			}
		}
	}while(FALSE);

	(*DBusOutParamList_sp) << iReplyRet;

	return iOutRet;
}

INT_t CMediaPlayerApp::OnDBusCall_getDisplayParam(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
	SharedPtr <CDBusParameterList> & DBusOutParamList_sp)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	INT32_t iReplyRet = ERROR_SUCCESS;
	DISP_PARAM_TYPE eDispParamType;
	INT_t iValue;
	BOOL_t bSaveCfg = FALSE;

	do
	{
		if(1 > DBusInParamList_sp->getSize())
		{
			iReplyRet = ERROR_INVALID_PARAMETER;
			break;
		}
		eDispParamType = (DISP_PARAM_TYPE)((*DBusInParamList_sp)[0])->toInt32();
		iReplyRet = m_oMediaSrv_sp->getDisplayParam(eDispParamType, OUT iValue);
		if(ERROR_SUCCESS != iReplyRet)
		{
			break;
		}
	}while(FALSE);

	(*DBusOutParamList_sp) << iReplyRet;
	(*DBusOutParamList_sp) << iValue;

	return iOutRet;
}

INT_t CMediaPlayerApp::OnDBusCall_getDisplayPosition(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
	SharedPtr <CDBusParameterList> & DBusOutParamList_sp)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	INT32_t iReplyRet = ERROR_SUCCESS;
	RUA_DISPLAY_TYPE eRuaDispType = RUA_DISP_UNKNOWN;
	int x, y, w, h;

	do
	{
		if(1 > DBusInParamList_sp->getSize())
		{
			iReplyRet = ERROR_INVALID_PARAMETER;
			break;
		}
		eRuaDispType = (RUA_DISPLAY_TYPE)((*DBusInParamList_sp)[0])->toInt32();
		iReplyRet = m_oMediaSrv_sp->getDisplayPosition(eRuaDispType, OUT x, OUT y, OUT w, OUT h);
		if(ERROR_SUCCESS != iReplyRet)
		{
			break;
		}
	}while(FALSE);

	(*DBusOutParamList_sp) << iReplyRet;
	(*DBusOutParamList_sp) << x;
	(*DBusOutParamList_sp) << y;
	(*DBusOutParamList_sp) << w;
	(*DBusOutParamList_sp) << h;

	return iOutRet;
}

INT_t CMediaPlayerApp::OnDBusCall_setMonitorType(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
	SharedPtr <CDBusParameterList> & DBusOutParamList_sp)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	INT32_t iReplyRet = ERROR_SUCCESS;
	MONITOR_MANUFACTURER_ID eMonitorManufacturerId = MONITOR_MANUFACTURER_ID_UNDEFINED;

	do
	{
		if(1 > DBusInParamList_sp->getSize())
		{
			iReplyRet = ERROR_INVALID_PARAMETER;
			break;
		}
		eMonitorManufacturerId = (MONITOR_MANUFACTURER_ID)((*DBusInParamList_sp)[0])->toInt32();;
		iReplyRet = m_oMediaSrv_sp->setMonitorType(eMonitorManufacturerId);
		if(ERROR_SUCCESS != iReplyRet)
		{
			break;
		}
	}while(FALSE);

	(*DBusOutParamList_sp) << iReplyRet;

	return iOutRet;
}

INT_t CMediaPlayerApp::OnDBusCall_getMonitorType(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
	SharedPtr <CDBusParameterList> & DBusOutParamList_sp)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	INT32_t iReplyRet = ERROR_SUCCESS;
	MONITOR_MANUFACTURER_ID eMonitorManufacturerId = MONITOR_MANUFACTURER_ID_UNDEFINED;

	if(Sw_LogDbusCmd)
	{
		LOG("Cmd:getMonitorType\n");
	}

	do
	{
		iReplyRet = m_oMediaSrv_sp->getMonitorType(OUT eMonitorManufacturerId);
		if(ERROR_SUCCESS != iReplyRet)
		{
			break;
		}
	}while(FALSE);

	(*DBusOutParamList_sp) << iReplyRet;
	(*DBusOutParamList_sp) << eMonitorManufacturerId;

	if(Sw_LogDbusCmd)
	{
		LOG("Ret:%d,MonitorType:%d\n", iReplyRet, eMonitorManufacturerId);
	}

	return iOutRet;
}

INT_t CMediaPlayerApp::OnDBusCall_setPlaySpeedCtrlAsync(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
	SharedPtr <CDBusParameterList> & DBusOutParamList_sp)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	INT32_t iReplyRet = ERROR_SUCCESS;
	int PlaybackSpeed;

	do
	{
		if(1 > DBusInParamList_sp->getSize())
		{
			iReplyRet = ERROR_INVALID_PARAMETER;
			break;
		}
		PlaybackSpeed = ((*DBusInParamList_sp)[0])->toInt32();
		iReplyRet = m_oMediaSrv_sp->setPlaySpeedCtrlAsync(PlaybackSpeed);
		if(ERROR_SUCCESS != iReplyRet)
		{
			break;
		}
	}while(FALSE);

	(*DBusOutParamList_sp) << iReplyRet;

	return iOutRet;
}

INT_t CMediaPlayerApp::OnDBusCall_getPlaySpeedCtrl(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
	SharedPtr <CDBusParameterList> & DBusOutParamList_sp)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	INT32_t iReplyRet = ERROR_SUCCESS;
	int PlaybackSpeed;

	do
	{
		iReplyRet = m_oMediaSrv_sp->getPlaySpeedCtrl(OUT PlaybackSpeed);
		if(ERROR_SUCCESS != iReplyRet)
		{
			break;
		}
	}while(FALSE);

	(*DBusOutParamList_sp) << iReplyRet;
	(*DBusOutParamList_sp) << PlaybackSpeed;

	return iOutRet;
}

INT_t CMediaPlayerApp::OnDBusCall_getCurClkTicks(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
	SharedPtr <CDBusParameterList> & DBusOutParamList_sp)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	INT32_t iReplyRet = ERROR_SUCCESS;
	int CurClkTicks;
	struct timeval tv;

	do
	{
		iRet = gettimeofday(&tv, NULL);
		if(0 != iRet)
		{
			iOutRet = ERR_GET_SYS_TIME_FAIL;
			break;
		}
		CurClkTicks = tv.tv_sec;
	}while(FALSE);

	(*DBusOutParamList_sp) << iReplyRet;
	(*DBusOutParamList_sp) << CurClkTicks;

	return iOutRet;
}

INT_t CMediaPlayerApp::OnDBusCall_setCurClkTicks(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
	SharedPtr <CDBusParameterList> & DBusOutParamList_sp)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	INT32_t iReplyRet = ERROR_SUCCESS;
	int CurClkTicks;
	struct timeval tv;
	struct tm tmRtcTimeToSet, *ptmRet;
	time_t RelTimeSec;
	SET_TIME_IN_PARAM setTimeInParam;

	do
	{
		if(1 > DBusInParamList_sp->getSize())
		{
			iReplyRet = ERROR_INVALID_PARAMETER;
			break;
		}
		CurClkTicks = ((*DBusInParamList_sp)[0])->toInt32();
		tv.tv_sec = CurClkTicks;
		tv.tv_usec = 0;
		iRet = settimeofday(&tv, NULL);
		if(0 != iRet)
		{
			iOutRet = ERR_SET_SYS_TIME_FAIL;
			break;
		}
		//set hw rtc time, tmRtcTimeToSet is UTC time
		RelTimeSec = CurClkTicks;
		ZeroMemory(&tmRtcTimeToSet, sizeof(tmRtcTimeToSet));
		ptmRet = gmtime_r(&RelTimeSec, &tmRtcTimeToSet);
		if(NULL == ptmRet)
		{
			iOutRet = ERROR_CALL_SYSTEM_FAILED;
			break;
		}
		setTimeInParam.uiYear = tmRtcTimeToSet.tm_year;
		setTimeInParam.uiMonth = tmRtcTimeToSet.tm_mon + 1;
		setTimeInParam.uiDay = tmRtcTimeToSet.tm_mday;
		setTimeInParam.uiHour = tmRtcTimeToSet.tm_hour;
		setTimeInParam.uiMinute = tmRtcTimeToSet.tm_min;
		setTimeInParam.uiSecond = tmRtcTimeToSet.tm_sec;
		iRet = m_oMediaSrv_sp->setHwRtcTime(&setTimeInParam);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}
	}while(FALSE);

	(*DBusOutParamList_sp) << iReplyRet;

	return iOutRet;
}

INT_t CMediaPlayerApp::OnDBusCall_getConfigDateTime(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
	SharedPtr <CDBusParameterList> & DBusOutParamList_sp)
{
	INT_t iOutRet = ERROR_SUCCESS;
	INT32_t iReplyRet = ERROR_SUCCESS;

	do
	{
	}while(FALSE);

	(*DBusOutParamList_sp) << iReplyRet;
	(*DBusOutParamList_sp) << 0;

	return iOutRet;
}

INT_t CMediaPlayerApp::OnDBusCall_getCpuSerialNo(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
	SharedPtr <CDBusParameterList> & DBusOutParamList_sp)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	INT32_t iReplyRet = ERROR_SUCCESS;
	DECLARE_CLS_STACK_BUF_STRING(strCpuSerialNo, 64);

	do
	{
		iRet = m_oMediaSrv_sp->getCpuSerialNo(OUT strCpuSerialNo);
		if(ERROR_SUCCESS != iRet)
		{
			iReplyRet = iRet;
			break;
		}
	}while(FALSE);

	(*DBusOutParamList_sp) << iReplyRet;
	(*DBusOutParamList_sp) << strCpuSerialNo;

	return iOutRet;
}

/*
ThreadContext: main thread
*/
INT_t CMediaPlayerApp::OnDBusCall_setHdmi3DTvMode(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
	SharedPtr <CDBusParameterList> & DBusOutParamList_sp)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	INT32_t iReplyRet = ERROR_SUCCESS;
	HDMI_3D_TV_MODE eHdmi3DTvMode = H3DTvMode_Normal;

	do
	{
		if(1 > DBusInParamList_sp->getSize())
		{
			iReplyRet = ERROR_INVALID_PARAMETER;
			break;
		}
		eHdmi3DTvMode = (typeof(eHdmi3DTvMode))((*DBusInParamList_sp)[0]->toInt32());
		iRet = m_oMediaSrv_sp->setHdmi3DTvMode(eHdmi3DTvMode);
		if(ERROR_SUCCESS != iRet)
		{
			iReplyRet = iRet;
			break;
		}
	}while(FALSE);

	(*DBusOutParamList_sp) << iReplyRet;

	return iOutRet;
}

INT_t CMediaPlayerApp::OnDBusCall_setConfigDateTime(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
	SharedPtr <CDBusParameterList> & DBusOutParamList_sp)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	INT32_t iReplyRet = ERROR_SUCCESS;
	int CurClkTicks;
	struct timeval tv;
	struct tm tmRtcTimeToSet, *ptmRet;
	time_t RelTimeSec;
	SET_TIME_IN_PARAM setTimeInParam;

	do
	{
		if(1 > DBusInParamList_sp->getSize())
		{
			iReplyRet = ERROR_INVALID_PARAMETER;
			break;
		}
		iRet = gettimeofday(&tv, NULL);
		if(0 != iRet)
		{
			iOutRet = ERR_GET_SYS_TIME_FAIL;
			break;
		}
		CurClkTicks = tv.tv_sec;
		//set hw rtc time, tmRtcTimeToSet is UTC time
		RelTimeSec = CurClkTicks;
		ZeroMemory(&tmRtcTimeToSet, sizeof(tmRtcTimeToSet));
		ptmRet = gmtime_r(&RelTimeSec, &tmRtcTimeToSet);
		if(NULL == ptmRet)
		{
			iOutRet = ERROR_CALL_SYSTEM_FAILED;
			break;
		}
		setTimeInParam.uiYear = tmRtcTimeToSet.tm_year;
		setTimeInParam.uiMonth = tmRtcTimeToSet.tm_mon + 1;
		setTimeInParam.uiDay = tmRtcTimeToSet.tm_mday;
		setTimeInParam.uiHour = tmRtcTimeToSet.tm_hour;
		setTimeInParam.uiMinute = tmRtcTimeToSet.tm_min;
		setTimeInParam.uiSecond = tmRtcTimeToSet.tm_sec;
		iRet = m_oMediaSrv_sp->setHwRtcTime(&setTimeInParam);
		if(ERROR_SUCCESS != iRet)
		{
			iReplyRet = iRet;
			break;
		}
	}while(FALSE);

	(*DBusOutParamList_sp) << iReplyRet;

	return iOutRet;
}

INT_t CMediaPlayerApp::OnDBusCall_setOutputSpdifMode(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
	SharedPtr <CDBusParameterList> & DBusOutParamList_sp)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	INT32_t iReplyRet = ERROR_SUCCESS;
	INT32_t iOutputSpdifMode = -1;

	do{
		if(m_oMediaSrv_sp.isNull())
		{
			iOutRet = ERROR_INVALID_PARAMETER;
			break;
		}
		
		iOutputSpdifMode = (INT32_t)(((*DBusInParamList_sp)[0])->toInt32());
		iRet = m_oMediaSrv_sp->setOutputSpdifMode((const INT32_t)iOutputSpdifMode);
		if(ERROR_SUCCESS != iRet)
		{
			iReplyRet = iRet;
			break;
		}
		//schedule a display output update immediately
		{
			SharedPtr<CMessageQueueItem> MsgItem_sp(new CMessageQueueItem);
			SharedPtr <CGenericMsgData> MsgData_sp(new CGenericMsgData);
			if(MsgItem_sp.isNull() || MsgData_sp.isNull())
			{
				iReplyRet = ERROR_OUT_OF_MEMORY;
				break;
			}
			MsgData_sp->m_uiMsgId = MP_MSG_DISP_OUT_UPDATE;
			iRet = MsgItem_sp->SetMessageData(MsgData_sp);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
				break;
			}
			iRet = PostMessage(MsgItem_sp);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
				break;
			}
		}
	}while(FALSE);

	(*DBusOutParamList_sp) << iReplyRet;

	return iOutRet;
}

INT_t CMediaPlayerApp::OnDBusCall_getOutputSpdifMode(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
	SharedPtr <CDBusParameterList> & DBusOutParamList_sp)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	INT32_t iReplyRet = ERROR_SUCCESS;
	INT32_t iOutputSpdifMode = -1;

	do{
		if(m_oMediaSrv_sp.isNull())
		{
			iOutRet = ERROR_INVALID_PARAMETER;
			break;
		}
		
		iRet = m_oMediaSrv_sp->getOutputSpdifMode(&iOutputSpdifMode);
		if(ERROR_SUCCESS != iRet)
		{
			iReplyRet = iRet;
			break;
		}
		
	}while(FALSE);

	(*DBusOutParamList_sp) << iReplyRet;
	(*DBusOutParamList_sp) << iOutputSpdifMode;

	return iOutRet;
}

INT_t CMediaPlayerApp::OnDBusCall_setVideoDispAspectRatio(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
	SharedPtr <CDBusParameterList> & DBusOutParamList_sp)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	INT32_t iReplyRet = ERROR_SUCCESS;
	DISPLAY_ASPECT_RATIO eDispAspectRatio = DispAspectRatio_DEFAULT;
	UINT32_t OptFlag = 0x00000000;

	do
	{
		if(2 > DBusInParamList_sp->getSize())
		{
			iReplyRet = ERROR_INVALID_PARAMETER;
			break;
		}
		eDispAspectRatio = (typeof(eDispAspectRatio))(((*DBusInParamList_sp)[0])->toInt32());
		OptFlag = ((*DBusInParamList_sp)[1])->toUint32();
		iRet = m_oMediaSrv_sp->setVideoDispAspectRatio(eDispAspectRatio, OptFlag);
		if(ERROR_SUCCESS != iRet)
		{
			iReplyRet = iRet;
			break;
		}
	}while(FALSE);

	(*DBusOutParamList_sp) << iReplyRet;

	if(Sw_LogDbusCmd)
	{
		LOG_BLINE("setVideoDispAspectRatio,eDispAspectRatio=%d,OptFlag:0x%08x,iOutRet=%d\n", eDispAspectRatio, OptFlag, iReplyRet);
	}

	return iOutRet;
}

#if 1/*added by lxj 2012-9-28*/
INT_t CMediaPlayerApp::OnDBusCall_getVideoDispAspectRatio(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
	SharedPtr <CDBusParameterList> & DBusOutParamList_sp)
{
	INT_t iRet;
	INT32_t iReplyRet = ERROR_SUCCESS;
	DISPLAY_ASPECT_RATIO eReplyDispAspectRatio = DispAspectRatio_DEFAULT;

	do
	{
		iRet = m_oMediaSrv_sp->getVideoDispAspectRatio(eReplyDispAspectRatio);
		if(ERROR_SUCCESS != iRet)
		{
			iReplyRet = iRet;
			break;
		}
	}while(FALSE);

	(*DBusOutParamList_sp) << iReplyRet;
	(*DBusOutParamList_sp) << eReplyDispAspectRatio;

	if(Sw_LogDbusCmd)
	{
		LOG_BLINE("getVideoDispAspectRatio,eReplyDispAspectRatio=%d,iReplyRet=%d\n", eReplyDispAspectRatio, iReplyRet);
	}

	return iRet;
}
#endif

INT_t CMediaPlayerApp::OnDBusCall_setHdmiAudioOutput(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
	SharedPtr <CDBusParameterList> & DBusOutParamList_sp)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	INT32_t iReplyRet = ERROR_SUCCESS;
	BOOL_t bEnable = TRUE;

	do
	{
		if(1 > DBusInParamList_sp->getSize())
		{
			iReplyRet = ERROR_INVALID_PARAMETER;
			break;
		}
		bEnable = (typeof(bEnable))(((*DBusInParamList_sp)[0])->toInt32());
		iRet = m_oMediaSrv_sp->setHdmiAudioOutput(bEnable);
		if(ERROR_SUCCESS != iRet)
		{
			iReplyRet = iRet;
			break;
		}
		//schedule a display output update immediately
		{
			SharedPtr<CMessageQueueItem> MsgItem_sp(new CMessageQueueItem);
			SharedPtr <CGenericMsgData> MsgData_sp(new CGenericMsgData);
			if(MsgItem_sp.isNull() || MsgData_sp.isNull())
			{
				iReplyRet = ERROR_OUT_OF_MEMORY;
				break;
			}
			MsgData_sp->m_uiMsgId = MP_MSG_DISP_OUT_UPDATE;
			iRet = MsgItem_sp->SetMessageData(MsgData_sp);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
				break;
			}
			iRet = PostMessage(MsgItem_sp);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
				break;
			}
		}
	}while(FALSE);

	(*DBusOutParamList_sp) << iReplyRet;

	if(Sw_LogDbusCmd)
	{
		LOG_BLINE("setHdmiAudioOutput(%d),iReplyRet=%d\n", bEnable, iReplyRet);
	}

	return iOutRet;
}

INT_t CMediaPlayerApp::OnDBusCall_setAnalogAudioMute(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
	SharedPtr <CDBusParameterList> & DBusOutParamList_sp)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	INT32_t iReplyRet = ERROR_SUCCESS;
	BOOL_t bMute = FALSE;

	do
	{
		if(1 > DBusInParamList_sp->getSize())
		{
			iReplyRet = ERROR_INVALID_PARAMETER;
			break;
		}
		bMute = (typeof(bMute))(((*DBusInParamList_sp)[0])->toInt32());
		iRet = m_oMediaSrv_sp->setAnalogAudioMute(bMute);
		if(ERROR_SUCCESS != iRet)
		{
			iReplyRet = iRet;
			break;
		}
	}while(FALSE);

	(*DBusOutParamList_sp) << iReplyRet;

	if(Sw_LogDbusCmd)
	{
		LOG_BLINE("setAnalogAudioMute(%d),iReplyRet=%d\n", bMute, iReplyRet);
	}

	return iOutRet;
}

/*
ThreadContext: main thread
*/
INT_t CMediaPlayerApp::OnDBusCall_setSerialParameters(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
	SharedPtr <CDBusParameterList> & DBusOutParamList_sp)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	INT32_t iReplyRet = ERROR_SUCCESS;
	SERIAL_PORT_PARAM newSerialPortParamVal;

	do
	{
		if(1 > DBusInParamList_sp->getSize())
		{
			iReplyRet = ERROR_INVALID_PARAMETER;
			break;
		}
		iRet = SerialPortParamDesc_To_ParamValue(((*DBusInParamList_sp)[0])->toString(), &newSerialPortParamVal);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}
		//Cache the settings
		m_SerialPortParam = newSerialPortParamVal;
		//Save the setting string to persistent storage
		iRet = SysProp_setPersistent(SysProp_KEY_SerialParameters, ((*DBusInParamList_sp)[0])->toString());
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}
		//set parameters on port
		//set baudrate, etc.
		iRet = m_SerialComPort_sp->setComParameters(m_SerialPortParam.iBaudrate,
			m_SerialPortParam.eSerialParity, m_SerialPortParam.iDataBits, m_SerialPortParam.iStopBits);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}
	}while(FALSE);

	(*DBusOutParamList_sp) << iReplyRet;

	return iOutRet;
}

/*
ThreadContext: main thread
*/
INT_t CMediaPlayerApp::OnDBusCall_getSerialParameters(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
	SharedPtr <CDBusParameterList> & DBusOutParamList_sp)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	INT32_t iReplyRet = ERROR_SUCCESS;
	DECLARE_CLS_STACK_BUF_STRING(strSerialParameters, 64);

	do
	{
		iRet = SerialPortParmVal_To_Desc(&m_SerialPortParam, OUT strSerialParameters);
		if(ERROR_SUCCESS != iRet)
		{
			iReplyRet = iRet;
			break;
		}
	}while(FALSE);

	(*DBusOutParamList_sp) << iReplyRet;
	(*DBusOutParamList_sp) << strSerialParameters;

	return iOutRet;
}

INT_t CMediaPlayerApp::OnDBusCall_getSerialControlData(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
	SharedPtr <CDBusParameterList> & DBusOutParamList_sp)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	INT32_t iReplyRet = ERROR_SUCCESS;
	CByteArray2 receivedSerialData;

	do
	{
		iRet = m_SerialComPort_sp->ReadResult(OUT receivedSerialData);
		if(ERROR_SUCCESS != iRet)
		{
			iReplyRet = iRet;
			break;
		}
		iRet = receivedSerialData.Add('\0');
		if(ERROR_SUCCESS != iRet)
		{
			iReplyRet = iRet;
		}
	}while(FALSE);

	(*DBusOutParamList_sp) << iReplyRet;
	(*DBusOutParamList_sp) << ((LPCSTR)(receivedSerialData.GetData()));

	return iOutRet;
}

INT_t CMediaPlayerApp::OnDBusCall_setSerialControlData(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
	SharedPtr <CDBusParameterList> & DBusOutParamList_sp)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	INT32_t iReplyRet = ERROR_SUCCESS;
	DECLARE_CLS_STACK_BUF_STRING(strSerialControlData, 1024);

	do
	{
		if(1 > DBusInParamList_sp->getSize())
		{
			iReplyRet = ERROR_INVALID_PARAMETER;
			break;
		}
		strSerialControlData = ((*DBusInParamList_sp)[0])->toString();
		iRet = m_SerialComPort_sp->SendCommand(strSerialControlData);
		if(ERROR_SUCCESS != iRet)
		{
			iReplyRet = iRet;
			break;
		}
	}while(FALSE);

	(*DBusOutParamList_sp) << iReplyRet;

	return iOutRet;
}

INT_t CMediaPlayerApp::OnDBusCall_setGpioLedStatus(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
	SharedPtr <CDBusParameterList> & DBusOutParamList_sp)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	INT32_t iReplyRet = ERROR_SUCCESS;
	UINT32_t GpioLedStatusToSet, NewActualLedStatus = 0;

	do
	{
		if(1 > DBusInParamList_sp->getSize())
		{
			iReplyRet = ERROR_INVALID_PARAMETER;
			break;
		}
		GpioLedStatusToSet = ((*DBusInParamList_sp)[0])->toUint32();
		iReplyRet = m_oMediaSrv_sp->setGpioLedStatus(GpioLedStatusToSet, OUT NewActualLedStatus);
	}while(FALSE);

	(*DBusOutParamList_sp) << iReplyRet;
	(*DBusOutParamList_sp) << NewActualLedStatus;

	return iOutRet;
}

INT_t CMediaPlayerApp::OnDBusCall_DisplayOnLedScreen(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
	SharedPtr <CDBusParameterList> & DBusOutParamList_sp)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	DBusError DBusErr;
	INT32_t iReplyRet = ERROR_SUCCESS;
	DECLARE_CLS_STACK_BUF_STRING(strContentToDisp, 64);
	INT_t StartPosToDisp;

	do
	{
		if(2 > DBusInParamList_sp->getSize())
		{
			iReplyRet = ERROR_INVALID_PARAMETER;
			break;
		}
		strContentToDisp = ((*DBusInParamList_sp)[0])->toString();
		StartPosToDisp = ((*DBusInParamList_sp)[1])->toInt32();
		iReplyRet = m_oMediaSrv_sp->DisplayOnLedScreen(strContentToDisp, StartPosToDisp);
	}while(FALSE);

	(*DBusOutParamList_sp) << iReplyRet;

	return iOutRet;
}

INT_t CMediaPlayerApp::OnDBusCall_DispOnLedScrAsync(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
	SharedPtr <CDBusParameterList> & DBusOutParamList_sp)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	DBusError DBusErr;
	INT32_t iReplyRet = ERROR_SUCCESS;
	DECLARE_CLS_STACK_BUF_STRING(strContentToDisp, 64);
	INT_t StartPosToDisp;

	do
	{
		if(2 > DBusInParamList_sp->getSize())
		{
			iReplyRet = ERROR_INVALID_PARAMETER;
			break;
		}
		strContentToDisp = ((*DBusInParamList_sp)[0])->toString();
		StartPosToDisp = ((*DBusInParamList_sp)[1])->toInt32();
		iReplyRet = m_oMediaSrv_sp->DispOnLedScrAsync(strContentToDisp, StartPosToDisp);
	}while(FALSE);

	(*DBusOutParamList_sp) << iReplyRet;

	return iOutRet;
}

INT_t CMediaPlayerApp::DBusIntrospectableIf_Introspect(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
	SharedPtr <CDBusParameterList> & DBusOutParamList_sp)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	DBusError DBusErr;
	SharedPtr <CDBusParameter_STRING> DBusParam_IntrospectXml_sp(new CDBusParameter_STRING);

	do
	{
		if(DBusParam_IntrospectXml_sp.isNull())
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}
		DBusParam_IntrospectXml_sp->setValue(g_pszMediaPlayer_Introspect);
		{
			SharedPtr<CDBusParameter> DBusParam_sp = DBusParam_IntrospectXml_sp;
			iRet = DBusOutParamList_sp->addParameter(DBusParam_sp);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
				break;
			}
		}
	}while(FALSE);

	return iOutRet;
}

/*
Thread context: main thread
*/
INT_t CMediaPlayerApp::SysSrvCfgMgrIf_NewSysCfgIsReady(SharedPtr <CDBusParameterList> & DBusInParamList_sp)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	CString strSysCfgDirPath;
	DECLARE_CLS_STACK_BUF_STRING(strShellCmd, 1024);

	if(Sw_LogDbusCmd)
	{
		LOG_BLINE("NewSysCfgIsReady\n");
	}

	do
	{
		if(1 > DBusInParamList_sp->getSize())
		{
			iOutRet = ERROR_INVALID_PARAMETER;
			break;
		}

		strSysCfgDirPath = (((*DBusInParamList_sp)[0])->toString());
		if(Sw_LogDbusCmd)
		{
			LOG_BLINE("  SysCfgDirPath=%s\n", (LPCSTR)(strSysCfgDirPath));
		}
		// /etc/localtime
		iRet = strShellCmd.Format(
			"rm -f /etc/localtime;"
			"cp -fa \"%s/etc/localtime\" /etc/localtime",
			(LPCSTR)strSysCfgDirPath);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}
		iRet = system(strShellCmd);
		if(ERROR_SUCCESS != iRet)
		{
			LOG_BLINE("Cmd(%s) ret %d\n", (LPCSTR)strShellCmd, iRet);
		}
		//make timezone to take effect immediately
		tzset();
		// /MP7XX/Config/MediaPlayer.xml
		iRet = strShellCmd.Format("cp -fa \"%s/MP7XX/Config/MediaPlayer.xml\" /MP7XX/Config/MediaPlayer.xml", (LPCSTR)strSysCfgDirPath);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}
		iRet = system(strShellCmd);
		if(ERROR_SUCCESS != iRet)
		{
			LOG_BLINE("Cmd(%s) ret %d\n", (LPCSTR)strShellCmd, iRet);
		}
#ifdef ENABLE_DTV
		//Program.data
		do
		{
			DECLARE_CLS_STACK_BUF_STRING(strSrcFilePath,1024);
			iRet = strSrcFilePath.Format("%s/data/Program.data", (LPCSTR)strSysCfgDirPath);
			if(ERROR_SUCCESS != iRet)
			{
				PRINT_BFILE_LINENO_IRET_STR;
				break;
			}
			int bExist = FALSE;
			iRet = ExistFile((LPCSTR)strSrcFilePath, &bExist);
			if(ERROR_SUCCESS != iRet)
			{
				PRINT_BFILE_LINENO_IRET_STR;
				break;
			}
			if(FALSE == bExist)
			{
				break;
			}
			//exist, then copy
			iRet = strShellCmd.Format("cp -fa \"%s/data/Program.data\" /data/Program.data", (LPCSTR)strSysCfgDirPath);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
				break;
			}
			iRet = system(strShellCmd);
			if(ERROR_SUCCESS != iRet)
			{
				LOG_BLINE("Cmd(%s) ret %d\n", (LPCSTR)strShellCmd, iRet);
			}

			if(m_oMediaSrv_sp.isNull())
			{
				iOutRet = ERROR_INVALID_PARAMETER;
				break;
			}

			iRet = m_oMediaSrv_sp->ReLoadProgramTable();
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
				break;
			}
		}while(FALSE);
#endif
	}while(FALSE);

	return iOutRet;
}

VOID CMediaPlayerApp::OnHdmiHotplugChk()
{
	m_oMediaSrv_sp->OutputDisplayUpdate();
}

VOID CMediaPlayerApp::OnSaveVolume()
{
	INT_t iRet;
	bool bRet;
	bool bCreateNodeIfNotExist = TRUE;

	do
	{
		iRet = m_SettingXmlDoc_sp->setElementPropertyValue(XML_VOLUME_ELEMENT_PATH, AUD_ENG0_MASTER_NAME, m_VolumePercent,
			bCreateNodeIfNotExist);
		if(ERROR_SUCCESS != iRet)
		{
			PRINT_BFILE_LINENO_IRET_STR;
			break;
		}
		bRet = m_SettingXmlDoc_sp->SaveFile(MP_SETTING_XML_DOC_PATH);
		if(false == bRet)
		{
			LOG_BLINE("Save vol err\n");
		}
		sync();
	}while(FALSE);
}

INT_t CMediaPlayerApp::setHwRtcTime(int Year, int Month, int Date, int Hour, int Minute, int Second, LPCSTR pszTimeZone)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	struct tm tmSystemTimeToSet, tmRtcTimeToSet, *ptmRet;
	time_t RelTimeSec;
	int TimeZoneHourOff;
	RMstatus eRMstatus;
	SET_TIME_IN_PARAM setTimeInParam;

	do
	{
		if(NULL == pszTimeZone)
		{
			iOutRet = ERROR_INVALID_PARAMETER;
			break;
		}
		TimeZoneHourOff = atoi(pszTimeZone);

		ZeroMemory(&tmSystemTimeToSet, sizeof(tmSystemTimeToSet));
		tmSystemTimeToSet.tm_year = Year - 1900;
		tmSystemTimeToSet.tm_mon = Month - 1;
		tmSystemTimeToSet.tm_mday = Date;
		tmSystemTimeToSet.tm_hour = Hour;
		tmSystemTimeToSet.tm_min = Minute;
		tmSystemTimeToSet.tm_sec = Second;

		//set system global timezone settings
		iRet = CSystemTimezone::setSystemGlobalTimeZone(TimeZoneHourOff);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}
		tzset();

		//local time => UTC time
		RelTimeSec = mktime(&tmSystemTimeToSet);

		//set system UTC time
		iRet = stime(&RelTimeSec);
		if(0 != iRet)
		{
			iOutRet = ERROR_CALL_SYSTEM_FAILED;
			break;
		}

		//set hw rtc time, tmRtcTimeToSet is UTC time
		ZeroMemory(&tmRtcTimeToSet, sizeof(tmRtcTimeToSet));
		ptmRet = gmtime_r(&RelTimeSec, &tmRtcTimeToSet);
		if(NULL == ptmRet)
		{
			iOutRet = ERROR_CALL_SYSTEM_FAILED;
			break;
		}
		setTimeInParam.uiYear = tmRtcTimeToSet.tm_year;
		setTimeInParam.uiMonth = tmRtcTimeToSet.tm_mon + 1;
		setTimeInParam.uiDay = tmRtcTimeToSet.tm_mday;
		setTimeInParam.uiHour = tmRtcTimeToSet.tm_hour;
		setTimeInParam.uiMinute = tmRtcTimeToSet.tm_min;
		setTimeInParam.uiSecond = tmRtcTimeToSet.tm_sec;
		iRet = m_oMediaSrv_sp->setHwRtcTime(&setTimeInParam);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}
	}while(FALSE);

	return iOutRet;
}

INT_t CMediaPlayerApp::getTimeZoneSetting(OUT int & TimezoneHourOff)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	time_t timeUTC, timeLocal;
	struct tm tmLocal;
	struct tm * ptmRet = NULL;

	do
	{
		/*
		system("echo TZ=${TZ}");
		system("date");
		system("date -u");
		*/
		timeUTC = time(NULL);
		if(-1 == timeUTC)	//error
		{
			iOutRet = ERR_GET_SYS_TIME_FAIL;
			break;
		}
		//LOG_BLINE("timeUTC=%d\n", timeUTC);

		ptmRet = localtime_r(&timeUTC, &tmLocal);
		if(NULL == ptmRet)
		{
			iOutRet = ERR_GET_SYS_TIME_FAIL;
			break;
		}
		timeLocal = timegm(&tmLocal);
		//LOG_BLINE("timeLocal=%d\n", timeLocal);

		/*
		{
			time_t timeSysUtc;
			iRet = CSystemTimezone::getSysUtcTime(OUT timeSysUtc);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
				break;
			}
			LOG_BLINE("timeSysUtc=%d\n", timeSysUtc);
		}
		*/

		TimezoneHourOff = (timeLocal - timeUTC) / (1*60*60);
	}while(FALSE);

	return iOutRet;
}

INT_t CMediaPlayerApp::setTimeZoneSetting(int TimezoneHourOff)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;

	do
	{
		//set system global timezone settings
		iRet = CSystemTimezone::setSystemGlobalTimeZone(TimezoneHourOff);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}
		tzset();
	}while(FALSE);

	return iOutRet;
}

INT_t CMediaPlayerApp::SyncSysTimeToHwRtc()
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	int CurClkTicks;
	struct timeval tv;
	struct tm tmRtcTimeToSet, *ptmRet;
	time_t RelTimeSec;
	SET_TIME_IN_PARAM setTimeInParam;

	do
	{
		iRet = gettimeofday(&tv, NULL);
		if(0 != iRet)
		{
			iOutRet = ERR_GET_SYS_TIME_FAIL;
			break;
		}
		CurClkTicks = tv.tv_sec;
		//set hw rtc time, tmRtcTimeToSet is UTC time
		RelTimeSec = CurClkTicks;
		ZeroMemory(&tmRtcTimeToSet, sizeof(tmRtcTimeToSet));
		ptmRet = gmtime_r(&RelTimeSec, &tmRtcTimeToSet);
		if(NULL == ptmRet)
		{
			iOutRet = ERROR_CALL_SYSTEM_FAILED;
			break;
		}
		setTimeInParam.uiYear = tmRtcTimeToSet.tm_year;
		setTimeInParam.uiMonth = tmRtcTimeToSet.tm_mon + 1;
		setTimeInParam.uiDay = tmRtcTimeToSet.tm_mday;
		setTimeInParam.uiHour = tmRtcTimeToSet.tm_hour;
		setTimeInParam.uiMinute = tmRtcTimeToSet.tm_min;
		setTimeInParam.uiSecond = tmRtcTimeToSet.tm_sec;
		iRet = m_oMediaSrv_sp->setHwRtcTime(&setTimeInParam);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}
	}while(FALSE);

	return iOutRet;
}

VOID CMediaPlayerApp::NotifyExitApp()
{
	INT_t iRet;

	do
	{
		m_bShouldExitApp = TRUE;
	}while(FALSE);
}

INT_t CMediaPlayerApp::ConnectDBus()
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	DBusError DBusErr;
	dbus_bool_t bDbusRet;

	do
	{
		//Server connection
		dbus_error_init(&DBusErr);
		m_pDBusConn = dbus_bus_get_private(DBUS_BUS_SYSTEM, &DBusErr);
		if(NULL == m_pDBusConn)
		{
			iOutRet = ERR_CONNECTION_FAIL;
			break;
		}
		if(dbus_error_is_set(&DBusErr))
		{
			iOutRet = ERR_CONNECTION_FAIL;
			dbus_error_free(&DBusErr);
			break;
		}
		dbus_connection_set_exit_on_disconnect(m_pDBusConn, FALSE);
		//Register fd event callbacks
		bDbusRet = dbus_connection_set_watch_functions(m_pDBusConn, DBusAddWatchCb, DBusRemoveWatchCb, NULL, this, NULL);
		if(FALSE == bDbusRet)
		{
			iOutRet = ERR_CONNECTION_FAIL;
			break;
		}
	}while(FALSE);

	return iOutRet;
}

INT_t CMediaPlayerApp::disconnectDBus()
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	dbus_bool_t bDbusRet;

	do
	{
		if(m_pDBusConn)
		{
			//no more watching
			bDbusRet = dbus_connection_set_watch_functions(m_pDBusConn, NULL, NULL, NULL, this, NULL);
			if(FALSE == bDbusRet)
			{
				LOG_BLINE("DbusConnSetWatchFunc(NULL) failed\n");
			}

			dbus_connection_close(m_pDBusConn);
			dbus_connection_unref(m_pDBusConn);
			m_pDBusConn = NULL;
		}
	}while(FALSE);

	return iOutRet;
}

INT_t CMediaPlayerApp::setDBusService()
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	DBusError DBusErr;

	do
	{
		dbus_error_init(&DBusErr);
		iRet = dbus_bus_request_name(m_pDBusConn, DBUS_MPLAYER_SERVICE_NAME, 0, &DBusErr);
		if(-1 == iRet)
		{
			iOutRet = ERR_SETUP_FAIL;
			dbus_error_free(&DBusErr);
			break;
		}
		else if(2 == iRet)
		{
			iOutRet = ERR_SETUP_FAIL;
			LOG_BLINE("Srv \"%s\" reg fail\n", DBUS_MPLAYER_SERVICE_NAME);
			break;
		}
		//LOG_BLINE("iRet=%d\n", iRet);
		dbus_bus_add_match(m_pDBusConn, "type='signal',interface='" DBUS_IF_freedesktop_DBus "'", &DBusErr);
		if(dbus_error_is_set(&DBusErr))
		{
			iOutRet = ERR_SETUP_FAIL;
			dbus_error_free(&DBusErr);
			break;
		}
		dbus_bus_add_match(m_pDBusConn, "type='signal',interface='" DBUS_MPLAYER_OBJECT_INTERFACE "'", &DBusErr);
		if(dbus_error_is_set(&DBusErr))
		{
			iOutRet = ERR_SETUP_FAIL;
			dbus_error_free(&DBusErr);
			break;
		}
		dbus_bus_add_match(m_pDBusConn, "type='signal',interface='" DBUS_SystemService_NetMgrSrv_If "'", &DBusErr);
		if(dbus_error_is_set(&DBusErr))
		{
			iOutRet = ERR_SETUP_FAIL;
			dbus_error_free(&DBusErr);
			break;
		}
		dbus_bus_add_match(m_pDBusConn, "type='signal',interface='" DBUS_SysSrv_SysEvt_If "'", &DBusErr);
		if(dbus_error_is_set(&DBusErr))
		{
			iOutRet = ERR_SETUP_FAIL;
			dbus_error_free(&DBusErr);
			break;
		}
		dbus_bus_add_match(m_pDBusConn, "type='signal',interface='" DbusIf_SysSrv_CfgMgr "'", &DBusErr);
		if(dbus_error_is_set(&DBusErr))
		{
			iOutRet = ERR_SETUP_FAIL;
			dbus_error_free(&DBusErr);
			break;
		}
		dbus_connection_flush(m_pDBusConn);
	}while(FALSE);

	return iOutRet;
}

INT_t CMediaPlayerApp::unsetDBusService()
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	DBusError DBusErr;

	do
	{
		if(NULL == m_pDBusConn)
		{
			break;
		}

		dbus_error_init(&DBusErr);
		dbus_bus_remove_match(m_pDBusConn, "type='signal',interface='" DbusIf_SysSrv_CfgMgr "'", &DBusErr);
		if(dbus_error_is_set(&DBusErr))
		{
			iOutRet = ERR_REMOVE_REG_INFO_FAIL;
			dbus_error_free(&DBusErr);
			break;
		}
		dbus_bus_remove_match(m_pDBusConn, "type='signal',interface='" DBUS_SysSrv_SysEvt_If "'", &DBusErr);
		if(dbus_error_is_set(&DBusErr))
		{
			iOutRet = ERR_REMOVE_REG_INFO_FAIL;
			dbus_error_free(&DBusErr);
			break;
		}
		dbus_bus_remove_match(m_pDBusConn, "type='signal',interface='" DBUS_SystemService_NetMgrSrv_If "'", &DBusErr);
		if(dbus_error_is_set(&DBusErr))
		{
			iOutRet = ERR_REMOVE_REG_INFO_FAIL;
			dbus_error_free(&DBusErr);
			break;
		}
		dbus_bus_remove_match(m_pDBusConn, "type='signal',interface='" DBUS_MPLAYER_OBJECT_INTERFACE "'", &DBusErr);
		if(dbus_error_is_set(&DBusErr))
		{
			iOutRet = ERR_REMOVE_REG_INFO_FAIL;
			dbus_error_free(&DBusErr);
			break;
		}
		dbus_bus_remove_match(m_pDBusConn, "type='signal',interface='" DBUS_IF_freedesktop_DBus "'", &DBusErr);
		if(dbus_error_is_set(&DBusErr))
		{
			iOutRet = ERR_REMOVE_REG_INFO_FAIL;
			dbus_error_free(&DBusErr);
			break;
		}
		iRet = dbus_bus_release_name(m_pDBusConn, DBUS_MPLAYER_SERVICE_NAME, &DBusErr);
		if(-1 == iRet)
		{
			iOutRet = ERR_REMOVE_REG_INFO_FAIL;
			dbus_error_free(&DBusErr);
			break;
		}
	}while(FALSE);

	return iOutRet;
}

INT_t CMediaPlayerApp::setVolume(int VolumePercent)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;

	do
	{
		int CurVolPercent = 30;
		iRet = m_oMediaSrv_sp->ChangeVolume(0, &CurVolPercent);
		if(ERROR_SUCCESS != iRet)
		{
			PRINT_BFILE_LINENO_IRET_STR;
			iOutRet = iRet;
			break;
		}
		//VolumePercent = 0;	//zero for debug
		int VolChange = VolumePercent - CurVolPercent;
		iRet = m_oMediaSrv_sp->ChangeVolume(VolChange, &CurVolPercent);
		if(ERROR_SUCCESS != iRet)
		{
			PRINT_BFILE_LINENO_IRET_STR;
			iOutRet = iRet;
			break;
		}
		m_VolumePercent = CurVolPercent;
	}while(FALSE);

	return iOutRet;
}

INT_t CMediaPlayerApp::SaveDisplayParam(DISP_PARAM_TYPE eDispParamType, INT_t iValue)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	bool bRet;
	LPCSTR pszPropName = "";
	bool bCreateNodeIfNotExist = TRUE;

	do
	{
		pszPropName = getPropNameDescFromDispParamType(eDispParamType);
		if(NULL == pszPropName || 0 == strcmp(pszPropName, ""))
		{
			iOutRet = ERROR_INVALID_PARAMETER;
			break;
		}

		iRet = m_SettingXmlDoc_sp->setElementPropertyValue(XML_DispParam_Ele_PATH, pszPropName, iValue, bCreateNodeIfNotExist);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}
		bRet = m_SettingXmlDoc_sp->SaveFile(MP_SETTING_XML_DOC_PATH);
		if(false == bRet)
		{
			LOG_BLINE("Save %s err\n", pszPropName);
		}
		sync();
	}while(FALSE);

	return iOutRet;
}

INT_t CMediaPlayerApp::SaveVoMode(VIDEO_OUTPUT_MODE eNewVoMode)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	bool bRet;
	bool bCreateNodeIfNotExist = TRUE;

	do
	{
		iRet = m_SettingXmlDoc_sp->setElementPropertyValue(XML_DispParam_Ele_PATH, PropDesc_VoMode, eNewVoMode, bCreateNodeIfNotExist);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}
		bRet = m_SettingXmlDoc_sp->SaveFile(MP_SETTING_XML_DOC_PATH);
		if(false == bRet)
		{
			LOG_BLINE("Save %s err\n", PropDesc_VoMode);
		}
		//to disk
		sync();
	}while(FALSE);

	return iOutRet;
}

LPCSTR CMediaPlayerApp::getPropNameDescFromDispParamType(DISP_PARAM_TYPE eDispParamType)
{
	LPCSTR pszPropNameDesc = "";

	if(DispPARAM_Brightness == eDispParamType)
	{
		pszPropNameDesc = PropDesc_Brightness;
	}
	else if(DispPARAM_Contrast == eDispParamType)
	{
		pszPropNameDesc = PropDesc_Contrast;
	}
	else if(DispPARAM_Saturation == eDispParamType)
	{
		pszPropNameDesc = PropDesc_Saturation;
	}
	else if(DispPARAM_Hue == eDispParamType)
	{
		pszPropNameDesc = PropDesc_Hue;
	}

	return pszPropNameDesc;
}

INT_t CMediaPlayerApp::applyDisplayParamsFromCfg(BOOL_t bContinueIfErr/* = TRUE*/)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	CString strValue;
	INT_t iValue = 50;

	if(Sw_LogVideoOutputInfo)
	{
		LOG_BLINE("applyDisplayParamsFromCfg\n");
	}

	do
	{
		//Brightness
		iRet = m_SettingXmlDoc_sp->getElementPropertyValue(XML_DispParam_Ele_PATH, PropDesc_Brightness, OUT strValue, "50");
		if(ERROR_SUCCESS == iRet)
		{
			iValue = atoi((LPCSTR)strValue);
			GENERALIZE_PERCENT(iValue);
			if(DispParam_LowLimit_Percent > iValue)
			{
				iValue = DispParam_LowLimit_Percent;
			}
			iRet = m_oMediaSrv_sp->setDisplayParam(DispPARAM_Brightness, iValue);
			if(ERROR_SUCCESS != iRet)
			{
				if(bContinueIfErr)
				{
					PRINT_BFILE_LINENO_IRET_STR;
				}
				else
				{
					iOutRet = iRet;
					break;
				}
			}
		}
		else
		{
			if(bContinueIfErr)
			{
				PRINT_BFILE_LINENO_IRET_STR;
			}
			else
			{
				iOutRet = iRet;
				break;
			}
		}
		//Contrast
		iRet = m_SettingXmlDoc_sp->getElementPropertyValue(XML_DispParam_Ele_PATH, PropDesc_Contrast, OUT strValue, "50");
		if(ERROR_SUCCESS == iRet)
		{
			iValue = atoi((LPCSTR)strValue);
			GENERALIZE_PERCENT(iValue);
			if(DispParam_LowLimit_Percent > iValue)
			{
				iValue = DispParam_LowLimit_Percent;
			}
			iRet = m_oMediaSrv_sp->setDisplayParam(DispPARAM_Contrast, iValue);
			if(ERROR_SUCCESS != iRet)
			{
				if(bContinueIfErr)
				{
					PRINT_BFILE_LINENO_IRET_STR;
				}
				else
				{
					iOutRet = iRet;
					break;
				}
			}
		}
		else
		{
			if(bContinueIfErr)
			{
				PRINT_BFILE_LINENO_IRET_STR;
			}
			else
			{
				iOutRet = iRet;
				break;
			}
		}
		//Saturation
		iRet = m_SettingXmlDoc_sp->getElementPropertyValue(XML_DispParam_Ele_PATH, PropDesc_Saturation, OUT strValue, "50");
		if(ERROR_SUCCESS == iRet)
		{
			iValue = atoi((LPCSTR)strValue);
			GENERALIZE_PERCENT(iValue);
			if(DispParam_LowLimit_Percent > iValue)
			{
				iValue = DispParam_LowLimit_Percent;
			}
			iRet = m_oMediaSrv_sp->setDisplayParam(DispPARAM_Saturation, iValue);
			if(ERROR_SUCCESS != iRet)
			{
				if(bContinueIfErr)
				{
					PRINT_BFILE_LINENO_IRET_STR;
				}
				else
				{
					iOutRet = iRet;
					break;
				}
			}
		}
		else
		{
			if(bContinueIfErr)
			{
				PRINT_BFILE_LINENO_IRET_STR;
			}
			else
			{
				iOutRet = iRet;
				break;
			}
		}
		//Hue
		iRet = m_SettingXmlDoc_sp->getElementPropertyValue(XML_DispParam_Ele_PATH, PropDesc_Hue, OUT strValue, "50");
		if(ERROR_SUCCESS == iRet)
		{
			iValue = atoi((LPCSTR)strValue);
			GENERALIZE_PERCENT(iValue);
			if(DispParam_LowLimit_Percent > iValue)
			{
				iValue = DispParam_LowLimit_Percent;
			}
			iRet = m_oMediaSrv_sp->setDisplayParam(DispPARAM_Hue, iValue);
			if(ERROR_SUCCESS != iRet)
			{
				if(bContinueIfErr)
				{
					PRINT_BFILE_LINENO_IRET_STR;
				}
				else
				{
					iOutRet = iRet;
					break;
				}
			}
		}
		else
		{
			if(bContinueIfErr)
			{
				PRINT_BFILE_LINENO_IRET_STR;
			}
			else
			{
				iOutRet = iRet;
				break;
			}
		}
	}while(FALSE);

	return iOutRet;
}

int CMediaPlayerApp::CalcMaxFd()
{
	int iMaxFd = 0;
	FD_EventIf_MAP::iterator itFdEventIf;

	do
	{
		for(itFdEventIf = m_FdEventIfMap.begin(); itFdEventIf != m_FdEventIfMap.end(); itFdEventIf++)
		{
			if(itFdEventIf->first > iMaxFd)
			{
				iMaxFd = itFdEventIf->first;
			}
		}
	}while(FALSE);

	return iMaxFd;
}

INT_t CMediaPlayerApp::SyncCacheToFile()
{
	INT_t iOutRet = ERROR_SUCCESS;

	do
	{

	}while(FALSE);

	return iOutRet;
}

INT_t CMediaPlayerApp::SerialPortParamDesc_To_ParamValue(LPCSTR pszSerialPortParamDesc,
	P_SERIAL_PORT_PARAM pSerialPortParamVal)
{
	INT_t iOutRet = ERROR_SUCCESS;
	DECLARE_CLS_STACK_BUF_STRING(strSerialParameters, 64);
	CString::STD_STRING_LIST lstSerialParamField;
	CString::STD_STRING_LIST::iterator itStrField;

	do
	{
		strSerialParameters = pszSerialPortParamDesc;
		//LOG_BLINE("SerialParam: %s\n", (LPCSTR)strSerialParameters);
		lstSerialParamField = strSerialParameters.Split(',');
		if(4 > lstSerialParamField.size())
		{
			iOutRet = ERROR_INVALID_PARAMETER;
			break;
		}
		itStrField = lstSerialParamField.begin();
		pSerialPortParamVal->iBaudrate = (*itStrField).toInt();
		itStrField++;
		pSerialPortParamVal->eSerialParity = getSerialParityFromDesc((*itStrField));
		itStrField++;
		pSerialPortParamVal->iDataBits = (*itStrField).toInt();
		itStrField++;
		pSerialPortParamVal->iStopBits = (*itStrField).toInt();
	}while(FALSE);

	return iOutRet;
}

INT_t CMediaPlayerApp::SerialPortParmVal_To_Desc(P_SERIAL_PORT_PARAM pSerialPortParamVal,
	OUT CStackBufString & strSerialPortParamDesc)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;

	do
	{
		iRet = strSerialPortParamDesc.Format("%d,%s,%d,%d", pSerialPortParamVal->iBaudrate,
			getSerialParityDescFromVal(pSerialPortParamVal->eSerialParity),
			 pSerialPortParamVal->iDataBits, pSerialPortParamVal->iStopBits);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}
	}while(FALSE);

	return iOutRet;
}

CSerialComPort::SERIAL_PARITY CMediaPlayerApp::getSerialParityFromDesc(LPCSTR pszParityDesc)
{
	CSerialComPort::SERIAL_PARITY eSerialParity = CSerialComPort::PARITY_NO;

	if(NULL == pszParityDesc)
	{
	}
	else if(0 == strcmp("N", pszParityDesc))
	{
		eSerialParity = CSerialComPort::PARITY_NO;
	}
	else if(0 == strcmp("E", pszParityDesc))
	{
		eSerialParity = CSerialComPort::PARITY_EVEN;
	}
	else if(0 == strcmp("O", pszParityDesc))
	{
		eSerialParity = CSerialComPort::PARITY_ODD;
	}

	return eSerialParity;
}

LPCSTR CMediaPlayerApp::getSerialParityDescFromVal(CSerialComPort::SERIAL_PARITY eSerialParity)
{
	LPCSTR pszSerialParityDesc = "N";

	if(CSerialComPort::PARITY_EVEN == eSerialParity)
	{
		pszSerialParityDesc = "E";
	}
	else if(CSerialComPort::PARITY_ODD == eSerialParity)
	{
		pszSerialParityDesc = "O";
	}

	return pszSerialParityDesc;
}

VOID CMediaPlayerApp::SerialPortParamVal_Init(P_SERIAL_PORT_PARAM pSerialPortParamVal)
{
	pSerialPortParamVal->iBaudrate = 9600;
	pSerialPortParamVal->eSerialParity = CSerialComPort::PARITY_NO;
	pSerialPortParamVal->iDataBits = 8;
	pSerialPortParamVal->iStopBits = 1;
}

/*
ThreadContext: main thread
*/
VOID CMediaPlayerApp::OnChk_DelayedSet_VcrDefaultSurface()
{
	BOOL_t bNeedUnregTimer = TRUE;
	INT_t iRet;

	m_oMediaSrv_sp->DelayedSet_VcrDefaultSurface(OUT bNeedUnregTimer);
	//LOG_BLINE("bNeedUnregTimer=%d\n", bNeedUnregTimer);
	if(bNeedUnregTimer)
	{
		bNeedUnregTimer = FALSE;
		if(0 < m_DelayedSet_VcrDefaultSurface_TimerId)
		{
			iRet = m_GenericTimer.UnregisterTimer(m_DelayedSet_VcrDefaultSurface_TimerId);
			if(ERROR_SUCCESS == iRet)
			{
				m_DelayedSet_VcrDefaultSurface_TimerId = 0;
			}
			else
			{
				PRINT_BFILE_LINENO_IRET_STR;
			}
		}
	}
}

#if 1/*added by lxj 2012-11-22*/
INT_t CMediaPlayerApp::OnDBusCall_setVideoSyncMode(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
	SharedPtr <CDBusParameterList> & DBusOutParamList_sp)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	INT32_t iReplyRet = ERROR_SUCCESS;
	Mp7xxCommon::VIDEO_SYNC_MODE_t eVideoSyncMode;

	do
	{
		if(1 > DBusInParamList_sp->getSize()){
			iReplyRet = ERROR_INVALID_PARAMETER;
			LOG_BLINE("ERROR: eVideoSyncMode parameter\n");
			break;
		}
		eVideoSyncMode = (typeof(eVideoSyncMode))(((*DBusInParamList_sp)[0])->toInt32());
		switch( eVideoSyncMode ){
			case Mp7xxCommon::VidSyncMode_DISABLED:
			case Mp7xxCommon::VidSyncMode_MASTER:
			case Mp7xxCommon::VidSyncMode_SLAVE:
				break;
			default:
				iReplyRet = ERROR_INVALID_PARAMETER;
				LOG_BLINE("ERROR: eVideoSyncMode is bad values\n");
				goto ret;
		}

		if( m_VideoSync_sp.isNull() ){
			iRet = ERROR_INVALID_STATE;
		}else{
			iRet = m_VideoSync_sp->StopVideoSync();/*Stoped first*/
			if( ERROR_SUCCESS == iRet ){
				iRet = m_VideoSync_sp->setVideoSyncMode(eVideoSyncMode);
				if( ERROR_SUCCESS == iRet ){
					iRet = m_VideoSync_sp->StartVideoSync();
				}
			}
		}

		iReplyRet = iRet;

		if(ERR_SUCCESS == iReplyRet)
		{
			if(Mp7xxCommon::VidSyncMode_MASTER == m_VideoSync_sp->getVideoSyncMode() ||
				Mp7xxCommon::VidSyncMode_SLAVE == m_VideoSync_sp->getVideoSyncMode())
			{
				iRet =  m_oMediaSrv_sp->setPlayPrebufMax(PLAY_PrebufMax_VideoSync);
			}
			else	//normal
			{
				iRet =  m_oMediaSrv_sp->setPlayPrebufMax(PLAY_PrebufMax_NORMAL);
			}
			if(ERR_SUCCESS != iRet)
			{
				PRINT_BFILE_LINENO_IRET_STR;
			}
		}
	}while(FALSE);

ret:
	(*DBusOutParamList_sp) << iReplyRet;

	return iOutRet;
}

INT_t CMediaPlayerApp::OnDBusCall_getVideoSyncMode(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
	SharedPtr <CDBusParameterList> & DBusOutParamList_sp)
{
	INT_t iRet;
	INT32_t iReplyRet = ERROR_SUCCESS;

	(*DBusOutParamList_sp) << iReplyRet;
	if( m_VideoSync_sp.isNull() ){
		(*DBusOutParamList_sp) << "";
	}else{
		(*DBusOutParamList_sp) << m_VideoSync_sp->getVideoSyncMode();
	}

	return iRet;
}

INT_t CMediaPlayerApp::OnDBusCall_setVideoSyncMaster(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
	SharedPtr <CDBusParameterList> & DBusOutParamList_sp)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	INT32_t iReplyRet = ERROR_SUCCESS;
	CString strVideoSyncMaster;

	do
	{
		if(1 > DBusInParamList_sp->getSize()){
			iReplyRet = ERROR_INVALID_PARAMETER;
			LOG_BLINE("ERROR: strVideoSyncMaster parameter\n");
			break;
		}
#if 1
		strVideoSyncMaster = (typeof(strVideoSyncMaster))(((*DBusInParamList_sp)[0])->toString());
#else/*added by lxj 2012-11-23,this is test for transmit array data on dbus*/
		SharedPtr<CByteArray2> ByteArray_sp;
		ByteArray_sp = (typeof(ByteArray_sp))(((*DBusInParamList_sp)[0])->toByteArray());
		LOG_BLINE("data=%s,len=%d\n",ByteArray_sp->GetData(),ByteArray_sp->GetSize());
#endif
		if( m_VideoSync_sp.isNull() ){
			iRet = ERROR_INVALID_STATE;
		}else{
			iRet = m_VideoSync_sp->setVideoSyncMaster(strVideoSyncMaster);/*Only Idle state can be set*/
		}
		iReplyRet = iOutRet = iRet;
	}while(FALSE);

	(*DBusOutParamList_sp) << iReplyRet;

	return iOutRet;
}

INT_t CMediaPlayerApp::OnDBusCall_getVideoSyncMaster(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
	SharedPtr <CDBusParameterList> & DBusOutParamList_sp)
{
	INT_t iRet;
	INT32_t iReplyRet = ERROR_SUCCESS;

#if 1
	(*DBusOutParamList_sp) << iReplyRet;
	if( m_VideoSync_sp.isNull() ){
		(*DBusOutParamList_sp) << "";
	}else{
		(*DBusOutParamList_sp) << m_VideoSync_sp->getVideoSyncMaster();
	}
#else/*added by lxj 2012-11-23,this is test for transmit array data on dbus*/
	SharedPtr<CDBusParameter_ByteArray> ByteArray_sp (new CDBusParameter_ByteArray);
	BYTE data[16]="ByteArray";
	if(ByteArray_sp->toByteArray().isNull()){
		LOG_BLINE("toByteArray is empty!\n");
	}
	ByteArray_sp->toByteArray()->Append(data,16);

	(*DBusOutParamList_sp) << iReplyRet;
	(*DBusOutParamList_sp) << ByteArray_sp;;
#endif

	return iRet;
}
#endif

INT_t CMediaPlayerApp::OnDBusCall_setHdmiCecCtrl(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
	SharedPtr <CDBusParameterList> & DBusOutParamList_sp)
{
	INT_t iOutRet = ERROR_SUCCESS;
	INT32_t iReplyRet = ERROR_SUCCESS;

	do
	{
		if(1 > DBusInParamList_sp->getSize()){
			iReplyRet = ERROR_INVALID_PARAMETER;
			break;
		}
		CONST HDMI_CEC_CTRL_CMD eHdmiCecCtrlCmd = (typeof(eHdmiCecCtrlCmd))
			((*DBusInParamList_sp)[0])->toInt32();
		iReplyRet = m_oMediaSrv_sp->setHdmiCecCtrl(eHdmiCecCtrlCmd);
	}while(false);

	(*DBusOutParamList_sp) << iReplyRet;

	return iOutRet;
}

INT_t CMediaPlayerApp::OnDBusCall_setShowClosedCaption(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
	SharedPtr <CDBusParameterList> & DBusOutParamList_sp)
{
	INT_t iOutRet = ERROR_SUCCESS;
	INT32_t iReplyRet = ERROR_SUCCESS;
	INT32_t iParamSelection;

	if(1 > DBusInParamList_sp->getSize()){
		iReplyRet = ERROR_INVALID_PARAMETER;
		goto EXIT_PROC;
	}

	iParamSelection = ((*DBusInParamList_sp)[0])->toInt32();
	iReplyRet = m_oMediaSrv_sp->setShowClosedCaption((ClosedCaption_SELECTION)iParamSelection);

EXIT_PROC:	

	(*DBusOutParamList_sp) << iReplyRet;

	return iOutRet;
}

INT_t CMediaPlayerApp::OnDBusCall_getShowClosedCaption(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
	SharedPtr <CDBusParameterList> & DBusOutParamList_sp)
{
	INT_t iOutRet = ERROR_SUCCESS;
	INT32_t iReplyRet = ERROR_SUCCESS;
	ClosedCaption_SELECTION oParamSelection = CC_SEL_Disabled;
	do
	{
		if(m_oMediaSrv_sp.isNull())
		{
			iOutRet = ERROR_INVALID_PARAMETER;
			break;
		}

		iReplyRet = m_oMediaSrv_sp->getShowClosedCaption(OUT oParamSelection);
		if(ERROR_SUCCESS != iReplyRet)
		{
			iOutRet = iReplyRet;
			break;
		}
	}while(FALSE);

EXIT_PROC:	

	(*DBusOutParamList_sp) << iOutRet;
	(*DBusOutParamList_sp) << oParamSelection;

	return iOutRet;
}

#if 1 /*Add by xuweiwei 2014-2-18*/
INT_t CMediaPlayerApp::OnDBusCall_setVideoRotation(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
	SharedPtr <CDBusParameterList> & DBusOutParamList_sp)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	INT32_t iReplyRet = ERROR_SUCCESS;
	INT32_t iVideoRotationMode = -1;

	do{
		if(1 > DBusInParamList_sp->getSize() ||m_oMediaSrv_sp.isNull())
		{
			iOutRet = ERROR_INVALID_PARAMETER;
			break;  
		}
		
		iVideoRotationMode = (INT32_t)(((*DBusInParamList_sp)[0])->toInt32());
              if(iVideoRotationMode <0 || iVideoRotationMode >3)
              {
                    iOutRet = ERROR_INVALID_PARAMETER;
		      break;
              }
              iRet = m_oMediaSrv_sp->setVideoRotation((const INT32_t)iVideoRotationMode);
		if(ERROR_SUCCESS != iRet)
		{
			iReplyRet = iRet;
			break;
		}
	}while(FALSE);

	(*DBusOutParamList_sp) << iReplyRet;

	return iOutRet;
}

INT_t CMediaPlayerApp::OnDBusCall_getVideoRotation(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
	SharedPtr <CDBusParameterList> & DBusOutParamList_sp)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	INT32_t iReplyRet = ERROR_SUCCESS;
	INT32_t iVideoRotationMode = -1;

	do{
		if(m_oMediaSrv_sp.isNull())
		{
			iOutRet = ERROR_INVALID_PARAMETER;
			break;
		}
		
		iRet = m_oMediaSrv_sp->getVideoRotation(&iVideoRotationMode);
		if(ERROR_SUCCESS != iRet)
		{
			iReplyRet = iRet;
			break;
		}
		
	}while(FALSE);

	(*DBusOutParamList_sp) << iReplyRet;
	(*DBusOutParamList_sp) << iVideoRotationMode;

	return iOutRet;
}

#endif

INT_t CMediaPlayerApp::OnDBusCall_enableAudio6Ch(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
	SharedPtr <CDBusParameterList> & DBusOutParamList_sp)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	INT32_t iReplyRet = ERROR_SUCCESS;
	INT32_t iEnAudio6ChFlag = -1;

	do
	{
		if(1 > DBusInParamList_sp->getSize() || m_oMediaSrv_sp.isNull())
		{
			iReplyRet = ERROR_INVALID_PARAMETER;
			goto EXIT_PROC;
		}       

		iEnAudio6ChFlag = (INT32_t)(((*DBusInParamList_sp)[0])->toInt32());
		if(0 != iEnAudio6ChFlag && 1 != iEnAudio6ChFlag)
		{
			iReplyRet = ERROR_INVALID_PARAMETER;
			goto EXIT_PROC;
		}
		iRet = m_oMediaSrv_sp->setEnableAudio6Ch((BOOL_t)iEnAudio6ChFlag);
		if(ERROR_SUCCESS != iRet)
		{
			iReplyRet = iRet;
			break;
		}
	}while(FALSE);


EXIT_PROC:  

	(*DBusOutParamList_sp) << iReplyRet;

	return iOutRet;
}

INT_t CMediaPlayerApp::OnDBusCall_getEnableAudio6Ch(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
	SharedPtr <CDBusParameterList> & DBusOutParamList_sp)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	INT32_t iReplyRet = ERROR_SUCCESS;
	BOOL_t oEnAudio6Chflg = -1;

	do{
		if(m_oMediaSrv_sp.isNull())
		{
			iOutRet = ERROR_INVALID_PARAMETER;
			break;
		}
		
		iRet = m_oMediaSrv_sp->getEnableAudio6Ch(oEnAudio6Chflg);
		if(ERROR_SUCCESS != iRet)
		{
			iReplyRet = iRet;
			break;
		}

              if(0!=oEnAudio6Chflg && 1!=oEnAudio6Chflg)
              {
                    iOutRet = ERROR_INVALID_PARAMETER;
                    break;
              }              
		
	}while(FALSE);

	(*DBusOutParamList_sp) << iReplyRet;
	(*DBusOutParamList_sp) << oEnAudio6Chflg;

	return iOutRet;
}


