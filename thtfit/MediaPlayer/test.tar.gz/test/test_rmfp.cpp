/*****************************************
 Copyright 2001-2010
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   test_rmfp.c
  @brief


  @author Sebastian Frias Feltrer, Christian Wolff
  @date   2007-09-13
*/
/****************************************************************************/
/*  DISCLAIMER:                                                             */
/*                                                                          */
/*  This is a basic example for the 'rmfp' and 'rmoutput' libraries         */
/*                                                                          */
/*  Please do not use this in production environments !!!                   */
/*                                                                          */
/*  This code is given as an example on how to use the 'display' setup      */
/*  method of the 'rmoutput' library, and how to play back a file with      */
/*  'rmfp'. It also provides some interaction between the output and        */
/*  playback, such as selection of letterbox vs. pan-scan modes, and        */
/*  CEC functionality                                                       */
/*                                                                          */
/****************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <dlfcn.h>
#include <unistd.h>
#include <math.h>
#include <assert.h>

#define ALLOW_OS_CODE 1

// rmoutput includes (RUA implementation)
#include <rmoutput/rua/include/output_rua.h>
#include <rmoutput/debugger/include/rmoutput_debugger.h>

// rmfp includes
#include "rmfp.h"
#include <rmfontrender/include/rmfontrender.h>
#include <rmlibhttp/include/rmlibhttp.h>
#include <rmlibcurl/include/rmlibcurl.h>
#include <rmdtcpapi/include/rmdtcpapi.h>
#include <rmriff/include/rmriff.h>
#include <rmlibudp/include/udpStreamFile.h>

/*
 * Internal application functions
 */
#include "test_rmfp.h"
#include "get_key.h"
#include "rmmmimplementation.h"
#include "parse_command_line.h"
#include "callbacks.h"
#include "resources.h"
#include "surface.h"

#ifdef WITH_THREADS
 #include <rmlibcw/include/rmthreads.h>
#else
 // you must have COMPILKIND=withthreads, that will automatically #define WITH_THREADS
 #error "Mediaplayer requires threads support"
#endif

#include <UrlInfo.h>
#include <StackBufString.h>
#include <DateTime.h>
#include "MediaSrvInterface.h"
#include <samples/rminputstream.h>
#include <DbgLogSwitchDef.h>
#include <RmSyncAccess/include/RmSyncAccess.h>
#include <rmdetector3/src/lib/rmsystem-common.h>

#define CLOSE_FILE(myfile_handle)\
	if (myfile_handle) {\
		RMCloseFile(myfile_handle);\
		myfile_handle = NULL;\
	}

#define SEEK_FILE_TO_ZERO(myfile_handle)\
	if (myfile_handle)\
		RMSeekFile(myfile_handle, 0, RM_FILE_SEEK_START);

// defined inside dbgimplementation.c, used here to control RMDBG* output
extern int verbose_stdout;
extern int verbose_stderr;

#ifdef WITH_THREADS
#include <rmlibcw/include/rmthreads.h>
#else

#error "test_rmfp requires threads support"

/*
  you must have COMPILKIND=withthreads, that will automatically #define WITH_THREADS
*/

#endif

// HDMI thread handling
extern RMbool run_hdmi;
extern RMthread hdmi_thread;
extern RMsemaphore hdmi_semaphore;

#define LOCALDBG DISABLE
#define DETECTIONDBG ENABLE

#define MAX_SUBS_TO_SCAN 1000

static RMstatus detect_and_setup_stream(struct rmfp_main_thread_context_type *pMainContext,
					RMfile fileHandle,
					const RMascii *fileName,
					struct RMFPOptions *pOptions,
					struct RMFPStreamType *pStreamType);


static RMstatus run_threading_test(struct rmfp_main_thread_context_type *pMainContext, RMfile fileHandle, struct RMFPStreamType *pStreamType,struct RMFPOptions *pOptions);
void *rmfp_key_management_thread(void *pContext);


static RMascii *get_next_filename(struct rmfp_main_thread_context_type *pMainContext);
static RMstatus close_font_rendering(struct rmfp_main_thread_context_type *pMainContext);
static void init_rmfp_file_specific_context(struct rmfp_main_thread_context_type *pMainContext);
static RMstatus find_all_external_subtitles(struct rmfp_main_thread_context_type *pMainContext, struct RMFPPlayOptions *playback_options, RMascii* FileName);

static RMfile open_dtcp_url(struct rmfp_main_thread_context_type *pMainContext, const RMascii *pURL, struct RMDTCPAPIConnectionParameters *pDTCPConnectionParameters);
static RMfile open_url(struct rmfp_main_thread_context_type *pMainContext, const RMascii *fileName);


/**************************************************************************************************/
RMstatus player_rmfp_openurl(struct rmfp_main_thread_context_type *pMainContext, const RMascii *fileName)
{
	RMstatus status = RM_OK;

	//LOG_BLINE("Time: %lld ms\n", GetSysUpTimeMs());

	// Open the URL of the file to be played
	// In multicast and SPI mode, this is not needed there is no file to play

	if (!pMainContext->pOptions->demux_options.spi &&
		!pMainContext->pOptions->demux_options.multicast.count)
	{
		if (pMainContext->AppOptions.Playback.is_directory) 
		{
			fileName = get_next_filename(pMainContext);

			if (fileName == NULL)
			{
				fprintf(ERRORMSG, "No more file to read\n");
				status = RM_ERROR;
				goto exit;
			}

			pMainContext->fileHandle = open_url(pMainContext, fileName);
			if (!pMainContext->fileHandle)
			{
				if(Sw_LogMediaFileInfo)
				{
					fprintf(ERRORMSG, "Open url '%s' error\n", fileName);
				}
				status = RM_ERROR;
				goto exit;
			}

			pMainContext->stream_type.application_type = RMFP_application_type_UNKNOWN;
			pMainContext->EOS = FALSE;

		}
		else 
		{
			/* Catch rtsp filenames */
			if (RMNCompareAscii(fileName, "rtsp://", 7))
			{
				pMainContext->fileHandle = NULL;
				pMainContext->stream_type.application_type = RMFP_application_type_ASF;
				pMainContext->pOptions->playback_options.rtsp_url = fileName;
			}
			else if(RMNCompareAscii(fileName, "http://", 7))
			{
				pMainContext->fileHandle = open_stream(fileName, RM_FILE_OPEN_READ, NULL);
				if(CC_UNLIKELY(NULL == pMainContext->fileHandle))
				{
					status = RM_ERROR;
					goto exit;
				}
			}
			else if(RMNCompareAscii(fileName,"udp://",6)
				|| RMNCompareAscii(fileName,"rtp://",6))
			{
				pMainContext->fileHandle = CreateUdpStreamFile();
				if(NULL == pMainContext->fileHandle)
				{
					status = RM_ERROR;
					goto exit;
				}

				pMainContext->stream_type.application_type = RMFP_application_type_PSFDEMUX;
				pMainContext->pOptions->demux_options.system_type = RM_SYSTEM_MPEG2_TRANSPORT;

				//set url
				RM_IOCTRL_SET_URL_IN RmIoCtrlSetUrlIn;
				RM_IOCTRL_SET_URL_OUT RmIoCtrlSetUrlOut;
				RmIoCtrlSetUrlIn.pszUrl =(char*) fileName;
				status = RmFileIoCtrl(pMainContext->fileHandle, CTRL_CODE_SET_URL, (RMuint8 *)(&RmIoCtrlSetUrlIn), 
					sizeof(RmIoCtrlSetUrlIn), (RMuint8 *)(&RmIoCtrlSetUrlOut), sizeof(RmIoCtrlSetUrlOut));
				if(CC_UNLIKELY(RMFAILED(status)))
				{
					PRINT_BFILE_LINENO_RM_STATUS;
					goto exit;
				}
				if(CC_UNLIKELY(ERROR_SUCCESS != RmIoCtrlSetUrlOut.iRet))
				{
					goto exit;
				}
			}
#if 1/*added by lxj 2012-8-22 for usb video in*/
			else if (RMNCompareAscii(fileName, "capture://usb", 13))
			{
				//LOG_BLINE("player_rmfp_openur(),%s\n",fileName);
				pMainContext->fileHandle = NULL;
				pMainContext->stream_type.application_type = RMFP_application_type_CAPTURE;
				pMainContext->pOptions->playback_options.url = fileName;
			}
#endif
			else
			{
				pMainContext->fileHandle = open_url(pMainContext, fileName);
				if (!pMainContext->fileHandle)
				{
					if(Sw_LogMediaFileInfo)
					{
						fprintf(ERRORMSG, "Open url '%s' error\n", fileName);
					}
					status = RM_ERROR;
					goto exit;
				}
				pMainContext->pOptions->playback_options.url = fileName;
			}
		}
	}

	// For index creation
	if (pMainContext->pOptions->demux_options.index2create_file_handle) 
	{
		pMainContext->pOptions->demux_options.second_file_handle = open_url(pMainContext, fileName);
		if (!pMainContext->pOptions->demux_options.second_file_handle) 
		{
			if(Sw_LogMediaFileInfo)
			{
				fprintf(ERRORMSG, "Open url '%s' error\n", fileName);
			}
			status = RM_ERROR;
			goto exit;
		}
	}

	// ���û��ָ��, ���ý������
	// If the stream type has not been passed in the command line, try to autodetect the parameters
	// All parameters are not detected and the command line parameters are still used here
	//fprintf(ERRORMSG, "application_type '%d'\n", pMainContext->stream_type.application_type);

	if (pMainContext->stream_type.application_type == RMFP_application_type_UNKNOWN) 
	{
		//LOG_BLINE("Time: %lld ms\n", GetSysUpTimeMs());
		pMainContext->AppOptions.Display.osd_scaler_ID = EMHWLIB_MODULE(DispGFXMultiScaler, 0);
		status = detect_and_setup_stream(pMainContext, pMainContext->fileHandle, 
			fileName, pMainContext->pOptions, 
			&(pMainContext->stream_type));
		//LOG_BLINE("Time: %lld ms\n", GetSysUpTimeMs());
		if (status != RM_OK)
		{
			fprintf(ERRORMSG, "Detection failed (%s)\n", RMstatusToString(status));
			goto exit;
		}

		if (pMainContext->AppOptions.Playback.detect_only) 
		{
			status = RM_OK;
			goto exit;
		}
	}

exit:
	return status;
}

RMstatus player_rmfp_closeurl(struct rmfp_main_thread_context_type *pMainContext)
{
	RMstatus status = RM_OK;

	// Close the main file handle
	if (CC_LIKELY(pMainContext->fileHandle)) {
		RMDBGLOG((LOCALDBG, "Closing FileHandle %p\n", pMainContext->fileHandle));
		status = RMFPCloseURL(pMainContext->pHandle, pMainContext->fileHandle);
		if (status != RM_OK) {
			fprintf(ERRORMSG, "Unable to close file (%s)\n", RMstatusToString(status));
		}
		pMainContext->fileHandle = NULL;
	}

	return status;
}

RMstatus player_rmfp_run(struct rmfp_main_thread_context_type *pMainContext)
{
	RMstatus status = RM_ERROR;

    status = RMFPMain(pMainContext->pHandle, pMainContext->fileHandle,
						  &pMainContext->stream_type, pMainContext->pOptions);
	if (status != RM_OK) {
		fprintf(ERRORMSG, "RMFPMain() returned with error (%s)\n", RMstatusToString(status));
	}
	
	return status;
}

RMstatus player_rmfp_exit(struct rmfp_main_thread_context_type *pMainContext)
{
	RMstatus status = RM_ERROR;

	// Close DTCP Session if there's one opened
	if (pMainContext->pDTCPHandle) {
		RMDBGLOG((ENABLE, "Closing DTCP-IP session\n"));
		status = RMDTCPAPICloseSession(pMainContext->pDTCPHandle);
		if(RMFAILED(status))
		{			
			PRINT_BFILE_LINENO_RM_STATUS;
		}
	}

#if 0
	/******************************************************************
	 * Here we must close some resouces used by the application callbask:
	 * - the close caption software render
	 * - the text subtitles displayer
	 * - ...
	 **********************************************/
	if (Options.video_options.CloseCaptionMode == RMFPCloseCaptionMode_ShowInOSD) {
		RMDBGLOG((LOCALDBG, "close software close caption decoder\n"));

		status = close_close_caption_software_renderer(pMainContext);
		if (status != RM_OK)
			fprintf(ERRORMSG, "Cannot close software close caption decoder (%s)\n", RMstatusToString(status));
	}
#endif

#if 0
	// �ر���Ļ����
	/* Close all subtiles */
	for (cnt=0; cnt<Options.playback_options.text_subs.count; cnt++)
		CLOSE_FILE(Options.playback_options.text_subs.entry[cnt].file_handle);
	Options.playback_options.text_subs.count = 0;
	CLOSE_FILE(Options.playback_options.subidx_sub_file_handle);
	CLOSE_FILE(Options.playback_options.subidx_idx_file_handle);
#endif
	
#if 0
	/*
	 * Close ALL possibly opened handles:
	 * - opened by this function
	 * - opened in the parse_command_line function
	*/
	CLOSE_FILE(Options.playback_options.save_video_file_handle);
	CLOSE_FILE(Options.playback_options.save_audio_file_handle);
	CLOSE_FILE(Options.playback_options.save_spu_file_handle);
	CLOSE_FILE(Options.demux_options.index_file_handle);
	CLOSE_FILE(Options.demux_options.multicast_dump_file_handle);
	CLOSE_FILE(Options.demux_options.tsdump_file_handle);
	CLOSE_FILE(Options.demux_options.tsdump_index_file_handle);
	CLOSE_FILE(Options.demux_options.save_pat_file_handle);
	CLOSE_FILE(Options.demux_options.save_pmt_file_handle);
	CLOSE_FILE(Options.demux_options.save_custom_pid_file_handle);
	CLOSE_FILE(Options.demux_options.index2create_file_handle);
	CLOSE_FILE(Options.demux_options.second_file_handle);
	CLOSE_FILE(pMainContext->AppOptions.Playback.fonts.default_font_file_handle);
	CLOSE_FILE(pMainContext->AppOptions.Playback.fonts.cc_font_file_handle);
	CLOSE_FILE(pMainContext->AppOptions.Playback.fonts.forced_font_file_handle);
	for (cnt=0; cnt<pMainContext->AppOptions.Playback.fonts.nb_additional_fonts; cnt++)
		CLOSE_FILE(pMainContext->AppOptions.Playback.fonts.additional_font_file_handle[cnt]);
#endif

	// Close the RMFP handle
	if (pMainContext->pHandle) {
		status = RMFPCloseHandle(pMainContext->pHandle);
		if (status != RM_OK)
			fprintf(ERRORMSG, "close handle error (%s)\n", RMstatusToString(status));
		pMainContext->pHandle = NULL;
	}

	// Close the font rendering management
	status = close_font_rendering(pMainContext);
	if (status != RM_OK)
		fprintf(ERRORMSG, "Cannot close font rendering (%s)\n", RMstatusToString(status));

	// Release debugger ressources
	if (pMainContext->pDebug) {
		rmoutput_debug_exit(&(pMainContext->pDebug));
	}

	// Close display
	if(pMainContext->pRUA)
	{
		if (! (pMainContext->AppOptions.Playback.no_disp)) {
			status = rmoutput_display_close(pMainContext->pHWLib, pMainContext->dh_info,
											pMainContext->display_opt, pMainContext->display_conf);
			if (RMFAILED(status)) {
				fprintf(stderr, "Can not close display! %s\n", RMstatusToString(status));
			}
		}
	}

	// Close DCC and RUA
	if (pMainContext->pDCC) {
		status = DCCClose(pMainContext->pDCC);
		if (status != RM_OK)
			fprintf(ERRORMSG, "Cannot close DCC (%s)\n", RMstatusToString(status));
		pMainContext->pDCC = NULL;
	}
	if (pMainContext->pRUA) {
		status = RUADestroyInstance(pMainContext->pRUA);
		if (status != RM_OK)
		{
			fprintf(ERRORMSG, "Cannot destroy RUA instance (%s)\n", RMstatusToString(status));
		}
		pMainContext->pRUA = NULL;
	}

    RMCheckMemory();
	
	return status;
}

RMbool IsM2TFile(RMascii* extension)
{
	// test a few extensions	
	if(RMCompareAsciiCaseInsensitively (extension, "mpg"))
	{
		return TRUE;
	}
	else if(RMCompareAsciiCaseInsensitively (extension, "mpeg"))
	{
		return TRUE;
	}
	else if(RMCompareAsciiCaseInsensitively (extension, "m2t")){
		return TRUE;
	}
	else if(RMCompareAsciiCaseInsensitively (extension, "m2v"))
	{
		return TRUE;
	}
	else if(RMCompareAsciiCaseInsensitively (extension, "ts"))
	{
		return TRUE;
	}
	else if(RMCompareAsciiCaseInsensitively (extension, "tp"))
	{
		return TRUE;
	}
	else if(RMCompareAsciiCaseInsensitively (extension, "m2ts"))
	{
		return TRUE;
	}

	return FALSE;
}

/**************************************************************************************************/
static RMstatus detect_and_setup_stream(struct rmfp_main_thread_context_type *pMainContext,
	RMfile fileHandle,
	const RMascii *fileName,
	struct RMFPOptions *pOptions,
	struct RMFPStreamType *pStreamType)
{
	RMstatus status = RM_OK, eRMstatus = RM_OK;
	INT_t iRet;
	struct RMFPStreamInfo *pStreamInfo = NULL;
	RMbool Verbose = TRUE;
	RMuint32 uiDataDetectLength = (64 * 1024);
	RMuint32 uiStepLenToAdd = (64 * 1024);
	RMuint32 uiLimitedDetectLen = (1536 * 1024);	//1.5M
	CUrlInfo FileUrlInfo(fileName);
	DECLARE_CLS_STACK_BUF_STRING(strFileExtensionName, 32);
	UINT64_t CurUpTimeMs;
	SharedPtr <IMediaFileInfoCache> MediaFileInfoCacheIf_sp = getMediaFileInfoCacheSrvSp();

#if 0/*added by lxj 2013-1-15*/
	DBG_TIME("%s() begin\n",__func__);
#endif

	ASSERT_NULL_POINTER(pMainContext);
	ASSERT_NULL_POINTER(fileHandle);
	ASSERT_NULL_POINTER(pOptions);
	ASSERT_NULL_POINTER(pStreamType);

	strFileExtensionName = FileUrlInfo.getExtensionName();
	//LOG_BLINE("ExtensionName:%s\n", (LPCSTR)strFileExtensionName);
	if(IsM2TFile((RMascii*)((LPCSTR)strFileExtensionName)))
	{
		uiDataDetectLength = (128*1024);
		uiStepLenToAdd = (128*1024);
	}

	//CurUpTimeMs = GetSysUpTimeMs();
	//LOG_BLINE("Time: %llu ms\n", CurUpTimeMs);

	do
	{
		if(MediaFileInfoCacheIf_sp.isValid())
		{
			IMediaFileInfoCache::FIND_STREAM_INFO_IN_PARAM oFindStreamInfoInParam;
			IMediaFileInfoCache::FIND_STREAM_INFO_OUT_PARAM oFindStreamInfoOutParam;
			oFindStreamInfoInParam.pszFileName = fileName;
			iRet = MediaFileInfoCacheIf_sp->FindStreamInfoInCache(&oFindStreamInfoInParam, &oFindStreamInfoOutParam);
			if(ERROR_SUCCESS == iRet)
			{
				if(oFindStreamInfoOutParam.pRmfpStreamInfo)
				{
					RMMemcpy(&(pMainContext->stream_type.application_type), &(oFindStreamInfoOutParam.RmfpStreamType),
						sizeof(pMainContext->stream_type.application_type));
					//oFindStreamInfoOutParam.pRmfpStreamInfo is allocated newly.
					pStreamInfo = oFindStreamInfoOutParam.pRmfpStreamInfo;	//transform
					oFindStreamInfoOutParam.pRmfpStreamInfo = NULL;
					break;	//found, no need to detect again.
				}
			}
			else if(ERROR_NOT_FOUND == iRet)
			{
			}
			else
			{
				PRINT_BFILE_LINENO_IRET_STR;
			}
		}

		BOOL_t bDetectedStreamInfo = FALSE;
			
		while(TRUE)
		{
			if (pStreamInfo)
			{
				status = RMFPReleaseStreamInfo(pMainContext->pHandle, pStreamInfo);
				if(RMFAILED(status))
				{
					eRMstatus = status;
					PRINT_BFILE_LINENO_RMSTATUS;
				}
				pStreamInfo = NULL;
			}

			RMbool bAvoidSeeking = FALSE;
			status = RMFPGetStreamInfo(pMainContext->pHandle, pMainContext->fileHandle,
				fileName, uiDataDetectLength, bAvoidSeeking, &(pMainContext->stream_type), &pStreamInfo); 
			if(RMSUCCEEDED(status) && (RMFP_application_type_UNKNOWN != pMainContext->stream_type.application_type))
			{
				if(RMFP_application_type_PICTURE == pMainContext->stream_type.application_type || 
					RMFP_application_type_AUDIO  == pMainContext->stream_type.application_type || 
					RMFP_application_type_OGG == pMainContext->stream_type.application_type)
				{
					bDetectedStreamInfo = TRUE;
				}
				else if(RMFP_application_type_MP4 == pMainContext->stream_type.application_type)
				{
					if(1 <= pStreamInfo->SystemStreamCount && (1 <= pStreamInfo->VideoStreamCount || 1 <= pStreamInfo->AudioStreamCount))
					{
						bDetectedStreamInfo = TRUE;
					}
				}
				else if(RMFP_application_type_RIFF == pMainContext->stream_type.application_type &&
					0 < pStreamInfo->SystemStreamCount && pStreamInfo->pSystem &&
					RMSystemDetector_RIFF_Type_WAVE == pStreamInfo->pSystem[0].DemuxMode)
				{
					bDetectedStreamInfo = TRUE;
				}
				else if(RMFP_application_type_PSFDEMUX == pMainContext->stream_type.application_type &&
					pStreamInfo->pSystem &&
					(RM_SYSTEM_MPEG2_TRANSPORT == pStreamInfo->pSystem[0].DemuxMode) &&
					(1 <= pStreamInfo->SystemStreamCount) &&
					((1 <= pStreamInfo->VideoStreamCount) || (1 <= pStreamInfo->AudioStreamCount)))
				{
					bDetectedStreamInfo = TRUE;
				}
#if 1/*added by lxj 2013-1-15*/
				else if(RMFP_application_type_ASF == pMainContext->stream_type.application_type ){
					if(1 <= pStreamInfo->SystemStreamCount && (1 <= pStreamInfo->VideoStreamCount || 1 <= pStreamInfo->AudioStreamCount)){
						bDetectedStreamInfo = TRUE;
					}
				}
#endif
				else
				{
					if((1 <= pStreamInfo->SystemStreamCount) && 
						((1 <= pStreamInfo->VideoStreamCount) && (1 <= pStreamInfo->AudioStreamCount)))
					{
						bDetectedStreamInfo = TRUE;
					}
				}
				//Break the detection progress if detected
				if(bDetectedStreamInfo)
				{
					if(Sw_LogMediaFileInfo)
					{
						LOG("DetectedLen:%lu\n", uiDataDetectLength);
					}
					break;
				}
			}
			else if(RMFAILED(status))	//error
			{
				RMstatus eRMstatus = status;
				PRINT_BFILE_LINENO_RMSTATUS;
				break;
			}
			
			uiDataDetectLength += uiStepLenToAdd;
			if(uiLimitedDetectLen <= uiDataDetectLength)
			{
				break;
			}
		}

		if(bDetectedStreamInfo)
		{
			if(MediaFileInfoCacheIf_sp.isValid())
			{
				//AddMediaInfoCache will clone one from pStreamInfo
				iRet = MediaFileInfoCacheIf_sp->AddMediaInfoCache(fileName, &(pMainContext->stream_type), pStreamInfo);
				if(ERROR_SUCCESS != iRet)
				{
					PRINT_BFILE_LINENO_IRET_STR;
				}
			}
		}
	}while(FALSE);

	if(RMFAILED(status))
	{
		goto exit;
	}

	//CurUpTimeMs = GetSysUpTimeMs();
	//LOG_BLINE("Time: %llu ms\n", CurUpTimeMs);

	/*
	fprintf(NORMALMSG, "Attempting stream detection...\n\n");
	status = RMFPGetStreamInfo(pMainContext->pHandle,
							   fileHandle,
							   fileName,
							   pMainContext->AppOptions.Playback.detect_limit,
							   FALSE,
							   pStreamType,
							   &pStreamInfo);
	*/

	/*
	Use soft demux
	This code is here because the software demux and the hardware demux require different
	checks
	*/
	if ((pMainContext->AppOptions.Playback.UseSoftwareDemux) && (pStreamType->application_type == RMFP_application_type_PSFDEMUX))
		pStreamType->application_type = RMFP_application_type_SOFTDEMUX;

#if (EM86XX_CHIP < EM86XX_CHIPID_TANGO3)
	// JPEG progressive are only supported from tango3 and up
	if (pStreamType->application_type == RMFP_application_type_PICTURE) {
		if (pStreamInfo->DataStreamCount
			&& pStreamInfo->pData) {
				if ((pStreamInfo->pData->Parameters.picture.format == RMFPPictureFormat_JPEG)
					&& (pStreamInfo->pData[0].Parameters.picture.Profile == RMFPPictureProfile_Progressive)) {
						status = RM_NOT_SUPPORTED;
						RMNOTIFY((NULL, status, "Progressive JPEG not supported with this chip\n"));
				}
		}
	}
#endif

	if ((status != RM_OK) || (pStreamType->application_type == RMFP_application_type_UNKNOWN)) {
		RMDBGLOG((ENABLE, "stream detection failed, can't play (%s)\n", RMstatusToString(status)));
		goto exit;
	}

	//LOG("Detection successful\n");

	if (pMainContext->AppOptions.Playback.detect_only)
		Verbose = FALSE;

	RMDBGLOG((DETECTIONDBG, "SystemStreams %lu\n", pStreamInfo->SystemStreamCount));
	RMDBGLOG((DETECTIONDBG, "VideoStreams %lu\n", pStreamInfo->VideoStreamCount));
	RMDBGLOG((DETECTIONDBG, "AudioStreams %lu\n", pStreamInfo->AudioStreamCount));


#define RMFP_STREAMINFO_AUDIO_PROFILE_VERSION  1
#define RMFP_STREAMINFO_VIDEO_PROFILE_VERSION  1
#define RMFP_STREAMINFO_SYSTEM_PROFILE_VERSION 1

	if (pStreamInfo->SystemStreamCount && pStreamInfo->pSystem) {

		RMDBGLOG((DETECTIONDBG, "SystemInfo version 0x%lx\n", pStreamInfo->pSystem[0].Version));

		if (pStreamInfo->pSystem[0].Version != RMFP_STREAMINFO_SYSTEM_PROFILE_VERSION) {
			RMNOTIFY((NULL, RM_ERROR, "Got SystemInfo version 0x%lx, expecting 0x%lx\n",
				pStreamInfo->pSystem[0].Version,
				RMFP_STREAMINFO_SYSTEM_PROFILE_VERSION));
			return RM_ERROR;
		}

		if (pStreamInfo->pSystem[0].TSSkip)
			RMDBGLOG((DETECTIONDBG, "TSSkip = %lu\n", pStreamInfo->pSystem[0].TSSkip));

		RMDBGLOG((DETECTIONDBG, "DemuxMode 0x%lx\n", pStreamInfo->pSystem[0].DemuxMode));

	}

	if (!Verbose) {

		fprintf(stderr, "System:");

		switch(pStreamType->application_type) 
		{
		case RMFP_application_type_ASF:
			fprintf(stderr, " ASF");
			break;
		case RMFP_application_type_AVI:
			fprintf(stderr, " AVI");
			break;
		case RMFP_application_type_MP4:
			fprintf(stderr, " MP4");
			break;
		case RMFP_application_type_PSFDEMUX:
		case RMFP_application_type_SOFTDEMUX:
			if (pStreamInfo->SystemStreamCount && pStreamInfo->pSystem) {
				switch (pStreamInfo->pSystem[0].DemuxMode) 
				{
				case RM_SYSTEM_MPEG1:
					fprintf(stderr, " M1S");
					break;
				case RM_SYSTEM_MPEG2_PROGRAM:
					fprintf(stderr, " M2P");
					break;
				case RM_SYSTEM_MPEG2_TRANSPORT:
					fprintf(stderr, " M2T");
					break;
				case RM_SYSTEM_MPEG2_DVD:
					fprintf(stderr, " DVD");
					break;
				};

				if (pStreamInfo->pSystem[0].TSSkip)
					fprintf(stderr, ", TSSkip=%lu", pStreamInfo->pSystem[0].TSSkip);
			}
			else
				fprintf(stderr, " UNKNOWN DEMUX");
			break;
		case RMFP_application_type_VIDEO:
			fprintf(stderr, " Elementary Video");
			break;
		case RMFP_application_type_AUDIO:
			fprintf(stderr, " Elementary Audio");
			break;
		case RMFP_application_type_PICTURE:
			fprintf(stderr, " Picture");
			break;
		case RMFP_application_type_MKV:
			fprintf(stderr, " MKV");
			break;
		case RMFP_application_type_OGG:
			fprintf(stderr, " OGG");
			break;
		case RMFP_application_type_HLS:
			fprintf(stderr, " HLS");
			break;
		default:
			fprintf(stderr, " UNKNOWN");
			break;
		};

		fprintf(stderr, "\n");

	}

	if (pStreamInfo->VideoStreamCount && pStreamInfo->pVideo) {
		RMuint32 i;

		for (i = 0; i < pStreamInfo->VideoStreamCount; i++) {
			RMDBGLOG((DETECTIONDBG, "Video stream %lu: StreamID %lu ParentStreamID %lu (info version 0x%lx)\n",
				i,
				pStreamInfo->pVideo[i].StreamID,
				pStreamInfo->pVideo[i].ParentStreamID,
				pStreamInfo->pVideo[i].Version));

			if (pStreamInfo->pVideo[i].Version != RMFP_STREAMINFO_VIDEO_PROFILE_VERSION) {
				RMNOTIFY((NULL, RM_ERROR, "Got VideoInfo version 0x%lx, expecting 0x%lx\n",
					pStreamInfo->pVideo[i].Version,
					RMFP_STREAMINFO_VIDEO_PROFILE_VERSION));
				return RM_ERROR;
			}

			if (pStreamInfo->pVideo[i].PID) {
				RMDBGPRINT((DETECTIONDBG, "\t(pid=%lu [0x%lx] subid=%lu [0x%lx] pidType=%lu [0x%lx])\n",
					pStreamInfo->pVideo[i].PID,
					pStreamInfo->pVideo[i].PID,
					pStreamInfo->pVideo[i].SubID,
					pStreamInfo->pVideo[i].SubID,
					pStreamInfo->pVideo[i].PIDType,
					pStreamInfo->pVideo[i].PIDType));
			}

			RMDBGPRINT((DETECTIONDBG, "\tCodec     0x%lx\n", (RMuint32)pStreamInfo->pVideo[i].Codec));
			RMDBGPRINT((DETECTIONDBG, "\tProfile   %lu\n", pStreamInfo->pVideo[i].Profile));
			RMDBGPRINT((DETECTIONDBG, "\tLevel     %lu\n", pStreamInfo->pVideo[i].Level));
			RMDBGPRINT((DETECTIONDBG, "\tMaxWidth  %lu\n", pStreamInfo->pVideo[i].MaxWidth));
			RMDBGPRINT((DETECTIONDBG, "\tMaxHeight %lu\n", pStreamInfo->pVideo[i].MaxHeight));

			RMDBGPRINT((DETECTIONDBG, "\tSkipNCP   %lu\n", pStreamInfo->pVideo[i].skipNCP));


			if (!Verbose) {

				fprintf(stderr, "Video: StreamID %lu",
					pStreamInfo->pVideo[i].StreamID);

				fprintf(stderr, ", Codec:");
				switch (pStreamInfo->pVideo[i].Codec) 
				{
				case EMhwlibVideoCodec_MPEG2:
					fprintf(stderr, " MPEG2");
					break;
				case EMhwlibVideoCodec_MPEG4:
					fprintf(stderr, " MPEG4");
					if (pStreamInfo->pVideo[i].skipNCP)
						fprintf(stderr, ", SkipNCP");
					break;
				case EMhwlibVideoCodec_MPEG4_Padding:
					fprintf(stderr, " MPEG4_Padding");
					if (pStreamInfo->pVideo[i].skipNCP)
						fprintf(stderr, ", SkipNCP");
					break;
				case EMhwlibVideoCodec_DIVX3:
					fprintf(stderr, " DIVX3");
					break;
				case EMhwlibVideoCodec_VC1:
					fprintf(stderr, " VC1");
					break;
				case EMhwlibVideoCodec_WMV:
					fprintf(stderr, " WMV");
					break;
				case EMhwlibVideoCodec_H264:
					fprintf(stderr, " H264");
					break;
				case EMhwlibVideoCodec_AVS:
					fprintf(stderr, " AVS");
					break;
				case EMhwlibJPEGCodec:
					fprintf(stderr, " JPEG");
					break;
				case EMhwlibDVDSpuCodec:
					fprintf(stderr, " DVDSpu");
					break;
				case EMhwlibBDRLECodec:
					fprintf(stderr, " BDRLE");
					break;
				default:
					fprintf(stderr, " UNKNOWN!");
					break;
				};

				if (pStreamInfo->pVideo[i].PID) {
					fprintf(stderr, ", PID=0x%lx SubID=0x%lx",
						pStreamInfo->pVideo[i].PID,
						pStreamInfo->pVideo[i].SubID);

				}

				fprintf(stderr, "\n");
			}
		}
	}

	if (pStreamInfo->AudioStreamCount && pStreamInfo->pAudio) {
		RMuint32 i;

		for (i = 0; i < pStreamInfo->AudioStreamCount; i++) {
			RMDBGLOG((DETECTIONDBG, "Audio stream %lu: StreamID %lu ParentStreamID %lu (info version 0x%lx)\n",
				i,
				pStreamInfo->pAudio[i].StreamID,
				pStreamInfo->pAudio[i].ParentStreamID,
				pStreamInfo->pAudio[i].Version));

			if (pStreamInfo->pAudio[i].Version != RMFP_STREAMINFO_AUDIO_PROFILE_VERSION) {
				RMNOTIFY((NULL, RM_ERROR, "Got AudioInfo version 0x%lx, expecting 0x%lx\n",
					pStreamInfo->pAudio[i].Version,
					RMFP_STREAMINFO_AUDIO_PROFILE_VERSION));
				return RM_ERROR;
			}

			if (pStreamInfo->pAudio[i].PID) {
				RMDBGPRINT((DETECTIONDBG, "\t(pid=%lu [0x%lx] subid=%lu [0x%lx] pidType=%lu [0x%lx])\n",
					pStreamInfo->pAudio[i].PID,
					pStreamInfo->pAudio[i].PID,
					pStreamInfo->pAudio[i].SubID,
					pStreamInfo->pAudio[i].SubID,
					pStreamInfo->pAudio[i].PIDType,
					pStreamInfo->pAudio[i].PIDType));
			}

			RMDBGPRINT((DETECTIONDBG, "\tCodec         0x%lx\n", (RMuint32)pStreamInfo->pAudio[i].Codec));
			RMDBGPRINT((DETECTIONDBG, "\tSubCodec      0x%lx\n", pStreamInfo->pAudio[i].SubCodec));
			RMDBGPRINT((DETECTIONDBG, "\tSampleRate    %lu\n", pStreamInfo->pAudio[i].SampleRate));
			RMDBGPRINT((DETECTIONDBG, "\tChannels      %lu\n", pStreamInfo->pAudio[i].Channels));
			RMDBGPRINT((DETECTIONDBG, "\tBitsPerSample %lu\n", pStreamInfo->pAudio[i].BitsPerSample));
			RMDBGPRINT((DETECTIONDBG, "\tBitrate       %lu\n", pStreamInfo->pAudio[i].Bitrate));
			RMDBGPRINT((DETECTIONDBG, "\tVBR           %lu\n", pStreamInfo->pAudio[i].isVBR));

			if (!Verbose) {

				fprintf(stderr, "Audio: StreamID %lu",
					pStreamInfo->pAudio[i].StreamID);

				fprintf(stderr, ", Codec:");
				switch (pStreamInfo->pAudio[i].Codec) 
				{
				case AudioDecoder_Codec_AC3:
					fprintf(stderr, " AC3/EAC3");
					break;
				case AudioDecoder_Codec_AAC:
					switch (pStreamInfo->pAudio[i].SubCodec) 
					{
					case 0:
						fprintf(stderr, " ADIF");
						break;
					case 1:
						fprintf(stderr, " ADTS");
						break;
					case 3:
						fprintf(stderr, " AAC LATM");
						break;
					default:
						fprintf(stderr, " UNKNOWN AAC");
						break;
					}
					break;
				case AudioDecoder_Codec_DTS:
					fprintf(stderr, " DTS");
					break;
				case AudioDecoder_Codec_MPEG1:
					fprintf(stderr, " MPEG");
					break;
				case AudioDecoder_Codec_PCM:
					fprintf(stderr, " PCM (%lu)", pStreamInfo->pAudio[i].SubCodec);
					break;
				case AudioDecoder_Codec_WMA:
					if (pStreamInfo->pAudio[i].SubCodec == 0x7a23)
						fprintf(stderr, " WMATS");
					else
						fprintf(stderr, " WMA");
					break;
				case AudioDecoder_Codec_WMAPRO:
					fprintf(stderr, " WMAPRO");
					break;
				case AudioDecoder_Codec_DVDA:
					fprintf(stderr, " MLP/TrueHD");
					break;
				case AudioDecoder_Codec_FLAC:
					fprintf(stderr, " FLAC");
					break;
				case AudioDecoder_Codec_VORBIS:
					fprintf(stderr, " Vorbis");
					break;
				default:
					fprintf(stderr, " UNKNOWN!");
					break;
				};

				if (pStreamInfo->pAudio[i].PID) {
					fprintf(stderr, ", PID=0x%lx SubID=0x%lx",
						pStreamInfo->pAudio[i].PID,
						pStreamInfo->pAudio[i].SubID);

				}

				fprintf(stderr, "\n");

				fprintf(stderr, "\tSampleRate    %lu\n", pStreamInfo->pAudio[i].SampleRate);
				fprintf(stderr, "\tChannels      %lu\n", pStreamInfo->pAudio[i].Channels);
				fprintf(stderr, "\tBitsPerSample %lu\n", pStreamInfo->pAudio[i].BitsPerSample);
				fprintf(stderr, "\tBitrate       %lu\n", pStreamInfo->pAudio[i].Bitrate);
				fprintf(stderr, "\tVBR           %lu\n", (RMuint32)pStreamInfo->pAudio[i].isVBR);
			}
		}

	}

	if (!Verbose)
		fprintf(stderr, "\n");

	/*
	Apply detected parameters to cmdline:

	This is necessary only for:
	- elementary video
	- elementary audio
	- M2P, DVD, M1S files when using the PSFDemux

	Therefore we check the application type before applying the parameters

	*/

	status = RMFPApplyStreamInfoToOptions(pMainContext->pHandle, fileHandle, pStreamType, pStreamInfo, pOptions);
	if (status != RM_OK) {
		RMNOTIFY((NULL, status, "Cannot apply stream info to options\n"));
		goto exit;
	}


	if (pStreamType->application_type == RMFP_application_type_PICTURE) {
		// enable wait exit
		RMDBGLOG((ENABLE, "set WaitExit to TRUE\n"));
		pOptions->playback_options.WaitExit = TRUE;

		/* check if its image => force loop disable */
		if (pMainContext->AppOptions.Playback.loop) {
			RMNOTIFY((NULL, RM_ERROR, " Loop is not allowed when playing a picture file, disable it \n"));
			pMainContext->AppOptions.Playback.loop = FALSE;
		}

	}

	/*
	use software JPEG decoding ?
	This code is here because the codec for JPEG is forced when applying the options
	*/
	if ((!pMainContext->AppOptions.Playback.UseSoftwareJPEGDecoder) &&
		(pStreamType->application_type == RMFP_application_type_PICTURE) &&
		(pOptions->playback_options.PictureFormat == RMFPPictureFormat_JPEG)) {

			const RMascii *pCause = "";
			RMbool UseSoftwareDecoder = FALSE;
			RMuint32 Width  = pOptions->video_options.vcodec_max_width;
			RMuint32 Height = pOptions->video_options.vcodec_max_height;

			// check if profile is supported by hardware
			switch (pOptions->video_options.vcodec_profile) 
			{
			case EMhwlibJPEGProfile_2222:
#if (EM86XX_CHIP < EM86XX_CHIPID_TANGO3)
				// not supported
				UseSoftwareDecoder = TRUE;
				pCause = "profile 444 not supported";
				break;
#elif	(EM86XX_CHIP == EM86XX_CHIPID_TANGO3)	//correct for JPEG YUV 4:4:4
				UseSoftwareDecoder = TRUE;
				pCause = "YUV 4:4:4 not supported by hw";
				pMainContext->AppOptions.Display.osd_scaler_ID = pMainContext->pOptions->video_options.VideoScalerID;
				break;
#endif

			case EMhwlibJPEGProfile_2211:
			case EMhwlibJPEGProfile_2212:
			case EMhwlibJPEGProfile_2111:
			case EMhwlibJPEGProfile_2221:
			case EMhwlibJPEGProfile_1211:
				UseSoftwareDecoder = FALSE;
				break;

#if (EM86XX_CHIP >= EM86XX_CHIPID_TANGO3)
			case EMhwlibJPEGProfile_2222p:
			case EMhwlibJPEGProfile_2211p:
			case EMhwlibJPEGProfile_2212p:
			case EMhwlibJPEGProfile_2111p:
			case EMhwlibJPEGProfile_2221p:
			case EMhwlibJPEGProfile_1211p:
				UseSoftwareDecoder = FALSE;
				break;
#endif
			};

			if (!Width || (Width > 8064)) {
				UseSoftwareDecoder = TRUE;
				pCause = "Wrong size";
			}

			if (!Height || (Height > 4032)) {
				UseSoftwareDecoder = TRUE;
				pCause = "Wrong size";
			}

			if (UseSoftwareDecoder) {
#if	(EM86XX_CHIP == EM86XX_CHIPID_TANGO3)
#else
				RMDBGLOG((ENABLE, "StreamType is JPEG (%lu x %lu) but '%s', use software decoding\n", Width, Height, pCause));
				fprintf(ERRORMSG,  "StreamType is JPEG (%lu x %lu) but '%s', use software decoding\n", Width, Height, pCause);
#endif
			}
			else {
				pStreamType->application_type = RMFP_application_type_VIDEO;
			}
	}

exit:

	if(pStreamInfo)
	{
		status = RMFPReleaseStreamInfo(pMainContext->pHandle, pStreamInfo);
		if(RMFAILED(status))
		{
			eRMstatus = status;
			PRINT_BFILE_LINENO_RMSTATUS;
		}
		pStreamInfo = NULL;
	}

#if 0/*added by lxj 2013-1-15*/
	DBG_TIME("%s() end\n",__func__);
#endif

	return status;
}

/**************************************************************************************************/


void *rmfp_key_management_thread(void *context)
{
	struct rmfp_main_thread_context_type *ThreadContext = (struct rmfp_main_thread_context_type *)context;
	struct RMFPPlaybackCommand command;
	RMstatus status;

	while (!ThreadContext->exit_key_management_thread) {

		ENTER_CS(ThreadContext->GetKeyCS);

		status = get_command(context, &command, 0);

		LEAVE_CS(ThreadContext->GetKeyCS);

		if (status == RM_PENDING) {
			// sleep for a while
			RMMicroSecondSleep(20000);
		}
		else if (status == RM_OK) {
			struct RMFPCommandStatus command_status;
			RMuint64 ref_time_us;

			RMMemset(&command_status, 0x00, sizeof(command_status));

			/* Execute command */
			status = RMFPSendCommand(ThreadContext->pHandle, &command);
			if (status != RM_OK)
				RMNOTIFY((NULL, status, "Error executing command\n"));

			ref_time_us = RMGetTimeInMicroSeconds();

			/* Wait for answer */
			status = RMFPWaitForCommandCompletion(ThreadContext->pHandle, &command_status, 10000);
			switch (status) {
			case RM_OK:
				notify_command_status(ThreadContext, &command_status);
				RMDBGLOG((ENABLE, "Got command completion after %lld ms\n", (RMGetTimeInMicroSeconds() - ref_time_us)/(RMuint64)1000));
				break;
			case RM_TIMEOUT:
				RMNOTIFY((NULL, status, "Timeout waiting for command completion\n"));
				break;
			default:
				RMNOTIFY((NULL, status, "RMFPWaitForCommandCompletion\n"));
				break;
			}
		}
		else {
			RMNOTIFY((NULL, status, "Cannot get command\n"));
			break;
		}
	}

	return NULL;
}

/**************************************************************************************************/

static RMstatus run_threading_test(struct rmfp_main_thread_context_type *pMainContext, RMfile fileHandle, struct RMFPStreamType *pStreamType, struct RMFPOptions *pOptions)
{
	RMthread threadID;
	RMstatus err;

	fprintf(NORMALMSG, "About to launch RMFP in a thread\n");

	fprintf(NORMALMSG, "Launching Key management thread\n");
	pMainContext->exit_key_management_thread = FALSE;
	threadID = RMCreateThread("Key management", rmfp_key_management_thread, (void*)pMainContext);
	fprintf(NORMALMSG, "Launch finished\n");

	/* Launch the main application */
	err = RMFPMain(pMainContext->pHandle, fileHandle, pStreamType, pOptions);

	// wait for thread to finish
	fprintf(NORMALMSG, "\n\nWaiting for Key management to finish\n");;
	pMainContext->exit_key_management_thread = TRUE;
	RMWaitForThreadToFinish(threadID);

	return err;
}


/*************************************************************************************************/

static RMascii *get_next_filename(struct rmfp_main_thread_context_type *pMainContext)
{
	RMdirectoryEntry entry;

	while( RMReadDirectory(pMainContext->directory[pMainContext->dir_index], &entry) == RM_OK ){
		RMnonAscii *dir_path;
		if(entry.name[0] == '.') /* skip . .. and hidden files */
			continue;
		pMainContext->path[pMainContext->path_index[pMainContext->dir_index]] = '\0';
		RMAppendAscii (pMainContext->path, (RMascii*)entry.name);

		dir_path = RMnonAsciiFromAscii(pMainContext->path);
		RMOpenDirectory(dir_path, &(pMainContext->directory[pMainContext->dir_index+1]));
		RMFreeNonAscii(dir_path);

		if(pMainContext->directory[pMainContext->dir_index+1] != NULL) {
			if((!pMainContext->AppOptions.Playback.recursive) || (pMainContext->dir_index+1 >= MAX_DIR_RECURSION)) {
				RMCloseDirectory(pMainContext->directory[pMainContext->dir_index+1]);
				continue;
			}
			pMainContext->dir_index++;
			RMAppendAscii (pMainContext->path, "/");
			pMainContext->path_index[pMainContext->dir_index] = RMasciiLength(pMainContext->path);
			RMDBGLOG((ENABLE, "==============%s is a directory\n", entry.name));
			return get_next_filename(pMainContext);
		}
		else {
			RMDBGLOG((ENABLE, "Opening %s\n", pMainContext->path));
			return pMainContext->path;
		}
	}
	RMCloseDirectory(pMainContext->directory[pMainContext->dir_index]);
	pMainContext->directory[pMainContext->dir_index] = NULL;
	if(pMainContext->dir_index) {
		pMainContext->dir_index--;
		return get_next_filename(pMainContext);
	}

	return NULL;
}

/*************************************************************************************************/

RMstatus init_font_rendering(struct rmfp_main_thread_context_type *pMainContext,
					RMascii* pAppName,  RMuint8** ppDefaultFontName, RMuint8** ppCCFontName, RMuint8** ppForcedFontName)
{
	RMstatus err;

	struct RMFontRenderProfile profile;
	RMint32 cnt;

	ASSERT_NULL_POINTER(pMainContext);
	ASSERT_NULL_POINTER(pAppName);
	ASSERT_NULL_POINTER(ppDefaultFontName);
	ASSERT_NULL_POINTER(ppCCFontName);
	ASSERT_NULL_POINTER(ppForcedFontName);

	/* Default values */
	*ppDefaultFontName = NULL;
	*ppCCFontName = NULL;
	*ppForcedFontName = NULL;

	/* Set profile default values */
	err = RMFontRenderInitProfile(&profile);
	if (err != RM_OK)
	{
		RMNOTIFY((NULL, err, "Unable to init font rendering profile\n"));
		return err;
	}


	/* Create a new font rendering handle */
	err = RMFontRenderOpen(&profile, &pMainContext->pFontRenderHandle);
	if (err != RM_OK)
	{
		RMNOTIFY((NULL, err, "Unable to open a new font rendering handle\n"));
		return err;
	}

	/*
	 * Now add the default and additional fonts
	 */

	pMainContext->forced_font_slotID = -1;
	pMainContext->cc_font_slotID = -1;
	pMainContext->default_font_slotID = -1;

	for (cnt = -2; cnt < (RMint32) pMainContext->AppOptions.Playback.fonts.nb_additional_fonts; cnt++)
	{

		RMfile pFontFileHandle;
		RMint32* pFontSlotID;
		RMuint8** ppFontName;

		/* Forced font, only one will be added to list */
		if (pMainContext->AppOptions.Playback.fonts.forced_font_file_handle)
		{
			pFontFileHandle = pMainContext->AppOptions.Playback.fonts.forced_font_file_handle;
			pFontSlotID = &pMainContext->forced_font_slotID;
			/* They all will be set in this case */
			ppFontName = NULL;
		}
		/* Default font first */
		else if (cnt == -2)
		{
			if (!pMainContext->AppOptions.Playback.fonts.default_font_file_handle)
				continue;

			pFontFileHandle = pMainContext->AppOptions.Playback.fonts.default_font_file_handle;
			pFontSlotID = &pMainContext->default_font_slotID;
			ppFontName = ppDefaultFontName;

		}
		/* CC font first */
		else if (cnt == -1)
		{
			if (!pMainContext->AppOptions.Playback.fonts.cc_font_file_handle)
				continue;

			pFontFileHandle = pMainContext->AppOptions.Playback.fonts.cc_font_file_handle;
			pFontSlotID = &pMainContext->cc_font_slotID;
			ppFontName = ppCCFontName;
		}
		else
		{
			pFontFileHandle = pMainContext->AppOptions.Playback.fonts.additional_font_file_handle[cnt];
			pFontSlotID = &pMainContext->additional_font_slotID[cnt];
			ppFontName = NULL;
		}

		/* Open font from memory */
		if (!pMainContext->AppOptions.Playback.open_font_from_file)
		{
			RMint64 font_buffer_size;
			RMuint8* pFontBuffer;
			RMuint32 read_size;
			/* Get size of file */
			err = RMSizeOfOpenFile(pFontFileHandle, &font_buffer_size);
			if (err != RM_OK)
			{
				RMNOTIFY((NULL, err, "Cannot find font size\n"));
				return err;
			}

			/* Allocate memory */
			pFontBuffer = (typeof(pFontBuffer))RMMalloc(font_buffer_size);
			if (!pFontBuffer)
			{
				RMNOTIFY((NULL, RM_FATALOUTOFMEMORY, "Unable to allocate %d bytes for default font\n", font_buffer_size));
				return RM_FATALOUTOFMEMORY;
			}

			/* Read font */
			err = RMReadFile(pFontFileHandle, pFontBuffer, font_buffer_size, &read_size);
			if (err != RM_OK)
			{
				RMNOTIFY((NULL, err, "ERR : RMReadFile error\n"));
				RMFree(pFontBuffer);
				return err;
			}

			/* Add font */
			err = RMFontRenderOpenFontSlot(pMainContext->pFontRenderHandle, pFontBuffer, read_size, pFontSlotID);
			if (err != RM_OK)
			{
				RMNOTIFY((NULL, err, "Unable to add font\n"));
				RMFree(pFontBuffer);
				return err;
			}

			/* Release temp buffer */
			RMFree(pFontBuffer);
		}
		/* Open font from file */
		else {

			RMFontRenderOpenFontSlotWithFile(pMainContext->pFontRenderHandle, pFontFileHandle, pFontSlotID);
		}

		/*
		 * Get fonts names if needed
		 */
		if (pMainContext->AppOptions.Playback.fonts.forced_font_file_handle || (cnt < 0))
		{
			RMuint32 nb_fonts;

			err = RMFontRenderGetSlotIDFontCount(pMainContext->pFontRenderHandle, *pFontSlotID, &nb_fonts);
			if (err != RM_OK)
			{
				fprintf(ERRORMSG, "Font init failed\n");
				return err;
			}

			if (nb_fonts > 0)
			{
				struct RMFontRenderFontInfo *pFontInfoTable;

				/*
				* Allocate the list of fonts info ;)
				*/
				pFontInfoTable = (struct RMFontRenderFontInfo *) RMMalloc(nb_fonts*sizeof(struct RMFontRenderFontInfo));
				if (!pFontInfoTable)
				{
					fprintf(ERRORMSG, "Font init failed\n");
					return RM_FATALOUTOFMEMORY;
				}

				err = RMFontRenderGetSlotIDFontInfo(pMainContext->pFontRenderHandle, *pFontSlotID, pFontInfoTable);
				if (err != RM_OK)
				{
					fprintf(ERRORMSG, "Font init failed\n");
					RMFree(pFontInfoTable);
					return err;
				}

				/*
				* Store first font name
				* TODO: allow to select the index ?
				*/

				if (pMainContext->AppOptions.Playback.fonts.forced_font_file_handle)
				{
					*ppDefaultFontName = pFontInfoTable[0].pFontName;
					*ppCCFontName = pFontInfoTable[0].pFontName;
					*ppForcedFontName = pFontInfoTable[0].pFontName;
				}
				else
					*ppFontName =  pFontInfoTable[0].pFontName;

				RMFree(pFontInfoTable);
			}
		}

		/* Add a new additional font if needed */
		if (cnt >= 0)
			pMainContext->nb_additional_fonts++;

		/* If the font if forced, the others will be ignored */
		if (pMainContext->AppOptions.Playback.fonts.forced_font_file_handle)
			break;
	}

	return RM_OK;
}

/*************************************************************************************************/

static RMstatus close_font_rendering(struct rmfp_main_thread_context_type *pMainContext)
{
	RMstatus err;
	RMuint32 cnt;

	/* Nothing to do */
	if (!pMainContext->pFontRenderHandle)
		return RM_OK;

	/* Release forced, cc, default and additional fonts */
	if (pMainContext->default_font_slotID != -1)
	{
		err = RMFontRenderCloseFontSlot(pMainContext->pFontRenderHandle, pMainContext->default_font_slotID);
		if (err != RM_OK)
			RMNOTIFY((NULL, err, "Unable to release forced font (index=%d)\n", pMainContext->default_font_slotID));
	}
	if (pMainContext->forced_font_slotID != -1)
	{
		err = RMFontRenderCloseFontSlot(pMainContext->pFontRenderHandle, pMainContext->forced_font_slotID);
		if (err != RM_OK)
			RMNOTIFY((NULL, err, "Unable to release forced font (index=%d)\n", pMainContext->forced_font_slotID));
	}
	if (pMainContext->cc_font_slotID != -1)
	{
		err = RMFontRenderCloseFontSlot(pMainContext->pFontRenderHandle, pMainContext->cc_font_slotID);
		if (err != RM_OK)
			RMNOTIFY((NULL, err, "Unable to release forced font (index=%d)\n", pMainContext->cc_font_slotID));
	}
	for (cnt = 0; cnt < pMainContext->nb_additional_fonts; cnt++)
	{
		err = RMFontRenderCloseFontSlot(pMainContext->pFontRenderHandle, pMainContext->additional_font_slotID[cnt]);
		if (err != RM_OK)
			RMNOTIFY((NULL, err, "Unable to release defaut font (index=%d)\n", pMainContext->additional_font_slotID[cnt]));
	}

	/* Now close the lib */
	err = RMFontRenderClose(pMainContext->pFontRenderHandle);
	if (err != RM_OK)
		RMNOTIFY((NULL, err, "Unable to close the font rendering handle\n"));

	return RM_OK;
}

/*************************************************************************************************/

static void init_rmfp_file_specific_context(struct rmfp_main_thread_context_type *pMainContext)
{
	/* No OSD by default */
	pMainContext->OSDAvailable = FALSE;

	/* Reset structures */
	RMMemset(&pMainContext->metadata, 0, sizeof(pMainContext->metadata));
	RMMemset(&pMainContext->defaults_metadata, 0, sizeof(pMainContext->defaults_metadata));
	RMMemset(&pMainContext->stream_properties, 0, sizeof(pMainContext->stream_properties));
	RMMemset(&pMainContext->current_pat, 0, sizeof(pMainContext->current_pat));
	RMMemset(&pMainContext->current_pmt, 0, sizeof(pMainContext->current_pmt));
	RMMemset(&pMainContext->OSDProfile, 0, sizeof(pMainContext->OSDProfile));
}

/*************************************************************************************************/

static RMbool external_subtitles_scan_filter_callback(RMdirectoryEntry *pEntry, void* pContext)
{
	RMascii* pPrefix = (RMascii*) pContext;

	return RMNCompareAscii((RMascii*) pEntry->name, pPrefix, RMasciiLength(pPrefix));

}

/*************************************************************************************************/

static RMstatus find_all_external_subtitles(struct rmfp_main_thread_context_type *pMainContext, struct RMFPPlayOptions *playback_options, RMascii* FileName)
{
	RMstatus status;
	RMuint32 file_index;
	RMuint32 cnt;
	RMint32 scnt;
	RMascii* pPrefix = NULL;
	RMascii* pCurrentDirectory = NULL;
	RMascii* pRealFileNameStart;
	RMdirectory current_directory;
	RMuint32 entries_count;
	RMdirectoryEntry* pEntryTable = NULL;
	struct RMFPProgress rmfp_progress = {0, };

	/* Fill notify structure common values */
	rmfp_progress.progress_type = (typeof(rmfp_progress.progress_type))TEST_RMFP_progress_type_scanning_subs;
	rmfp_progress.info_type = RMFP_progress_info_type_percentage;

	/* Notify subs scan start */
	rmfp_progress.progress.percentage = 0;
	notify_progress(pMainContext, &rmfp_progress, (RMbool *)NULL);

	/* Default status */
	status = RM_OK;

	/* Get real file name start (without dir) */
	for (scnt=RMasciiLength(FileName); scnt>=0; scnt--)
	{
		if (FileName[scnt] == '/')
			break;
	}
	pRealFileNameStart = FileName + scnt + 1;

	/* Get current directory */
	pCurrentDirectory = RMMallocAndDuplicateAscii(FileName);
	if (!pCurrentDirectory) {
		fprintf(NORMALMSG, "Bad file name [%s]\n", FileName);
		status = RM_ERROR;
		goto AUTO_SUBS_EXIT;
	}
	for (scnt=RMasciiLength(FileName)-1; scnt>=0; scnt--)
	{
		if (pCurrentDirectory[scnt] == '/') {
			pCurrentDirectory[scnt+1] = 0;
			break;
		}
	}

	/* Create a new string with the prefix of the file */
	pPrefix = RMMallocAndDuplicateAscii(FileName);
	if (!pPrefix) {
		fprintf(NORMALMSG, "Bad file name [%s]\n", FileName);
		status = RM_ERROR;
		goto AUTO_SUBS_EXIT;
	}
	/* Remove first extension */
	for (scnt=RMasciiLength(pPrefix)-1; scnt>=0; scnt--) {
		if (pPrefix[scnt] == '/')
			break;
		if (pPrefix[scnt] == '.') {
			pPrefix[scnt] = '\0';
			break;
		}
	}

	/* Open the current directory to find all matching names */
	status = RMOpenDirectory((RMnonAscii*) pCurrentDirectory, &current_directory);
	if (status != RM_OK) {
		fprintf(NORMALMSG, "Unable to open current directory, skipping subs detection...\n");

		/* This could be normal, if we open an http stream for instance */
		status = RM_OK;

		goto AUTO_SUBS_EXIT;
	}

	/* Get the number of entries in the directory matching the name */
	status = RMCountDirectoryEntries(current_directory, &entries_count, external_subtitles_scan_filter_callback, pPrefix - (FileName - pRealFileNameStart));
	if (status != RM_OK) {
		fprintf(NORMALMSG, "Unable to get current directory entries count...\n");

		status = RM_OK;
		goto AUTO_SUBS_EXIT;
	}

	/* Allocate the table with a max of MAX_SUBS_TO_SCAN entries */
	entries_count = RMmax(entries_count, MAX_SUBS_TO_SCAN);
	pEntryTable = (RMdirectoryEntry*) RMMalloc(entries_count*sizeof(RMdirectoryEntry));
	if (!pEntryTable) {
		fprintf(NORMALMSG, "Unable to allocate directory entries table...\n");

		/* Run anyway */
		status = RM_OK;
		goto AUTO_SUBS_EXIT;
	}

	/* Get the number of entries in the directory matching the name */
	status = RMScanDirectory(current_directory,  pEntryTable, entries_count, &entries_count, external_subtitles_scan_filter_callback, pPrefix - (FileName - pRealFileNameStart));
	if (status != RM_OK) {
		fprintf(NORMALMSG, "Unable to get current directory entries count...\n");

		/* Run anyway */
		status = RM_OK;
		goto AUTO_SUBS_EXIT;
	}

	RMDBGLOG((ENABLE, "%lu potential subtitles entries found in current directory\n", entries_count));

	/* Scan all files matching the name add interesting subs */
	for (file_index=0; file_index<entries_count; file_index++) {

		/* Notify subs scan (dont send again 0) */
		if (entries_count && ((100 * file_index) / entries_count)) {
			rmfp_progress.progress.percentage = (100 * file_index) / entries_count;
			notify_progress(pMainContext, &rmfp_progress, (RMbool *)NULL);
		}

		if (RMasciiLength((RMascii*) pEntryTable[file_index].name) < 4)
			continue;

		/* First detect SUB and IDX from SUB/IDX */
		for (cnt=0; cnt<2; cnt++) {
			RMfile* pFileHandle;
			const RMascii* pSuffix;

			/* Select the right parameters for sub or idx */
			if (cnt == 0) {
				pFileHandle = &playback_options->subidx_sub_file_handle;
				pSuffix = ".sub";
			}
			else {
				pFileHandle = &playback_options->subidx_idx_file_handle;
				pSuffix = ".idx";
			}

			if (!(*pFileHandle)) {

				/* First create the right name */
				RMascii* pSubName;

				pSubName = (typeof(pSubName))RMMalloc(RMasciiLength(pPrefix) + RMasciiLength(pSuffix) +1);
				if (!pSubName) {
					fprintf(NORMALMSG, "Bad file name prefix [%s]\n", pPrefix);
					continue;
				}
				RMPrintAscii(pSubName, "%s%s", pPrefix, pSuffix);

				/* Check it and open it */
				if (RMCompareAscii(pSubName - (FileName - pRealFileNameStart), (RMascii*) pEntryTable[file_index].name)) {
					*pFileHandle = RMOpenFile((const RMnonAscii*) pSubName, RM_FILE_OPEN_READ);
					if (!(*pFileHandle))
						fprintf(NORMALMSG, "Unable to open sub file [%s]\n", pSubName);
				}

				/* Free name */
				RMFree(pSubName);
			}
		}

		/*
		 * Then try to open text subs if possible
		 */

		if (playback_options->text_subs.count == RMFP_MAX_TEXT_SUBS)
			continue;

		/*
		 * Check that the prefix is right (to support files like 'prefix.VF.srt')
		 */
		if (RMNCompareAscii((RMascii*) pEntryTable[file_index].name, pPrefix - (FileName - pRealFileNameStart), RMasciiLength(pPrefix - (FileName - pRealFileNameStart)))) {
			RMascii* pSuffix = (RMascii*) ( pEntryTable[file_index].name + RMasciiLength((RMascii*) pEntryTable[file_index].name) - 4);
			RMbool valid_sub;

			valid_sub = FALSE;

			/* Now check that the suffix is a known one */
			if (RMCompareAsciiCaseInsensitively(pSuffix ,".ass")) {
				playback_options->text_subs.entry[playback_options->text_subs.count].type = RMFPTextSubs_ASS;
				valid_sub = TRUE;
			}
			if (RMCompareAsciiCaseInsensitively(pSuffix ,".ssa")) {
				playback_options->text_subs.entry[playback_options->text_subs.count].type = RMFPTextSubs_SSA;
				valid_sub = TRUE;
			}
			if (RMCompareAsciiCaseInsensitively(pSuffix ,".srt")) {
				playback_options->text_subs.entry[playback_options->text_subs.count].type = RMFPTextSubs_ASCII;
				valid_sub = TRUE;
			}
			if (RMCompareAsciiCaseInsensitively(pSuffix ,".smi")) {
				playback_options->text_subs.entry[playback_options->text_subs.count].type = RMFPTextSubs_SMI;
				valid_sub = TRUE;
			}

			/* Open file if it is a sub  */
			if (valid_sub) {

				/* First create the right name */
				RMascii* pSubName;

				pSubName = (typeof(pSubName))RMMalloc(RMasciiLength(pCurrentDirectory) + RMasciiLength((RMascii*) pEntryTable[file_index].name) + 2);
				if (!pSubName) {
					fprintf(NORMALMSG, "Bad file name prefix [%s]\n", pPrefix);
					continue;
				}
				RMPrintAscii(pSubName, "%s/%s", pCurrentDirectory, (RMascii*) pEntryTable[file_index].name);

				playback_options->text_subs.entry[playback_options->text_subs.count].file_handle = RMOpenFile(	(RMnonAscii*) pSubName,
																RM_FILE_OPEN_READ);
				if (!playback_options->text_subs.entry[playback_options->text_subs.count].file_handle)
					fprintf(NORMALMSG, "Unable to open sub file [%s]\n", pSubName);
				else {
					RMNCopyAscii( playback_options->text_subs.entry[playback_options->text_subs.count].description,
								(RMascii*) pEntryTable[file_index].name, RMFP_MAX_DESCRIPTION_SIZE);

					/* Sub is correctly opened, validate it */
					playback_options->text_subs.count++;

					fprintf(NORMALMSG, "Found a text subtitle [%s]\n", (RMascii*) pEntryTable[file_index].name);
				}

				RMFree(pSubName);
			}
		}
	}

	/* Now close directory */
	RMCloseDirectory(current_directory);

	/* Consistency check, do not allow incomplete SUB/IDX pair */
	if (	(playback_options->subidx_sub_file_handle && !playback_options->subidx_idx_file_handle)
	||	(!playback_options->subidx_sub_file_handle && playback_options->subidx_idx_file_handle)
		) {
		if (playback_options->subidx_sub_file_handle) {
			RMCloseFile(playback_options->subidx_sub_file_handle);
			playback_options->subidx_sub_file_handle = NULL;
		}
		if (playback_options->subidx_idx_file_handle) {
			RMCloseFile(playback_options->subidx_idx_file_handle);
			playback_options->subidx_idx_file_handle = NULL;
		}
	}
	else if (playback_options->subidx_sub_file_handle && playback_options->subidx_idx_file_handle){
		/* SUB/IDX found ! */
		fprintf(NORMALMSG, "Found matching SUB/IDX subtitles\n");
		playback_options->subidx_index = 0;
	}

AUTO_SUBS_EXIT:

	/* Notify subs scan end */
	rmfp_progress.progress.percentage = 100;
	notify_progress(pMainContext, &rmfp_progress, (RMbool *)NULL);

	/* Free memory */
	if (pPrefix)
		RMFree(pPrefix);
	if (pCurrentDirectory)
		RMFree(pCurrentDirectory);
	if (pEntryTable)
		RMFree(pEntryTable);

	return status;
}

static RMfile open_dtcp_url(struct rmfp_main_thread_context_type *pMainContext,
                            const RMascii *pURL,
                            struct RMDTCPAPIConnectionParameters *pDTCPConnectionParameters)
{
	RMstatus Status;
	struct RMDTCPAPIProfile DTCPProfile = { 0, };
	struct RMDTCPAPIURLHandle *pDTCPURLHandle = NULL;

	HTTPFile *HTTPFileHandle = NULL;
#ifdef	USE_RMLIBCURL
	struct RMLibCURLHandle *curlHandle = NULL;
#endif	//USE_RMLIBCURL
	
	RMfile EncryptedFileHandle = NULL;
	RMfile DecryptedFileHandle = NULL;

	RMDBGLOG((ENABLE, "DTCP-IP encrypted URL detected, start DTCP-IP session\n"));


	DTCPProfile.pRUA = pMainContext->pRUA;

	DTCPProfile.UseInbandDecryption = FALSE;

#if (EM86XX_CHIP < EM86XX_CHIPID_TANGO3)
	DTCPProfile.SlotID              = 0;
#else
	DTCPProfile.SlotID              = 0xD7CBD7CB;
#endif
	DTCPProfile.WithPreload         = FALSE;
	DTCPProfile.FlashSector         = 4;
	DTCPProfile.pPathToCertificates = (typeof(DTCPProfile.pPathToCertificates))"/mnt/";

	DTCPProfile.pHost = pDTCPConnectionParameters->pHost;
	DTCPProfile.Port  = pDTCPConnectionParameters->Port;


	Status = RMDTCPAPIOpenSession(&DTCPProfile, &(pMainContext->pDTCPHandle));
	if (Status != RM_OK) {
		RMNOTIFY((NULL, RM_ERROR, "Cannot Open DTCP Session!\n"));

		goto dtcp_exit_with_error;
	}

#ifdef	USE_RMLIBCURL
	Status = RMLibCURLOpen(&curlHandle);
	if(RMFAILED(Status)) {
		RMNOTIFY((NULL, Status, "RMLibCURLOpen() failed\n"));
		curlHandle = NULL;
	}

	if (curlHandle != NULL) {
		/* Set SSL Certificate path */
		Status = RMLibCURLSetSSLCertificatePath( curlHandle,  (RMascii *)LIBCURL_SSL_CERT_PATH );
		if(RMFAILED(Status)) {
			RMNOTIFY((NULL, Status, "RMLibCURLSetSSLCertificatePath() failed\n"));
			RMLibCURLClose(curlHandle);
			curlHandle = NULL;
		}
		else {	
			/** TODO: Not sure how not including httpFileOps will affect functionality. **/
			Status = RMLibCURLOpenURL(curlHandle, (RMascii *)pURL, &EncryptedFileHandle);
			if (RMFAILED(Status)) {
				RMNOTIFY((NULL, Status, "RMLibCURLOpenURL() failed\n"));
			}
			else {
				RMNOTIFY((NULL, Status, "rmlibcurl successfully opened\n"));
			}
		}
	}
	
	if ( curlHandle == NULL) {
		goto dtcp_exit_with_error;
	}
	else 
#endif	//USE_RMLIBCURL
	{
		// Open the URL
		HTTPFileHandle = fetchOpen((const RMascii *)pURL, (RMHTTPFlags)0);
		if (!HTTPFileHandle) {
			RMNOTIFY((NULL, RM_ERROR, "Cannot open HTTP connection!\n"));
	
			goto dtcp_exit_with_error;
		}
	
		/*
		WARNING: 'httpFileOps' is declared extern (in rmlibhttp/include/rmlibhttp.h)
		to be exported from within rmlibhttp/src/http.c
	
		That is probably not the best way to do it...
		*/
		EncryptedFileHandle = RMOpenFileCookie(HTTPFileHandle, RM_FILE_OPEN_READ, (RMFileOps *)httpFileOps);
		if (!EncryptedFileHandle) {
			RMNOTIFY((NULL, RM_ERROR, "Cannot open HTTP pseudo-file!\n"));
	
			goto dtcp_exit_with_error;
		}
	}

	Status = RMDTCPAPIOpenStream(pMainContext->pDTCPHandle, EncryptedFileHandle, TRUE, &DecryptedFileHandle, &pDTCPURLHandle);
	if (Status != RM_OK) {
		RMNOTIFY((NULL, Status, "Cannot open DTCP stream\n"));

		goto dtcp_exit_with_error;
	}


	RMDBGLOG((ENABLE, "DTCP-IP init success!\n"));

	pMainContext->pOptions->playback_options.pDTCPURLHandle = pDTCPURLHandle;
	pMainContext->pOptions->playback_options.DTCPUseDemuxForDecryption = FALSE;

	RMDBGLOG((ENABLE, "Releasing parameters\n"));

	RMDTCPAPIReleaseParameters(pDTCPConnectionParameters);
	return DecryptedFileHandle;


dtcp_exit_with_error:

	if (DecryptedFileHandle) {
		RMDBGLOG((ENABLE, "Closing decrypted file\n"));
		RMCloseFile(DecryptedFileHandle);

		EncryptedFileHandle = NULL;
	}

	if (EncryptedFileHandle) {
		RMDBGLOG((ENABLE, "Closing encrypted file\n"));
		RMCloseFile(EncryptedFileHandle);

		// this also closes the HTTPFile so here set the httpfile to null so that it is not freed
		HTTPFileHandle = NULL;
	}

	if (HTTPFileHandle) {
		RMDBGLOG((ENABLE, "Closing http file\n"));
		fetchClose(HTTPFileHandle);
	}

#ifdef	USE_RMLIBCURL
	if (curlHandle) {
		RMDBGLOG((ENABLE, "Closing curl handle\n"));
		RMLibCURLClose(curlHandle);
	}
#endif	//USE_RMLIBCURL

	if (pMainContext->pDTCPHandle) {
		RMDBGLOG((ENABLE, "Closing session\n"));
		RMDTCPAPICloseSession(pMainContext->pDTCPHandle);
	}

	RMDBGLOG((ENABLE, "Releasing parameters\n"));
	RMDTCPAPIReleaseParameters(pDTCPConnectionParameters);

	return NULL;
}

static RMfile open_url(struct rmfp_main_thread_context_type *pMainContext, const RMascii *fileName)
{
	RMstatus Status = RM_ERROR;
	struct RMDTCPAPIConnectionParameters DTCPConnectionParameters = { 0, };

	RMfile fileHandle = NULL;
	RMfile CDXAFileHandle = NULL;
	/* RMfile LiveHttpFileHandle = NULL; */

	RMDBGLOG((ENABLE, "open_url(%p, '%s')\n", pMainContext, fileName));
#define RECORD_TIMEOUT_MS (5 * 1000)

	//Try apple live http file
	/* LiveHttpFileHandle = RMLiveHTTPOpen(fileName, RM_FILE_OPEN_READ); */
	/* if (LiveHttpFileHandle) { */
	/* 	fprintf(NORMALMSG, "live http file\n"); */
	/* 	fileHandle = LiveHttpFileHandle; */
	/* 	if (RMLiveHTTPisSlidingWindow(fileHandle)) */
	/* 		pMainContext->pOptions->playback_options.linear_mode = TRUE; */
	/* 	return fileHandle; */
	/* } */

	if (pMainContext->AppOptions.Playback.file_is_not_closed) {
		// use record
		RMDBGLOG((ENABLE, "open record\n"));

		fileHandle = RMRecordFileOpen((const RMnonAscii*)fileName, RM_FILE_OPEN_READ, NULL, RECORD_TIMEOUT_MS);
	}
	else {
		Status = RMDTCPAPIGetParametersFromURL((RMascii *)fileName, &DTCPConnectionParameters);
		if (Status == RM_OK)
			fileHandle = open_dtcp_url(pMainContext, fileName, &DTCPConnectionParameters);
		else
			fileHandle = RMFPOpenURL(pMainContext->pHandle, fileName);
	}

	if (!fileHandle) {
		if(Sw_LogMediaFileInfo)
		{
			fprintf(ERRORMSG, "Open url '%s' error\n", fileName);
		}
		return NULL;
	}

	if (Status != RM_OK) {
		// HACK: currently the DTCP-IP lib doesn't handle small requests, RIFFCDXAOpen does some, so disable this
		CDXAFileHandle = RMRIFFCDXAOpen(fileHandle, RM_FILE_OPEN_READ, TRUE);
		if (CDXAFileHandle) {
			fprintf(NORMALMSG, "CDXA file\n");
			fileHandle = CDXAFileHandle;
		}
	}

	if (pMainContext->pOptions->playback_options.unseekable_file)
		fileHandle = RMMakeUnseekableFile(fileHandle);

	return fileHandle;
}

