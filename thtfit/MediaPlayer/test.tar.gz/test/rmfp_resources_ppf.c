/*****************************************
 Copyright 2001-2009
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   rmfp_resources_ppf.c
  @brief


  @author Francesco Iacopino
  @date   2009-12-03
*/

#include "rmfp_internal.h"

#define LOCALDBG DISABLE

RMstatus rmfp_internal_open_ppf(struct RMFPHandle *pHandle, struct RMLibPlayVideoSource *pVideoSource, RMuint32 input_surface, RMuint32 *output_surface){

	RMstatus status;
	struct RMFPPPFResourcesProfile rmfp_ppf_resources_profile = { 0, };
	struct EMhwlibMemoryBlockList requiredmemblocks;
	RMuint32 block, i=0, ppf_malloc_sizes[4];

	status =  RMPPFCreateInstance(&(pVideoSource->pPPFHandle.pppf));
	if (status != RM_OK) {
		RMNOTIFY((NULL, status, "Cannot create PPF instance\n"));
		   return status;
	}

	pVideoSource->pPPFHandle.ppf_filter_slot = 0;


	RMMemset(ppf_malloc_sizes, 0, sizeof(ppf_malloc_sizes));

	status = RMPPFSetInputSurface(pVideoSource->pPPFHandle.pppf, pHandle->demux_options.task_id, 0, input_surface);
	if (status != RM_OK) {
		   RMNOTIFY((NULL, status, "Cannot set the PPF input surface\n"));
		   return status;
	}

	status = RMPPFGetEngineMem(pVideoSource->pPPFHandle.pppf, pHandle->demux_options.task_id,  &requiredmemblocks);
	if (status != RM_OK) {
		   RMNOTIFY((NULL, status, "Cannot get the PPF GFX engine memory\n"));
		   return status;
	}

	for(block = 0; block < requiredmemblocks.BlockCount; block++)
	   ppf_malloc_sizes[i++] = requiredmemblocks.Blocks[block].Size;


	status = RMPPFGetOutputMem(pVideoSource->pPPFHandle.pppf, pHandle->demux_options.task_id, 0, &requiredmemblocks);
	if (status != RM_OK) {
		 RMNOTIFY((NULL, status, "Cannot get the PPF output memory\n"));
		 return status;
	}

	for(block = 0; block < requiredmemblocks.BlockCount; block++)
	   ppf_malloc_sizes[i++] = requiredmemblocks.Blocks[block].Size;

	rmfp_ppf_resources_profile.Version	= GET_VERSION_FROM_MAGIC(RMFP_PPF_RESOURCES_PROFILE_VERSION);

	rmfp_ppf_resources_profile.dram	= pHandle->playback_options.DRAMIndex;

	rmfp_ppf_resources_profile.engine_memory_address	= 0;
	rmfp_ppf_resources_profile.engine_memory_size	= ppf_malloc_sizes[0];

	rmfp_ppf_resources_profile.input_memory_address	= 0;
	rmfp_ppf_resources_profile.input_memory_size	= ppf_malloc_sizes[1];

	rmfp_ppf_resources_profile.output_memory_address	= 0;
	rmfp_ppf_resources_profile.output_memory_size	= ppf_malloc_sizes[2];

	rmfp_ppf_resources_profile.data_memory_address	= 0;
	rmfp_ppf_resources_profile.data_memory_size	= ppf_malloc_sizes[3];

	rmfp_ppf_resources_profile.engine_index	= pHandle->video_options.EngineIndex;
	rmfp_ppf_resources_profile.decoder_index = pHandle->video_options.DecoderIndex;

	rmfp_ppf_resources_profile.STC_index	= pHandle->playback_options.STCIndex;

	// then present the RMFPPPFResourcesProfile to the application if the callback was defined
	if (pHandle->profile.rmfp_ppf_resources_callback) {
		status = pHandle->profile.rmfp_ppf_resources_callback(pHandle->profile.callback_context, &rmfp_ppf_resources_profile);
		if (status != RM_OK) {
			RMNOTIFY((NULL, status, "Failed to get resources from application\n"));
			return status;
		}
	}

	// engine
	if ((!rmfp_ppf_resources_profile.engine_memory_address) &&
		(rmfp_ppf_resources_profile.engine_memory_size)) {
		pHandle->ppf_resources.engine_memory_address = DCCMalloc(pHandle->profile.pDCC,
										  rmfp_ppf_resources_profile.dram,
										  RUA_DRAM_UNCACHED,
										  rmfp_ppf_resources_profile.engine_memory_size);

		if (!pHandle->ppf_resources.engine_memory_address) {
			RMNOTIFY((NULL, RM_FATALOUTOFMEMORY, "Can't allocate %lu bytes in DRAM %lu\n",
					rmfp_ppf_resources_profile.engine_memory_size,
					rmfp_ppf_resources_profile.dram));
			return RM_FATALOUTOFMEMORY;
		}
		else
			RMDBGLOG((LOCALDBG, "allocated %lu bytes for gfx engine\n", rmfp_ppf_resources_profile.engine_memory_size));

		pHandle->ppf_resources.free_engine = TRUE;
	}
	else
		pHandle->ppf_resources.engine_memory_address = rmfp_ppf_resources_profile.engine_memory_address;


	requiredmemblocks.Blocks[0].Address = pHandle->ppf_resources.engine_memory_address;
	requiredmemblocks.Blocks[0].Size = rmfp_ppf_resources_profile.engine_memory_size;
	requiredmemblocks.BlockCount = 1;

	RMDBGLOG((LOCALDBG, "Engine Memory: %lu bytes at %p\n",
			requiredmemblocks.Blocks[0].Size,
			requiredmemblocks.Blocks[0].Address));

	status = RMPPFSetEngineMem(pVideoSource->pPPFHandle.pppf, pHandle->demux_options.task_id, &requiredmemblocks);
	if (status != RM_OK) {
		 RMNOTIFY((NULL, status, "Cannot set the PPF GFX engine memory\n"));
		 return status;
	}

	// input
	if ((!rmfp_ppf_resources_profile.input_memory_address) &&
		(rmfp_ppf_resources_profile.input_memory_size)) {
		pHandle->ppf_resources.input_memory_address = DCCMalloc(pHandle->profile.pDCC,
									   rmfp_ppf_resources_profile.dram,
									   RUA_DRAM_UNCACHED,
									   rmfp_ppf_resources_profile.input_memory_size);

		if (!pHandle->ppf_resources.input_memory_address) {
			RMNOTIFY((NULL, RM_FATALOUTOFMEMORY, "Can't allocate %lu bytes in DRAM %lu\n",
					rmfp_ppf_resources_profile.input_memory_size,
					rmfp_ppf_resources_profile.dram));
			return RM_FATALOUTOFMEMORY;
		}
		else
			RMDBGLOG((LOCALDBG, "allocated %lu bytes for ppf input\n", rmfp_ppf_resources_profile.input_memory_size));

		pHandle->ppf_resources.free_input = TRUE;
	}
	else
		pHandle->ppf_resources.input_memory_address = rmfp_ppf_resources_profile.input_memory_address;

	requiredmemblocks.BlockCount = 3;
	requiredmemblocks.Blocks[0].Address = pHandle->ppf_resources.input_memory_address;
	requiredmemblocks.Blocks[0].Size = rmfp_ppf_resources_profile.input_memory_size;

	RMDBGLOG((LOCALDBG, "Input Memory: %lu bytes at %p\n",
			requiredmemblocks.Blocks[0].Size,
			requiredmemblocks.Blocks[0].Address));

	// output
	if ((!rmfp_ppf_resources_profile.output_memory_address) &&
		(rmfp_ppf_resources_profile.output_memory_size)) {
		pHandle->ppf_resources.output_memory_address = DCCMalloc(pHandle->profile.pDCC,
									   rmfp_ppf_resources_profile.dram,
									   RUA_DRAM_UNCACHED,
									   rmfp_ppf_resources_profile.output_memory_size);

		if (!pHandle->ppf_resources.output_memory_address) {
			RMNOTIFY((NULL, RM_FATALOUTOFMEMORY, "Can't allocate %lu bytes in DRAM %lu\n",
					rmfp_ppf_resources_profile.output_memory_size,
					rmfp_ppf_resources_profile.dram));
			return RM_FATALOUTOFMEMORY;
		}
		else
			RMDBGLOG((LOCALDBG, "allocated %lu bytes for ppf output\n", rmfp_ppf_resources_profile.output_memory_size));

		pHandle->ppf_resources.free_output = TRUE;
	}
	else
		pHandle->ppf_resources.output_memory_address = rmfp_ppf_resources_profile.output_memory_address;

	requiredmemblocks.Blocks[1].Address = pHandle->ppf_resources.output_memory_address;
	requiredmemblocks.Blocks[1].Size = rmfp_ppf_resources_profile.output_memory_size;

	RMDBGLOG((LOCALDBG, "Output Memory: %lu bytes at %p\n",
			requiredmemblocks.Blocks[1].Size,
			requiredmemblocks.Blocks[1].Address));

	// data
	if ((!rmfp_ppf_resources_profile.data_memory_address) &&
		(rmfp_ppf_resources_profile.data_memory_size)) {
		pHandle->ppf_resources.data_memory_address = DCCMalloc(pHandle->profile.pDCC,
									   rmfp_ppf_resources_profile.dram,
									   RUA_DRAM_UNCACHED,
									   rmfp_ppf_resources_profile.data_memory_size);

		if (!pHandle->ppf_resources.data_memory_address) {
			RMNOTIFY((NULL, RM_FATALOUTOFMEMORY, "Can't allocate %lu bytes in DRAM %lu\n",
					rmfp_ppf_resources_profile.data_memory_size,
					rmfp_ppf_resources_profile.dram));
			return RM_FATALOUTOFMEMORY;
		}
		else
			RMDBGLOG((LOCALDBG, "allocated %lu bytes for ppf input\n", rmfp_ppf_resources_profile.data_memory_size));

		pHandle->ppf_resources.free_data = TRUE;
	}
	else
		pHandle->ppf_resources.data_memory_address = rmfp_ppf_resources_profile.data_memory_address;

	requiredmemblocks.Blocks[2].Address = pHandle->ppf_resources.data_memory_address;
	requiredmemblocks.Blocks[2].Size = rmfp_ppf_resources_profile.data_memory_size;

	RMDBGLOG((LOCALDBG, "Output Memory: %lu bytes at %p\n",
			requiredmemblocks.Blocks[2].Size,
			requiredmemblocks.Blocks[2].Address));

	status = RMPPFSetOutputMem(pVideoSource->pPPFHandle.pppf, pHandle->demux_options.task_id, 0, &requiredmemblocks);
	if (status != RM_OK) {
		 RMNOTIFY((NULL, status, "Cannot set the PPF output memory\n"));
		 return status;
	}
	status = RMPPFGetOutputSurface(pVideoSource->pPPFHandle.pppf, pHandle->demux_options.task_id, 0, output_surface);
	if (status != RM_OK) {
		 RMNOTIFY((NULL, status, "Cannot get the PPF output surface\n"));
		 return status;
	}

	return RM_OK;
}

RMstatus rmfp_internal_close_ppf(struct RMFPHandle *pHandle, struct RMLibPlayVideoSource *pVideoSource){

	RMuint32 surface = 0;
	RMstatus status;
	struct RMFPPPFResourcesProfile rmfp_ppf_resources_profile = { 0, };
	enum ppf_watermark_cmd cmd = ppf_watermark_cmd_stop;

	//send command : stop
	status = RMPPFSetCommand(pVideoSource->pPPFHandle.pppf, pHandle->demux_options.task_id, &cmd, sizeof(cmd), NULL, 0);
	if (status != RM_OK){
	   RMNOTIFY((NULL, status, "Cannot set the PPF command (%s)\n", RMstatusToString(status)));
	   return status;
	}

	//unset input surface
	status = RMPPFSetInputSurface(pVideoSource->pPPFHandle.pppf, pHandle->demux_options.task_id, 0, (RMuint32)NULL);
	if (status != RM_OK){
	   RMNOTIFY((NULL, status, "Cannot set the PPF input surface (%s)\n", RMstatusToString(status)));
	   return status;
	}

	//unset output mem
	{
		   struct EMhwlibMemoryBlockList dummyblocks;

		   dummyblocks.BlockCount = 0;

		   status = RMPPFSetEngineMem(pVideoSource->pPPFHandle.pppf, pHandle->demux_options.task_id, &dummyblocks);
		   if (status != RM_OK) {
			   RMNOTIFY((NULL, status, "Error in RMPPFSetOutMem %s\n", RMstatusToString(status)));
			   return status;
		   }

		   status = RMPPFSetOutputMem(pVideoSource->pPPFHandle.pppf, pHandle->demux_options.task_id, 0, &dummyblocks);
		   if (status != RM_OK) {
			   RMNOTIFY((NULL, status, "Error in RMPPFSetOutMem %s\n", RMstatusToString(status)));
			   return status;
		   }
	}

	status = RUASetProperty(pHandle->profile.pRUA, pHandle->video_options.VideoScalerID, RMGenericPropertyID_Surface, &surface, sizeof(surface), 0);
	if (status != RM_OK) {
	   RMNOTIFY((NULL, status, "Error Unsetting surface on the scaler %s\n", RMstatusToString(status)));
	   return status;
	}


	if (pHandle->ppf_resources.free_engine) {
		RMDBGLOG((LOCALDBG, "Free ppf engine memory at %p\n", pHandle->ppf_resources.engine_memory_address));
		DCCFree(pHandle->profile.pDCC, pHandle->ppf_resources.engine_memory_address);
		pHandle->ppf_resources.engine_memory_address = 0;
	}

	if (pHandle->ppf_resources.free_input) {
		RMDBGLOG((LOCALDBG, "Free ppf input memory at %p\n", pHandle->ppf_resources.input_memory_address));
		DCCFree(pHandle->profile.pDCC, pHandle->ppf_resources.input_memory_address);
		pHandle->ppf_resources.input_memory_address = 0;
	}

	if (pHandle->ppf_resources.free_output) {
		RMDBGLOG((LOCALDBG, "Free ppf output memory at %p\n", pHandle->ppf_resources.output_memory_address));
		DCCFree(pHandle->profile.pDCC, pHandle->ppf_resources.output_memory_address);
		pHandle->ppf_resources.output_memory_address = 0;
	}

	if (pHandle->ppf_resources.free_data) {
		RMDBGLOG((LOCALDBG, "Free ppf data memory at %p\n", pHandle->ppf_resources.data_memory_address));
		DCCFree(pHandle->profile.pDCC, pHandle->ppf_resources.data_memory_address);
		pHandle->ppf_resources.data_memory_address = 0;
	}

	rmfp_ppf_resources_profile.Version = GET_VERSION_FROM_MAGIC(RMFP_PICTURE_TRANSFORM_RESOURCES_PROFILE_VERSION);

	rmfp_ppf_resources_profile.dram = pHandle->picture_transform_resources.dram;

	rmfp_ppf_resources_profile.engine_memory_address = pHandle->ppf_resources.engine_memory_address;
	rmfp_ppf_resources_profile.engine_memory_size = pHandle->ppf_resources.engine_memory_size;

	rmfp_ppf_resources_profile.input_memory_address = pHandle->ppf_resources.input_memory_address;
	rmfp_ppf_resources_profile.input_memory_size = pHandle->ppf_resources.input_memory_size;

	rmfp_ppf_resources_profile.output_memory_address = pHandle->ppf_resources.output_memory_address;
	rmfp_ppf_resources_profile.output_memory_size = pHandle->ppf_resources.output_memory_size;

	rmfp_ppf_resources_profile.data_memory_address = pHandle->ppf_resources.data_memory_address;
	rmfp_ppf_resources_profile.data_memory_size = pHandle->ppf_resources.data_memory_size;

	rmfp_ppf_resources_profile.engine_index = pHandle->picture_transform_resources.engine_index;
	rmfp_ppf_resources_profile.decoder_index = pHandle->picture_transform_resources.decoder_index;

	rmfp_ppf_resources_profile.STC_index = pHandle->playback_options.STCIndex;

	// then present the RMFPPictureTransformResourcesProfile to the application if the callback was defined
	if (pHandle->profile.rmfp_release_ppf_resources_callback) {
		status = pHandle->profile.rmfp_release_ppf_resources_callback(pHandle->profile.callback_context, &rmfp_ppf_resources_profile);
		if (status != RM_OK) {
			RMNOTIFY((NULL, status, "The application failed to release the resources\n"));
			return status;
		}
	}

	status = RMPPFDestroyInstance(pVideoSource->pPPFHandle.pppf);
	if (status != RM_OK) {
		RMNOTIFY((NULL, status, "Error in RMPPFDestroyInstance %s\n", RMstatusToString(status)));
		return status;
	}

	return RM_OK;
}


