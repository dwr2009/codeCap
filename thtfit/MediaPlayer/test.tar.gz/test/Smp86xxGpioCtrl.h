#ifndef	_SMP86XX_GPIO_CTRL_H_
#define	_SMP86XX_GPIO_CTRL_H_

#include <BaseTypeDef.h>

namespace Smp86xx
{

#define	GPIO_INPUT		1
#define	GPIO_OUTPUT		2

class CSmp86xxGpioCtrl
{
public:
	CSmp86xxGpioCtrl();
	virtual ~CSmp86xxGpioCtrl();
	virtual BOOL_t ChkInit();
	virtual INT_t setGpioDirection(enum GPIOId_type GpioId, INT_t Direction);
	virtual INT_t setGpioData(enum GPIOId_type GpioId, BOOL_t bValue);
	virtual VOID DelayUs(INT_t DelayTimeUs);
private:
	INT_t CommonConstruct();
protected:
	struct llad * m_pLlad;
	struct gbus * m_pGbus;
private:
	BOOL_t m_bInited;
};

}	//namespace Smp86xx

#endif	//_SMP86XX_GPIO_CTRL_H_
