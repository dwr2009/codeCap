/*****************************************
 Copyright 2001-2007
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   rmfp_resources_dmapool.c
  @brief


  @author Sebastian Frias Feltrer
  @date   2007-11-05
*/

#include "rmfp_internal.h"



#define LOCALDBG ENABLE


RMstatus rmfp_internal_get_dmapool_handler(void *pContext, struct RMLibPlayDMAPool *pDMAPool, struct RMLibPlayDMAPoolProfile *pDMAPoolProfile)
{
	struct RMFPHandle *pHandle = NULL;
	struct RUA *pRUA = NULL;
	struct RUABufferPool *pDMA = NULL;
	RMuint32 DMAPoolSize;
	RMstatus status = RM_OK;
	struct RMFPDMAPoolProfile rmfp_dmapool_profile = { 0, };

	RMDBGLOG((LOCALDBG, "rmfp_get_dmapool()\n"));

	ASSERT_NULL_POINTER(pContext);
	ASSERT_NULL_POINTER(pDMAPool);
	ASSERT_NULL_POINTER(pDMAPoolProfile);

	pHandle = (struct RMFPHandle *)pContext;
	pRUA = pHandle->profile.pRUA;


	DMAPoolSize = pDMAPoolProfile->bufferCount << pDMAPoolProfile->bufferSize_log2;

	RMDBGLOG((LOCALDBG, "Open DMAPool: ModuleID 0x%lx, dir %lu, BufferSize %ld, Count %ld, MaxSize %lu\n", 
		  pDMAPoolProfile->moduleID,
		  (RMuint32)pDMAPoolProfile->direction,
		  (1 << pDMAPoolProfile->bufferSize_log2), 
		  pDMAPoolProfile->bufferCount, DMAPoolSize));


  // create a RMFPDMAPoolProfile
	rmfp_dmapool_profile.Version         = GET_VERSION_FROM_MAGIC(RMFP_DMAPOOL_PROFILE_VERSION);

	rmfp_dmapool_profile.ModuleID        = pDMAPoolProfile->moduleID;
	rmfp_dmapool_profile.Direction       = pDMAPoolProfile->direction;
	rmfp_dmapool_profile.BufferCount     = pDMAPoolProfile->bufferCount;
	rmfp_dmapool_profile.BufferSize_log2 = pDMAPoolProfile->bufferSize_log2;


  // then present the RMFPDMAPoolResourcesProfile to the application if the callback was defined
	if (pHandle->profile.rmfp_open_dmapool_callback) {

		RMDBGLOG((LOCALDBG, "Request DMAPool to application\n"));

		status = pHandle->profile.rmfp_open_dmapool_callback(pHandle->profile.callback_context, &rmfp_dmapool_profile, &pDMA);
		if (status != RM_OK) {
			RMNOTIFY((NULL, status, "Failed to open DMAPool\n"));
			return status;
		}
	}
	else {
		// we must allocate it internally

		RMDBGLOG((LOCALDBG, "Allocate DMAPool internally\n"));

		status = RUAOpenPool(pRUA,
				     pDMAPoolProfile->moduleID,
				     pDMAPoolProfile->bufferCount,
				     pDMAPoolProfile->bufferSize_log2,
				     pDMAPoolProfile->direction,
				     &pDMA);
		if (status != RM_OK) {
			RMNOTIFY((NULL, status, "Cannot open DMA pool\n"));
			goto exit;
		}
	}


exit:

	pDMAPool->pool = (void *)pDMA;

	return status;

}



RMstatus rmfp_internal_release_dmapool_handler(void *pContext, struct RMLibPlayDMAPool *pDMAPool)
{
	struct RMFPHandle *pHandle = NULL;
	struct RUABufferPool *pDMA = NULL;
	RMstatus status;

	RMDBGLOG((LOCALDBG, "rmfp_release_dmapool()\n"));

	ASSERT_NULL_POINTER(pContext);
	ASSERT_NULL_POINTER(pDMAPool);

	pHandle = (struct RMFPHandle *)pContext;
	pDMA = (struct RUABufferPool *)pDMAPool->pool;


	if (pHandle->profile.rmfp_close_dmapool_callback) {
		RMDBGLOG((LOCALDBG, "Tell application to release the DMAPool\n"));

		status = pHandle->profile.rmfp_close_dmapool_callback(pHandle->profile.callback_context, pDMA);
		if (status != RM_OK) {
			RMNOTIFY((NULL, status, "Failed to close application opened DMAPool\n"));
			return status;
		}
	}
	else {
		RMDBGLOG((LOCALDBG, "Release internally allocated DMAPool\n"));

		status = RUAClosePool(pDMA);
	}

	return status;

}
