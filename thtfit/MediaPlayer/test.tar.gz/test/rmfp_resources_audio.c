/*****************************************
 Copyright 2001-2007
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   rmfp_resources_audio.c
  @brief


  @author Sebastian Frias Feltrer
  @date   2007-11-05
*/

#ifndef	ALLOW_OS_CODE
#define	ALLOW_OS_CODE
#endif	//ALLOW_OS_CODE

#include "rmfp_internal.h"
#include "DbgLogSwitchDef.h"
#include <ErrPrintHelper.h>

#define LOCALDBG ENABLE


#define ALWAYS_TRY_TO_FREE_SHARED_MEMORY (0)

#define RUA_ADDRESS_ID_TAG(tag, engine) ((engine << 16) | (tag))
#define PRINT_UINT32_VARIABLE(x) RMDBGLOG((LOCALDBG, "%s = 0x%lx (signed %ld unsigned %lu)\n", #x, x, x, x))

static RMstatus rmfp_fill_profile_with_options(struct RMFPAudioOptions *pAudioOptions, struct RMLibPlayAudioProfile *pAudioProfile);
static RMstatus rmfp_fill_output_options(struct RMFPHandle *pHandle, RMuint32 EngineModuleID, struct RMLibPlayAudioProfile *pAudioProfile);
static RMstatus rmfp_print_rmlibplay_audio_decoder_profile(struct RMLibPlayAudioProfile *pAudioProfile);
static RMstatus rmfp_print_dcc_audio_decoder_profile(struct DCCXMultipleAudioProfile *pMultipleAudioProfile);


RMstatus rmfp_internal_get_audio_decoder_handler(void *pContext, struct RMLibPlayMultipleAudioSource *pMultipleAudioSource, struct RMLibPlayAudioProfile *pAudioProfile)
{
	struct RMFPHandle *pHandle = NULL;

	struct DCCXMultipleAudioProfile dcc_audio_profile = { 0, };
	struct DCCXMultipleAudioResources dcc_audio_resources = { 0, };
	struct RMFPMultipleAudioInstancesProfile rmfp_audio_instances_profile = { 0, };
	struct RMFPMultipleAudioResourcesProfile rmfp_audio_resources_profile = { 0, };
	struct DCCMultipleAudioSource *pDCCMultipleAudioSource = NULL;
	struct RMFPPlayOptions *pPlayOptions = NULL;
	struct RMFPAudioOptions *pAudioOptions = NULL;
	RMuint32 shared_memory_address;
	RMuint32 protected_memory_address;
	RMuint32 unprotected_memory_address;

	RMstatus status;
	RMuint32 i;
	RMint32 leftTryTimes;

	RMDBGLOG((LOCALDBG, "rmfp_get_audio_decoder()\n"));

	ASSERT_NULL_POINTER(pContext);
	ASSERT_NULL_POINTER(pMultipleAudioSource);
	ASSERT_NULL_POINTER(pAudioProfile);

	pHandle = (struct RMFPHandle *)pContext;

	pAudioOptions = &(pHandle->audio_options);
	pPlayOptions = &(pHandle->playback_options);


	RMDBGLOG((LOCALDBG, "profile before applying options\n"));
	rmfp_print_rmlibplay_audio_decoder_profile(pAudioProfile);


	rmfp_fill_profile_with_options(pAudioOptions, pAudioProfile);

	RMDBGLOG((LOCALDBG, "profile after applying options\n"));
	rmfp_print_rmlibplay_audio_decoder_profile(pAudioProfile);

	/*
	 * First ask the application for the instances index/engines
	 */
	rmfp_audio_instances_profile.Version = GET_VERSION_FROM_MAGIC(RMFP_AUDIO_INSTANCES_PROFILE_VERSION);

	/* Only 1 instance */
	if ((pAudioOptions->nb_audio_instances == 0) || (pAudioOptions->nb_audio_instances == 1)) {
		rmfp_audio_instances_profile.instance[0].engine_index = pAudioOptions->EngineIndex;
		rmfp_audio_instances_profile.instance[0].decoder_index = pAudioOptions->DecoderIndex;;

		rmfp_audio_instances_profile.number_of_instances= 1;
	}
	/* More than 1 instances */
	else if (pAudioOptions->nb_audio_instances <= MAX_AUDIO_DECODER_INSTANCES) {
		RMuint32 current_engine = 0;
		RMuint32 nb_decoders_in_engine = 0;
		for (i = 0; i < pAudioOptions->nb_audio_instances; i++) {

			rmfp_audio_instances_profile.instance[i].engine_index = current_engine;
			rmfp_audio_instances_profile.instance[i].decoder_index = nb_decoders_in_engine;

			nb_decoders_in_engine++;
			rmfp_audio_instances_profile.number_of_instances++;

			if (nb_decoders_in_engine == MAX_AUDIO_DECODER_INSTANCES_PER_ENGINE) {
				if (current_engine == (MAX_AUDIO_ENGINE_INSTANCES-1))
					break;
				else {
					current_engine++;
					nb_decoders_in_engine = 0;
				}
			}
		}
	}
	/* Too much instances */
	else {
		RMNOTIFY((NULL, RM_ERROR, "too much audio instances requested\n"));
		return RM_ERROR;
	}

	/* Now call the callback and check that the count has not changed */
	if (pHandle->profile.rmfp_audio_instances_callback) {
		RMuint32 count = rmfp_audio_instances_profile.number_of_instances;

		status = pHandle->profile.rmfp_audio_instances_callback(pHandle->profile.callback_context, &rmfp_audio_instances_profile);
		if (status != RM_OK) {
			RMNOTIFY((NULL, status, "Failed to get audio instances from application\n"));
			return status;
		}

		if (count != rmfp_audio_instances_profile.number_of_instances) {
			RMNOTIFY((NULL, RM_ERROR, "The application is not allowed to change the audio decoders count\n"));
			return RM_ERROR;
		}
	}

	/*
	 * Now create the DCC profile
	 */

	/* Only 1 instance */
	if ((pAudioOptions->nb_audio_instances == 0) || (pAudioOptions->nb_audio_instances == 1)) {
		dcc_audio_profile.instance[0].STCID = pPlayOptions->STCIndex + pPlayOptions->STCEngine*3;
		dcc_audio_profile.instance[0].BitstreamFIFOSize = pAudioProfile->BitstreamFIFOSize;
		dcc_audio_profile.instance[0].XferFIFOCount = pAudioProfile->XferFIFOCount;
		dcc_audio_profile.instance[0].PtsFIFOCount = pAudioProfile->PtsFIFOCount;
		dcc_audio_profile.instance[0].InbandFIFOCount = pAudioProfile->InbandFIFOCount;

		dcc_audio_profile.instance[0].AudioEngineIndex = rmfp_audio_instances_profile.instance[0].engine_index;
		dcc_audio_profile.instance[0].AudioDecoderIndex = rmfp_audio_instances_profile.instance[0].decoder_index;
		dcc_audio_profile.instance[0].DemuxProgramID =rmfp_audio_instances_profile.instance[0].engine_index * 2;

		dcc_audio_profile.number_of_instances = 1;
		pAudioOptions->nb_audio_instances = 1;
	}
	/* More than 1 instances */
	else if (pAudioOptions->nb_audio_instances <= MAX_AUDIO_DECODER_INSTANCES) {
		/* Try to fill decoders starting from requested audio engine */
		for (i = 0; i < pAudioOptions->nb_audio_instances; i++) {
			dcc_audio_profile.instance[i].STCID = pPlayOptions->STCIndex + pPlayOptions->STCEngine*3;
			dcc_audio_profile.instance[i].BitstreamFIFOSize = pAudioProfile->BitstreamFIFOSize;
			dcc_audio_profile.instance[i].XferFIFOCount = pAudioProfile->XferFIFOCount;
			dcc_audio_profile.instance[i].PtsFIFOCount = pAudioProfile->PtsFIFOCount;
			dcc_audio_profile.instance[i].InbandFIFOCount = pAudioProfile->InbandFIFOCount;

			dcc_audio_profile.instance[i].AudioEngineIndex = rmfp_audio_instances_profile.instance[i].engine_index;
			dcc_audio_profile.instance[i].AudioDecoderIndex = rmfp_audio_instances_profile.instance[i].decoder_index;
			dcc_audio_profile.instance[i].DemuxProgramID = rmfp_audio_instances_profile.instance[i].engine_index * 2;

		}

		dcc_audio_profile.number_of_instances = rmfp_audio_instances_profile.number_of_instances;

	}

	rmfp_print_dcc_audio_decoder_profile(&dcc_audio_profile);

	/* Get resources required */
	status = DCCGetMultipleAudioResourcesRequired(pHandle->profile.pDCC, &dcc_audio_profile, &dcc_audio_resources);
	if (status != RM_OK) {
		RMNOTIFY((NULL, status, "Cannot get required resources for multiple audio\n"));
		return status;
	}

	/* Fill rmfp resources profile */
	rmfp_audio_resources_profile.Version                = GET_VERSION_FROM_MAGIC(RMFP_AUDIO_RESOURCES_PROFILE_VERSION);
	rmfp_audio_resources_profile.STC_index              = pPlayOptions->STCIndex + pPlayOptions->STCEngine*3;
	rmfp_audio_resources_profile.number_of_instances    = dcc_audio_resources.number_of_instances;
	rmfp_audio_resources_profile.number_of_engines      = MAX_AUDIO_ENGINE_INSTANCES;

	for (i = 0; i < MAX_AUDIO_ENGINE_INSTANCES; i++) {
		rmfp_audio_resources_profile.engine[i].dram = pPlayOptions->DRAMIndex;

		rmfp_audio_resources_profile.engine[i].shared_memory_address = dcc_audio_resources.engine[i].DecoderSharedMemoryAddress;
		rmfp_audio_resources_profile.engine[i].shared_memory_size = dcc_audio_resources.engine[i].DecoderSharedMemorySize;
	}
	for (i = 0; i < dcc_audio_resources.number_of_instances; i++) {
		rmfp_audio_resources_profile.instance[i].dram = pPlayOptions->DRAMIndex;

		rmfp_audio_resources_profile.instance[i].protected_memory_address = dcc_audio_resources.instance[i].ProtectedMemoryAddress;
		rmfp_audio_resources_profile.instance[i].protected_memory_size = dcc_audio_resources.instance[i].ProtectedMemorySize;

		rmfp_audio_resources_profile.instance[i].unprotected_memory_address = dcc_audio_resources.instance[i].UnprotectedMemoryAddress;
		rmfp_audio_resources_profile.instance[i].unprotected_memory_size = dcc_audio_resources.instance[i].UnprotectedMemorySize;

		rmfp_audio_resources_profile.instance[i].engine_index = rmfp_audio_instances_profile.instance[i].engine_index;
		rmfp_audio_resources_profile.instance[i].decoder_index = rmfp_audio_instances_profile.instance[i].decoder_index;
	}

 	/* then present the resources profile to the application if the callback was defined */
	if (pHandle->profile.rmfp_audio_resources_callback) {
		status = pHandle->profile.rmfp_audio_resources_callback(pHandle->profile.callback_context, &rmfp_audio_resources_profile);
		if (status != RM_OK) {
			RMNOTIFY((NULL, status, "Failed to get resources from application\n"));
			return status;
		}
	}

	/*
	 * Check the parameters returned by the application.
	 * The application is allowed to change the audio engine repartition.
	 * If the engine memory allocation is not correct anymore, we need to recompute the needed dcc resources and recall the callback
	 */

	/* Update the DCC profile */
	for (i = 0; i < pAudioOptions->nb_audio_instances; i++) {
		dcc_audio_profile.instance[i].AudioEngineIndex = rmfp_audio_resources_profile.instance[i].engine_index;
		dcc_audio_profile.instance[i].AudioDecoderIndex = rmfp_audio_resources_profile.instance[i].decoder_index;
		dcc_audio_profile.instance[i].DemuxProgramID = rmfp_audio_resources_profile.instance[i].engine_index * 2;
	}

	/* Get resources required again */
	status = DCCGetMultipleAudioResourcesRequired(pHandle->profile.pDCC, &dcc_audio_profile, &dcc_audio_resources);
	if (status != RM_OK) {
		RMNOTIFY((NULL, status, "Cannot get required resources for multiple audio\n"));
		return status;
	}



 	/*
	 * then allocate the remaining resources and create an audio source
	 */
	for (i = 0; i < MAX_AUDIO_ENGINE_INSTANCES; i++) {
		RMuint32 engine_moduleID, dummy;

		/* Get corresponding engine module id */
		status = DCCGetAudioModuleIDsFromIndexes(pHandle->profile.pDCC, i, 0, &engine_moduleID, &dummy);
		if (status != RM_OK) {
			RMNOTIFY((NULL, status, "Can't set engine moduleID\n"));
			return status;
		}

		pHandle->audio_resources.engine[i].dram = rmfp_audio_resources_profile.engine[i].dram;

		/*
		 * Shared memory : this must be done only once per engine
		 */
		if ((!rmfp_audio_resources_profile.engine[i].shared_memory_address)
		    && (rmfp_audio_resources_profile.engine[i].shared_memory_size)) {
			RMuint32 addr;
			RMuint32 tag = RUA_ADDRESS_ID_TAG(RUA_ADDRESS_ID_AUDIO_DECODER_SHARED, engine_moduleID);

			addr = RUAGetAddressID(pHandle->profile.pRUA, tag);
			if (addr) {
				RMDBGLOG((ENABLE, "Found DecoderSharedMem by ID @ 0x%lx, reusing it\n", addr));

				shared_memory_address = addr;

				/* since both addr and size are set, then DCCOpenVideoSourceWithResources will use
				   RMMpegEnginePropertyID_DecoderSharedMemory to set the mem, just as if it had been
				   allocated here
				*/
			}
			else {


				shared_memory_address = DCCMalloc(pHandle->profile.pDCC,
								  rmfp_audio_resources_profile.engine[i].dram,
								  RUA_DRAM_UNCACHED,
								  rmfp_audio_resources_profile.engine[i].shared_memory_size);

				if (!shared_memory_address) {
					RMNOTIFY((NULL, RM_FATALOUTOFMEMORY, "Can't allocate %lu bytes in DRAM %lu\n",
						  rmfp_audio_resources_profile.engine[i].shared_memory_size,
						  pPlayOptions->DRAMIndex));

					return RM_FATALOUTOFMEMORY;
				}
				else
					RMDBGLOG((LOCALDBG, "Allocated %lu bytes for shared on engine %d\n", rmfp_audio_resources_profile.engine[i].shared_memory_size,i));


				// Free shared only if this instance allocated it
				pHandle->audio_resources.engine[i].free_shared = TRUE;

				// set ID so that other processes can find the memory
				status = RUASetAddressID(pHandle->profile.pRUA, shared_memory_address, tag);
				if (status != RM_OK) {
					RMNOTIFY((NULL, status, "Can't set addressID 0x%lx to address 0x%lx\n", tag, shared_memory_address));
					return status;
				}

				/* Acquire address so that it is not released from the RUA register table */
				status = RUAAcquireAddress(pHandle->profile.pRUA, shared_memory_address);
				if (status != RM_OK) {
					RMNOTIFY((NULL, status, "Can't acquire shared memory\n"));
					return status;
				}
			}
		}
		else {
			if (rmfp_audio_resources_profile.engine[i].shared_memory_address)
				RMDBGLOG((LOCALDBG, "Reusing DecoderSharedMem @ 0x%lx\n",
					  rmfp_audio_resources_profile.engine[i].shared_memory_address));

			shared_memory_address = rmfp_audio_resources_profile.engine[i].shared_memory_address;
		}

		RMDBGLOG((LOCALDBG, "Decoder Shared Memory: %lu bytes at %p\n",
			  rmfp_audio_resources_profile.engine[i].shared_memory_size,
			  shared_memory_address));


#if ALWAYS_TRY_TO_FREE_SHARED_MEMORY
		/* Try to free shared when exiting */
		pHandle->audio_resources.engine[i].free_shared = TRUE;
#endif


		if (rmfp_audio_resources_profile.engine[i].shared_memory_size) {
			struct AudioEngine_DecoderSharedMemory_type shared;

			/* Set shared memory (allocated by rmfp or application) */
			shared.Address = shared_memory_address;
			shared.Size = rmfp_audio_resources_profile.engine[i].shared_memory_size;

			status = RUASetProperty(pHandle->profile.pRUA, engine_moduleID, RMAudioEnginePropertyID_DecoderSharedMemory, &shared, sizeof(shared), 0);
			if (status != RM_OK) {
				RMNOTIFY((NULL, status, "Can't set sample decoder shared memory\n"));
				return status;
			}

			RMDBGLOG((LOCALDBG, "Set DecoderSharedMemory[%lu] EngineModuleID 0x%lx to address %p size %lu\n",
				  i,
				  engine_moduleID,
				  shared.Address,
				  shared.Size));
		}
	}

	for (i = 0; i < dcc_audio_resources.number_of_instances; i++) {
		pHandle->audio_resources.instance[i].dram = rmfp_audio_resources_profile.instance[i].dram;

		/*
		 * Protected memory
		 */
		if ((!rmfp_audio_resources_profile.instance[i].protected_memory_address)
		    &&
		    (rmfp_audio_resources_profile.instance[i].protected_memory_size)) {
			protected_memory_address = DCCMalloc(pHandle->profile.pDCC,
							     rmfp_audio_resources_profile.instance[i].dram,
							     RUA_DRAM_CACHED,
							     rmfp_audio_resources_profile.instance[i].protected_memory_size);

			if (!protected_memory_address) {
				RMNOTIFY((NULL, RM_FATALOUTOFMEMORY, "Can't allocate %lu bytes in DRAM %lu\n",
					rmfp_audio_resources_profile.instance[i].protected_memory_size,
					pPlayOptions->DRAMIndex));
				return RM_FATALOUTOFMEMORY;
			}
			else
				RMDBGLOG((LOCALDBG, "allocated %lu bytes for protected\n", rmfp_audio_resources_profile.instance[i].protected_memory_size));

			pHandle->audio_resources.instance[i].free_protected = TRUE;
		}
		else {
			protected_memory_address = rmfp_audio_resources_profile.instance[i].protected_memory_address;
			pHandle->audio_resources.instance[i].free_protected = FALSE;
		}

		dcc_audio_resources.instance[i].ProtectedMemoryAddress = protected_memory_address;
		dcc_audio_resources.instance[i].ProtectedMemorySize = rmfp_audio_resources_profile.instance[i].protected_memory_size;

		RMDBGLOG((LOCALDBG, "Protected Memory: %lu bytes at %p\n",
			  dcc_audio_resources.instance[i].ProtectedMemorySize,
			  dcc_audio_resources.instance[i].ProtectedMemoryAddress));

		/*
		 * Unprotected memory
		 */
		if ((!rmfp_audio_resources_profile.instance[i].unprotected_memory_address)
		    &&
		    (rmfp_audio_resources_profile.instance[i].unprotected_memory_size)) {
			unprotected_memory_address = DCCMalloc(pHandle->profile.pDCC,
							       rmfp_audio_resources_profile.instance[i].dram,
							       RUA_DRAM_UNCACHED,
							       rmfp_audio_resources_profile.instance[i].unprotected_memory_size);

			if (!unprotected_memory_address) {
				RMNOTIFY((NULL, RM_FATALOUTOFMEMORY, "Can't allocate %lu bytes in DRAM %lu\n",
					rmfp_audio_resources_profile.instance[i].unprotected_memory_size,
					pPlayOptions->DRAMIndex));
				return RM_FATALOUTOFMEMORY;
			}
			else
				RMDBGLOG((LOCALDBG, "allocated %lu bytes for unprotected\n", rmfp_audio_resources_profile.instance[i].unprotected_memory_size));

			pHandle->audio_resources.instance[i].free_unprotected = TRUE;
		}
		else {
			unprotected_memory_address = rmfp_audio_resources_profile.instance[i].unprotected_memory_address;
			pHandle->audio_resources.instance[i].free_unprotected = FALSE;
		}

		dcc_audio_resources.instance[i].UnprotectedMemoryAddress = unprotected_memory_address;
		dcc_audio_resources.instance[i].UnprotectedMemorySize = rmfp_audio_resources_profile.instance[i].unprotected_memory_size;

		RMDBGLOG((LOCALDBG, "Unprotected Memory: %lu bytes at %p\n",
			 dcc_audio_resources.instance[i].UnprotectedMemorySize,
			  dcc_audio_resources.instance[i].UnprotectedMemoryAddress));
	}

	/* Open decoder */
	status = DCCOpenMultipleAudioDecoderSourceWithResources(pHandle->profile.pDCC, &dcc_audio_profile, &dcc_audio_resources, &pDCCMultipleAudioSource);
	if (status != RM_OK) {
		RMNOTIFY((NULL, status, "error opening multiple audio sources\n"));
		return status;
	}

	pMultipleAudioSource->source = (void *)pDCCMultipleAudioSource;


	for(i = 0; i<dcc_audio_resources.number_of_instances; i++) {
		struct DCCAudioSourceHandle audioHandle;
		RMbool afs;
		struct AudioDecoder_AudioPlayTime_type audio_time_interval;


		status = DCCMultipleAudioSourceGetSingleDecoderHandleForInstance(pDCCMultipleAudioSource, i, &audioHandle);
		if (status != RM_OK) {
			RMNOTIFY((NULL, status, "error getting multiple audio instance\n"));
			return status;
		}

		status = rmfp_fill_output_options(pHandle, audioHandle.engineID, pAudioProfile);
		if (status != RM_OK) {
			RMNOTIFY((NULL, status, "error filling output options\n"));
			return status;
		}

		RMDBGLOG((LOCALDBG, "profile after retrieving options from engine\n"));
		rmfp_print_rmlibplay_audio_decoder_profile(pAudioProfile);

		RMDBGLOG((LOCALDBG, "setting codec %lu\n", pAudioProfile->Codec));

		leftTryTimes = 10;
		while(leftTryTimes--)
		{
			switch (pAudioProfile->Codec) {
			case AudioDecoder_Codec_AAC:
				status = DCCSetAudioAACFormat(audioHandle.pAudioSource, &pAudioProfile->params.AAC);
				break;
			case AudioDecoder_Codec_AC3:
				status = DCCSetAudioAc3Format(audioHandle.pAudioSource, &pAudioProfile->params.AC3);
				break;
			case AudioDecoder_Codec_VORBIS:
				status = DCCSetAudioVorbisFormat(audioHandle.pAudioSource, &pAudioProfile->params.VORBIS);
				break;
			case AudioDecoder_Codec_AG711:
				status = DCCSetAudioAG711Format(audioHandle.pAudioSource, &pAudioProfile->params.AG711);
				break;
			case AudioDecoder_Codec_BSAC:
				status = DCCSetAudioBSACFormat(audioHandle.pAudioSource, &pAudioProfile->params.BSAC);
				break;
			case AudioDecoder_Codec_DRA:
				status = DCCSetAudioDraFormat(audioHandle.pAudioSource, &pAudioProfile->params.DRA);
				break;
			case AudioDecoder_Codec_DTS:
				status = DCCSetAudioDtsFormat(audioHandle.pAudioSource, &pAudioProfile->params.DTS);
				break;
			case AudioDecoder_Codec_DTSLBR:
				status = DCCSetAudioDTSLBRFormat(audioHandle.pAudioSource, &pAudioProfile->params.DTSLBR);
				break;
			case AudioDecoder_Codec_DVDA:
				status = DCCSetAudioDVDAFormat(audioHandle.pAudioSource, &pAudioProfile->params.DVDA);
				break;
			case AudioDecoder_Codec_EXAC:
				status = DCCSetAudioExACFormat(audioHandle.pAudioSource, &pAudioProfile->params.EXAC);
				break;
			case AudioDecoder_Codec_FLAC:
				status = DCCSetAudioFlacFormat(audioHandle.pAudioSource, &pAudioProfile->params.FLAC);
				break;
			case AudioDecoder_Codec_MPEG1:
				status = DCCSetAudioMpegFormat(audioHandle.pAudioSource, &pAudioProfile->params.MPEG);
				break;
			case AudioDecoder_Codec_PCM:

				switch (pAudioProfile->SubCodec) {
				case 0:
					status = DCCSetAudioPcmCdaFormat(audioHandle.pAudioSource, &pAudioProfile->params.PCMCDA);
					break;
				case 1:
					status = DCCSetAudioLpcmVobFormat(audioHandle.pAudioSource, &pAudioProfile->params.LPCMVOB);
					break;
				case 2:
					status = DCCSetAudioLpcmAobFormat(audioHandle.pAudioSource, &pAudioProfile->params.LPCMAOB);
					break;
				case 3:
					status = DCCSetAudioLpcmBDFormat(audioHandle.pAudioSource, &pAudioProfile->params.LPCMBD);
					break;
				case 4:
					status = DCCSetAudioLpcmWFAFormat(audioHandle.pAudioSource, &pAudioProfile->params.LPCMWFA);
					break;
				default:
#if 0
					// this shouldn't exist, all codecs should be handled
					{
						struct DCCAudioDecoderFormat audio_format;
						audio_format.Codec = pAudioProfile->Codec;
						status = DCCSetAudioDecoderSourceFormat(audioHandle.pAudioSource, &audio_format);
						break;
					}
#else
					RMNOTIFY((NULL, RM_ERROR, "unknown codec\n"));
					return RM_ERROR;
#endif
				}
				break;
			case AudioDecoder_Codec_ADPCM:
				status = DCCSetAudioAdpcmFormat(audioHandle.pAudioSource, &pAudioProfile->params.ADPCM);
				break;
			case AudioDecoder_Codec_WMA:
			case AudioDecoder_Codec_WMAPRO:
				status = DCCSetAudioWMAFormat(audioHandle.pAudioSource, &pAudioProfile->params.WMA);
				break;
			default:
#if 0
				// this shouldn't exist, all codecs should be handled
				{
					struct DCCAudioDecoderFormat audio_format;
					audio_format.Codec = pAudioProfile->Codec;
					status = DCCSetAudioDecoderSourceFormat(audioHandle.pAudioSource, &audio_format);
					break;
				}
#else
				RMNOTIFY((NULL, RM_ERROR, "unknown codec\n"));
				return RM_ERROR;
#endif
			}
			if(RMSUCCEEDED(status))
			{
				break;
			}
			else if(RM_PENDING == status)
			{
				usleep(10*1000);
			}
			else	//other errors
			{
				break;
			}
		}

		if (status != RM_OK) {
			RMNOTIFY((NULL, status, "Couldn't setup audio codec parameters\n"));
			return status;
		}



		if (pAudioOptions->afs) {
			RMDBGLOG((LOCALDBG, "SampleRate detected by microcode\n"));
		} else {
			RMDBGLOG((LOCALDBG, "SampleRate forced\n"));
		}

		status = RUASetProperty(pHandle->profile.pRUA, audioHandle.engineID, RMAudioEnginePropertyID_SampleFrequencyFromStream, &(pAudioOptions->afs), sizeof(pAudioOptions->afs), 0);
		if (status != RM_OK)
			RMNOTIFY((NULL, status, "Can't set sample rate from stream property\n"));


		audio_time_interval.PlayMode = Audio_Play_Disable;
		audio_time_interval.PlayStartPTS = 0;
		audio_time_interval.PlayEndPTS = 0;

		status = RUASetProperty(pHandle->profile.pRUA, audioHandle.moduleID, RMAudioDecoderPropertyID_AudioPlayTime, &audio_time_interval, sizeof(audio_time_interval), 0);
		if (status != RM_OK) {
			RMNOTIFY((NULL, status, "Cannot set audio play time\n"));
		}

		/* enable sync to stc according to sync_stc */
		status = RUASetProperty(pHandle->profile.pRUA, audioHandle.moduleID, RMAudioDecoderPropertyID_SyncSTCEnable,
					&pAudioOptions->sync_stc, sizeof(pAudioOptions->sync_stc), 0);
		if (status != RM_OK) {
			RMNOTIFY((NULL, status, "cannot  enable sync audio to stc! %s\n", RMstatusToString(status)));
		}
	}

	// we need to store the profile because we need it to do the update of the outport mode
	pMultipleAudioSource->Profile = *pAudioProfile;

	return status;
}


RMstatus rmfp_internal_release_audio_decoder_handler(void *pContext, struct RMLibPlayMultipleAudioSource *pAudioSource)
{
	struct RMFPHandle *pHandle = NULL;
	struct DCCMultipleAudioSource *pDCCMultipleAudioSource = NULL;
	struct RMFPPlayOptions *pPlayOptions = NULL;
	struct DCCXMultipleAudioResources dcc_audio_resources = {0, };
	struct RMFPMultipleAudioResourcesProfile rmfp_audio_resources_profile;
	RMstatus status;
	RMuint32 i;
	struct DCCAudioSourceHandle audioHandle[MAX_AUDIO_DECODER_INSTANCES];

	RMDBGLOG((LOCALDBG, "rmfp_release_audio_decoder()\n"));

	ASSERT_NULL_POINTER(pContext);
	ASSERT_NULL_POINTER(pAudioSource);

	pHandle = (struct RMFPHandle *)pContext;
	pDCCMultipleAudioSource = (struct DCCMultipleAudioSource *)pAudioSource->source;
	pPlayOptions = &(pHandle->playback_options);

	/* Stop decoders */
	status = DCCStopMultipleAudioSource(pDCCMultipleAudioSource);
	if (status != RM_OK)
		RMNOTIFY((NULL, status, "Failed to get stop audio decoders but close the audio decoder anyway\n"));

	/* Get resources */
	status = DCCGetMultipleAudioDecoderResources(pDCCMultipleAudioSource, &dcc_audio_resources);
	if (status != RM_OK)
		RMNOTIFY((NULL, status, "Failed to get audio resources to free but close the audio decoder anyway\n"));

	/* Get all instances before closing the decoder */
	for (i = 0; i < dcc_audio_resources.number_of_instances; i++) {

		/* Get indexes */
		status = DCCMultipleAudioSourceGetSingleDecoderHandleForInstance(pDCCMultipleAudioSource, i, &audioHandle[i]);
		if (status != RM_OK)
			return status;
	}

	/* Close decoder */
	status = DCCXCloseMultipleAudioSource(pDCCMultipleAudioSource);
	if (status != RM_OK)
		RMNOTIFY((NULL, status, "Failed to close audio decoder but continue to release the resources\n"));

	/* Free everything allocated in RMFP */
	for (i = 0; i < MAX_AUDIO_ENGINE_INSTANCES; i++) {
		if (pHandle->audio_resources.engine[i].free_shared) {
			RMuint32 engine_moduleID, dummy;
			struct AudioEngine_DecoderSharedMemory_type shared;
			RMuint32 address;

			/* Get corresponding engine module id */
			status = DCCGetAudioModuleIDsFromIndexes(pHandle->profile.pDCC, i, 0, &engine_moduleID, &dummy);
			if (status != RM_OK) {
				RMNOTIFY((NULL, status, "Can't set engine moduleID\n"));
				return status;
			}

			status = RUAGetProperty(pHandle->profile.pRUA, engine_moduleID, RMAudioEnginePropertyID_DecoderSharedMemory, &shared, sizeof(shared));
			if (status != RM_OK) {
				RMNOTIFY((NULL, status, "Cannot get DecoderSharedMemory0\n"));
				return status;
			}

			if (shared.Address) {
				RMuint32 connected_task_count;

				address = shared.Address;


				/* Get count of task still using this memory */
				status = RUAGetProperty(pHandle->profile.pRUA,
							engine_moduleID,
							RMAudioEnginePropertyID_ConnectedTaskCount,
							&connected_task_count,
							sizeof(connected_task_count));
				if (status != RM_OK) {
					RMNOTIFY((NULL, status, "Cannot get RMAudioEnginePropertyID_ConnectedTaskCount %lu\n", engine_moduleID));
					return status;
				}

				if (connected_task_count == 0) {

					/* Release address */
					status = RUAReleaseAddress(pHandle->profile.pRUA, address);
					if (status != RM_OK) {
						RMNOTIFY((NULL, status, "Can't release shared memory\n"));
						return status;
					}

					// reset ID because we'll free the mem
					status = RUASetAddressID(pHandle->profile.pRUA, address, 0);
					if (status != RM_OK) {
						RMNOTIFY((NULL, status, "Can't reset addressID for address 0x%lx\n", address));
						return status;
					}


					/* Set to 0 */
					shared.Address = 0;
					shared.Size = 0;
					status = RUASetProperty(pHandle->profile.pRUA,
								engine_moduleID,
								RMAudioEnginePropertyID_DecoderSharedMemory,
								&shared,
								sizeof(shared),
								0);
					if (status != RM_OK) {
						RMNOTIFY((NULL, status, "RMAudioEnginePropertyID_DecoderSharedMemory\n"));
						return status;
					}

					/* Now free the address */
					DCCFree(pHandle->profile.pDCC, address);

					RMDBGLOG((LOCALDBG, "Free audio shared memory at %p\n", address));
				}
				else
					RMDBGLOG((ENABLE, "Don't free %lx_AUDIO shared memory. There are still %lx audio tasks opened. \n", i, connected_task_count));

			}
		}
	}
	for (i = 0; i < dcc_audio_resources.number_of_instances; i++) {
		if (pHandle->audio_resources.instance[i].free_protected) {
			RMDBGLOG((LOCALDBG, "Free audio protected memory at %p\n", dcc_audio_resources.instance[i].ProtectedMemoryAddress));
			DCCFree(pHandle->profile.pDCC, dcc_audio_resources.instance[i].ProtectedMemoryAddress);
		}

		if (pHandle->audio_resources.instance[i].free_unprotected) {
			RMDBGLOG((LOCALDBG, "Free audio unprotected memory at %p\n", dcc_audio_resources.instance[i].UnprotectedMemoryAddress));
			DCCFree(pHandle->profile.pDCC, dcc_audio_resources.instance[i].UnprotectedMemoryAddress);
		}
	}

	/*
	 * Application must free its own allocation
	 */

	/* Fill rmfp resources profile */
	rmfp_audio_resources_profile.Version                = GET_VERSION_FROM_MAGIC(RMFP_AUDIO_RESOURCES_PROFILE_VERSION);

	rmfp_audio_resources_profile.STC_index              = pPlayOptions->STCIndex + pPlayOptions->STCEngine*3;
	rmfp_audio_resources_profile.number_of_instances    = dcc_audio_resources.number_of_instances;
	rmfp_audio_resources_profile.number_of_engines      = MAX_AUDIO_ENGINE_INSTANCES;

	if (pHandle->profile.rmfp_release_audio_resources_callback) {
		for (i = 0; i < MAX_AUDIO_ENGINE_INSTANCES; i++) {
			rmfp_audio_resources_profile.engine[i].dram = pHandle->audio_resources.engine[i].dram;
			rmfp_audio_resources_profile.engine[i].shared_memory_address = dcc_audio_resources.engine[i].DecoderSharedMemoryAddress;
			rmfp_audio_resources_profile.engine[i].shared_memory_size = dcc_audio_resources.engine[i].DecoderSharedMemorySize;
		}
		for (i = 0; i < dcc_audio_resources.number_of_instances; i++) {
			rmfp_audio_resources_profile.instance[i].dram = pHandle->audio_resources.instance[i].dram;

			rmfp_audio_resources_profile.instance[i].protected_memory_address = dcc_audio_resources.instance[i].ProtectedMemoryAddress;
			rmfp_audio_resources_profile.instance[i].protected_memory_size = dcc_audio_resources.instance[i].ProtectedMemorySize;

			rmfp_audio_resources_profile.instance[i].unprotected_memory_address = dcc_audio_resources.instance[i].UnprotectedMemoryAddress;
			rmfp_audio_resources_profile.instance[i].unprotected_memory_size = dcc_audio_resources.instance[i].UnprotectedMemorySize;

			rmfp_audio_resources_profile.instance[i].engine_index = audioHandle[i].engineIndex;
			rmfp_audio_resources_profile.instance[i].decoder_index = audioHandle[i].moduleIndex;
		}

		status = pHandle->profile.rmfp_release_audio_resources_callback(pHandle->profile.callback_context, &rmfp_audio_resources_profile);
		if (status != RM_OK) {
			RMNOTIFY((NULL, status, "The application failed to release the resources\n"));
			return status;
		}
	}

	return RM_OK;
}


RMstatus rmfp_internal_update_audio_decoder_outport(void *pContext, struct RMLibPlayMultipleAudioSource *pMultipleAudioSource, RMuint32 ModuleID)
{
	struct RMFPHandle *pHandle = NULL;
	RMstatus status = RM_OK;
	struct DCCAudioSourceHandle audioHandle;
	RMuint32 instances, i;
	struct RMLibPlayAudioProfile *pAudioProfile = NULL;

	RMDBGLOG((ENABLE, "rmfp_internal_update_audio_decoder_outport(ModuleID 0x%lx)\n", ModuleID));

	ASSERT_NULL_POINTER(pContext);
	ASSERT_NULL_POINTER(pMultipleAudioSource);
	ASSERT_NULL_POINTER(pMultipleAudioSource->source);


	pHandle = (struct RMFPHandle *)pContext;
	pAudioProfile = &(pMultipleAudioSource->Profile);

	status = DCCMultipleAudioSourceGetNumberOfInstances(pMultipleAudioSource->source, &instances);
	if (status != RM_OK)
		goto exit;


	for (i = 0; i < instances; i++) {

		status = DCCMultipleAudioSourceGetSingleDecoderHandleForInstance(pMultipleAudioSource->source, i, &audioHandle);
		if (status != RM_OK) {
			RMNOTIFY((NULL, status, "error getting multiple audio instance\n"));
			goto exit;
		}

		if (audioHandle.moduleID == ModuleID) {
			RMDBGLOG((ENABLE, "Update instance %lu\n", i));
			break;
		}
	}

	if (i == instances) {
		status = RM_NOT_FOUND;
		RMNOTIFY((NULL, status, "Couldn't find instance for moduleID 0x%lx\n", ModuleID));
		goto exit;
	}


	status = rmfp_fill_output_options(pHandle, audioHandle.engineID, pAudioProfile);
	if (status != RM_OK) {
		RMNOTIFY((NULL, status, "error filling outport mode from engine 0x%lx\n", audioHandle.engineID));
		goto exit;
	}

	rmfp_print_rmlibplay_audio_decoder_profile(pAudioProfile);

	switch (pMultipleAudioSource->Profile.Codec) {
	case AudioDecoder_Codec_AAC:
		status = RUASetProperty(pHandle->profile.pRUA,
					ModuleID,
					RMAudioDecoderPropertyID_AACParameters,
					&(pAudioProfile->params.AAC), sizeof(struct AudioDecoder_AACParameters_type), 0);
		break;
	case AudioDecoder_Codec_AC3:
		status = RUASetProperty(pHandle->profile.pRUA,
					ModuleID,
					RMAudioDecoderPropertyID_Ac3Parameters,
					&(pAudioProfile->params.AC3), sizeof(struct AudioDecoder_Ac3Parameters_type), 0);
		break;
	case AudioDecoder_Codec_AG711:
		status = RUASetProperty(pHandle->profile.pRUA,
					ModuleID,
					RMAudioDecoderPropertyID_AG711Parameters,
					&(pAudioProfile->params.AG711), sizeof(struct AudioDecoder_AG711Parameters_type), 0);
		break;
	case AudioDecoder_Codec_BSAC:
		status = RUASetProperty(pHandle->profile.pRUA,
					ModuleID,
					RMAudioDecoderPropertyID_BSACParameters,
					&(pAudioProfile->params.BSAC), sizeof(struct AudioDecoder_BSACParameters_type), 0);
		break;
	case AudioDecoder_Codec_DRA:
		status = RUASetProperty(pHandle->profile.pRUA,
					ModuleID,
					RMAudioDecoderPropertyID_DraParameters,
					&(pAudioProfile->params.DRA), sizeof(struct AudioDecoder_DraParameters_type), 0);
		break;
	case AudioDecoder_Codec_DTS:
		status = RUASetProperty(pHandle->profile.pRUA,
					ModuleID,
					RMAudioDecoderPropertyID_DtsParameters,
					&(pAudioProfile->params.DTS), sizeof(struct AudioDecoder_DtsParameters_type), 0);
		break;
	case AudioDecoder_Codec_DTSLBR:
		status = RUASetProperty(pHandle->profile.pRUA,
					ModuleID,
					RMAudioDecoderPropertyID_DtslbrParameters,
					&(pAudioProfile->params.DTSLBR), sizeof(struct AudioDecoder_DtslbrParameters_type), 0);
		break;
	case AudioDecoder_Codec_DVDA:
		status = RUASetProperty(pHandle->profile.pRUA,
					ModuleID,
					RMAudioDecoderPropertyID_DVDAParameters,
					&(pAudioProfile->params.DVDA), sizeof(struct AudioDecoder_DVDAParameters_type), 0);

		break;
	case AudioDecoder_Codec_EXAC:
		status = RUASetProperty(pHandle->profile.pRUA,
					ModuleID,
					RMAudioDecoderPropertyID_ExACParameters,
					&(pAudioProfile->params.EXAC), sizeof(struct AudioDecoder_ExACParameters_type), 0);
		break;
	case AudioDecoder_Codec_FLAC:
		status = RUASetProperty(pHandle->profile.pRUA,
					ModuleID,
					RMAudioDecoderPropertyID_FlacParameters,
					&(pAudioProfile->params.FLAC), sizeof(struct AudioDecoder_FlacParameters_type), 0);
		break;
	case AudioDecoder_Codec_MPEG1:
		status = RUASetProperty(pHandle->profile.pRUA,
					ModuleID,
					RMAudioDecoderPropertyID_MpegParameters,
					&(pAudioProfile->params.MPEG), sizeof(struct AudioDecoder_MpegParameters_type), 0);
		break;
	case AudioDecoder_Codec_PCM:

		switch (pAudioProfile->SubCodec){
		case 0:
			status = RUASetProperty(pHandle->profile.pRUA,
						ModuleID,
						RMAudioDecoderPropertyID_PcmCdaParameters,
						&(pAudioProfile->params.PCMCDA), sizeof(struct AudioDecoder_PcmCdaParameters_type), 0);
			break;
		case 1:
			status = RUASetProperty(pHandle->profile.pRUA,
						ModuleID,
						RMAudioDecoderPropertyID_LpcmVobParameters,
						&(pAudioProfile->params.LPCMVOB), sizeof(struct AudioDecoder_LpcmVobParameters_type), 0);
			break;
		case 2:
			status = RUASetProperty(pHandle->profile.pRUA,
						ModuleID,
						RMAudioDecoderPropertyID_LpcmAobParameters,
						&(pAudioProfile->params.LPCMAOB), sizeof(struct AudioDecoder_LpcmAobParameters_type), 0);
			break;
		case 3:
			status = RUASetProperty(pHandle->profile.pRUA,
						ModuleID,
						RMAudioDecoderPropertyID_LpcmBDParameters,
						&(pAudioProfile->params.LPCMBD), sizeof(struct AudioDecoder_LpcmBDParameters_type), 0);
			break;
		case 4:
			status = RUASetProperty(pHandle->profile.pRUA,
						ModuleID,
						RMAudioDecoderPropertyID_LpcmWFAParameters,
						&(pAudioProfile->params.LPCMWFA), sizeof(struct AudioDecoder_LpcmWFAParameters_type), 0);
			break;
		default:
			// this shouldn't exist, all codecs should be handled
			RMNOTIFY((NULL, RM_ERROR, "unknown codec\n"));
			return RM_ERROR;
		}
		break;
	case AudioDecoder_Codec_VORBIS:
		status = RUASetProperty(pHandle->profile.pRUA,
					ModuleID,
					RMAudioDecoderPropertyID_VorbisParameters,
					&(pAudioProfile->params.VORBIS), sizeof(struct AudioDecoder_VorbisParameters_type), 0);
		break;
	case AudioDecoder_Codec_WMA:
	case AudioDecoder_Codec_WMAPRO:
		status = RUASetProperty(pHandle->profile.pRUA,
					ModuleID,
					RMAudioDecoderPropertyID_WMAParameters,
					&(pAudioProfile->params.WMA), sizeof(struct AudioDecoder_WMAParameters_type), 0);
		break;
	default:
		// this shouldn't exist, all codecs should be handled
		RMNOTIFY((NULL, RM_ERROR, "unknown codec\n"));
		return RM_ERROR;

	}

	if (status != RM_OK)
		RMNOTIFY((NULL, status, "Couldn't setup audio codec parameters\n"));

exit:

	return status;

}

static RMstatus rmfp_fill_profile_with_options(struct RMFPAudioOptions *pAudioOptions, struct RMLibPlayAudioProfile *pAudioProfile)
{

	ASSERT_NULL_POINTER(pAudioOptions);
	ASSERT_NULL_POINTER(pAudioProfile);

	RMDBGLOG((LOCALDBG, "filling profile with audio options\n"));


	switch(pAudioProfile->Codec) {
	case AudioDecoder_Codec_AAC:
		pAudioProfile->params.AAC.Acmod2DualMode    = pAudioOptions->Acmod2DualMode;

		break;
	case AudioDecoder_Codec_AC3:
		pAudioProfile->params.AC3.CompMode          = pAudioOptions->CompMode;
		pAudioProfile->params.AC3.DynScaleHi        = pAudioOptions->DynScaleHi;
		pAudioProfile->params.AC3.DynScaleLo        = pAudioOptions->DynScaleLo;
		pAudioProfile->params.AC3.PcmScale          = pAudioOptions->PcmScale;
		pAudioProfile->params.AC3.Acmod2DualMode    = pAudioOptions->Acmod2DualMode;


		break;
	case AudioDecoder_Codec_AG711:
		//pAudioProfile->params.AG711.CodingMode      = pAudioProfile->SubCodec;


		break;
	case AudioDecoder_Codec_BSAC:
		//pAudioProfile->params.BSAC.InputFormat      = pAudioProfile->SubCodec;


		break;
	case AudioDecoder_Codec_DRA:
		RMDBGLOG((ENABLE, "DRA doesn't seem to have cmdline parameters to apply\n"));


		break;
	case AudioDecoder_Codec_DTS:
		pAudioProfile->params.DTS.dts_CD            = pAudioOptions->DTS_CD;


		break;
	case AudioDecoder_Codec_DTSLBR:
		RMDBGLOG((ENABLE, "DTSLBR doesn't seem to have cmdline parameters to apply\n"));


		break;
	case AudioDecoder_Codec_DVDA:
		pAudioProfile->params.DVDA.Chconfig         = pAudioOptions->chconfig;
		pAudioProfile->params.DVDA.DRCenable        = pAudioOptions->drcenable;
		pAudioProfile->params.DVDA.DRCboost         = pAudioOptions->drcboost;
		pAudioProfile->params.DVDA.DRCcut           = pAudioOptions->drccut;
		pAudioProfile->params.DVDA.DRCdialref       = pAudioOptions->drcdialref;
		pAudioProfile->params.DVDA.Lossless         = pAudioOptions->lossless;


		break;
	case AudioDecoder_Codec_EXAC:
		RMDBGLOG((ENABLE, "EXAC doesn't seem to have cmdline parameters to apply\n"));


		break;
	case AudioDecoder_Codec_FLAC:
		RMDBGLOG((ENABLE, "FLAC doesn't seem to have cmdline parameters to apply\n"));


		break;
	case AudioDecoder_Codec_MPEG1:
		pAudioProfile->params.MPEG.Acmod2DualMode   = pAudioOptions->Acmod2DualMode;


		break;
	case AudioDecoder_Codec_PCM:
		switch (pAudioProfile->SubCodec){
		case 0:

			if (pAudioOptions->ChannelAssign)
				pAudioProfile->params.PCMCDA.ChannelAssign = pAudioOptions->ChannelAssign;


			break;
		case 1:

			if (pAudioOptions->ChannelAssign)
				pAudioProfile->params.LPCMVOB.ChannelAssign = pAudioOptions->ChannelAssign;


			pAudioProfile->params.LPCMVOB.DownMix           = FALSE;


			RMMemset(pAudioProfile->params.LPCMVOB.CoefLR, 0, sizeof(pAudioProfile->params.LPCMVOB.CoefLR));

			break;
		case 2:

			if (pAudioOptions->ChannelAssign)
				pAudioProfile->params.LPCMAOB.ChannelAssign = pAudioOptions->ChannelAssign;


			pAudioProfile->params.LPCMAOB.SamplingFrequencyGroup2 = 0;
			pAudioProfile->params.LPCMAOB.BitsPerSampleGroup2     = 0;

			pAudioProfile->params.LPCMAOB.DownSample              = pAudioOptions->DownSample;
			pAudioProfile->params.LPCMAOB.DownMix                 = FALSE;


			RMMemset(pAudioProfile->params.LPCMAOB.CoefLR, 0, sizeof(pAudioProfile->params.LPCMAOB.CoefLR));

			break;
		case 3:

			if (pAudioOptions->ChannelAssign)
				pAudioProfile->params.LPCMBD.ChannelAssign = pAudioOptions->ChannelAssign;

			break;
		case 4:

			if (pAudioOptions->ChannelAssign)
				pAudioProfile->params.LPCMBD.ChannelAssign = pAudioOptions->ChannelAssign;

			break;
		default:
			// this shouldn't exist, all codecs should be handled
			break;
		}
		break;
	case AudioDecoder_Codec_ADPCM:

		RMDBGLOG((ENABLE, "ADPCM doesn't seem to have cmdline parameters to apply\n"));
		if (pAudioOptions->ChannelAssign)
			pAudioProfile->params.ADPCM.ChannelAssign = pAudioOptions->ChannelAssign;

		break;
	case AudioDecoder_Codec_TTONE:
		RMDBGLOG((ENABLE, "TTONE doesn't seem to have cmdline parameters to apply\n"));

		break;

	case AudioDecoder_Codec_VORBIS:
		RMDBGLOG((ENABLE, "Vorbis doesn't seem to have cmdline parameters to apply\n"));

		break;

	case AudioDecoder_Codec_WMAPRO:
	case AudioDecoder_Codec_WMA:


		RMMemset(pAudioProfile->params.WMA.DownMixCoef, 0, sizeof(pAudioProfile->params.WMA.DownMixCoef));

		break;

	default:
		// this shouldn't exist, all codecs should be handled
		RMDBGLOG((ENABLE, "Generic audio format??\n"));
		break;
	}

	return RM_OK;

}

struct speaker_config_conversion_entry {
	enum AudioOutputChannels_type SpeakerConfig;
	RMuint32 DVDA_ChConfig;
};

static struct speaker_config_conversion_entry speaker_config_conversion_table[] = {
	{ Audio_Out_Ch_C,             2, },
	{ Audio_Out_Ch_LR,            2, },
	{ Audio_Out_Ch_LCR,           6, },
	{ Audio_Out_Ch_LRS,           6, },
	{ Audio_Out_Ch_LCRS,          6, },
	{ Audio_Out_Ch_LRLsRs,        6, },
	{ Audio_Out_Ch_LCRLsRs,       6, },
	{ Audio_Out_Ch_LCRLsRsSs,     8, },
	{ Audio_Out_Ch_LRLsRsLssRss,  8, },
	{ Audio_Out_Ch_LCRLsRsLssRss, 8, },
};



/*
   this function will be deprecated soon, once all these options are set directly to the engine
 */
static RMstatus rmfp_fill_output_options(struct RMFPHandle *pHandle, RMuint32 EngineModuleID, struct RMLibPlayAudioProfile *pAudioProfile)
{
	RMstatus status;
	struct AudioEngine_StoreOutputMode_type StoredOutputMode = { 0, };

	ASSERT_NULL_POINTER(pHandle);
	ASSERT_NULL_POINTER(pAudioProfile);

	RMDBGLOG((LOCALDBG, "filling profile with audio output options retrived from the engine\n"));

	status = RUAGetProperty(pHandle->profile.pRUA,
				EngineModuleID,
				RMAudioEnginePropertyID_StoreOutputMode,
				&StoredOutputMode,
				sizeof(StoredOutputMode));

	if (status != RM_OK) {
		RMNOTIFY((NULL, status, "failed to get engine output options!\n"));
		return status;
	}

	PRINT_UINT32_VARIABLE(StoredOutputMode.SpeakerConfig);
	PRINT_UINT32_VARIABLE(StoredOutputMode.SPDIF);
	PRINT_UINT32_VARIABLE(StoredOutputMode.DualMode);
	PRINT_UINT32_VARIABLE(StoredOutputMode.LFE);
	PRINT_UINT32_VARIABLE(StoredOutputMode.BassMode);
	PRINT_UINT32_VARIABLE(StoredOutputMode.Surround20);


	switch(pAudioProfile->Codec) {
	case AudioDecoder_Codec_AAC:

		pAudioProfile->params.AAC.OutputChannels    = StoredOutputMode.SpeakerConfig;
		pAudioProfile->params.AAC.OutputSpdif       = StoredOutputMode.SPDIF;
		pAudioProfile->params.AAC.OutputDualMode    = StoredOutputMode.DualMode;
		pAudioProfile->params.AAC.OutputLfe         = StoredOutputMode.LFE;
		pAudioProfile->params.AAC.BassMode          = StoredOutputMode.BassMode;
		pAudioProfile->params.AAC.OutputSurround20  = StoredOutputMode.Surround20;

		break;
	case AudioDecoder_Codec_AC3:

		pAudioProfile->params.AC3.OutputChannels    = StoredOutputMode.SpeakerConfig;
		pAudioProfile->params.AC3.OutputSpdif       = StoredOutputMode.SPDIF;
		pAudioProfile->params.AC3.OutputDualMode    = StoredOutputMode.DualMode;
		pAudioProfile->params.AC3.OutputLfe         = StoredOutputMode.LFE;
		pAudioProfile->params.AC3.BassMode          = StoredOutputMode.BassMode;
		pAudioProfile->params.AC3.OutputSurround20  = StoredOutputMode.Surround20;
		break;
	case AudioDecoder_Codec_AG711:

		pAudioProfile->params.AG711.OutputChannels   = StoredOutputMode.SpeakerConfig;
		pAudioProfile->params.AG711.OutputSpdif      = StoredOutputMode.SPDIF;
		pAudioProfile->params.AG711.OutputDualMode   = StoredOutputMode.DualMode;
		pAudioProfile->params.AG711.OutputLfe        = StoredOutputMode.LFE;
		pAudioProfile->params.AG711.BassMode         = StoredOutputMode.BassMode;
		pAudioProfile->params.AG711.OutputSurround20 = StoredOutputMode.Surround20;

		break;
	case AudioDecoder_Codec_BSAC:

		pAudioProfile->params.BSAC.OutputChannels   = StoredOutputMode.SpeakerConfig;
		pAudioProfile->params.BSAC.OutputSpdif      = StoredOutputMode.SPDIF;
		pAudioProfile->params.BSAC.OutputDualMode   = StoredOutputMode.DualMode;
		pAudioProfile->params.BSAC.OutputLfe        = StoredOutputMode.LFE;
		pAudioProfile->params.BSAC.BassMode         = StoredOutputMode.BassMode;
		pAudioProfile->params.BSAC.OutputSurround20 = StoredOutputMode.Surround20;

		break;
	case AudioDecoder_Codec_DRA:

		pAudioProfile->params.DRA.OutputChannels    = StoredOutputMode.SpeakerConfig;
		pAudioProfile->params.DRA.OutputSpdif       = StoredOutputMode.SPDIF;
		pAudioProfile->params.DRA.OutputDualMode    = StoredOutputMode.DualMode;
		pAudioProfile->params.DRA.OutputLfe         = StoredOutputMode.LFE;
		pAudioProfile->params.DRA.BassMode          = StoredOutputMode.BassMode;
		pAudioProfile->params.DRA.OutputSurround20  = StoredOutputMode.Surround20;

		break;
	case AudioDecoder_Codec_DTS:

		pAudioProfile->params.DTS.OutputChannels    = StoredOutputMode.SpeakerConfig;
		pAudioProfile->params.DTS.OutputSpdif       = StoredOutputMode.SPDIF;
		pAudioProfile->params.DTS.OutputDualMode    = StoredOutputMode.DualMode;
		pAudioProfile->params.DTS.OutputLfe         = StoredOutputMode.LFE;
		pAudioProfile->params.DTS.BassMode          = StoredOutputMode.BassMode;
		pAudioProfile->params.DTS.OutputSurround20  = StoredOutputMode.Surround20;

		break;
	case AudioDecoder_Codec_DTSLBR:

		pAudioProfile->params.DTSLBR.OutputChannels    = StoredOutputMode.SpeakerConfig;
		pAudioProfile->params.DTSLBR.OutputSpdif       = StoredOutputMode.SPDIF;
		pAudioProfile->params.DTSLBR.OutputDualMode    = StoredOutputMode.DualMode;
		pAudioProfile->params.DTSLBR.OutputLfe         = StoredOutputMode.LFE;
		pAudioProfile->params.DTSLBR.BassMode          = StoredOutputMode.BassMode;
		pAudioProfile->params.DTSLBR.OutputSurround20  = StoredOutputMode.Surround20;

		break;
	case AudioDecoder_Codec_DVDA:

	{
		RMuint32 j;
		RMuint32 NumberOfEntries = sizeof(speaker_config_conversion_table) / sizeof(struct speaker_config_conversion_entry);

		for (j = 0; j < NumberOfEntries; j++) {
			if (StoredOutputMode.SpeakerConfig == speaker_config_conversion_table[j].SpeakerConfig) {
				pAudioProfile->params.DVDA.Chconfig = speaker_config_conversion_table[j].DVDA_ChConfig;
				RMDBGLOG((LOCALDBG, "set chconfig to %lu\n", pAudioProfile->params.DVDA.Chconfig));
				break;
			}
		}
	}

		pAudioProfile->params.DVDA.OutputChannels   = StoredOutputMode.SpeakerConfig;
		pAudioProfile->params.DVDA.OutputSpdif      = StoredOutputMode.SPDIF;
		pAudioProfile->params.DVDA.OutputDualMode   = StoredOutputMode.DualMode;
		pAudioProfile->params.DVDA.OutputLfe        = StoredOutputMode.LFE;
		pAudioProfile->params.DVDA.BassMode         = StoredOutputMode.BassMode;
		pAudioProfile->params.DVDA.OutputSurround20 = StoredOutputMode.Surround20;

		break;
	case AudioDecoder_Codec_EXAC:

		pAudioProfile->params.EXAC.OutputChannels   = StoredOutputMode.SpeakerConfig;
		pAudioProfile->params.EXAC.OutputSpdif      = StoredOutputMode.SPDIF;
		pAudioProfile->params.EXAC.OutputDualMode   = StoredOutputMode.DualMode;
		pAudioProfile->params.EXAC.OutputLfe        = StoredOutputMode.LFE;
		pAudioProfile->params.EXAC.BassMode         = StoredOutputMode.BassMode;
		pAudioProfile->params.EXAC.OutputSurround20 = StoredOutputMode.Surround20;

		break;
	case AudioDecoder_Codec_FLAC:

		pAudioProfile->params.FLAC.OutputChannels    = StoredOutputMode.SpeakerConfig;
		pAudioProfile->params.FLAC.OutputSpdif       = StoredOutputMode.SPDIF;
		pAudioProfile->params.FLAC.OutputDualMode    = StoredOutputMode.DualMode;
		pAudioProfile->params.FLAC.OutputLfe         = StoredOutputMode.LFE;
		pAudioProfile->params.FLAC.BassMode          = StoredOutputMode.BassMode;
		pAudioProfile->params.FLAC.OutputSurround20  = StoredOutputMode.Surround20;

		break;
	case AudioDecoder_Codec_MPEG1:

		pAudioProfile->params.MPEG.OutputChannels   = StoredOutputMode.SpeakerConfig;
		pAudioProfile->params.MPEG.OutputSpdif      = StoredOutputMode.SPDIF;
		pAudioProfile->params.MPEG.OutputDualMode   = StoredOutputMode.DualMode;
		pAudioProfile->params.MPEG.OutputLfe        = StoredOutputMode.LFE;
		pAudioProfile->params.MPEG.BassMode         = StoredOutputMode.BassMode;
		pAudioProfile->params.MPEG.OutputSurround20 = StoredOutputMode.Surround20;

		break;
	case AudioDecoder_Codec_PCM:
		switch (pAudioProfile->SubCodec){
		case 0:

			pAudioProfile->params.PCMCDA.OutputChannels    = StoredOutputMode.SpeakerConfig;
			pAudioProfile->params.PCMCDA.OutputSpdif       = StoredOutputMode.SPDIF;
			pAudioProfile->params.PCMCDA.OutputDualMode    = StoredOutputMode.DualMode;
			pAudioProfile->params.PCMCDA.OutputLfe         = StoredOutputMode.LFE;
			pAudioProfile->params.PCMCDA.BassMode          = StoredOutputMode.BassMode;
			pAudioProfile->params.PCMCDA.OutputSurround20  = StoredOutputMode.Surround20;

			break;
		case 1:

			pAudioProfile->params.LPCMVOB.OutputChannels    = StoredOutputMode.SpeakerConfig;
			pAudioProfile->params.LPCMVOB.OutputSpdif       = StoredOutputMode.SPDIF;
			pAudioProfile->params.LPCMVOB.OutputDualMode    = StoredOutputMode.DualMode;
			pAudioProfile->params.LPCMVOB.OutputLfe         = StoredOutputMode.LFE;
			pAudioProfile->params.LPCMVOB.BassMode          = StoredOutputMode.BassMode;
			pAudioProfile->params.LPCMVOB.OutputSurround20  = StoredOutputMode.Surround20;


			break;
		case 2:


			pAudioProfile->params.LPCMAOB.OutputChannels          = StoredOutputMode.SpeakerConfig;
			pAudioProfile->params.LPCMAOB.OutputSpdif             = StoredOutputMode.SPDIF;
			pAudioProfile->params.LPCMAOB.OutputDualMode          = StoredOutputMode.DualMode;
			pAudioProfile->params.LPCMAOB.OutputLfe               = StoredOutputMode.LFE;
			pAudioProfile->params.LPCMAOB.BassMode                = StoredOutputMode.BassMode;
			pAudioProfile->params.LPCMAOB.OutputSurround20        = StoredOutputMode.Surround20;



			break;
		case 3:

			pAudioProfile->params.LPCMBD.OutputChannels    = StoredOutputMode.SpeakerConfig;
			pAudioProfile->params.LPCMBD.OutputSpdif       = StoredOutputMode.SPDIF;
			pAudioProfile->params.LPCMBD.OutputDualMode    = StoredOutputMode.DualMode;
			pAudioProfile->params.LPCMBD.OutputLfe         = StoredOutputMode.LFE;
			pAudioProfile->params.LPCMBD.BassMode          = StoredOutputMode.BassMode;
			pAudioProfile->params.LPCMBD.OutputSurround20  = StoredOutputMode.Surround20;


			break;
		case 4:

			pAudioProfile->params.LPCMWFA.OutputChannels    = StoredOutputMode.SpeakerConfig;
			pAudioProfile->params.LPCMWFA.OutputSpdif       = StoredOutputMode.SPDIF;
			pAudioProfile->params.LPCMWFA.OutputDualMode    = StoredOutputMode.DualMode;
			pAudioProfile->params.LPCMWFA.OutputLfe         = StoredOutputMode.LFE;
			pAudioProfile->params.LPCMWFA.BassMode          = StoredOutputMode.BassMode;
			pAudioProfile->params.LPCMWFA.OutputSurround20  = StoredOutputMode.Surround20;


			break;
		default:
			// this shouldn't exist, all codecs should be handled
			// ERROR!

			return RM_ERROR;
			break;
		}
		break;
	case AudioDecoder_Codec_ADPCM:
		pAudioProfile->params.ADPCM.OutputChannels = StoredOutputMode.SpeakerConfig;
		pAudioProfile->params.ADPCM.OutputSpdif    = StoredOutputMode.SPDIF;
		pAudioProfile->params.ADPCM.OutputDualMode = StoredOutputMode.DualMode;
		pAudioProfile->params.ADPCM.OutputLfe      = StoredOutputMode.LFE;
		pAudioProfile->params.ADPCM.BassMode       = StoredOutputMode.BassMode;

		break;

	case AudioDecoder_Codec_TTONE:
		pAudioProfile->params.TestTone.OutputChannels = StoredOutputMode.SpeakerConfig;
		pAudioProfile->params.TestTone.OutputSpdif    = StoredOutputMode.SPDIF;
		pAudioProfile->params.TestTone.OutputDualMode = StoredOutputMode.DualMode;
		pAudioProfile->params.TestTone.OutputLfe      = StoredOutputMode.LFE;
		pAudioProfile->params.TestTone.BassMode       = StoredOutputMode.BassMode;

		break;

	case AudioDecoder_Codec_VORBIS:

		pAudioProfile->params.VORBIS.OutputChannels   = StoredOutputMode.SpeakerConfig;
		pAudioProfile->params.VORBIS.OutputSpdif      = StoredOutputMode.SPDIF;
		pAudioProfile->params.VORBIS.OutputDualMode   = StoredOutputMode.DualMode;
		pAudioProfile->params.VORBIS.OutputLfe        = StoredOutputMode.LFE;
		pAudioProfile->params.VORBIS.BassMode         = StoredOutputMode.BassMode;
		pAudioProfile->params.VORBIS.OutputSurround20 = StoredOutputMode.Surround20;

		break;

	case AudioDecoder_Codec_WMAPRO:
	case AudioDecoder_Codec_WMA:
		pAudioProfile->params.WMA.OutputChannels   = StoredOutputMode.SpeakerConfig;
		pAudioProfile->params.WMA.OutputSpdif      = StoredOutputMode.SPDIF;
		pAudioProfile->params.WMA.OutputDualMode   = StoredOutputMode.DualMode;
		pAudioProfile->params.WMA.OutputLfe        = StoredOutputMode.LFE;
		pAudioProfile->params.WMA.BassMode         = StoredOutputMode.BassMode;
		pAudioProfile->params.WMA.OutputSurround20 = StoredOutputMode.Surround20;


		break;
	default:
		// this shouldn't exist, all codecs should be handled
		// ERROR!

		RMNOTIFY((NULL, RM_ERROR, "Generic audio format??\n"));
		return RM_ERROR;
		break;
	}

	return RM_OK;

}




static RMstatus rmfp_print_dcc_audio_decoder_profile(struct DCCXMultipleAudioProfile *pMultipleAudioProfile)
{
	RMuint32 i;

	ASSERT_NULL_POINTER(pMultipleAudioProfile);

	RMDBGPRINT((LOCALDBG, "DCCAudioProfile:\n"));
	RMDBGPRINT((LOCALDBG, "\tNumber of instances     %lu\n", pMultipleAudioProfile->number_of_instances));

	for (i = 0; i < pMultipleAudioProfile->number_of_instances; i++) {
		RMDBGPRINT((LOCALDBG, "\t[%d]STCIndex                %lu\n", i, pMultipleAudioProfile->instance[i].STCID));
		RMDBGPRINT((LOCALDBG, "\t[%d]BitstreamFIFOSize       %lu\n", i, pMultipleAudioProfile->instance[i].BitstreamFIFOSize));
		RMDBGPRINT((LOCALDBG, "\t[%d]XferFIFOCount           %lu\n", i, pMultipleAudioProfile->instance[i].XferFIFOCount));
		RMDBGPRINT((LOCALDBG, "\t[%d]PtsFIFOCount            %lu\n", i, pMultipleAudioProfile->instance[i].PtsFIFOCount));
		RMDBGPRINT((LOCALDBG, "\t[%d]InbandFIFOCount         %lu\n", i, pMultipleAudioProfile->instance[i].InbandFIFOCount));
		RMDBGPRINT((LOCALDBG, "\t[%d]audio engine index      %lu\n", i, pMultipleAudioProfile->instance[i].AudioEngineIndex));
		RMDBGPRINT((LOCALDBG, "\t[%d]audio decoder index     %lu\n", i, pMultipleAudioProfile->instance[i].AudioDecoderIndex));
	}

	return RM_OK;
}



static RMstatus rmfp_print_rmlibplay_audio_decoder_profile(struct RMLibPlayAudioProfile *pAudioProfile)
{

	ASSERT_NULL_POINTER(pAudioProfile);


	RMDBGPRINT((LOCALDBG, "RMLibPlayAudioProfile:\n"));
	RMDBGPRINT((LOCALDBG, "\tCodec                %lu\n", (RMuint32)pAudioProfile->Codec));
	RMDBGPRINT((LOCALDBG, "\tSubCodec             %lu\n", pAudioProfile->SubCodec));

	RMDBGPRINT((LOCALDBG, "\tBitstreamFIFOSize    %lu\n", pAudioProfile->BitstreamFIFOSize));
	RMDBGPRINT((LOCALDBG, "\tXferFIFOCount        %lu\n", pAudioProfile->XferFIFOCount));
	RMDBGPRINT((LOCALDBG, "\tPtsFIFOCount         %lu\n", pAudioProfile->PtsFIFOCount));
	RMDBGPRINT((LOCALDBG, "\tInbandFIFOCount      %lu\n", pAudioProfile->InbandFIFOCount));

	switch (pAudioProfile->Codec) {
	case AudioDecoder_Codec_AAC:
		RMDBGPRINT((LOCALDBG, "\tACC Profile\n"));
		RMDBGPRINT((LOCALDBG, "\t\tInputFormat      %ld\n", pAudioProfile->params.AAC.InputFormat));

		RMDBGPRINT((LOCALDBG, "\t\tAcmod2DualMode   %ld\n", pAudioProfile->params.AAC.Acmod2DualMode));
		RMDBGPRINT((LOCALDBG, "\t\tBassMode         %ld\n", pAudioProfile->params.AAC.BassMode));
		RMDBGPRINT((LOCALDBG, "\t\tOutputChannels   %ld\n", pAudioProfile->params.AAC.OutputChannels));
		RMDBGPRINT((LOCALDBG, "\t\tOutputDualMode   %ld\n", pAudioProfile->params.AAC.OutputDualMode));
		RMDBGPRINT((LOCALDBG, "\t\tOutputLfe        %ld\n", pAudioProfile->params.AAC.OutputLfe));
		RMDBGPRINT((LOCALDBG, "\t\tOutputSpdif      %ld\n", pAudioProfile->params.AAC.OutputSpdif));
		RMDBGPRINT((LOCALDBG, "\t\tOutputSurround20 %ld\n", pAudioProfile->params.AAC.OutputSurround20));
		break;

	case AudioDecoder_Codec_AC3:
		RMDBGPRINT((LOCALDBG, "\tAC3 Profile\n"));
		RMDBGPRINT((LOCALDBG, "\t\tPCMScale         %ld\n", pAudioProfile->params.AC3.PcmScale));
		RMDBGPRINT((LOCALDBG, "\t\tDynScaleLo       %ld\n", pAudioProfile->params.AC3.DynScaleLo));
		RMDBGPRINT((LOCALDBG, "\t\tDynScaleHi       %ld\n", pAudioProfile->params.AC3.DynScaleHi));
		RMDBGPRINT((LOCALDBG, "\t\tCompMode         %ld\n", pAudioProfile->params.AC3.CompMode));

		RMDBGPRINT((LOCALDBG, "\t\tAcmod2DualMode   %ld\n", pAudioProfile->params.AC3.Acmod2DualMode));
		RMDBGPRINT((LOCALDBG, "\t\tBassMode         %ld\n", pAudioProfile->params.AC3.BassMode));
		RMDBGPRINT((LOCALDBG, "\t\tOutputChannels   %ld\n", pAudioProfile->params.AC3.OutputChannels));
		RMDBGPRINT((LOCALDBG, "\t\tOutputDualMode   %ld\n", pAudioProfile->params.AC3.OutputDualMode));
		RMDBGPRINT((LOCALDBG, "\t\tOutputLfe        %ld\n", pAudioProfile->params.AC3.OutputLfe));
		RMDBGPRINT((LOCALDBG, "\t\tOutputSpdif      %ld\n", pAudioProfile->params.AC3.OutputSpdif));
		RMDBGPRINT((LOCALDBG, "\t\tOutputSurround20 %ld\n", pAudioProfile->params.AC3.OutputSurround20));

		break;
	case AudioDecoder_Codec_AG711:
		RMDBGPRINT((LOCALDBG, "\tAG711 Profile\n"));
		RMDBGPRINT((LOCALDBG, "\t\tVersionNumber    %ld\n", pAudioProfile->params.AG711.CodingMode));
		RMDBGPRINT((LOCALDBG, "\t\tSamplingFreq     %ld\n", pAudioProfile->params.AG711.SamplingFrequency));

		RMDBGPRINT((LOCALDBG, "\t\tBassMode         %ld\n", pAudioProfile->params.AG711.BassMode));
		RMDBGPRINT((LOCALDBG, "\t\tOutputChannels   %ld\n", pAudioProfile->params.AG711.OutputChannels));
		RMDBGPRINT((LOCALDBG, "\t\tOutputDualMode   %ld\n", pAudioProfile->params.AG711.OutputDualMode));
		RMDBGPRINT((LOCALDBG, "\t\tOutputLfe        %ld\n", pAudioProfile->params.AG711.OutputLfe));
		RMDBGPRINT((LOCALDBG, "\t\tOutputSpdif      %ld\n", pAudioProfile->params.AG711.OutputSpdif));
		RMDBGPRINT((LOCALDBG, "\t\tOutputSurround20 %ld\n", pAudioProfile->params.AG711.OutputSurround20));

		break;
	case AudioDecoder_Codec_BSAC:
		RMDBGPRINT((LOCALDBG, "\tBSAC Profile\n"));
		RMDBGPRINT((LOCALDBG, "\t\tInputFormat      %ld\n", pAudioProfile->params.BSAC.InputFormat));

		RMDBGPRINT((LOCALDBG, "\t\tBassMode         %ld\n", pAudioProfile->params.BSAC.BassMode));
		RMDBGPRINT((LOCALDBG, "\t\tOutputChannels   %ld\n", pAudioProfile->params.BSAC.OutputChannels));
		RMDBGPRINT((LOCALDBG, "\t\tOutputDualMode   %ld\n", pAudioProfile->params.BSAC.OutputDualMode));
		RMDBGPRINT((LOCALDBG, "\t\tOutputLfe        %ld\n", pAudioProfile->params.BSAC.OutputLfe));
		RMDBGPRINT((LOCALDBG, "\t\tOutputSpdif      %ld\n", pAudioProfile->params.BSAC.OutputSpdif));
		RMDBGPRINT((LOCALDBG, "\t\tOutputSurround20 %ld\n", pAudioProfile->params.BSAC.OutputSurround20));

		break;
	case AudioDecoder_Codec_DRA:
		RMDBGPRINT((LOCALDBG, "\tDRA Profile\n"));

		RMDBGPRINT((LOCALDBG, "\t\tBassMode         %ld\n", pAudioProfile->params.DRA.BassMode));
		RMDBGPRINT((LOCALDBG, "\t\tOutputChannels   %ld\n", pAudioProfile->params.DRA.OutputChannels));
		RMDBGPRINT((LOCALDBG, "\t\tOutputDualMode   %ld\n", pAudioProfile->params.DRA.OutputDualMode));
		RMDBGPRINT((LOCALDBG, "\t\tOutputLfe        %ld\n", pAudioProfile->params.DRA.OutputLfe));
		RMDBGPRINT((LOCALDBG, "\t\tOutputSpdif      %ld\n", pAudioProfile->params.DRA.OutputSpdif));
		RMDBGPRINT((LOCALDBG, "\t\tOutputSurround20 %ld\n", pAudioProfile->params.DRA.OutputSurround20));

		break;
	case AudioDecoder_Codec_DTS:
		RMDBGPRINT((LOCALDBG, "\tDTS Profile\n"));
		RMDBGPRINT((LOCALDBG, "\t\tDTSCD            %ld\n", pAudioProfile->params.DTS.dts_CD));

		RMDBGPRINT((LOCALDBG, "\t\tBassMode         %ld\n", pAudioProfile->params.DTS.BassMode));
		RMDBGPRINT((LOCALDBG, "\t\tOutputChannels   %ld\n", pAudioProfile->params.DTS.OutputChannels));
		RMDBGPRINT((LOCALDBG, "\t\tOutputDualMode   %ld\n", pAudioProfile->params.DTS.OutputDualMode));
		RMDBGPRINT((LOCALDBG, "\t\tOutputLfe        %ld\n", pAudioProfile->params.DTS.OutputLfe));
		RMDBGPRINT((LOCALDBG, "\t\tOutputSpdif      %ld\n", pAudioProfile->params.DTS.OutputSpdif));
		RMDBGPRINT((LOCALDBG, "\t\tOutputSurround20 %ld\n", pAudioProfile->params.DTS.OutputSurround20));

		break;
	case AudioDecoder_Codec_DTSLBR:
		RMDBGPRINT((LOCALDBG, "\tDTSHD LBR Profile\n"));

		RMDBGPRINT((LOCALDBG, "\t\tBassMode         %ld\n", pAudioProfile->params.DTSLBR.BassMode));
		RMDBGPRINT((LOCALDBG, "\t\tOutputChannels   %ld\n", pAudioProfile->params.DTSLBR.OutputChannels));
		RMDBGPRINT((LOCALDBG, "\t\tOutputDualMode   %ld\n", pAudioProfile->params.DTSLBR.OutputDualMode));
		RMDBGPRINT((LOCALDBG, "\t\tOutputLfe        %ld\n", pAudioProfile->params.DTSLBR.OutputLfe));
		RMDBGPRINT((LOCALDBG, "\t\tOutputSpdif      %ld\n", pAudioProfile->params.DTSLBR.OutputSpdif));
		RMDBGPRINT((LOCALDBG, "\t\tOutputSurround20 %ld\n", pAudioProfile->params.DTSLBR.OutputSurround20));

		break;
	case AudioDecoder_Codec_DVDA:
		RMDBGPRINT((LOCALDBG, "\tDVDA Profile\n"));
		RMDBGPRINT((LOCALDBG, "\t\tLossless         %ld\n", pAudioProfile->params.DVDA.Lossless));
		RMDBGPRINT((LOCALDBG, "\t\tChannelConfig    %ld\n", pAudioProfile->params.DVDA.Chconfig));
		RMDBGPRINT((LOCALDBG, "\t\tDRCenable        %ld\n", pAudioProfile->params.DVDA.DRCenable));
		RMDBGPRINT((LOCALDBG, "\t\tDRCboost         %ld\n", pAudioProfile->params.DVDA.DRCboost));
		RMDBGPRINT((LOCALDBG, "\t\tDRCcut           %ld\n", pAudioProfile->params.DVDA.DRCcut));
		RMDBGPRINT((LOCALDBG, "\t\tDRCdialref       %ld\n", pAudioProfile->params.DVDA.DRCdialref));

		RMDBGPRINT((LOCALDBG, "\t\tBassMode         %ld\n", pAudioProfile->params.DVDA.BassMode));
		RMDBGPRINT((LOCALDBG, "\t\tOutputChannels   %ld\n", pAudioProfile->params.DVDA.OutputChannels));
		RMDBGPRINT((LOCALDBG, "\t\tOutputDualMode   %ld\n", pAudioProfile->params.DVDA.OutputDualMode));
		RMDBGPRINT((LOCALDBG, "\t\tOutputLfe        %ld\n", pAudioProfile->params.DVDA.OutputLfe));
		RMDBGPRINT((LOCALDBG, "\t\tOutputSpdif      %ld\n", pAudioProfile->params.DVDA.OutputSpdif));
		RMDBGPRINT((LOCALDBG, "\t\tOutputSurround20 %ld\n", pAudioProfile->params.DVDA.OutputSurround20));

		break;
	case AudioDecoder_Codec_EXAC:
		RMDBGPRINT((LOCALDBG, "\tEXAC Profile\n"));

		RMDBGPRINT((LOCALDBG, "\t\tBassMode         %ld\n", pAudioProfile->params.EXAC.BassMode));
		RMDBGPRINT((LOCALDBG, "\t\tOutputChannels   %ld\n", pAudioProfile->params.EXAC.OutputChannels));
		RMDBGPRINT((LOCALDBG, "\t\tOutputDualMode   %ld\n", pAudioProfile->params.EXAC.OutputDualMode));
		RMDBGPRINT((LOCALDBG, "\t\tOutputLfe        %ld\n", pAudioProfile->params.EXAC.OutputLfe));
		RMDBGPRINT((LOCALDBG, "\t\tOutputSpdif      %ld\n", pAudioProfile->params.EXAC.OutputSpdif));
		RMDBGPRINT((LOCALDBG, "\t\tOutputSurround20 %ld\n", pAudioProfile->params.EXAC.OutputSurround20));

		break;
	case AudioDecoder_Codec_FLAC:
		RMDBGPRINT((LOCALDBG, "\tFLAC Profile\n"));

		RMDBGPRINT((LOCALDBG, "\t\tBassMode         %ld\n", pAudioProfile->params.FLAC.BassMode));
		RMDBGPRINT((LOCALDBG, "\t\tOutputChannels   %ld\n", pAudioProfile->params.FLAC.OutputChannels));
		RMDBGPRINT((LOCALDBG, "\t\tOutputDualMode   %ld\n", pAudioProfile->params.FLAC.OutputDualMode));
		RMDBGPRINT((LOCALDBG, "\t\tOutputLfe        %ld\n", pAudioProfile->params.FLAC.OutputLfe));
		RMDBGPRINT((LOCALDBG, "\t\tOutputSpdif      %ld\n", pAudioProfile->params.FLAC.OutputSpdif));
		RMDBGPRINT((LOCALDBG, "\t\tOutputSurround20 %ld\n", pAudioProfile->params.FLAC.OutputSurround20));

		break;
	case AudioDecoder_Codec_MPEG1:

		RMDBGPRINT((LOCALDBG, "\tMPEG Profile\n"));
		RMDBGPRINT((LOCALDBG, "\t\tAcmod2DualMode   %ld\n", pAudioProfile->params.MPEG.Acmod2DualMode));
		RMDBGPRINT((LOCALDBG, "\t\tBassMode         %ld\n", pAudioProfile->params.MPEG.BassMode));
		RMDBGPRINT((LOCALDBG, "\t\tOutputChannels   %ld\n", pAudioProfile->params.MPEG.OutputChannels));
		RMDBGPRINT((LOCALDBG, "\t\tOutputDualMode   %ld\n", pAudioProfile->params.MPEG.OutputDualMode));
		RMDBGPRINT((LOCALDBG, "\t\tOutputLfe        %ld\n", pAudioProfile->params.MPEG.OutputLfe));
		if(Sw_LogMediaFileInfo)
		{
			//LOG("\t\tOutputSpdif      0x%08x\n", pAudioProfile->params.MPEG.OutputSpdif);
		}
		else
		{
			RMDBGPRINT((LOCALDBG, "\t\tOutputSpdif      %ld\n", pAudioProfile->params.MPEG.OutputSpdif));
		}
		RMDBGPRINT((LOCALDBG, "\t\tOutputSurround20 %ld\n", pAudioProfile->params.MPEG.OutputSurround20));

		break;
     case AudioDecoder_Codec_ADPCM:
                RMDBGPRINT((LOCALDBG, "\tADPCM Profile\n"));

                RMDBGPRINT((LOCALDBG, "\t\tSamplingFreq     %ld\n", pAudioProfile->params.ADPCM.SamplingFrequency));
                RMDBGPRINT((LOCALDBG, "\t\tBitsPerSample    %ld\n", pAudioProfile->params.ADPCM.BitsPerSample));
                RMDBGPRINT((LOCALDBG, "\t\tChannelAssign    %ld\n", pAudioProfile->params.ADPCM.ChannelAssign));

                //MDBGPRINT((LOCALDBG, "\t\tnBlockAlign    %ld\n", pAudioProfile->params.ADPCM.nBlockAlign));

                RMDBGPRINT((LOCALDBG, "\t\tOutputChannels   %ld\n", pAudioProfile->params.ADPCM.OutputChannels));
                RMDBGPRINT((LOCALDBG, "\t\tOutputDualMode   %ld\n", pAudioProfile->params.ADPCM.OutputDualMode));
                RMDBGPRINT((LOCALDBG, "\t\tOutputLfe        %ld\n", pAudioProfile->params.ADPCM.OutputLfe));
                RMDBGPRINT((LOCALDBG, "\t\tOutputSpdif      %ld\n", pAudioProfile->params.ADPCM.OutputSpdif));
                RMDBGPRINT((LOCALDBG, "\t\tOutputSurround20 %ld\n", pAudioProfile->params.ADPCM.OutputSurround20));
                break;
	case AudioDecoder_Codec_PCM:
		switch (pAudioProfile->SubCodec) {

		case 0:

			RMDBGPRINT((LOCALDBG, "\tPCM-CDA Profile\n"));
			RMDBGPRINT((LOCALDBG, "\t\tSamplingFreq     %ld\n", pAudioProfile->params.PCMCDA.SamplingFrequency));
			RMDBGPRINT((LOCALDBG, "\t\tBitsPerSample    %ld\n", pAudioProfile->params.PCMCDA.BitsPerSample));
			RMDBGPRINT((LOCALDBG, "\t\tChannelAssign    %ld\n", pAudioProfile->params.PCMCDA.ChannelAssign));

			RMDBGPRINT((LOCALDBG, "\t\tSigned           %ld\n", pAudioProfile->params.PCMCDA.SignedPCM));
			RMDBGPRINT((LOCALDBG, "\t\tMSBFirst         %ld\n", pAudioProfile->params.PCMCDA.MsbFirst));

			RMDBGPRINT((LOCALDBG, "\t\tBassMode         %ld\n", pAudioProfile->params.PCMCDA.BassMode));
			RMDBGPRINT((LOCALDBG, "\t\tOutputChannels   %ld\n", pAudioProfile->params.PCMCDA.OutputChannels));
			RMDBGPRINT((LOCALDBG, "\t\tOutputDualMode   %ld\n", pAudioProfile->params.PCMCDA.OutputDualMode));
			RMDBGPRINT((LOCALDBG, "\t\tOutputLfe        %ld\n", pAudioProfile->params.PCMCDA.OutputLfe));
			RMDBGPRINT((LOCALDBG, "\t\tOutputSpdif      %ld\n", pAudioProfile->params.PCMCDA.OutputSpdif));
			RMDBGPRINT((LOCALDBG, "\t\tOutputSurround20 %ld\n", pAudioProfile->params.PCMCDA.OutputSurround20));

			break;
		case 1:

			RMDBGPRINT((LOCALDBG, "\tLPCM-VOB Profile\n"));
			RMDBGPRINT((LOCALDBG, "\t\tSamplingFreq     %ld\n", pAudioProfile->params.LPCMVOB.SamplingFrequency));
			RMDBGPRINT((LOCALDBG, "\t\tBitsPerSample    %ld\n", pAudioProfile->params.LPCMVOB.BitsPerSample));
			RMDBGPRINT((LOCALDBG, "\t\tChannelAssign    %ld\n", pAudioProfile->params.LPCMVOB.ChannelAssign));

			RMDBGPRINT((LOCALDBG, "\t\tCoefLR           %ld\n", pAudioProfile->params.LPCMVOB.CoefLR));
			RMDBGPRINT((LOCALDBG, "\t\tDownMix          %ld\n", pAudioProfile->params.LPCMVOB.DownMix));

			RMDBGPRINT((LOCALDBG, "\t\tBassMode         %ld\n", pAudioProfile->params.LPCMVOB.BassMode));
			RMDBGPRINT((LOCALDBG, "\t\tOutputChannels   %ld\n", pAudioProfile->params.LPCMVOB.OutputChannels));
			RMDBGPRINT((LOCALDBG, "\t\tOutputDualMode   %ld\n", pAudioProfile->params.LPCMVOB.OutputDualMode));
			RMDBGPRINT((LOCALDBG, "\t\tOutputLfe        %ld\n", pAudioProfile->params.LPCMVOB.OutputLfe));
			RMDBGPRINT((LOCALDBG, "\t\tOutputSpdif      %ld\n", pAudioProfile->params.LPCMVOB.OutputSpdif));
			RMDBGPRINT((LOCALDBG, "\t\tOutputSurround20 %ld\n", pAudioProfile->params.LPCMVOB.OutputSurround20));

			break;
		case 2:

			RMDBGPRINT((LOCALDBG, "\tLPCM-AOB Profile\n"));
			RMDBGPRINT((LOCALDBG, "\t\tSamplingFreq1    %ld\n", pAudioProfile->params.LPCMAOB.SamplingFrequencyGroup1));
			RMDBGPRINT((LOCALDBG, "\t\tBitsPerSample1   %ld\n", pAudioProfile->params.LPCMAOB.BitsPerSampleGroup1));

			RMDBGPRINT((LOCALDBG, "\t\tSamplingFreq2    %ld\n", pAudioProfile->params.LPCMAOB.SamplingFrequencyGroup2));
			RMDBGPRINT((LOCALDBG, "\t\tBitsPerSample2   %ld\n", pAudioProfile->params.LPCMAOB.BitsPerSampleGroup2));

			RMDBGPRINT((LOCALDBG, "\t\tChannelAssign    %ld\n", pAudioProfile->params.LPCMAOB.ChannelAssign));

			RMDBGPRINT((LOCALDBG, "\t\tCoefLR           %ld\n", pAudioProfile->params.LPCMAOB.CoefLR));
			RMDBGPRINT((LOCALDBG, "\t\tPhaseLR          %ld\n", pAudioProfile->params.LPCMAOB.PhaseLR));
			RMDBGPRINT((LOCALDBG, "\t\tDownSample       %ld\n", pAudioProfile->params.LPCMAOB.DownSample));
			RMDBGPRINT((LOCALDBG, "\t\tDownMix          %ld\n", pAudioProfile->params.LPCMAOB.DownMix));
			RMDBGPRINT((LOCALDBG, "\t\tGroup2Shift      %ld\n", pAudioProfile->params.LPCMAOB.Group2Shift));

			RMDBGPRINT((LOCALDBG, "\t\tBassMode         %ld\n", pAudioProfile->params.LPCMAOB.BassMode));
			RMDBGPRINT((LOCALDBG, "\t\tOutputChannels   %ld\n", pAudioProfile->params.LPCMAOB.OutputChannels));
			RMDBGPRINT((LOCALDBG, "\t\tOutputDualMode   %ld\n", pAudioProfile->params.LPCMAOB.OutputDualMode));
			RMDBGPRINT((LOCALDBG, "\t\tOutputLfe        %ld\n", pAudioProfile->params.LPCMAOB.OutputLfe));
			RMDBGPRINT((LOCALDBG, "\t\tOutputSpdif      %ld\n", pAudioProfile->params.LPCMAOB.OutputSpdif));
			RMDBGPRINT((LOCALDBG, "\t\tOutputSurround20 %ld\n", pAudioProfile->params.LPCMAOB.OutputSurround20));

			break;
		case 3:

			RMDBGPRINT((LOCALDBG, "\tLPCM-BD Profile\n"));
			RMDBGPRINT((LOCALDBG, "\t\tSamplingFreq     %ld\n", pAudioProfile->params.LPCMBD.SamplingFrequency));
			RMDBGPRINT((LOCALDBG, "\t\tBitsPerSample    %ld\n", pAudioProfile->params.LPCMBD.BitsPerSample));
			RMDBGPRINT((LOCALDBG, "\t\tChannelAssign    %ld\n", pAudioProfile->params.LPCMBD.ChannelAssign));

			RMDBGPRINT((LOCALDBG, "\t\tBassMode         %ld\n", pAudioProfile->params.LPCMBD.BassMode));
			RMDBGPRINT((LOCALDBG, "\t\tOutputChannels   %ld\n", pAudioProfile->params.LPCMBD.OutputChannels));
			RMDBGPRINT((LOCALDBG, "\t\tOutputDualMode   %ld\n", pAudioProfile->params.LPCMBD.OutputDualMode));
			RMDBGPRINT((LOCALDBG, "\t\tOutputLfe        %ld\n", pAudioProfile->params.LPCMBD.OutputLfe));
			RMDBGPRINT((LOCALDBG, "\t\tOutputSpdif      %ld\n", pAudioProfile->params.LPCMBD.OutputSpdif));
			RMDBGPRINT((LOCALDBG, "\t\tOutputSurround20 %ld\n", pAudioProfile->params.LPCMBD.OutputSurround20));

			break;

		case 4:

			RMDBGPRINT((LOCALDBG, "\tLPCM-WFA Profile\n"));
			RMDBGPRINT((LOCALDBG, "\t\tSamplingFreq     %ld\n", pAudioProfile->params.LPCMWFA.SamplingFrequency));
			RMDBGPRINT((LOCALDBG, "\t\tBitsPerSample    %ld\n", pAudioProfile->params.LPCMWFA.BitsPerSample));
			RMDBGPRINT((LOCALDBG, "\t\tChannelAssign    %ld\n", pAudioProfile->params.LPCMWFA.ChannelAssign));

			RMDBGPRINT((LOCALDBG, "\t\tBassMode         %ld\n", pAudioProfile->params.LPCMWFA.BassMode));
			RMDBGPRINT((LOCALDBG, "\t\tOutputChannels   %ld\n", pAudioProfile->params.LPCMWFA.OutputChannels));
			RMDBGPRINT((LOCALDBG, "\t\tOutputDualMode   %ld\n", pAudioProfile->params.LPCMWFA.OutputDualMode));
			RMDBGPRINT((LOCALDBG, "\t\tOutputLfe        %ld\n", pAudioProfile->params.LPCMWFA.OutputLfe));
			RMDBGPRINT((LOCALDBG, "\t\tOutputSpdif      %ld\n", pAudioProfile->params.LPCMWFA.OutputSpdif));
			RMDBGPRINT((LOCALDBG, "\t\tOutputSurround20 %ld\n", pAudioProfile->params.LPCMWFA.OutputSurround20));

			break;

		default:
			RMNOTIFY((NULL, RM_ERROR, "unknown codec\n"));
			return RM_ERROR;
		}
		break;

	case AudioDecoder_Codec_PCMX:
		RMDBGPRINT((LOCALDBG, "\tPCMX Profile\n"));
		RMDBGPRINT((LOCALDBG, "\t\tSamplingFreq     %ld\n", pAudioProfile->params.PCMX.SamplingFrequency));
		RMDBGPRINT((LOCALDBG, "\t\tBitsPerSample    %ld\n", pAudioProfile->params.PCMX.BitsPerSample));
		RMDBGPRINT((LOCALDBG, "\t\tChannelAssign    %ld\n", pAudioProfile->params.PCMX.ChannelAssign));

		RMDBGPRINT((LOCALDBG, "\t\tSigned           %ld\n", pAudioProfile->params.PCMX.SignedPCM));
		RMDBGPRINT((LOCALDBG, "\t\tMSBFirst         %ld\n", pAudioProfile->params.PCMX.MsbFirst));

		RMDBGPRINT((LOCALDBG, "\t\tBassMode         %ld\n", pAudioProfile->params.PCMX.BassMode));
		RMDBGPRINT((LOCALDBG, "\t\tOutputChannels   %ld\n", pAudioProfile->params.PCMX.OutputChannels));
		RMDBGPRINT((LOCALDBG, "\t\tOutputDualMode   %ld\n", pAudioProfile->params.PCMX.OutputDualMode));
		RMDBGPRINT((LOCALDBG, "\t\tOutputLfe        %ld\n", pAudioProfile->params.PCMX.OutputLfe));
		RMDBGPRINT((LOCALDBG, "\t\tOutputSpdif      %ld\n", pAudioProfile->params.PCMX.OutputSpdif));
		RMDBGPRINT((LOCALDBG, "\t\tOutputSurround20 %ld\n", pAudioProfile->params.PCMX.OutputSurround20));

		break;

	case AudioDecoder_Codec_TTONE:
		RMDBGPRINT((LOCALDBG, "\tTestTone Profile\n"));
		RMDBGPRINT((LOCALDBG, "\t\tTestToneType     %ld\n", pAudioProfile->params.TestTone.TToneType));
		RMDBGPRINT((LOCALDBG, "\t\tChannelMask      %ld\n", pAudioProfile->params.TestTone.TToneChannelMask));

		RMDBGPRINT((LOCALDBG, "\t\tBassMode         %ld\n", pAudioProfile->params.TestTone.BassMode));
		RMDBGPRINT((LOCALDBG, "\t\tOutputChannels   %ld\n", pAudioProfile->params.TestTone.OutputChannels));
		RMDBGPRINT((LOCALDBG, "\t\tOutputDualMode   %ld\n", pAudioProfile->params.TestTone.OutputDualMode));
		RMDBGPRINT((LOCALDBG, "\t\tOutputLfe        %ld\n", pAudioProfile->params.TestTone.OutputLfe));
		RMDBGPRINT((LOCALDBG, "\t\tOutputSpdif      %ld\n", pAudioProfile->params.TestTone.OutputSpdif));

		break;

	case AudioDecoder_Codec_VORBIS:
		RMDBGPRINT((LOCALDBG, "\tVORBIS Profile\n"));

		RMDBGPRINT((LOCALDBG, "\t\tBassMode         %ld\n", pAudioProfile->params.VORBIS.BassMode));
		RMDBGPRINT((LOCALDBG, "\t\tOutputChannels   %ld\n", pAudioProfile->params.VORBIS.OutputChannels));
		RMDBGPRINT((LOCALDBG, "\t\tOutputDualMode   %ld\n", pAudioProfile->params.VORBIS.OutputDualMode));
		RMDBGPRINT((LOCALDBG, "\t\tOutputLfe        %ld\n", pAudioProfile->params.VORBIS.OutputLfe));
		RMDBGPRINT((LOCALDBG, "\t\tOutputSpdif      %ld\n", pAudioProfile->params.VORBIS.OutputSpdif));
		RMDBGPRINT((LOCALDBG, "\t\tOutputSurround20 %ld\n", pAudioProfile->params.VORBIS.OutputSurround20));

		break;

	case AudioDecoder_Codec_WMA:
		RMDBGPRINT((LOCALDBG, "\tWMA Profile\n"));
		RMDBGPRINT((LOCALDBG, "\t\tVersionNumber    %ld\n", pAudioProfile->params.WMA.VersionNumber));
		RMDBGPRINT((LOCALDBG, "\t\tSamplingFreq     %ld\n", pAudioProfile->params.WMA.SamplingFrequency));
		RMDBGPRINT((LOCALDBG, "\t\tNumberOfChannels %ld\n", pAudioProfile->params.WMA.NumberOfChannels));
		RMDBGPRINT((LOCALDBG, "\t\tBitrate          %ld\n", pAudioProfile->params.WMA.Bitrate));
		RMDBGPRINT((LOCALDBG, "\t\tPacketSize       %ld\n", pAudioProfile->params.WMA.PacketSize));
		RMDBGPRINT((LOCALDBG, "\t\tEncoderOptions   %ld\n", pAudioProfile->params.WMA.EncoderOptions));
		RMDBGPRINT((LOCALDBG, "\t\tValidDownMixCoef %ld\n", pAudioProfile->params.WMA.ValidDownMixCoef));


		RMDBGPRINT((LOCALDBG, "\t\tBassMode         %ld\n", pAudioProfile->params.WMA.BassMode));
		RMDBGPRINT((LOCALDBG, "\t\tOutputChannels   %ld\n", pAudioProfile->params.WMA.OutputChannels));
		RMDBGPRINT((LOCALDBG, "\t\tOutputDualMode   %ld\n", pAudioProfile->params.WMA.OutputDualMode));
		RMDBGPRINT((LOCALDBG, "\t\tOutputLfe        %ld\n", pAudioProfile->params.WMA.OutputLfe));
		RMDBGPRINT((LOCALDBG, "\t\tOutputSpdif      %ld\n", pAudioProfile->params.WMA.OutputSpdif));
		RMDBGPRINT((LOCALDBG, "\t\tOutputSurround20 %ld\n", pAudioProfile->params.WMA.OutputSurround20));

		break;

	case AudioDecoder_Codec_WMAPRO:
		RMDBGPRINT((LOCALDBG, "\tWMAPro Profile\n"));
		RMDBGPRINT((LOCALDBG, "\t\tVersionNumber    %ld\n", pAudioProfile->params.WMA.VersionNumber));
		RMDBGPRINT((LOCALDBG, "\t\tSamplingFreq     %ld\n", pAudioProfile->params.WMA.SamplingFrequency));
		RMDBGPRINT((LOCALDBG, "\t\tNumberOfChannels %ld\n", pAudioProfile->params.WMA.NumberOfChannels));
		RMDBGPRINT((LOCALDBG, "\t\tBitrate          %ld\n", pAudioProfile->params.WMA.Bitrate));
		RMDBGPRINT((LOCALDBG, "\t\tPacketSize       %ld\n", pAudioProfile->params.WMA.PacketSize));
		RMDBGPRINT((LOCALDBG, "\t\tEncoderOptions   %ld\n", pAudioProfile->params.WMA.EncoderOptions));
		RMDBGPRINT((LOCALDBG, "\t\tValidDownMixCoef %ld\n", pAudioProfile->params.WMA.ValidDownMixCoef));

		RMDBGPRINT((LOCALDBG, "\t\tValidBitsPerSamp %ld\n", pAudioProfile->params.WMA.WMAProValidBitsPerSample));
		RMDBGPRINT((LOCALDBG, "\t\tChannelMask      %ld\n", pAudioProfile->params.WMA.WMAProChannelMask));
		RMDBGPRINT((LOCALDBG, "\t\tWMAProVersion    %ld\n", pAudioProfile->params.WMA.WMAProVersionNumber));
		RMDBGPRINT((LOCALDBG, "\t\tDynamicRangeCtrl %ld\n", pAudioProfile->params.WMA.DynamicRangeControl));

		RMDBGPRINT((LOCALDBG, "\t\tBassMode         %ld\n", pAudioProfile->params.WMA.BassMode));
		RMDBGPRINT((LOCALDBG, "\t\tOutputChannels   %ld\n", pAudioProfile->params.WMA.OutputChannels));
		RMDBGPRINT((LOCALDBG, "\t\tOutputDualMode   %ld\n", pAudioProfile->params.WMA.OutputDualMode));
		RMDBGPRINT((LOCALDBG, "\t\tOutputLfe        %ld\n", pAudioProfile->params.WMA.OutputLfe));
		RMDBGPRINT((LOCALDBG, "\t\tOutputSpdif      %ld\n", pAudioProfile->params.WMA.OutputSpdif));
		RMDBGPRINT((LOCALDBG, "\t\tOutputSurround20 %ld\n", pAudioProfile->params.WMA.OutputSurround20));

		break;

	case AudioDecoder_Codec_ATX:
	case AudioDecoder_Codec_WMAPRO_SPDIF:
	case AudioDecoder_Codec_Speech:
		RMDBGLOG((ENABLE, "don't know how to handle this format yet\n"));
		break;
	}

	return RM_OK;
}

