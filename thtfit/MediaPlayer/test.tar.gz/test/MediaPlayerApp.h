#ifndef	_MEDIA_PLAYER_APP_H_
#define	_MEDIA_PLAYER_APP_H_

#include <BaseTypeDef.h>
#include <stdio.h>
#include <stdint.h>
#include <sys/types.h>
#include <CCplusplusBridge.h>
#include <dbus/dbus.h>
#include <SharedPtr.h>
#include "DBusParameterList.h"
#include "MediaSrv.h"
#include <GenericTimer.h>
#include "DBusInterfaceDef.h"
#include <TiXmlDoc2.h>
#include <CmdLineArgument.h>
#include "MediaPlayerAppDef.h"
#include "MediaPlayerAppIf.h"
#include "FileDescriptorEventIf.h"
#include <map>
#include <Array.h>
#include "DbgLogSwitchDef.h"
#include "SerialComPort.h"
#include <EventLoopInterface.h>
#include "GraphicsScreen.h"
#include <UdpSocket.h>
#include <SnmpCmdConv.h>
#include "VideoSync.h"/*added by lxj 2012-12-29*/

using namespace std;
using namespace MediaPlayer;
using namespace VideoSync;/*added by lxj 2012-12-29*/

#define	CMD_LINE_NotApplyDispOpt			"-NotApplyDispOpt"
#define	CMD_LINE_DisableVcrMixerSrc			"-DisableVcrMixerSrc"
#define	CMD_LINE_NotRunMainLoop				"-NotRunMainLoop"
#define	CMD_LINE_DoInitForDualSplitDisp		"-DoInitForDualSplitDisp"

#define	VOLUME_SAVE_TIMEOUT_MS			(2*1000)

#define	XML_VOLUME_ELEMENT_PATH			"Volume"
#define	AUD_ENG0_MASTER_NAME			"AudEng0Master"

#define	DBUS_IF_freedesktop_DBus		"org.freedesktop.DBus"

#define	METHOD_Introspect				"Introspect"

//Method names
#define	METHOD_setDataSource			"setDataSource"
#define	METHOD_Prepare					"Prepare"
#define	METHOD_Play						"Play"
#define	METHOD_Play2					"Play2"
#define	METHOD_Stop						"Stop"
#define	METHOD_setVideoPosition			"setVideoPosition"
#define	METHOD_setVideoInputWindowSize	"setVideoInputWindowSize"
#define	METHOD_setOsdPosition			"setOsdPosition"
#define	METHOD_ChangeVolume				"ChangeVolume"
#define	METHOD_setHwRtcTime				"setHwRtcTime"
#define	METHOD_getTimeZoneSetting		"getTimeZoneSetting"
#define	METHOD_setTimeZoneSetting		"setTimeZoneSetting"
#define	METHOD_setGpioLedStatus			"setGpioLedStatus"
#define	METHOD_setPlayMode				"setPlayMode"
#define	METHOD_getPlayMode				"getPlayMode"
#define	METHOD_DisplayOnLedScreen		"DisplayOnLedScreen"
#define	METHOD_DispOnLedScrAsync		"DispOnLedScrAsync"
#define	METHOD_getMonitorInfo			"getMonitorInfo"
#ifdef ENABLE_DTV
#define	METHOD_PlayTuner				"PlayTuner"
#define	METHOD_GetTunerChannelStrength	"GetTunerChannelStrength"
#define	METHOD_ResetDuration			"ResetDuration"
#define	METHOD_ChannelUp				"ChannelUp"
#define	METHOD_ChannelDown				"ChannelDown"
#define	METHOD_SetTunerStandardMode		"TunerMode"
#define	METHOD_GetTunerMode			"GetTunerMode"
#define	METHOD_TunerScan				"TunerScan"
#define	METHOD_GetEntryChannelInfo		"Get_EntryChannelInfo"
#define	METHOD_GetForceTxMode			"GetForceTxMode"
#define	METHOD_GetFirstChNumber			"GetFirstChNumber"
#define	METHOD_setTunerChannelMode		"setTunerChannelMode"
#define	METHOD_getTunerChannelMode		"getTunerChannelMode"
#endif

typedef map < int, WeakPtr <IFileDescriptorEventIf> > FD_EventIf_MAP;

class CMediaPlayerApp : public CGeneralApp, public CThreadMessageQueue, public IMediaSrvEventListener,
	public ITimerListener, public IFileDescriptorEventIf, public IEventLoopInterface, public IMediaSrvScanProgressListener
{
public:
	class CPollingFdInfo
	{
	public:
		CPollingFdInfo();
		INT_t FixPollingFdset(CIntArray & BadFd_Array);
	public:
		fd_set m_FdsRead, m_FdsWrite, m_FdsExcept;
		int m_iMaxFd;
	};
	typedef struct
	{
		INT_t iBaudrate;
		CSerialComPort::SERIAL_PARITY eSerialParity;
		INT_t iDataBits;
		INT_t iStopBits;
	}SERIAL_PORT_PARAM, *P_SERIAL_PORT_PARAM;
public:
	CMediaPlayerApp(int argc, char * argv[]);
	virtual ~CMediaPlayerApp();
	INT_t InitInstance();
	INT_t ExitInstance();
	static VOID SigHandler(VOID * pCbContext, int SigNo);
	INT_t Run();
	virtual VOID OnTimer(UINT_t TimerId);
	virtual INT_t PlaybackStart();
	virtual INT_t PlaybackEos(LPCSTR pszFileName, UINT32_t PlaybackId, BOOL_t bIsCompletePlaybackEos);
	virtual INT_t PlayNextFile();
	virtual INT_t HdmiStereoscopic3DFmt_Changed();
	virtual INT_t On_VideoOutputModeIsSet();
#if ENABLE_DTV
	virtual INT_t Tuner_StartScan();
	virtual INT_t NotifyScanProgress(UINT32_t PgmNum,UINT32_t Progress);
	virtual INT_t Tuner_StopScan();
	virtual INT_t NotifyTuPlayerPropmtMsg(UINT32_t MsgTag);
#endif
	virtual SharedPtr <TiXmlDocument2> getXmlCfgDoc();
	virtual INT_t OnFdEvent(int iFd, CONST IFileDescriptorEventIf::FD_EVENT_FLAGS FdEvtFlags);
	dbus_bool_t DBusAddWatch(DBusWatch * pDbusWatch);
	void DBusRemoveWatch(DBusWatch * pDbusWatch);
	virtual INT_t RegisterFdNotify(CONST int iFd, CONST IFileDescriptorEventIf::FD_EVENT_FLAGS FdEvtFlags,
		CONST WeakPtr <IFileDescriptorEventIf> FdEvtIf_wp);
	virtual INT_t getFdNotifyInfo(CONST int iFd, OUT IFileDescriptorEventIf::FD_EVENT_FLAGS & FdEvtFlags,
		OUT WeakPtr <IFileDescriptorEventIf> & FdEvtIf_wp);
	virtual INT_t UnregisterFdNotify(CONST int iFd);
#if 1/*added by lxj 2013-1-4*/
	virtual INT_t RegisterTimer(WeakPtr <CppBase::ITimerListener> TimerListener_wp, OUT UINT_t & TimerId, INT_t TimeoutMs);
	virtual INT_t UnregisterTimer(CONST UINT_t TimerId);
	virtual INT_t PlaybackReadyToPlay();
#endif
protected:
	INT_t MainLoop();
	INT_t ProcessDBusMsg(DBusMessage * pDBusMsg);
	INT_t ProcessGenericMsg(SharedPtr<CMessageQueueItem> & MsgItem_sp);
	INT_t On_PlaybackStart(SharedPtr <CGenericMsgData> & MsgData_sp);
	INT_t On_PlaybackEos(SharedPtr <CGenericMsgData> & MsgData_sp);
	INT_t On_PlayNextFile();
	INT_t On_PlaybackReadyToPlay(SharedPtr <CGenericMsgData> & MsgData_sp);/*added by lxj 2013-1-4*/
	INT_t ProcessDBusMsg_MethodCall(DBusMessage * pDBusMsg);
	INT_t DBusIntrospectableIf_MethodCall(DBusMessage * pDBusMsg);
	INT_t SysSrvCfgMgrIf_Signal(DBusMessage * pDBusMsg);
	INT_t ProcessDBusMsg_DefaultIfCall(DBusMessage * pDBusMsg);
	INT_t ProcessDBusMsg_DBusIntrospectableIfCall(DBusMessage * pDBusMsg);
	INT_t ProcessDBusMsg_DBusDBusIfCall(DBusMessage * pDBusMsg);
	INT_t ProcessDBusMsg_SysSrvNetMgrIfCall(DBusMessage * pDBusMsg);
	INT_t ProcessDBusMsg_SysSrvSysEvtIfCall(DBusMessage * pDBusMsg);
	INT_t ProcessDBusMsg_SysSrvCfgMgrIfCall(DBusMessage * pDBusMsg);
	INT_t OnDBusCall_setDataSource(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
		SharedPtr <CDBusParameterList> & DBusOutParamList_sp);
	INT_t OnDBusCall_Prepare(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
		SharedPtr <CDBusParameterList> & DBusOutParamList_sp);
	INT_t OnDBusCall_Play(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
		SharedPtr <CDBusParameterList> & DBusOutParamList_sp);
	INT_t OnDBusCall_Play2(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
		SharedPtr <CDBusParameterList> & DBusOutParamList_sp);
	INT_t OnDBusCall_Stop(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
		SharedPtr <CDBusParameterList> & DBusOutParamList_sp);
	INT_t OnDBusCall_setVideoPosition(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
		SharedPtr <CDBusParameterList> & DBusOutParamList_sp);
	INT_t OnDBusCall_setVideoInputWindowSize(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
		SharedPtr <CDBusParameterList> & DBusOutParamList_sp);
	INT_t OnDBusCall_setOsdPosition(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
		SharedPtr <CDBusParameterList> & DBusOutParamList_sp);
	INT_t OnDBusCall_ChangeVideoOutputMode(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
		SharedPtr <CDBusParameterList> & DBusOutParamList_sp);
	INT_t OnDBusCall_setVideoOutputModeAsync(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
		SharedPtr <CDBusParameterList> & DBusOutParamList_sp);
	INT_t OnDBusCall_ChangeVolume(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
		SharedPtr <CDBusParameterList> & DBusOutParamList_sp);
	INT_t OnDBusCall_setHwRtcTime(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
		SharedPtr <CDBusParameterList> & DBusOutParamList_sp);
	INT_t OnDBusCall_getTimeZoneSetting(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
		SharedPtr <CDBusParameterList> & DBusOutParamList_sp);
	INT_t OnDBusCall_setTimeZoneSetting(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
		SharedPtr <CDBusParameterList> & DBusOutParamList_sp);
	INT_t OnDBusCall_setGpioLedStatus(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
		SharedPtr <CDBusParameterList> & DBusOutParamList_sp);
	INT_t OnDBusCall_DisplayOnLedScreen(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
		SharedPtr <CDBusParameterList> & DBusOutParamList_sp);
	INT_t OnDBusCall_DispOnLedScrAsync(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
		SharedPtr <CDBusParameterList> & DBusOutParamList_sp);
	INT_t OnDBusCall_getMonitorInfo(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
		SharedPtr <CDBusParameterList> & DBusOutParamList_sp);
	INT_t OnDBusCall_setPlayMode(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
		SharedPtr <CDBusParameterList> & DBusOutParamList_sp);
	INT_t OnDBusCall_getPlayMode(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
		SharedPtr <CDBusParameterList> & DBusOutParamList_sp);
	INT_t OnDBusCall_setDisplayParam(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
		SharedPtr <CDBusParameterList> & DBusOutParamList_sp);
	INT_t OnDBusCall_getDisplayParam(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
		SharedPtr <CDBusParameterList> & DBusOutParamList_sp);
	INT_t OnDBusCall_getDisplayPosition(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
		SharedPtr <CDBusParameterList> & DBusOutParamList_sp);
	INT_t OnDBusCall_setMonitorType(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
		SharedPtr <CDBusParameterList> & DBusOutParamList_sp);
	INT_t OnDBusCall_getMonitorType(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
		SharedPtr <CDBusParameterList> & DBusOutParamList_sp);
	INT_t OnDBusCall_setPlaySpeedCtrlAsync(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
		SharedPtr <CDBusParameterList> & DBusOutParamList_sp);
	INT_t OnDBusCall_getPlaySpeedCtrl(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
		SharedPtr <CDBusParameterList> & DBusOutParamList_sp);
	INT_t OnDBusCall_getCurClkTicks(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
		SharedPtr <CDBusParameterList> & DBusOutParamList_sp);
	INT_t OnDBusCall_getConfigDateTime(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
		SharedPtr <CDBusParameterList> & DBusOutParamList_sp);
	INT_t OnDBusCall_getCpuSerialNo(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
		SharedPtr <CDBusParameterList> & DBusOutParamList_sp);
	INT_t OnDBusCall_setHdmi3DTvMode(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
		SharedPtr <CDBusParameterList> & DBusOutParamList_sp);
	INT_t OnDBusCall_setCurClkTicks(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
		SharedPtr <CDBusParameterList> & DBusOutParamList_sp);
	INT_t OnDBusCall_setConfigDateTime(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
		SharedPtr <CDBusParameterList> & DBusOutParamList_sp);
	INT_t OnDBusCall_setOutputSpdifMode(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
		SharedPtr <CDBusParameterList> & DBusOutParamList_sp);
	INT_t OnDBusCall_getOutputSpdifMode(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
		SharedPtr <CDBusParameterList> & DBusOutParamList_sp);
	INT_t OnDBusCall_setVideoDispAspectRatio(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
		SharedPtr <CDBusParameterList> & DBusOutParamList_sp);
	INT_t OnDBusCall_getTunerChannelMode(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
		SharedPtr <CDBusParameterList> & DBusOutParamList_sp);
	INT_t OnDBusCall_setTunerChannelMode(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
		SharedPtr <CDBusParameterList> & DBusOutParamList_sp);
#if 1/*added by lxj 2012-9-28*/
	INT_t OnDBusCall_getVideoDispAspectRatio(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
		SharedPtr <CDBusParameterList> & DBusOutParamList_sp);
#endif
	INT_t OnDBusCall_setHdmiAudioOutput(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
		SharedPtr <CDBusParameterList> & DBusOutParamList_sp);
	INT_t OnDBusCall_setAnalogAudioMute(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
		SharedPtr <CDBusParameterList> & DBusOutParamList_sp);
	INT_t OnDBusCall_setSerialParameters(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
		SharedPtr <CDBusParameterList> & DBusOutParamList_sp);
	INT_t OnDBusCall_getSerialParameters(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
		SharedPtr <CDBusParameterList> & DBusOutParamList_sp);
	INT_t OnDBusCall_getSerialControlData(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
		SharedPtr <CDBusParameterList> & DBusOutParamList_sp);
	INT_t OnDBusCall_setSerialControlData(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
		SharedPtr <CDBusParameterList> & DBusOutParamList_sp);
	INT_t DBusIntrospectableIf_Introspect(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
		SharedPtr <CDBusParameterList> & DBusOutParamList_sp);
	INT_t SysSrvCfgMgrIf_NewSysCfgIsReady(SharedPtr <CDBusParameterList> & DBusInParamList_sp);
#ifdef ENABLE_DTV
	INT_t OnDBusCall_GetEntryChannelInfo(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
		SharedPtr <CDBusParameterList> & DBusOutParamList_sp);
	INT_t OnDBusCall_PlayTuner(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
		SharedPtr <CDBusParameterList> & DBusOutParamList_sp);
	INT_t OnDBusCall_TunerScan(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
		SharedPtr <CDBusParameterList> & DBusOutParamList_sp);
	INT_t OnDBusCall_GetTunerChannelStrength(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
		SharedPtr <CDBusParameterList> & DBusOutParamList_sp);
	INT_t OnDBusCall_ResetDuration(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
		SharedPtr <CDBusParameterList> & DBusOutParamList_sp);
	INT_t OnDBusCall_ChannelUp(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
		SharedPtr <CDBusParameterList> & DBusOutParamList_sp);
	INT_t OnDBusCall_ChannelDown(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
		SharedPtr <CDBusParameterList> & DBusOutParamList_sp);
	INT_t OnDBusCall_TunerMode(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
		SharedPtr <CDBusParameterList> & DBusOutParamList_sp);
	INT_t OnDBusCall_GetTunerMode(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
		SharedPtr <CDBusParameterList> & DBusOutParamList_sp);
	INT_t OnDBusCall_GetFirstChNumber(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
		SharedPtr <CDBusParameterList> & DBusOutParamList_sp);
	INT_t OnDBusCall_GetForceTxMode(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
		SharedPtr <CDBusParameterList> & DBusOutParamList_sp);
	INT_t OnDBusCall_GetLoadProgramTableState(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
		SharedPtr <CDBusParameterList> & DBusOutParamList_sp);
	INT_t On_StartTunerScan();
	INT_t On_NotifyScanProgress(SharedPtr <CGenericMsgData> & MsgData_sp);
	INT_t On_TuPlayerPropmtMsg(SharedPtr <CGenericMsgData> & MsgData_sp);
	INT_t On_DoneTunerScan();
#endif
#if 1/*added by lxj 2012-11-22*/
	INT_t OnDBusCall_getVideoSyncMode(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
		SharedPtr <CDBusParameterList> & DBusOutParamList_sp);
	INT_t OnDBusCall_setVideoSyncMode(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
		SharedPtr <CDBusParameterList> & DBusOutParamList_sp);
	INT_t OnDBusCall_getVideoSyncMaster(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
		SharedPtr <CDBusParameterList> & DBusOutParamList_sp);
	INT_t OnDBusCall_setVideoSyncMaster(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
		SharedPtr <CDBusParameterList> & DBusOutParamList_sp);
#endif
	INT_t OnDBusCall_setHdmiCecCtrl(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
		SharedPtr <CDBusParameterList> & DBusOutParamList_sp);
	INT_t OnDBusCall_setShowClosedCaption(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
		SharedPtr <CDBusParameterList> & DBusOutParamList_sp);
	INT_t OnDBusCall_getShowClosedCaption(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
		SharedPtr <CDBusParameterList> & DBusOutParamList_sp);
#if 1 /* Add by xuweiwei 2014-2-18*/
	INT_t OnDBusCall_setVideoRotation(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
		SharedPtr <CDBusParameterList> & DBusOutParamList_sp);
	
	INT_t OnDBusCall_getVideoRotation(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
		SharedPtr <CDBusParameterList> & DBusOutParamList_sp);
#endif
	
#if 1 /*Add by xuweiwei 2014-3-17*/
	INT_t OnDBusCall_enableAudio6Ch(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
		SharedPtr <CDBusParameterList> & DBusOutParamList_sp);
    INT_t OnDBusCall_getEnableAudio6Ch(SharedPtr <CDBusParameterList> & DBusInParamList_sp,
		SharedPtr <CDBusParameterList> & DBusOutParamList_sp);
#endif
	VOID OnHdmiHotplugChk();
	VOID OnSaveVolume();
	INT_t setHwRtcTime(int Year, int Month, int Date, int Hour, int Minute, int Second, LPCSTR pszTimeZone);
	INT_t getTimeZoneSetting(OUT int & TimezoneHourOff);
	INT_t setTimeZoneSetting(int TimezoneHourOff);
	INT_t SyncSysTimeToHwRtc();
private:
	VOID OnLinuxSignal(int SigNo);
	INT_t ConnectDBus();
	INT_t disconnectDBus();
	INT_t setDBusService();
	INT_t unsetDBusService();
	VOID NotifyExitApp();
	INT_t setVolume(int VolumePercent);
	INT_t SaveDisplayParam(DISP_PARAM_TYPE eDispParamType, INT_t iValue);
	INT_t SaveVoMode(VIDEO_OUTPUT_MODE eNewVoMode);
	LPCSTR getPropNameDescFromDispParamType(DISP_PARAM_TYPE eDispParamType);
	INT_t applyDisplayParamsFromCfg(BOOL_t bContinueIfErr = TRUE);
	int CalcMaxFd();
	INT_t SyncCacheToFile();
	INT_t SerialPortParamDesc_To_ParamValue(LPCSTR pszSerialPortParamDesc,
		P_SERIAL_PORT_PARAM pSerialPortParamVal);
	INT_t SerialPortParmVal_To_Desc(P_SERIAL_PORT_PARAM pSerialPortParamVal,
		OUT CStackBufString & strSerialPortParamDesc);
	CSerialComPort::SERIAL_PARITY getSerialParityFromDesc(LPCSTR pszParityDesc);
	LPCSTR getSerialParityDescFromVal(CSerialComPort::SERIAL_PARITY eSerialParity);
	VOID SerialPortParamVal_Init(P_SERIAL_PORT_PARAM pSerialPortParamVal);
	VOID OnChk_DelayedSet_VcrDefaultSurface();
public:
	WeakPtr <CMediaPlayerApp> m_this_wp;
private:
	BOOL_t m_bShouldExitApp;
	BOOL_t m_bDBusNeedShutdown;
	DBusConnection * m_pDBusConn;
	SharedPtr <CMediaSrv> m_oMediaSrv_sp;
	CGenericTimer m_GenericTimer;
	UINT_t m_HdmiHotplugChkTimerId;
	UINT_t m_VolumeSaveTimerId;
	UINT_t m_DelayedSet_VcrDefaultSurface_TimerId;
	CMutex2 m_SharedDataMutex;
	SharedPtr <TiXmlDocument2> m_SettingXmlDoc_sp;
	int m_VolumePercent;
	SharedPtr <CCmdLineArgument> m_AppCmdLineArgs_sp;
	FD_EventIf_MAP m_FdEventIfMap;
	CPollingFdInfo m_PollingFdInfo;
	BOOL_t m_bNotRunMainLoop;
	SERIAL_PORT_PARAM m_SerialPortParam;
	SharedPtr <CSerialComPort> m_SerialComPort_sp;
	SharedPtr <CGraphicsScreen> m_GraphScreen_sp;
#if 1/*added by lxj 2012-12-29*/
	SharedPtr <CVideoSync> m_VideoSync_sp;
#endif
	fd_set m_fdsDbusComm;
};

#endif	//_MEDIA_PLAYER_APP_H_

