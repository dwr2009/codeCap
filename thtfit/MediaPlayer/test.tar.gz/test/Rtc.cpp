#ifndef	ALLOW_OS_CODE
	#define	ALLOW_OS_CODE
#endif	//ALLOW_OS_CODE

#include "Rtc.h"
#include <stdio.h>

#define	I2C_MODULE_INDEX_SOFTWARE			0
#define	I2C_MODULE_INDEX_HARDWARE			1

#define	I2C_SCL_GPIO_PIN		GPIOId_Sys_0
#define	I2C_SDA_GPIO_PIN		GPIOId_Sys_1
#define	I2C_SPEED_IN_KHZ		50
#define	I2C_DELAY_IN_US			(1000/I2C_SPEED_IN_KHZ)

#define	I2C_DEV_WRITE_ADDR		0xDE

#define	REG_ADDR_SECOND			0x00
#define	REG_ADDR_MINUTE			0x01
#define	REG_ADDR_HOUR			0x02
#define	REG_ADDR_DAY			0x03
#define	REG_ADDR_MONTH			0x04
#define	REG_ADDR_YEAR			0x05
#define	REG_ADDR_CTRL_STAT_07	0x07

#define	WRTC_BIT_SHIFT			4
#define	MIL_BIT_SHIFT			7

CRtcISL1208::CRtcISL1208()
{
	m_uiI2CModuleId = EMHWLIB_MODULE(I2C, I2C_MODULE_INDEX_HARDWARE);
	
	RMMemset(&m_oI2CReadInParam, 0x00,sizeof(m_oI2CReadInParam));
	m_oI2CReadInParam.DeviceParameter.APIVersion = 1;
	m_oI2CReadInParam.DeviceParameter.Clock = I2C_SCL_GPIO_PIN;
	m_oI2CReadInParam.DeviceParameter.Data = I2C_SDA_GPIO_PIN;
	m_oI2CReadInParam.DeviceParameter.Delay = I2C_DELAY_IN_US;
	m_oI2CReadInParam.DeviceParameter.Speed = I2C_SPEED_IN_KHZ;
	m_oI2CReadInParam.DeviceParameter.DevAddr = I2C_DEV_WRITE_ADDR;

	RMMemset(&m_oI2CSendParam, 0x00,sizeof(m_oI2CSendParam));
	m_oI2CSendParam.DeviceParameter = m_oI2CReadInParam.DeviceParameter;
}

CRtcISL1208::~CRtcISL1208()
{

}

//BCD code
RMstatus CRtcISL1208::getTime(struct RUA *pRUA, P_GET_TIME_OUT_PARAM pGetTimeOutParam)
{
	RMstatus eRMstatus = RM_OK;
	struct I2C_Read_out_type i2c_out;
	RMbool bMIL_bit = 0, bHR21_bit = 0;
	
	RMMemset(&i2c_out, 0x00,sizeof(i2c_out));
	m_oI2CReadInParam.UseSubAddr = TRUE;
	
	do
	{
		if(NULL == pRUA || NULL == pGetTimeOutParam)
		{
			printf("PARA ERROR\n");
			break;
		}
		//Init the vars
		pGetTimeOutParam->uiYear = 0;
		pGetTimeOutParam->uiMonth = 0;
		pGetTimeOutParam->uiDay = 0;
		pGetTimeOutParam->uiHour = 0;
		pGetTimeOutParam->uiMinute = 0;
		pGetTimeOutParam->uiSecond = 0;
		//year
		m_oI2CReadInParam.SubAddr = REG_ADDR_YEAR;
		eRMstatus = RUAExchangeProperty(pRUA, m_uiI2CModuleId, RMI2CPropertyID_Read,
			&m_oI2CReadInParam, sizeof(m_oI2CReadInParam), &i2c_out, sizeof(i2c_out));
		if(RMFAILED(eRMstatus))
		{
			printf("ERROR_I2C_READ_FAI\n");
			break;
		}
		pGetTimeOutParam->uiYear = ((i2c_out.Data & 0xF0) >> 4) * 10 + (i2c_out.Data & 0x0F);
			//20 century
		if(100 > pGetTimeOutParam->uiYear)
		{
			pGetTimeOutParam->uiYear += 2000;
		}
		//month
		m_oI2CReadInParam.SubAddr = 0x04;
		eRMstatus = RUAExchangeProperty(pRUA, m_uiI2CModuleId, RMI2CPropertyID_Read,
			&m_oI2CReadInParam, sizeof(m_oI2CReadInParam), &i2c_out, sizeof(i2c_out));
		if(RMFAILED(eRMstatus))
		{
			printf("ERROR_I2C_READ_FAI\n");
			break;
		}
		pGetTimeOutParam->uiMonth = ((i2c_out.Data & 0x10) >> 4) * 10 + (i2c_out.Data & 0x0F);
		//day
		m_oI2CReadInParam.SubAddr = 0x03;
		eRMstatus = RUAExchangeProperty(pRUA, m_uiI2CModuleId, RMI2CPropertyID_Read,
			&m_oI2CReadInParam, sizeof(m_oI2CReadInParam), &i2c_out, sizeof(i2c_out));
		if(RMFAILED(eRMstatus))
		{
			printf("ERROR_I2C_READ_FAI\n");
			break;
		}
		pGetTimeOutParam->uiDay = ((i2c_out.Data & 0x30) >> 4) * 10 + (i2c_out.Data & 0x0F);
		//hour
		m_oI2CReadInParam.SubAddr = 0x02;
		eRMstatus = RUAExchangeProperty(pRUA, m_uiI2CModuleId, RMI2CPropertyID_Read,
			&m_oI2CReadInParam, sizeof(m_oI2CReadInParam), &i2c_out, sizeof(i2c_out));
		if(RMFAILED(eRMstatus))
		{
			printf("ERROR_I2C_READ_FAI\n");
			break;
		}
		bMIL_bit = (i2c_out.Data & 0x80) >> 7;
		if(bMIL_bit)	//24 Hours
		{			
			pGetTimeOutParam->uiHour = ((i2c_out.Data & 0x30) >> 4) * 10 + (i2c_out.Data & 0x0F);
		}
		else	//12 Hours
		{
			bHR21_bit = (i2c_out.Data & 0x20) >> 5;
			pGetTimeOutParam->uiHour = ((i2c_out.Data & 0x10) >> 4) * 10 + (i2c_out.Data & 0x0F);
			if(bHR21_bit)	//PM
			{
				pGetTimeOutParam->uiHour += 12;
			}
		}
		//minute
		m_oI2CReadInParam.SubAddr = 0x01;
		eRMstatus = RUAExchangeProperty(pRUA, m_uiI2CModuleId, RMI2CPropertyID_Read,
			&m_oI2CReadInParam, sizeof(m_oI2CReadInParam), &i2c_out, sizeof(i2c_out));
		if(RMFAILED(eRMstatus))
		{
			printf("ERROR_I2C_READ_FAI\n");
			break;
		}
		pGetTimeOutParam->uiMinute = ((i2c_out.Data & 0x70) >> 4) * 10 + (i2c_out.Data & 0x0F);
		//second
		m_oI2CReadInParam.SubAddr = 0x00;
		eRMstatus = RUAExchangeProperty(pRUA, m_uiI2CModuleId, RMI2CPropertyID_Read,
			&m_oI2CReadInParam, sizeof(m_oI2CReadInParam), &i2c_out, sizeof(i2c_out));
		if(RMFAILED(eRMstatus))
		{
			printf("ERROR_I2C_READ_FAI\n");;
			break;
		}
		pGetTimeOutParam->uiSecond = ((i2c_out.Data & 0x70) >> 4) * 10 + (i2c_out.Data & 0x0F);
	}while(FALSE);

	

	return eRMstatus;
}

RMstatus CRtcISL1208::setTime(struct RUA *pRUA, P_SET_TIME_IN_PARAM pSetTimeInParam)
{
	RMstatus eOutRMstatus = RM_OK, eRMstatus = RM_OK;
	struct I2C_Read_out_type i2c_out;

	RMMemset(&i2c_out, 0x00,sizeof(i2c_out));
	m_oI2CReadInParam.UseSubAddr = TRUE;
	m_oI2CSendParam.UseSubAddr = TRUE;
	
	do
	{
		if(NULL == pRUA || NULL == pSetTimeInParam)
		{
			printf("SETTIME PARA ERROR\n");
			break;
		}
		//WRTC bit = 1
		eRMstatus = EnableWRTC(pRUA, TRUE);
		if(RM_OK != eRMstatus)
		{
			eOutRMstatus = eRMstatus;
			break;
		}
		//Year
		m_oI2CSendParam.SubAddr = REG_ADDR_YEAR;
		m_oI2CSendParam.Data = (((pSetTimeInParam->uiYear % 100) / 10) << 4) | 
			((pSetTimeInParam->uiYear % 100) % 10);
		eRMstatus = RUASetProperty(pRUA, m_uiI2CModuleId, RMI2CPropertyID_Send,
			&m_oI2CSendParam, sizeof(m_oI2CSendParam), 0);
		if(RMFAILED(eRMstatus))
		{
			printf(" ERROR_I2C_WRITE_FAIL\n");
			break;
		}
		//Month
		m_oI2CSendParam.SubAddr = REG_ADDR_MONTH;
		m_oI2CSendParam.Data = ((pSetTimeInParam->uiMonth / 10) << 4) | (pSetTimeInParam->uiMonth % 10);
		eRMstatus = RUASetProperty(pRUA, m_uiI2CModuleId, RMI2CPropertyID_Send,
			&m_oI2CSendParam, sizeof(m_oI2CSendParam), 0);
		if(RMFAILED(eRMstatus))
		{
			printf(" ERROR_I2C_WRITE_FAIL\n");
			break;
		}
		//Day
		m_oI2CSendParam.SubAddr = REG_ADDR_DAY;
		m_oI2CSendParam.Data = ((pSetTimeInParam->uiDay / 10) << 4) | (pSetTimeInParam->uiDay % 10);
		eRMstatus = RUASetProperty(pRUA, m_uiI2CModuleId, RMI2CPropertyID_Send,
			&m_oI2CSendParam, sizeof(m_oI2CSendParam), 0);
		if(RMFAILED(eRMstatus))
		{
			printf(" ERROR_I2C_WRITE_FAIL\n");
			break;
		}
		//Hours
		m_oI2CSendParam.SubAddr = REG_ADDR_HOUR;
		m_oI2CSendParam.Data = ((pSetTimeInParam->uiHour / 10) << 4) | (pSetTimeInParam->uiHour % 10);
		m_oI2CSendParam.Data |= (1 << MIL_BIT_SHIFT);
		eRMstatus = RUASetProperty(pRUA, m_uiI2CModuleId, RMI2CPropertyID_Send,
			&m_oI2CSendParam, sizeof(m_oI2CSendParam), 0);
		if(RMFAILED(eRMstatus))
		{
			printf(" ERROR_I2C_WRITE_FAIL\n");
			break;
		}
		//Minute
		m_oI2CSendParam.SubAddr = REG_ADDR_MINUTE;
		m_oI2CSendParam.Data = ((pSetTimeInParam->uiMinute / 10) << 4) | (pSetTimeInParam->uiMinute % 10);
		eRMstatus = RUASetProperty(pRUA, m_uiI2CModuleId, RMI2CPropertyID_Send,
			&m_oI2CSendParam, sizeof(m_oI2CSendParam), 0);
		if(RMFAILED(eRMstatus))
		{
			printf(" ERROR_I2C_WRITE_FAIL\n");
			break;
		}
		//Second
		m_oI2CSendParam.SubAddr = REG_ADDR_SECOND;
		m_oI2CSendParam.Data = ((pSetTimeInParam->uiSecond / 10) << 4) | (pSetTimeInParam->uiSecond % 10);
		eRMstatus = RUASetProperty(pRUA, m_uiI2CModuleId, RMI2CPropertyID_Send,
			&m_oI2CSendParam, sizeof(m_oI2CSendParam), 0);
		if(RMFAILED(eRMstatus))
		{
			printf(" ERROR_I2C_WRITE_FAIL\n");
			break;
		}
		//WRTC bit = 0
		eRMstatus = EnableWRTC(pRUA, FALSE);
		if(RM_OK != eRMstatus)
		{
			break;
		}
	}while(FALSE);

	return eOutRMstatus;
}

RMstatus CRtcISL1208::EnableWRTC(struct RUA *pRUA, RMbool bEnable)
{
	RMstatus eRMstatus = RM_OK;
	struct I2C_Read_out_type i2c_out;	

	RMMemset(&i2c_out, 0x00,sizeof(i2c_out));
	m_oI2CReadInParam.UseSubAddr = TRUE;
	m_oI2CSendParam.UseSubAddr = TRUE;
	do
	{
		if(NULL == pRUA)
		{
			printf("EnableWRTC PARA ERROR\n");
			break;
		}
		//Read
		m_oI2CReadInParam.SubAddr = REG_ADDR_CTRL_STAT_07;
		eRMstatus = RUAExchangeProperty(pRUA, m_uiI2CModuleId, RMI2CPropertyID_Read,
			&m_oI2CReadInParam, sizeof(m_oI2CReadInParam), &i2c_out, sizeof(i2c_out));
		if(RMFAILED(eRMstatus))
		{
			printf("READ ERROR\n");
			break;
		}
		//Modify
		if(bEnable)
		{
			i2c_out.Data |= (1 << WRTC_BIT_SHIFT);
		}
		else
		{
			i2c_out.Data &= ~(1 << WRTC_BIT_SHIFT);
		}
		//Write
		m_oI2CSendParam.SubAddr = REG_ADDR_CTRL_STAT_07;
		m_oI2CSendParam.Data = (i2c_out.Data | (1 << WRTC_BIT_SHIFT));
		eRMstatus = RUASetProperty(pRUA, m_uiI2CModuleId, RMI2CPropertyID_Send,
			&m_oI2CSendParam, sizeof(m_oI2CSendParam), 0);
		if(RMFAILED(eRMstatus))
		{
			printf("WRITE ERROR\n");
			break;
		}
	}while(FALSE);

	return eRMstatus;
}

