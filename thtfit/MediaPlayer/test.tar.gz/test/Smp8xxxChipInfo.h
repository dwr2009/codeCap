#ifndef	_SMP8XXX_CHIPINFO_H_
#define	_SMP8XXX_CHIPINFO_H_

#include <rmdef/rmdef.h>
#include <BaseErrDef.h>
#include <BaseTypeDef.h>
#include <llad/include/gbus.h>

class CSmp8xxxChipInfo
{
public:
	CSmp8xxxChipInfo();
	virtual ~CSmp8xxxChipInfo();
	virtual INT_t ReadChipInfo();
	virtual RMuint16 getChipId();
private:
	INT_t OpenGbus();
	INT_t CloseGbus();
private:
	struct llad * m_pLlad;
	struct gbus * m_pGbus;
	BOOL_t m_bGotChipInfo;
	RMuint16 m_ChipId;
};

#endif	//_SMP8XXX_CHIPINFO_H_

