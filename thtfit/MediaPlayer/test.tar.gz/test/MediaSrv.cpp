#ifndef	ALLOW_OS_CODE
#define	ALLOW_OS_CODE
#endif	//ALLOW_OS_CODE

#include "MediaSrv.h"
#include "TransactionMsgId.h"
#include <DateTime.h>
#include <unistd.h>
#include <AutoLock.h>
#include "TransactionMsgData.h"
#include <memory.h>
#include <StackBufString.h>
#include "resources.h"
#include "callbacks.h"
#include "parse_command_line.h"
#include "ciphers.h"
#include "DBusMessage.h"
#include <StackBufString.h>
#include "VolumeTableCalc.h"
#include <emhwlib/include/tango3/emhwlib_chipspecific_tango3.h>
#include "dcc/include/dcc_macros.h"
#include "get_key.h"
#include <Mcp23017RegDef.h>
#include <RuaPropertyAdvancedApi.h>
#include <DisplayWindow.h>
#include <TiXmlDoc2.h>
#include "MediaPlayerAppIf.h"
#include <DBusParameterList.h>
#include <InvArgException.h>
#include <BaseErrException.h>
#include <SysBaseSrvApi.h>
#include "DbgLogSwitchDef.h"
#include <UrlInfo.h>
#include <RmSyncAccess/include/RmSyncAccess.h>
#include <emhwlib_hal/include/emhwlib_lram_tango3.h>
#include <XenvOperationLib.h>
#include <ColorFormat.h>
#include <sys/time.h>
#include "Api/MediaPlayerApi.h"
#include <SnmpCmdConv.h>
#include <AutoScopeLock.h>
#include <sys/times.h>
#include <Smp86xxMemRscInfo.h>

static WeakPtr <CMediaSrv> g_MediaSrv_wp;

static void init_rmfp_file_specific_context(struct rmfp_main_thread_context_type *pMainContext);

static void init_rmfp_file_specific_context(struct rmfp_main_thread_context_type *pMainContext)
{
	/* No OSD by default */
	pMainContext->OSDAvailable = FALSE;

	/* Reset structures */
	RMMemset(&pMainContext->metadata, 0, sizeof(pMainContext->metadata));
	RMMemset(&pMainContext->defaults_metadata, 0, sizeof(pMainContext->defaults_metadata));
	RMMemset(&pMainContext->stream_properties, 0, sizeof(pMainContext->stream_properties));
	RMMemset(&pMainContext->current_pat, 0, sizeof(pMainContext->current_pat));
	RMMemset(&pMainContext->current_pmt, 0, sizeof(pMainContext->current_pmt));
	RMMemset(&pMainContext->OSDProfile, 0, sizeof(pMainContext->OSDProfile));
}

RMbool RMKeyAvailable(RMuint32 TimeOutInMicroSeconds)
{
	RMbool bOutRet = FALSE;
	SharedPtr <CMediaSrv> MediaSrv_sp;

	do
	{
		MediaSrv_sp = g_MediaSrv_wp.Promote();
		if(MediaSrv_sp.isNull())
		{
			break;
		}
		bOutRet = MediaSrv_sp->RMKeyAvailable(TimeOutInMicroSeconds);
	}while(FALSE);

	return bOutRet;
}

RMascii RMGetKey(void)
{
	RMascii OutKey;
	SharedPtr <CMediaSrv> MediaSrv_sp;

	do
	{
		MediaSrv_sp = g_MediaSrv_wp.Promote();
		if(MediaSrv_sp.isNull())
		{
			break;
		}
		OutKey = MediaSrv_sp->RMGetKey();
	}while(FALSE);

	return OutKey;
}

RMascii RMGetKeyExtended(RMbool* pIsSpecialChar)
{
	if(pIsSpecialChar)
	{
		*pIsSpecialChar = FALSE;
	}
	return RMGetKey();
}

#define EMHWLIB_CATEGORY(mod) mod
#define EMHWLIB_PROPERTY(mod, prop) RM ## mod ## PropertyID_ ## prop
#define EMHWLIB_GENERIC_PROPERTY(prop) RMGenericPropertyID_ ## prop
#define EMHWLIB_MODULE_TYPE(mod, type) mod ## _ ## type

static RMstatus rua_set_prop(void *pContext, RMuint32 ModuleID, RMuint32 PropertyID, void *pValue, RMuint32 ValueSize)
{
    return RUASetProperty((struct RUA *)pContext, ModuleID, PropertyID, pValue, ValueSize, 0);
}

static RMstatus rua_set_pending_prop(void *pContext, RMuint32 ModuleID, RMuint32 PropertyID, void *pValue, RMuint32 ValueSize)
{
	struct RUAEvent evt;
	RMstatus err;
	RMuint32 n;
	
	n = 3;
	do {
		evt.Mask = EMHWLIB_DISPLAY_EVENT_ID(ModuleID);
		if (evt.Mask > 0) {
			evt.ModuleID = EMHWLIB_CATEGORY(DisplayBlock);
			err = RUAResetEvent((struct RUA *)pContext, &evt);
			if (RMFAILED(err)) {
#if RUAOUTPUT_NOTIFY
				RMNOTIFY((NULL, err, "Can not reset display event\n"));
#endif
				return err;
			}
		}
		
		err = RUASetProperty((struct RUA *)pContext, ModuleID, PropertyID, pValue, ValueSize, 0);
		if ((err == RM_PENDING) && (evt.Mask > 0)) {
			RMuint32 index;
			
			err = RuaWaitFor_DispBlk_DispEvt_ThrdSync((struct RUA *)pContext, &evt, 1, WAIT_COMMAND_TIMEOUT_US, &index);
			if (RMFAILED(err)) {
#if RUAOUTPUT_NOTIFY
				RMNOTIFY((NULL, err, "Wait for display update event completion failed, ModuleID 0x%08lX\n", ModuleID));
#endif
				if (err != RM_PENDING) return err;
			}
			err = RUASetProperty((struct RUA *)pContext, ModuleID, PropertyID, pValue, ValueSize, 0);
		}
		if (err == RM_PENDING) {
#if RUAOUTPUT_NOTIFY
			RMDBGLOG((ENABLE, "Property %ld on ModuleID 0x%08lX still pending, trying again...\n", PropertyID, ModuleID));
#endif
		}
		n--;
	} while ((n > 0) && (err == RM_PENDING));
	
#if RUAOUTPUT_NOTIFY
	if (RMFAILED(err)) {
		RMNOTIFY((NULL, err, "Can not set Property %ld on ModuleID 0x%08lX\n", PropertyID, ModuleID));
	}
#endif
	
	return err;
}

static RMstatus rua_get_prop(void *pContext, RMuint32 ModuleID, RMuint32 PropertyID, void *pValue, RMuint32 ValueSize)
{
    return RUAGetProperty((struct RUA *)pContext, ModuleID, PropertyID, pValue, ValueSize);
}

static RMstatus rua_exchange_prop(void *pContext, RMuint32 ModuleID, RMuint32 PropertyID, void *pValueIn, RMuint32 ValueInSize, void *pValueOut, RMuint32 ValueOutSize)
{
	return RUAExchangeProperty((struct RUA *)pContext, ModuleID, PropertyID, pValueIn, ValueInSize, pValueOut, ValueOutSize);
}

static RMuint32 rua_malloc(void *pContext, RMuint32 MemblockID, RMuint32 Size)
{
	return RUAMalloc((struct RUA *)pContext, MemblockID, RUA_DRAM_UNPROTECTED, Size); 
}

static void rua_free(void *pContext, RMuint32 Buf)
{
	return RUAFree((struct RUA *)pContext, Buf);
}

// Exposed RUA function
RMstatus rmoutput_rua_set_pending_property(struct RUA *pRUA, RMuint32 ModuleID, RMuint32 PropertyID, void *pValue, RMuint32 ValueSize)
{
	return rua_set_pending_prop((void *)pRUA, ModuleID, PropertyID, pValue, ValueSize);
}

// Init function
RMstatus rmoutput_rua_fill_callbacks(struct RUA *pRUA, struct rmoutput_hwlib_callbacks *pHWLib)
{
	if (pRUA == NULL) return RM_FATALINVALIDPOINTER;
	if (pHWLib == NULL) return RM_FATALINVALIDPOINTER;
	
	pHWLib->APIVersion = 1;
	pHWLib->context = (void *)pRUA;
	pHWLib->set_prop = rua_set_prop;
	pHWLib->set_pending_prop = rua_set_pending_prop;
	pHWLib->get_prop = rua_get_prop;
	pHWLib->exchange_prop = rua_exchange_prop;
	pHWLib->malloc = rua_malloc;
	pHWLib->free = rua_free;
	pHWLib->match_timing = NULL;
	
	return RM_OK;
}

INT_t IMediaSrvEventListener::PlayNextFile()
{
	return ERROR_SUCCESS;
}

INT_t IMediaSrvEventListener::PlaybackEos(LPCSTR pszFileName, UINT32_t PlaybackId, BOOL_t bIsCompletePlaybackEos)
{	
	//LOG_BLINE("IMediaSrvEventListener::PlaybackEos\n");

	return ERROR_SUCCESS;
}

INT_t IMediaSrvScanProgressListener::NotifyScanProgress(UINT32_t PgmNum,UINT32_t Progress) 
{
	return ERROR_SUCCESS;
}

INT_t IMediaSrvScanProgressListener::Tuner_StartScan()
{
	return ERROR_SUCCESS;
}

INT_t IMediaSrvScanProgressListener::Tuner_StopScan()
{
	return ERROR_SUCCESS;
}

INT_t IMediaSrvScanProgressListener::NotifyTuPlayerPropmtMsg(UINT32_t MsgTag)
{
	return ERROR_SUCCESS;
}


/*
ThreadContext: other
*/
CMediaSrv::CMediaSrv()
{
	INT_t iRet;
	RMstatus eRMstatus;

	m_bShouldExitThread = FALSE;	
	m_pDBusConnMediaSrv = NULL;
	m_iPlayStatus = PLAY_STAT_IDLE;
	iRet = m_Mp7xxGlobalStatusData.setMpSrvPlayStatus(m_iPlayStatus);
	if(ERROR_SUCCESS != iRet)
	{
		PRINT_BFILE_LINENO_IRET_STR;
	}
	m_ePlaySourceType = PLAY_SOURCE_UNKNOWN;
	iRet = m_PlayStatChangedEvent.SetEvent();
	if(ERROR_SUCCESS != iRet)
	{
		PRINT_BFILE_LINENO_IRET_STR;
	}
	ZeroMemory(&m_RmfpMainContext, sizeof(m_RmfpMainContext));
	ZeroMemory(&m_Display_opt, sizeof(m_Display_opt));
	ZeroMemory(&m_Display_conf, sizeof(m_Display_conf));
	ZeroMemory(&m_RmfpOptions, sizeof(m_RmfpOptions));
	ZeroMemory(&m_RmfpProfile, sizeof(m_RmfpProfile));
	m_RmfpMainContext.display_opt = &m_Display_opt;
	m_RmfpMainContext.display_conf = &m_Display_conf;
	m_RmfpMainContext.pOptions = &m_RmfpOptions;
	m_RmfpMainContext.pMediaSrv = NULL;
	m_RmfpMainContext.current_status.playbackState.state = RMFP_Playback_state_Stopped;
	m_bQuitPlay = FALSE;
	m_pPlayCtrlCtx = NULL;

	//backup options
	m_RmfpOptionsBackup = m_RmfpOptions;
	m_PlaybackId = 0;
	m_bNotApplyDispOpt = FALSE;

	//I2C parameters
	ZeroMemory(&m_oI2cSendParam, sizeof(m_oI2cSendParam));
	m_oI2cSendParam.DeviceParameter.APIVersion = 1;
	m_oI2cSendParam.DeviceParameter.Clock = GPIOId_Sys_0;
	m_oI2cSendParam.DeviceParameter.Data = GPIOId_Sys_1;
	m_oI2cSendParam.DeviceParameter.Delay = 10;
	m_oI2cSendParam.DeviceParameter.DevAddr = LED_CTRL_MCP23017_I2C_ADDR;
	m_oI2cSendParam.DeviceParameter.Speed = 45;	// 45KHz
	m_uiI2CModuleId = EMHWLIB_MODULE(I2C, I2C_MODULE_INDEX_HARDWARE);
	ZeroMemory(&m_oI2cReadInParam, sizeof(m_oI2cReadInParam));
	m_oI2cReadInParam.DeviceParameter = m_oI2cSendParam.DeviceParameter;
	
	m_eVoMode = VO_MODE_HDMI_720p50;
	m_eMonitorManufacturerId = MONITOR_MANUFACTURER_ID_UNDEFINED;
#ifdef ENABLE_DTV
	m_bTunerOpenSucc = FALSE;
#endif

	eRMstatus = PlayCtrlCtx_TLS_Init();
	if(RMFAILED(eRMstatus))
	{
		PRINT_BFILE_LINENO_RMSTATUS;
	}
	
	m_pPlayCtrlCtx = PlayCtrlCtx_Create();
	if(NULL == m_pPlayCtrlCtx)
	{
		LOG_BLINE("PlayCtrlCtx_Create FAILED\n");
	}

	m_bNeedApplyAudioCfgToHdmi = FALSE;
	m_bDisableVcrMixerSrc = FALSE;
	m_VidDispAspectRatioAtNextPlay = DispAspectRatio_DEFAULT;
	m_CurVidDispAspectRatio = DispAspectRatio_DEFAULT;
	m_bVidDispAspectRatioAtNextPlay_Valid = FALSE;
	m_bCanProcessMsgInDataIoTimeoutCb = FALSE;
	m_BlackSurfaceAddr = 0;
	m_Cur_DigLostPixels = 0;
	m_Prev_ChkDigLostPixel_TimeMs = 0;
	m_bShouldApplyHdmi3DInfoFrame = FALSE;	//in initial stage, not re-send.
	m_idProcessTunerTaskTimer = CGenericTimer::TIMER_ID_INVALID;
	m_eHdmi3DTvMode = H3DTvMode_Normal;
	m_bIsCompletePlaybackEos = TRUE;
	m_eShowClosedCaption = CC_SEL_Disabled;
	m_Cur_PTEnable=FALSE;

	/*
	edid_dbg = RMdebuglevel_all;
	hdmi_dbg = RMdebuglevel_all;
	rmoutput_dbg = RMdebuglevel_all;
	//*/
}

/*
ThreadContext: other
*/
CMediaSrv::~CMediaSrv()
{
	INT_t iRet;
	RMstatus eRMstatus;
	
	if(getThreadIsRunning())
	{
		iRet = StopThread();
		if(ERROR_SUCCESS != iRet)
		{
			PRINT_BFILE_LINENO_IRET_STR;
		}
	}

	if(m_pGbus)
	{
		gbus_close(m_pGbus);
		m_pGbus = NULL;
	}
	if(m_pLlad)
	{
		llad_close(m_pLlad);
		m_pLlad = NULL;
	}

	if(m_pPlayCtrlCtx)
	{
		eRMstatus = PlayCtrlCtx_Destroy(m_pPlayCtrlCtx);
		if(RMFAILED(eRMstatus))
		{
			PRINT_BFILE_LINENO_RMSTATUS;
		}
		m_pPlayCtrlCtx = NULL;
	}

	eRMstatus = PlayCtrlCtx_TLS_Uninit();
	if(RMFAILED(eRMstatus))
	{
		PRINT_BFILE_LINENO_RMSTATUS;
	}
	
#ifdef ENABLE_DTV
	m_TunerSrv_sp.Clear();
#endif	
}

INT_t CMediaSrv::InitInstance()
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	DBusError DBusErr;
	RMstatus eRMstatus = RM_OK;
	DECLARE_CLS_STACK_BUF_STRING(strShellCmd, 1024);
	struct rmfp_main_thread_context_type *pMainContext = &m_RmfpMainContext;

	do
	{
		g_MediaSrv_wp = m_this_wp;

		{
			m_pLlad = llad_open((RMascii *)"0");
			if(NULL == m_pLlad)
			{
				LOG("Failed to open llad dev\n");
				iOutRet = ERR_INIT_FAIL;
				break;
			}
		}
		{
			m_pGbus = gbus_open(m_pLlad);
			if(NULL == m_pGbus)
			{
				LOG("Failed to open gbus\n");
				iOutRet = ERR_INIT_FAIL;
				break;
			}
		}
			
		m_Smp8xxxChipInfo_sp = SharedPtr <CSmp8xxxChipInfo> (new CSmp8xxxChipInfo);
		if(m_Smp8xxxChipInfo_sp.isNull())
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}
		iRet = m_Smp8xxxChipInfo_sp->ReadChipInfo();
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}

		m_MediaFileInfoCache_sp = SharedPtr <CMediaFileInfoCache> (new CMediaFileInfoCache);
		if(m_MediaFileInfoCache_sp.isNull())
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}

		{
			//Client connection
			dbus_error_init(&DBusErr);
			{
				m_pDBusConnMediaSrv = dbus_bus_get_private(DBUS_BUS_SYSTEM, &DBusErr);
				if(NULL == m_pDBusConnMediaSrv)
				{
					iOutRet = ERR_CONNECTION_FAIL;
					break;
				}
				if(dbus_error_is_set(&DBusErr))
				{			
					iOutRet = ERR_CONNECTION_FAIL;
					dbus_error_free(&DBusErr);
					break;
				}
				dbus_connection_set_exit_on_disconnect(m_pDBusConnMediaSrv, FALSE);
			}
		}

		m_CnkB85LcmLedScr_sp = SharedPtr <CCnkB85Lcm> (new CCnkB85Lcm);
		if(m_CnkB85LcmLedScr_sp.isNull())
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}
		if(FALSE == m_CnkB85LcmLedScr_sp->ChkInit())
		{
			iOutRet = ERR_INIT_FAIL;
			break;
		}

		iOutRet = RmfpInit();
		if(ERROR_SUCCESS != iOutRet)
		{
			break;
		}

		iRet = m_CnkB85LcmLedScr_sp->InitLCD();
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}
		iRet = m_CnkB85LcmLedScr_sp->DisplayStr("READY");
		if(ERROR_SUCCESS != iRet)
		{
			PRINT_BFILE_LINENO_IRET_STR;
		}
		
		//Read the previous ethernet IP
		do
		{
			iRet = SysProp_del(SysProp_KEY_PrevEthernetIP);
			if(ERROR_SUCCESS != iRet)
			{
				if(ERROR_NOT_FOUND != iRet)
				{
					PRINT_BFILE_LINENO_IRET_STR;	
				}
			}
			DECLARE_CLS_STACK_BUF_STRING(strCurEthernetIP, 64);
			iRet = SysProp_get(SysProp_KEY_CurEthernetIP, OUT strCurEthernetIP);
			if(ERROR_SUCCESS != iRet)
			{
				if(ERROR_NOT_FOUND != iRet)
				{
					PRINT_BFILE_LINENO_IRET_STR;	
				}
				break;
			}
			iRet = m_CnkB85LcmLedScr_sp->DisplayStr((LPCSTR)strCurEthernetIP);
			if(ERROR_SUCCESS != iRet)
			{
				PRINT_BFILE_LINENO_IRET_STR;
			}
		}while(FALSE);

		m_oI2cSendParam.UseSubAddr = TRUE;
		m_oI2cSendParam.SubAddr = RegAddr_IODIRB;
		m_oI2cSendParam.Data = 0x00;	//Output
		eRMstatus = RUASetProperty(m_RmfpMainContext.pRUA, m_uiI2CModuleId, RMI2CPropertyID_Send, &m_oI2cSendParam,
			sizeof(m_oI2cSendParam), 0);
		if(RMFAILED(eRMstatus))
		{
			LOG_BLINE("SetButtonLedIoDir,%s\n", RMstatusToString(eRMstatus));
		}

		//Load alsa(AudioDecoder 1) drv
		strShellCmd = "modprobe em8xxxalsa";
		iRet = system(strShellCmd);
		if(ERROR_SUCCESS != iRet)
		{
			LOG_BLINE("Cmd(%s) ret %d\n", (LPCSTR)strShellCmd, iRet);
		}

#if 1/*added by lxj 2012-9-28*/
		CString strValue;
		CGeneralApp * pApp = getApp();

		SharedPtr <TiXmlDocument2> XmlDoc_sp;
		XmlDoc_sp = pApp->getXmlCfgDoc();
		if(XmlDoc_sp.isNull()){
			iOutRet = ERROR_INVALID_STATE;
			break;
		}
		iRet = XmlDoc_sp->getElementPropertyValue(XML_DispParam_Ele_PATH, PropDesc_VideoMode, OUT strValue, "0");
		if(ERROR_SUCCESS == iRet){
			m_CurVidDispAspectRatio = (DISPLAY_ASPECT_RATIO)(-1);
			switch( (DISPLAY_ASPECT_RATIO)(atoi(strValue)) ){
				case DispAspectRatio_DEFAULT:
				case DispAspectRatio_16_9:
				case DispAspectRatio_4_3:
				case DispAspectRatio_FULL:
					m_VidDispAspectRatioAtNextPlay = (DISPLAY_ASPECT_RATIO)(atoi(strValue));
					break;
				default:
					m_VidDispAspectRatioAtNextPlay = DispAspectRatio_DEFAULT;
					break;
			}
			m_bVidDispAspectRatioAtNextPlay_Valid = TRUE;
			iRet = applyVideoDispAspectRatio(m_VidDispAspectRatioAtNextPlay);
			if(ERROR_SUCCESS != iRet)
			{
				PRINT_BFILE_LINENO_IRET_STR;
			}
		}else{
			PRINT_BFILE_LINENO_IRET_STR;
		}
#endif			

		//get the settting of ShowClosedCaption
		{
			DECLARE_CLS_STACK_BUF_STRING(strVal, 64);
			iRet = SysProp_get(SysProp_KEY_ShowClosedCaption, OUT strVal);
			if(ERR_SUCCESS == iRet)
			{
				m_eShowClosedCaption = (typeof(m_eShowClosedCaption))((INT_t)strVal);
			}
			else
			{
				if(ERR_NOT_FOUND != iRet)
				{
					PRINT_BFILE_LINENO_IRET_STR;
				}
			}
		}
	}while(FALSE);

	return iOutRet;
}

INT_t CMediaSrv::setVideoPosition(INT32_t x, INT32_t y, INT32_t Width, INT32_t Height,
	OUT struct EMhwlibDisplayWindow * pDispOutputWindowToUpdate/* = NULL*/)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	RMuint32 DispMixer = EMHWLIB_MODULE(DispMainMixer, 0);
	RMstatus eRMstatus;
	RMuint32 MainVideoScalerModuleId = EMHWLIB_MODULE(DispMainVideoScaler, 0);
	RMuint32 MixerSrcIndex;
	RMuint32 MixerSrcModuleId;
	struct EMhwlibDisplayWindow DispOutputWindow, OldDispOutWin;
	struct rmfp_main_thread_context_type * pMainContext = &m_RmfpMainContext;
	struct RUA * pRua = pMainContext->pRUA;
	RMint32 tryIntervalMsIfPending = 30;
	RMint32 tryTimesIfPending = 3;
	
	CAutoLock AutoRangeLocker(&m_mutexVideoAudioIoSet); 

	//LOG_BLINE("x=%d,y=%d,w=%d,h=%d\n", x, y, Width, Height);

	do
	{
		//parameters correction
		DispOutputWindow.XPositionMode = EMhwlibDisplayWindowPositionMode_FrontEdgeToBorder;
		DispOutputWindow.X = x;
		DispOutputWindow.YPositionMode = EMhwlibDisplayWindowPositionMode_FrontEdgeToBorder;
		DispOutputWindow.Y = y;
		DispOutputWindow.XMode = EMhwlibDisplayWindowValueMode_Relative;
		DispOutputWindow.YMode = EMhwlibDisplayWindowValueMode_Relative;
		DispOutputWindow.WidthMode = EMhwlibDisplayWindowValueMode_Relative;
		DispOutputWindow.HeightMode = EMhwlibDisplayWindowValueMode_Relative;
		DispOutputWindow.Width = Width;
		DispOutputWindow.Height = Height;

		eRMstatus = RUAExchangeProperty(m_RmfpMainContext.pRUA, DispMixer, RMGenericPropertyID_MixerSourceIndex,
			&MainVideoScalerModuleId, sizeof(MainVideoScalerModuleId), &MixerSrcIndex, sizeof(MixerSrcIndex));
		if(RM_PENDING == eRMstatus)
		{
			LOG_BLINE("RuaExchProp pending\n");
		}
		else if(RMFAILED(eRMstatus))
		{
			iOutRet = ERR_RUA_GET_MIXER_SRC_ID_FAIL;
			break;
		}
		
		MixerSrcModuleId = EMHWLIB_TARGET_MODULE(EMHWLIB_MODULE_CATEGORY(DispMixer), 0 , MixerSrcIndex);
		
		eRMstatus = RUAGetProperty2(m_RmfpMainContext.pRUA, MixerSrcModuleId, RMGenericPropertyID_MixerSourceWindow,
			&OldDispOutWin, sizeof(OldDispOutWin));
		if(RM_PENDING == eRMstatus)
		{
			LOG_BLINE("RuaSetProp pending\n");
		}
		else if(RMFAILED(eRMstatus))
		{
			iOutRet = ERR_RUA_GET_MIXER_SRC_WINDOW_FAIL;
			break;
		}
		/*
		LOG_BLINE("XPositionMode=%d,X=%d,YPositionMode=%d,Y=%d,XMode=%d,YMode=%d,WidthMode=%d,HeightMode=%d,Width=%d,Height=%d\n",
			OldDispOutWin.XPositionMode, OldDispOutWin.X, OldDispOutWin.YPositionMode, OldDispOutWin.Y,
			OldDispOutWin.XMode, OldDispOutWin.YMode, OldDispOutWin.WidthMode, OldDispOutWin.HeightMode,
			OldDispOutWin.Width, OldDispOutWin.Height);
		*/
		if((sizeof(OldDispOutWin) == sizeof(DispOutputWindow)) && (0 == memcmp(&OldDispOutWin, &DispOutputWindow, sizeof(OldDispOutWin))))
		{
			if(pDispOutputWindowToUpdate)
			{
				*pDispOutputWindowToUpdate = DispOutputWindow;
			}
			break;
		}
		
		eRMstatus = RuaSetProp5(m_RmfpMainContext.pRUA, MixerSrcModuleId, RMGenericPropertyID_MixerSourceWindow,
			&DispOutputWindow, sizeof(DispOutputWindow), tryTimesIfPending, tryIntervalMsIfPending);
		if(RM_PENDING == eRMstatus)
		{
			LOG_BLINE("RuaSetProp pending\n");
		}
		else if(RMFAILED(eRMstatus))
		{
			iOutRet = ERR_RUA_SET_MIXER_SRC_WINDOW_FAIL;
			break;
		}

		//OSD scaler output size(OSDScaler,GfxMultiScaler,...)
		{
			RMint32 osdScaler_x, osdScaler_y, osdScaler_w, osdScaler_h;
			struct EMhwlibDisplayWindow curOsdScalerDispWinSize;
			iRet = getScalerOutputWindowSize(pRua, pMainContext->AppOptions.Display.osd_scaler_ID, 
				OUT osdScaler_x, OUT osdScaler_y, OUT osdScaler_w, OUT osdScaler_h, &curOsdScalerDispWinSize);
			if(ERR_SUCCESS == iRet)
			{
				//LOG_BLINE("Expected winsize,x=%d,y=%d,w=%d,h=%d\n", x, y, Width, Height);
				/*
				LOG_BLINE("ScalerModuleId(0x%08x),CurV:x=%d,y=%d,w=%d,h=%d\n", pMainContext->AppOptions.Display.osd_scaler_ID,
					x, y, w, h);
				*/
				if((sizeof(DispOutputWindow) == sizeof(curOsdScalerDispWinSize)) && 
					(0 != memcmp(&DispOutputWindow, &curOsdScalerDispWinSize, sizeof(DispOutputWindow))))
				{
					//not equal, needs set with the new value.
					//LOG_BLINE("New scaler output window size,x=%d,y=%d,w=%d,h=%d\n", x, y, Width, Height);
					/*
					if(HwScaler_Relative_MAX_SIZE_W == Width) {
						x = 0;
					}
					if(HwScaler_Relative_MAX_SIZE_H == Height) {
						y = 0;
					}
					*/
					iRet = setScalerOutputWindowSize(pRua, pMainContext->AppOptions.Display.osd_scaler_ID, 
						x, y, Width, Height);
					if(ERR_SUCCESS != iRet)
					{
						PRINT_BFILE_LINENO_IRET_STR;
					}
				}
			}
			else
			{
				PRINT_BFILE_LINENO_IRET_STR;
			}
		}

		eRMstatus = RuaSetProp5(pRua, DispMixer, RMGenericPropertyID_Validate, NULL, 0, tryTimesIfPending, tryIntervalMsIfPending);
		if(RM_PENDING == eRMstatus)
		{
			LOG_BLINE("RuaSetProp pending\n");
		}
		else if(RMFAILED(eRMstatus))
		{
			iOutRet = ERR_RUA_SET_VALIDATE_FAIL;
			break;
		}

		if(pDispOutputWindowToUpdate)
		{
			*pDispOutputWindowToUpdate = DispOutputWindow;
		}
	}while(FALSE);

	return iOutRet;
}

#if 0/*added by lxj 2013-1-15*/
INT_t CMediaSrv::getVideoPosition(INT32_t *x, INT32_t *y, INT32_t *Width, INT32_t *Height)
{
	INT_t iOutRet = ERROR_SUCCESS;
	RMuint32 DispMixer = EMHWLIB_MODULE(DispMainMixer, 0);
	RMstatus eRMstatus;
	RMuint32 MainVideoScalerModuleId = EMHWLIB_MODULE(DispMainVideoScaler, 0);
	RMuint32 MixerSrcIndex;
	RMuint32 MixerSrcModuleId;
	struct EMhwlibDisplayWindow OldDispOutWin;
	
	CAutoLock AutoRangeLocker(&m_mutexVideoAudioIoSet); 

	do
	{
		if( NULL == x || NULL == y || NULL == Width || NULL == Height ){
			iOutRet = ERROR_INVALID_PARAMETER;
			break;
		}

		eRMstatus = RUAExchangeProperty(m_RmfpMainContext.pRUA, DispMixer, RMGenericPropertyID_MixerSourceIndex,
			&MainVideoScalerModuleId, sizeof(MainVideoScalerModuleId), &MixerSrcIndex, sizeof(MixerSrcIndex));
		if(RM_PENDING == eRMstatus)
		{
			LOG_BLINE("RuaExchProp pending\n");
		}
		else if(RMFAILED(eRMstatus))
		{
			iOutRet = ERR_RUA_GET_MIXER_SRC_ID_FAIL;
			break;
		}
		
		MixerSrcModuleId = EMHWLIB_TARGET_MODULE(EMHWLIB_MODULE_CATEGORY(DispMixer), 0 , MixerSrcIndex);
		
		eRMstatus = RUAGetProperty2(m_RmfpMainContext.pRUA, MixerSrcModuleId, RMGenericPropertyID_MixerSourceWindow,
			&OldDispOutWin, sizeof(OldDispOutWin));
		if(RM_PENDING == eRMstatus)
		{
			LOG_BLINE("RuaSetProp pending\n");
		}
		else if(RMFAILED(eRMstatus))
		{
			iOutRet = ERR_RUA_GET_MIXER_SRC_WINDOW_FAIL;
			break;
		}

		*x = (INT32_t)(OldDispOutWin.X);
		*y = (INT32_t)(OldDispOutWin.Y);
		*Width = (INT32_t)(OldDispOutWin.Width);
		*Height = (INT32_t)(OldDispOutWin.Height);
		
#if 1/*for debug*/
		LOG_BLINE("XPositionMode=%d,X=%d,YPositionMode=%d,Y=%d,XMode=%d,YMode=%d,WidthMode=%d,HeightMode=%d,Width=%d,Height=%d\n",
			OldDispOutWin.XPositionMode, OldDispOutWin.X, OldDispOutWin.YPositionMode, OldDispOutWin.Y,
			OldDispOutWin.XMode, OldDispOutWin.YMode, OldDispOutWin.WidthMode, OldDispOutWin.HeightMode,
			OldDispOutWin.Width, OldDispOutWin.Height);
#endif
	}while(FALSE);

	return iOutRet;
}
#endif

INT_t CMediaSrv::setOsdPosition(INT32_t x, INT32_t y, INT32_t Width, INT32_t Height,
	OUT struct EMhwlibDisplayWindow * pDispOutputWindowToUpdate/* = NULL*/)
{
	return setScalerOutputWindowSize(m_RmfpMainContext.pRUA, EMHWLIB_MODULE(DispOSDScaler, 0), x, y, Width, Height,
		pDispOutputWindowToUpdate);
}

INT_t CMediaSrv::setVideoPositionAsync(INT32_t x, INT32_t y, INT32_t Width, INT32_t Height)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	SharedPtr <CMsgData_setVideoPosition> MsgData_setVideoPos_sp(new CMsgData_setVideoPosition);
	SharedPtr<CMessageQueueItem> ThreadMsg_sp(new CMessageQueueItem);
	SharedPtr <CGenericMsgData> MsgData_sp;

	//LOG_BLINE("setVideoPositionAsync\n");

	do
	{
		if(MsgData_setVideoPos_sp.isNull() || ThreadMsg_sp.isNull())
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}

		MsgData_setVideoPos_sp->m_uiMsgId = MSG_CMD_setVideoPosition;
		MsgData_setVideoPos_sp->x = x;
		MsgData_setVideoPos_sp->y = y;
		MsgData_setVideoPos_sp->Width = Width;
		MsgData_setVideoPos_sp->Height = Height;
		MsgData_sp = MsgData_setVideoPos_sp;
		iRet = ThreadMsg_sp->SetMessageData(MsgData_sp);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}
		iRet = PostMessage(ThreadMsg_sp);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}		
	}while(FALSE);

	return iOutRet;
}

INT_t CMediaSrv::setVideoInputWindowSize(CONST INT32_t inWinX, CONST INT32_t inWinY, CONST INT32_t inWinW, CONST INT32_t inWinH)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	SharedPtr <CMsgData_setVideoInputWindowSize> MsgData_setVideoInputWindowSize_sp(new CMsgData_setVideoInputWindowSize);
	SharedPtr<CMessageQueueItem> ThreadMsg_sp(new CMessageQueueItem);
	SharedPtr <CGenericMsgData> MsgData_sp;

	if(MsgData_setVideoInputWindowSize_sp.isNull() || ThreadMsg_sp.isNull())
	{
		iOutRet = ERROR_OUT_OF_MEMORY;
		goto EXIT_PROC;
	}

	MsgData_setVideoInputWindowSize_sp->m_uiMsgId = MSG_CMD_setVideoInputWindowSize;
	MsgData_setVideoInputWindowSize_sp->inWinX = inWinX;
	MsgData_setVideoInputWindowSize_sp->inWinY = inWinY;
	MsgData_setVideoInputWindowSize_sp->inWinW = inWinW;
	MsgData_setVideoInputWindowSize_sp->inWinH = inWinH;
	MsgData_sp = MsgData_setVideoInputWindowSize_sp;
	iRet = ThreadMsg_sp->SetMessageData(MsgData_sp);
	if(ERROR_SUCCESS != iRet)
	{
		iOutRet = iRet;
		goto EXIT_PROC;
	}
	iRet = SendMessage(ThreadMsg_sp);
	if(ERROR_SUCCESS != iRet)
	{
		iOutRet = iRet;
		goto EXIT_PROC;
	}		

EXIT_PROC:
	return iOutRet;
}

INT_t CMediaSrv::ChangeVolume(INT32_t VolumePercentToChange, INT32_t * pNewVolumePercent,
	BOOL_t * pbVolChanged/* = NULL*/)
{
	INT_t iOutRet = ERROR_SUCCESS;
	RMstatus eRMstatus;
	RMuint32 OldVolumeLevel, NewVolumeLevel;
	RMint32 OldVolumePercent, NewVolumePercent;

	CAutoLock AutoRangeLocker(&m_mutexVideoAudioIoSet); 

	do
	{
		if(pbVolChanged)
		{
			*pbVolChanged = FALSE;
		}

		OldVolumeLevel = 0;
		eRMstatus = getVolumeLevel(&OldVolumeLevel);
		if(RMFAILED(eRMstatus))
		{
			iOutRet = ERR_RUA_GET_VOLUME_FAIL;
			break;
		}
		OldVolumePercent = getPercentFromVolVal(OldVolumeLevel);

		NewVolumePercent = OldVolumePercent + VolumePercentToChange;
		if(0 > NewVolumePercent)
		{
			NewVolumePercent = 0;
		}
		else if(100 < NewVolumePercent)
		{
			NewVolumePercent = 100;
		}

		if(NewVolumePercent != OldVolumePercent)
		{
			NewVolumeLevel = getVolValFromPercent(NewVolumePercent);
			eRMstatus = setVolumeLevel(NewVolumeLevel);
			if(RMFAILED(eRMstatus))
			{
				iOutRet = ERR_RUA_GET_VOLUME_FAIL;
				break;
			}
			if(pbVolChanged)
			{
				*pbVolChanged = TRUE;
			}
		}

		if(pNewVolumePercent)
		{
			*pNewVolumePercent = NewVolumePercent;
		}
	}while(FALSE);

	return iOutRet;
}

/*
ThreadContext: Remote
*/
INT_t CMediaSrv::ChangeVidOutMode(VIDEO_OUTPUT_MODE eVoMode, VIDEO_OUTPUT_MODE * peNewVoMode/* = NULL*/, 
	VIDEO_OUTPUT_MODE * peOldVoMode/* = NULL*/)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	SharedPtr <CMsgData_ChangeVidOutMode> MsgData_ChangeVidOutMode_sp(new CMsgData_ChangeVidOutMode);
	SharedPtr<CMessageQueueItem> ThreadMsg_sp(new CMessageQueueItem);
	SharedPtr <CGenericMsgData> MsgData_sp;

	do
	{
		if(MsgData_ChangeVidOutMode_sp.isNull() || ThreadMsg_sp.isNull())
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}

		MsgData_ChangeVidOutMode_sp->m_uiMsgId = MSG_CMD_ChangeVidOutMode;
		MsgData_ChangeVidOutMode_sp->m_eVoModeToSet = eVoMode;
		MsgData_sp = MsgData_ChangeVidOutMode_sp;
		iRet = ThreadMsg_sp->SetMessageData(MsgData_sp);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}

		iRet = SendMessage(ThreadMsg_sp);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}
		if(peNewVoMode)
		{
			*peNewVoMode = MsgData_ChangeVidOutMode_sp->m_eNewVoMode;
		}
		if(peOldVoMode)
		{
			*peOldVoMode = MsgData_ChangeVidOutMode_sp->m_eOldVoMode;
		}
		if(ERROR_SUCCESS != MsgData_sp->m_iOutRet)
		{
			iOutRet = MsgData_sp->m_iOutRet;
			break;
		}
	}while(FALSE);	

	return iOutRet;
}

/*
ThreadContext: Remote
*/
INT_t CMediaSrv::ChangeVidOutModeAsync(VIDEO_OUTPUT_MODE eVoMode, VIDEO_OUTPUT_MODE * peNewVoMode/* = NULL*/, 
	VIDEO_OUTPUT_MODE * peOldVoMode/* = NULL*/)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	SharedPtr <CMsgData_ChangeVidOutMode> MsgData_ChangeVidOutMode_sp(new CMsgData_ChangeVidOutMode);
	SharedPtr<CMessageQueueItem> ThreadMsg_sp(new CMessageQueueItem);
	SharedPtr <CGenericMsgData> MsgData_sp;

	do
	{
		if(MsgData_ChangeVidOutMode_sp.isNull() || ThreadMsg_sp.isNull())
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}

		MsgData_ChangeVidOutMode_sp->m_uiMsgId = MSG_CMD_ChangeVidOutMode;
		MsgData_ChangeVidOutMode_sp->m_eVoModeToSet = eVoMode;
		MsgData_sp = MsgData_ChangeVidOutMode_sp;
		iRet = ThreadMsg_sp->SetMessageData(MsgData_sp);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}
		if(peOldVoMode)
		{			
			CAutoLock AutoRangeLocker(&m_SharedDataMutex);
			*peOldVoMode = m_eVoMode;
		}
		if(peNewVoMode)
		{
			*peNewVoMode = eVoMode;
		}

		{			
			VIDEO_OUTPUT_MODE eCurVoMode;
			{
				CAutoLock AutoRangeLocker(&m_mutexVideoAudioIoSet);
				CAutoLock AutoRangeLocker2(&m_SharedDataMutex);				
				eCurVoMode = m_eVoMode;
			}

			if((VO_MODE_SPLIT_MODE_MIN_BOUNDARY < eCurVoMode && eCurVoMode < VO_MODE_SPLIT_MODE_MAX_BOUNDARY) ||
				(VO_MODE_SPLIT_MODE_MIN_BOUNDARY < eVoMode && eVoMode < VO_MODE_SPLIT_MODE_MAX_BOUNDARY))
			{
				iRet = Stop();
				if(ERR_SUCCESS != iRet)
				{
					PRINT_BFILE_LINENO_IRET_STR;
				}
			}
		}

		iRet = PostMessage(ThreadMsg_sp);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}
	}while(FALSE);

	return iOutRet;
}

/*
ThreadContext: local
*/
INT_t CMediaSrv::ChangeVideoOutputMode(VIDEO_OUTPUT_MODE eVoMode, VIDEO_OUTPUT_MODE * peNewVoMode/* = NULL*/, 
	VIDEO_OUTPUT_MODE * peOldVoMode/* = NULL*/)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	RMstatus eRMstatus = RM_OK;
	struct rmfp_main_thread_context_type *pMainContext = &m_RmfpMainContext;
	struct RUA * pRua = pMainContext->pRUA;
	CGeneralApp * pApp = getApp();
	RMuint32 vcrScalerModuleId = EMHWLIB_MODULE(DispVCRMultiScaler, 0);
	RMuint32 osdScalerModuleId = EMHWLIB_MODULE(DispOSDScaler, 0);
	RMint32 tryTimesIfPending = 3;
	RMint32 tryIntervalMs = 30;
	RMbool bPersistentSurface = TRUE;
	RMbool bEnable = FALSE;
	RMbool bNeedValidate = TRUE;
	RMuint32 dispMainMixerModuleId = EMHWLIB_MODULE(DispMainMixer, 0);
	RMint32 doSetVidOutputModeTimes = 0;

	CAutoLock AutoRangeLocker(&m_mutexVideoAudioIoSet);

	do
	{		
		if(peOldVoMode)
		{
			*peOldVoMode = m_eVoMode;
		}
		if(peNewVoMode)
		{
			*peNewVoMode = m_eVoMode;
		}
		
		if(VO_MODE_NotSet == eVoMode)	//read back current value
		{
			break;
		}

		if(eVoMode == m_eVoMode)
		{
		}
		else if((VO_MODE_SPLIT_MODE_MIN_BOUNDARY < eVoMode && eVoMode < VO_MODE_SPLIT_MODE_MAX_BOUNDARY) || 
			(VO_MODE_SPLIT_MODE_MIN_BOUNDARY < m_eVoMode && m_eVoMode < VO_MODE_SPLIT_MODE_MAX_BOUNDARY))
		{
			{
				CAutoLock AutoRangeLocker(&m_SharedDataMutex);
				if(PLAY_STAT_IDLE != m_iPlayStatus)
				{
					iOutRet = ERROR_INVALID_STATE;
					break;
				}
			}
		}
		
		if(FALSE == ((VO_MODE_START_VALUE < eVoMode && VO_MODE_END_VALUE > eVoMode) ||
			(VO_MODE_SPLIT_MODE_MIN_BOUNDARY < eVoMode && VO_MODE_SPLIT_MODE_MAX_BOUNDARY > eVoMode)))
		{
			iOutRet = ERROR_INVALID_PARAMETER;
			break;
		}

		//close the old hdmi
		eRMstatus = rmoutput_close_hdmi_chip(pMainContext->dh_info, 
			(pMainContext->display_opt->hdmi_options.APIVersion < 5) || (! pMainContext->display_opt->hdmi_options.keep_hdmi));
		if(RMFAILED(eRMstatus))
		{
			PRINT_BFILE_LINENO_RMSTATUS;
		}
		//init
		eRMstatus = InitDisplayContext();
		if(RMFAILED(eRMstatus))
		{
			PRINT_BFILE_LINENO_RMSTATUS;
		}

		while(TRUE)
		{
			pMainContext->display_opt->output_enable_mask = RMOUTPUT_OUT_HDMI | /*RMOUTPUT_OUT_CAV | */RMOUTPUT_OUT_VGA | RMOUTPUT_OUT_CVBS;
			pMainContext->display_opt->HD.RouteSourceModuleID = DispMainMixer;
			pMainContext->display_opt->HD.VIC = 0;
			pMainContext->display_opt->sd_component = FALSE;
			pMainContext->display_opt->cav_1080p = FALSE;
			pMainContext->display_opt->SD.RouteSourceModuleID = DispMainMixer;
			pMainContext->AppOptions.Display.scaler_ID = DispMainVideoScaler;
			pMainContext->pOptions->video_options.VideoScalerID = DispMainVideoScaler;
			pMainContext->AppOptions.Display.route = RMFPRoute_Main;

			if(VO_MODE_HDMI_720p50 == eVoMode)
			{
				pMainContext->display_opt->output_enable_mask = RMOUTPUT_OUT_HDMI | RMOUTPUT_OUT_VGA | RMOUTPUT_OUT_CVBS;
				pMainContext->display_opt->HD.TimingInfo.Standard = EMhwlibTVStandard_HDMI_720p50;
			}
			else if(VO_MODE_HDMI_1080i50 == eVoMode)
			{			
				pMainContext->display_opt->output_enable_mask = RMOUTPUT_OUT_HDMI | RMOUTPUT_OUT_VGA | RMOUTPUT_OUT_CVBS;
				pMainContext->display_opt->HD.TimingInfo.Standard = EMhwlibTVStandard_HDMI_1080i50;
			}
			else if(VO_MODE_HDMI_1080p50 == eVoMode)
			{
				pMainContext->display_opt->output_enable_mask = RMOUTPUT_OUT_HDMI | RMOUTPUT_OUT_VGA | RMOUTPUT_OUT_CVBS;
				pMainContext->display_opt->HD.TimingInfo.Standard = EMhwlibTVStandard_HDMI_1080p50;
			}
			else if(VO_MODE_HDMI_480p60 == eVoMode)
			{
				pMainContext->display_opt->HD.TimingInfo.Standard = EMhwlibTVStandard_HDMI_480p59;
			}
			else if(VO_MODE_HDMI_480i60 == eVoMode)
			{
				//MP500, enables CVBS
				pMainContext->display_opt->output_enable_mask = RMOUTPUT_OUT_HDMI | RMOUTPUT_OUT_CVBS;
				pMainContext->display_opt->HD.TimingInfo.Standard = EMhwlibTVStandard_HDMI_480i59;
			}
			else if(VO_MODE_HDMI_576p50 == eVoMode)
			{
				//MP500, enables HDMI,CAV,CVBS
				pMainContext->display_opt->HD.TimingInfo.Standard = EMhwlibTVStandard_HDMI_576p50;
			}
			else if(VO_MODE_640x480p59 == eVoMode)
			{
				//MP500, enables nothing
				pMainContext->display_opt->output_enable_mask = RMOUTPUT_OUT_HDMI | RMOUTPUT_OUT_VGA;
				pMainContext->display_opt->HD.TimingInfo.Standard = EMhwlibTVStandard_HDMI_640x480p59;
			}
			else if(VO_MODE_640x480p60 == eVoMode)
			{
				//MP500, enables CVBS
				pMainContext->display_opt->output_enable_mask = RMOUTPUT_OUT_HDMI | RMOUTPUT_OUT_VGA;
				pMainContext->display_opt->HD.TimingInfo.Standard = EMhwlibTVStandard_HDMI_640x480p60;
			}
			else if(VO_MODE_HDMI_480p59 == eVoMode)
			{
				//MP500, enables HDMI,CAV,CVBS
				pMainContext->display_opt->HD.TimingInfo.Standard = EMhwlibTVStandard_HDMI_480p59;
			}
			else if(VO_MODE_HDMI_720p59 == eVoMode)
			{
				//MP500, enables HDMI,CAV,CVBS
				pMainContext->display_opt->output_enable_mask = RMOUTPUT_OUT_HDMI | RMOUTPUT_OUT_VGA | RMOUTPUT_OUT_CVBS;
				pMainContext->display_opt->HD.TimingInfo.Standard = EMhwlibTVStandard_HDMI_720p59;
			}
			else if(VO_MODE_HDMI_1080i59 == eVoMode)
			{
				//MP500, enables HDMI,CAV,CVBS
				pMainContext->display_opt->HD.TimingInfo.Standard = EMhwlibTVStandard_HDMI_1080i59;
			}
			else if(VO_MODE_2880x240 == eVoMode)
			{
				//MP500, enables nothing
				pMainContext->display_opt->output_enable_mask = RMOUTPUT_OUT_HDMI;
				pMainContext->display_opt->HD.TimingInfo.Standard = EMhwlibTVStandard_HDMI_2880x240p60;
			}
			else if(VO_MODE_1440x480p59 == eVoMode)
			{
				//MP500, enables HDMI
				pMainContext->display_opt->output_enable_mask = RMOUTPUT_OUT_HDMI;
				pMainContext->display_opt->HD.TimingInfo.Standard = EMhwlibTVStandard_HDMI_1440x480p59;
			}
			else if(VO_MODE_1440x480p60 == eVoMode)
			{
				//MP500, enables HDMI
				pMainContext->display_opt->output_enable_mask = RMOUTPUT_OUT_HDMI;
				pMainContext->display_opt->HD.TimingInfo.Standard = EMhwlibTVStandard_HDMI_1440x480p60;
			}
			else if(VO_MODE_HDMI_1080p59 == eVoMode)
			{
				//MP500, enables HDMI,CAV,CVBS
				pMainContext->display_opt->output_enable_mask = RMOUTPUT_OUT_HDMI | RMOUTPUT_OUT_VGA | RMOUTPUT_OUT_CVBS;
				pMainContext->display_opt->HD.TimingInfo.Standard = EMhwlibTVStandard_HDMI_1080p59;
			}
			/*
			else if(VO_MODE_720x288p == eVoMode)
			{
				//MP500, enables nothing
				pMainContext->display_opt->output_enable_mask = RMOUTPUT_OUT_HDMI;
				pMainContext->display_opt->HD.TimingInfo.Standard = EMhwlibTVStandard_HDMI_288p50;
			}
			*/
			/*		
			else if(VO_MODE_2880x576i50 == eVoMode)
			{
				//MP500, enables nothing
				pMainContext->display_opt->output_enable_mask = RMOUTPUT_OUT_HDMI;
				pMainContext->display_opt->HD.TimingInfo.Standard = EMhwlibTVStandard_HDMI_2880x576i50;
			}
			*/
			else if(VO_MODE_HDMI_2880x288p50 == eVoMode)
			{
				//MP500, enables HDMI
				pMainContext->display_opt->output_enable_mask = RMOUTPUT_OUT_HDMI;
				pMainContext->display_opt->HD.TimingInfo.Standard = EMhwlibTVStandard_HDMI_2880x288p50;
			}
			else if(VO_MODE_1440x576i50 == eVoMode)
			{
				//MP500, enables HDMI
				pMainContext->display_opt->output_enable_mask = RMOUTPUT_OUT_HDMI;
				pMainContext->display_opt->HD.TimingInfo.Standard = EMhwlibTVStandard_HDMI_1440x576i50;
			}
			else if(VO_MODE_HDMI_1080p23 == eVoMode)
			{
				//MP500, enables HDMI,CVBS
				pMainContext->display_opt->output_enable_mask = RMOUTPUT_OUT_HDMI | RMOUTPUT_OUT_CAV;
				pMainContext->display_opt->cav_1080p = TRUE;
				pMainContext->display_opt->HD.TimingInfo.Standard = EMhwlibTVStandard_HDMI_1080p23;
			}
			else if(VO_MODE_1080p24 == eVoMode)
			{
				//MP500, enables HDMI,CVBS
				pMainContext->display_opt->output_enable_mask = RMOUTPUT_OUT_HDMI | RMOUTPUT_OUT_CAV;
				pMainContext->display_opt->cav_1080p = TRUE;
				pMainContext->display_opt->HD.TimingInfo.Standard = EMhwlibTVStandard_HDMI_1080p24;
			}
			else if(VO_MODE_1080p25 == eVoMode)
			{
				//MP500, enables HDMI,CVBS
				pMainContext->display_opt->output_enable_mask = RMOUTPUT_OUT_HDMI | RMOUTPUT_OUT_CAV;
				pMainContext->display_opt->cav_1080p = TRUE;
				pMainContext->display_opt->HD.TimingInfo.Standard = EMhwlibTVStandard_HDMI_1080p25;
			}
			else if(VO_MODE_1080p29 == eVoMode)
			{
				//MP500, enables HDMI,CVBS
				pMainContext->display_opt->output_enable_mask = RMOUTPUT_OUT_HDMI | RMOUTPUT_OUT_CAV;
				pMainContext->display_opt->cav_1080p = TRUE;
				pMainContext->display_opt->HD.TimingInfo.Standard = EMhwlibTVStandard_HDMI_1080p29;
			}
			else if(VO_MODE_1080p30 == eVoMode)
			{
				//MP500, enables HDMI,CVBS
				pMainContext->display_opt->output_enable_mask = RMOUTPUT_OUT_HDMI | RMOUTPUT_OUT_CAV;
				pMainContext->display_opt->cav_1080p = TRUE;
				pMainContext->display_opt->HD.TimingInfo.Standard = EMhwlibTVStandard_HDMI_1080p30;
			}
			else if(VO_MODE_2880x480p59 == eVoMode)
			{
				//MP500, enables HDMI
				pMainContext->display_opt->output_enable_mask = RMOUTPUT_OUT_HDMI;
				pMainContext->display_opt->HD.TimingInfo.Standard = EMhwlibTVStandard_HDMI_2880x480p59;
			}
			else if(VO_MODE_2880x480p == eVoMode)
			{
				//MP500, enables HDMI
				pMainContext->display_opt->output_enable_mask = RMOUTPUT_OUT_HDMI;
				pMainContext->display_opt->HD.TimingInfo.Standard = EMhwlibTVStandard_HDMI_2880x480p60;
			}
			else if(VO_MODE_2880x576p50 == eVoMode)
			{
				//MP500, enables HDMI
				pMainContext->display_opt->output_enable_mask = RMOUTPUT_OUT_HDMI;
				pMainContext->display_opt->HD.TimingInfo.Standard = EMhwlibTVStandard_HDMI_2880x576p50;
			}
			else if(VO_MODE_1080i50_1250 == eVoMode)
			{
				//MP500, enables HDMI
				pMainContext->display_opt->output_enable_mask = RMOUTPUT_OUT_HDMI;
				pMainContext->display_opt->HD.TimingInfo.Standard = EMhwlibTVStandard_HDMI_1080i50_1250;
			}
			else if(VO_MODE_1080i100 == eVoMode)
			{
				//MP500, enables HDMI
				pMainContext->display_opt->output_enable_mask = RMOUTPUT_OUT_HDMI;
				pMainContext->display_opt->HD.TimingInfo.Standard = EMhwlibTVStandard_HDMI_1080i100;
			}
			else if(VO_MODE_720p100 == eVoMode)
			{
				//MP500, enables HDMI
				pMainContext->display_opt->output_enable_mask = RMOUTPUT_OUT_HDMI | RMOUTPUT_OUT_VGA;
				pMainContext->display_opt->HD.TimingInfo.Standard = EMhwlibTVStandard_HDMI_720p100;
			}
			else if(VO_MODE_576p100 == eVoMode)
			{
				//MP500, enables HDMI
				pMainContext->display_opt->output_enable_mask = RMOUTPUT_OUT_HDMI | RMOUTPUT_OUT_VGA;
				pMainContext->display_opt->HD.TimingInfo.Standard = EMhwlibTVStandard_HDMI_576p100;
			}
			else if(VO_MODE_576i100 == eVoMode)
			{
				//MP500, enables nothing
				pMainContext->display_opt->output_enable_mask = RMOUTPUT_OUT_HDMI | RMOUTPUT_OUT_VGA;
				pMainContext->display_opt->HD.TimingInfo.Standard = EMhwlibTVStandard_HDMI_576i100;
			}
			else if(VO_MODE_1080i119 == eVoMode)
			{
				//MP500, enables HDMI
				pMainContext->display_opt->HD.TimingInfo.Standard = EMhwlibTVStandard_HDMI_1080i119;
			}
			else if(VO_MODE_1080i120 == eVoMode)
			{
				//MP500, enables HDMI
				pMainContext->display_opt->output_enable_mask = RMOUTPUT_OUT_HDMI | RMOUTPUT_OUT_VGA;
				pMainContext->display_opt->HD.TimingInfo.Standard = EMhwlibTVStandard_HDMI_1080i120;
			}
			else if(VO_MODE_HDMI_CAV_1080p60 == eVoMode)
			{
				//MP500, enables HDMI,CAV,CVBS
				pMainContext->display_opt->output_enable_mask = RMOUTPUT_OUT_HDMI | RMOUTPUT_OUT_CAV | RMOUTPUT_OUT_CVBS;
				pMainContext->display_opt->HD.TimingInfo.Standard = EMhwlibTVStandard_HDMI_1080p60;
				pMainContext->display_opt->cav_1080p = TRUE;
			}
			else if(VO_MODE_HDMI_CAV_1080i60 == eVoMode)
			{
				//MP500, enables HDMI,CAV,CVBS
				pMainContext->display_opt->output_enable_mask = RMOUTPUT_OUT_HDMI | RMOUTPUT_OUT_CAV | RMOUTPUT_OUT_CVBS;
				pMainContext->display_opt->HD.TimingInfo.Standard = EMhwlibTVStandard_HDMI_1080i60;
			}
			else if(VO_MODE_HDMI_CAV_720p60 == eVoMode)
			{
				//MP500, enables HDMI,CAV,CVBS
				pMainContext->display_opt->output_enable_mask = RMOUTPUT_OUT_HDMI | RMOUTPUT_OUT_CAV | RMOUTPUT_OUT_CVBS;
				pMainContext->display_opt->HD.TimingInfo.Standard = EMhwlibTVStandard_HDMI_720p60;
			}
			else if(VO_MODE_COMPONENT_480p60 == eVoMode)
			{
				//MP500, enables HDMI,CAV,CVBS
				pMainContext->display_opt->output_enable_mask = RMOUTPUT_OUT_HDMI | RMOUTPUT_OUT_CAV | RMOUTPUT_OUT_CVBS;
				pMainContext->display_opt->HD.TimingInfo.Standard = EMhwlibTVStandard_HDMI_480p59;
			}
			else if(VO_MODE_COMPONENT_1080p50 == eVoMode)
			{
				//MP500, enables HDMI,CAV,CVBS
				pMainContext->display_opt->output_enable_mask = RMOUTPUT_OUT_HDMI | RMOUTPUT_OUT_CAV | RMOUTPUT_OUT_CVBS;
				pMainContext->display_opt->HD.TimingInfo.Standard = EMhwlibTVStandard_1080p50;
				pMainContext->display_opt->cav_1080p = TRUE;
			}
			else if(VO_MODE_COMPONENT_1080p60 == eVoMode)
			{
				//MP500, enables HDMI,CAV,CVBS
				pMainContext->display_opt->output_enable_mask = RMOUTPUT_OUT_HDMI | RMOUTPUT_OUT_CAV | RMOUTPUT_OUT_CVBS;
				pMainContext->display_opt->cav_1080p = TRUE;
				pMainContext->display_opt->HD.TimingInfo.Standard = EMhwlibTVStandard_1080p60;
			}
			else if(VO_MODE_COMPONENT_1080i60 == eVoMode)
			{
				//MP500, enables HDMI,CAV,CVBS
				pMainContext->display_opt->output_enable_mask = RMOUTPUT_OUT_HDMI | RMOUTPUT_OUT_CAV | RMOUTPUT_OUT_CVBS;
				pMainContext->display_opt->HD.TimingInfo.Standard = EMhwlibTVStandard_1080i60;
			}
			else if(VO_MODE_COMPONENT_720p50 == eVoMode)
			{
				//MP500, enables HDMI,CAV,CVBS
				pMainContext->display_opt->output_enable_mask = RMOUTPUT_OUT_HDMI | RMOUTPUT_OUT_CAV | RMOUTPUT_OUT_CVBS;
				pMainContext->display_opt->HD.TimingInfo.Standard = EMhwlibTVStandard_720p50;
			}
			else if(VO_MODE_COMPONENT_720p60 == eVoMode)
			{
				//MP500, enables HDMI,CAV,CVBS
				pMainContext->display_opt->output_enable_mask = RMOUTPUT_OUT_HDMI | RMOUTPUT_OUT_CAV | RMOUTPUT_OUT_CVBS;
				pMainContext->display_opt->HD.TimingInfo.Standard = EMhwlibTVStandard_720p60;
			}
			else if(VO_MODE_COMPONENT_1080i50 == eVoMode)
			{
				//MP500, enables HDMI,CAV,CVBS
				pMainContext->display_opt->output_enable_mask = RMOUTPUT_OUT_HDMI | RMOUTPUT_OUT_CAV | RMOUTPUT_OUT_CVBS;
				pMainContext->display_opt->HD.TimingInfo.Standard = EMhwlibTVStandard_1080i50;
			}
			else if(VO_MODE_COMPONENT_576p50 == eVoMode)
			{
				//MP500, enables HDMI,CAV,CVBS
				pMainContext->display_opt->output_enable_mask = RMOUTPUT_OUT_HDMI | RMOUTPUT_OUT_CAV | RMOUTPUT_OUT_CVBS;
				pMainContext->display_opt->HD.TimingInfo.Standard = EMhwlibTVStandard_576p50;
			}
			else if(VO_MODE_VESA_720x400x70 == eVoMode)
			{
				//Not exist in MP500
				pMainContext->display_opt->HD.TimingInfo.Standard = EMhwlibTVStandard_VESA_720x400x70;
			}
			else if(VO_MODE_VESA_800x600x60 == eVoMode)
			{
				//MP500, enables VGA
				pMainContext->display_opt->output_enable_mask = RMOUTPUT_OUT_VGA;
				pMainContext->display_opt->HD.TimingInfo.Standard = EMhwlibTVStandard_VESA_800x600x60;
			}
			else if(VO_MODE_VESA_1024x768x60 == eVoMode)
			{
				//MP500, enables VGA
				pMainContext->display_opt->output_enable_mask = RMOUTPUT_OUT_VGA;
				pMainContext->display_opt->HD.TimingInfo.Standard = EMhwlibTVStandard_VESA_1024x768x60;
			}
			else if(VO_MODE_VESA_1280x768x60 == eVoMode)
			{
				//MP500, enables VGA
				pMainContext->display_opt->output_enable_mask = RMOUTPUT_OUT_VGA;
				pMainContext->display_opt->HD.TimingInfo.Standard = EMhwlibTVStandard_VESA_1280x768x60;
			}
			else if(VO_MODE_VESA_1280x1024x60 == eVoMode)
			{
				//MP500, enables VGA
				pMainContext->display_opt->output_enable_mask = RMOUTPUT_OUT_VGA;
				pMainContext->display_opt->HD.TimingInfo.Standard = EMhwlibTVStandard_VESA_1280x1024x60;
			}
			else if(VO_MODE_VESA_1360x768x60 == eVoMode)
			{
				//MP500, enables VGA
				pMainContext->display_opt->output_enable_mask = RMOUTPUT_OUT_VGA;
				pMainContext->display_opt->HD.TimingInfo.Standard = EMhwlibTVStandard_VESA_1360x768x60;
			}
			else if(VO_MODE_VESA_1366x768x60 == eVoMode)
			{
				//MP500 does not support this mode.
				pMainContext->display_opt->output_enable_mask = RMOUTPUT_OUT_HDMI | RMOUTPUT_OUT_VGA;
				pMainContext->display_opt->HD.TimingInfo.Standard = EMhwlibTVStandard_VESA_1366x768x60;
			}
			else if(VO_MODE_VESA_1600x1200x60 == eVoMode)
			{
				//MP500, enables VGA
				pMainContext->display_opt->output_enable_mask = RMOUTPUT_OUT_VGA;
				pMainContext->display_opt->HD.TimingInfo.Standard = EMhwlibTVStandard_VESA_1600x1200x60;
			}
			else if(VO_MODE_RGB_1080i50 == eVoMode)
			{
				//MP500, enables VGA
				pMainContext->display_opt->output_enable_mask = RMOUTPUT_OUT_HDMI | RMOUTPUT_OUT_VGA | RMOUTPUT_OUT_CVBS;
				pMainContext->display_opt->HD.TimingInfo.Standard = EMhwlibTVStandard_HDMI_1080i50;
			}
			else if(VO_MODE_CVBS == eVoMode)
			{
				//MP500, enables CVBS
				pMainContext->display_opt->output_enable_mask = RMOUTPUT_OUT_CVBS;
				pMainContext->display_opt->HD.TimingInfo.PixelClock = 0;  // invalidate timing parameter
				pMainContext->display_opt->HD.TimingInfo.Standard = EMhwlibTVStandard_NTSC_M;
				pMainContext->display_opt->SD.TimingInfo.PixelClock = 0;  // invalidate timing parameter
				pMainContext->display_opt->SD.TimingInfo.Standard = EMhwlibTVStandard_NTSC_M;
			}
			/*
			else if(VO_MODE_HDMI_2160p25 == eVoMode)
			{
				pMainContext->display_opt->output_enable_mask = RMOUTPUT_OUT_HDMI;
				pMainContext->display_opt->HD.TimingInfo.Standard = EMhwlibTVStandard_HDMI_2160p25;
			}
			else if(VO_MODE_HDMI_4K2Kp23 == eVoMode)
			{
				pMainContext->display_opt->output_enable_mask = RMOUTPUT_OUT_HDMI;
				pMainContext->display_opt->HD.TimingInfo.Standard = EMhwlibTVStandard_HDMI_4K2Kp23;
			}
			else if(VO_MODE_HDMI_4K2Kp24 == eVoMode)
			{
				pMainContext->display_opt->output_enable_mask = RMOUTPUT_OUT_HDMI;
				pMainContext->display_opt->HD.TimingInfo.Standard = EMhwlibTVStandard_HDMI_4K2Kp24;
			}
			*/
			else if(VO_MODE_SPLIT_HdmiVcr_VgaMain == eVoMode)
			{
				//opts
				pMainContext->display_opt->output_enable_mask = RMOUTPUT_OUT_HDMI | RMOUTPUT_OUT_VGA;
				pMainContext->display_opt->sd_component = TRUE;
				//HD
				pMainContext->display_opt->HD.RouteSourceModuleID = DispVCRMultiScaler;
				pMainContext->display_opt->HD.TimingInfo.Standard = EMhwlibTVStandard_HDMI_720p60;
				//SD
				pMainContext->display_opt->SD.RouteSourceModuleID = DispMainMixer;
				pMainContext->display_opt->SD.TimingInfo.Standard = EMhwlibTVStandard_VESA_1024x768x60;
				//Video opts
				pMainContext->AppOptions.Display.scaler_ID = DispVCRMultiScaler;
				pMainContext->pOptions->video_options.VideoScalerID = DispVCRMultiScaler;
				pMainContext->AppOptions.Display.route = RMFPRoute_Secondary;
			}
			else if(VO_MODE_SPLIT_HdmiVcr_1080p60_VgaMain == eVoMode)
			{
				//opts
				pMainContext->display_opt->output_enable_mask = RMOUTPUT_OUT_HDMI | RMOUTPUT_OUT_VGA;
				pMainContext->display_opt->sd_component = TRUE;
				//HD
				pMainContext->display_opt->HD.RouteSourceModuleID = DispVCRMultiScaler;
				pMainContext->display_opt->HD.TimingInfo.Standard = EMhwlibTVStandard_HDMI_1080p60;
				//SD
				pMainContext->display_opt->SD.RouteSourceModuleID = DispMainMixer;
				pMainContext->display_opt->SD.TimingInfo.Standard = EMhwlibTVStandard_VESA_1024x768x60;
				//Video opts
				pMainContext->AppOptions.Display.scaler_ID = DispVCRMultiScaler;
				pMainContext->pOptions->video_options.VideoScalerID = DispVCRMultiScaler;
				pMainContext->AppOptions.Display.route = RMFPRoute_Secondary;
			}
			else if(VO_MODE_SPLIT_HdmiMain_1080p60_VgaVcr == eVoMode)
			{
				//opts
				pMainContext->display_opt->output_enable_mask = RMOUTPUT_OUT_HDMI | RMOUTPUT_OUT_VGA;
				pMainContext->display_opt->sd_component = TRUE;
				//HD
				pMainContext->display_opt->HD.RouteSourceModuleID = DispMainMixer;
				pMainContext->display_opt->HD.TimingInfo.Standard = EMhwlibTVStandard_HDMI_1080p60;
				//SD
				pMainContext->display_opt->SD.RouteSourceModuleID = DispVCRMultiScaler;
				pMainContext->display_opt->SD.TimingInfo.Standard = EMhwlibTVStandard_VESA_1024x768x60;
				//Video opts
				pMainContext->AppOptions.Display.scaler_ID = DispMainVideoScaler;
				pMainContext->pOptions->video_options.VideoScalerID = DispMainVideoScaler;
				pMainContext->AppOptions.Display.route = RMFPRoute_Main;
			}
			else
			{
				iOutRet = ERROR_NOT_SUPPORTED;
			}

			if(ERROR_SUCCESS == iOutRet)
			{
				break;
			}
			else if(ERROR_NOT_SUPPORTED == iOutRet)
			{
				//try next mode
				iOutRet = ERROR_SUCCESS;
				eVoMode = (typeof(eVoMode))(eVoMode + 1);
				if(FALSE == (VO_MODE_START_VALUE < eVoMode && eVoMode < VO_MODE_END_VALUE))
				{
					eVoMode = (typeof(eVoMode))(VO_MODE_START_VALUE + 1);
				}
			}
			else	//err
			{
				break;
			}
		}
		if(ERROR_SUCCESS != iOutRet)
		{
			break;
		}

DO_SET_VIDEO_OUTPUT_MODE:
		if(VO_MODE_SPLIT_HdmiMain_1080p60_VgaVcr == eVoMode)
		{
			bNeedValidate = TRUE;
			eRMstatus = Scaler_setSourceStateInMixer(pRua, vcrScalerModuleId, EMhwlibMixerSourceState_Slave, bNeedValidate);
			if(RMFAILED(eRMstatus))
			{
				PRINT_BFILE_LINENO_RMSTATUS;
			}
			
			bEnable = FALSE;
			bNeedValidate = TRUE;
			eRMstatus = Scaler_Enable(pRua, vcrScalerModuleId, bEnable, bNeedValidate);
			if(RMFAILED(eRMstatus))
			{
				PRINT_BFILE_LINENO_RMSTATUS;
			}
			
			bEnable = FALSE;
			bNeedValidate = TRUE;
			eRMstatus = Scaler_SrcTargetModuleInMixer_Enable(pRua, vcrScalerModuleId, bEnable, bNeedValidate);
			if(RMFAILED(eRMstatus))
			{
				PRINT_BFILE_LINENO_RMSTATUS;
			}
		}
		
		iRet = setVideoOutputMode();
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}

		if(VO_MODE_SPLIT_HdmiMain_1080p60_VgaVcr == eVoMode)
		{
			//Connect the OSD surface to DispVCRMultiScaler
			RMbool bWaitForDispEvtIfPending = TRUE;
			RMuint32 OsdScalerModuleId;
			RMuint32 MainMixerModuleId = EMHWLIB_MODULE(DispMainMixer, 0);
			RMuint32 OsdSurfaceAddr;
			RMuint32 VcrScalerInVcrMixerSrcIndex = 0;
			RMuint32 OsdSaclerInMainMixerSrcIndex = 0;
			RMuint32 VcrScalerInMainMixerSrcIndex = 0;
			RMuint32 OsdScalerMixerSrcTargetModuleId = 0;
			RMuint32 VcrMixerSrcTargetModuleId;
			enum EMhwlibMixerSourceState MixerSrcState = EMhwlibMixerSourceState_Master;
			RMuint32 NullSurfaceAddr = 0;
			RMuint32 vcrScalerSurfaceAddr = 0;
			
			do
			{				
				eRMstatus = InitVcrScaler();
				if(RMFAILED(eRMstatus))
				{
					PRINT_BFILE_LINENO_RMSTATUS;
					break;
				}

				eRMstatus = DCCGetScalerModuleID(m_RmfpMainContext.pDCC, DCCRoute_Main, DCCSurface_OSD, 0, &OsdScalerModuleId);
				if(RMFAILED(eRMstatus))
				{
					PRINT_BFILE_LINENO_RMSTATUS;
					break;
				}
				eRMstatus = RUAGetProperty2(m_RmfpMainContext.pRUA, OsdScalerModuleId, RMGenericPropertyID_Surface,
					&OsdSurfaceAddr, sizeof(OsdSurfaceAddr));
				if(RMFAILED(eRMstatus))
				{
					PRINT_BFILE_LINENO_RMSTATUS;
					break;
				}
				//G_BLINE("osdScalerSurfaceAddr=0x%08x\n", OsdSurfaceAddr);

				eRMstatus = RUAExchangeProperty(m_RmfpMainContext.pRUA, MainMixerModuleId, RMGenericPropertyID_MixerSourceIndex,
					&OsdScalerModuleId, sizeof(OsdScalerModuleId), (&OsdSaclerInMainMixerSrcIndex), sizeof(OsdSaclerInMainMixerSrcIndex));
				if(RMFAILED(eRMstatus))
				{
					PRINT_BFILE_LINENO_RMSTATUS;
					break;
				}
				eRMstatus = RUAExchangeProperty(m_RmfpMainContext.pRUA, MainMixerModuleId, RMGenericPropertyID_MixerSourceIndex,
					&vcrScalerModuleId, sizeof(vcrScalerModuleId), (&VcrScalerInMainMixerSrcIndex), sizeof(VcrScalerInMainMixerSrcIndex));
				if(RMFAILED(eRMstatus))
				{
					PRINT_BFILE_LINENO_RMSTATUS;
					break;
				}
				//LOG_BLINE("VcrScalerInMainMixerSrcIndex=%d\n", VcrScalerInMainMixerSrcIndex);				
				VcrMixerSrcTargetModuleId = EMHWLIB_TARGET_MODULE(EMHWLIB_MODULE_CATEGORY(MainMixerModuleId), 0, VcrScalerInMainMixerSrcIndex);			
				//LOG_BLINE("VcrMixerSrcTargetModuleId=0x%08x\n", VcrMixerSrcTargetModuleId);
				OsdScalerMixerSrcTargetModuleId = EMHWLIB_TARGET_MODULE(EMHWLIB_MODULE_CATEGORY(MainMixerModuleId), 0, OsdSaclerInMainMixerSrcIndex);

				if(m_bDisableVcrMixerSrc)
				{
					RMbool bEnable = FALSE;
					eRMstatus = RuaSetProp5(pMainContext->pRUA, OsdScalerMixerSrcTargetModuleId, RMGenericPropertyID_Enable,
						&bEnable, sizeof(bEnable), tryTimesIfPending, tryIntervalMs);
					if(RMFAILED(eRMstatus))
					{
						PRINT_BFILE_LINENO_RMSTATUS;
					}
					else	//RM_OK
					{	
						eRMstatus = RuaSetProp5(pMainContext->pRUA, OsdScalerMixerSrcTargetModuleId, RMGenericPropertyID_Validate,
							NULL, 0, tryTimesIfPending, tryIntervalMs);
						if(RMFAILED(eRMstatus))
						{
							PRINT_BFILE_LINENO_RMSTATUS;
						}
						eRMstatus = RuaSetProp5(pMainContext->pRUA, MainMixerModuleId, RMGenericPropertyID_Validate,
							NULL, 0, tryTimesIfPending, tryIntervalMs);
						if(RMFAILED(eRMstatus))
						{
							PRINT_BFILE_LINENO_RMSTATUS;
						}
					}
				}

				RMuint32 osdScalerSurfaceAddr = OsdSurfaceAddr;
				//get the main osd surface address
				UINT32_t curGuiFbSurfaceAddrTmp;
				iRet = getCurGuiFbSurfaceAddr(OUT curGuiFbSurfaceAddrTmp);
				if(ERR_SUCCESS != iRet)
				{
					PRINT_BFILE_LINENO_IRET_STR;
					curGuiFbSurfaceAddrTmp = 0;
				}
				OsdSurfaceAddr = curGuiFbSurfaceAddrTmp;
				//LOG_BLINE("OsdSurfaceAddr=0x%08x\n", OsdSurfaceAddr);
				if(0 == OsdSurfaceAddr)
				{
					break;
				}
				if(osdScalerSurfaceAddr != OsdSurfaceAddr)
				{
					break;
				}

				// clear OSD at main side
				if(osdScalerSurfaceAddr)
				{
					bPersistentSurface = FALSE;
					eRMstatus = RuaSetProp5(pMainContext->pRUA, OsdScalerModuleId, RMGenericPropertyID_PersistentSurface,
						&bPersistentSurface, sizeof(bPersistentSurface), tryTimesIfPending, tryIntervalMs);
					if(RMFAILED(eRMstatus))
					{
						PRINT_BFILE_LINENO_RMSTATUS;
					}
				}
				eRMstatus = RuaSetProp5(pMainContext->pRUA, OsdScalerModuleId, RMGenericPropertyID_Surface,
					&NullSurfaceAddr, sizeof(NullSurfaceAddr), tryTimesIfPending, tryIntervalMs);
				if(RMFAILED(eRMstatus))
				{
					PRINT_BFILE_LINENO_RMSTATUS;
				}

				eRMstatus = RuaSetProp5(pMainContext->pRUA, OsdScalerModuleId, RMGenericPropertyID_Validate, NULL, 0,
					tryTimesIfPending, tryIntervalMs);
				if(RMFAILED(eRMstatus))
				{
					PRINT_BFILE_LINENO_RMSTATUS;
				}

				eRMstatus = RuaSetProp5(pMainContext->pRUA, MainMixerModuleId, RMGenericPropertyID_Validate, NULL, 0,
					tryTimesIfPending, tryIntervalMs);
				if(RMFAILED(eRMstatus))
				{
					PRINT_BFILE_LINENO_RMSTATUS;
				}
				
				{
					RMbool bEnable = TRUE;
					eRMstatus = RuaSetProp5(pMainContext->pRUA, vcrScalerModuleId, RMGenericPropertyID_Enable,
						&bEnable, sizeof(bEnable), tryTimesIfPending, tryIntervalMs);
					if(RMFAILED(eRMstatus))
					{
						PRINT_BFILE_LINENO_RMSTATUS;
					}
				}
				
				eRMstatus = RUAGetProperty(pMainContext->pRUA, vcrScalerModuleId, RMGenericPropertyID_Surface,
					&vcrScalerSurfaceAddr, sizeof(vcrScalerSurfaceAddr));
				if(RMFAILED(eRMstatus))
				{
					PRINT_BFILE_LINENO_RMSTATUS;
					vcrScalerSurfaceAddr = 0;
				}
				if(vcrScalerSurfaceAddr)
				{
					bPersistentSurface = FALSE;
					eRMstatus = RuaSetProp5(pMainContext->pRUA, vcrScalerModuleId, RMGenericPropertyID_PersistentSurface,
						&bPersistentSurface, sizeof(bPersistentSurface), tryTimesIfPending, tryIntervalMs);
					if(RMFAILED(eRMstatus))
					{
						PRINT_BFILE_LINENO_RMSTATUS;
					}
				}
				eRMstatus = RuaSetProp5(pMainContext->pRUA, vcrScalerModuleId, RMGenericPropertyID_Surface,
					&NullSurfaceAddr, sizeof(NullSurfaceAddr), tryTimesIfPending, tryIntervalMs);
				if(RMFAILED(eRMstatus))
				{
					PRINT_BFILE_LINENO_RMSTATUS;
				}

				MixerSrcState = EMhwlibMixerSourceState_Master;
				eRMstatus = RuaSetProp5(pMainContext->pRUA, VcrMixerSrcTargetModuleId, RMGenericPropertyID_MixerSourceState,
					&MixerSrcState, sizeof(MixerSrcState), tryTimesIfPending, tryIntervalMs);
				if(RMFAILED(eRMstatus))
				{
					PRINT_BFILE_LINENO_RMSTATUS;
				}
				
				eRMstatus = RuaSetProp5(pMainContext->pRUA, vcrScalerModuleId, RMGenericPropertyID_Surface,
					&OsdSurfaceAddr, sizeof(OsdSurfaceAddr), tryTimesIfPending, tryIntervalMs);
				if(RMFAILED(eRMstatus))
				{
					PRINT_BFILE_LINENO_RMSTATUS;
				}
				bPersistentSurface = TRUE;
				eRMstatus = RuaSetProp5(pMainContext->pRUA, vcrScalerModuleId, RMGenericPropertyID_PersistentSurface,
					&bPersistentSurface, sizeof(bPersistentSurface), tryTimesIfPending, tryIntervalMs);
				if(RMFAILED(eRMstatus))
				{
					PRINT_BFILE_LINENO_RMSTATUS;
				}

				eRMstatus = RUAGetProperty2(m_RmfpMainContext.pRUA, vcrScalerModuleId, RMGenericPropertyID_Surface,
					&OsdSurfaceAddr, sizeof(OsdSurfaceAddr));
				if(RMFAILED(eRMstatus))
				{
					PRINT_BFILE_LINENO_RMSTATUS;
					break;
				}
				LOG_BLINE("vcrSurfaceAddr=0x%08x\n", OsdSurfaceAddr);

				MixerSrcState = EMhwlibMixerSourceState_Master;
				eRMstatus = RuaSetProp5(pMainContext->pRUA, VcrMixerSrcTargetModuleId, RMGenericPropertyID_MixerSourceState,
					&MixerSrcState, sizeof(MixerSrcState), tryTimesIfPending, tryIntervalMs);
				if(RMFAILED(eRMstatus))
				{
					PRINT_BFILE_LINENO_RMSTATUS;
				}

				{
					RMbool bEnable = TRUE;
					eRMstatus = RuaSetProp5(pMainContext->pRUA, vcrScalerModuleId, RMGenericPropertyID_Enable,
						&bEnable, sizeof(bEnable), tryTimesIfPending, tryIntervalMs);
					if(RMFAILED(eRMstatus))
					{
						PRINT_BFILE_LINENO_RMSTATUS;
					}
				}

				eRMstatus = RuaSetProp5(pMainContext->pRUA, VcrMixerSrcTargetModuleId, RMGenericPropertyID_Validate, NULL, 0,
					tryTimesIfPending, tryIntervalMs);
				if(RMFAILED(eRMstatus))
				{
					PRINT_BFILE_LINENO_RMSTATUS;
				}
								
				eRMstatus = RuaSetProp5(pMainContext->pRUA, vcrScalerModuleId, RMGenericPropertyID_Validate, NULL, 0,
					tryTimesIfPending, tryIntervalMs);
				if(RMFAILED(eRMstatus))
				{
					PRINT_BFILE_LINENO_RMSTATUS;
				}
				
				eRMstatus = RuaSetProp5(pMainContext->pRUA, MainMixerModuleId, RMGenericPropertyID_Validate, NULL, 0,
					tryTimesIfPending, tryIntervalMs);
				if(RMFAILED(eRMstatus))
				{
					PRINT_BFILE_LINENO_RMSTATUS;
				}
			}while(FALSE);
		}
		
		//post process
		if(VO_MODE_SPLIT_HdmiMain_1080p60_VgaVcr == eVoMode)
		{
			RMuint32 DispDigitalOutModuleId = EMHWLIB_MODULE(DispDigitalOut, 0);
			RMuint32 DispComponentOutModuleId = EMHWLIB_MODULE(DispComponentOut, 0);
			RMuint32 DispMainAnalogOutModuleId = EMHWLIB_MODULE(DispMainAnalogOut, 0);
			RMuint32 SlaveOutput;
			RMuint32 SyncSrcModuleId;
			struct EMhwlibClockGenerator ClockPll;
			RMuint32 MainMixerModuleId = EMHWLIB_MODULE(DispMainMixer, 0);
			RMuint32 VcrMixerSrcTargetModuleId;
			RMuint32 VcrScalerInMainMixerSrcIndex = 0;
			enum EMhwlibMixerSourceState MixerSrcState = EMhwlibMixerSourceState_Master;
			RMbool bWaitForDispEvtIfPending = TRUE;
			RMuint32 OsdScalerModuleId;
			RMuint32 OsdSurfaceAddr = 0;
			RMuint32 NullSurfaceAddr;
			
			eRMstatus = DCCGetScalerModuleID(m_RmfpMainContext.pDCC, DCCRoute_Main, DCCSurface_OSD, 0, &OsdScalerModuleId);
			if(RMFAILED(eRMstatus))
			{
				PRINT_BFILE_LINENO_RMSTATUS;
				break;
			}

			eRMstatus = RUAExchangeProperty(m_RmfpMainContext.pRUA, MainMixerModuleId, RMGenericPropertyID_MixerSourceIndex,
				&vcrScalerModuleId, sizeof(vcrScalerModuleId), (&VcrScalerInMainMixerSrcIndex), sizeof(VcrScalerInMainMixerSrcIndex));
			if(RMFAILED(eRMstatus))
			{
				PRINT_BFILE_LINENO_RMSTATUS;
				break;
			}

			VcrMixerSrcTargetModuleId = EMHWLIB_TARGET_MODULE(EMHWLIB_MODULE_CATEGORY(MainMixerModuleId), 0, VcrScalerInMainMixerSrcIndex);			

			if(m_bDisableVcrMixerSrc)
			{
				RMbool bEnable = FALSE;
				eRMstatus = RuaSetProp5(pMainContext->pRUA, VcrMixerSrcTargetModuleId, RMGenericPropertyID_Enable,
					&bEnable, sizeof(bEnable), tryTimesIfPending, tryIntervalMs);
				if(RMFAILED(eRMstatus))
				{
					PRINT_BFILE_LINENO_RMSTATUS;
				}
				else	//RM_OK
				{
					eRMstatus = RuaSetProp5(pMainContext->pRUA, VcrMixerSrcTargetModuleId, RMGenericPropertyID_Validate, NULL, 0,
						tryTimesIfPending, tryIntervalMs);
					if(RMFAILED(eRMstatus))
					{
						PRINT_BFILE_LINENO_RMSTATUS;
					}

					eRMstatus = RuaSetProp5(pMainContext->pRUA, MainMixerModuleId, RMGenericPropertyID_Validate, NULL, 0,
						tryTimesIfPending, tryIntervalMs);
					if(RMFAILED(eRMstatus))
					{
						PRINT_BFILE_LINENO_RMSTATUS;
					}
				}
			}

			if(m_bDisableVcrMixerSrc)
			{
				RMuint32 VcrScalerSrcTargetModuleId;
				RMbool bEnable = TRUE;
				VcrScalerSrcTargetModuleId = EMHWLIB_TARGET_MODULE(EMHWLIB_MODULE_CATEGORY(MainMixerModuleId), 0, 0);
				eRMstatus = RuaSetProp5(pMainContext->pRUA, VcrScalerSrcTargetModuleId, RMGenericPropertyID_Enable,
					&bEnable, sizeof(bEnable), tryTimesIfPending, tryIntervalMs);
				if(RMFAILED(eRMstatus))
				{
					PRINT_BFILE_LINENO_RMSTATUS;
				}
				else	//RM_OK
				{
					eRMstatus = RuaSetProp5(pMainContext->pRUA, VcrScalerSrcTargetModuleId, RMGenericPropertyID_Validate, NULL, 0,
						tryTimesIfPending, tryIntervalMs);
					if(RMFAILED(eRMstatus))
					{
						PRINT_BFILE_LINENO_RMSTATUS;
					}
				}
			}
		}

		//VO_MODE_SPLIT_HdmiMain_1080p60_VgaVcr => other modes
		if(VO_MODE_SPLIT_HdmiMain_1080p60_VgaVcr != eVoMode && VO_MODE_SPLIT_HdmiMain_1080p60_VgaVcr == m_eVoMode)
		{
			//restore OSD surface to OSD scaler
			RMuint32 vcrScalerSurfaceAddr;
			RMuint32 osdScalerSurfaceAddr;
			RMuint32 curGuiFbSurfaceAddr;
			RMuint32 nullSurfaceAddr = 0;
			{
				UINT32_t curGuiFbSurfaceAddrTmp;
				iRet = getCurGuiFbSurfaceAddr(OUT curGuiFbSurfaceAddrTmp);
				if(ERR_SUCCESS != iRet)
				{
					PRINT_BFILE_LINENO_IRET_STR;
					curGuiFbSurfaceAddrTmp = 0;
				}
				curGuiFbSurfaceAddr = curGuiFbSurfaceAddrTmp;
			}
			eRMstatus = RUAGetProperty(m_RmfpMainContext.pRUA, vcrScalerModuleId, RMGenericPropertyID_Surface,
				&vcrScalerSurfaceAddr, sizeof(vcrScalerSurfaceAddr));
			if(RMFAILED(eRMstatus))
			{
				PRINT_BFILE_LINENO_RMSTATUS;
				vcrScalerSurfaceAddr = 0;
			}
			LOG_BLINE("vcrScalerSurfaceAddr=0x%08x\n", vcrScalerSurfaceAddr);
			if(vcrScalerSurfaceAddr && vcrScalerSurfaceAddr != curGuiFbSurfaceAddr)
			{
				LOG_BLINE("BUG,vcrScalerSurfaceAddr=0x%08x,curGuiFbSurfaceAddr=0x%08x\n", vcrScalerSurfaceAddr, curGuiFbSurfaceAddr);
			}
			//VCR scaler
			eRMstatus = Scaler_Enable(pMainContext->pRUA, vcrScalerModuleId, FALSE/*disable*/, FALSE/*not validate*/);
			if(RMFAILED(eRMstatus))
			{
				PRINT_BFILE_LINENO_RMSTATUS;
			}
			eRMstatus = Scaler_setSourceStateInMixer(pMainContext->pRUA, vcrScalerModuleId, EMhwlibMixerSourceState_Slave, FALSE/*not validate*/);
			if(RMFAILED(eRMstatus))
			{
				PRINT_BFILE_LINENO_RMSTATUS;
			}
			if(vcrScalerSurfaceAddr)
			{
				bPersistentSurface = FALSE;
				eRMstatus = RuaSetProp5(pMainContext->pRUA, vcrScalerModuleId, RMGenericPropertyID_PersistentSurface,
					&bPersistentSurface, sizeof(bPersistentSurface), tryTimesIfPending, tryIntervalMs);
				if(RMFAILED(eRMstatus))
				{
					PRINT_BFILE_LINENO_RMSTATUS;
				}
			}
			eRMstatus = RuaSetProp5(pMainContext->pRUA, vcrScalerModuleId, RMGenericPropertyID_Surface, &nullSurfaceAddr, sizeof(nullSurfaceAddr),
				tryTimesIfPending, tryIntervalMs);
			if(RMFAILED(eRMstatus))
			{
				PRINT_BFILE_LINENO_RMSTATUS;
			}
			eRMstatus = RuaSetProp5(pMainContext->pRUA, vcrScalerModuleId, RMGenericPropertyID_Validate, NULL, 0,
				tryTimesIfPending, tryIntervalMs);
			if(RMFAILED(eRMstatus))
			{
				PRINT_BFILE_LINENO_RMSTATUS;
			}
			//OSD scaler
			eRMstatus = RUAGetProperty(m_RmfpMainContext.pRUA, vcrScalerModuleId, RMGenericPropertyID_Surface,
				&osdScalerSurfaceAddr, sizeof(osdScalerSurfaceAddr));
			if(RMFAILED(eRMstatus))
			{
				PRINT_BFILE_LINENO_RMSTATUS;
				osdScalerSurfaceAddr = 0;
			}
			if(osdScalerSurfaceAddr)
			{
				bPersistentSurface = FALSE;
				eRMstatus = RuaSetProp5(pMainContext->pRUA, osdScalerModuleId, RMGenericPropertyID_PersistentSurface,
					&bPersistentSurface, sizeof(bPersistentSurface), tryTimesIfPending, tryIntervalMs);
				if(RMFAILED(eRMstatus))
				{
					PRINT_BFILE_LINENO_RMSTATUS;
				}
			}
			eRMstatus = RuaSetProp5(pMainContext->pRUA, osdScalerModuleId, RMGenericPropertyID_Surface, &nullSurfaceAddr, sizeof(nullSurfaceAddr),
				tryTimesIfPending, tryIntervalMs);
			if(RMFAILED(eRMstatus))
			{
				PRINT_BFILE_LINENO_RMSTATUS;
			}
			eRMstatus = RuaSetProp5(pMainContext->pRUA, osdScalerModuleId, RMGenericPropertyID_Validate, NULL, 0,
				tryTimesIfPending, tryIntervalMs);
			if(RMFAILED(eRMstatus))
			{
				PRINT_BFILE_LINENO_RMSTATUS;
			}
			eRMstatus = RuaSetProp5(pMainContext->pRUA, osdScalerModuleId, RMGenericPropertyID_Surface, 
				&curGuiFbSurfaceAddr, sizeof(curGuiFbSurfaceAddr),
				tryTimesIfPending, tryIntervalMs);
			if(RMFAILED(eRMstatus))
			{
				PRINT_BFILE_LINENO_RMSTATUS;
			}
			bPersistentSurface = TRUE;
			eRMstatus = RuaSetProp5(pMainContext->pRUA, osdScalerModuleId, RMGenericPropertyID_PersistentSurface,
				&bPersistentSurface, sizeof(bPersistentSurface), tryTimesIfPending, tryIntervalMs);
			if(RMFAILED(eRMstatus))
			{
				PRINT_BFILE_LINENO_RMSTATUS;
			}
			eRMstatus = RuaSetProp5(pMainContext->pRUA, osdScalerModuleId, RMGenericPropertyID_Validate, NULL, 0,
				tryTimesIfPending, tryIntervalMs);
			if(RMFAILED(eRMstatus))
			{
				PRINT_BFILE_LINENO_RMSTATUS;
			}
		}

		if(VO_MODE_SPLIT_HdmiMain_1080p60_VgaVcr == eVoMode)
		{
			//GUI OSD2
			iRet = createSecondOsd();
			if(ERR_SUCCESS != iRet)
			{
				PRINT_BFILE_LINENO_IRET_STR;
				goto SECOND_OSD_INIT_END;
			}
			iRet = secondOsd_ClearScr();
			if(ERR_SUCCESS != iRet)
			{
				PRINT_BFILE_LINENO_IRET_STR;
				goto SECOND_OSD_INIT_END;
			}
			iRet = bindSecondOsdToDispScaler(osdScalerModuleId);
			if(ERR_SUCCESS != iRet)
			{
				PRINT_BFILE_LINENO_IRET_STR;
				goto SECOND_OSD_INIT_END;
			}
SECOND_OSD_INIT_END:
			;
		}
		else	//other modes
		{
			iRet = releaseSecondOsd();
			if(ERR_IS_USING == iRet)
			{
				LOG_BLINE("Osd2 surface is in use.\n");
			}
			else if(ERR_SUCCESS != iRet)
			{
				PRINT_BFILE_LINENO_IRET_STR;
			}
		}

		doSetVidOutputModeTimes++;

		//other modes => VO_MODE_SPLIT_HdmiMain_1080p60_VgaVcr
		if(VO_MODE_SPLIT_HdmiMain_1080p60_VgaVcr == eVoMode && VO_MODE_SPLIT_HdmiMain_1080p60_VgaVcr != m_eVoMode)
		{
			if(2 > doSetVidOutputModeTimes)
			{
				goto DO_SET_VIDEO_OUTPUT_MODE;
			}
		}
		
		m_eVoMode = eVoMode;
		if(peNewVoMode)
		{
			*peNewVoMode = m_eVoMode;
		}

		/*
		{
			
			struct DispRouting_Routing_type CurDispRouting;
			eRMstatus = RUAGetProperty(m_RmfpMainContext.pRUA, DispRouting, RMDispRoutingPropertyID_Routing,
				&CurDispRouting, sizeof(CurDispRouting));
			if(RMSUCCEEDED(eRMstatus))
			{
				LOG_BLINE("DigitalOutputEnable=%d,DigitalOutputSourceModuleID=%d\n", 
					CurDispRouting.DigitalOutputEnable, CurDispRouting.DigitalOutputSourceModuleID);
			}
			else
			{
				PRINT_BFILE_LINENO_RMSTATUS;
			}
		}
		*/

		if(VO_MODE_SPLIT_MODE_MIN_BOUNDARY < m_eVoMode && VO_MODE_SPLIT_MODE_MAX_BOUNDARY > m_eVoMode)	//split HDMI+VGA
		{
			//needs restore the original m_CurRightStereoscopic3D
			m_eHdmi3DTvMode = H3DTvMode_Normal;
			iRet = setStereoscopic3DFormat(&m_CurRightStereoscopic3D);
			if(CC_UNLIKELY(ERROR_SUCCESS != iRet))
			{
				PRINT_BFILE_LINENO_IRET_STR;
			}
		}

		//notify the main thread
		do
		{
			SharedPtr <IMediaSrvEventListener> MediaSrvEvtListener_sp;
			{
				CAutoLock AutoRangeLocker(&m_SharedDataMutex);
				MediaSrvEvtListener_sp = m_MediaSrvEvtListener_wp.Promote();
			}
			if(MediaSrvEvtListener_sp.isNull())
			{
				break;
			}
					
			iRet = MediaSrvEvtListener_sp->On_VideoOutputModeIsSet();
			if(ERROR_SUCCESS != iRet)
			{
				PRINT_BFILE_LINENO_IRET_STR;
			}
			iRet = WakeupMainThread();
			if(ERROR_SUCCESS != iRet)
			{
				PRINT_BFILE_LINENO_IRET_STR;
			}
		}while(FALSE);

		/*
		if(Sw_LogMediaFileInfo)
		{
			struct EMhwlibTVFormatDigital TvFormatDigital;
			eRMstatus = RUAGetProperty(m_RmfpMainContext.pRUA, DispDigitalOut, RMGenericPropertyID_DigitalTVFormat, &TvFormatDigital, sizeof(TvFormatDigital));
			if(RMSUCCEEDED(eRMstatus))
			{
				LOG_BLINE("VbiStandard=%d,PixelClock=%u,ActiveWidth=%u,ActiveHeight=%u\n", 
					TvFormatDigital.VbiStandard, TvFormatDigital.PixelClock, TvFormatDigital.ActiveWidth, TvFormatDigital.ActiveHeight);
			}
			else
			{
				PRINT_BFILE_LINENO_RMSTATUS;
			}
		}
		*/
	}while(FALSE);

	return iOutRet;
}

INT_t CMediaSrv::setVideoOutputMode()
{
	INT_t iOutRet = ERROR_SUCCESS;
	RMstatus eRMstatus = RM_OK;
	struct rmfp_main_thread_context_type *pMainContext = &m_RmfpMainContext;

	CAutoLock AutoRangeLocker(&m_mutexVideoAudioIoSet); 

	do
	{		
		if(pMainContext->pHWLib)
		{
			eRMstatus = rmoutput_complete_video_timing(pMainContext->pHWLib, &(pMainContext->display_opt->HD.TimingInfo));
		}
		else
		{
			pMainContext->display_opt->HD.TimingInfo.PixelClock = 0;
		}
		if (RMSUCCEEDED(eRMstatus))
		{
			// disable EDID target when using forced mode, not use EDID preferred resolution
			pMainContext->display_opt->resolution_target.target = FALSE;
		}
		else
		{
			LOG_BLINE("CompleteVidTiming err %s\n", RMstatusToString(eRMstatus));
		}
		// Initialize video and audio outputs		
		eRMstatus = rmoutput_apply_display_options((pMainContext->pHWLib), (pMainContext->dh_info), 
			pMainContext->display_opt, pMainContext->display_conf);
		if (RMFAILED(eRMstatus))
		{
			LOG_BLINE("ApplyDispOpts err %s\n", RMstatusToString(eRMstatus));
		}
		//Complete HDMI timing
		if(pMainContext->dh_info->hdmi && pMainContext->dh_info->hdmi->State.HotPlugState/* &&
			pMainContext->dh_info->hdmi->State.ReceiverState*/)
		{
			// Update the display and apply changed settings, based on the display options
			UINT64_t StartTimeMs = GetSysUpTimeMs(), CurTimeMs;
			while(TRUE)
			{
				eRMstatus = rmoutput_display_update((pMainContext->pHWLib), (pMainContext->dh_info), 
					pMainContext->display_opt, pMainContext->display_conf);
				if(RMFAILED(eRMstatus))
				{
					LOG_BLINE("OutputDispUpdate err %s\n", RMstatusToString(eRMstatus));
				}
				CurTimeMs = GetSysUpTimeMs();
				if(1500 <= CurTimeMs - StartTimeMs)
				{
					break;
				}
				usleep(0);
			}
		}
		/* not call rmoutput_apply_audio_options because it has been called in rmoutput_apply_display_options and rmoutput_display_update
		//apply audio option
		eRMstatus = rmoutput_apply_audio_options(pMainContext->pHWLib, &(pMainContext->display_opt->audio_options));
		if (RMFAILED(eRMstatus)) 
		{
			LOG_BLINE("ApplyAudOpts err %s\n", RMstatusToString(eRMstatus));
		}
		*/
	}while(FALSE);

	return iOutRet;
}

INT_t CMediaSrv::setPlaySpeedCtrl(int iSpeed)
{
	INT_t iOutRet = ERROR_SUCCESS;

	

	return iOutRet;
}

/*
ThreadContext: must be Local
*/
INT_t CMediaSrv::getPlaySpeed(OUT int & iSpeed)
{
	INT_t iOutRet = ERROR_SUCCESS;
	RMstatus eRMstatus = RM_OK;
	struct RMFPPlaybackStatus RmfpPlaybackStatus;

	iSpeed = 5;	//normal speed

	do
	{
		if(NULL == m_RmfpMainContext.pHandle)
		{
			break;
		}
		eRMstatus = Rmfp_getPlaybackStatus(m_RmfpMainContext.pHandle, &RmfpPlaybackStatus);
		if(RMFAILED(eRMstatus))
		{
			PRINT_BFILE_LINENO_RMSTATUS;
			break;
		}
		if(0 == RmfpPlaybackStatus.playbackState.speed.M)
		{
			break;
		}
		iSpeed = (RmfpPlaybackStatus.playbackState.speed.N * 5 / RmfpPlaybackStatus.playbackState.speed.M);
	}while(FALSE);

	return iOutRet;
}

RMstatus CMediaSrv::InitDisplayContext()
{
	static BOOL_t g_bFirstCall = TRUE;
	RMstatus eOutRMstatus = RM_OK, eRMstatus;
	struct rmfp_main_thread_context_type *pMainContext = &m_RmfpMainContext;
	struct EMhwlibStereoscopic3D curStereoscopic3D;
	enum OutputSpdif_type eCurOutputSpdifMode;
	RMbool bCurSpdifParamIsSet = FALSE;

	enum AudioOutputChannels_type eChannelConfig;
	RMbool bChannelConfigIsSet=TRUE;
	RMbool bIsLfe=FALSE;
	RMbool bLfeSet=TRUE;
    
	do
	{
		if(FALSE == g_bFirstCall)	//save
		{
			curStereoscopic3D = pMainContext->display_opt->hdmi_options.requestedStereoscopic3D;
			eCurOutputSpdifMode = pMainContext->display_opt->audio_options.SPDIF;
			bCurSpdifParamIsSet = pMainContext->display_opt->audio_options.SPDIFSET;

			//save audio channel
			eChannelConfig=pMainContext->display_opt->audio_options.ChannelConfig;
			bChannelConfigIsSet=pMainContext->display_opt->audio_options.ChannelConfigSET;
			bIsLfe=pMainContext->display_opt->audio_options.LFE;
			bLfeSet=pMainContext->display_opt->audio_options.LFESET;
		}
		eRMstatus = rmoutput_init_display_context(pMainContext->display_opt,
											   pMainContext->display_conf,
											   &(pMainContext->pHWLib),
											   &(pMainContext->dh_info));
		if(CC_UNLIKELY(RMFAILED(eRMstatus)))
		{
			eOutRMstatus = eRMstatus;
			break;
		}
		pMainContext->display_opt->hdmi_options.srm_storage = (RMascii *)("./hdcp.srm");
		//do not use hdmi loop thread
		pMainContext->display_opt->hdmi_options.use_hdmi_loop_thread = FALSE;
		
		//Init audio options
		//LOG_BLINE("display_opt->audio_options.SampleRate=%d\n", pMainContext->display_opt->audio_options.SampleRate);
		//Maybe not need SampleRate?
		pMainContext->display_opt->audio_options.SampleRate = 44100;
		//LOG_BLINE("display_opt->audio_options.SampleRate=%d\n", pMainContext->display_opt->audio_options.SampleRate);
		//LOG_BLINE("EngineIndex=%d\n", pMainContext->display_opt->audio_options.EngineIndex);
		pMainContext->display_opt->audio_options.EngineIndex = 0;
		//Default: HDMI, CAV, CVBS/S-Video
		pMainContext->display_opt->output_enable_mask = RMOUTPUT_OUT_HDMI | /*RMOUTPUT_OUT_CAV | */RMOUTPUT_OUT_VGA | RMOUTPUT_OUT_CVBS;
		//should call display_close on terminated, but once set it to TRUE, OsdBuf will be deleted.
		//pMainContext->display_opt->no_close = FALSE;

		//reinitialize
		pMainContext->display_conf->hdmi_config.VIC = 0;
		// Connect RUA to rmoutput
		if(CC_UNLIKELY(NULL == pMainContext->pHWLib->context))	//needs initialization
		{
			if (RMFAILED(eRMstatus = rmoutput_rua_fill_callbacks(pMainContext->pRUA, pMainContext->pHWLib))) {
				RMNOTIFY((NULL, eRMstatus, "Error creating rmoutput instance!\n"));
			}
		}

		if(g_bFirstCall)
		{
			m_CurRightStereoscopic3D = pMainContext->display_opt->hdmi_options.requestedStereoscopic3D;
		}
		else	//restore
		{
			pMainContext->display_opt->hdmi_options.requestedStereoscopic3D = curStereoscopic3D;
			pMainContext->display_opt->audio_options.SPDIF = eCurOutputSpdifMode;
			pMainContext->display_opt->audio_options.SPDIFSET = bCurSpdifParamIsSet;

            //restore audio channel
            pMainContext->display_opt->audio_options.ChannelConfig=eChannelConfig;
            pMainContext->display_opt->audio_options.ChannelConfigSET=bChannelConfigIsSet;
            pMainContext->display_opt->audio_options.LFE=bIsLfe;
            pMainContext->display_opt->audio_options.LFESET=bLfeSet;
		}
	}while(FALSE);

	g_bFirstCall = FALSE;

	return eOutRMstatus;
}

INT_t CMediaSrv::RmfpInit()
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	RMstatus eRMstatus = RM_OK;
	struct rmfp_main_thread_context_type *pMainContext = &m_RmfpMainContext;
	struct RMFPProfile *pProfile = &m_RmfpProfile;
	struct RMFPStreamType *pStreamType = &m_RmfpStreamType;
	struct RMFPOptions *pOptions = &m_RmfpOptions;
	CGeneralApp * pApp = getApp();
	struct RUA * pRua = pMainContext->pRUA;
	RMuint32 osdScalerModuleId = EMHWLIB_MODULE(DispOSDScaler, 0);
	RMuint32 osdSurfaceAddr = 0;

	do
	{
		RMfile fileHandle = NULL;
		RMascii *fileName = NULL;
		RMstatus status, status_return;
		RMuint32 cnt;

		pMainContext->GetKeyCS = RMCreateCriticalSection();
		if (!pMainContext->GetKeyCS) {
			fprintf(ERRORMSG, "Unable to create GetKeyCS\n");
			iOutRet = ERR_INIT_FAIL;
			goto exit;
		}
		
		// RMFP profile initialization
		pProfile->magicNumber = RMFP_MAGIC_NUMBER;
		status = RMFPInitProfile(pProfile);
		if (status != RM_OK) {
			fprintf(ERRORMSG, "Init profile error (%s)\n", RMstatusToString(status));
			goto exit;
		}
	
		// Initialize all RMFP options to the default values
		status = RMFPInitOptions(pOptions);
		if (status != RM_OK) {
			fprintf(ERRORMSG, "Init options error (%s)\n", RMstatusToString(status));
			goto exit;
		}
		//Enable ClosedCaption CC1
		pOptions->video_options.CloseCaptionMode = RMFPCloseCaptionMode_ShowInOSD;
		pOptions->video_options.CloseCaptionType = RMFPCloseCaptionType_EIA608;
		pOptions->video_options.CloseCaptionSelect = EMhwlibCCSelect_CC1;
		//if accurated seek is used, some file have FF/FW problem.
		pOptions->playback_options.accurate_seek = FALSE;
        
		/*
		* FALSE: fixed 44100, but audio quality is effected.
		*/
		//pOptions->audio_options.afs = FALSE;

		// Set default stream type value
		status = RMFPInitStreamType(pStreamType);
		if (status != RM_OK) {
			fprintf(ERRORMSG, "Init streamtype error (%s)\n", RMstatusToString(status));
			goto exit;
		}
	
		// Initialize display options
		status = init_application_options(&(pMainContext->AppOptions));
		if (status != RM_OK) {
			fprintf(ERRORMSG, "Init display options error (%s)\n", RMstatusToString(status));
			goto exit;
		}
	
		// Create RUA and DCC instance which are mandatory for RMFP to work
		status = RUACreateInstance(&(pMainContext->pRUA), pMainContext->AppOptions.Playback.BoardIndex);
		if (status != RM_OK) {
			fprintf(ERRORMSG, "Error creating RUA instance (%s)\n", RMstatusToString(status));
			goto exit;
		}

		//Mute audio volume
		iRet = ChangeVolume(-100, NULL);
		if(ERROR_SUCCESS != iRet)
		{
			PRINT_BFILE_LINENO_IRET_STR;
		}
		
		status = DCCOpen(pMainContext->pRUA, &(pMainContext->pDCC));
		if (status != RM_OK) {
			fprintf(ERRORMSG, "Error Opening DCC! (%s)\n", RMstatusToString(status));
			goto exit;
		}
		pRua = pMainContext->pRUA;
	
		status = DCCSetMemoryManager(pMainContext->pDCC, pOptions->playback_options.DRAMIndex);
		if (status != RM_OK) {
			fprintf(ERRORMSG, "Error setting DCC DRAM controller index! (%s)\n", RMstatusToString(status));
			goto exit;
		}

		pMainContext->pMediaSrv = this;
		pProfile->rmfp_get_command_callback = Cb_getCommand;
		pProfile->rmfp_notify_command_status_callback = Cb_notifyCommandStatus;
	
		// Init Display Chain (see bug #11864, the display setup inside callbacks.c is incomplete)
		status = DCCInitChainEx(pMainContext->pDCC, DCCInitMode_LeaveDisplay);
		if (status != RM_OK) {
			fprintf(ERRORMSG, "Cannot initialize display chain (%s)\n", RMstatusToString(status));
			goto exit;
		}
	
		// Load Micro Code if requested in the options
		if (pMainContext->AppOptions.Playback.LoadUCODE) {
			//RMDBGLOG((LOCALDBG, "DCC init microcode\n"));
			status = DCCInitMicroCodeEx(pMainContext->pDCC, DCCInitMode_LeaveDisplay);
			if (status != RM_OK) {
				fprintf(ERRORMSG, "Cannot initialize microcode (%s)\n", RMstatusToString(status));
				goto exit;
			}
		} else {
#ifdef WITH_XLOADED_UCODE
			fprintf(NORMALMSG, "INFO: -noucode is meaningful only in legacy 'non-XLU' mode, it has no effect here\n");
#else
			RMDBGLOG((LOCALDBG, "Don't init microcode\n"));
#endif
		}

		//get the main osd surface address
		UINT32_t curGuiFbSurfaceAddrTmp;
		iRet = getCurGuiFbSurfaceAddr(OUT curGuiFbSurfaceAddrTmp);
		if(ERR_SUCCESS != iRet)
		{
			PRINT_BFILE_LINENO_IRET_STR;
			curGuiFbSurfaceAddrTmp = 0;
		}
		if(0 == curGuiFbSurfaceAddrTmp)
		{
			eRMstatus = RUAGetProperty2(pRua, osdScalerModuleId, RMGenericPropertyID_Surface, &osdSurfaceAddr, sizeof(osdSurfaceAddr));
			if(RMFAILED(eRMstatus))
			{
				iOutRet = ERR_INIT_FAIL;
				break;
			}
			LOG_BLINE("osdSurfaceAddr=0x%08x\n", osdSurfaceAddr);
			if(0 != osdSurfaceAddr)
			{
				iRet = setCurGuiFbSurfaceAddr(osdSurfaceAddr);
				if(ERROR_SUCCESS != iRet)
				{
					PRINT_BFILE_LINENO_IRET_STR;
				}
			}
		}

		status = InitDisplayContext();
		if(RMFAILED(status))
		{
			iOutRet = ERR_INIT_FAIL;
			break;
		}

#if 1 /*Add by xuweiwei 2014-3-18 Enable HDMI Audio have six channel*/
		{
			DECLARE_CLS_STACK_BUF_STRING(strEnHdmiAudio6Ch, 32);
			INT_t m_EnHdmiAudio6Ch=0; 
			iRet = SysProp_get(SysProp_KEY_EnAudio6ChFlag, OUT strEnHdmiAudio6Ch);
			if(ERR_SUCCESS == iRet)
			{
				m_EnHdmiAudio6Ch = (INT_t)(strEnHdmiAudio6Ch);
				iRet=setEnAudio6Channel((BOOL_t)m_EnHdmiAudio6Ch);
				if(ERROR_SUCCESS != iRet)
				{
					PRINT_BFILE_LINENO_IRET_STR;
				}
			}
			else
			{
				if(ERR_NOT_FOUND != iRet)
				{
					PRINT_BFILE_LINENO_IRET_STR;
				}
			}
		}			 
#endif
		//SPDIF mode
		{
			DECLARE_CLS_STACK_BUF_STRING(strOutputSpdifMode, 64);
			INT_t iSnmpOutSpdifMode = Mp7xxCommon::SnmpOutSpdifMode_Uncompressed;
			iRet = SysProp_get(SysProp_KEY_OutputSpdifMode, OUT strOutputSpdifMode);
			if(ERROR_SUCCESS == iRet)
			{
				iSnmpOutSpdifMode = (INT_t)strOutputSpdifMode;
			}
			else
			{
				if(ERROR_NOT_FOUND != iRet)
				{
					PRINT_BFILE_LINENO_IRET_STR;	
				}				
			}
			iRet = setMruaOutputSpdifMode(iSnmpOutSpdifMode);
			if(ERROR_SUCCESS != iRet)
			{
				PRINT_BFILE_LINENO_IRET_STR;	
			}				
		}

		// If no scaler has been specified by the command line, force it to a default value
		// Then apply the scaler options
		if (!pMainContext->AppOptions.Display.scaler_ID) {
			pMainContext->AppOptions.Display.scaler_ID = DispMainVideoScaler;
			pMainContext->pOptions->video_options.VideoScalerID = DispMainVideoScaler;
		}
	
		if(m_bNotApplyDispOpt)
		{
		}
		else	//!m_bNotApplyDispOpt
		{
			if(VO_MODE_SPLIT_MODE_MIN_BOUNDARY < m_eVoMode && m_eVoMode < VO_MODE_SPLIT_MODE_MAX_BOUNDARY)
			{
				eRMstatus = InitVcrScaler();
				if(RMFAILED(eRMstatus))
				{
					PRINT_BFILE_LINENO_RMSTATUS;
				}
			}
			//apply a video output mode saved previously
			iRet = ChangeVideoOutputMode(m_eVoMode);
			if(ERROR_NOT_SUPPORTED == iRet || ERROR_INVALID_PARAMETER == iRet)
			{
				m_eVoMode = VO_MODE_HDMI_720p59;
				iRet = ChangeVideoOutputMode(m_eVoMode);
			}
			if(ERROR_SUCCESS != iRet)
			{
				LOG_BLINE("iRet=%d,VoMode=%d\n", iRet, m_eVoMode);
			}
		}
		
		/**********************************************************************************************************
		 * Now, create the RMFP profile :
		 * - pass the created RUA and DCC handles
		 * - pass the callback context (test_rmfp context here), that will be pass as an argument to all callbacks
		 * - pass all the implemented callbacks
		 **********************************************************************************************************/
	
		// RUA, DCC and callback context (our context)
		pProfile->pRUA = pMainContext->pRUA;
		pProfile->pDCC = pMainContext->pDCC;
		pProfile->callback_context = (void*) pMainContext;

		/*
		 * Font rendering handle
		 */
		status = init_font_rendering(pMainContext, pApp->m_ppArgv[0], &pProfile->pDefaultFontName, &pProfile->pCCFontName, &pProfile->pForcedFontName);
		if (status != RM_OK)
			goto exit;
		
		pProfile->pFontRenderHandle = pMainContext->pFontRenderHandle;
		
		// Resources management callbacks
		// Location : resources.c
#if USE_RESOURCE_CALLBACKS
		pProfile->rmfp_video_resources_callback = video_resources_handler;
		pProfile->rmfp_picture_transform_resources_callback = picture_transform_resources_handler;
		pProfile->rmfp_ppf_resources_callback = ppf_resources_handler;
		pProfile->rmfp_audio_instances_callback = audio_instances_handler;
		pProfile->rmfp_audio_resources_callback = audio_resources_handler;
		pProfile->rmfp_demux_resources_callback = demux_resources_handler;
	
		pProfile->rmfp_demux_output_resources_callback = demux_output_resources_handler;
		pProfile->rmfp_spu_resources_callback = spu_resources_handler;
		pProfile->rmfp_ccfifo_resources_callback = ccfifo_resources_handler;
		pProfile->rmfp_teletext_resources_callback = teletext_resources_handler;
		pProfile->rmfp_rmwmdrm_resources_callback = rmwmdrm_resources_handler;
	
		pProfile->rmfp_release_video_resources_callback = release_video_resources_handler;
		pProfile->rmfp_release_picture_transform_resources_callback = release_picture_transform_resources_handler;
		pProfile->rmfp_release_ppf_resources_callback = release_ppf_resources_handler;
		pProfile->rmfp_release_audio_resources_callback = release_audio_resources_handler;
		pProfile->rmfp_release_demux_resources_callback = release_demux_resources_handler;
	
		pProfile->rmfp_release_demux_output_resources_callback = release_demux_output_resources_handler;
		pProfile->rmfp_release_spu_resources_callback = release_spu_resources_handler;
		pProfile->rmfp_release_ccfifo_resources_callback = release_ccfifo_resources_handler;
		pProfile->rmfp_release_teletext_resources_callback = release_teletext_resources_handler;
		pProfile->rmfp_release_rmwmdrm_resources_callback = release_rmwmdrm_resources_handler;
	
		if (pMainContext->AppOptions.Playback.cipher_config_file_name) {
			pProfile->rmfp_demux_cipher_resources_callback = cipher_resources_handler;
			pProfile->rmfp_release_demux_cipher_resources_callback = release_cipher_resources_handler;
		}
	
		if (pMainContext->AppOptions.Playback.dmapool_in_rua_mem) {
			pProfile->rmfp_open_dmapool_callback = open_dmapool_handler;
			pProfile->rmfp_close_dmapool_callback = close_dmapool_handler;
		}
	
		pProfile->rmfp_open_osd_callback = open_osd;
		pProfile->rmfp_close_osd_callback = close_osd;
	
		pProfile->rmfp_get_route_callback = get_route_handler;
		pProfile->rmfp_get_surface_events_callback = get_surface_events_handler;
		pProfile->rmfp_disconnect_surface_callback = disconnect_surface_handler;
		pProfile->rmfp_disk_control_callback = disk_control;
		pProfile->rmfp_get_rmwmdrm_profile_callback = rmwmdrm_profile;
#endif
		
#if USE_NOTIFICATION_CALLBACKS
		pProfile->rmfp_notify_available_commands_callback = notify_available_commands;
		pProfile->rmfp_notify_playback_status_callback = notify_playback_status;
		pProfile->rmfp_notify_playback_start_callback = Cb_notify_playback_start;
		pProfile->rmfp_notify_playback_eos_callback = Cb_notify_playback_eos;
		pProfile->rmfp_notify_current_streams_properties_callback = notify_current_streams_properties;
		pProfile->rmfp_notify_stream_metadata_callback = notify_stream_metadata;
		pProfile->rmfp_notify_pat_callback = notify_pat;
		pProfile->rmfp_notify_pmt_callback = notify_pmt;
	
		if (pMainContext->AppOptions.Playback.cipher_config_file_name) {
			pProfile->rmfp_notify_pid_creation_callback = notify_pid_creation;
			pProfile->rmfp_notify_send_data_callback = notify_send_data;
		}
#if 1/*added by lxj 2013-1-8*/
		pProfile->rmfp_notify_progress_callback = Cb_notify_progress;
#else
		pProfile->rmfp_notify_progress_callback = notify_progress;
#endif
#else
		// we need to enable all commands since we'll not receive the available commands from the application
		pMainContext->availableCommandsMask = 0xFFFFFFFF;
#endif
	
		pProfile->rmfp_open_bdspu_decoder_callback = open_bdspu_decoder;
		pProfile->rmfp_close_bdspu_decoder_callback = close_bdspu_decoder;
		pProfile->rmfp_send_bdspu_decoder_callback = send_bdspu_decoder;
		pProfile->rmfp_flush_bdspu_decoder_callback = flush_bdspu_decoder;
	
		pProfile->rmfp_get_video_scaler_callback = rmfp_getVideoScalerModuleId;
		pProfile->pfnRmoutputAudioEngine_setSampleFreq = Rmfp_AudioEngine_setSampleFreq;
		
		// Special open options
		pProfile->options.use_http_caching = pMainContext->AppOptions.Playback.use_http_caching;

	
		/************************************************
		 * Open the RMP handle using the created profile,
		 * then store it in our context
		 ************************************************/
		status = RMFPOpenHandle(pProfile, &(pMainContext->pHandle));
		if (status != RM_OK) {
			fprintf(ERRORMSG, "Open handle error (%s)\n", RMstatusToString(status));
			goto exit;
		}
	
		pMainContext->EOS = FALSE;
	
		if (pMainContext->AppOptions.Display.route != RMFPRoute_Main && 
			pMainContext->pOptions->video_options.CloseCaptionMode == RMFPCloseCaptionMode_SendToTV)
		{
			pMainContext->pOptions->video_options.CloseCaptionMode = RMFPCloseCaptionMode_Disabled;
		}
		
		if (pMainContext->dh_info) {
			// "One Touch Play" feature
			pMainContext->dh_info->CEC.RequestImageViewOn = TRUE;
			pMainContext->dh_info->CEC.RequestActiveSource = TRUE;
			pMainContext->dh_info->CEC.DeckInfo = CEC_DeckInfo_Play;
		}
		
		/* Check if osd scaler support VideoNonInterleaved mode */
		{
			enum EMhwlibColorMode color_mode = EMhwlibColorMode_VideoNonInterleaved;
	
			status = RUASetProperty(pMainContext->pRUA,
						pMainContext->AppOptions.Display.osd_scaler_ID,
						RMGenericPropertyID_IsColorModeSupported,
						&(color_mode),
						sizeof(color_mode),
						0);
			if(status != RM_OK){
				RMDBGLOG((ENABLE, "Osd scaler don't support VideoNonInterleaved mode -> forced rgb mode\n"));
				pOptions->picture_options.force_rgb = TRUE;
			}
		}
		
		// Reset file specific context
		init_rmfp_file_specific_context(pMainContext);
			
		pMainContext->fileHandle = fileHandle;
		pMainContext->playback_started = FALSE;
	
		// Check that the outports have been configured
		// Wait for a vsync on the routing
		if (1) {
			struct RUAEvent event = { 0, };
	
			event.ModuleID = EMHWLIB_MODULE(DisplayBlock,0);
			event.Mask = EMHWLIB_DISPLAY_EVENT_ID(DispRouting);
	
			RUAResetEvent(pMainContext->pRUA, &event);
			status = RuaWaitFor_DispBlk_DispEvt_ThrdSync(pMainContext->pRUA, &event, 1, 500000, NULL);
			if (status != RM_OK) {
				fprintf(ERRORMSG, "\n################################################################################\n");
				fprintf(ERRORMSG, "#########	   PLEASE CONFIGURE OUTPORTS BEFORE USING TEST_RMFP 	 ##########\n");
				fprintf(ERRORMSG, "#########	   Example: 'example_outports -analog -audio_engine 0'	 ##########\n");
				fprintf(ERRORMSG, "#########	   Or, add '-o hdmi cav cvbs' to the test_rmfp options	 ##########\n");
				fprintf(ERRORMSG, "################################################################################\n\n");
				goto exit;
			}
		}
	
		if (1) {
			struct AudioEngine_StoreOutputMode_type StoredOutputMode;
			RMuint32 EngineIndex = (RMuint32)pMainContext->pOptions->audio_options.EngineIndex;
			//LOG_BLINE("EngineIndex=%d\n", EngineIndex);
			RMuint32 EngineModuleID = EMHWLIB_MODULE(AudioEngine, EngineIndex);
	
			status = RUAGetProperty(pMainContext->pRUA,
						EngineModuleID,
						RMAudioEnginePropertyID_StoreOutputMode,
						&StoredOutputMode,
						sizeof(StoredOutputMode));
	
			if (status != RM_OK) {
				RMNOTIFY((NULL, status, "failed to get engine %lu output options!\n", EngineIndex));
	
				fprintf(ERRORMSG, "\n");
				fprintf(ERRORMSG, "It seems that the audio engine selected (%lu) has not been properly initialised.\n", EngineIndex);
				fprintf(ERRORMSG, "Make sure that you use '-audio_engine %lu' in example_outports' commandline.\n", EngineIndex);
				fprintf(ERRORMSG, "\n");
			}
		}
	}while(FALSE);
exit:

	//backup options
	m_RmfpOptionsBackup = *pOptions;

	return iOutRet;
}

INT_t CMediaSrv::ExitInstance()
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	RMstatus eRMstatus;
	struct rmfp_main_thread_context_type *pMainContext = &m_RmfpMainContext;
	struct RUA * pRua = pMainContext->pRUA;
	RMint32 TryIntervalMsIfPending = 30;
	RMint32 RetryTimesIfPending = 3;

	do
	{
		if(getThreadIsRunning())
		{
			iRet = StopThread();
			if(ERROR_SUCCESS != iRet)
			{
				PRINT_BFILE_LINENO_IRET_STR;
			}
		}

		m_CnkB85LcmLedScr_sp.Release();

		if(m_BlackSurfaceAddr)
		{
			RMuint32 VcrScalerModuleId = EMHWLIB_MODULE(DispVCRMultiScaler, 0);
			RMuint32 NullSurfaceAddr = 0;
			eRMstatus = RuaSetProp5(pMainContext->pRUA, VcrScalerModuleId, RMGenericPropertyID_DefaultSurface,
				&NullSurfaceAddr, sizeof(NullSurfaceAddr), RetryTimesIfPending, TryIntervalMsIfPending);
			if(RMFAILED(eRMstatus))
			{
				PRINT_BFILE_LINENO_RMSTATUS;
			}
			RUAFree(pRua, m_BlackSurfaceAddr);
			m_BlackSurfaceAddr = 0;
		}

#ifdef ENABLE_DTV
		m_TunerSrv_sp.Clear();
#endif	//ENABLE_DTV

		iRet = releaseSecondOsd();
		if(ERR_IS_USING == iRet)
		{
			LOG_BLINE("Osd2 surface is in use.\n");
		}
		else if(ERR_SUCCESS != iRet)
		{
			PRINT_BFILE_LINENO_IRET_STR;
		}

		eRMstatus = player_rmfp_exit(&m_RmfpMainContext);
		if (RMFAILED(eRMstatus)) 
		{
			PRINT_BFILE_LINENO_RMSTATUS;
		}

		m_MediaFileInfoCache_sp.Release();
			
		if(m_pDBusConnMediaSrv)
		{
			dbus_connection_close(m_pDBusConnMediaSrv);
			dbus_connection_unref(m_pDBusConnMediaSrv);
			m_pDBusConnMediaSrv = NULL;
		}

		iRet = RmfpUninit();
		if(ERROR_SUCCESS != iRet)
		{
			PRINT_BFILE_LINENO_IRET_STR;
		}
	}while(FALSE);

	return iOutRet;
}

INT_t CMediaSrv::StartThread()
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	RMstatus eRMstatus = RM_OK;

	do
	{
		eRMstatus = PlayCtrlCtx_setDataIoTimeoutCb(m_pPlayCtrlCtx, Cb_DataIoTimeoutCallback);
		if(RMFAILED(eRMstatus))
		{
			PRINT_BFILE_LINENO_RMSTATUS;
		}

		//Create a worker thread
		{
			PTHREAD_CREATE_PARAMS ThreadCreateParams;			
			ThreadCreateParams.iSizeOfThis = sizeof(ThreadCreateParams);
			iRet = PThrdCreateParamInit(&ThreadCreateParams);
			if(CC_UNLIKELY(ERROR_SUCCESS != iRet))
			{
				PRINT_BFILE_LINENO_IRET_CRT_ERR;
				iOutRet = iRet;
				break;
			}			
			ThreadCreateParams.bDetached = TRUE;
			iRet = CreateThread(&ThreadCreateParams);
			if(CC_UNLIKELY(ERROR_SUCCESS != iRet))
			{
				PRINT_BFILE_LINENO_IRET_CRT_ERR;
				iOutRet = iRet;
				break;
			}			
		}
	}while(FALSE);

	return iOutRet;
}

INT_t CMediaSrv::StopThread()
{
	INT_t iOutRet = ERROR_SUCCESS;
	INT_t iRet;
	SharedPtr <CMessageQueueItem> GenericMsg_sp;
	SharedPtr <CGenericMsgData> MsgData_sp;
	RMstatus eRMstatus = RM_OK;
	
	//Stop the workder thread
	m_bShouldExitThread = TRUE;
	
	do
	{
		GenericMsg_sp = SharedPtr <CMessageQueueItem>(new CMessageQueueItem);
		if(CC_UNLIKELY(NULL == GenericMsg_sp.get()))
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}
		MsgData_sp = SharedPtr <CGenericMsgData>(new CGenericMsgData);
		if(CC_UNLIKELY(NULL == MsgData_sp.get()))
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}

		if(getThreadIsRunning())
		{
			iRet = Stop();
			if(ERROR_SUCCESS != iRet)
			{
				if(ERROR_INVALID_STATE != iRet)
				{
					PRINT_BFILE_LINENO_IRET_STR;
				}
			}
		}

		MsgData_sp->m_uiMsgId = MSG_CMD_EXIT_THREAD;
		iRet = GenericMsg_sp->SetMessageData(MsgData_sp);
		if(CC_UNLIKELY(ERROR_SUCCESS != iRet))
		{
			iOutRet = iRet;
			break;
		}
		iRet = PostMessage(GenericMsg_sp);
		if(CC_UNLIKELY(ERROR_SUCCESS != iRet))
		{
			iOutRet = iRet;
			break;
		}		

		Interrupt();	//cause EINTR
		//Wait for the worker thread to finish
		INT_t iChkIntervalMs = 20;
		UINT64_t StartTimeMs = GetSysUpTimeMs();
		while(getThreadIsRunning())
		{	
			usleep(iChkIntervalMs*1000);
			UINT64_t CurTimeMs = GetSysUpTimeMs();
			if(CC_UNLIKELY((2*1000) <= (CurTimeMs - StartTimeMs)))
			{
				LOG_BLINE("WaitForThrdExit,timeout\n");
				Interrupt();	//cause EINTR			
				StartTimeMs = CurTimeMs;
			}
		}
	}while(FALSE);

	eRMstatus = PlayCtrlCtx_setDataIoTimeoutCb(m_pPlayCtrlCtx, NULL);
	if(RMFAILED(eRMstatus))
	{
		PRINT_BFILE_LINENO_RMSTATUS;
	}
	
	return iOutRet;
}

/*
ThreadContext: local worker thread
*/
PVOID CMediaSrv::ThreadLoop()
{
	INT_t iRet;
	RMstatus eRMstatus = RM_OK;
	void * pOutRet = 0;
	SharedPtr<CMessageQueueItem> TransactionMsg;
	bool bPlayCtrlCtx_set = false;
	INT_t iNextTimeoutMs;

	if(m_pPlayCtrlCtx)
	{
		eRMstatus = PlayCtrlCtx_TLS_setValue(m_pPlayCtrlCtx);
		if(RMFAILED(eRMstatus))
		{
			PRINT_BFILE_LINENO_RMSTATUS;
		}
		else
		{
			bPlayCtrlCtx_set = true;
		}		
	}

	while(TRUE)
	{		
		if(CC_UNLIKELY(m_bShouldExitThread))
		{
			iRet = ClearAllMessage();	//we must SetEvent on all msgs or they which are waiting on these events will be always blocked
			if(ERROR_SUCCESS != iRet)
			{
				PRINT_BFILE_LINENO_IRET_STR;
			}
			break;
		}
		iRet = m_GenericTimer.getNextTimeoutMs(OUT iNextTimeoutMs);
		if(ERROR_SUCCESS == iRet)
		{
			if(0 > iNextTimeoutMs)	//-1, infinite
			{
				iNextTimeoutMs = (10*1000);
			}
		}
		else
		{
			PRINT_BFILE_LINENO_IRET_STR;
			iNextTimeoutMs = (10*1000);
		}
		iRet = GetMessageTimeout(TransactionMsg, iNextTimeoutMs);
		if(CC_LIKELY(ERROR_SUCCESS == iRet))
		{
			if(CC_LIKELY(TransactionMsg.isValid()))
			{
				ProcessMsg(TransactionMsg);
				TransactionMsg.Clear();
			}
		}
		else if(CC_LIKELY(ERR_TIMEOUT == iRet))
		{
			iRet = m_GenericTimer.CheckAndTrig();
			if(ERROR_SUCCESS != iRet)
			{
				PRINT_BFILE_LINENO_IRET_STR;
			}
		}
		else if(CC_LIKELY(ERR_LINUX_SIGNAL_INT == iRet))
		{
		}
		else
		{
			PRINT_BFILE_LINENO_IRET_CRT_ERR;
		}
		
		DBusConnWakeUp_ClearMsg();
	}	

	if(bPlayCtrlCtx_set)
	{
		eRMstatus = PlayCtrlCtx_TLS_unsetValue();
		if(RMFAILED(eRMstatus))
		{
			PRINT_BFILE_LINENO_RMSTATUS;
		}
		bPlayCtrlCtx_set = false;
	}

	return pOutRet;
}

INT_t CMediaSrv::ClearAllMessage()
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	SharedPtr<CMessageQueueItem> TransactionMsg;
	SharedPtr<CGenericMsgData> GenMsgData_sp;

	do
	{
		while(TRUE)
		{
			//the timeout value of 0 means only test on it
			iRet = GetMessageTimeout(TransactionMsg, 0);
			if(CC_LIKELY(ERROR_SUCCESS == iRet))
			{
				if(CC_LIKELY(NULL != TransactionMsg.get()))
				{
					GenMsgData_sp = TransactionMsg->GetMessageData();
					if(CC_LIKELY(NULL != GenMsgData_sp.get()))
					{
						GenMsgData_sp->m_iOutRet = ERROR_INVALID_STATE;
					}
					iRet = TransactionMsg->SetEvent();
					if(CC_UNLIKELY(ERROR_SUCCESS != iRet))
					{
						PRINT_BFILE_LINENO_IRET_CRT_ERR;
					}
					TransactionMsg.Clear();
				}
			}
			else if(CC_LIKELY(ERR_TIMEOUT == iRet))	//no more msg, should break.
			{
				break;
			}
			else if(CC_LIKELY(ERR_LINUX_SIGNAL_INT == iRet))
			{
			}
			else
			{
				PRINT_BFILE_LINENO_IRET_CRT_ERR;
				break;
			}
		}
	}while(FALSE);

	return iOutRet;
}

VOID CMediaSrv::ProcessMsg(SharedPtr<CMessageQueueItem> & TransactionMsg)
{
	INT_t iRet;
	SharedPtr<CGenericMsgData> GenMsgData_sp;

	do
	{
		GenMsgData_sp = TransactionMsg->GetMessageData();
		if(CC_UNLIKELY(NULL == GenMsgData_sp.get()))
		{
			iRet = TransactionMsg->SetEvent();
			if(CC_UNLIKELY(ERROR_SUCCESS != iRet))
			{
				PRINT_BFILE_LINENO_IRET_CRT_ERR;
			}
			break;
		}

		//LOG_BLINE("MsgId:%d\n", GenMsgData_sp->m_uiMsgId);

		if(MSG_CMD_EXIT_THREAD == GenMsgData_sp->m_uiMsgId)
		{
			GenMsgData_sp->m_iOutRet = ERROR_SUCCESS;
			iRet = TransactionMsg->SetEvent();
			if(CC_UNLIKELY(ERROR_SUCCESS != iRet))
			{
				PRINT_BFILE_LINENO_IRET_CRT_ERR;
			}
		}
		else if(MSG_CMD_setDataSource == GenMsgData_sp->m_uiMsgId)
		{
			GenMsgData_sp->m_iOutRet = On_setDataSource(GenMsgData_sp);
			iRet = TransactionMsg->SetEvent();
			if(CC_UNLIKELY(ERROR_SUCCESS != iRet))
			{
				PRINT_BFILE_LINENO_IRET_CRT_ERR;
			}
		}
		else if(MSG_CMD_Prepare == GenMsgData_sp->m_uiMsgId)
		{
			GenMsgData_sp->m_iOutRet = On_Prepare(GenMsgData_sp);
			iRet = TransactionMsg->SetEvent();
			if(CC_UNLIKELY(ERROR_SUCCESS != iRet))
			{
				PRINT_BFILE_LINENO_IRET_CRT_ERR;
			}
		}
		else if(MSG_CMD_Play == GenMsgData_sp->m_uiMsgId)
		{
			On_Play(GenMsgData_sp, TransactionMsg);
		}
		else if(MSG_CMD_Stop == GenMsgData_sp->m_uiMsgId)
		{
			GenMsgData_sp->m_iOutRet = On_Stop(GenMsgData_sp);
			iRet = TransactionMsg->SetEvent();
			if(CC_UNLIKELY(ERROR_SUCCESS != iRet))
			{
				PRINT_BFILE_LINENO_IRET_CRT_ERR;
			}
		}
		else if(MSG_CMD_QuitPlay == GenMsgData_sp->m_uiMsgId)
		{
			GenMsgData_sp->m_iOutRet = onQuitPlay(TransactionMsg, GenMsgData_sp);
			iRet = TransactionMsg->SetEvent();
			if(CC_UNLIKELY(ERROR_SUCCESS != iRet))
			{
				PRINT_BFILE_LINENO_IRET_CRT_ERR;
			}
		}
		else if(MSG_CMD_setPlayMode == GenMsgData_sp->m_uiMsgId)
		{
			GenMsgData_sp->m_iOutRet = On_setPlayMode(TransactionMsg);
			iRet = TransactionMsg->SetEvent();
			if(CC_UNLIKELY(ERROR_SUCCESS != iRet))
			{
				PRINT_BFILE_LINENO_IRET_CRT_ERR;
			}
		}
		else if(MSG_CMD_getPlayMode == GenMsgData_sp->m_uiMsgId)
		{
			GenMsgData_sp->m_iOutRet = On_getPlayMode(TransactionMsg);
			iRet = TransactionMsg->SetEvent();
			if(CC_UNLIKELY(ERROR_SUCCESS != iRet))
			{
				PRINT_BFILE_LINENO_IRET_CRT_ERR;
			}
		}
		else if(MSG_CMD_setVideoPosition == GenMsgData_sp->m_uiMsgId)
		{			
			//LOG_BLINE("MSG_CMD_setVideoPosition\n");
			GenMsgData_sp->m_iOutRet = On_setVideoPosition(TransactionMsg);
			iRet = TransactionMsg->SetEvent();
			if(CC_UNLIKELY(ERROR_SUCCESS != iRet))
			{
				PRINT_BFILE_LINENO_IRET_CRT_ERR;
			}
		}
		else if(MSG_CMD_setVideoInputWindowSize == GenMsgData_sp->m_uiMsgId)
		{			
			GenMsgData_sp->m_iOutRet = On_setVideoInputWindowSize(TransactionMsg);
			iRet = TransactionMsg->SetEvent();
			if(CC_UNLIKELY(ERROR_SUCCESS != iRet))
			{
				PRINT_BFILE_LINENO_IRET_CRT_ERR;
			}
		}
		else if(MSG_CMD_ChangeVidOutMode == GenMsgData_sp->m_uiMsgId)
		{			
			GenMsgData_sp->m_iOutRet = On_ChangeVidOutMode(TransactionMsg);
			iRet = TransactionMsg->SetEvent();
			if(CC_UNLIKELY(ERROR_SUCCESS != iRet))
			{
				PRINT_BFILE_LINENO_IRET_CRT_ERR;
			}
		}
		else if(MSG_CMD_setOutputSpdifMode == GenMsgData_sp->m_uiMsgId)
		{
			GenMsgData_sp->m_iOutRet = On_SetOutputSpdifMode(TransactionMsg);
			iRet = TransactionMsg->SetEvent();
			if(CC_UNLIKELY(ERROR_SUCCESS != iRet))
			{
				PRINT_BFILE_LINENO_IRET_CRT_ERR;
			}
		}
		else if(MSG_CMD_setPlaySpeedCtrl == GenMsgData_sp->m_uiMsgId)
		{			
			//GenMsgData_sp->m_iOutRet = On_setPlaySpeedCtrl(TransactionMsg);
			GenMsgData_sp->m_iOutRet = ERROR_INVALID_STATE;
			iRet = TransactionMsg->SetEvent();
			if(CC_UNLIKELY(ERROR_SUCCESS != iRet))
			{
				PRINT_BFILE_LINENO_IRET_CRT_ERR;
			}
		}
		else if(MSG_CMD_getPlaySpeedCtrl == GenMsgData_sp->m_uiMsgId)
		{			
			GenMsgData_sp->m_iOutRet = On_getPlaySpeedCtrl(TransactionMsg);
			iRet = TransactionMsg->SetEvent();
			if(CC_UNLIKELY(ERROR_SUCCESS != iRet))
			{
				PRINT_BFILE_LINENO_IRET_CRT_ERR;
			}
		}
		else if(MSG_CMD_DispOnLedScr == GenMsgData_sp->m_uiMsgId)
		{			
			GenMsgData_sp->m_iOutRet = On_DispOnLedScr(TransactionMsg);
			iRet = TransactionMsg->SetEvent();
			if(CC_UNLIKELY(ERROR_SUCCESS != iRet))
			{
				PRINT_BFILE_LINENO_IRET_CRT_ERR;
			}
		}
#ifdef ENABLE_DTV
		else if(MSG_CMD_PlayTuner == GenMsgData_sp->m_uiMsgId)
		{
			iRet = On_PlayTuner(GenMsgData_sp,TransactionMsg);
			if(ERROR_SUCCESS != iRet)
			{
				iRet = StopTunerPlayer();
				if(ERROR_SUCCESS != iRet)
				{
					PRINT_BFILE_LINENO_IRET_CRT_ERR;
				}
			}
		}
		else if(MSG_CMD_TunerScan == GenMsgData_sp->m_uiMsgId)
		{
			iRet = On_TunerScan(GenMsgData_sp, TransactionMsg);
			//if(ERROR_SUCCESS != iRet)
			{
				iRet = StopTunerPlayer();
				if(ERROR_SUCCESS != iRet)
				{
					PRINT_BFILE_LINENO_IRET_CRT_ERR;
				}
			}
		}
		else if(MSG_CMD_ResetDuration == GenMsgData_sp->m_uiMsgId)
		{
			On_ResetDuration(GenMsgData_sp, TransactionMsg);
		}
		else if(MSG_CMD_GetSignalStrength == GenMsgData_sp->m_uiMsgId)
		{
			On_GetSignalStrength(GenMsgData_sp,TransactionMsg);
		}
		else if(MSG_CMD_GetFirstChNum == GenMsgData_sp->m_uiMsgId)
		{
			On_GetFirstChNum(GenMsgData_sp,TransactionMsg);
		}
		else if(MSG_CMD_TunerMode == GenMsgData_sp->m_uiMsgId)
		{
			On_SetTunerStandardMode(GenMsgData_sp,TransactionMsg);
		}
		else if(MSG_CMD_GetTunerMode == GenMsgData_sp->m_uiMsgId)
		{
			On_GetTunerStandardMode(GenMsgData_sp,TransactionMsg);
		}
		else if(MSG_CMD_ChannelUp == GenMsgData_sp->m_uiMsgId)
		{
			On_SetChannelUp(TransactionMsg);
		}
		else if(MSG_CMD_ChannelDown == GenMsgData_sp->m_uiMsgId)
		{
			On_SetChannelDown(TransactionMsg);
		}
		else if(MSG_CMD_ReLoadProgram == GenMsgData_sp->m_uiMsgId)
		{
			On_ReLoadProgramTable(TransactionMsg);
		}
		else if(MSG_CMD_GetEntryChannelInfo == GenMsgData_sp->m_uiMsgId)
		{
			On_GetEntryChannelInfo(GenMsgData_sp,TransactionMsg);
		}
		else if(MSG_CMD_SetTunerChannelMode == GenMsgData_sp->m_uiMsgId)
		{
			On_SetTunerChannelMode(GenMsgData_sp,TransactionMsg);
		}
		else if(MSG_CMD_GetTunerChannelMode == GenMsgData_sp->m_uiMsgId)
		{
			On_GetTunerChannelMode(GenMsgData_sp,TransactionMsg);
		}
#endif
		else if(MSG_CMD_setShowClosedCaption == GenMsgData_sp->m_uiMsgId)
		{
			GenMsgData_sp->m_iOutRet = On_setShowClosedCaption(TransactionMsg);
			iRet = TransactionMsg->SetEvent();
			if(CC_UNLIKELY(ERROR_SUCCESS != iRet))
			{
				PRINT_BFILE_LINENO_IRET_CRT_ERR;
			}
		}
		else if(MSG_CMD_setVideoRotation== GenMsgData_sp->m_uiMsgId)
		{
			GenMsgData_sp->m_iOutRet = On_setVideoRotation(TransactionMsg);
			iRet = TransactionMsg->SetEvent();
			if(CC_UNLIKELY(ERROR_SUCCESS != iRet))
			{
				PRINT_BFILE_LINENO_IRET_CRT_ERR;
			}
		}
		else if(MSG_CMD_setEnableAudio6Ch== GenMsgData_sp->m_uiMsgId)
		{
			GenMsgData_sp->m_iOutRet = On_setEnableAudio6Ch(TransactionMsg);
			iRet = TransactionMsg->SetEvent();
			if(CC_UNLIKELY(ERROR_SUCCESS != iRet))
			{
				PRINT_BFILE_LINENO_IRET_CRT_ERR;
			}
		}
        else if(MSG_CMD_getEnableAudio6Ch== GenMsgData_sp->m_uiMsgId)
		{
			GenMsgData_sp->m_iOutRet = On_getEnableAudio6Ch(TransactionMsg);
			iRet = TransactionMsg->SetEvent();
			if(CC_UNLIKELY(ERROR_SUCCESS != iRet))
			{
				PRINT_BFILE_LINENO_IRET_CRT_ERR;
			}
		}
		else
		{
			GenMsgData_sp->m_iOutRet = ERR_INVALID_CMD;
			iRet = TransactionMsg->SetEvent();
			if(CC_UNLIKELY(ERROR_SUCCESS != iRet))
			{
				PRINT_BFILE_LINENO_IRET_CRT_ERR;
			}
		}
	}while(FALSE);
}

INT_t CMediaSrv::setDataSource(LPCSTR pszDataSrcUrl)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	SharedPtr <CMsgData_setDataSource> MsgData_setDataSource_sp(new CMsgData_setDataSource);
	SharedPtr<CMessageQueueItem> ThreadMsg_sp(new CMessageQueueItem);

	do
	{
		if(NULL == MsgData_setDataSource_sp.get())
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}
		if(NULL == ThreadMsg_sp.get())
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}
		MsgData_setDataSource_sp->m_uiMsgId = MSG_CMD_setDataSource;
		MsgData_setDataSource_sp->m_strDataSrcUrl = pszDataSrcUrl;
		iRet = ThreadMsg_sp->SetMessageData((SharedPtr<CGenericMsgData>&)MsgData_setDataSource_sp);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}

		iRet = SendMessage(ThreadMsg_sp);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}
		iOutRet = MsgData_setDataSource_sp->m_iOutRet;
	}while(FALSE);

	return iOutRet;
}

INT_t CMediaSrv::Prepare()
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	SharedPtr <CGenericMsgData> MsgData_Prepare_sp(new CGenericMsgData);
	SharedPtr<CMessageQueueItem> ThreadMsg_sp(new CMessageQueueItem);

	do
	{
		if(NULL == MsgData_Prepare_sp.get())
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}
		if(NULL == ThreadMsg_sp.get())
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}
		MsgData_Prepare_sp->m_uiMsgId = MSG_CMD_Prepare;
		iRet = ThreadMsg_sp->SetMessageData((SharedPtr<CGenericMsgData>&)MsgData_Prepare_sp);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}

		iRet = SendMessage(ThreadMsg_sp);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}
		iOutRet = MsgData_Prepare_sp->m_iOutRet;
	}while(FALSE);

	return iOutRet;
}

/*
ThreadContext: others
*/
INT_t CMediaSrv::Play(OUT UINT32_t * pPlaybackId/* = NULL*/, IN CMediaSrv::P_PLAY_PARAMS pPlayParams/* = NULL*/)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	RMstatus eRMstatus = RM_OK;
	SharedPtr <CMsgData_Play> MsgData_Play_sp(new CMsgData_Play);
	SharedPtr<CMessageQueueItem> ThreadMsg_sp(new CMessageQueueItem);
	SharedPtr <CGenericMsgData> MsgData_sp;

	do
	{
		if(NULL == MsgData_Play_sp.get())
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}
		if(NULL == ThreadMsg_sp.get())
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}

		if(m_pPlayCtrlCtx)
		{
			eRMstatus = PlayCtrlCtx_setShouldStopDataIO(m_pPlayCtrlCtx, FALSE);
			if(RMFAILED(eRMstatus))
			{
				PRINT_BFILE_LINENO_RMSTATUS;
			}
			eRMstatus = PlayCtrlCtx_ResetDataIoErrState(m_pPlayCtrlCtx);
			if(RMFAILED(eRMstatus))
			{
				PRINT_BFILE_LINENO_RMSTATUS;
			}
		}

		MsgData_Play_sp->m_uiMsgId = MSG_CMD_Play;
		if(pPlayParams)
		{
			MsgData_Play_sp->LoopCount = pPlayParams->LoopCount;
#if 1/*added by lxj 2013-1-8*/
			MsgData_Play_sp->bPauseAfterBuffering = pPlayParams->bPauseAfterBuffering;
#endif
		}
		else
		{
			MsgData_Play_sp->LoopCount = 1;
#if 1/*added by lxj 2013-1-8*/
			MsgData_Play_sp->bPauseAfterBuffering = FALSE;
#endif
		}
		MsgData_sp = MsgData_Play_sp;
		iRet = ThreadMsg_sp->SetMessageData(MsgData_sp);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}

		iRet = SendMessage(ThreadMsg_sp);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}
		if(pPlaybackId)
		{
			*pPlaybackId = MsgData_Play_sp->m_PlaybackId;
		}
		iOutRet = MsgData_Play_sp->m_iOutRet;
	}while(FALSE);

	return iOutRet;
}

/*
ThreadContext: other threads
*/
INT_t CMediaSrv::Stop(OUT UINT32_t * pPlaybackId/* = NULL*/, OUT CStackBufString * pStrUrl/* = NULL*/)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	RMstatus eRMstatus = RM_OK;
	SharedPtr <CGenericMsgData> MsgData_Stop_sp;
	SharedPtr<CMessageQueueItem> ThreadMsg_sp;

#if 0/*2012-11-9 for test how many time is spend in this function*/
	DBG_TIME("%s() begin\n",__func__);
#endif

	//RMLOGFL((ENABLE, "Jiffies=%lu\n", times(NULL)));

	do
	{
		//thread context check
		if(CC_UNLIKELY(GetThreadId() == pthread_self()))
		{
			LOG_BLINE("BUG,can not call from same thread\n");
			break;
		}

		if(pPlaybackId)
		{
			*pPlaybackId = 0;	//invalid
		}

		m_bCanProcessMsgInDataIoTimeoutCb = FALSE;

		iRet = m_PlayStatChangedEvent.ResetEvent();
		if(ERROR_SUCCESS != iRet)
		{
			PRINT_BFILE_LINENO_IRET_STR;
		}

		if(NULL != m_pPlayCtrlCtx)
		{
			eRMstatus = PlayCtrlCtx_setShouldStopDataIO(m_pPlayCtrlCtx, TRUE);
			if(RMFAILED(eRMstatus))
			{
				PRINT_BFILE_LINENO_RMSTATUS;
			}				
		}

		MsgData_Stop_sp = SharedPtr <CGenericMsgData>(new CGenericMsgData);
		ThreadMsg_sp = SharedPtr<CMessageQueueItem> (new CMessageQueueItem);
		if(NULL == MsgData_Stop_sp.get())
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}
		if(NULL == ThreadMsg_sp.get())
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}
		
		MsgData_Stop_sp->m_uiMsgId = MSG_CMD_Stop;
		iRet = ThreadMsg_sp->SetMessageData((SharedPtr<CGenericMsgData>&)MsgData_Stop_sp);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}

		iRet = PostMessage(ThreadMsg_sp);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}
		//QuitPlay
		SharedPtr <CMsgData_QuitPlay> MsgData_QuitPlay_sp(new CMsgData_QuitPlay);
		if(MsgData_QuitPlay_sp.isNull())
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}
		ThreadMsg_sp = SharedPtr<CMessageQueueItem> (new CMessageQueueItem);
		if(NULL == ThreadMsg_sp.get())
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}
		MsgData_QuitPlay_sp->m_uiMsgId = MSG_CMD_QuitPlay;
		iRet = ThreadMsg_sp->SetMessageData((SharedPtr<CGenericMsgData>&)MsgData_QuitPlay_sp);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}

		iRet = PostMessage(ThreadMsg_sp);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}
		Interrupt();	//cause EINTR
		while(TRUE)
		{
			iRet = ThreadMsg_sp->WaitEventTimeout(1*1000);
			if(ERROR_SUCCESS == iRet)
			{
				break;
			}
			if(FALSE == getThreadIsRunning())
			{
				break;
			}
		}
		//wait the status to be changed
		while(TRUE)
		{
			if(FALSE == getThreadIsRunning())
			{
				break;
			}
			if(PLAY_STAT_IDLE == m_iPlayStatus)
			{
				break;
			}
			iRet = m_PlayStatChangedEvent.WaitEventTimeout(1*1000);
			if(ERROR_SUCCESS == iRet)
			{
				if(PLAY_STAT_IDLE != m_iPlayStatus)
				{
					iRet = m_PlayStatChangedEvent.ResetEvent();	//want the next change event
					if(ERROR_SUCCESS != iRet)
					{
						PRINT_BFILE_LINENO_IRET_STR;
					}
				}
			}
			else if(ERR_TIMEOUT == iRet)
			{
			}
			else	//err
			{
				PRINT_BFILE_LINENO_IRET_STR;
			}
			if(PLAY_STAT_IDLE == m_iPlayStatus)
			{
				break;
			}
		}
		iOutRet = (MsgData_QuitPlay_sp->m_iOutRet);
		{
			CAutoScopeLock autoScopeLock(&(MsgData_QuitPlay_sp->mLock));
			if(pStrUrl)
			{
				*pStrUrl = MsgData_QuitPlay_sp->m_strUrl;
			}
			if(pPlaybackId)
			{
				*pPlaybackId = MsgData_QuitPlay_sp->m_PlaybackId;
			}
		}
	}while(FALSE);

#if 0/*2012-11-9 for test how many time is spend in this function*/
	DBG_TIME("%s() end\n",__func__);
#endif

	//RMLOGFL((ENABLE, "Jiffies=%lu\n", times(NULL)));

	return iOutRet;
}


/*
ThreadContext: play thread
*/
INT_t CMediaSrv::On_setDataSource(SharedPtr<CGenericMsgData> & GenMsgData_sp)
{
	INT_t iOutRet = ERROR_SUCCESS;
	DECLARE_CLS_STACK_BUF_STRING(strTmpDataSrcUrl, (4*1024));
	
	CAutoLock AutoRangeLocker(&m_SharedDataMutex);
	SharedPtr <CMsgData_setDataSource> MsgData_setDataSource_sp;

	do
	{
		if(PLAY_STAT_IDLE != m_iPlayStatus)
		{
			iOutRet = ERROR_INVALID_STATE;
			break;
		}
		MsgData_setDataSource_sp = GenMsgData_sp.DynamicCast<CMsgData_setDataSource>();
		if(MsgData_setDataSource_sp.isNull())
		{
			iOutRet = ERROR_INVALID_PARAMETER;
			PRINT_BFILE_LINENO_BUG_STR;
			break;
		}
		//parse data source list
		m_strDataSrcUrl = MsgData_setDataSource_sp->m_strDataSrcUrl;
		strTmpDataSrcUrl = MsgData_setDataSource_sp->m_strDataSrcUrl;
		m_strDataSrcUrlList = strTmpDataSrcUrl.Split('\n');
		m_CntNodeInUrlList = m_strDataSrcUrlList.size();
		
		m_currIterator = m_strDataSrcUrlList.begin();	
	}while(FALSE);

	return iOutRet;
}

/*
ThreadContext: play thread
*/
INT_t CMediaSrv::On_Prepare(SharedPtr<CGenericMsgData> & GenMsgData_sp)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	CAutoLock AutoRangeLocker(&m_SharedDataMutex);
	INT_t iOldPlayStaus;
	struct RMFPOptions *pOptions = &m_RmfpOptions;

	do
	{
		if(PLAY_STAT_IDLE != m_iPlayStatus)
		{
			iOutRet = ERROR_INVALID_STATE;
			break;
		}
		//init
		m_RmfpMainContext.stream_type.application_type = RMFP_application_type_UNKNOWN;	
		//ClosedCaption
		if(CC_SEL_CC1 == m_eShowClosedCaption)
		{
			pOptions->video_options.CloseCaptionMode = RMFPCloseCaptionMode_ShowInOSD;
			pOptions->video_options.CloseCaptionType = RMFPCloseCaptionType_EIA608;
			pOptions->video_options.CloseCaptionSelect = EMhwlibCCSelect_CC1;
		}
		else if(CC_SEL_CC2 == m_eShowClosedCaption)
		{
			pOptions->video_options.CloseCaptionMode = RMFPCloseCaptionMode_ShowInOSD;
			pOptions->video_options.CloseCaptionType = RMFPCloseCaptionType_EIA608;
			pOptions->video_options.CloseCaptionSelect = EMhwlibCCSelect_CC2;
		}
		else if(CC_SEL_CC3 == m_eShowClosedCaption)
		{
			pOptions->video_options.CloseCaptionMode = RMFPCloseCaptionMode_ShowInOSD;
			pOptions->video_options.CloseCaptionType = RMFPCloseCaptionType_EIA608;
			pOptions->video_options.CloseCaptionSelect = EMhwlibCCSelect_CC3;
		}
		else if(CC_SEL_CC4 == m_eShowClosedCaption)
		{
			pOptions->video_options.CloseCaptionMode = RMFPCloseCaptionMode_ShowInOSD;
			pOptions->video_options.CloseCaptionType = RMFPCloseCaptionType_EIA608;
			pOptions->video_options.CloseCaptionSelect = EMhwlibCCSelect_CC4;
		}
		else if(CC_SEL_EIA708 == m_eShowClosedCaption)
		{
			pOptions->video_options.CloseCaptionMode = RMFPCloseCaptionMode_ShowInOSD;
			pOptions->video_options.CloseCaptionType = RMFPCloseCaptionType_EIA708;
			pOptions->video_options.CloseCaptionSelect = EMhwlibCCSelect_CC1;
		}
		else
		{
			pOptions->video_options.CloseCaptionMode = RMFPCloseCaptionMode_Disabled;
		}
		//state
		iOldPlayStaus = m_iPlayStatus;
		m_iPlayStatus = PLAY_STAT_PREPARED;
		iRet = m_Mp7xxGlobalStatusData.setMpSrvPlayStatus(m_iPlayStatus);
		if(ERROR_SUCCESS != iRet)
		{
			PRINT_BFILE_LINENO_IRET_STR;
		}
		if(iOldPlayStaus != m_iPlayStatus)
		{
			iRet = m_PlayStatChangedEvent.SetEvent();
			if(ERROR_SUCCESS != iRet)
			{
				PRINT_BFILE_LINENO_IRET_STR;
			}		
		}
	}while(FALSE);
	
	return iOutRet;
}

INT_t CMediaSrv::RmfpUninit()
{
	INT_t iOutRet = ERROR_SUCCESS;
	struct rmfp_main_thread_context_type *pMainContext = &m_RmfpMainContext;

	do
	{
		if(pMainContext->GetKeyCS)
		{
			RMDeleteCriticalSection(pMainContext->GetKeyCS);			
			pMainContext->GetKeyCS = NULL;
		}
	}while(FALSE);

	return iOutRet;
}

RMstatus CMediaSrv::RMFPOptions_RestoreSet(struct RMFPOptions *pOption)
{
	RMstatus eRMstatus;
	struct rmfp_main_thread_context_type *pMainContext = &m_RmfpMainContext;
	
	do{
		eRMstatus = Rmfp_setRequestQuitPlay(pMainContext->pHandle, FALSE);
		if(RMFAILED(eRMstatus))
		{
			PRINT_BFILE_LINENO_RMSTATUS;
		}
		
		if(NULL == pOption) return RM_ERROR;

#if	0
		//PLAYBACK OPTION
		pOption->playback_options.WaitExit = m_RmfpOptionsBackup.playback_options.WaitExit;
		pOption->playback_options.duration = m_RmfpOptionsBackup.playback_options.duration;
		pOption->playback_options.dmapool_count = m_RmfpOptionsBackup.playback_options.dmapool_count;
		pOption->playback_options.dmapool_log2size = m_RmfpOptionsBackup.playback_options.dmapool_log2size;
		pOption->playback_options.send_audio = m_RmfpOptionsBackup.playback_options.send_audio;
		pOption->playback_options.send_audio_pts = m_RmfpOptionsBackup.playback_options.send_audio_pts;
		pOption->playback_options.send_video = m_RmfpOptionsBackup.playback_options.send_video;
		pOption->playback_options.send_video_pts = m_RmfpOptionsBackup.playback_options.send_video_pts;
		pOption->playback_options.send_spu = m_RmfpOptionsBackup.playback_options.send_spu;
		pOption->playback_options.send_spu_pts = m_RmfpOptionsBackup.playback_options.send_spu_pts;

		//VIDEO OPTION
		pOption->video_options.skipNCP = m_RmfpOptionsBackup.video_options.skipNCP;
		pOption->video_options.vcodec = m_RmfpOptionsBackup.video_options.vcodec;
		pOption->video_options.vcodec_max_width      = m_RmfpOptionsBackup.video_options.vcodec_max_width;
		pOption->video_options.vcodec_max_height     = m_RmfpOptionsBackup.video_options.vcodec_max_height;
		pOption->video_options.vcodec_profile        = m_RmfpOptionsBackup.video_options.vcodec_profile;
		pOption->video_options.vcodec_level          = m_RmfpOptionsBackup.video_options.vcodec_level;
		pOption->video_options.vcodec_extra_pictures = m_RmfpOptionsBackup.video_options.vcodec_extra_pictures;

		//AUDIO OPTION
		pOption->audio_options.Codec = m_RmfpOptionsBackup.audio_options.Codec;
		pOption->audio_options.SubCodec  = m_RmfpOptionsBackup.audio_options.SubCodec;
		pOption->audio_options.DTS_CD = m_RmfpOptionsBackup.audio_options.DTS_CD;
		pOption->audio_options.MsbFirst = m_RmfpOptionsBackup.audio_options.MsbFirst;
		pOption->audio_options.skip_first_n_bytes = m_RmfpOptionsBackup.audio_options.skip_first_n_bytes;
		pOption->audio_options.send_n_bytes = m_RmfpOptionsBackup.audio_options.send_n_bytes;
		pOption->audio_options.SignedPCM = m_RmfpOptionsBackup.audio_options.SignedPCM;
		pOption->audio_options.bit_per_sample = m_RmfpOptionsBackup.audio_options.bit_per_sample;
		pOption->audio_options.PCMSamplingFrequency = m_RmfpOptionsBackup.audio_options.PCMSamplingFrequency;

		//DEMUX
		pOption->demux_options.ts_skip = m_RmfpOptionsBackup.demux_options.ts_skip;
		pOption->demux_options.system_type = m_RmfpOptionsBackup.demux_options.system_type;
		pOption->demux_options.default_pmt_pid = m_RmfpOptionsBackup.demux_options.default_pmt_pid;

		//PICTURE
		pOption->playback_options.PictureFormat = m_RmfpOptionsBackup.playback_options.PictureFormat;
#else
		//maybe a little performance consumption
		*pOption = m_RmfpOptionsBackup;
#endif
	}while(FALSE);

	return RM_OK;
}


#ifdef ENABLE_DTV
INT_t CMediaSrv::ReLoadProgramTable()
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	SharedPtr<CMessageQueueItem> ThreadMsg_sp(new CMessageQueueItem);
	SharedPtr <CGenericMsgData> MsgData_sp(new CGenericMsgData);

	do{
		if(NULL == MsgData_sp.get())
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}

		if(NULL == ThreadMsg_sp.get())
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}

		MsgData_sp->m_uiMsgId = MSG_CMD_ReLoadProgram;
		iRet = ThreadMsg_sp->SetMessageData(MsgData_sp);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}
		
		iRet = PostMessage(ThreadMsg_sp);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}
	}while(FALSE);

	return iOutRet;
}


INT_t CMediaSrv::SetScanProgressListner(WeakPtr <IMediaSrvScanProgressListener> MediaScanProgressListener_wp)
{
	INT_t iOutRet = ERROR_SUCCESS;

	{
		CAutoLock AutoRangeLocker(&m_SharedDataMutex);
		m_MediaSrvScanProgressListener_wp = MediaScanProgressListener_wp;
	}

	return iOutRet;
}

INT_t CMediaSrv::ProcessEventForTuneProgram()
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;

	//LOG_BLINE("%s\n", __FUNCTION__);

	do{		
		{
			CAutoLock AutoRangeLocker(&m_SharedDataMutex);
			if(PLAY_STAT_PLAYING != m_iPlayStatus )
			{
				iOutRet = ERROR_INVALID_STATE;
				break;
			}
		}

		if(m_TunerSrv_sp.isNull())
		{
			iOutRet = ERROR_INVALID_STATE;
			break;
		}
		
		m_TunerSrv_sp->OnEventTuneProgram();
	}while(FALSE);

	return iOutRet;
}

INT_t CMediaSrv::SetChannelDown()
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	SharedPtr <CGenericMsgData> MsgData_sp(new CGenericMsgData);
	SharedPtr<CMessageQueueItem> ThreadMsg_sp(new CMessageQueueItem);

	do{
		if(NULL == MsgData_sp.get())
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}

		if(NULL == ThreadMsg_sp.get())
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}

		MsgData_sp->m_uiMsgId = MSG_CMD_ChannelDown;
		iRet = ThreadMsg_sp->SetMessageData(MsgData_sp);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}
		
		iRet = SendMessage(ThreadMsg_sp);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}
		
		iOutRet = MsgData_sp->m_iOutRet;
		
	}while(FALSE);

	return iOutRet;
}

INT_t CMediaSrv::TunerMode(IN INT32_t iStdMode)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	SharedPtr <CMsgData_SetTuMode> MsgSetTuStandardMode_sp(new CMsgData_SetTuMode);
	SharedPtr<CMessageQueueItem> ThreadMsg_sp(new CMessageQueueItem);
	SharedPtr <CGenericMsgData> MsgData_sp;

	do{
		if(MsgSetTuStandardMode_sp.isNull())
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}

		if(ThreadMsg_sp.isNull())
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}

		MsgSetTuStandardMode_sp->m_uiMsgId = MSG_CMD_TunerMode;
		MsgSetTuStandardMode_sp->m_iStdMode = iStdMode;
		MsgData_sp = MsgSetTuStandardMode_sp;
		iRet = ThreadMsg_sp->SetMessageData(MsgData_sp);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}
		
		iRet = SendMessage(ThreadMsg_sp);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}
		
	}while(FALSE);

	return iOutRet;
}

INT_t CMediaSrv::SetChannelUp()
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	SharedPtr <CGenericMsgData> MsgData_sp(new CGenericMsgData);
	SharedPtr<CMessageQueueItem> ThreadMsg_sp(new CMessageQueueItem);

	do{
		if(NULL == MsgData_sp.get())
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}

		if(NULL == ThreadMsg_sp.get())
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}

		MsgData_sp->m_uiMsgId = MSG_CMD_ChannelUp;
		iRet = ThreadMsg_sp->SetMessageData(MsgData_sp);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}
		
		iRet = SendMessage(ThreadMsg_sp);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}
		
		iOutRet = MsgData_sp->m_iOutRet;
		
	}while(FALSE);

	return iOutRet;
}

INT_t CMediaSrv::ResetDuration()
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	SharedPtr <CGenericMsgData> MsgData_sp(new CGenericMsgData);
	SharedPtr<CMessageQueueItem> ThreadMsg_sp(new CMessageQueueItem);

	do{
		if(NULL == MsgData_sp.get())
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}

		if(NULL == ThreadMsg_sp.get())
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}

		MsgData_sp->m_uiMsgId = MSG_CMD_ResetDuration;
		iRet = ThreadMsg_sp->SetMessageData(MsgData_sp);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}
		
		iRet = SendMessage(ThreadMsg_sp);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}
		
		iOutRet = MsgData_sp->m_iOutRet;
	}while(FALSE);

	return iOutRet;
}

INT_t CMediaSrv::TunerScan()
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	SharedPtr<CMessageQueueItem> ThreadMsg_sp(new CMessageQueueItem);
	SharedPtr <CGenericMsgData> MsgDataTunerScan_sp(new CGenericMsgData);
	RMstatus eRMstatus = RM_ERROR;

	do{
		if(NULL == MsgDataTunerScan_sp.get())
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}

		if(NULL == ThreadMsg_sp.get())
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}
		
		if(m_pPlayCtrlCtx)
		{
			eRMstatus = PlayCtrlCtx_setShouldStopDataIO(m_pPlayCtrlCtx, FALSE);
			if(RMFAILED(eRMstatus))
			{
				PRINT_BFILE_LINENO_RMSTATUS;
			}
			eRMstatus = PlayCtrlCtx_ResetDataIoErrState(m_pPlayCtrlCtx);
			if(RMFAILED(eRMstatus))
			{
				PRINT_BFILE_LINENO_RMSTATUS;
			}
		}
		

		MsgDataTunerScan_sp->m_uiMsgId = MSG_CMD_TunerScan;
		iRet = ThreadMsg_sp->SetMessageData(MsgDataTunerScan_sp);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}

		iRet = SendMessage(ThreadMsg_sp);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}
		iOutRet = MsgDataTunerScan_sp->m_iOutRet;
		
	}while(FALSE);

	return iOutRet;
}

INT_t CMediaSrv::Get_EntryChannelInfo(IN INT32_t EntryId ,OUT INT32_t *pChannelNumber,OUT INT32_t *pSubChannelCount,OUT CStackBufString &StrProgramPids)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	SharedPtr<CMsgData_GetEntryInfo> MsgData_EntryInfo_sp( new CMsgData_GetEntryInfo);
	SharedPtr<CMessageQueueItem> ThreadMsg_sp(new CMessageQueueItem);
	SharedPtr <CGenericMsgData> MsgData_sp;

	do{
		if(NULL == MsgData_EntryInfo_sp.get())
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}

		if(NULL == ThreadMsg_sp.get())
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}
		MsgData_EntryInfo_sp->m_EntryId = EntryId;
		MsgData_EntryInfo_sp->m_uiMsgId = MSG_CMD_GetEntryChannelInfo;
		MsgData_sp = MsgData_EntryInfo_sp;
		iRet = ThreadMsg_sp->SetMessageData(MsgData_sp);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}

		iRet = SendMessage(ThreadMsg_sp);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}
		if(NULL != pChannelNumber && NULL != pSubChannelCount)
		{
			*pChannelNumber = MsgData_EntryInfo_sp->m_ChannelNum;
			*pSubChannelCount = MsgData_EntryInfo_sp->m_SubChannlNum;

			iRet = StrProgramPids.Format("%s",MsgData_EntryInfo_sp->m_StrProgramPids);
			if(ERROR_SUCCESS != iRet)
			{
				PRINT_BFILE_LINENO_IRET_CRT_ERR;
			}
			iOutRet = MsgData_EntryInfo_sp->m_iOutRet;
		}
	}while(FALSE);

	return iOutRet;
}

INT_t CMediaSrv::GetFirstChNumber(OUT UINT32_t *pOutMajor,OUT UINT32_t *pOutMinor)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	SharedPtr <CMsgData_GetFirstChNum> MsgGetChannelNumber_sp(new CMsgData_GetFirstChNum);
	SharedPtr<CMessageQueueItem> ThreadMsg_sp(new CMessageQueueItem);
	SharedPtr <CGenericMsgData> MsgData_sp;

	do{
		if(MsgGetChannelNumber_sp.isNull() || ThreadMsg_sp.isNull())
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}
		
		MsgGetChannelNumber_sp->m_uiMsgId = MSG_CMD_GetFirstChNum;
		MsgData_sp = MsgGetChannelNumber_sp;
		iRet = ThreadMsg_sp->SetMessageData(MsgData_sp);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}
		
		iRet = SendMessage(ThreadMsg_sp);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}
		
		if(NULL != pOutMajor && NULL != pOutMinor)
		{
			(*pOutMajor) = MsgGetChannelNumber_sp->m_major;
			(*pOutMinor) = MsgGetChannelNumber_sp->m_minor;
		}
		
		iOutRet = MsgGetChannelNumber_sp->m_iOutRet;
	}while(FALSE);

	return iOutRet;
}

INT_t CMediaSrv::PlayTuner( OUT UINT32_t * pPlaybackId/* = NULL*/)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	RMstatus eRMstatus = RM_OK;
	SharedPtr <CMsgData_Play> MsgTuner_Play_sp(new CMsgData_Play);
	SharedPtr<CMessageQueueItem> ThreadMsg_sp(new CMessageQueueItem);
	SharedPtr <CGenericMsgData> MsgData_sp;

	do{
		
		if(NULL == MsgTuner_Play_sp.get())
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}

		if(NULL == ThreadMsg_sp.get())
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}

		MsgTuner_Play_sp->m_uiMsgId = MSG_CMD_PlayTuner;
		MsgData_sp = MsgTuner_Play_sp;
		iRet = ThreadMsg_sp->SetMessageData(MsgData_sp);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}

		iRet = SendMessage(ThreadMsg_sp);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}
		if(NULL != pPlaybackId)
		{
			*pPlaybackId = MsgTuner_Play_sp->m_PlaybackId;
		}
		iOutRet = MsgTuner_Play_sp->m_iOutRet;
	}while(FALSE);

	return iOutRet;

}

INT_t CMediaSrv::setTunerChannelMode(INT32_t iTunerChMode)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	SharedPtr <CMsgData_SetTuChMode> MsgSetChannelMode_sp(new CMsgData_SetTuChMode);
	SharedPtr<CMessageQueueItem> ThreadMsg_sp(new CMessageQueueItem);
	SharedPtr <CGenericMsgData> MsgData_sp;
	
	do{
		if(MsgSetChannelMode_sp.isNull() || ThreadMsg_sp.isNull())
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}
		
		MsgSetChannelMode_sp->m_uiMsgId = MSG_CMD_SetTunerChannelMode;
		MsgSetChannelMode_sp->m_iChannelMode = iTunerChMode;
		MsgData_sp = MsgSetChannelMode_sp;
		iRet = ThreadMsg_sp->SetMessageData(MsgData_sp);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}
		
		iRet = SendMessage(ThreadMsg_sp);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}
	}while(FALSE);

	return iOutRet;
}

INT_t CMediaSrv::getTunerChannelMode(INT32_t *pOChannelMode)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	SharedPtr <CMsgData_GetTuChMode> MsgGetChannelMode_sp(new CMsgData_GetTuChMode);
	SharedPtr<CMessageQueueItem> ThreadMsg_sp(new CMessageQueueItem);
	SharedPtr <CGenericMsgData> MsgData_sp;
	
	do{
		if(MsgGetChannelMode_sp.isNull() || ThreadMsg_sp.isNull())
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}

		if(NULL == pOChannelMode)
		{
			iOutRet = ERROR_INVALID_PARAMETER;
			break;
		}
		
		MsgGetChannelMode_sp->m_uiMsgId = MSG_CMD_GetTunerChannelMode;
		MsgData_sp = MsgGetChannelMode_sp;

		iRet = ThreadMsg_sp->SetMessageData(MsgData_sp);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}
				
		iRet = SendMessage(ThreadMsg_sp);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}

		if(NULL != pOChannelMode)
		{
			*pOChannelMode = MsgGetChannelMode_sp->m_OChannelMode;
		}
		
		iOutRet = MsgGetChannelMode_sp->m_iOutRet;		
	}while(FALSE);

	return iOutRet;
}


INT_t CMediaSrv::GetTunerChannelStrength(OUT UINT32_t *pStrength)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	SharedPtr <CMsgData_GetStrength> MsgGetChannelStrength_sp(new CMsgData_GetStrength);
	SharedPtr<CMessageQueueItem> ThreadMsg_sp(new CMessageQueueItem);
	SharedPtr <CGenericMsgData> MsgData_sp;

	do{
		if(MsgGetChannelStrength_sp.isNull() || ThreadMsg_sp.isNull() || NULL == pStrength)
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}
		
		MsgGetChannelStrength_sp->m_uiMsgId = MSG_CMD_GetSignalStrength;
		MsgData_sp = MsgGetChannelStrength_sp;
		iRet = ThreadMsg_sp->SetMessageData(MsgData_sp);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}
		
		iRet = SendMessage(ThreadMsg_sp);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}
		
		if(NULL != pStrength)
		{
			*pStrength = MsgGetChannelStrength_sp->m_channelStrength;
		}
		
		iOutRet = MsgGetChannelStrength_sp->m_iOutRet;
	}while(FALSE);

	return iOutRet;
}

INT_t CMediaSrv::GetTunerMode(OUT INT32_t *pStdMode)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	SharedPtr <CMsgData_GetTunerMode> MsgGetChanStdMode_sp(new CMsgData_GetTunerMode);
	SharedPtr<CMessageQueueItem> ThreadMsg_sp(new CMessageQueueItem);
	SharedPtr <CGenericMsgData> MsgData_sp;

	do{
		if(MsgGetChanStdMode_sp.isNull() || ThreadMsg_sp.isNull() || NULL == pStdMode)
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}
		
		MsgGetChanStdMode_sp->m_uiMsgId = MSG_CMD_GetTunerMode;
		MsgData_sp = MsgGetChanStdMode_sp;
		iRet = ThreadMsg_sp->SetMessageData(MsgData_sp);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}
		
		iRet = SendMessage(ThreadMsg_sp);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}
		
		if(NULL != pStdMode)
		{
			*pStdMode = MsgGetChanStdMode_sp->m_channelStdMode;
		}
		
		iOutRet = MsgGetChanStdMode_sp->m_iOutRet;
	}while(FALSE);

	return iOutRet;
}


/*****************************************************************************/

INT_t CMediaSrv::FindChannelIndexInScanedTable(LPCSTR pChStrIndex,RMbool *pFound)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	
	do{
		if(NULL == pChStrIndex || NULL == pFound)
		{
			iOutRet = ERROR_INVALID_PARAMETER;
			break;
		}
		
		if(m_TunerSrv_sp.isNull())
		{
			iOutRet = ERROR_INVALID_PARAMETER;
			break;
		}
		
		iRet = m_TunerSrv_sp->OnSetUrl(pChStrIndex,pFound);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}
	}while(FALSE);
	
	return iOutRet;
}

INT_t CMediaSrv::CloseDemux()
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;

	do{
		if(m_TunerSrv_sp.isNull())
		{
			iOutRet = ERROR_INVALID_PARAMETER;
			break;
		}

		iRet = m_TunerSrv_sp->OnClosePsfDemux();
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}

	}while(FALSE);

	return iOutRet;
}

INT_t CMediaSrv::PsfPlayback()
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;

	do{
		iRet = m_TunerSrv_sp->OnPsfSetPmt();
		if(ERROR_SUCCESS != iRet)
		{
			//PRINT_BFILE_LINENO_IRET_STR;
			iOutRet = iRet;
			break;
		}
	}while(FALSE);

	return iOutRet;
}

INT_t CMediaSrv::SetChannelInfoAndLockFreq()
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	UINT32_t Lock = 0;

	do{
		if(m_TunerSrv_sp.isNull())
		{
			iOutRet = ERROR_INVALID_PARAMETER;
			break;
		}
		
		iRet = m_TunerSrv_sp->OnSetChannelInfo();
		if(ERROR_SUCCESS != iRet)
		{	
			PRINT_BFILE_LINENO_IRET_STR;
			iOutRet = iRet;
			break;
		}

		iRet = m_TunerSrv_sp->OnWaitLock(&Lock);
		if(ERROR_SUCCESS != iRet)
		{
			PRINT_BFILE_LINENO_IRET_STR;
		}

		if(Sw_LogTuner)
		{
			LOG("Lock=%d\n",Lock);
		}
	}while(FALSE);

	return iOutRet;
}


INT_t CMediaSrv::StartScanProgram()
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;

	do{
		if(m_TunerSrv_sp.isNull())
		{
			iOutRet = ERROR_INVALID_PARAMETER;
			break;
		}

		iRet = m_TunerSrv_sp->OnScanProgram();
		if(ERROR_SUCCESS != iRet  
			&& ERR_TU_SCAN_DONE != iRet
			&& ERR_TU_USER_STOP_SCAN != iRet)
		{
			iOutRet = iRet;
			break;
		}
		
	}while(FALSE);

	return iOutRet;
}

INT_t CMediaSrv::InitTunerPlayer()
{
	INT_t iOutRet = ERROR_SUCCESS;

	do{
		if(NULL == m_RmfpMainContext.pRUA)
		{
			iOutRet = ERROR_INVALID_PARAMETER;
			break;
		}

		m_TunerSrv_sp = SharedPtr <CTunerSrv> (new CTunerSrv(m_RmfpMainContext.pRUA));
		if(m_TunerSrv_sp.isNull())
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}
		
	}while(FALSE);

	return iOutRet;
}

INT_t CMediaSrv::OpenTunerPlayer()
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	UINT64_t StartTimeMs = GetSysUpTimeMs(), CurTimeMs;
	
	do{
		if(NULL == m_RmfpMainContext.pRUA)
		{
			iOutRet = ERROR_INVALID_PARAMETER;
			break;
		}
		
		if(m_TunerSrv_sp.isNull())
		{
			m_TunerSrv_sp = SharedPtr <CTunerSrv> (new CTunerSrv(m_RmfpMainContext.pRUA));
				
			if(m_TunerSrv_sp.isNull())
			{
				iOutRet = ERROR_OUT_OF_MEMORY;
				break;
			}
		}

		iRet = m_TunerSrv_sp->OpenTuner();
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}		
	}while(FALSE);

	CurTimeMs = GetSysUpTimeMs();

	if(Sw_LogTuner)
	{
		LOG("OpenTuner took %llu ms\n", (CurTimeMs-StartTimeMs));
	}

	return iOutRet;
}

INT_t CMediaSrv::ConfigPsfDemuxPara(struct rmfp_main_thread_context_type *pMainContext)
{
	INT_t iOutRet = ERROR_SUCCESS;

	do{
		
		if(NULL == pMainContext)
		{
			iOutRet = ERROR_INVALID_PARAMETER;
			break;
		}
		
		pMainContext->stream_type.application_type = RMFP_application_type_DTV;
		pMainContext->pOptions->demux_options.system_type = RM_SYSTEM_MPEG2_TRANSPORT;
		pMainContext->pOptions->playback_options.stc_offset_ms = -300;
#if	1	//enabled at this moment, this will cause the video problem when changing video output mode.
		pMainContext->pOptions->playback_options.stc_compensation = TRUE;
		pMainContext->pOptions->playback_options.vcxo_index = 0;
#else
		pMainContext->pOptions->playback_options.stc_compensation = FALSE;
		pMainContext->pOptions->playback_options.vcxo_index = -1;
#endif		
		pMainContext->pOptions->demux_options.spi = TRUE;		
	}while(FALSE);

	return iOutRet;
}

INT_t CMediaSrv::On_GetEntryChannelInfo(SharedPtr<CGenericMsgData> & GenMsgData_sp,SharedPtr<CMessageQueueItem> & TransactionMsg)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	SharedPtr <CMsgData_GetEntryInfo> CMsgData_GetEntryInfo_sp = GenMsgData_sp.DynamicCast<CMsgData_GetEntryInfo>();
	SharedPtr <IMediaSrvScanProgressListener> IMediaSrvTuPlayerListener_sp;
	
	do{
		if(CMsgData_GetEntryInfo_sp.isNull())
		{
			iOutRet = ERROR_INVALID_STATE;
			iRet = TransactionMsg->SetEvent();
			if(CC_UNLIKELY(ERROR_SUCCESS != iRet))
			{
				PRINT_BFILE_LINENO_IRET_CRT_ERR;
			}
			break;
		}

		{
			CAutoLock AutoRangeLocker(&m_SharedDataMutex);
			IMediaSrvTuPlayerListener_sp = m_MediaSrvScanProgressListener_wp.Promote();
		}
		
		if(IMediaSrvTuPlayerListener_sp.isNull())
		{
			PRINT_BFILE_LINENO_BUG_STR;
			iOutRet = ERROR_INVALID_PARAMETER;
			break;
		}

		if(FALSE == m_bTunerOpenSucc)
		{
			iRet = OpenTunerPlayer();
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet =ERR_TUNER_OPEN_FAIL;
				PRINT_BFILE_LINENO_IRET_STR;
				CMsgData_GetEntryInfo_sp->m_iOutRet = iOutRet;
				iRet = TransactionMsg->SetEvent();
				if(CC_UNLIKELY(ERROR_SUCCESS != iRet))
				{
					PRINT_BFILE_LINENO_IRET_CRT_ERR;
				}
				IMediaSrvTuPlayerListener_sp->NotifyTuPlayerPropmtMsg(ERR_NO_DEV);
				break;
			}
			
			m_bTunerOpenSucc = TRUE;
		}
		
		if(m_TunerSrv_sp.isNull())
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			CMsgData_GetEntryInfo_sp->m_iOutRet = iOutRet;
			iRet = TransactionMsg->SetEvent();
			if(CC_UNLIKELY(ERROR_SUCCESS != iRet))
			{
				PRINT_BFILE_LINENO_IRET_CRT_ERR;
			}
			break;
		}
		
		if(FALSE == m_TunerSrv_sp->OnCheckInit())
		{
			iOutRet = ERR_INIT_FAIL;
			CMsgData_GetEntryInfo_sp->m_iOutRet = iOutRet;
			iRet = TransactionMsg->SetEvent();
			if(CC_UNLIKELY(ERROR_SUCCESS != iRet))
			{
				PRINT_BFILE_LINENO_IRET_CRT_ERR;
			}
			break;	
		}
		ZeroMemory(CMsgData_GetEntryInfo_sp->m_StrProgramPids,64);
		iRet = m_TunerSrv_sp->OnGetChannelInfo(CMsgData_GetEntryInfo_sp->m_EntryId,
			&CMsgData_GetEntryInfo_sp->m_ChannelNum,
			&CMsgData_GetEntryInfo_sp->m_SubChannlNum,
			CMsgData_GetEntryInfo_sp->m_StrProgramPids);
		
		iOutRet = iRet;
		CMsgData_GetEntryInfo_sp->m_iOutRet = iOutRet;
		iRet = TransactionMsg->SetEvent();
		if(CC_UNLIKELY(ERROR_SUCCESS != iRet))
		{
			PRINT_BFILE_LINENO_IRET_CRT_ERR;
		}
		break;
	}while(FALSE);

	return iOutRet;
}

INT_t CMediaSrv::On_PlayTuner(SharedPtr<CGenericMsgData> & GenMsgData_sp, SharedPtr<CMessageQueueItem> & TransactionMsg)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	RMstatus eRMstatus = RM_OK;
	RMbool bChFound = FALSE;
	DECLARE_CLS_STACK_BUF_STRING(strUrl, (4*1024));
	SharedPtr <CMsgData_Play> MsgData_PlayTuner_sp = GenMsgData_sp.DynamicCast<CMsgData_Play>();
	SharedPtr <IMediaSrvScanProgressListener> IMediaSrvTuPlayerMsgListener_sp;
	INT32_t iChannelMode  = 0;

	do{
		if(MsgData_PlayTuner_sp.isNull())
		{
			iOutRet = ERROR_INVALID_STATE;
			iRet = TransactionMsg->SetEvent();
			if(CC_UNLIKELY(ERROR_SUCCESS != iRet))
			{
				PRINT_BFILE_LINENO_IRET_CRT_ERR;
			}
			break;
		}

		{
			CAutoLock AutoRangeLocker(&m_SharedDataMutex);
			if(PLAY_STAT_PREPARED != m_iPlayStatus)
			{
				iOutRet = ERROR_INVALID_STATE;
				MsgData_PlayTuner_sp->m_iOutRet = iOutRet;
				iRet = TransactionMsg->SetEvent();
				if(CC_UNLIKELY(ERROR_SUCCESS != iRet))
				{
					PRINT_BFILE_LINENO_IRET_CRT_ERR;
				}
				break;
			}
		}

		if(m_pPlayCtrlCtx)
		{
			eRMstatus = PlayCtrlCtx_setShouldStopDataIO(m_pPlayCtrlCtx, FALSE);
			if(RMFAILED(eRMstatus))
			{
				PRINT_BFILE_LINENO_RMSTATUS;
			}
			eRMstatus = PlayCtrlCtx_ResetDataIoErrState(m_pPlayCtrlCtx);
			if(RMFAILED(eRMstatus))
			{
				PRINT_BFILE_LINENO_RMSTATUS;
			}
		}

		{
			CAutoLock AutoRangeLocker(&m_SharedDataMutex);
			strUrl = (LPCSTR)(*m_currIterator);
			m_CntNodeInUrlList --;
			if(m_CntNodeInUrlList > 0)
			{
				m_currIterator ++;
			}
		}

		m_bIsCompletePlaybackEos = TRUE;

		//implement the SNMP command "videoMode"
		if(TRUE == m_bVidDispAspectRatioAtNextPlay_Valid)
		{
			DISPLAY_ASPECT_RATIO eVidDispAspectRatioAtNextPlay;
			m_bVidDispAspectRatioAtNextPlay_Valid = FALSE;
			{
				CAutoLock AutoRangeLocker(&m_SharedDataMutex);
				eVidDispAspectRatioAtNextPlay = m_VidDispAspectRatioAtNextPlay;
			}
			iRet = applyVideoDispAspectRatio(eVidDispAspectRatioAtNextPlay);
			if(ERROR_SUCCESS != iRet)
			{
				PRINT_BFILE_LINENO_IRET_STR;
			}
		}

		{
			CAutoLock AutoRangeLocker(&m_SharedDataMutex);
			m_bPlaybackEosIsSent = FALSE;
			INT_t iOldPlayStatus = m_iPlayStatus;
			m_iPlayStatus = PLAY_STAT_PLAYING;
			iRet = m_Mp7xxGlobalStatusData.setMpSrvPlayStatus(m_iPlayStatus);
			if(ERROR_SUCCESS != iRet)
			{
				PRINT_BFILE_LINENO_IRET_STR;
			}
			if(iOldPlayStatus != m_iPlayStatus)
			{
				iRet = m_PlayStatChangedEvent.SetEvent();
				if(ERROR_SUCCESS != iRet)
				{
					PRINT_BFILE_LINENO_IRET_STR;
				}
			}
			
			m_bQuitPlay = FALSE;
			iOutRet = ERROR_SUCCESS;
			MsgData_PlayTuner_sp->m_iOutRet = iOutRet;
			//increment the m_PlaybackId
			m_PlaybackId++;
			if(0 == m_PlaybackId)
			{
				m_PlaybackId++;
			}
			MsgData_PlayTuner_sp->m_PlaybackId = m_PlaybackId;
			iRet = TransactionMsg->SetEvent();
			if(CC_UNLIKELY(ERROR_SUCCESS != iRet))
			{
				PRINT_BFILE_LINENO_IRET_CRT_ERR;
			}
		}

		{
			CAutoLock AutoRangeLocker(&m_SharedDataMutex);
			IMediaSrvTuPlayerMsgListener_sp = m_MediaSrvScanProgressListener_wp.Promote();
		}
		
		if(IMediaSrvTuPlayerMsgListener_sp.isNull())
		{
			PRINT_BFILE_LINENO_BUG_STR;
			iOutRet = ERROR_INVALID_PARAMETER;
			break;
		}
		

		if(FALSE == m_bTunerOpenSucc)
		{
			iRet = OpenTunerPlayer();
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet =ERR_TUNER_OPEN_FAIL;
				
				iRet = IMediaSrvTuPlayerMsgListener_sp->NotifyTuPlayerPropmtMsg(ERR_NO_DEV);
				if(ERROR_SUCCESS != iRet)
				{
					PRINT_BFILE_LINENO_IRET_CRT_ERR;
				}
				break;
			}
			
			m_bTunerOpenSucc = TRUE;
		}
		
		if(m_TunerSrv_sp.isNull())
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			
			break;
		}

		if(FALSE == m_TunerSrv_sp->OnCheckInit())
		{
			iOutRet = ERR_INIT_FAIL;
			break;	
		}

		iRet = ConfigPsfDemuxPara(&m_RmfpMainContext);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}
		
		eRMstatus = player_rmfp_run(&m_RmfpMainContext);
		if(RM_OK != eRMstatus)
		{
			PRINT_BFILE_LINENO_RMSTATUS;
			iOutRet = ERROR_FILE_OPEN_FAIL;
			break;
		}

		//Play Tuner Default Use 2D mode
		iRet = setStereoscopic3DFormat();
		if(ERROR_SUCCESS != iRet)
		{
			PRINT_BFILE_LINENO_BUG_STR;
		}

		m_bShouldApplyHdmi3DInfoFrame = TRUE;	//now, we can schedule to re-send Hdmi3D info frame.
		m_CurRightStereoscopic3D.Format = EMhwlibStereoscopicFormat_2D;
		iRet = m_TunerSrv_sp->OnGetTunerChannelMode(&iChannelMode);
		if(ERROR_SUCCESS == iRet)
		{}
		else if(ERROR_NOT_FOUND == iRet)
		{
			iChannelMode = CHANNEL_MODE_DEFAULT;
		}
		else
		{
			iOutRet = iRet;
			break;
		}

		if(CHANNEL_MODE_DEFAULT == iChannelMode 
			|| CHANNEL_MODE_FIXED_SCANNED == iChannelMode)
		{
			iRet =  FindChannelIndexInScanedTable((LPCSTR)strUrl, &bChFound);
			if(ERROR_SUCCESS != iRet)
			{
				PRINT_BFILE_LINENO_IRET_STR;
				iOutRet = ERROR_NOT_FOUND;
				
				iRet = IMediaSrvTuPlayerMsgListener_sp->NotifyTuPlayerPropmtMsg(ERROR_NOT_FOUND);
				if(ERROR_SUCCESS != iRet)
				{
					PRINT_BFILE_LINENO_IRET_CRT_ERR;
				}
				
				break;
			}
		}
		else
		{
			iRet = m_TunerSrv_sp->FindChannelIndexInFixedTable((LPCSTR)strUrl, &bChFound);
			if(ERROR_SUCCESS != iRet)
			{
				PRINT_BFILE_LINENO_IRET_STR;
				iOutRet = ERROR_NOT_FOUND;
				
				iRet = IMediaSrvTuPlayerMsgListener_sp->NotifyTuPlayerPropmtMsg(ERROR_NOT_FOUND);
				if(ERROR_SUCCESS != iRet)
				{
					PRINT_BFILE_LINENO_IRET_CRT_ERR;
				}
				
				break;
			}
		}
		
		iRet = SetChannelInfoAndLockFreq();
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}

		iRet = PsfPlayback();
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}
		eRMstatus = NotifyPlaybackStart();
		if(RM_OK != eRMstatus)
		{
			PRINT_BFILE_LINENO_RMSTATUS;
		}
		
		m_ePlaySourceType = PLAY_SOURCE_TUNER_IN;
		//Register a timer to process the demux output periodically.
		if(CGenericTimer::TIMER_ID_INVALID != m_idProcessTunerTaskTimer)
		{
			iRet = m_GenericTimer.UnregisterTimer(m_idProcessTunerTaskTimer);
			if(ERROR_SUCCESS != iRet)
			{
				PRINT_BFILE_LINENO_IRET_STR;
			}
			m_idProcessTunerTaskTimer = 0;
		}
		iRet = m_GenericTimer.RegisterTimer(m_this_wp, OUT m_idProcessTunerTaskTimer, 100/*ms*/);
		if(ERROR_SUCCESS != iRet)
		{
			PRINT_BFILE_LINENO_IRET_STR;
		}
	}while(FALSE);

	return iOutRet;
}

/*
ThreadContext: play thread
*/
INT_t CMediaSrv::StopTunerPlayer()
{
	INT_t iOutRet = ERROR_SUCCESS,iRet;
	RMstatus eRMstatus = RM_ERROR;
	BOOL_t bSendPlayEos = TRUE;
	INT_t iCurrPlayStatus= PLAY_STAT_IDLE;
	struct rmfp_main_thread_context_type *pMainContext = &m_RmfpMainContext;

	do{
		if(m_TunerSrv_sp.isNull())
		{
			iOutRet = ERROR_INVALID_STATE;
			break;
		}
		
		iOutRet = getMpSrvPlayStatus(&iCurrPlayStatus);
		if(ERROR_SUCCESS != iOutRet) 
		{
			PRINT_BFILE_LINENO_RMSTATUS
			
		}
		
		if(PLAY_STAT_TUNER_SCANNING == iCurrPlayStatus)
		{
			bSendPlayEos = FALSE;
		}
		
		iRet = CloseDemux();
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}

		eRMstatus = RMFPReleaseSource(pMainContext->pHandle);
		if(RM_OK != eRMstatus)
		{
			PRINT_BFILE_LINENO_RMSTATUS;
			iOutRet = ERR_FILE_CLOSE_FAIL;
			break;
		}
		eRMstatus = player_rmfp_closeurl(pMainContext);
		if(RM_OK != eRMstatus)
		{
			PRINT_BFILE_LINENO_RMSTATUS;
			iOutRet = ERR_FILE_CLOSE_FAIL;
			break;
		}
		//restore actual settings for rmfp options
		eRMstatus = RMFPOptions_RestoreSet(pMainContext->pOptions);
		if(RM_OK != eRMstatus)
		{
			PRINT_BFILE_LINENO_RMSTATUS;
			iOutRet = ERR_FILE_CLOSE_FAIL;
			break;
		}

		if(FALSE == m_bPlaybackEosIsSent && TRUE == bSendPlayEos )
		{
			eRMstatus = NotifyPlaybackEos();
			if(RMFAILED(eRMstatus))
			{
				PRINT_BFILE_LINENO_RMSTATUS;
			}
		}
		
		INT_t iOldPlayStatus = m_iPlayStatus;
		m_iPlayStatus = PLAY_STAT_IDLE;
		iRet = m_Mp7xxGlobalStatusData.setMpSrvPlayStatus(m_iPlayStatus);
		if(ERROR_SUCCESS != iRet)
		{
			PRINT_BFILE_LINENO_IRET_STR;
		}
		if(iOldPlayStatus != m_iPlayStatus)
		{
			iRet = m_PlayStatChangedEvent.SetEvent();
			if(ERROR_SUCCESS != iRet)
			{
				PRINT_BFILE_LINENO_IRET_STR;
				iOutRet = iRet;
				break;
			}
		}
	}while(FALSE);

	return iOutRet;
}

INT_t CMediaSrv::On_GetTunerStandardMode(SharedPtr<CGenericMsgData> & GenMsgData_sp,SharedPtr<CMessageQueueItem> & TransactionMsg)
{
	INT_t iOutRet = ERROR_SUCCESS,iRet;
	SharedPtr <CMsgData_GetTunerMode> MsgData_GetTuMode_sp = GenMsgData_sp.DynamicCast<CMsgData_GetTunerMode>();
	INT32_t iStdMode = -1;
	
	do{
		if(MsgData_GetTuMode_sp.isNull())
		{
			iOutRet = ERROR_INVALID_STATE;
			break;
		}
		
		if(m_TunerSrv_sp.isNull())
		{
			iRet = InitTunerPlayer();
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet =ERR_TUNER_OPEN_FAIL;
				PRINT_BFILE_LINENO_IRET_STR;
				break;
			}
		}
			
		if(m_TunerSrv_sp.isNull())
		{
			iOutRet = ERR_INIT_FAIL;
			break;
		}

		if(FALSE == m_TunerSrv_sp->OnCheckInit())
		{
			iOutRet = ERR_INIT_FAIL;
			break;	
		}

		iRet = m_TunerSrv_sp->OnGetTunerMode(&iStdMode);
		if(ERROR_SUCCESS == iRet)
		{
		}
		else if(ERROR_NOT_FOUND == iRet)
		{
			iRet = m_TunerSrv_sp->OnGetCurrStdMode(&iStdMode);
			if(ERROR_SUCCESS != iRet)
			{
				PRINT_BFILE_LINENO_IRET_STR;
				iOutRet = iRet;
				break;
			}
		}
		else
		{
			iOutRet = iRet;
			break;
		}
	}while(FALSE);
	
	MsgData_GetTuMode_sp->m_iOutRet = iOutRet;
	MsgData_GetTuMode_sp->m_channelStdMode = iStdMode;
	iRet = TransactionMsg->SetEvent();
	if(CC_UNLIKELY(ERROR_SUCCESS != iRet))
	{
		PRINT_BFILE_LINENO_IRET_CRT_ERR;
	}

	return iOutRet;
}

INT_t CMediaSrv::On_SetTunerChannelMode(SharedPtr<CGenericMsgData> & GenMsgData_sp,SharedPtr<CMessageQueueItem> & TransactionMsg)
{
	INT_t iOutRet = ERROR_SUCCESS,iRet;
	SharedPtr <CMsgData_SetTuChMode> MsgData_SetTuChMode_sp = GenMsgData_sp.DynamicCast<CMsgData_SetTuChMode>();
	INT32_t iTuChMode = 0;

	do{
		if(MsgData_SetTuChMode_sp.isNull())
		{
			iOutRet = ERROR_INVALID_STATE;
			
			break;
		}

		iTuChMode = MsgData_SetTuChMode_sp->m_iChannelMode;

		if(m_TunerSrv_sp.isNull())
		{
			iRet = InitTunerPlayer();
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet =ERR_TUNER_OPEN_FAIL;
				PRINT_BFILE_LINENO_IRET_STR;
				break;
			}
		}

		if(m_TunerSrv_sp.isNull())
		{
			iOutRet = ERR_INIT_FAIL;
			break;
		}

		if(FALSE == m_TunerSrv_sp->OnCheckInit())
		{
			iOutRet = ERR_INIT_FAIL;
			break;	
		}

		iRet = m_TunerSrv_sp->OnSetTunerChannelMode(&iTuChMode);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}
	}while(FALSE);

	iRet = TransactionMsg->SetEvent();
	if(CC_UNLIKELY(ERROR_SUCCESS != iRet))
	{
		PRINT_BFILE_LINENO_IRET_CRT_ERR;
	}

	return iOutRet;
}

INT_t CMediaSrv::On_GetTunerChannelMode(SharedPtr<CGenericMsgData> & GenMsgData_sp,SharedPtr<CMessageQueueItem> & TransactionMsg)
{
	INT_t iOutRet = ERROR_SUCCESS,iRet;
	SharedPtr <CMsgData_GetTuChMode> MsgData_GetTuChMode_sp = GenMsgData_sp.DynamicCast<CMsgData_GetTuChMode>();
	INT32_t iTuChMode = 0;
	
	do{
		if(MsgData_GetTuChMode_sp.isNull())
		{
			iOutRet = ERROR_INVALID_STATE;
			break;
		}
		
		if(m_TunerSrv_sp.isNull())
		{
			iRet = InitTunerPlayer();
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = ERR_TUNER_OPEN_FAIL;
				PRINT_BFILE_LINENO_IRET_STR;
				break;
			}
		}
			
		if(m_TunerSrv_sp.isNull())
		{
			iOutRet = ERR_INIT_FAIL;
			break;
		}

		if(FALSE == m_TunerSrv_sp->OnCheckInit())
		{
			iOutRet = ERR_INIT_FAIL;
			break;	
		}

		iRet = m_TunerSrv_sp->OnGetTunerChannelMode(&iTuChMode);
		if(ERROR_SUCCESS == iRet)
		{
		}
		else if(ERROR_NOT_FOUND == iRet)
		{
		}
		else
		{
			iOutRet = iRet;
			break;
		}
	}while(FALSE);
	
	MsgData_GetTuChMode_sp->m_iOutRet = iOutRet;
	MsgData_GetTuChMode_sp->m_OChannelMode = iTuChMode;
	iRet = TransactionMsg->SetEvent();
	if(CC_UNLIKELY(ERROR_SUCCESS != iRet))
	{
		PRINT_BFILE_LINENO_IRET_CRT_ERR;
	}

	return iOutRet;
}

INT_t CMediaSrv::On_SetTunerStandardMode(SharedPtr<CGenericMsgData> & GenMsgData_sp,SharedPtr<CMessageQueueItem> & TransactionMsg)
{
	INT_t iOutRet = ERROR_SUCCESS,iRet;
	SharedPtr <CMsgData_SetTuMode> MsgData_SetTuMode_sp = GenMsgData_sp.DynamicCast<CMsgData_SetTuMode>();
	INT32_t iTuStdMode = -1;
	
	do{
		if(MsgData_SetTuMode_sp.isNull())
		{
			iOutRet = ERROR_INVALID_STATE;
			break;
		}

		iTuStdMode = MsgData_SetTuMode_sp->m_iStdMode;
		
		if(m_TunerSrv_sp.isNull())
		{
			iRet = InitTunerPlayer();
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet =ERR_TUNER_OPEN_FAIL;
				PRINT_BFILE_LINENO_IRET_STR;
				break;
			}
		}

		if(m_TunerSrv_sp.isNull())
		{
			iOutRet = ERR_INIT_FAIL;
			break;
		}

		if(FALSE == m_TunerSrv_sp->OnCheckInit())
		{
			iOutRet = ERR_INIT_FAIL;
			break;	
		}

		iRet = m_TunerSrv_sp->OnSetTunerMode(&iTuStdMode);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}
	}while(FALSE);

	MsgData_SetTuMode_sp->m_iOutRet = iOutRet;
	iRet = TransactionMsg->SetEvent();
	if(CC_UNLIKELY(ERROR_SUCCESS != iRet))
	{
		PRINT_BFILE_LINENO_IRET_CRT_ERR;
	}

	return iOutRet;
}


INT_t CMediaSrv::On_ReLoadProgramTable(SharedPtr<CMessageQueueItem> & TransactionMsg)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	SharedPtr<CGenericMsgData> GenMsgData_sp;

	do{
		GenMsgData_sp = TransactionMsg->GetMessageData();
		if(GenMsgData_sp.isNull())
		{
			
			PRINT_BFILE_LINENO_BUG_STR;
			iOutRet = ERROR_INVALID_STATE;
			iRet = TransactionMsg->SetEvent();
			if(CC_UNLIKELY(ERROR_SUCCESS != iRet))
			{
				PRINT_BFILE_LINENO_IRET_CRT_ERR;
			}
			break;
		}
		{
			CAutoLock AutoRangeLocker(&m_SharedDataMutex);
			if(PLAY_STAT_PLAYING != m_iPlayStatus)
			{
				iOutRet = ERROR_INVALID_STATE;
				GenMsgData_sp->m_iOutRet = iOutRet;
				iRet = TransactionMsg->SetEvent();
				if(CC_UNLIKELY(ERROR_SUCCESS != iRet))
				{
					PRINT_BFILE_LINENO_IRET_CRT_ERR;
				}
				break;
			}
		}

		if(m_TunerSrv_sp.isNull())
		{
			iOutRet = ERR_INIT_FAIL;
			GenMsgData_sp->m_iOutRet = iOutRet;
			iRet = TransactionMsg->SetEvent();
			if(CC_UNLIKELY(ERROR_SUCCESS != iRet))
			{
				PRINT_BFILE_LINENO_IRET_CRT_ERR;
			}
			break;
		}

		iOutRet = ERROR_SUCCESS;
		GenMsgData_sp->m_iOutRet = iOutRet;
		iRet = TransactionMsg->SetEvent();
		if(CC_UNLIKELY(ERROR_SUCCESS != iRet))
		{
			PRINT_BFILE_LINENO_IRET_CRT_ERR;
		}

		iRet = m_TunerSrv_sp->OnReloadProgram();
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}
	}while(FALSE);

	return iOutRet;
}


INT_t CMediaSrv::On_SetChannelDown(SharedPtr<CMessageQueueItem> & TransactionMsg)
{
	INT_t iOutRet = ERROR_SUCCESS,iRet;
	SharedPtr<CGenericMsgData> GenMsgData_sp;

	do{
		GenMsgData_sp = TransactionMsg->GetMessageData();
		if(GenMsgData_sp.isNull())
		{
			
			PRINT_BFILE_LINENO_BUG_STR;
			iOutRet = ERROR_INVALID_STATE;
			iRet = TransactionMsg->SetEvent();
			if(CC_UNLIKELY(ERROR_SUCCESS != iRet))
			{
				PRINT_BFILE_LINENO_IRET_CRT_ERR;
			}
			break;
		}
		
		{
			CAutoLock AutoRangeLocker(&m_SharedDataMutex);
			if(PLAY_STAT_PLAYING != m_iPlayStatus)
			{
				iOutRet = ERROR_INVALID_STATE;
				GenMsgData_sp->m_iOutRet = iOutRet;
				iRet = TransactionMsg->SetEvent();
				if(CC_UNLIKELY(ERROR_SUCCESS != iRet))
				{
					PRINT_BFILE_LINENO_IRET_CRT_ERR;
				}
				break;
			}
		}

		if(m_TunerSrv_sp.isNull())
		{
			iOutRet = ERR_INIT_FAIL;
			GenMsgData_sp->m_iOutRet = iOutRet;
			iRet = TransactionMsg->SetEvent();
			if(CC_UNLIKELY(ERROR_SUCCESS != iRet))
			{
				PRINT_BFILE_LINENO_IRET_CRT_ERR;
			}
			break;
		}

		iOutRet = ERROR_SUCCESS;
		GenMsgData_sp->m_iOutRet = iOutRet;
		iRet = TransactionMsg->SetEvent();
		if(CC_UNLIKELY(ERROR_SUCCESS != iRet))
		{
			PRINT_BFILE_LINENO_IRET_CRT_ERR;
		}

		iRet = m_TunerSrv_sp->OnChannelDown();
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}
	}while(FALSE);

	return iOutRet;
}

INT_t CMediaSrv::On_SetChannelUp(SharedPtr<CMessageQueueItem> & TransactionMsg)
{
	INT_t iOutRet = ERROR_SUCCESS,iRet;
	SharedPtr<CGenericMsgData> GenMsgData_sp;
	
	do{
		
		GenMsgData_sp = TransactionMsg->GetMessageData();
		if(GenMsgData_sp.isNull())
		{
			PRINT_BFILE_LINENO_BUG_STR;
			iOutRet = ERROR_INVALID_STATE;
			iRet = TransactionMsg->SetEvent();
			if(CC_UNLIKELY(ERROR_SUCCESS != iRet))
			{
				PRINT_BFILE_LINENO_IRET_CRT_ERR;
			}
			break;
		}
		{
			CAutoLock AutoRangeLocker(&m_SharedDataMutex);
			if(PLAY_STAT_PLAYING != m_iPlayStatus)
			{
				iOutRet = ERROR_INVALID_STATE;
				GenMsgData_sp->m_iOutRet = iOutRet;
				iRet = TransactionMsg->SetEvent();
				if(CC_UNLIKELY(ERROR_SUCCESS != iRet))
				{
					PRINT_BFILE_LINENO_IRET_CRT_ERR;
				}
				break;
			}
		}
	
		if(m_TunerSrv_sp.isNull())
		{
			iOutRet = ERR_INIT_FAIL;
			GenMsgData_sp->m_iOutRet = iOutRet;
			iRet = TransactionMsg->SetEvent();
			if(CC_UNLIKELY(ERROR_SUCCESS != iRet))
			{
				PRINT_BFILE_LINENO_IRET_CRT_ERR;
			}
			break;
		}

		iOutRet = ERROR_SUCCESS;
		GenMsgData_sp->m_iOutRet = iOutRet;
		iRet = TransactionMsg->SetEvent();
		if(CC_UNLIKELY(ERROR_SUCCESS != iRet))
		{
			PRINT_BFILE_LINENO_IRET_CRT_ERR;
		}

		iRet = m_TunerSrv_sp->OnChannelUp();
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}
	}while(FALSE);

	return iOutRet;
}

INT_t CMediaSrv::On_GetFirstChNum(SharedPtr<CGenericMsgData> & GenMsgData_sp,SharedPtr<CMessageQueueItem> & TransactionMsg)
{
	INT_t iOutRet = ERROR_SUCCESS,iRet;
	SharedPtr <CMsgData_GetFirstChNum> MsgData_GetFirstChNumber_sp = GenMsgData_sp.DynamicCast<CMsgData_GetFirstChNum>();
	UINT32_t iMajor = 0,iMinor = 0;

	do{
		if(MsgData_GetFirstChNumber_sp.isNull())
		{
			iOutRet = ERROR_INVALID_STATE;
			MsgData_GetFirstChNumber_sp->m_iOutRet = iOutRet;
			break;
		}

		if(m_TunerSrv_sp.isNull())
		{
			iOutRet = ERR_INIT_FAIL;
			MsgData_GetFirstChNumber_sp->m_iOutRet = iOutRet;
			break;
		}

		iRet = m_TunerSrv_sp->OnGetChannelNumber(&iMajor,&iMinor);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			MsgData_GetFirstChNumber_sp->m_iOutRet = iOutRet;
			break;
		}

		MsgData_GetFirstChNumber_sp->m_major = iMajor;
		MsgData_GetFirstChNumber_sp->m_minor = iMinor;
		
	}while(FALSE);

	iRet = TransactionMsg->SetEvent();
	if(CC_UNLIKELY(ERROR_SUCCESS != iRet))
	{
		PRINT_BFILE_LINENO_IRET_CRT_ERR;
	}

	return iOutRet;
}

INT_t CMediaSrv::On_GetSignalStrength(SharedPtr<CGenericMsgData> & GenMsgData_sp,SharedPtr<CMessageQueueItem> & TransactionMsg)
{
	INT_t iOutRet = ERROR_SUCCESS,iRet;
	SharedPtr <CMsgData_GetStrength> MsgData_GetStrength_sp = GenMsgData_sp.DynamicCast<CMsgData_GetStrength>();
	UINT32_t iStrength = 0;

	do{
		if(MsgData_GetStrength_sp.isNull())
		{
			iOutRet = ERROR_INVALID_STATE;
			MsgData_GetStrength_sp->m_iOutRet = iOutRet;
			break;
		}
		
		{
			CAutoLock AutoRangeLocker(&m_SharedDataMutex);
			if(PLAY_STAT_PLAYING != m_iPlayStatus)
			{
				MsgData_GetStrength_sp->m_channelStrength = iStrength;
				MsgData_GetStrength_sp->m_iOutRet = iOutRet;
				break;
			}
		}

		if(m_TunerSrv_sp.isNull())
		{
			iOutRet = ERR_INIT_FAIL;
			MsgData_GetStrength_sp->m_iOutRet = iOutRet;
			break;
		}

		iRet = m_TunerSrv_sp->OnGetStrength(&iStrength);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			MsgData_GetStrength_sp->m_iOutRet = iOutRet;
			break;
		}

		MsgData_GetStrength_sp->m_channelStrength = iStrength;
	}while(FALSE);

	iRet = TransactionMsg->SetEvent();
	if(CC_UNLIKELY(ERROR_SUCCESS != iRet))
	{
		PRINT_BFILE_LINENO_IRET_CRT_ERR;
	}

	return iOutRet;
}

void CMediaSrv::CallBackScanProgress(UINT16_t *pRrogramNum,UINT16_t *pScanRrogress)
{
	SharedPtr <CMediaSrv> MediaSrv_sp;
	do
	{
		if(NULL == pRrogramNum || NULL == pScanRrogress)
		{
			break;
		}
		MediaSrv_sp = g_MediaSrv_wp.Promote();
		if(MediaSrv_sp.isNull())
		{
			break;
		}
		MediaSrv_sp->FN_cbScanProgress(pRrogramNum, pScanRrogress);
	}while(FALSE);
}

void CMediaSrv::FN_cbScanProgress(UINT16_t *pRrogramNum,UINT16_t *pScanRrogress)
{
	INT_t iRet;
	UINT32_t uiProgramNum = 0;
	UINT32_t uiScanRrogress = 0;
	SharedPtr <CMediaSrv> MediaSrv_sp;
	SharedPtr <IMediaSrvScanProgressListener> IMediaSrvScanProgressListener_sp;

	do{
		if(NULL == pRrogramNum || NULL == pScanRrogress)
		{
			break;
		}

		{
			CAutoLock AutoRangeLocker(&m_SharedDataMutex);
			IMediaSrvScanProgressListener_sp = m_MediaSrvScanProgressListener_wp.Promote();
		}
		
		if(IMediaSrvScanProgressListener_sp.isNull())
		{
			PRINT_BFILE_LINENO_BUG_STR;
			break;
		}
		
		uiProgramNum |= *pRrogramNum;
		uiScanRrogress |= *pScanRrogress;
		
		iRet = IMediaSrvScanProgressListener_sp->NotifyScanProgress(uiProgramNum,uiScanRrogress);
		if(ERROR_SUCCESS != iRet)
		{
			PRINT_BFILE_LINENO_BUG_STR;
		}
		
		iRet = WakeupMainThread();
		if(ERROR_SUCCESS != iRet)
		{
			PRINT_BFILE_LINENO_IRET_STR;
		}
	}while(FALSE);

}

INT_t CMediaSrv::On_TunerScan(SharedPtr<CGenericMsgData> & GenMsgData_sp, SharedPtr<CMessageQueueItem> & TransactionMsg)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	RMstatus eRMstatus = RM_OK;
	SharedPtr <CGenericMsgData> MsgData_TunerScan_sp(new CGenericMsgData);
	SharedPtr <IMediaSrvScanProgressListener> IMediaSrvScanProgressListener_sp;
	
	
	do{
		if(MsgData_TunerScan_sp.isNull())
		{
			iOutRet = ERROR_INVALID_STATE;
			iRet = TransactionMsg->SetEvent();
			if(CC_UNLIKELY(ERROR_SUCCESS != iRet))
			{
				PRINT_BFILE_LINENO_IRET_CRT_ERR;
			}
			break;
		}
		
		
		if(m_pPlayCtrlCtx)
		{
			eRMstatus = PlayCtrlCtx_setShouldStopDataIO(m_pPlayCtrlCtx, FALSE);
			if(RMFAILED(eRMstatus))
			{
				PRINT_BFILE_LINENO_RMSTATUS;
			}
			eRMstatus = PlayCtrlCtx_ResetDataIoErrState(m_pPlayCtrlCtx);
			if(RMFAILED(eRMstatus))
			{
				PRINT_BFILE_LINENO_RMSTATUS;
			}
		}

		{
			CAutoLock AutoRangeLocker(&m_SharedDataMutex);
			MsgData_TunerScan_sp->m_iOutRet = ERROR_SUCCESS;
			iRet = TransactionMsg->SetEvent();
			if(CC_UNLIKELY(ERROR_SUCCESS != iRet))
			{
				PRINT_BFILE_LINENO_IRET_CRT_ERR;
			}
		}
		
		iRet = ConfigPsfDemuxPara(&m_RmfpMainContext);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}
		
		eRMstatus = player_rmfp_run(&m_RmfpMainContext);
		if(RM_OK != eRMstatus)
		{
			PRINT_BFILE_LINENO_RMSTATUS;
			iOutRet = ERROR_FILE_OPEN_FAIL;
			break;
		}

		

		{
			CAutoLock AutoRangeLocker(&m_SharedDataMutex);
			IMediaSrvScanProgressListener_sp = m_MediaSrvScanProgressListener_wp.Promote();
		}
		
		if(IMediaSrvScanProgressListener_sp.isNull())
		{
			PRINT_BFILE_LINENO_BUG_STR;
			iOutRet = ERROR_INVALID_PARAMETER;
			break;
		}
		
		if(FALSE == m_bTunerOpenSucc)
		{
			iRet = OpenTunerPlayer();
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet =ERR_TUNER_OPEN_FAIL;
				PRINT_BFILE_LINENO_IRET_STR;
				iRet = IMediaSrvScanProgressListener_sp->NotifyTuPlayerPropmtMsg(ERR_NO_DEV);
				if(ERROR_SUCCESS != iRet)
				{
					PRINT_BFILE_LINENO_IRET_CRT_ERR;
				}
				break;
			}
			
			m_bTunerOpenSucc = TRUE;
		}

		if(m_TunerSrv_sp.isNull())
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}

		if(FALSE == m_TunerSrv_sp->OnCheckInit())
		{
			iOutRet = ERR_INIT_FAIL;
			break;	
		}
		
		iRet = m_TunerSrv_sp->OnSetScanProgressCb(CallBackScanProgress);
		if(ERROR_SUCCESS != iRet)
		{
			PRINT_BFILE_LINENO_BUG_STR;
		}
		
		
		iRet = IMediaSrvScanProgressListener_sp->Tuner_StartScan();
		if(ERROR_SUCCESS != iRet)
		{
			PRINT_BFILE_LINENO_BUG_STR;
		}
		
		iRet = StartScanProgram();
		if(ERROR_SUCCESS != iRet && ERR_TU_SCAN_DONE != iRet
			&& ERR_TU_USER_STOP_SCAN != iRet)
		{
			iOutRet = iRet;
			iRet = IMediaSrvScanProgressListener_sp->Tuner_StopScan();
			if(ERROR_SUCCESS != iRet)
			{
				PRINT_BFILE_LINENO_BUG_STR;
			}
			
			iRet = IMediaSrvScanProgressListener_sp->NotifyTuPlayerPropmtMsg(ERR_NO_DEV);
			if(ERROR_SUCCESS != iRet)
			{
				PRINT_BFILE_LINENO_IRET_CRT_ERR;
			}
			
			break;
		}
		
		iRet = IMediaSrvScanProgressListener_sp->Tuner_StopScan();
		if(ERROR_SUCCESS != iRet)
		{
			PRINT_BFILE_LINENO_BUG_STR;
		}

	}while(FALSE);

	return iOutRet;
}

INT_t CMediaSrv::On_ResetDuration(SharedPtr<CGenericMsgData> & GenMsgData_sp, SharedPtr<CMessageQueueItem> & TransactionMsg)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	INT_t iCurrPlayStatus= PLAY_STAT_IDLE;
	SharedPtr <IMediaSrvScanProgressListener> IMediaSrvTuPlayerListener_sp;
	
	do{
		
		iOutRet = ERROR_SUCCESS;
		GenMsgData_sp->m_iOutRet = iOutRet;
		iRet = TransactionMsg->SetEvent();
		if(CC_UNLIKELY(ERROR_SUCCESS != iRet))
		{
			PRINT_BFILE_LINENO_IRET_CRT_ERR;
		}
		
		{
			CAutoLock AutoRangeLocker(&m_SharedDataMutex);
			IMediaSrvTuPlayerListener_sp = m_MediaSrvScanProgressListener_wp.Promote();
		}
		
		if(IMediaSrvTuPlayerListener_sp.isNull())
		{
			PRINT_BFILE_LINENO_BUG_STR;
			iOutRet = ERROR_INVALID_PARAMETER;
			break;
		}
		
		if(FALSE == m_bTunerOpenSucc)
		{
			iRet = OpenTunerPlayer();
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet =ERR_TUNER_OPEN_FAIL;
				PRINT_BFILE_LINENO_IRET_STR;
				GenMsgData_sp->m_iOutRet = iOutRet;
				iRet = TransactionMsg->SetEvent();
				if(CC_UNLIKELY(ERROR_SUCCESS != iRet))
				{
					PRINT_BFILE_LINENO_IRET_CRT_ERR;
				}

				IMediaSrvTuPlayerListener_sp->NotifyTuPlayerPropmtMsg(ERR_NO_DEV);
				
				break;
			}
			
			m_bTunerOpenSucc = TRUE;
		}
		
		if(m_TunerSrv_sp.isNull())
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			iRet = TransactionMsg->SetEvent();
			if(CC_UNLIKELY(ERROR_SUCCESS != iRet))
			{
				PRINT_BFILE_LINENO_IRET_CRT_ERR;
			}
			break;
		}

		if(FALSE == m_TunerSrv_sp->OnCheckInit())
		{
			iOutRet = ERR_INIT_FAIL;
			GenMsgData_sp->m_iOutRet = iOutRet;
			iRet = TransactionMsg->SetEvent();
			if(CC_UNLIKELY(ERROR_SUCCESS != iRet))
			{
				PRINT_BFILE_LINENO_IRET_CRT_ERR;
			}
			break;	
		}
		
		iOutRet = getMpSrvPlayStatus(&iCurrPlayStatus);
		if(ERROR_SUCCESS != iOutRet) 
		{
			PRINT_BFILE_LINENO_IRET_CRT_ERR
			
		}
		if(PLAY_STAT_PLAYING == iCurrPlayStatus
			|| PLAY_STAT_TUNER_SCANNING == iCurrPlayStatus)
		{
			iOutRet = ERROR_INVALID_STATE;
			GenMsgData_sp->m_iOutRet = iOutRet;
			iRet = TransactionMsg->SetEvent();
			if(CC_UNLIKELY(ERROR_SUCCESS != iRet))
			{
				PRINT_BFILE_LINENO_IRET_CRT_ERR;
			}
			break;
		}
		
		iRet = m_TunerSrv_sp->OnReInitTunerModules();
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}
		
	}while(FALSE);
	
	return iOutRet;
}

#endif

/*
ThreadContext: PlayThread
*/
INT_t CMediaSrv::On_Play(SharedPtr<CGenericMsgData> & GenMsgData_sp, SharedPtr<CMessageQueueItem> & TransactionMsg)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	RMstatus eRMstatus = RM_OK;
	DECLARE_CLS_STACK_BUF_STRING(strUrl, (4*1024));
	SharedPtr <CMsgData_Play> MsgData_Play_sp = GenMsgData_sp.DynamicCast<CMsgData_Play>();
	struct rmfp_main_thread_context_type *pMainContext = &m_RmfpMainContext;	

	//LOG_BLINE("%s() start\n",__func__);
#if 0/*2012-11-27 for test how many time is spend in this function*/
	DBG_TIME("%s() begin\n",__func__);
#endif

	do
	{		
		if(MsgData_Play_sp.isNull())
		{
			PRINT_BFILE_LINENO_BUG_STR;
			iOutRet = ERROR_INVALID_STATE;
			MsgData_Play_sp->m_iOutRet = iOutRet;
			iRet = TransactionMsg->SetEvent();
			if(CC_UNLIKELY(ERROR_SUCCESS != iRet))
			{
				PRINT_BFILE_LINENO_IRET_CRT_ERR;
			}
			break;
		}

		{
			CAutoLock AutoRangeLocker(&m_SharedDataMutex);
			if(PLAY_STAT_PREPARED != m_iPlayStatus)
			{
				iOutRet = ERROR_INVALID_STATE;
				MsgData_Play_sp->m_iOutRet = iOutRet;
				iRet = TransactionMsg->SetEvent();
				if(CC_UNLIKELY(ERROR_SUCCESS != iRet))
				{
					PRINT_BFILE_LINENO_IRET_CRT_ERR;
				}
				break;
			}
		}

		m_bIsCompletePlaybackEos = TRUE;

		{
			CAutoLock AutoRangeLocker(&m_SharedDataMutex);
			strUrl = (LPCSTR)(*m_currIterator);
			m_CntNodeInUrlList --;
			if(m_CntNodeInUrlList > 0)
			{
				m_currIterator ++;
			}
		}
		//get the param LoopCount
		if(1 < MsgData_Play_sp->LoopCount)
		{
			pMainContext->AppOptions.Playback.loop = TRUE;
			pMainContext->AppOptions.Playback.LoopCount = MsgData_Play_sp->LoopCount;
		}
		else
		{
			pMainContext->AppOptions.Playback.loop = FALSE;
		}

#if 1/*added by lxj 2013-1-8*/
		if( RM_OK != Rmfp_setPauseAfterBuffering(pMainContext->pHandle,MsgData_Play_sp->bPauseAfterBuffering)){
			LOG_BLINE("set pause_after_buffering fails\n");
		}
#endif
		//Prepare to start
		{
			CAutoLock AutoRangeLocker(&m_SharedDataMutex);
			m_bPlaybackEosIsSent = FALSE;
			INT_t iOldPlayStatus = m_iPlayStatus;
			m_iPlayStatus = PLAY_STAT_PLAYING;
			iRet = m_Mp7xxGlobalStatusData.setMpSrvPlayStatus(m_iPlayStatus);
			if(ERROR_SUCCESS != iRet)
			{
				PRINT_BFILE_LINENO_IRET_STR;
			}
			if(iOldPlayStatus != m_iPlayStatus)
			{
				iRet = m_PlayStatChangedEvent.SetEvent();
				if(ERROR_SUCCESS != iRet)
				{
					PRINT_BFILE_LINENO_IRET_STR;
				}
			}
			m_ePlaySourceType = PLAY_SOURCE_FILE;
			m_bQuitPlay = FALSE;
			//increment the m_PlaybackId
			m_PlaybackId++;
			if(0 == m_PlaybackId)
			{
				m_PlaybackId++;
			}
			MsgData_Play_sp->m_iOutRet = ERROR_SUCCESS;
			MsgData_Play_sp->m_PlaybackId = m_PlaybackId;
			iRet = TransactionMsg->SetEvent();
			if(CC_UNLIKELY(ERROR_SUCCESS != iRet))
			{
				PRINT_BFILE_LINENO_IRET_CRT_ERR;
			}
		}
	
		//implement the SNMP command "videoMode"
		if(m_bVidDispAspectRatioAtNextPlay_Valid)
		{			
			DISPLAY_ASPECT_RATIO eVidDispAspectRatioAtNextPlay;
			m_bVidDispAspectRatioAtNextPlay_Valid = FALSE;
			{
				CAutoLock AutoRangeLocker(&m_SharedDataMutex);
				eVidDispAspectRatioAtNextPlay = m_VidDispAspectRatioAtNextPlay;
			}
			
			iRet = applyVideoDispAspectRatio(eVidDispAspectRatioAtNextPlay);
			if(ERROR_SUCCESS != iRet)
			{
				PRINT_BFILE_LINENO_IRET_STR;
			}
		}

		pMainContext->EOS = FALSE;	//at beginning of playback

		m_bCanProcessMsgInDataIoTimeoutCb = TRUE;

		eRMstatus = player_rmfp_openurl(&m_RmfpMainContext, (LPCSTR)strUrl);
		if(RMFAILED(eRMstatus))
		{
			break;
		}
		m_bCanProcessMsgInDataIoTimeoutCb = FALSE;

		//detect 3D
		{			
			CUrlInfo FileUrlInfo(strUrl);
			struct EMhwlibStereoscopic3D Stereioscopic3DFmt;
			BOOL_t bIs3DFile = FALSE;
			eRMstatus = Stereoscopic3D_Init(&Stereioscopic3DFmt);
			if(RMFAILED(eRMstatus))
			{
				PRINT_BFILE_LINENO_RMSTATUS;
			}
			if(FileUrlInfo.Filename().Equal("TAB_", 4))
			{
				bIs3DFile = TRUE;
				Stereioscopic3DFmt.Format = EMhwlibStereoscopicFormat_OverUnderHalf;
			}
			else if(FileUrlInfo.Filename().Equal("SBS_", 4))
			{
				bIs3DFile = TRUE;
				Stereioscopic3DFmt.Format = EMhwlibStereoscopicFormat_SideBySideHalf;
			}
			m_CurRightStereoscopic3D = Stereioscopic3DFmt;
			if(H3DTvMode_Force2D != m_eHdmi3DTvMode)
			{
				if(bIs3DFile)
				{
					iRet = setStereoscopic3DFormat(&Stereioscopic3DFmt);
				}
				else
				{
					//no arguments, will use default 2D.
					iRet = setStereoscopic3DFormat();
				}
				if(CC_UNLIKELY(ERROR_SUCCESS != iRet))
				{
					PRINT_BFILE_LINENO_IRET_STR;
				}
			}
		}

		m_bShouldApplyHdmi3DInfoFrame = TRUE;	//now, we can schedule to re-send Hdmi3D info frame.

#if 1/*added by lxj 2012-09-21*/
		RMuint32 active_scalers_bak = pMainContext->ActiveScalers;
		if( pMainContext->stream_type.application_type == RMFP_application_type_CAPTURE ){
			pMainContext->ActiveScalers |= VIDEO_SCALER_ACTIVE;
		}
#endif
#if 0/*2012-11-27 for test how many time is spend in this function*/
		DBG_TIME("%s(),player_rmfp_run\n",__func__);
#endif

#if 1 /*Add by xuweiwei 2014-2-18 in order to Video rotation*/
		pMainContext->pOptions->playback_options.PTOrientation=m_Cur_PTOrientation;
		pMainContext->pOptions->playback_options.PTEnable=m_Cur_PTEnable;
#endif
		eRMstatus = player_rmfp_run(&m_RmfpMainContext);
		if(RMFAILED(eRMstatus))
		{
			PRINT_BFILE_LINENO_RMSTATUS;
		}
		eRMstatus = player_rmfp_closeurl(&m_RmfpMainContext);
		if(RMFAILED(eRMstatus))
		{
			PRINT_BFILE_LINENO_RMSTATUS;
		}

#if 1/*added by lxj 2012-09-21*/
		if( pMainContext->stream_type.application_type == RMFP_application_type_CAPTURE ){
			pMainContext->ActiveScalers = active_scalers_bak;
		}
#endif
		//restore actual settings for rmfp options
		RMFPOptions_RestoreSet(m_RmfpMainContext.pOptions);
	}while(FALSE);

	if(FALSE == m_bPlaybackEosIsSent && 0 == m_CntNodeInUrlList)
	{
		iRet = SendEvt_PlaybackEos();
		if(ERROR_SUCCESS != iRet)
		{
			PRINT_BFILE_LINENO_IRET_STR;
		}
	}
	else if(m_CntNodeInUrlList > 0)
	{
		iRet = SendEvt_PlayNextFile();
		if(ERROR_SUCCESS != iRet)
		{
			PRINT_BFILE_LINENO_IRET_STR;
		}
	}

	m_ePlaySourceType = PLAY_SOURCE_UNKNOWN;
	m_bCanProcessMsgInDataIoTimeoutCb = FALSE;
	//new play state
	INT_t iOldPlayStatus = m_iPlayStatus;
	m_iPlayStatus = PLAY_STAT_IDLE;
	iRet = m_Mp7xxGlobalStatusData.setMpSrvPlayStatus(m_iPlayStatus);
	if(ERROR_SUCCESS != iRet)
	{
		PRINT_BFILE_LINENO_IRET_STR;
	}
	if(iOldPlayStatus != m_iPlayStatus)
	{
		iRet = m_PlayStatChangedEvent.SetEvent();
		if(ERROR_SUCCESS != iRet)
		{
			PRINT_BFILE_LINENO_IRET_STR;
		}
	}

	//LOG_BLINE("%s() end\n",__func__);
	return iOutRet;
}

INT_t CMediaSrv::On_Stop(SharedPtr<CGenericMsgData> & GenMsgData_sp)
{
	INT_t iOutRet = ERROR_SUCCESS,iRet;
	
	do
	{		
		//thread context check
		if(CC_UNLIKELY(GetThreadId() != pthread_self()))
		{
			LOG_BLINE("BUG,dangerous call with mismatched thread context(%u!=%u)\n", pthread_self(), GetThreadId());
			break;
		}

		//idle check
		{
			CAutoLock AutoRangeLocker(&m_SharedDataMutex);	
			if(PLAY_STAT_IDLE == m_iPlayStatus)
			{
				break;
			}
		}
	}while(FALSE);

	return iOutRet;
}

INT_t CMediaSrv::onQuitPlay(SharedPtr<CMessageQueueItem> & TransactionMsg, SharedPtr<CGenericMsgData> & GenMsgData_sp)
{
	INT_t iOutRet = ERROR_SUCCESS,iRet;
	
	do
	{		
		//thread context check
		if(CC_UNLIKELY(GetThreadId() != pthread_self()))
		{
			LOG_BLINE("BUG,dangerous call with mismatched thread context(%u!=%u)\n", pthread_self(), GetThreadId());
			break;
		}

		//idle check
		{
			CAutoLock AutoRangeLocker(&m_SharedDataMutex);	
			if(PLAY_STAT_IDLE == m_iPlayStatus)
			{
				break;
			}
			//return playbackId if possible
			if(PLAY_STAT_PLAYING == m_iPlayStatus)
			{
				SharedPtr <CMsgData_QuitPlay> quitPlayMsgData_sp;
				{
					CAutoLock AutoRangeLocker(&m_SharedDataMutex);	
					if(TransactionMsg.isValid())
					{
						SharedPtr<CGenericMsgData> genericMsgData_sp = TransactionMsg->GetMessageData();
						if(genericMsgData_sp.isValid())
						{
							quitPlayMsgData_sp = genericMsgData_sp.DynamicCast<CMsgData_QuitPlay>();
						}
					}
				}
				if(quitPlayMsgData_sp.isValid())
				{
					CAutoScopeLock autoScopeLock(&(quitPlayMsgData_sp->mLock));
					quitPlayMsgData_sp->m_PlaybackId = m_PlaybackId;
					quitPlayMsgData_sp->m_strUrl = m_strDataSrcUrl;
				}
			}
			//
		}
	
#ifdef ENABLE_DTV
		//stop tuner playback
		do
		{
			if(m_TunerSrv_sp.isNull())
			{
				break;
			}
			
			{
				INT_t iCurrPlayStatus = PLAY_STAT_IDLE;
				
				iOutRet = getMpSrvPlayStatus(&iCurrPlayStatus);
				if(ERROR_SUCCESS != iOutRet) 
				{
					PRINT_BFILE_LINENO_IRET_CRT_ERR
					
				}
				
				if(PLAY_STAT_PLAYING != iCurrPlayStatus &&
					PLAY_STAT_TUNER_SCANNING != iCurrPlayStatus)
				{
					break;
				}
			
				iRet = StopTunerPlayer();
				if(ERROR_SUCCESS != iRet)
				{
					PRINT_BFILE_LINENO_BUG_STR;
					iOutRet = iRet;
					break;
				}

				{
					SharedPtr <IMediaSrvScanProgressListener> IMediaSrvScanProgressListener_sp;
			
					{
						CAutoLock AutoRangeLocker(&m_SharedDataMutex);
						IMediaSrvScanProgressListener_sp = m_MediaSrvScanProgressListener_wp.Promote();
					}
					
					if(IMediaSrvScanProgressListener_sp.isNull())
					{
						PRINT_BFILE_LINENO_BUG_STR;
						iOutRet = ERROR_INVALID_PARAMETER;
						break;
					}

					iRet = IMediaSrvScanProgressListener_sp->Tuner_StopScan();
					if(ERROR_SUCCESS != iRet)
					{
						PRINT_BFILE_LINENO_BUG_STR;
					}
				}
								
				if(CGenericTimer::TIMER_ID_INVALID != m_idProcessTunerTaskTimer)
				{
					iRet = m_GenericTimer.UnregisterTimer(m_idProcessTunerTaskTimer);
					if(ERROR_SUCCESS != iRet)
					{
						PRINT_BFILE_LINENO_IRET_STR;
					}
					m_idProcessTunerTaskTimer = 0;
				}
			}
		}while(FALSE);
#endif

		m_ePlaySourceType = PLAY_SOURCE_UNKNOWN;
	}while(FALSE);

	return iOutRet;
}

//ThreadContext: MediaSrv
INT_t CMediaSrv::On_setPlayMode(SharedPtr<CMessageQueueItem> & TransactionMsg)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	SharedPtr<CGenericMsgData> GenMsgData_sp;

	do
	{
		GenMsgData_sp = TransactionMsg->GetMessageData();
		if(CC_UNLIKELY(GenMsgData_sp.isNull()))
		{
			PRINT_BFILE_LINENO_BUG_STR;
			break;
		}

		if(PLAY_STAT_PLAYING != m_iPlayStatus)
		{
			iOutRet = ERROR_INVALID_STATE;
			break;
		}
	}while(FALSE);

	return iOutRet;
}

//ThreadContext: MediaSrv
INT_t CMediaSrv::On_getPlayMode(SharedPtr<CMessageQueueItem> & TransactionMsg)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	SharedPtr<CGenericMsgData> GenMsgData_sp;

	do
	{
		GenMsgData_sp = TransactionMsg->GetMessageData();
		if(CC_UNLIKELY(GenMsgData_sp.isNull()))
		{
			PRINT_BFILE_LINENO_BUG_STR;
			break;
		}
		GenMsgData_sp->m_uiParam = getCurPlayMode();
	}while(FALSE);

	return iOutRet;
}

/*
Thread context: play thread
*/
INT_t CMediaSrv::On_setVideoPosition(SharedPtr<CMessageQueueItem> & TransactionMsg)
{	
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	SharedPtr<CMsgData_setVideoPosition> MsgData_setVideoPos_sp;
	SharedPtr<CGenericMsgData> GenMsgData_sp;
	struct rmfp_main_thread_context_type *pMainContext = &m_RmfpMainContext;	

	do
	{
		GenMsgData_sp = TransactionMsg->GetMessageData();
		if(CC_UNLIKELY(GenMsgData_sp.isNull()))
		{
			PRINT_BFILE_LINENO_BUG_STR;
			iOutRet = ERR_INTERNAL_FAIL;
			break;
		}
		MsgData_setVideoPos_sp = GenMsgData_sp.DynamicCast<CMsgData_setVideoPosition>();
		if(MsgData_setVideoPos_sp.isNull())
		{
			PRINT_BFILE_LINENO_BUG_STR;
			iOutRet = ERR_INTERNAL_FAIL;
			break;
		}
		iOutRet = setVideoPosition(MsgData_setVideoPos_sp->x, MsgData_setVideoPos_sp->y,
			MsgData_setVideoPos_sp->Width, MsgData_setVideoPos_sp->Height,
			&(m_RmfpMainContext.AppOptions.Display.output_window));
		if(ERROR_SUCCESS != iOutRet)
		{
			break;
		}
		pMainContext->AppOptions.Display.output_osd_window = pMainContext->AppOptions.Display.output_window;
	}while(FALSE);

	return iOutRet;
}

/*
Thread context: playback thread
*/
INT_t CMediaSrv::On_setVideoInputWindowSize(SharedPtr<CMessageQueueItem> & TransactionMsg)
{	
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	RMstatus eRMstatus;
	SharedPtr<CMsgData_setVideoInputWindowSize> MsgData_setVidInWinSize_sp;
	SharedPtr<CGenericMsgData> GenMsgData_sp;
	struct rmfp_main_thread_context_type *pMainContext = &m_RmfpMainContext;
	struct RUA * pRua = pMainContext->pRUA;
	RMuint32 videoScalerModuleId;

	CAutoLock AutoRangeLocker(&m_mutexVideoAudioIoSet); 

	GenMsgData_sp = TransactionMsg->GetMessageData();
	if(CC_UNLIKELY(GenMsgData_sp.isNull()))
	{
		PRINT_BFILE_LINENO_BUG_STR;
		iOutRet = ERR_INTERNAL_FAIL;
		goto EXIT_PROC;
	}
	MsgData_setVidInWinSize_sp = GenMsgData_sp.DynamicCast<CMsgData_setVideoInputWindowSize>();
	if(MsgData_setVidInWinSize_sp.isNull())
	{
		PRINT_BFILE_LINENO_BUG_STR;
		iOutRet = ERR_INTERNAL_FAIL;
		goto EXIT_PROC;
	}

	eRMstatus = rmfp_getVideoScalerModuleId(pMainContext, &videoScalerModuleId, NULL);
	if(RMFAILED(eRMstatus))
	{
		PRINT_BFILE_LINENO_RMSTATUS;
		videoScalerModuleId = EMHWLIB_MODULE(DispMainVideoScaler, 0);
	}

	iOutRet = Scaler_setInputWindowSize(pRua, videoScalerModuleId, MsgData_setVidInWinSize_sp->inWinX, MsgData_setVidInWinSize_sp->inWinY,
		MsgData_setVidInWinSize_sp->inWinW, MsgData_setVidInWinSize_sp->inWinH,
		&(m_RmfpMainContext.AppOptions.Display.source_window));
	if(ERROR_SUCCESS != iOutRet)
	{
		goto EXIT_PROC;
	}

EXIT_PROC:
	return iOutRet;
}

INT_t CMediaSrv::On_SetOutputSpdifMode(SharedPtr<CMessageQueueItem> & TransactionMsg)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	SharedPtr<CMsgData_setSpdifMode> MsgData_SPDIFMode_sp;
	SharedPtr<CGenericMsgData> GenMsgData_sp;
	INT32_t iSnmpOutSpdifMode = Mp7xxCommon::SnmpOutSpdifMode_Uncompressed;
	DECLARE_CLS_STACK_BUF_STRING(strOutputSpdifMode, 64);

	CAutoLock AutoRangeLocker(&m_mutexVideoAudioIoSet); 
	
	do{
		GenMsgData_sp = TransactionMsg->GetMessageData();
		if(CC_UNLIKELY(GenMsgData_sp.isNull()))
		{
			PRINT_BFILE_LINENO_BUG_STR;
			iOutRet = ERR_INTERNAL_FAIL;
			break;
		}
		
		MsgData_SPDIFMode_sp = GenMsgData_sp.DynamicCast<CMsgData_setSpdifMode>();
		if(MsgData_SPDIFMode_sp.isNull())
		{
			PRINT_BFILE_LINENO_BUG_STR;
			iOutRet = ERR_INTERNAL_FAIL;
			break;
		}

		iSnmpOutSpdifMode = MsgData_SPDIFMode_sp->m_iSpdifMode;
		
		//SAVE
		iRet = strOutputSpdifMode.Format("%d", iSnmpOutSpdifMode);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}
		iRet = SysProp_setPersistent(SysProp_KEY_OutputSpdifMode, (LPCSTR)strOutputSpdifMode);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}

		iRet = setMruaOutputSpdifMode(iSnmpOutSpdifMode);
		if(ERROR_SUCCESS != iRet)
		{
			PRINT_BFILE_LINENO_IRET_STR;
			iOutRet = iRet;
			goto EXIT_PROC;
		}				
	}while(FALSE);

EXIT_PROC:

	return iOutRet;
}

INT_t CMediaSrv::On_setShowClosedCaption(SharedPtr<CMessageQueueItem> & TransactionMsg)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	SharedPtr<CGenericMsgData> MsgData_sp;

	MsgData_sp = TransactionMsg->GetMessageData();
	if(CC_UNLIKELY(MsgData_sp.isNull()))
	{
		iOutRet = ERR_INV_PARAM;
		goto EXIT_PROC;
	}

	m_eShowClosedCaption = (typeof(m_eShowClosedCaption))(MsgData_sp->m_uiParam);
	if(CC_SEL_MIN_VALUE > m_eShowClosedCaption || CC_SEL_MAX_VALUE < m_eShowClosedCaption)
	{
		iOutRet = ERR_INV_PARAM;
		goto EXIT_PROC;
	}
	iRet = SysProp_setPersistent(SysProp_KEY_ShowClosedCaption, (INT_t)m_eShowClosedCaption);
	if(ERR_SUCCESS != iRet)
	{
		iOutRet = iRet;
		goto EXIT_PROC;
	}

EXIT_PROC:
	return iOutRet;
}

INT_t CMediaSrv::On_setVideoRotation(SharedPtr<CMessageQueueItem> & TransactionMsg)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	SharedPtr<CMsgData_setVideoRotation> MsgData_VideoRotation_sp;
	SharedPtr<CGenericMsgData> GenMsgData_sp;
	INT32_t iVideoRotationMode = Mp7xxCommon::VIDEO_ROTATION_0;
	DECLARE_CLS_STACK_BUF_STRING(strVideoRotationMode, 64);

	CAutoLock AutoRangeLocker(&m_mutexVideoAudioIoSet); 
	
	do{
		GenMsgData_sp = TransactionMsg->GetMessageData();
		if(CC_UNLIKELY(GenMsgData_sp.isNull()))
		{
			PRINT_BFILE_LINENO_BUG_STR;
			iOutRet = ERR_INTERNAL_FAIL;
			break;
		}
		
		MsgData_VideoRotation_sp = GenMsgData_sp.DynamicCast<CMsgData_setVideoRotation>();
		if(MsgData_VideoRotation_sp.isNull())
		{
			PRINT_BFILE_LINENO_BUG_STR;
			iOutRet = ERR_INTERNAL_FAIL;
			break;
		}

		iVideoRotationMode = MsgData_VideoRotation_sp->m_iVideoRotationMode;
		
		//SAVE
		iRet = strVideoRotationMode.Format("%d", iVideoRotationMode);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}
		iRet = SysProp_setPersistent(SysProp_KEY_VideoRotationMode, (LPCSTR)strVideoRotationMode);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}

		iRet = setMruaVideoRotationMode(iVideoRotationMode);
		if(ERROR_SUCCESS != iRet)
		{
			PRINT_BFILE_LINENO_IRET_STR;
			iOutRet = iRet;
			goto EXIT_PROC;
		}				
	}while(FALSE);

EXIT_PROC:

	return iOutRet;
}


INT_t CMediaSrv::On_setEnableAudio6Ch(SharedPtr<CMessageQueueItem> & TransactionMsg)
{
    	INT_t iOutRet = ERROR_SUCCESS, iRet;
	SharedPtr<CMsgData_setEnableAudio6Ch> MsgData_setEnableAudio6Ch_sp;
	SharedPtr<CGenericMsgData> GenMsgData_sp;
	BOOL_t iEnAudio6ChFlag = FALSE;
	DECLARE_CLS_STACK_BUF_STRING(strEnAudio6ChFlag, 32);

	CAutoLock AutoRangeLocker(&m_mutexVideoAudioIoSet); 
	
	do{
		GenMsgData_sp = TransactionMsg->GetMessageData();
		if(CC_UNLIKELY(GenMsgData_sp.isNull()))
		{
			PRINT_BFILE_LINENO_BUG_STR;
			iOutRet = ERR_INTERNAL_FAIL;
			break;
		}
		
		MsgData_setEnableAudio6Ch_sp = GenMsgData_sp.DynamicCast<CMsgData_setEnableAudio6Ch>();
		if(MsgData_setEnableAudio6Ch_sp.isNull())
		{
			PRINT_BFILE_LINENO_BUG_STR;
			iOutRet = ERR_INTERNAL_FAIL;
			break;
		}

		iEnAudio6ChFlag = MsgData_setEnableAudio6Ch_sp->m_iEnAudio6ChFlag;
		
		//SAVE
		iRet = strEnAudio6ChFlag.Format("%d", iEnAudio6ChFlag);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}
		iRet = SysProp_setPersistent(SysProp_KEY_EnAudio6ChFlag, (LPCSTR)strEnAudio6ChFlag);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}

		iRet = setEnAudio6Channel(iEnAudio6ChFlag);
		if(ERROR_SUCCESS != iRet)
		{
			PRINT_BFILE_LINENO_IRET_STR;
			iOutRet = iRet;
			goto EXIT_PROC;
		}				
	}while(FALSE);

EXIT_PROC:

	return iOutRet;
    
}

INT_t CMediaSrv::On_getEnableAudio6Ch(SharedPtr<CMessageQueueItem> & TransactionMsg)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	SharedPtr<CGenericMsgData> GenMsgData_sp;
       BOOL_t oEnAudio6ChFlag = -1;
	DECLARE_CLS_STACK_BUF_STRING(strEnAudio6ChFlag, 32);

	do
	{    
            GenMsgData_sp = TransactionMsg->GetMessageData();
            if(CC_UNLIKELY(GenMsgData_sp.isNull()))
            {
                PRINT_BFILE_LINENO_BUG_STR;
                break;
            }

            iRet = SysProp_get(SysProp_KEY_EnAudio6ChFlag, OUT strEnAudio6ChFlag);
            if(ERR_SUCCESS != iRet)
            {
                  iOutRet=iRet;
                  break;
            }
            oEnAudio6ChFlag = (INT_t)(strEnAudio6ChFlag); 
            GenMsgData_sp->m_uiParam = oEnAudio6ChFlag;

        }while(FALSE);

	return iOutRet;

}

INT_t CMediaSrv::On_ChangeVidOutMode(SharedPtr<CMessageQueueItem> & TransactionMsg)
{	
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	SharedPtr<CMsgData_ChangeVidOutMode> MsgData_ChangeVidOutMode_sp;
	SharedPtr<CGenericMsgData> GenMsgData_sp;

	do
	{
		GenMsgData_sp = TransactionMsg->GetMessageData();
		if(CC_UNLIKELY(GenMsgData_sp.isNull()))
		{
			PRINT_BFILE_LINENO_BUG_STR;
			iOutRet = ERR_INTERNAL_FAIL;
			break;
		}
		MsgData_ChangeVidOutMode_sp = GenMsgData_sp.DynamicCast<CMsgData_ChangeVidOutMode>();
		if(MsgData_ChangeVidOutMode_sp.isNull())
		{
			PRINT_BFILE_LINENO_BUG_STR;
			iOutRet = ERR_INTERNAL_FAIL;
			break;
		}
		iOutRet = ChangeVideoOutputMode(MsgData_ChangeVidOutMode_sp->m_eVoModeToSet, 
			&(MsgData_ChangeVidOutMode_sp->m_eNewVoMode), &(MsgData_ChangeVidOutMode_sp->m_eOldVoMode));
		if(ERROR_SUCCESS != iOutRet)
		{
			break;
		}

		if(MsgData_ChangeVidOutMode_sp->m_eNewVoMode != MsgData_ChangeVidOutMode_sp->m_eOldVoMode)
		{
			iRet = EmitVidOutModeChangedEvent(MsgData_ChangeVidOutMode_sp->m_eNewVoMode);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
				break;
			}
		}
	}while(FALSE);

	return iOutRet;
}

INT_t CMediaSrv::On_setPlaySpeedCtrl(SharedPtr<CMessageQueueItem> & TransactionMsg)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	SharedPtr<CMsgData_setPlaySpeedCtrl> MsgData_setPlaySpeedCtrl_sp;
	SharedPtr<CGenericMsgData> GenMsgData_sp;

	do
	{
		GenMsgData_sp = TransactionMsg->GetMessageData();
		if(CC_UNLIKELY(GenMsgData_sp.isNull()))
		{
			PRINT_BFILE_LINENO_BUG_STR;
			iOutRet = ERR_INTERNAL_FAIL;
			break;
		}
		MsgData_setPlaySpeedCtrl_sp = GenMsgData_sp.DynamicCast<CMsgData_setPlaySpeedCtrl>();
		if(MsgData_setPlaySpeedCtrl_sp.isNull())
		{
			PRINT_BFILE_LINENO_BUG_STR;
			iOutRet = ERR_INTERNAL_FAIL;
			break;
		}
		iOutRet = setPlaySpeedCtrl(MsgData_setPlaySpeedCtrl_sp->m_iSpeed);
		if(ERROR_SUCCESS != iOutRet)
		{
			break;
		}
	}while(FALSE);

	return iOutRet;
}

INT_t CMediaSrv::On_getPlaySpeedCtrl(SharedPtr<CMessageQueueItem> & TransactionMsg)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	SharedPtr<CMsgData_getPlaySpeedCtrl> MsgData_getPlaySpeedCtrl_sp;
	SharedPtr<CGenericMsgData> GenMsgData_sp;

	do
	{
		GenMsgData_sp = TransactionMsg->GetMessageData();
		if(CC_UNLIKELY(GenMsgData_sp.isNull()))
		{
			PRINT_BFILE_LINENO_BUG_STR;
			iOutRet = ERR_INTERNAL_FAIL;
			break;
		}
		MsgData_getPlaySpeedCtrl_sp = GenMsgData_sp.DynamicCast<CMsgData_getPlaySpeedCtrl>();
		if(MsgData_getPlaySpeedCtrl_sp.isNull())
		{
			PRINT_BFILE_LINENO_BUG_STR;
			iOutRet = ERR_INTERNAL_FAIL;
			break;
		}
		iOutRet = getPlaySpeed(OUT MsgData_getPlaySpeedCtrl_sp->m_iSpeed);
		if(ERROR_SUCCESS != iOutRet)
		{
			break;
		}
	}while(FALSE);

	return iOutRet;
}

INT_t CMediaSrv::On_DispOnLedScr(SharedPtr<CMessageQueueItem> & TransactionMsg)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	SharedPtr<CMsgData_DispOnLedScr> MsgData_DispOnLedScr_sp;
	SharedPtr<CGenericMsgData> GenMsgData_sp;

	do
	{
		GenMsgData_sp = TransactionMsg->GetMessageData();
		if(CC_UNLIKELY(GenMsgData_sp.isNull()))
		{
			PRINT_BFILE_LINENO_BUG_STR;
			iOutRet = ERR_INTERNAL_FAIL;
			break;
		}
		MsgData_DispOnLedScr_sp = GenMsgData_sp.DynamicCast<CMsgData_DispOnLedScr>();
		if(MsgData_DispOnLedScr_sp.isNull())
		{
			PRINT_BFILE_LINENO_BUG_STR;
			iOutRet = ERR_INTERNAL_FAIL;
			break;
		}
		iOutRet = DisplayOnLedScreen(MsgData_DispOnLedScr_sp->m_strDispContent, MsgData_DispOnLedScr_sp->m_StartPosToDisp);
		if(ERROR_SUCCESS != iOutRet)
		{
			break;
		}
	}while(FALSE);

	return iOutRet;
}

//Callbacks
RMstatus CMediaSrv::Cb_getCommand(void* pContext, struct RMFPPlaybackCommand *pCommand, RMuint32 TimeOutInMicroSeconds)
{
	RMstatus eRMstatus = RM_OK;
	struct rmfp_main_thread_context_type * pRmfpMainContext;
	CMediaSrv * pMediaSrv;

	do
	{
		if(NULL == pContext || NULL == pCommand)
		{
			eRMstatus = RM_INVALID_PARAMETER;
			break;
		}
		pRmfpMainContext = (typeof(pRmfpMainContext))pContext;
		pMediaSrv = (typeof(pMediaSrv))(pRmfpMainContext->pMediaSrv);
		if(NULL == pMediaSrv)
		{
			eRMstatus = RM_INVALID_PARAMETER;
			break;
		}
		eRMstatus = pMediaSrv->getCommand(pCommand, TimeOutInMicroSeconds);
	}while(FALSE);

	return eRMstatus;
}

RMstatus CMediaSrv::Cb_notifyCommandStatus(void *pContext, struct RMFPCommandStatus *pStatus)
{
	RMstatus eRMstatus = RM_OK;
	struct rmfp_main_thread_context_type * pRmfpMainContext;
	CMediaSrv * pMediaSrv;

	do
	{
		if(NULL == pContext)
		{
			eRMstatus = RM_INVALID_PARAMETER;
			break;
		}
		pRmfpMainContext = (typeof(pRmfpMainContext))pContext;
		pMediaSrv = (typeof(pMediaSrv))(pRmfpMainContext->pMediaSrv);
		if(NULL == pMediaSrv)
		{
			eRMstatus = RM_INVALID_PARAMETER;
			break;
		}
		eRMstatus = pMediaSrv->notifyCommandStatus(pStatus);
	}while(FALSE);

	return eRMstatus;
}

RMstatus CMediaSrv::getCommand(struct RMFPPlaybackCommand *pCommand, RMuint32 TimeOutInMicroSeconds)
{
	RMstatus eRMstatus = RM_OK;
	INT_t iRet;
	SharedPtr<CMessageQueueItem> TransactionMsg;
	struct rmfp_main_thread_context_type *pMainContext = &m_RmfpMainContext;	

	do
	{
		if(m_bQuitPlay)
		{
			pCommand->command = RMFP_Playback_command_Quit;
			m_bIsCompletePlaybackEos = FALSE;
			break;
		}

		if(pMainContext->EOS)
		{
			//LOG_BLINE("EOS\n");
			if(pMainContext->AppOptions.Playback.loop && 0 < pMainContext->AppOptions.Playback.LoopCount)
			{
				pMainContext->playback_started = FALSE;
				//set cmd params
				pCommand->command = RMFP_Playback_command_Play;
				pCommand->params.speed.N = 1;
				pCommand->params.speed.M = 1;
			}
			else
			{
				pCommand->command = RMFP_Playback_command_Quit;
				m_bIsCompletePlaybackEos = FALSE;
			}
			pMainContext->EOS = FALSE;
			break;
		}
		
		iRet = GetMessageTimeout(TransactionMsg, TimeOutInMicroSeconds/1000);
		if(CC_LIKELY(ERROR_SUCCESS == iRet))
		{
			if(CC_LIKELY(NULL != TransactionMsg.get()))
			{
				m_CurTransactionMsg_sp = TransactionMsg;
				//LOG_BLINE("CMediaSrv::getCommand\n");
				iRet = TranslateToRmfpCmd(TransactionMsg, pCommand);
				if(ERROR_SUCCESS != iRet)
				{
					eRMstatus = RM_PENDING;
					{
						CAutoLock AutoRangeLocker(&m_SharedDataMutex);
						if(TransactionMsg.isValid())
						{
							iRet = TransactionMsg->SetEvent();
							if(CC_UNLIKELY(ERROR_SUCCESS != iRet))
							{
								PRINT_BFILE_LINENO_IRET_CRT_ERR;
							}
						}
					}
				}
				TransactionMsg.Release();
			}
			else
			{
				eRMstatus = RM_PENDING;
			}
			break;
		}
		else if(CC_LIKELY(ERR_TIMEOUT == iRet))
		{
			eRMstatus = RM_PENDING;
			break;
		}
		else if(CC_LIKELY(ERR_LINUX_SIGNAL_INT == iRet))
		{
			eRMstatus = RM_PENDING;
			break;
		}
		else
		{
			PRINT_BFILE_LINENO_IRET_CRT_ERR;
			eRMstatus = RM_ERROR;
			break;
		}
	}while(FALSE);

	DBusConnWakeUp_ClearMsg();
	
	return eRMstatus;
}

//called from rmfp
RMstatus CMediaSrv::notifyCommandStatus(struct RMFPCommandStatus *pStatus)
{
	RMstatus eRMstatus = RM_OK;
	INT_t iRet;

	do
	{
		if(NULL == pStatus)
		{
			break;
		}
	}while(FALSE);
	
	{
		CAutoLock AutoRangeLocker(&m_SharedDataMutex);
		if(m_CurTransactionMsg_sp.isValid())
		{
			//LOG_BLINE("CMediaSrv::notifyCommandStatus\n");
			iRet = m_CurTransactionMsg_sp->SetEvent();
			if(CC_UNLIKELY(ERROR_SUCCESS != iRet))
			{
				PRINT_BFILE_LINENO_IRET_CRT_ERR;
			}
		}
	}

	return eRMstatus;
}

#if 1/*added by lxj 2013-1-8*/
/*
ThreadContext: PlayThread
*/
RMstatus CMediaSrv::Cb_notify_progress(void *pContext, struct RMFPProgress* pProgress, RMbool *pAbort)
{
	RMstatus eRMstatus = RM_OK;
	struct rmfp_main_thread_context_type * pRmfpMainContext;
	CMediaSrv * pMediaSrv;

	do
	{
		if(NULL == pContext)
		{
			eRMstatus = RM_INVALID_PARAMETER;
			break;
		}
		pRmfpMainContext = (typeof(pRmfpMainContext))pContext;
		pMediaSrv = (typeof(pMediaSrv))(pRmfpMainContext->pMediaSrv);
		if(NULL == pMediaSrv)
		{
			eRMstatus = RM_INVALID_PARAMETER;
			break;
		}
		eRMstatus = pMediaSrv->NotifyPlaybackProgress(pProgress,pAbort);
	}while(FALSE);

	return eRMstatus;
}

RMstatus CMediaSrv::NotifyPlaybackProgress(struct RMFPProgress* pProgress, RMbool *pAbort)
{
	INT_t iRet;
	RMstatus eOutRMstatus = RM_OK, eRMstatus;
	SharedPtr <IMediaSrvEventListener> MediaSrvEvtListener_sp;
	struct rmfp_main_thread_context_type *pMainContext = &m_RmfpMainContext;
	struct RUA * pRua = pMainContext->pRUA;	

	C_UNUSED(eRMstatus);
	
	do
	{
		eOutRMstatus = notify_progress(&m_RmfpMainContext,pProgress,pAbort);
		if(RMFAILED(eOutRMstatus))
		{
			break;
		}

		if( pProgress && (RMFP_progress_type_buffering == pProgress->progress_type)){
			switch (pProgress->info_type){
				case RMFP_progress_info_type_percentage:
					if (pProgress->progress.percentage == 100) {
						{
							CAutoLock AutoRangeLocker(&m_SharedDataMutex);
							MediaSrvEvtListener_sp = m_MediaSrvEvtListener_wp.Promote();
						}
						if(MediaSrvEvtListener_sp.isNull()){
							break;
						}
								
						iRet = MediaSrvEvtListener_sp->PlaybackReadyToPlay();
						if(ERROR_SUCCESS != iRet){
							PRINT_BFILE_LINENO_IRET_STR;
						}
						iRet = WakeupMainThread();
						if(ERROR_SUCCESS != iRet){
							PRINT_BFILE_LINENO_IRET_STR;
						}
					}
			}
		}
	}while(FALSE);

	return eOutRMstatus;
}
#endif

/*
ThreadContext: PlayThread
*/
RMstatus CMediaSrv::Cb_notify_playback_start(void *pContext)
{
	RMstatus eRMstatus = RM_OK;
	struct rmfp_main_thread_context_type * pRmfpMainContext;
	CMediaSrv * pMediaSrv;

	do
	{
		if(NULL == pContext)
		{
			eRMstatus = RM_INVALID_PARAMETER;
			break;
		}
		pRmfpMainContext = (typeof(pRmfpMainContext))pContext;
		pMediaSrv = (typeof(pMediaSrv))(pRmfpMainContext->pMediaSrv);
		if(NULL == pMediaSrv)
		{
			eRMstatus = RM_INVALID_PARAMETER;
			break;
		}
		eRMstatus = pMediaSrv->NotifyPlaybackStart();
	}while(FALSE);

	return eRMstatus;
}

/*
ThreadContext: local worker thread
*/
void CMediaSrv::Cb_DataIoTimeoutCallback(P_DATA_IO_CB_INFO pDataIoCbInfo, OUT P_DATA_IO_CB_ACTION pDataIoCbAction)
{
	SharedPtr<CMessageQueueItem> TransactionMsg;
	SharedPtr <CMediaSrv> MediaSrv_sp;

	do
	{
		MediaSrv_sp = g_MediaSrv_wp.Promote();
		if(MediaSrv_sp.isNull())
		{
			break;
		}
		MediaSrv_sp->DataIoTimeoutCallback(pDataIoCbInfo, pDataIoCbAction);
	}while(FALSE);
}

/*
ThreadContext: local worker thread
*/
void CMediaSrv::DataIoTimeoutCallback(P_DATA_IO_CB_INFO pDataIoCbInfo, OUT P_DATA_IO_CB_ACTION pDataIoCbAction)
{
	INT_t iRet;
	SharedPtr<CMessageQueueItem> TransactionMsg;

	do
	{
		if(FALSE == m_bCanProcessMsgInDataIoTimeoutCb)
		{
			break;
		}
		
		iRet = GetMessageTimeout(TransactionMsg, 0);
		if(CC_LIKELY(ERROR_SUCCESS == iRet))
		{
			if(CC_LIKELY(NULL != TransactionMsg.get()))
			{
				//LOG_BLINE("DataIoTimeoutCallback,new transaction msg\n");
				ProcessMsg(TransactionMsg);
				TransactionMsg.Release();
			}
		}
		else if(CC_LIKELY(ERR_TIMEOUT == iRet))
		{
		}
		else if(CC_LIKELY(ERR_LINUX_SIGNAL_INT == iRet))
		{
		}
		else
		{
			PRINT_BFILE_LINENO_IRET_CRT_ERR;
		}
	}while(FALSE);
}

/*
ThreadContext: local(player thread)
*/
RMstatus CMediaSrv::NotifyPlaybackStart()
{
	INT_t iRet;
	RMstatus eOutRMstatus = RM_OK, eRMstatus;
	SharedPtr <IMediaSrvEventListener> MediaSrvEvtListener_sp;
	struct rmfp_main_thread_context_type *pMainContext = &m_RmfpMainContext;
	struct RUA * pRua = pMainContext->pRUA;	

	C_UNUSED(eRMstatus);
	
	do
	{
		if(m_bShouldApplyHdmi3DInfoFrame)
		{
			m_bShouldApplyHdmi3DInfoFrame = FALSE;	//only do once
			pMainContext->display_opt->hdmi_options.bRequestedStereoscopic3D_changed = TRUE;	//schedule to do, atomic op, not need mutex.
			pMainContext->display_opt->hdmi_options.bForceSendVsiInfoFrameOnce = TRUE;
		}
		
		eOutRMstatus = notify_playback_start(&m_RmfpMainContext);
		if(RMFAILED(eOutRMstatus))
		{
			break;
		}
		
		{
			CAutoLock AutoRangeLocker(&m_SharedDataMutex);
			MediaSrvEvtListener_sp = m_MediaSrvEvtListener_wp.Promote();
		}
		if(MediaSrvEvtListener_sp.isNull())
		{
			break;
		}
				
		iRet = MediaSrvEvtListener_sp->PlaybackStart();
		if(ERROR_SUCCESS != iRet)
		{
			PRINT_BFILE_LINENO_IRET_STR;
		}
		iRet = WakeupMainThread();
		if(ERROR_SUCCESS != iRet)
		{
			PRINT_BFILE_LINENO_IRET_STR;
		}
	}while(FALSE);

	return eOutRMstatus;
}

/*
ThreadContext: PlayThread
*/
RMstatus CMediaSrv::Cb_notify_playback_eos(void *pContext)
{
	RMstatus eRMstatus = RM_OK;
	struct rmfp_main_thread_context_type * pRmfpMainContext;
	CMediaSrv * pMediaSrv;

	do
	{
		if(NULL == pContext)
		{
			eRMstatus = RM_INVALID_PARAMETER;
			break;
		}
		pRmfpMainContext = (typeof(pRmfpMainContext))pContext;
		pMediaSrv = (typeof(pMediaSrv))(pRmfpMainContext->pMediaSrv);
		if(NULL == pMediaSrv)
		{
			eRMstatus = RM_INVALID_PARAMETER;
			break;
		}
		
		eRMstatus = pMediaSrv->NotifyPlaybackEos();
	}while(FALSE);

	return eRMstatus;
}

/*
ThreadContext: Local(PlayThread), in callback
*/
RMstatus CMediaSrv::NotifyPlaybackEos()
{
	RMstatus eOutRMstatus = RM_OK;
	INT_t iRet;
	struct rmfp_main_thread_context_type *pMainContext = &m_RmfpMainContext;	
	
	do
	{
		if(pMainContext->AppOptions.Playback.loop)
		{
			pMainContext->AppOptions.Playback.LoopCount--;
			if(0 < pMainContext->AppOptions.Playback.LoopCount)
			{
				pMainContext->EOS = TRUE;
				break;
			}
		}
		
		eOutRMstatus = notify_playback_eos(pMainContext);
		if(RMFAILED(eOutRMstatus))
		{
			break;
		}
		
		if(0 == m_CntNodeInUrlList)
		{
			iRet = SendEvt_PlaybackEos();
			if(ERROR_SUCCESS != iRet)
			{
				PRINT_BFILE_LINENO_IRET_STR;
			}
		}
		
	}while(FALSE);

	return eOutRMstatus;
}

INT_t CMediaSrv::SendEvt_PlayNextFile()
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	SharedPtr <IMediaSrvEventListener> MediaSrvEvtListener_sp;

	do{
		{
			CAutoLock AutoRangeLocker(&m_SharedDataMutex);
			MediaSrvEvtListener_sp = m_MediaSrvEvtListener_wp.Promote();
		}

		if(MediaSrvEvtListener_sp.isNull())
		{
			PRINT_BFILE_LINENO_BUG_STR;
			break;
		}

		iRet = MediaSrvEvtListener_sp->PlayNextFile();
		if(ERROR_SUCCESS != iRet)
		{
			PRINT_BFILE_LINENO_IRET_STR;
		}
		iRet = WakeupMainThread();
		if(ERROR_SUCCESS != iRet)
		{
			PRINT_BFILE_LINENO_IRET_STR;
		}
		
	}while(FALSE);

	return iOutRet;
}

INT_t CMediaSrv::SendEvt_PlaybackEos()
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	SharedPtr <IMediaSrvEventListener> MediaSrvEvtListener_sp;
	DECLARE_CLS_STACK_BUF_STRING(strCurPlayUrl, (4*1024));	

	do
	{
		{
			CAutoLock AutoRangeLocker(&m_SharedDataMutex);
			MediaSrvEvtListener_sp = m_MediaSrvEvtListener_wp.Promote();
		}
		if(MediaSrvEvtListener_sp.isNull())
		{
			PRINT_BFILE_LINENO_BUG_STR;
			break;
		}
		
		{
			CAutoLock AutoRangeLocker(&m_SharedDataMutex);
			strCurPlayUrl = (LPCSTR)m_strDataSrcUrl;
		}

		if(m_bPlaybackEosIsSent)
		{
			PRINT_BFILE_LINENO_BUG_STR;
		}
		m_bPlaybackEosIsSent = TRUE;
		iRet = MediaSrvEvtListener_sp->PlaybackEos((LPCSTR)strCurPlayUrl, m_PlaybackId, m_bIsCompletePlaybackEos);
		if(ERROR_SUCCESS != iRet)
		{
			PRINT_BFILE_LINENO_IRET_STR;
		}
		iRet = WakeupMainThread();
		if(ERROR_SUCCESS != iRet)
		{
			PRINT_BFILE_LINENO_IRET_STR;
		}		
	}while(FALSE);

	return iOutRet;
}

INT_t CMediaSrv::TranslateToRmfpCmd(SharedPtr<CMessageQueueItem> & TransactionMsg, struct RMFPPlaybackCommand *pCommand)
{
	INT_t iOutRet = ERROR_SUCCESS;
	SharedPtr<CGenericMsgData> GenMsgData_sp;
	RMstatus eRMstatus;
	struct rmfp_main_thread_context_type *pMainContext = &m_RmfpMainContext;

	ZeroMemory(pCommand, sizeof(*pCommand));
	pCommand->command = RMFP_Playback_command_Unknown;

	do
	{
		GenMsgData_sp = TransactionMsg->GetMessageData();
		if(CC_UNLIKELY(NULL == GenMsgData_sp.get()))
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}
		
		GenMsgData_sp->m_iOutRet = ERROR_SUCCESS;
		
		if(MSG_CMD_setDataSource == GenMsgData_sp->m_uiMsgId)
		{
			GenMsgData_sp->m_iOutRet = ERROR_INVALID_STATE;
		}
		else if(MSG_CMD_Prepare == GenMsgData_sp->m_uiMsgId)
		{
			GenMsgData_sp->m_iOutRet = ERROR_INVALID_STATE;
		}
		else if(MSG_CMD_Play == GenMsgData_sp->m_uiMsgId)
		{
			GenMsgData_sp->m_iOutRet = ERROR_INVALID_STATE;
		}
		else if(MSG_CMD_TunerScan == GenMsgData_sp->m_uiMsgId)
		{
			GenMsgData_sp->m_iOutRet = ERROR_INVALID_STATE;
		}
		else if(MSG_CMD_Stop == GenMsgData_sp->m_uiMsgId)
		{
			eRMstatus = Rmfp_setRequestQuitPlay(pMainContext->pHandle, TRUE);
			if(RMFAILED(eRMstatus))
			{
				PRINT_BFILE_LINENO_RMSTATUS;
			}
			pCommand->command = RMFP_Playback_command_Stop;
			pCommand->params.stop.type = RMFP_stop_type_blackframe;
		}
		else if(MSG_CMD_QuitPlay == GenMsgData_sp->m_uiMsgId)
		{			
			eRMstatus = Rmfp_setRequestQuitPlay(pMainContext->pHandle, TRUE);
			if(RMFAILED(eRMstatus))
			{
				PRINT_BFILE_LINENO_RMSTATUS;
			}
			m_bQuitPlay = TRUE;
			pCommand->command = RMFP_Playback_command_Quit;
			m_bIsCompletePlaybackEos = FALSE;
		}
		else if(MSG_CMD_setPlayMode == GenMsgData_sp->m_uiMsgId)
		{
			RMuint32 AllowedCmdMask = 0;
			MediaPlayer::PlayMode ePlayMode = (typeof(ePlayMode))(GenMsgData_sp->m_uiParam);
			if(MediaPlayer::PlayMode_Normal == ePlayMode)
			{
				pCommand->command = RMFP_Playback_command_Play;
				pCommand->params.speed.N = 1;
				pCommand->params.speed.M = 1;
				m_RmfpMainContext.iframing = FALSE;
				if (pMainContext->dh_info) 
				{
					if ((pMainContext->dh_info->CEC.DeckInfo != CEC_DeckInfo_Play) && 
						(pMainContext->dh_info->CEC.DeckInfo != CEC_DeckInfo_Still)) 
					{
						// "One Touch Play" feature
						pMainContext->dh_info->CEC.RequestImageViewOn = TRUE;
						pMainContext->dh_info->CEC.RequestActiveSource = TRUE;
					}
					pMainContext->dh_info->CEC.DeckInfo = CEC_DeckInfo_Play;
				}
			}
			else if(MediaPlayer::PlayMode_Pause == ePlayMode)
			{
				pCommand->command = RMFP_Playback_command_Pause;
				pCommand->params.pause.type = RMFP_pause_default;
			}
			else if(MediaPlayer::PlayMode_FastForward == ePlayMode)
			{
				if((RM_OK == Rmfp_getAllowedCmdMask(m_RmfpMainContext.pHandle, &AllowedCmdMask)) &&
					(AllowedCmdMask & RMFP_ENABLE_COMMAND_IFORWARD))
				{
					pCommand->command = RMFP_Playback_command_IForward;
					pCommand->params.speed.N = 8;
					pCommand->params.speed.M = 1;
					m_RmfpMainContext.iframing = TRUE;
				}
				else
				{
					pCommand->command = RMFP_Playback_command_Play;
					pCommand->params.speed.N = 8;
					pCommand->params.speed.M = 1;
					m_RmfpMainContext.iframing = FALSE;
				}
				if(pMainContext->dh_info)
				{
					pMainContext->dh_info->CEC.DeckInfo = CEC_DeckInfo_SkipForwardWind;
				}
				if(pMainContext->pOptions->playback_options.accurate_seek)
				{
					eRMstatus = Rmfp_setRmlibplayPlaybackOpt_PrebufMax(pMainContext->pHandle, (1*1024*1024));
					if(RMFAILED(eRMstatus))
					{
						PRINT_BFILE_LINENO_RMSTATUS;
					}
				}
			}
			else if(MediaPlayer::PlayMode_Rewind == ePlayMode)
			{
				if((RM_OK == Rmfp_getAllowedCmdMask(m_RmfpMainContext.pHandle, &AllowedCmdMask)) &&
					(AllowedCmdMask & RMFP_ENABLE_COMMAND_IBACKWARD))
				{
					pCommand->command = RMFP_Playback_command_IBackward;
					m_RmfpMainContext.iframing = TRUE;
					pCommand->params.speed.N = -8;
					pCommand->params.speed.M = 1;
				}
				else
				{					
					if(Sw_LogPlaybackStatus)
					{
						LOG_BLINE("Not support IBackward\n");
					}
					GenMsgData_sp->m_iOutRet = ERROR_NOT_SUPPORTED;
				}
			}
			else
			{
				GenMsgData_sp->m_iOutRet = ERR_INVALID_CMD;
			}
		}
		else if(MSG_CMD_getPlayMode == GenMsgData_sp->m_uiMsgId)
		{
			GenMsgData_sp->m_iOutRet = ERROR_SUCCESS;
			GenMsgData_sp->m_uiParam = getCurPlayMode();
		}
		else if(MSG_CMD_setVideoPosition == GenMsgData_sp->m_uiMsgId)
		{
			//LOG_BLINE("MSG_CMD_setVideoPosition\n");
			GenMsgData_sp->m_iOutRet = On_setVideoPosition(TransactionMsg);
		}
		else if(MSG_CMD_setVideoInputWindowSize == GenMsgData_sp->m_uiMsgId)
		{
			GenMsgData_sp->m_iOutRet = On_setVideoInputWindowSize(TransactionMsg);
		}
		else if(MSG_CMD_ChangeVidOutMode == GenMsgData_sp->m_uiMsgId)
		{
			GenMsgData_sp->m_iOutRet = On_ChangeVidOutMode(TransactionMsg);
		}
		else if(MSG_CMD_setOutputSpdifMode == GenMsgData_sp->m_uiMsgId)
		{
			GenMsgData_sp->m_iOutRet = On_SetOutputSpdifMode(TransactionMsg);
		}
		else if(MSG_CMD_setPlaySpeedCtrl == GenMsgData_sp->m_uiMsgId)
		{									
			SharedPtr<CMsgData_setPlaySpeedCtrl> MsgData_setPlaySpeedCtrl_sp;
			MsgData_setPlaySpeedCtrl_sp = GenMsgData_sp.DynamicCast<CMsgData_setPlaySpeedCtrl>();
			if(MsgData_setPlaySpeedCtrl_sp.isNull())
			{
				PRINT_BFILE_LINENO_BUG_STR;
				GenMsgData_sp->m_iOutRet = ERR_INTERNAL_FAIL;
				break;
			}
			int iSpeed = MsgData_setPlaySpeedCtrl_sp->m_iSpeed;
			if(5 > iSpeed)
			{
				iSpeed = 5;
			}
			else if(250 < iSpeed)
			{
				iSpeed = 250;
			}
			pCommand->command = RMFP_Playback_command_Play;
			pCommand->params.speed.N = iSpeed;
			pCommand->params.speed.M = 5;
			m_RmfpMainContext.iframing = FALSE;
		}
		else if(MSG_CMD_getPlaySpeedCtrl == GenMsgData_sp->m_uiMsgId)
		{			
			GenMsgData_sp->m_iOutRet = On_getPlaySpeedCtrl(TransactionMsg);
		}
		else if(MSG_CMD_DispOnLedScr == GenMsgData_sp->m_uiMsgId)
		{			
			GenMsgData_sp->m_iOutRet = On_DispOnLedScr(TransactionMsg);
		}
		else if(MSG_CMD_SetTunerChannelMode == GenMsgData_sp->m_uiMsgId)
		{
			On_SetTunerChannelMode(GenMsgData_sp,TransactionMsg);
		}
		else if(MSG_CMD_GetTunerChannelMode == GenMsgData_sp->m_uiMsgId)
		{
			On_GetTunerChannelMode(GenMsgData_sp, TransactionMsg);
		}
		else if(MSG_CMD_setShowClosedCaption == GenMsgData_sp->m_uiMsgId)
		{
			GenMsgData_sp->m_iOutRet = On_setShowClosedCaption(TransactionMsg);
		}
		else if(MSG_CMD_setVideoRotation== GenMsgData_sp->m_uiMsgId)
		{
			GenMsgData_sp->m_iOutRet = On_setVideoRotation(TransactionMsg);
		}
		else if(MSG_CMD_setEnableAudio6Ch== GenMsgData_sp->m_uiMsgId)
		{
			GenMsgData_sp->m_iOutRet = On_setEnableAudio6Ch(TransactionMsg);
		}
		else if(MSG_CMD_getEnableAudio6Ch== GenMsgData_sp->m_uiMsgId)
		{
		    GenMsgData_sp->m_iOutRet = On_getEnableAudio6Ch(TransactionMsg);
		}
		else
		{
			GenMsgData_sp->m_iOutRet = ERR_INVALID_CMD;
			break;
		}
	}while(FALSE);

	return iOutRet;
}

INT_t CMediaSrv::TranslateToRmasciiKey(SharedPtr<CMessageQueueItem> & TransactionMsg, RMascii * pKey)
{
	INT_t iOutRet = ERROR_SUCCESS;
	SharedPtr<CGenericMsgData> GenMsgData_sp;

	do
	{
		if(pKey)
		{
			*pKey = 0;
		}

		GenMsgData_sp = TransactionMsg->GetMessageData();
		if(CC_UNLIKELY(GenMsgData_sp.isNull()))
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}

		if(MSG_CMD_Stop == GenMsgData_sp->m_uiMsgId)
		{
			if(pKey)
			{
				*pKey = KEY_COMMAND_STOP;
			}
		}
		else if(MSG_CMD_QuitPlay == GenMsgData_sp->m_uiMsgId)
		{
			m_bQuitPlay = TRUE;
			if(pKey)
			{
				*pKey = KEY_COMMAND_QUIT;
				m_bIsCompletePlaybackEos = FALSE;
			}
		}
		else if(MSG_CMD_setVideoPosition == GenMsgData_sp->m_uiMsgId)
		{
			//LOG_BLINE("MSG_CMD_setVideoPosition\n");
			GenMsgData_sp->m_iOutRet = On_setVideoPosition(TransactionMsg);
		}
		else if(MSG_CMD_setVideoInputWindowSize == GenMsgData_sp->m_uiMsgId)
		{
			GenMsgData_sp->m_iOutRet = On_setVideoInputWindowSize(TransactionMsg);
		}
		else if(MSG_CMD_ChangeVidOutMode == GenMsgData_sp->m_uiMsgId)
		{
			GenMsgData_sp->m_iOutRet = On_ChangeVidOutMode(TransactionMsg);
		}
		else if(MSG_CMD_setOutputSpdifMode == GenMsgData_sp->m_uiMsgId)
		{
			GenMsgData_sp->m_iOutRet = On_SetOutputSpdifMode(TransactionMsg);
		}
		else if(MSG_CMD_setPlaySpeedCtrl == GenMsgData_sp->m_uiMsgId)
		{			
			//GenMsgData_sp->m_iOutRet = On_setPlaySpeedCtrl(TransactionMsg);			
			GenMsgData_sp->m_iOutRet = ERROR_INVALID_STATE;
		}
		else if(MSG_CMD_getPlaySpeedCtrl == GenMsgData_sp->m_uiMsgId)
		{			
			GenMsgData_sp->m_iOutRet = On_getPlaySpeedCtrl(TransactionMsg);
		}
		else if(MSG_CMD_DispOnLedScr == GenMsgData_sp->m_uiMsgId)
		{			
			GenMsgData_sp->m_iOutRet = On_DispOnLedScr(TransactionMsg);
		}
		else if(MSG_CMD_getPlayMode == GenMsgData_sp->m_uiMsgId)
		{
			GenMsgData_sp->m_iOutRet = ERROR_SUCCESS;
			GenMsgData_sp->m_uiParam = getCurPlayMode();
		}
		else if(MSG_CMD_SetTunerChannelMode == GenMsgData_sp->m_uiMsgId)
		{
			On_SetTunerChannelMode(GenMsgData_sp,TransactionMsg);
		}
		else if(MSG_CMD_GetTunerChannelMode == GenMsgData_sp->m_uiMsgId)
		{
			On_GetTunerChannelMode(GenMsgData_sp, TransactionMsg);
		}
		else if(MSG_CMD_setShowClosedCaption == GenMsgData_sp->m_uiMsgId)
		{
			GenMsgData_sp->m_iOutRet = On_setShowClosedCaption(TransactionMsg);
		}
		else if(MSG_CMD_setVideoRotation== GenMsgData_sp->m_uiMsgId)
		{
			GenMsgData_sp->m_iOutRet = On_setVideoRotation(TransactionMsg);
		}
		else if(MSG_CMD_setEnableAudio6Ch== GenMsgData_sp->m_uiMsgId)
		{
			GenMsgData_sp->m_iOutRet = On_setEnableAudio6Ch(TransactionMsg);
		}
        else if(MSG_CMD_getEnableAudio6Ch== GenMsgData_sp->m_uiMsgId)
		{
			GenMsgData_sp->m_iOutRet = On_getEnableAudio6Ch(TransactionMsg);
		}
	}while(FALSE);

	return iOutRet;
}

INT_t CMediaSrv::setEventListener(WeakPtr <IMediaSrvEventListener> MediaSrvEvtListener_wp)
{
	INT_t iOutRet = ERROR_SUCCESS;
	CAutoLock AutoRangeLocker(&m_SharedDataMutex);
	
	m_MediaSrvEvtListener_wp = MediaSrvEvtListener_wp;		

	return iOutRet;
}

INT_t CMediaSrv::WakeupMainThread()
{
	INT_t iOutRet = ERROR_SUCCESS;
	DBusMessage * pDBusMsg = NULL;
	dbus_bool_t bDBusRet;

	do
	{
		if(NULL == m_pDBusConnMediaSrv)
		{
			iOutRet = ERROR_INVALID_STATE;
			break;
		}
		
		pDBusMsg = dbus_message_new_signal(DBUS_MPLAYER_OBJECT_PATH, DBUS_MPLAYER_OBJECT_INTERFACE, MP_SIGNAL_WakeupMainThread);
		if(NULL == pDBusMsg)
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}
		bDBusRet = dbus_connection_send(m_pDBusConnMediaSrv, pDBusMsg, NULL);
		if(FALSE == bDBusRet)
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}
		dbus_connection_flush(m_pDBusConnMediaSrv);
	}while(FALSE);

	if(pDBusMsg)
	{
		dbus_message_unref(pDBusMsg);
		pDBusMsg = NULL;
	}

	return ERROR_SUCCESS;
}

INT_t CMediaSrv::EmitVidOutModeChangedEvent(VIDEO_OUTPUT_MODE eCurMode)
{
	INT_t iOutRet = ERROR_SUCCESS;
	DBusMessage * pDBusMsg = NULL;
	dbus_bool_t bDBusRet;
	SharedPtr <CDBusParameterList> DBusOutParamList_sp(new CDBusParameterList);

	do
	{
		if(CC_UNLIKELY(NULL == m_pDBusConnMediaSrv))
		{
			iOutRet = ERROR_INVALID_STATE;
			break;
		}

		if(CC_UNLIKELY(DBusOutParamList_sp.isNull()))
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}
		
		pDBusMsg = dbus_message_new_signal(DBUS_MPLAYER_OBJECT_PATH, DBUS_MPLAYER_OBJECT_INTERFACE, MP_SIGNAL_VidOutModeChanged);
		if(NULL == pDBusMsg)
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}

		(*DBusOutParamList_sp) << eCurMode;

#ifdef	__EXCEPTIONS
		try
#endif	//__EXCEPTIONS
		{
			(*DBusOutParamList_sp) >> pDBusMsg;
		}
#ifdef	__EXCEPTIONS
		catch(CInvArgException & InvArgEx)
		{
			iOutRet = ERROR_INVALID_PARAMETER;
			break;
		}
		catch(CBaseErrException & BaseErrEx)
		{
			iOutRet = BaseErrEx.getBaseErr();
			break;
		}
		catch(...)
		{
			LOG_BLINE("BUG,uncaught exception\n");
		}
#endif	//__EXCEPTIONS

		bDBusRet = dbus_connection_send(m_pDBusConnMediaSrv, pDBusMsg, NULL);
		if(FALSE == bDBusRet)
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}
		dbus_connection_flush(m_pDBusConnMediaSrv);
	}while(FALSE);

	if(pDBusMsg)
	{
		dbus_message_unref(pDBusMsg);
		pDBusMsg = NULL;
	}

	return ERROR_SUCCESS;
}

VOID CMediaSrv::DBusConnWakeUp_ClearMsg()
{
 	dbus_bool_t bDBusRet;
	DBusMessage * pDBusMsg = NULL;

	do
	{
		bDBusRet = dbus_connection_read_write(m_pDBusConnMediaSrv, 0);
		if(FALSE == bDBusRet)	//the connection is closed
		{
			LOG_BLINE("DBusConnMediaSrv disconnect\n");
			break;
		}

		while(TRUE)
		{
			pDBusMsg = dbus_connection_pop_message(m_pDBusConnMediaSrv);
			if(pDBusMsg)
			{
				/*
				LOG_BLINE("dbus_message,type:%d,path:%s,interface:%s,member:%s,errorname:%s,destination:%s,sender:%s\n", 
					dbus_message_get_type(pDBusMsg), dbus_message_get_path(pDBusMsg),
					dbus_message_get_interface(pDBusMsg), dbus_message_get_member(pDBusMsg),
					dbus_message_get_error_name(pDBusMsg),	dbus_message_get_destination(pDBusMsg),
					dbus_message_get_sender(pDBusMsg));
				/*/
 				dbus_message_unref(pDBusMsg);
				pDBusMsg = NULL;
			}
			else	//no more data
			{
				break;
			}
		}
	}while(FALSE);
}

INT_t CMediaSrv::ProcessDBusMsg(DBusMessage * pDBusMsg)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	DBusError DBusErr;
	const char * pszInterfaceName = NULL;
		
	do
	{
		pszInterfaceName = dbus_message_get_interface(pDBusMsg);
		if(0 == strcmp(DBUS_INTERFACE_DBUS, pszInterfaceName))
		{
			iRet = ProcessDBusMsg_DBusDBusIfCall(pDBusMsg);
			if(ERROR_SUCCESS != iRet)
			{
				iOutRet = iRet;
			}
		}
		else
		{
			BOOL_t bFlush = TRUE;
			iOutRet = CDBusMessage::SendErrReply(m_pDBusConnMediaSrv, pDBusMsg, 
				DBUS_ERROR_UNKNOWN_INTERFACE, "Unsupported interface call", bFlush);
		}
	}while(FALSE);

	return iOutRet;
}

INT_t CMediaSrv::ProcessDBusMsg_DBusDBusIfCall(DBusMessage * pDBusMsg)
{
	INT_t iOutRet = ERROR_SUCCESS;
	DBusError DBusErr;
	dbus_bool_t bDBusRet;
	int DBusMsgType;
	const char * pszMethodame = NULL;

	do
	{
		DBusMsgType = dbus_message_get_type(pDBusMsg);
		if(DBUS_MESSAGE_TYPE_SIGNAL == DBusMsgType)
		{
			const char * pszMethodame = NULL;
			pszMethodame = dbus_message_get_member(pDBusMsg);
			if(NULL == pszMethodame)
			{
				pszMethodame = "";
			}
			if(0 == strcmp("NameOwnerChanged", pszMethodame))
			{
				/*
				const char *pszArg0 = NULL, *pszArg1 = NULL, *pszArg2 = NULL;
				dbus_error_init(&DBusErr);
				bDBusRet =  dbus_message_get_args(pDBusMsg, &DBusErr, DBUS_TYPE_STRING, &pszArg0,
					DBUS_TYPE_STRING, &pszArg0, DBUS_TYPE_STRING, &pszArg1, DBUS_TYPE_STRING, &pszArg2,
					DBUS_TYPE_INVALID);
				if(false == bDBusRet)
				{
					if (dbus_error_is_set(&DBusErr)) 
					{
						dbus_error_free(&err);
					}
					//LOG_BLINE("can't get dbus_msg args\n");
				}
				//LOG_BLINE("DBUS_MESSAGE_TYPE_SIGNAL,%s,Args:%s,%s,%s\n", pszMethodame, pszArg0, pszArg1, pszArg2);
				*/
			}
			else if(0 == strcmp("NameAcquired", pszMethodame))
			{
			}
			else
			{
				LOG_BLINE("DBUS_MESSAGE_TYPE_SIGNAL,%s\n", pszMethodame);				
			}
		}
		else if(DBUS_MESSAGE_TYPE_METHOD_CALL == DBusMsgType)
		{
			iOutRet = On_DBusIf_Call(pDBusMsg);
		}
		else
		{
			LOG_BLINE("DBusMsgType=%d\n", DBusMsgType);
		}
	}while(FALSE);

	return iOutRet;
}

INT_t CMediaSrv::On_DBusIf_Call(DBusMessage * pDBusMsg)
{
	INT_t iOutRet = ERROR_SUCCESS;
	BOOL_t bFlush = TRUE;

	iOutRet = CDBusMessage::SendErrReply(m_pDBusConnMediaSrv, pDBusMsg, 
		DBUS_ERROR_UNKNOWN_METHOD, "Unsupported method call", bFlush);

	return iOutRet;
}

RMstatus CMediaSrv::getVolumeLevel(RMuint32 * pVolumeLevel)
{
	RMstatus eOutRMstatus = RM_OK, eRMstatus = RM_OK;
	RMuint32 uiAudioEngineModuleId = 0;
	RMbool bGetVolume;

	do
	{
		if(NULL == pVolumeLevel)
		{
			break;
		}
		
		bGetVolume = false;
		for (int iAudEngId = 0; iAudEngId < MAX_AUDIO_ENGINE_INSTANCES; iAudEngId++)
		{
			struct AudioEngine_QueryVolume_in_type AudEngQVolIn;
			struct AudioEngine_QueryVolume_out_type AudEngQVolOut;
			RMuint32 uiAudioChannelId = 0;

			uiAudioEngineModuleId = EMHWLIB_MODULE(AudioEngine, iAudEngId);;
			RMMemset(&AudEngQVolIn, 0x00, sizeof(AudEngQVolIn));
	
			for (uiAudioChannelId = 0; uiAudioChannelId < AUD_ENG_AUD_CH_CNT; uiAudioChannelId++)
			{
				AudEngQVolIn.Channel = uiAudioChannelId;
				eRMstatus = RUAExchangeProperty(m_RmfpMainContext.pRUA, uiAudioEngineModuleId, 
					RMAudioEnginePropertyID_QueryVolume, &AudEngQVolIn, sizeof(AudEngQVolIn),
					&AudEngQVolOut, sizeof(AudEngQVolOut));
				if(RMSUCCEEDED(eRMstatus))
				{					
					*pVolumeLevel = AudEngQVolOut.Volume;
					bGetVolume = true;
					break;
				}
				else
				{
					eOutRMstatus = eRMstatus;
					LOG_BLINE("err %s", RMstatusToString(eRMstatus));
				}
			}

			if(bGetVolume)
			{
				eOutRMstatus = RM_OK;
				break;
			}
		}
	}while(FALSE);

	return eOutRMstatus;
}

RMstatus CMediaSrv::setVolumeLevel(RMuint32 VolumeLevel)
{
	RMstatus eOutRMstatus = RM_OK, eRMstatus = RM_OK;
	RMuint32 uiAudioEngineModuleId = 0;

	do
	{
		for (int iAudEngId = 0; iAudEngId < MAX_AUDIO_ENGINE_INSTANCES; iAudEngId++)
		{
			struct AudioEngine_Volume_type AudEngVolParaIn;

			uiAudioEngineModuleId = EMHWLIB_MODULE(AudioEngine, iAudEngId);;
			RMMemset(&AudEngVolParaIn, 0x00, sizeof(AudEngVolParaIn));
	
			for (AudEngVolParaIn.Channel = 0; AudEngVolParaIn.Channel < AUD_ENG_AUD_CH_CNT; AudEngVolParaIn.Channel++)
			{
				AudEngVolParaIn.Volume = VolumeLevel;
				eRMstatus = RUASetProperty(m_RmfpMainContext.pRUA, uiAudioEngineModuleId, 
					RMAudioEnginePropertyID_Volume, &AudEngVolParaIn, sizeof(AudEngVolParaIn), 0);
				if (CC_UNLIKELY(RMFAILED(eRMstatus)))
				{
					LOG_BLINE("SetAudVol,err %s", RMstatusToString(eRMstatus));
				}
			}
		}
	}while(FALSE);

	return eOutRMstatus;
}

RMbool CMediaSrv::RMKeyAvailable(INT_t TimeoutUs)
{
	INT_t iRet;
	RMbool bOutRet = FALSE;

	do
	{
		if(m_bQuitPlay)
		{
			bOutRet = TRUE;
			break;
		}

		//LOG_BLINE("TimeoutUs=%d\n", TimeoutUs);
		iRet = WaitMessageTimeout(TimeoutUs/1000);
		//PRINT_BFILE_LINENO_NEWLINE;
		if(CC_LIKELY(ERROR_SUCCESS == iRet))
		{
			bOutRet = TRUE;
			break;
		}
		else if(CC_LIKELY(ERR_TIMEOUT == iRet))
		{
			break;
		}
		else if(CC_LIKELY(ERR_LINUX_SIGNAL_INT == iRet))
		{
			break;
		}
		else
		{
			PRINT_BFILE_LINENO_IRET_CRT_ERR;
			break;
		}
	}while(FALSE);

	return bOutRet;
}

RMascii CMediaSrv::RMGetKey()
{
	RMascii OutKey = 0;
	INT_t iRet;
	SharedPtr<CMessageQueueItem> MsgItem_sp;

	do
	{
		if(m_bQuitPlay)
		{
			OutKey = KEY_COMMAND_QUIT;
			m_bIsCompletePlaybackEos = FALSE;
			break;
		}

		iRet = GetMessageTimeout(MsgItem_sp, (2*1000));
		if(CC_LIKELY(ERROR_SUCCESS == iRet))
		{
			if(MsgItem_sp.isValid())
			{
				iRet = TranslateToRmasciiKey(MsgItem_sp, &OutKey);
				if(ERROR_SUCCESS != iRet)
				{
					OutKey = 0;
				}
				iRet = MsgItem_sp->SetEvent();
				if(ERROR_SUCCESS != iRet)
				{
					PRINT_BFILE_LINENO_IRET_STR;
				}
				MsgItem_sp.Release();
			}
			break;
		}
		else if(CC_LIKELY(ERR_TIMEOUT == iRet))
		{
			OutKey = 0;
			break;
		}
		else if(CC_LIKELY(ERR_LINUX_SIGNAL_INT == iRet))
		{
			OutKey = 0;
			break;
		}
		else
		{
			PRINT_BFILE_LINENO_IRET_CRT_ERR;
			OutKey = 0;
			break;
		}
	}while(FALSE);

	return OutKey;
}

INT_t CMediaSrv::setHwRtcTime(P_SET_TIME_IN_PARAM pSetTimeInParam)
{
	INT_t iOutRet = ERROR_SUCCESS;
	RMstatus eRMstatus;
	CRtcISL1208 RtcAccessor;
	GET_TIME_OUT_PARAM getTimeOutParam;

	CAutoLock AutoRangeLocker(&m_mutexVideoAudioIoSet);

	do
	{
		eRMstatus = RtcAccessor.setTime(m_RmfpMainContext.pRUA, pSetTimeInParam);
		if(RMFAILED(eRMstatus))
		{
			iOutRet = ERR_SETUP_FAIL;
			break;
		}

		ZeroMemory(&getTimeOutParam, sizeof(getTimeOutParam));
		eRMstatus = RtcAccessor.getTime(m_RmfpMainContext.pRUA, &getTimeOutParam);
		if(RMSUCCEEDED(eRMstatus))
		{
			/*
			LOG_BLINE("Year:%d,Month:%d,Day:%d,Hour:%d,Minute:%d,Second:%d\n", getTimeOutParam.uiYear, 
				getTimeOutParam.uiMonth, getTimeOutParam.uiDay, getTimeOutParam.uiHour,
				getTimeOutParam.uiMinute, getTimeOutParam.uiSecond);
			*/
		}
		else
		{
			PRINT_BFILE_LINENO_RMSTATUS;
		}		
	}while(FALSE);

	return iOutRet;
}

INT_t CMediaSrv::setGpioLedStatus(CONST UINT32_t GpioLedStatusToSet, OUT UINT32_t & ActualLedStatus)
{
	INT_t iOutRet = ERROR_SUCCESS;
	RMstatus eRMstatus = RM_OK;
	RMuint8 OldGpioStatus, NewGpioStatus;

	CAutoLock AutoRangeLocker(&m_mutexVideoAudioIoSet);
	ActualLedStatus = 0x00000000;

	do
	{				
		if(0 == (GpioLedStatusToSet & 0x00FF0000))	//no need to set
		{
			break;
		}

		//Read the origin status of OLATB
		m_oI2cReadInParam.UseSubAddr = TRUE;
		m_oI2cReadInParam.SubAddr = RegAddr_OLATB;
		eRMstatus = RUAExchangeProperty(m_RmfpMainContext.pRUA, m_uiI2CModuleId, RMI2CPropertyID_Read,
			&m_oI2cReadInParam, sizeof(m_oI2cReadInParam), &m_oI2cReadOutParam, sizeof(m_oI2cReadOutParam));
		if(RMSUCCEEDED(eRMstatus))
		{
			OldGpioStatus = m_oI2cReadOutParam.Data;
		}
		else
		{
			iOutRet = ERROR_I2C_READ_FAIL;
			break;
		}

		//Write the new LED status
		NewGpioStatus = (OldGpioStatus & (~(OldGpioStatus & (GpioLedStatusToSet >> 16))));
		NewGpioStatus |= (GpioLedStatusToSet & (GpioLedStatusToSet >> 16));
		m_oI2cSendParam.UseSubAddr = TRUE;
		m_oI2cSendParam.SubAddr = RegAddr_GPIOB;
		m_oI2cSendParam.Data = NewGpioStatus;
		eRMstatus = RUASetProperty(m_RmfpMainContext.pRUA, m_uiI2CModuleId, RMI2CPropertyID_Send, &m_oI2cSendParam,
			sizeof(m_oI2cSendParam), 0);
		if(RMSUCCEEDED(eRMstatus))
		{
		}
		else
		{
			iOutRet = ERROR_I2C_WRITE_FAIL;
			break;
		}
		
	}while(FALSE);

	if(ERROR_SUCCESS == iOutRet)
	{
		//Read the status of OLATB
		m_oI2cReadInParam.UseSubAddr = TRUE;
		m_oI2cReadInParam.SubAddr = RegAddr_OLATB;
		eRMstatus = RUAExchangeProperty(m_RmfpMainContext.pRUA, m_uiI2CModuleId, RMI2CPropertyID_Read,
			&m_oI2cReadInParam, sizeof(m_oI2cReadInParam), &m_oI2cReadOutParam, sizeof(m_oI2cReadOutParam));
		if(RMSUCCEEDED(eRMstatus))
		{
			ActualLedStatus = (0x00FF0000 | m_oI2cReadOutParam.Data);
		}
		else
		{
			iOutRet = ERROR_I2C_READ_FAIL;
		}
	}
	
	return iOutRet;
}

/*
ThreadContext: any
*/
INT_t CMediaSrv::DisplayOnLedScreen(LPCSTR strContentToDisp, CONST INT_t StartPosToDisp)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;

	do
	{
		if(NULL == strContentToDisp)
		{
			break;
		}

		iRet = m_CnkB85LcmLedScr_sp->DisplayStr(strContentToDisp, StartPosToDisp);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}
	}while(FALSE);

	return iOutRet;
}

/*
ThreadContext: Other
*/
INT_t CMediaSrv::DispOnLedScrAsync(LPCSTR strContentToDisp, CONST INT_t StartPosToDisp)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	SharedPtr <CMsgData_DispOnLedScr> MsgData_DispOnLedScr_sp(new CMsgData_DispOnLedScr);
	SharedPtr<CMessageQueueItem> ThreadMsg_sp(new CMessageQueueItem);
	SharedPtr <CGenericMsgData> MsgData_sp;

	do
	{
		if(CC_UNLIKELY(NULL == strContentToDisp))
		{
			break;
		}

		if(MsgData_DispOnLedScr_sp.isNull() || ThreadMsg_sp.isNull())
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}

		MsgData_DispOnLedScr_sp->m_uiMsgId = MSG_CMD_DispOnLedScr;
		MsgData_DispOnLedScr_sp->m_strDispContent = strContentToDisp;
		MsgData_DispOnLedScr_sp->m_StartPosToDisp = StartPosToDisp;
		MsgData_sp = MsgData_DispOnLedScr_sp;
		iRet = ThreadMsg_sp->SetMessageData(MsgData_sp);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}
		iRet = PostMessage(ThreadMsg_sp);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}		
	}while(FALSE);

	return iOutRet;
}

INT_t CMediaSrv::getMonitorInfo(OUT CString & strMonitorType)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	DECLARE_CLS_STACK_BUF_STRING(strTmpMonitorType, 128);
	struct rmfp_main_thread_context_type *pMainContext = &m_RmfpMainContext;	

	CAutoLock AutoRangeLocker(&m_SharedDataMutex);

	do
	{
		if(NULL == pMainContext->dh_info->hdmi)
		{
			iOutRet = ERROR_INVALID_STATE;
			break;
		}

		pMainContext->dh_info->hdmi->EDIDBlock0.ManufacturerName[sizeof(pMainContext->dh_info->hdmi->EDIDBlock0.ManufacturerName)-1] = '\0';
		pMainContext->dh_info->hdmi->MonitorName[sizeof(pMainContext->dh_info->hdmi->MonitorName)-1] = '\0';		

		iRet = strTmpMonitorType.Format("%s,%04x,%s", pMainContext->dh_info->hdmi->EDIDBlock0.ManufacturerName,
			*((UINT16_t *)(pMainContext->dh_info->hdmi->EDIDBlock0.ProductCode)),
			pMainContext->dh_info->hdmi->MonitorName);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}
		strMonitorType = strTmpMonitorType;
	}while(FALSE);

	return iOutRet;
}

INT_t CMediaSrv::setPlayMode(MediaPlayer::PlayMode ePlayMode)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	SharedPtr<CMessageQueueItem> ThreadMsg_sp(new CMessageQueueItem);
	SharedPtr <CGenericMsgData> MsgData_sp;

	do
	{
		if(ThreadMsg_sp.isNull())
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}
		MsgData_sp = SharedPtr <CGenericMsgData> (new CGenericMsgData);
		if(MsgData_sp.isNull())
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}
		
		MsgData_sp->m_uiMsgId = MSG_CMD_setPlayMode;
		if(MediaPlayer::PlayMode_Normal == ePlayMode)
		{
			MsgData_sp->m_uiParam = ePlayMode;
		}
		else if(MediaPlayer::PlayMode_Pause == ePlayMode)
		{
			MsgData_sp->m_uiParam = ePlayMode;
		}
		else if(MediaPlayer::PlayMode_FastForward == ePlayMode)
		{
			MsgData_sp->m_uiParam = ePlayMode;
		}
		else if(MediaPlayer::PlayMode_Rewind == ePlayMode)
		{
			MsgData_sp->m_uiParam = ePlayMode;
		}
		else
		{
			iOutRet = ERROR_INVALID_PARAMETER;
			break;
		}
		iRet = ThreadMsg_sp->SetMessageData(MsgData_sp);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}

		iRet = SendMessage(ThreadMsg_sp);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}
		iOutRet = MsgData_sp->m_iOutRet;
	}while(FALSE);

	return iOutRet;
}

/*
ThreadContext: Other thread
*/
INT_t CMediaSrv::getPlayMode(OUT MediaPlayer::PlayMode & ePlayMode)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	SharedPtr<CMessageQueueItem> ThreadMsg_sp(new CMessageQueueItem);
	SharedPtr <CGenericMsgData> MsgData_sp;

	do
	{
		if(ThreadMsg_sp.isNull())
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}
		MsgData_sp = SharedPtr <CGenericMsgData> (new CGenericMsgData);
		if(MsgData_sp.isNull())
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}
		
		MsgData_sp->m_uiMsgId = MSG_CMD_getPlayMode;
		iRet = ThreadMsg_sp->SetMessageData(MsgData_sp);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}

		iRet = SendMessage(ThreadMsg_sp);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}
		iOutRet = MsgData_sp->m_iOutRet;
		ePlayMode = (typeof(ePlayMode))(MsgData_sp->m_uiParam);
		//LOG_BLINE("CurPlayMode=%d\n", ePlayMode);	
	}while(FALSE);

	return iOutRet;
}

/*
ThreadContext: any thread
*/
INT_t CMediaSrv::setDisplayParam(DISP_PARAM_TYPE eDispParamType, INT_t iValue)
{
	INT_t iOutRet = ERROR_SUCCESS;
	RMstatus eRMstatus = RM_OK;
	RMuint8 HwValue;
	RMuint16 Smp8xxxChipId;
	RMuint32 TryIntervalMsIfPending = 30;
	RMuint32 RetryTimesIfPending = 5;

	CAutoLock AutoRangeLocker(&m_mutexVideoAudioIoSet);

	do
	{
		if(0 > iValue)
		{
			iValue = 0;
		}
		else if(100 < iValue)
		{
			iValue = 100;
		}

		Smp8xxxChipId = m_Smp8xxxChipInfo_sp->getChipId();
		
		if(DispPARAM_Brightness == eDispParamType)
		{
			//Percent value -> Hw value
			HwValue = ((255 * iValue + (100 - 1)) / 100) - 128;
			//LOG_BLINE("HwVal:%u(0x%02x)\n", HwValue, HwValue);
			//Set
			eRMstatus = RuaSetProp5(m_RmfpMainContext.pRUA, DispDigitalOut, RMGenericPropertyID_Brightness,
				&HwValue, sizeof(HwValue), RetryTimesIfPending, TryIntervalMsIfPending);
			if(RMFAILED(eRMstatus))
			{
				//PRINT_BFILE_LINENO_RMSTATUS;
				iOutRet = ERR_RUA_SET_PROP_FAIL;
				break;
			}			
			eRMstatus = RuaSetProp5(m_RmfpMainContext.pRUA, DispMainAnalogOut, RMGenericPropertyID_Brightness,
				&HwValue, sizeof(HwValue), RetryTimesIfPending, TryIntervalMsIfPending);
			if(RMFAILED(eRMstatus))
			{
				//PRINT_BFILE_LINENO_RMSTATUS;
				iOutRet = ERR_RUA_SET_PROP_FAIL;
				break;
			}			
			eRMstatus = RuaSetProp5(m_RmfpMainContext.pRUA, DispComponentOut, RMGenericPropertyID_Brightness,
				&HwValue, sizeof(HwValue), RetryTimesIfPending, TryIntervalMsIfPending);
			if(RMFAILED(eRMstatus))
			{
				//PRINT_BFILE_LINENO_RMSTATUS;
				iOutRet = ERR_RUA_SET_PROP_FAIL;
				break;
			}
			if(0x8670 == Smp8xxxChipId || 0x8671 == Smp8xxxChipId || 0x8672 == Smp8xxxChipId || 0x8673 == Smp8xxxChipId ||
				0x8652 == Smp8xxxChipId || 0x8653 == Smp8xxxChipId ||
				0x8654 == Smp8xxxChipId || 0x8655 == Smp8xxxChipId)
			{
			}
			else
			{
				eRMstatus = RuaSetProp5(m_RmfpMainContext.pRUA, DispCompositeOut, RMGenericPropertyID_Brightness,
					&HwValue, sizeof(HwValue), RetryTimesIfPending, TryIntervalMsIfPending);
				if(RMFAILED(eRMstatus))
				{
					//PRINT_BFILE_LINENO_RMSTATUS;
					iOutRet = ERR_RUA_SET_PROP_FAIL;
					break;
				}
			}
		}
		else if(DispPARAM_Contrast == eDispParamType)
		{
			//Percent value -> Hw value
			HwValue = ((255 * iValue + (100 - 1)) / 100);
			//LOG_BLINE("HwVal:%u(0x%02x)\n", HwValue, HwValue);
			//Set the value
			eRMstatus = RuaSetProp5(m_RmfpMainContext.pRUA, DispDigitalOut, RMGenericPropertyID_Contrast,
				&HwValue, sizeof(HwValue), RetryTimesIfPending, TryIntervalMsIfPending);
			if(RMFAILED(eRMstatus))
			{
				iOutRet = ERR_RUA_SET_PROP_FAIL;
				break;
			}			
			eRMstatus = RuaSetProp5(m_RmfpMainContext.pRUA, DispMainAnalogOut, RMGenericPropertyID_Contrast,
				&HwValue, sizeof(HwValue), RetryTimesIfPending, TryIntervalMsIfPending);
			if(RMFAILED(eRMstatus))
			{
				iOutRet = ERR_RUA_SET_PROP_FAIL;
				break;
			}			
			eRMstatus = RuaSetProp5(m_RmfpMainContext.pRUA, DispComponentOut, RMGenericPropertyID_Contrast,
				&HwValue, sizeof(HwValue), RetryTimesIfPending, TryIntervalMsIfPending);
			if(RMFAILED(eRMstatus))
			{
				iOutRet = ERR_RUA_SET_PROP_FAIL;
				break;
			}			
			if(0x8670 == Smp8xxxChipId || 0x8671 == Smp8xxxChipId || 0x8672 == Smp8xxxChipId || 0x8673 == Smp8xxxChipId ||
				0x8652 == Smp8xxxChipId || 0x8653 == Smp8xxxChipId ||
				0x8654 == Smp8xxxChipId || 0x8655 == Smp8xxxChipId)
			{
			}
			else
			{
				eRMstatus = RuaSetProp5(m_RmfpMainContext.pRUA, DispCompositeOut, RMGenericPropertyID_Contrast,
					&HwValue, sizeof(HwValue), RetryTimesIfPending, TryIntervalMsIfPending);
				if(RMFAILED(eRMstatus))
				{
					iOutRet = ERR_RUA_SET_PROP_FAIL;
					break;
				}			
			}
		}
		else if(DispPARAM_Saturation == eDispParamType)
		{
			//Percent value -> Hw value
			HwValue = ((255 * iValue + (100 - 1)) / 100);
			//LOG_BLINE("HwVal:%u(0x%02x)\n", HwValue, HwValue);
			//Cb
			eRMstatus = RuaSetProp5(m_RmfpMainContext.pRUA, DispDigitalOut, RMGenericPropertyID_CbSaturation,
				&HwValue, sizeof(HwValue), RetryTimesIfPending, TryIntervalMsIfPending);
			if(RMFAILED(eRMstatus))
			{
				iOutRet = ERR_RUA_SET_PROP_FAIL;
				break;
			}			
			eRMstatus = RuaSetProp5(m_RmfpMainContext.pRUA, DispMainAnalogOut, RMGenericPropertyID_CbSaturation,
				&HwValue, sizeof(HwValue), RetryTimesIfPending, TryIntervalMsIfPending);
			if(RMFAILED(eRMstatus))
			{
				iOutRet = ERR_RUA_SET_PROP_FAIL;
				break;
			}			
			eRMstatus = RuaSetProp5(m_RmfpMainContext.pRUA, DispComponentOut, RMGenericPropertyID_CbSaturation,
				&HwValue, sizeof(HwValue), RetryTimesIfPending, TryIntervalMsIfPending);
			if(RMFAILED(eRMstatus))
			{
				iOutRet = ERR_RUA_SET_PROP_FAIL;
				break;
			}			
			if(0x8670 == Smp8xxxChipId || 0x8671 == Smp8xxxChipId || 0x8672 == Smp8xxxChipId || 0x8673 == Smp8xxxChipId ||
				0x8652 == Smp8xxxChipId || 0x8653 == Smp8xxxChipId ||
				0x8654 == Smp8xxxChipId || 0x8655 == Smp8xxxChipId)
			{
			}
			else
			{
				eRMstatus = RuaSetProp5(m_RmfpMainContext.pRUA, DispCompositeOut, RMGenericPropertyID_CbSaturation,
					&HwValue, sizeof(HwValue), RetryTimesIfPending, TryIntervalMsIfPending);
				if(RMFAILED(eRMstatus))
				{
					iOutRet = ERR_RUA_SET_PROP_FAIL;
					break;
				}		
			}
			//Cr
			eRMstatus = RuaSetProp5(m_RmfpMainContext.pRUA, DispDigitalOut, RMGenericPropertyID_CrSaturation,
				&HwValue, sizeof(HwValue), RetryTimesIfPending, TryIntervalMsIfPending);
			if(RMFAILED(eRMstatus))
			{
				iOutRet = ERR_RUA_SET_PROP_FAIL;
				break;
			}			
			eRMstatus = RuaSetProp5(m_RmfpMainContext.pRUA, DispMainAnalogOut, RMGenericPropertyID_CrSaturation,
				&HwValue, sizeof(HwValue), RetryTimesIfPending, TryIntervalMsIfPending);
			if(RMFAILED(eRMstatus))
			{
				iOutRet = ERR_RUA_SET_PROP_FAIL;
				break;
			}			
			eRMstatus = RuaSetProp5(m_RmfpMainContext.pRUA, DispComponentOut, RMGenericPropertyID_CrSaturation,
				&HwValue, sizeof(HwValue), RetryTimesIfPending, TryIntervalMsIfPending);
			if(RMFAILED(eRMstatus))
			{
				iOutRet = ERR_RUA_SET_PROP_FAIL;
				break;
			}			
			if(0x8670 == Smp8xxxChipId || 0x8671 == Smp8xxxChipId || 0x8672 == Smp8xxxChipId || 0x8673 == Smp8xxxChipId ||
				0x8652 == Smp8xxxChipId || 0x8653 == Smp8xxxChipId ||
				0x8654 == Smp8xxxChipId || 0x8655 == Smp8xxxChipId)
			{
			}
			else
			{
				eRMstatus = RuaSetProp5(m_RmfpMainContext.pRUA, DispCompositeOut, RMGenericPropertyID_CrSaturation,
					&HwValue, sizeof(HwValue), RetryTimesIfPending, TryIntervalMsIfPending);
				if(RMFAILED(eRMstatus))
				{
					iOutRet = ERR_RUA_SET_PROP_FAIL;
					break;
				}		
			}
		}
		else if(DispPARAM_Hue == eDispParamType)
		{
			//Percent value -> Hw value
			HwValue = ((128 * iValue + (100 - 1)) / 100) - 64;
			//LOG_BLINE("HwVal:%u(0x%02x)\n", HwValue, HwValue);
			//Set the value
			eRMstatus = RuaSetProp5(m_RmfpMainContext.pRUA, DispDigitalOut, RMGenericPropertyID_Hue,
				&HwValue, sizeof(HwValue), RetryTimesIfPending, TryIntervalMsIfPending);
			if(RMFAILED(eRMstatus))
			{
				iOutRet = ERR_RUA_SET_PROP_FAIL;
				break;
			}			
			eRMstatus = RuaSetProp5(m_RmfpMainContext.pRUA, DispMainAnalogOut, RMGenericPropertyID_Hue,
				&HwValue, sizeof(HwValue), RetryTimesIfPending, TryIntervalMsIfPending);
			if(RMFAILED(eRMstatus))
			{
				iOutRet = ERR_RUA_SET_PROP_FAIL;
				break;
			}			
			eRMstatus = RuaSetProp5(m_RmfpMainContext.pRUA, DispComponentOut, RMGenericPropertyID_Hue,
				&HwValue, sizeof(HwValue), RetryTimesIfPending, TryIntervalMsIfPending);
			if(RMFAILED(eRMstatus))
			{
				iOutRet = ERR_RUA_SET_PROP_FAIL;
				break;
			}			
			if(0x8670 == Smp8xxxChipId || 0x8671 == Smp8xxxChipId || 0x8672 == Smp8xxxChipId || 0x8673 == Smp8xxxChipId ||
				0x8652 == Smp8xxxChipId || 0x8653 == Smp8xxxChipId ||
				0x8654 == Smp8xxxChipId || 0x8655 == Smp8xxxChipId)
			{
			}
			else
			{
				eRMstatus = RuaSetProp5(m_RmfpMainContext.pRUA, DispCompositeOut, RMGenericPropertyID_Hue,
					&HwValue, sizeof(HwValue), RetryTimesIfPending, TryIntervalMsIfPending);
				if(RMFAILED(eRMstatus))
				{
					iOutRet = ERR_RUA_SET_PROP_FAIL;
					break;
				}			
			}
		}
		else
		{
			iOutRet = ERROR_INVALID_PARAMETER;
			break;
		}
		
		eRMstatus = RuaSetProp5(m_RmfpMainContext.pRUA, DispDigitalOut, RMGenericPropertyID_Validate,
			NULL, 0, RetryTimesIfPending, TryIntervalMsIfPending);
		if(RMFAILED(eRMstatus))
		{
			iOutRet = ERR_RUA_SET_VALIDATE_FAIL;
			break;
		}			
		eRMstatus = RuaSetProp5(m_RmfpMainContext.pRUA, DispMainAnalogOut, RMGenericPropertyID_Validate,
			NULL, 0, RetryTimesIfPending, TryIntervalMsIfPending);
		if(RMFAILED(eRMstatus))
		{
			iOutRet = ERR_RUA_SET_VALIDATE_FAIL;
			break;
		}			
		eRMstatus = RuaSetProp5(m_RmfpMainContext.pRUA, DispComponentOut, RMGenericPropertyID_Validate,
			NULL, 0, RetryTimesIfPending, TryIntervalMsIfPending);
		if(RMFAILED(eRMstatus))
		{
			iOutRet = ERR_RUA_SET_VALIDATE_FAIL;
			break;
		}			
		if(0x8670 == Smp8xxxChipId || 0x8671 == Smp8xxxChipId || 0x8672 == Smp8xxxChipId || 0x8673 == Smp8xxxChipId ||
			0x8652 == Smp8xxxChipId || 0x8653 == Smp8xxxChipId ||
			0x8654 == Smp8xxxChipId || 0x8655 == Smp8xxxChipId)
		{
		}
		else
		{
			eRMstatus = RuaSetProp5(m_RmfpMainContext.pRUA, DispCompositeOut, RMGenericPropertyID_Validate,
				NULL, 0, RetryTimesIfPending, TryIntervalMsIfPending);
			if(RMFAILED(eRMstatus))
			{
				iOutRet = ERR_RUA_SET_VALIDATE_FAIL;
				break;
			}
		}
	}while(FALSE);
	
	return iOutRet;
}

INT_t CMediaSrv::getDisplayParam(DISP_PARAM_TYPE eDispParamType, OUT INT_t & iValue)
{
	INT_t iOutRet = ERROR_SUCCESS;
	RMstatus eRMstatus = RM_OK;
	RMuint8 HwValue;
	RMuint16 Smp8xxxChipId;

	CAutoLock AutoRangeLocker(&m_mutexVideoAudioIoSet);

	do
	{
		Smp8xxxChipId = m_Smp8xxxChipInfo_sp->getChipId();
		
		if(DispPARAM_Brightness == eDispParamType)
		{
			//Set
			eRMstatus = RUAGetProperty2(m_RmfpMainContext.pRUA, DispDigitalOut, RMGenericPropertyID_Brightness,
				&HwValue, sizeof(HwValue));
			if(RMFAILED(eRMstatus))
			{
				//PRINT_BFILE_LINENO_RMSTATUS;
				iOutRet = ERR_RUA_SET_PROP_FAIL;
				break;
			}			
			//Hw value -> Percent value
			//LOG_BLINE("HwVal:%u(0x%02x)\n", HwValue, HwValue);
			iValue = (((RMint8)HwValue + 128) * 100) / 255;
		}
		else if(DispPARAM_Contrast == eDispParamType)
		{
			//Get the value
			eRMstatus = RUAGetProperty2(m_RmfpMainContext.pRUA, DispDigitalOut, RMGenericPropertyID_Contrast,
				&HwValue, sizeof(HwValue));
			if(RMFAILED(eRMstatus))
			{
				iOutRet = ERR_RUA_SET_PROP_FAIL;
				break;
			}			
			//Hw value -> Percent value
			//LOG_BLINE("HwVal:%u(0x%02x)\n", HwValue, HwValue);
			iValue = HwValue * 100 / 255;
		}
		else if(DispPARAM_Saturation == eDispParamType)
		{
			//Cb
			eRMstatus = RUAGetProperty2(m_RmfpMainContext.pRUA, DispDigitalOut, RMGenericPropertyID_CbSaturation,
				&HwValue, sizeof(HwValue));
			if(RMFAILED(eRMstatus))
			{
				iOutRet = ERR_RUA_SET_PROP_FAIL;
				break;
			}			
			//Hw value -> Percent value
			//LOG_BLINE("HwVal:%u(0x%02x)\n", HwValue, HwValue);
			iValue = HwValue * 100 / 255;
		}
		else if(DispPARAM_Hue == eDispParamType)
		{
			//Hue
			eRMstatus = RUAGetProperty2(m_RmfpMainContext.pRUA, DispDigitalOut, RMGenericPropertyID_Hue,
				&HwValue, sizeof(HwValue));
			if(RMFAILED(eRMstatus))
			{
				iOutRet = ERR_RUA_SET_PROP_FAIL;
				break;
			}			
			//Hw value -> Percent value
			//LOG_BLINE("HwVal:%u(0x%02x)\n", HwValue, HwValue);
			iValue = ((((RMint8)HwValue) + 64) * 100) / 128;
		}
		else
		{
			iOutRet = ERROR_INVALID_PARAMETER;
			break;
		}
		
		if(0 > iValue)
		{
			iValue = 0;
		}
		else if(100 < iValue)
		{
			iValue = 100;
		}

		//LOG_BLINE("Val:%d\n", iValue);
	}while(FALSE);
	
	return iOutRet;
}

INT_t CMediaSrv::getDisplayPosition(RUA_DISPLAY_TYPE eRuaDispType, OUT int & x, OUT int & y, OUT int & w, OUT int & h)
{
	INT_t iOutRet = ERROR_SUCCESS;
	RMuint32 ScalerModuleId;

	CAutoLock AutoRangeLocker(&m_mutexVideoAudioIoSet);

	do
	{
		if(RUA_DISP_VIDEO == eRuaDispType)
		{
			ScalerModuleId = EMHWLIB_MODULE(DispMainVideoScaler, 0);
		}
		else if(RUA_DISP_OSD == eRuaDispType)
		{
			ScalerModuleId = EMHWLIB_MODULE(DispOSDScaler, 0);
		}
		else
		{
			iOutRet = ERROR_INVALID_PARAMETER;
			break;
		}
		{
			RMint32 OutX, OutY, OutW, OutH;
			iOutRet = getScalerOutputWindowSize(m_RmfpMainContext.pRUA, ScalerModuleId, OutX, OutY, OutW, OutH);
			if(ERROR_SUCCESS != iOutRet)
			{
				break;
			}
			x = OutX;
			y = OutY;
			w = OutW;
			h = OutH;
		}
	}while(FALSE);

	return iOutRet;
}

INT_t CMediaSrv::OutputDisplayUpdate()
{
	INT_t iOutRet = ERROR_SUCCESS,iRet;	
	struct rmfp_main_thread_context_type *pMainContext = &m_RmfpMainContext;	
	RMstatus status, eRMstatus = RM_OK;
	struct RUA * pRua = pMainContext->pRUA;
	/*
	RMuint32 OsdScalerModuleId;
	RMuint32 OsdSurfaceAddr = 0;
	//*/

	do
	{
		if(m_bNotApplyDispOpt)
		{
			break;
		}
		
		//LOG("OutputDisplayUpdate\n");

		CAutoLock AutoRangeLocker(&m_mutexVideoAudioIoSet); 
		
		// Update the display and apply changed settings, based on the display options
		status = rmoutput_display_update((pMainContext->pHWLib), (pMainContext->dh_info), 
			pMainContext->display_opt, pMainContext->display_conf);
		if (status != RM_OK) {
			RMstatus eRMstatus = status;
			PRINT_BFILE_LINENO_RMSTATUS
		}

		/*
		eRMstatus = DCCGetScalerModuleID(m_RmfpMainContext.pDCC, DCCRoute_Main, DCCSurface_OSD, 0, &OsdScalerModuleId);
		if(RMFAILED(eRMstatus))
		{
			PRINT_BFILE_LINENO_RMSTATUS;
			break;
		}

		{
			eRMstatus = RUAGetProperty2(m_RmfpMainContext.pRUA, OsdScalerModuleId, RMGenericPropertyID_Surface,
				&OsdSurfaceAddr, sizeof(OsdSurfaceAddr));
			if(RMFAILED(eRMstatus))
			{
				PRINT_BFILE_LINENO_RMSTATUS;
				break;
			}
			LOG_BLINE("OsdSurfaceAddr=0x%08x\n", OsdSurfaceAddr);
		}
		//*/

		if(NULL == pMainContext->dh_info->hdmi)
		{
			break;
		}

		if(pMainContext->dh_info->hdmi->State.HotPlugChanged)
		{
			LOG("HDMI_HotPlugChanged\n");
			if(pMainContext->dh_info->hdmi->State.HotPlugState/* && pMainContext->dh_info->hdmi->State.ReceiverState*/)
			{
				UINT64_t StartTimeMs = GetSysUpTimeMs(), CurTimeMs;
				pMainContext->display_opt->hdmi_options.bRequestedStereoscopic3D_changed = TRUE;
				pMainContext->display_opt->hdmi_options.bForceSendVsiInfoFrameOnce = TRUE;
				while(TRUE)
				{
					rmoutput_display_update((pMainContext->pHWLib), (pMainContext->dh_info), 
						pMainContext->display_opt, pMainContext->display_conf);
					CurTimeMs = GetSysUpTimeMs();
					if(1500 <= CurTimeMs - StartTimeMs)
					{
						break;
					}
					usleep(0);
				}
			}
			/*add by xuweiwei 2013-7-1	solve debug for when disconnect HDMI aspect ratio will be change*/ 
			iRet = applyVideoDispAspectRatio(m_VidDispAspectRatioAtNextPlay,NULL,TRUE);
			if(ERROR_SUCCESS != iRet)
			{
				PRINT_BFILE_LINENO_IRET_STR;
			}
			/*---------------------------------end by xuweiwei--------------------------------*/
		}	
	}while(FALSE);
	
	return iOutRet;
}

INT_t CMediaSrv::FindStreamInfoInCache(CONST IMediaFileInfoCache::P_FIND_STREAM_INFO_IN_PARAM pFindInParam, 
	IMediaFileInfoCache::P_FIND_STREAM_INFO_OUT_PARAM pFindOutParam)
{
	return m_MediaFileInfoCache_sp->FindStreamInfoInCache(pFindInParam, pFindOutParam);
}

INT_t CMediaSrv::AddMediaInfoCache(const RMascii * pszFileName, CONST struct RMFPStreamType * pRmfpStreamType, 
	CONST struct RMFPStreamInfo * pRmfpStreamInfo)
{
	return m_MediaFileInfoCache_sp->AddMediaInfoCache(pszFileName, pRmfpStreamType, pRmfpStreamInfo);
}

INT_t CMediaSrv::setMonitorType(MONITOR_MANUFACTURER_ID eMonitorManufacturerId)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	bool bRet;
	SharedPtr <TiXmlDocument2> XmlDoc_sp;
	CGeneralApp * pApp = getApp();
	bool bCreateNodeIfNotExist = TRUE;

	CAutoLock AutoRangeLocker(&m_SharedDataMutex);

	m_eMonitorManufacturerId = eMonitorManufacturerId;

	do
	{
		XmlDoc_sp = pApp->getXmlCfgDoc();
		if(XmlDoc_sp.isNull())
		{
			iOutRet = ERROR_INVALID_STATE;
			break;
		}
		iRet = XmlDoc_sp->setElementPropertyValue(XML_Monitor_Ele_PATH, PropDesc_Type, m_eMonitorManufacturerId, bCreateNodeIfNotExist);
		if(ERROR_SUCCESS != iRet)
		{
			PRINT_BFILE_LINENO_IRET_STR;
			break;
		}
		bRet = XmlDoc_sp->SaveFile(MP_SETTING_XML_DOC_PATH);
		if(false == bRet)
		{
			LOG_BLINE("Save vol err\n");
		}
		sync();
	}while(FALSE);
	
	return iOutRet;
}

INT_t CMediaSrv::getMonitorType(OUT MONITOR_MANUFACTURER_ID & eMonitorManufacturerId)
{
	INT_t iOutRet = ERROR_SUCCESS;

	CAutoLock AutoRangeLocker(&m_SharedDataMutex);

	do
	{
		eMonitorManufacturerId = m_eMonitorManufacturerId;
	}while(FALSE);
	
	return iOutRet;
}

INT_t CMediaSrv::setPlaySpeedCtrlAsync(int Speed)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	SharedPtr <CMsgData_setPlaySpeedCtrl> MsgData_setPlaySpeedCtrl_sp(new CMsgData_setPlaySpeedCtrl);
	SharedPtr<CMessageQueueItem> ThreadMsg_sp(new CMessageQueueItem);
	SharedPtr <CGenericMsgData> MsgData_sp;

	do
	{
		if(MsgData_setPlaySpeedCtrl_sp.isNull() || ThreadMsg_sp.isNull())
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}
		MsgData_setPlaySpeedCtrl_sp->m_uiMsgId = MSG_CMD_setPlaySpeedCtrl;
		MsgData_setPlaySpeedCtrl_sp->m_iSpeed = Speed;
		MsgData_sp = MsgData_setPlaySpeedCtrl_sp;
		iRet = ThreadMsg_sp->SetMessageData(MsgData_sp);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}

		iRet = PostMessage(ThreadMsg_sp);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}
	}while(FALSE);
	
	return iOutRet;
}

INT_t CMediaSrv::getOutputSpdifMode(INT32_t *pOutSpdifMode)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	DECLARE_CLS_STACK_BUF_STRING(strOutputSpdifMode, 64);
	CStackBufString::SCANF_PARAM oScanfParam;
	CStackBufString::ScanfParam_Init(&oScanfParam);

	do{
		if(NULL == pOutSpdifMode)
		{
			iOutRet = ERROR_INVALID_PARAMETER;
			break;
		}
		
		iRet = SysProp_get(SysProp_KEY_OutputSpdifMode, OUT strOutputSpdifMode);
		if(ERROR_SUCCESS == iRet)
		{
			iRet = strOutputSpdifMode.Scanf(IN OUT oScanfParam, "%d", pOutSpdifMode);
			if(ERROR_SUCCESS != iRet)
			{
				//PRINT_BFILE_LINENO_IRET_STR;
				iOutRet = iRet;
				break;
			}
		}
		else
		{
			*pOutSpdifMode = 2;
		}
	}while(FALSE);

	return iOutRet;
}

INT_t CMediaSrv::setOutputSpdifMode(IN const INT32_t OutputSpdifMode)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	SharedPtr <CMsgData_setSpdifMode> MsgData_setOutputSpdif_sp(new CMsgData_setSpdifMode);
	SharedPtr<CMessageQueueItem> ThreadMsg_sp(new CMessageQueueItem);
	SharedPtr <CGenericMsgData> MsgData_sp;

	do{
		if(MsgData_setOutputSpdif_sp.isNull() || ThreadMsg_sp.isNull())
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}

		MsgData_setOutputSpdif_sp->m_uiMsgId = MSG_CMD_setOutputSpdifMode;
		MsgData_setOutputSpdif_sp->m_iSpdifMode = OutputSpdifMode;
		//LOG_BLINE("MsgData_setOutputSpdif_sp->m_iSpdifMode=%d\n", MsgData_setOutputSpdif_sp->m_iSpdifMode);
		MsgData_sp = MsgData_setOutputSpdif_sp;
		iRet = ThreadMsg_sp->SetMessageData(MsgData_sp);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}

		iRet = SendMessage(ThreadMsg_sp);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}		
		iOutRet = MsgData_sp->m_iOutRet;
	}while(FALSE);

	return iOutRet;
}

INT_t CMediaSrv:: setVideoDispAspectRatio(DISPLAY_ASPECT_RATIO eVideoDispAspectRato, UINT32_t OptFlag)
{
	INT_t iOutRet = ERROR_SUCCESS;

	do
	{
		if(DAR_ONLY_APPLY_ONCE_AT_NEXT_PLAY & OptFlag)
		{
			CAutoLock AutoRangeLocker(&m_SharedDataMutex);
#if 1/*added by xuweiwei 2014-4-2*/
			if( m_VidDispAspectRatioAtNextPlay != eVideoDispAspectRato)
			{
				SharedPtr <TiXmlDocument2> XmlDoc_sp;
				CGeneralApp * pApp = getApp();
				bool bCreateNodeIfNotExist = TRUE;
				XmlDoc_sp = pApp->getXmlCfgDoc();
				if(XmlDoc_sp.isNull())
				{
					iOutRet = ERROR_INVALID_STATE;
					break;
				}
				iOutRet = XmlDoc_sp->setElementPropertyValue(XML_DispParam_Ele_PATH, PropDesc_VideoMode, eVideoDispAspectRato, bCreateNodeIfNotExist);
				if(ERROR_SUCCESS != iOutRet)
				{
					LOG_BLINE("Set video display aspect ratio error\n");
					break;
				}
				bool bRet = XmlDoc_sp->SaveFile(MP_SETTING_XML_DOC_PATH);
				if(false == bRet)
				{
					LOG_BLINE("Save video display aspect ratio error\n");
				}
				sync();
			}
#endif
			m_VidDispAspectRatioAtNextPlay = eVideoDispAspectRato;
			m_bVidDispAspectRatioAtNextPlay_Valid = TRUE;
		}
		else
		{
			iOutRet = ERROR_INVALID_PARAMETER;
			break;
		}
	}while(FALSE);

	return iOutRet;
}

#if 1/*added by lxj 2012-9-28*/
INT_t CMediaSrv::getVideoDispAspectRatio(DISPLAY_ASPECT_RATIO &eVideoDispAspectRato)
{
	INT_t iRet = ERROR_SUCCESS;

	do
	{
		eVideoDispAspectRato = m_CurVidDispAspectRatio;
	}while(FALSE);

	return iRet;
}
#endif

RMstatus CMediaSrv::InitVcrScaler()
{
	RMstatus eOutRMstatus = RM_OK, eRMstatus = RM_OK;
	INT_t iRet;
	struct rmfp_main_thread_context_type *pMainContext = &m_RmfpMainContext;	
	RMuint32 VcrScalerModuleId = EMHWLIB_MODULE(DispVCRMultiScaler, 0);
	struct EMhwlibDisplayWindow ScalerInputWindowSize;
	RMbool bWaitForDispEvtIfPending = TRUE;
	enum EMhwlibScalingMode ScalingMode = EMhwlibScalingMode_LetterBox;
	RMuint8 ScalerConstrast = 128;
	RMint8 ScalerBrightness = 0;
	RMint32 LeftTryTimes = 0;
	struct RUA * pRua = pMainContext->pRUA;
	RMint32 TryIntervalMsIfPending = 30;
	RMint32 RetryTimesIfPending = 3;

	do
	{
		//set output window size
		iRet = setScalerOutputWindowSize(pRua, VcrScalerModuleId, 0, 0, 4096, 4096);
		if(ERROR_SUCCESS != iRet)
		{
			eOutRMstatus = RM_ERROR;
			break;
		}
		// Set the Scaler Input Window to full screen
		ScalerInputWindowSize.X = 0;
		ScalerInputWindowSize.Y = 0;
		ScalerInputWindowSize.Width = 4096;
		ScalerInputWindowSize.Height = 4096;
		ScalerInputWindowSize.XPositionMode = EMhwlibDisplayWindowPositionMode_FrontEdgeToBorder;
		ScalerInputWindowSize.YPositionMode = EMhwlibDisplayWindowPositionMode_FrontEdgeToBorder;
		ScalerInputWindowSize.XMode = EMhwlibDisplayWindowValueMode_Relative;
		ScalerInputWindowSize.YMode = EMhwlibDisplayWindowValueMode_Relative;
		ScalerInputWindowSize.WidthMode = EMhwlibDisplayWindowValueMode_Relative;
		ScalerInputWindowSize.HeightMode = EMhwlibDisplayWindowValueMode_Relative;
		LeftTryTimes = 5;
		eRMstatus = RuaSetProp5(pMainContext->pRUA, VcrScalerModuleId, RMGenericPropertyID_ScalerInputWindow,
			&ScalerInputWindowSize, sizeof(ScalerInputWindowSize), RetryTimesIfPending, TryIntervalMsIfPending);
		if(RMFAILED(eRMstatus))
		{
			PRINT_BFILE_LINENO_RMSTATUS;
		}
		//set ScalingMode
		eRMstatus = RuaSetProp5(pMainContext->pRUA, VcrScalerModuleId, RMGenericPropertyID_ScalingMode, 
			&ScalingMode, sizeof(ScalingMode), RetryTimesIfPending, TryIntervalMsIfPending);
		if(RMFAILED(eRMstatus))
		{
			PRINT_BFILE_LINENO_RMSTATUS;
		}
		//set contrast
		eRMstatus = RuaSetProp5(pMainContext->pRUA, VcrScalerModuleId, RMGenericPropertyID_Contrast, 
			&ScalerConstrast, sizeof(ScalerConstrast), RetryTimesIfPending, TryIntervalMsIfPending);
		if(RMFAILED(eRMstatus))
		{
			PRINT_BFILE_LINENO_RMSTATUS;
		}
		//set brightness
		eRMstatus = RuaSetProp5(pMainContext->pRUA, VcrScalerModuleId, RMGenericPropertyID_Brightness, 
			&ScalerBrightness, sizeof(ScalerBrightness), RetryTimesIfPending, TryIntervalMsIfPending);
		if(RMFAILED(eRMstatus))
		{
			PRINT_BFILE_LINENO_RMSTATUS;
		}
		//set BlackStripMode if needed
		{
			struct EMhwlibBlackStripMode CurBlkStripMode;
			eRMstatus = RUAGetProperty2(pRua, VcrScalerModuleId, RMGenericPropertyID_BlackStripMode, &CurBlkStripMode, sizeof(CurBlkStripMode));
			if(RMSUCCEEDED(eRMstatus))
			{
				if(FALSE == (4096 == CurBlkStripMode.Horizontal && 4096 == CurBlkStripMode.Vertical))
				{
					CurBlkStripMode.Horizontal = 4096;
					CurBlkStripMode.Vertical = 4096;
					eRMstatus = RuaSetProp5(pRua, VcrScalerModuleId, RMGenericPropertyID_BlackStripMode, &CurBlkStripMode, sizeof(CurBlkStripMode), 
						RetryTimesIfPending, TryIntervalMsIfPending);
					if(RMFAILED(eRMstatus))
					{
						PRINT_BFILE_LINENO_RMSTATUS;
					}
				}
			}
			else
			{
				PRINT_BFILE_LINENO_RMSTATUS;
			}
		}
		//set CutStripMode if needed
		{
			struct EMhwlibCutStripMode CurCutStripMode;
			eRMstatus = RUAGetProperty2(pRua, VcrScalerModuleId, RMGenericPropertyID_CutStripMode, &CurCutStripMode, sizeof(CurCutStripMode));
			if(RMSUCCEEDED(eRMstatus))
			{
				if(FALSE == (0 == CurCutStripMode.Horizontal && 0 == CurCutStripMode.Vertical))
				{
					CurCutStripMode.Horizontal = 0;
					CurCutStripMode.Vertical = 0;
					eRMstatus = RuaSetProp5(pRua, VcrScalerModuleId, RMGenericPropertyID_CutStripMode, &CurCutStripMode, sizeof(CurCutStripMode), 
						RetryTimesIfPending, TryIntervalMsIfPending);
					if(RMFAILED(eRMstatus))
					{
						PRINT_BFILE_LINENO_RMSTATUS;
					}
				}
			}
			else
			{
				PRINT_BFILE_LINENO_RMSTATUS;
			}
		}
		//enable if not
		{
			RMbool bEnable;
			eRMstatus = RUAGetProperty2(pRua, VcrScalerModuleId, RMGenericPropertyID_Enable, &bEnable, sizeof(bEnable));
			if(RMSUCCEEDED(eRMstatus))
			{
				if(FALSE == bEnable)
				{
					eRMstatus = RuaSetProp5(pRua, VcrScalerModuleId, RMGenericPropertyID_Validate, &bEnable, sizeof(bEnable), 
						RetryTimesIfPending, TryIntervalMsIfPending);
					if(RMFAILED(eRMstatus))
					{
						PRINT_BFILE_LINENO_RMSTATUS;
					}
				}
			}
			else
			{
				PRINT_BFILE_LINENO_RMSTATUS;
			}
		}
		//validate
		eRMstatus = RuaSetProp5(pRua, VcrScalerModuleId, RMGenericPropertyID_Validate, NULL, 0, RetryTimesIfPending, TryIntervalMsIfPending);
		if(RMFAILED(eRMstatus))
		{
			PRINT_BFILE_LINENO_RMSTATUS;
		}
	}while(FALSE);

	return eOutRMstatus;
}

INT_t CMediaSrv::applyMixerDispAspectRatio(DISPLAY_ASPECT_RATIO eDispAspectRatio)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	RMstatus eRMstatus = RM_OK;
	RMuint32 MainMixerModuleId = EMHWLIB_MODULE(DispMainMixer, 0);
	struct EMhwlibVideoFrameDescriptionForce VidFrameInfoForce;
	BOOL_t bWaitForDispEvtIfPending = TRUE;
	RMint32 LeftTryTimes = 0;

	do
	{
		ZeroMemory(&VidFrameInfoForce, sizeof(VidFrameInfoForce));
		if(DispAspectRatio_16_9 == eDispAspectRatio)
		{
			RMinsShiftBool(&(VidFrameInfoForce.ForceMask), TRUE, EMHWLIB_FRAMEINFO_BIT_AspectRatio);
			VidFrameInfoForce.FrameInfo.AFD.FrameAspectRatio.X = 16;
			VidFrameInfoForce.FrameInfo.AFD.FrameAspectRatio.Y = 9;
			VidFrameInfoForce.FrameInfo.AFD.PixelAspectRatio.X = 0;
			VidFrameInfoForce.FrameInfo.AFD.PixelAspectRatio.Y = 0;			
		}
		else if(DispAspectRatio_4_3 == eDispAspectRatio)
		{
			RMinsShiftBool(&(VidFrameInfoForce.ForceMask), TRUE, EMHWLIB_FRAMEINFO_BIT_AspectRatio);
			VidFrameInfoForce.FrameInfo.AFD.FrameAspectRatio.X = 4;
			VidFrameInfoForce.FrameInfo.AFD.FrameAspectRatio.Y = 3;
			VidFrameInfoForce.FrameInfo.AFD.PixelAspectRatio.X = 0;
			VidFrameInfoForce.FrameInfo.AFD.PixelAspectRatio.Y = 0;
		}
		else if(DispAspectRatio_DEFAULT == eDispAspectRatio)
		{
			RMinsShiftBool(&(VidFrameInfoForce.ForceMask), TRUE, EMHWLIB_FRAMEINFO_BIT_AspectRatio);
		}
		else
		{
			iOutRet = ERROR_INVALID_PARAMETER;
			break;
		}

		LeftTryTimes = 3;
		while(TRUE)
		{
			eRMstatus = RUASetProperty3(m_RmfpMainContext.pRUA, MainMixerModuleId, RMGenericPropertyID_FrameInfoForce, 
				&VidFrameInfoForce, sizeof(VidFrameInfoForce), bWaitForDispEvtIfPending);
			if(RM_OK == eRMstatus)
			{
				break;
			}
			else if(RM_PENDING == eRMstatus)
			{
			}
			else if(RMFAILED(eRMstatus))
			{
				iOutRet = ERR_RUA_SET_PROP_FAIL;
				break;
			}
			LeftTryTimes--;
			if(0 >= LeftTryTimes)
			{
				iOutRet = ERR_RUA_SET_PENDING;
				break;
			}
		}
		if(ERROR_SUCCESS != iOutRet)
		{
			break;
		}

		LeftTryTimes = 3;
		while(TRUE)
		{
			eRMstatus = RUASetProperty3(m_RmfpMainContext.pRUA, MainMixerModuleId, RMGenericPropertyID_Validate, NULL, 0, bWaitForDispEvtIfPending);
			if(RM_OK == eRMstatus)
			{
				break;
			}
			else if(RM_PENDING == eRMstatus)
			{
			}
			else if(RMFAILED(eRMstatus))
			{
				iOutRet = ERR_RUA_SET_PROP_FAIL;
				break;
			}
			LeftTryTimes--;
			if(0 >= LeftTryTimes)
			{
				iOutRet = ERR_RUA_SET_PENDING;
				break;
			}
		}
		if(ERROR_SUCCESS != iOutRet)
		{
			break;
		}
	}while(FALSE);

	return iOutRet;
}

/*
ThreadContext: player thread
*/
INT_t CMediaSrv::applyVideoDispAspectRatio(DISPLAY_ASPECT_RATIO eDispAspectRatio,
	struct EMhwlibStereoscopic3D * pStereoscopic3D/* = NULL*/, BOOL_t bForce/* = FALSE*/)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	struct rmfp_main_thread_context_type *pMainContext = &m_RmfpMainContext;	
	RMstatus eRMstatus = RM_OK;
	RMuint32 MainMixerModuleId = EMHWLIB_MODULE(DispMainMixer, 0);
	RMuint32 HDSDConverterModuleId = EMHWLIB_MODULE(DispHDSDConverter, 0);
	struct EMhwlibVideoFrameDescriptionForce VidFrameInfoForce;
	BOOL_t bWaitForDispEvtIfPending = TRUE;
	RMint32 LeftTryTimes = 0;
	struct DispRouting_Routing_type CurDispRouting;
	BOOL_t MainMixerIsOutput = FALSE;
	BOOL_t HDSDConverterIsOutput = FALSE;
	struct EMhwlibAspectRatio MainVideoScalerAspectRatio;
	RMuint32 DispMainAnalogModuleId = EMHWLIB_MODULE(DispMainAnalogOut, 0);

	do
	{
		if((FALSE == bForce) && (m_CurVidDispAspectRatio == eDispAspectRatio))	//no force, same
		{
			break;	//not need set
		}
		
		ZeroMemory(&VidFrameInfoForce, sizeof(VidFrameInfoForce));

		if(DispAspectRatio_DEFAULT == eDispAspectRatio)
		{
			RMinsShiftBool(&(VidFrameInfoForce.ForceMask), TRUE, EMHWLIB_FRAMEINFO_BIT_AspectRatio);
			VidFrameInfoForce.FrameInfo.AFD.FrameAspectRatio.X = 16;
			VidFrameInfoForce.FrameInfo.AFD.FrameAspectRatio.Y = 9;
			VidFrameInfoForce.FrameInfo.AFD.PixelAspectRatio.X = 0;
			VidFrameInfoForce.FrameInfo.AFD.PixelAspectRatio.Y = 0;
			MainVideoScalerAspectRatio.X = 16;
			MainVideoScalerAspectRatio.Y = 9;
		}
		else if(DispAspectRatio_16_9 == eDispAspectRatio)	//wide picture
		{
			RMinsShiftBool(&(VidFrameInfoForce.ForceMask), TRUE, EMHWLIB_FRAMEINFO_BIT_AspectRatio);
			VidFrameInfoForce.FrameInfo.AFD.FrameAspectRatio.X = 4;
			VidFrameInfoForce.FrameInfo.AFD.FrameAspectRatio.Y = 3;
			VidFrameInfoForce.FrameInfo.AFD.PixelAspectRatio.X = 0;
			VidFrameInfoForce.FrameInfo.AFD.PixelAspectRatio.Y = 0;			
			MainVideoScalerAspectRatio.X = 4;
			MainVideoScalerAspectRatio.Y = 3;
		}
		else if(DispAspectRatio_4_3 == eDispAspectRatio)
		{
			RMinsShiftBool(&(VidFrameInfoForce.ForceMask), TRUE, EMHWLIB_FRAMEINFO_BIT_AspectRatio);
			VidFrameInfoForce.FrameInfo.AFD.FrameAspectRatio.X = 16;
			VidFrameInfoForce.FrameInfo.AFD.FrameAspectRatio.Y = 9;
			VidFrameInfoForce.FrameInfo.AFD.PixelAspectRatio.X = 0;
			VidFrameInfoForce.FrameInfo.AFD.PixelAspectRatio.Y = 0;
			MainVideoScalerAspectRatio.X = 16;
			MainVideoScalerAspectRatio.Y = 9;
		}
		else if(DispAspectRatio_FULL == eDispAspectRatio)
		{
			RMinsShiftBool(&(VidFrameInfoForce.ClearMask), TRUE, EMHWLIB_FRAMEINFO_BIT_AspectRatio);
			MainVideoScalerAspectRatio.X = 0;
			MainVideoScalerAspectRatio.Y = 0;
		}
		else
		{
			iOutRet = ERROR_INVALID_PARAMETER;
			break;
		}

		CAutoLock AutoRangeLocker(&m_mutexVideoAudioIoSet); 

		eRMstatus = RUAGetProperty(m_RmfpMainContext.pRUA, DispRouting, RMDispRoutingPropertyID_Routing,
			&CurDispRouting, sizeof(CurDispRouting));
		if(RMFAILED(eRMstatus))
		{
			iOutRet = ERR_RUA_GET_PROP_FAIL;
			break;
		}

		if((CurDispRouting.DigitalOutputEnable && MainMixerModuleId == CurDispRouting.DigitalOutputSourceModuleID) ||
			(CurDispRouting.MainAnalogOutputEnable && MainMixerModuleId == CurDispRouting.MainAnalogOutputSourceModuleID) ||
			(CurDispRouting.ComponentOutputEnable && MainMixerModuleId == CurDispRouting.ComponentOutputSourceModuleID) ||
			(CurDispRouting.CompositeOutputEnable && MainMixerModuleId == CurDispRouting.CompositeOutputSourceModuleID))
		{
			MainMixerIsOutput = TRUE;
		}
		if((CurDispRouting.DigitalOutputEnable && HDSDConverterModuleId == CurDispRouting.DigitalOutputSourceModuleID) ||
			(CurDispRouting.MainAnalogOutputEnable && HDSDConverterModuleId == CurDispRouting.MainAnalogOutputSourceModuleID) ||
			(CurDispRouting.ComponentOutputEnable && HDSDConverterModuleId == CurDispRouting.ComponentOutputSourceModuleID) ||
			(CurDispRouting.CompositeOutputEnable && HDSDConverterModuleId == CurDispRouting.CompositeOutputSourceModuleID) )
		{
			HDSDConverterIsOutput = TRUE;
		}
		
		//LOG_BLINE("MainMixerIsOutput=%d,HDSDConverterIsOutput=%d\n", MainMixerIsOutput, HDSDConverterIsOutput);

#if	0
		//MainMixer
		if(MainMixerIsOutput)
		{
			LeftTryTimes = 3;
			while(TRUE)
			{
				eRMstatus = RUASetProperty3(m_RmfpMainContext.pRUA, MainMixerModuleId, RMGenericPropertyID_FrameInfoForce, 
					&VidFrameInfoForce, sizeof(VidFrameInfoForce), (500*1000)/*timeout us*/, bWaitForDispEvtIfPending);
				if(RM_OK == eRMstatus)
				{
					break;
				}
				else if(RM_PENDING == eRMstatus)
				{
					usleep(10*1000);
				}
				else if(RMFAILED(eRMstatus))
				{
					iOutRet = ERR_RUA_SET_PROP_FAIL;
					break;
				}
				LeftTryTimes--;
				if(0 >= LeftTryTimes)
				{
					iOutRet = ERR_RUA_SET_PENDING;
					break;
				}
			}
			if(ERROR_SUCCESS != iOutRet)
			{
				break;
			}

			LeftTryTimes = 3;
			while(TRUE)
			{
				eRMstatus = RUASetProperty3(m_RmfpMainContext.pRUA, MainMixerModuleId, RMGenericPropertyID_Validate, 
					NULL, 0, (500*1000)/*timeout us*/, bWaitForDispEvtIfPending);
				if(RM_OK == eRMstatus)
				{
					break;
				}
				else if(RM_PENDING == eRMstatus)
				{
					usleep(10*1000);
				}
				else if(RMFAILED(eRMstatus))
				{
					iOutRet = ERR_RUA_SET_PROP_FAIL;
					break;
				}
				LeftTryTimes--;
				if(0 >= LeftTryTimes)
				{
					iOutRet = ERR_RUA_SET_PENDING;
					break;
				}
			}
			if(ERROR_SUCCESS != iOutRet)
			{
				break;
			}
		}

		//HDSDConverter
		if(HDSDConverterIsOutput)
		{
			//Set FrameInfoForce
			LeftTryTimes = 3;
			while(TRUE)
			{
				eRMstatus = RUASetProperty3(m_RmfpMainContext.pRUA, HDSDConverterModuleId, RMGenericPropertyID_FrameInfoForce, 
					&VidFrameInfoForce, sizeof(VidFrameInfoForce), (500*1000)/*timeout us*/, bWaitForDispEvtIfPending);
				if(RM_OK == eRMstatus)
				{
					break;
				}
				else if(RM_PENDING == eRMstatus)
				{
					usleep(10*1000);
				}
				else if(RMFAILED(eRMstatus))
				{
					iOutRet = ERR_RUA_SET_PROP_FAIL;
					break;
				}
				LeftTryTimes--;
				if(0 >= LeftTryTimes)
				{
					iOutRet = ERR_RUA_SET_PENDING;
					break;
				}
			}
			if(ERROR_SUCCESS != iOutRet)
			{
				break;
			}
		
			LeftTryTimes = 3;
			while(TRUE)
			{
				eRMstatus = RUASetProperty3(m_RmfpMainContext.pRUA, HDSDConverterModuleId, RMGenericPropertyID_Validate, 
					NULL, 0, (500*1000)/*timeout us*/, bWaitForDispEvtIfPending);
				if(RM_OK == eRMstatus)
				{
					break;
				}
				else if(RM_PENDING == eRMstatus)
				{
					usleep(10*1000);
				}
				else if(RMFAILED(eRMstatus))
				{
					iOutRet = ERR_RUA_SET_PROP_FAIL;
					break;
				}
				LeftTryTimes--;
				if(0 >= LeftTryTimes)
				{
					iOutRet = ERR_RUA_SET_PENDING;
					break;
				}
			}
			if(ERROR_SUCCESS != iOutRet)
			{
				break;
			}
		}
#endif	

#if	0		
		//DispDigitalOut
		{
			RMuint32 idDispDigitalOutModule = EMHWLIB_MODULE(DispDigitalOut, 0);
			LOG_BLINE("DispDigitalOut=%d,idDispDigitalOutModule=%d\n", DispDigitalOut, idDispDigitalOutModule);
			struct EMhwlibVideoFrameDescriptionForce VidFrameInfoForce_Full = VidFrameInfoForce;
			RMinsShiftBool(&(VidFrameInfoForce_Full.ClearMask), TRUE, EMHWLIB_FRAMEINFO_BIT_AspectRatio);
			RMinsShiftBool(&(VidFrameInfoForce_Full.ForceMask), TRUE, EMHWLIB_FRAMEINFO_BIT_AspectRatio);
			VidFrameInfoForce_Full.FrameInfo.AFD.FrameAspectRatio.X = 10;
			VidFrameInfoForce_Full.FrameInfo.AFD.FrameAspectRatio.Y = 4;
			VidFrameInfoForce_Full.FrameInfo.AFD.PixelAspectRatio.X = 0;
			VidFrameInfoForce_Full.FrameInfo.AFD.PixelAspectRatio.Y = 0;			
			//Set FrameInfoForce
			LeftTryTimes = 3;
			while(TRUE)
			{
				eRMstatus = RUASetProperty3(m_RmfpMainContext.pRUA, idDispDigitalOutModule, RMGenericPropertyID_FrameInfoForce, 
					&VidFrameInfoForce_Full, sizeof(VidFrameInfoForce_Full), (500*1000)/*timeout us*/, bWaitForDispEvtIfPending);
				if(RM_OK == eRMstatus)
				{
					break;
				}
				else if(RM_PENDING == eRMstatus)
				{
					usleep(10*1000);
				}
				else if(RMFAILED(eRMstatus))
				{
					iOutRet = ERR_RUA_SET_PROP_FAIL;
					break;
				}
				LeftTryTimes--;
				if(0 >= LeftTryTimes)
				{
					iOutRet = ERR_RUA_SET_PENDING;
					break;
				}
			}
			if(ERROR_SUCCESS != iOutRet)
			{
				break;
			}
		
			LeftTryTimes = 3;
			while(TRUE)
			{
				eRMstatus = RUASetProperty3(m_RmfpMainContext.pRUA, idDispDigitalOutModule, RMGenericPropertyID_Validate, 
					NULL, 0, (500*1000)/*timeout us*/, bWaitForDispEvtIfPending);
				if(RM_OK == eRMstatus)
				{
					break;
				}
				else if(RM_PENDING == eRMstatus)
				{
					usleep(10*1000);
				}
				else if(RMFAILED(eRMstatus))
				{
					iOutRet = ERR_RUA_SET_PROP_FAIL;
					break;
				}
				LeftTryTimes--;
				if(0 >= LeftTryTimes)
				{
					iOutRet = ERR_RUA_SET_PENDING;
					break;
				}
			}
			if(ERROR_SUCCESS != iOutRet)
			{
				break;
			}
		}
#endif

		//DispMainAnalogModuleId
		{			
			struct EMhwlibVideoFrameDescriptionForce VidFrameInfoForce_Full = VidFrameInfoForce;
			RMinsShiftBool(&(VidFrameInfoForce_Full.ClearMask), TRUE, EMHWLIB_FRAMEINFO_BIT_AspectRatio);
			RMinsShiftBool(&(VidFrameInfoForce_Full.ForceMask), TRUE, EMHWLIB_FRAMEINFO_BIT_AspectRatio);
			VidFrameInfoForce_Full.FrameInfo.AFD.FrameAspectRatio.X = 0;
			VidFrameInfoForce_Full.FrameInfo.AFD.FrameAspectRatio.Y = 0;
			VidFrameInfoForce_Full.FrameInfo.AFD.PixelAspectRatio.X = 1;
			VidFrameInfoForce_Full.FrameInfo.AFD.PixelAspectRatio.Y = 1;			
			//Set FrameInfoForce
			LeftTryTimes = 3;
			while(TRUE)
			{
				eRMstatus = RUASetProperty3(m_RmfpMainContext.pRUA, DispMainAnalogModuleId, RMGenericPropertyID_FrameInfoForce, 
					&VidFrameInfoForce_Full, sizeof(VidFrameInfoForce_Full), (500*1000)/*timeout us*/, bWaitForDispEvtIfPending);
				if(RM_OK == eRMstatus)
				{
					break;
				}
				else if(RM_PENDING == eRMstatus)
				{
					usleep(10*1000);
				}
				else if(RMFAILED(eRMstatus))
				{
					iOutRet = ERR_RUA_SET_PROP_FAIL;
					break;
				}
				LeftTryTimes--;
				if(0 >= LeftTryTimes)
				{
					iOutRet = ERR_RUA_SET_PENDING;
					break;
				}
			}
			if(ERROR_SUCCESS != iOutRet)
			{
				break;
			}
		
			LeftTryTimes = 3;
			while(TRUE)
			{
				eRMstatus = RUASetProperty3(m_RmfpMainContext.pRUA, DispMainAnalogModuleId, RMGenericPropertyID_Validate, 
					NULL, 0, (500*1000)/*timeout us*/, bWaitForDispEvtIfPending);
				if(RM_OK == eRMstatus)
				{
					break;
				}
				else if(RM_PENDING == eRMstatus)
				{
					usleep(10*1000);
				}
				else if(RMFAILED(eRMstatus))
				{
					iOutRet = ERR_RUA_SET_PROP_FAIL;
					break;
				}
				LeftTryTimes--;
				if(0 >= LeftTryTimes)
				{
					iOutRet = ERR_RUA_SET_PENDING;
					break;
				}
			}
			if(ERROR_SUCCESS != iOutRet)
			{
				break;
			}
		}
		
		//HDSDConverterModuleId
		{			
			struct EMhwlibVideoFrameDescriptionForce VidFrameInfoForce_Full = VidFrameInfoForce;
			RMinsShiftBool(&(VidFrameInfoForce_Full.ClearMask), TRUE, EMHWLIB_FRAMEINFO_BIT_AspectRatio);
			RMinsShiftBool(&(VidFrameInfoForce_Full.ForceMask), TRUE, EMHWLIB_FRAMEINFO_BIT_AspectRatio);
			VidFrameInfoForce_Full.FrameInfo.AFD.FrameAspectRatio.X = 0;
			VidFrameInfoForce_Full.FrameInfo.AFD.FrameAspectRatio.Y = 0;
			VidFrameInfoForce_Full.FrameInfo.AFD.PixelAspectRatio.X = 1;
			VidFrameInfoForce_Full.FrameInfo.AFD.PixelAspectRatio.Y = 1;			
			//Set FrameInfoForce
			LeftTryTimes = 3;
			while(TRUE)
			{
				eRMstatus = RUASetProperty3(m_RmfpMainContext.pRUA, HDSDConverterModuleId, RMGenericPropertyID_FrameInfoForce, 
					&VidFrameInfoForce_Full, sizeof(VidFrameInfoForce_Full), (500*1000)/*timeout us*/, bWaitForDispEvtIfPending);
				if(RM_OK == eRMstatus)
				{
					break;
				}
				else if(RM_PENDING == eRMstatus)
				{
					usleep(10*1000);
				}
				else if(RMFAILED(eRMstatus))
				{
					iOutRet = ERR_RUA_SET_PROP_FAIL;
					break;
				}
				LeftTryTimes--;
				if(0 >= LeftTryTimes)
				{
					iOutRet = ERR_RUA_SET_PENDING;
					break;
				}
			}
			if(ERROR_SUCCESS != iOutRet)
			{
				break;
			}
		
			LeftTryTimes = 3;
			while(TRUE)
			{
				eRMstatus = RUASetProperty3(m_RmfpMainContext.pRUA, HDSDConverterModuleId, RMGenericPropertyID_Validate, 
					NULL, 0, (500*1000)/*timeout us*/, bWaitForDispEvtIfPending);
				if(RM_OK == eRMstatus)
				{
					break;
				}
				else if(RM_PENDING == eRMstatus)
				{
					usleep(10*1000);
				}
				else if(RMFAILED(eRMstatus))
				{
					iOutRet = ERR_RUA_SET_PROP_FAIL;
					break;
				}
				LeftTryTimes--;
				if(0 >= LeftTryTimes)
				{
					iOutRet = ERR_RUA_SET_PENDING;
					break;
				}
			}
			if(ERROR_SUCCESS != iOutRet)
			{
				break;
			}
		}

		RMuint32 MainVidScalerTargetModuleIdInMainMixer;
#if 0    /*Add by xuweiwei 2014-4-3*/
		if(VO_MODE_SPLIT_HdmiVcr_VgaMain ==m_eVoMode || VO_MODE_SPLIT_HdmiVcr_1080p60_VgaMain == m_eVoMode)
		{
			RMuint32 videoScalerModuleId;
			videoScalerModuleId = EMHWLIB_MODULE(DispVCRMultiScaler, 0);
			RMuint32 MainVidScalerSrcIdInMainMixer;
			eRMstatus = RUAExchangeProperty(m_RmfpMainContext.pRUA, MainMixerModuleId, RMGenericPropertyID_MixerSourceIndex,&videoScalerModuleId, sizeof(videoScalerModuleId), &MainVidScalerSrcIdInMainMixer, sizeof(MainVidScalerSrcIdInMainMixer));
			if(RMFAILED(eRMstatus))
			{
				PRINT_BFILE_LINENO_RMSTATUS;
				break;
			}
			MainVidScalerTargetModuleIdInMainMixer = EMHWLIB_TARGET_MODULE(EMHWLIB_MODULE_CATEGORY(MainMixerModuleId), 0, MainVidScalerSrcIdInMainMixer);
		}
		else
#endif  
		{
			RMuint32 videoScalerModuleId;
			eRMstatus = rmfp_getVideoScalerModuleId(pMainContext, &videoScalerModuleId, NULL);
			if(RMFAILED(eRMstatus))
			{
				PRINT_BFILE_LINENO_RMSTATUS;
				videoScalerModuleId = EMHWLIB_MODULE(DispMainVideoScaler, 0);
			}
			RMuint32 videoScalerCategoryId = EMHWLIB_MODULE_CATEGORY(videoScalerModuleId);
			RMuint32 MainVidScalerSrcIdInMainMixer;
			eRMstatus = RUAExchangeProperty(m_RmfpMainContext.pRUA, MainMixerModuleId, RMGenericPropertyID_MixerSourceIndex,&videoScalerCategoryId, sizeof(videoScalerCategoryId), &MainVidScalerSrcIdInMainMixer, sizeof(MainVidScalerSrcIdInMainMixer));
			if(RMFAILED(eRMstatus))
			{
				PRINT_BFILE_LINENO_RMSTATUS;
				break;
			}
			//LOG_BLINE("MainVidScalerSrcIdInMainMixer=%u\n", MainVidScalerSrcIdInMainMixer);
			MainVidScalerTargetModuleIdInMainMixer = EMHWLIB_TARGET_MODULE(EMHWLIB_MODULE_CATEGORY(MainMixerModuleId), 0, MainVidScalerSrcIdInMainMixer);	
		}

#if	0
		LeftTryTimes = 3;
		while(TRUE)
		{
			eRMstatus = RUASetProperty3(m_RmfpMainContext.pRUA, MainVidScalerTargetModuleIdInMainMixer, RMGenericPropertyID_FrameInfoForce, 
				&VidFrameInfoForce, sizeof(VidFrameInfoForce), (500*1000)/*timeout us*/, bWaitForDispEvtIfPending);
			if(RM_OK == eRMstatus)
			{
				break;
			}
			else if(RM_PENDING == eRMstatus)
			{
				usleep(10*1000);
			}
			else if(RMFAILED(eRMstatus))
			{
				iOutRet = ERR_RUA_SET_PROP_FAIL;
				break;
			}
			LeftTryTimes--;
			if(0 >= LeftTryTimes)
			{
				iOutRet = ERR_RUA_SET_PENDING;
				break;
			}
		}
		if(ERROR_SUCCESS != iOutRet)
		{
			break;
		}
#endif	
		
		LeftTryTimes = 3;
		while(TRUE)
		{
			eRMstatus = RUASetProperty3(m_RmfpMainContext.pRUA, MainVidScalerTargetModuleIdInMainMixer, RMGenericPropertyID_DisplayAspectRatio, 
				&MainVideoScalerAspectRatio, sizeof(MainVideoScalerAspectRatio), (500*1000)/*timeout us*/, bWaitForDispEvtIfPending);
			if(RM_OK == eRMstatus)
			{
				break;
			}
			else if(RM_PENDING == eRMstatus)
			{
				usleep(10*1000);
			}
			else if(RMFAILED(eRMstatus))
			{
				iOutRet = ERR_RUA_SET_PROP_FAIL;
				break;
			}
			LeftTryTimes--;
			if(0 >= LeftTryTimes)
			{
				iOutRet = ERR_RUA_SET_PENDING;
				break;
			}
		}
		if(ERROR_SUCCESS != iOutRet)
		{
			break;
		}

		LeftTryTimes = 3;
		while(TRUE)
		{
			eRMstatus = RUASetProperty3(m_RmfpMainContext.pRUA, MainVidScalerTargetModuleIdInMainMixer, RMGenericPropertyID_Validate, 
				NULL, 0, (500*1000)/*timeout us*/, bWaitForDispEvtIfPending);
			if(RM_OK == eRMstatus)
			{
				break;
			}
			else if(RM_PENDING == eRMstatus)
			{
				usleep(10*1000);
			}
			else if(RMFAILED(eRMstatus))
			{
				iOutRet = ERR_RUA_SET_PROP_FAIL;
				break;
			}
			LeftTryTimes--;
			if(0 >= LeftTryTimes)
			{
				iOutRet = ERR_RUA_SET_PENDING;
				break;
			}
		}
		if(ERROR_SUCCESS != iOutRet)
		{
			break;
		}

#if	0
		//HDSDConverter
		if(HDSDConverterIsOutput)
		{
			LeftTryTimes = 3;
			while(TRUE)
			{
				eRMstatus = RUASetProperty3(m_RmfpMainContext.pRUA, HDSDConverterModuleId, RMGenericPropertyID_DisplayAspectRatio, 
					&MainVideoScalerAspectRatio, sizeof(MainVideoScalerAspectRatio), (500*1000)/*timeout us*/, bWaitForDispEvtIfPending);
				if(RM_OK == eRMstatus)
				{
					break;
				}
				else if(RM_PENDING == eRMstatus)
				{
					usleep(10*1000);
				}
				else if(RMFAILED(eRMstatus))
				{
					iOutRet = ERR_RUA_SET_PROP_FAIL;
					break;
				}
				LeftTryTimes--;
				if(0 >= LeftTryTimes)
				{
					iOutRet = ERR_RUA_SET_PENDING;
					break;
				}
			}
			if(ERROR_SUCCESS != iOutRet)
			{
				break;
			}
			
			LeftTryTimes = 3;
			while(TRUE)
			{
				eRMstatus = RUASetProperty3(m_RmfpMainContext.pRUA, HDSDConverterModuleId, RMGenericPropertyID_Validate, 
					NULL, 0, (500*1000)/*timeout us*/, bWaitForDispEvtIfPending);
				if(RM_OK == eRMstatus)
				{
					break;
				}
				else if(RM_PENDING == eRMstatus)
				{
					usleep(10*1000);
				}
				else if(RMFAILED(eRMstatus))
				{
					iOutRet = ERR_RUA_SET_PROP_FAIL;
					break;
				}
				LeftTryTimes--;
				if(0 >= LeftTryTimes)
				{
					iOutRet = ERR_RUA_SET_PENDING;
					break;
				}
			}
			if(ERROR_SUCCESS != iOutRet)
			{
				break;
			}
		}
#endif

#if 1 /*Add by xuweiwei 2014-4-2*/
        if( m_CurVidDispAspectRatio != eDispAspectRatio )
        {
            m_CurVidDispAspectRatio = eDispAspectRatio;
        }
#endif 


#if 0/*added by lxj 2012-9-27*/
		if( m_CurVidDispAspectRatio != eDispAspectRatio ){
			SharedPtr <TiXmlDocument2> XmlDoc_sp;
			CGeneralApp * pApp = getApp();
			bool bCreateNodeIfNotExist = TRUE;

			m_CurVidDispAspectRatio = eDispAspectRatio;//save it
			XmlDoc_sp = pApp->getXmlCfgDoc();
			if(XmlDoc_sp.isNull()){
				iOutRet = ERROR_INVALID_STATE;
				break;
			}
			iOutRet = XmlDoc_sp->setElementPropertyValue(XML_DispParam_Ele_PATH, PropDesc_VideoMode, m_CurVidDispAspectRatio, bCreateNodeIfNotExist);
			if(ERROR_SUCCESS != iOutRet){
				LOG_BLINE("Set video display aspect ratio error\n");
				break;
			}
			bool bRet = XmlDoc_sp->SaveFile(MP_SETTING_XML_DOC_PATH);
			if(false == bRet)
			{
				LOG_BLINE("Save video display aspect ratio error\n");
			}
			sync();
		}
#endif		
	}while(FALSE);

	return iOutRet;
}


/*
ThreadContext: Remote
*/
INT_t CMediaSrv::getPlaySpeedCtrl(OUT int & Speed)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	SharedPtr <CMsgData_getPlaySpeedCtrl> MsgData_getPlaySpeedCtrl_sp(new CMsgData_getPlaySpeedCtrl);
	SharedPtr<CMessageQueueItem> ThreadMsg_sp(new CMessageQueueItem);
	SharedPtr <CGenericMsgData> MsgData_sp;

	do
	{
		Speed = 5;	//normal speed
		if(MsgData_getPlaySpeedCtrl_sp.isNull() || ThreadMsg_sp.isNull())
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}
		MsgData_getPlaySpeedCtrl_sp->m_uiMsgId = MSG_CMD_getPlaySpeedCtrl;
		MsgData_sp = MsgData_getPlaySpeedCtrl_sp;
		iRet = ThreadMsg_sp->SetMessageData(MsgData_sp);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}

		iRet = SendMessage(ThreadMsg_sp);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}
		Speed = MsgData_getPlaySpeedCtrl_sp->m_iSpeed;
	}while(FALSE);
	
	return iOutRet;
}

/*
ThreadContext: MediaSrv
*/
PlayMode CMediaSrv::getCurPlayMode()
{
	struct rmfp_main_thread_context_type *pMainContext = &m_RmfpMainContext;	
	PlayMode ePlayMode = PlayMode_Normal;	

	CAutoLock AutoRangeLocker(&m_SharedDataMutex);

	if(RMFP_Playback_state_Playing == pMainContext->current_status.playbackState.state)
	{
		ePlayMode = PlayMode_Normal;
	}
	else if(RMFP_Playback_state_Paused == pMainContext->current_status.playbackState.state)
	{
		ePlayMode = PlayMode_Pause;
	}
	else if(RMFP_Playback_state_Stopped == pMainContext->current_status.playbackState.state ||
		RMFP_Playback_state_Quitting == pMainContext->current_status.playbackState.state)
	{
		ePlayMode = PlayMode_Stopped;		
	}
	else if(RMFP_Playback_state_IForward == pMainContext->current_status.playbackState.state ||
		RMFP_Playback_state_SilentForward == pMainContext->current_status.playbackState.state)
	{
		ePlayMode = PlayMode_FastForward;		
	}
	else if(RMFP_Playback_state_IBackward == pMainContext->current_status.playbackState.state ||
		RMFP_Playback_state_SilentBackward == pMainContext->current_status.playbackState.state)
	{
		ePlayMode = PlayMode_Rewind;		
	}

	return ePlayMode;
}

/*
ThreadContext: main thread(app)
*/
INT_t CMediaSrv::setHdmiAudioOutput(BOOL_t bEnable)
{
	INT_t iOutRet = ERROR_SUCCESS;
	RMstatus eRMstatus = RM_OK;
	struct rmfp_main_thread_context_type *pMainContext = &m_RmfpMainContext;	

	do
	{
		CAutoLock AutoRangeLocker(&m_mutexVideoAudioIoSet); 

		if(NULL == pMainContext->dh_info->hdmi)
		{
			break;
		}
		
		if(bEnable)
		{
			eRMstatus = rmoutput_Unmute_HdmiAudio(pMainContext->dh_info);			
		}
		else	//disable
		{
			eRMstatus = rmoutput_Mute_HdmiAudio(pMainContext->dh_info);
		}
		if(RMFAILED(eRMstatus))
		{
			iOutRet = ERROR_FAILED;
			break;
		}
	}while(FALSE);

	return iOutRet;
}

/*
ThreadContext: any thread
*/
INT_t CMediaSrv::setStereoscopic3DFormat(struct EMhwlibStereoscopic3D * pStereoscopic3D/* = NULL*/)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	RMstatus eRMstatus;
	struct EMhwlibVideoFrameDescription CurVideoFrameInfo, NewVideoFrameInfo;
	struct EMhwlibVideoFrameDescriptionForce VideoFrameInfoForce;
	struct DispRouting_Routing_type CurDispRouting;
	struct rmfp_main_thread_context_type *pMainContext = &m_RmfpMainContext;	
	RMuint32 MainMixerModuleId = EMHWLIB_MODULE(DispMainMixer, 0);

	//LOG_BLINE("CMediaSrv::setStereoscopic3DFormat\n");

	CAutoLock AutoRangeLocker(&m_mutexVideoAudioIoSet); 
	
	do
	{
		//not do if no hdmi
		if(NULL == pMainContext->dh_info->hdmi)
		{
			break;
		}
		//check whether hdmi is configured to output.
		eRMstatus = RUAGetProperty(m_RmfpMainContext.pRUA, DispRouting, RMDispRoutingPropertyID_Routing,
			&CurDispRouting, sizeof(CurDispRouting));
		if(RMFAILED(eRMstatus))
		{
			iOutRet = ERR_RUA_GET_PROP_FAIL;
			break;
		}
		/*
		LOG_BLINE("DigitalOutputEnable=%d,dig_config.OutputModuleID=%d\n", CurDispRouting.DigitalOutputEnable,
			pMainContext->display_conf->dig_config.OutputModuleID);
		*/
		if(FALSE == CurDispRouting.DigitalOutputEnable || 0 == pMainContext->display_conf->dig_config.OutputModuleID)
		{
			break;
		}
		//set it with new values
		if(pStereoscopic3D)
		{
			pMainContext->display_opt->hdmi_options.requestedStereoscopic3D = *pStereoscopic3D;
		}
		else	//use the default value
		{
			pMainContext->display_opt->hdmi_options.requestedStereoscopic3D.Format = EMhwlibStereoscopicFormat_2D;
		}
		pMainContext->display_opt->hdmi_options.bRequestedStereoscopic3D_changed = TRUE;
		pMainContext->display_opt->hdmi_options.bForceSendVsiInfoFrameOnce = TRUE;
		//LOG_BLINE("bRequestedStereoscopic3D_changed\n");
		//emit the 3DFmt change event
		do
		{
			SharedPtr <IMediaSrvEventListener> MediaSrvEvtListener_sp;
			{
				CAutoLock AutoRangeLocker(&m_SharedDataMutex);
				MediaSrvEvtListener_sp = m_MediaSrvEvtListener_wp.Promote();
			}
			if(MediaSrvEvtListener_sp.isNull())
			{
				break;
			}
			iRet = MediaSrvEvtListener_sp->HdmiStereoscopic3DFmt_Changed();
			if(ERROR_SUCCESS != iRet)
			{
				PRINT_BFILE_LINENO_IRET_STR;
			}
			iRet = WakeupMainThread();
			if(ERROR_SUCCESS != iRet)
			{
				PRINT_BFILE_LINENO_IRET_STR;
			}		
		}while(FALSE);

		//strange, it does not take effect to do the following code.
		/*
		eRMstatus = RUAGetProperty(m_RmfpMainContext.pRUA, pMainContext->display_conf->dig_config.OutputModuleID,
			EMHWLIB_GENERIC_PROPERTY(FrameInfo), &CurVideoFrameInfo, sizeof(CurVideoFrameInfo));
		if(RMFAILED(eRMstatus))
		{
			iOutRet = ERR_RUA_GET_PROP_FAIL;
			break;
		}
		LOG_BLINE("Module:%d,Stereoscopic3D.Fmt=%d\n", pMainContext->display_conf->dig_config.OutputModuleID, CurVideoFrameInfo.Stereoscopic3D.Format);

		NewVideoFrameInfo = CurVideoFrameInfo;
		NewVideoFrameInfo.Stereoscopic3D.Format = EMhwlibStereoscopicFormat_OverUnderHalf;		
		{			
			UINT64_t uiStartTimeMs = GetSysUpTimeMs();
			while(TRUE)
			{
				eRMstatus = RUASetProperty(pMainContext->pRUA, pMainContext->display_conf->dig_config.OutputModuleID,
					EMHWLIB_GENERIC_PROPERTY(FrameInfo), &NewVideoFrameInfo, sizeof(NewVideoFrameInfo), 0);
				if(RMSUCCEEDED(eRMstatus))
				{
					break;
				}
				else if(RM_PENDING == eRMstatus && (1*1000 > (GetSysUpTimeMs() - uiStartTimeMs)))
				{
					usleep(5*1000);
				}
				else
				{
					iOutRet = ERR_RUA_SET_PROP_FAIL;
					break;
				}
			}
			if(ERROR_SUCCESS != iOutRet)
			{
				break;
			}
		}

		eRMstatus = RUAGetProperty(m_RmfpMainContext.pRUA, MainMixerModuleId,
			EMHWLIB_GENERIC_PROPERTY(FrameInfo), &CurVideoFrameInfo, sizeof(CurVideoFrameInfo));
		if(RMFAILED(eRMstatus))
		{
			iOutRet = ERR_RUA_GET_PROP_FAIL;
			break;
		}
		LOG_BLINE("Module:%d,Stereoscopic3D.Fmt=%d\n", MainMixerModuleId, CurVideoFrameInfo.Stereoscopic3D.Format);

		NewVideoFrameInfo = CurVideoFrameInfo;
		NewVideoFrameInfo.Stereoscopic3D.Format = EMhwlibStereoscopicFormat_OverUnderHalf;		
		{			
			UINT64_t uiStartTimeMs = GetSysUpTimeMs();
			while(TRUE)
			{
				eRMstatus = RUASetProperty(pMainContext->pRUA, MainMixerModuleId,
					EMHWLIB_GENERIC_PROPERTY(FrameInfo), &NewVideoFrameInfo, sizeof(NewVideoFrameInfo), 0);
				if(RMSUCCEEDED(eRMstatus))
				{
					break;
				}
				else if(RM_PENDING == eRMstatus && (1*1000 > (GetSysUpTimeMs() - uiStartTimeMs)))
				{
					usleep(5*1000);
				}
				else
				{
					iOutRet = ERR_RUA_SET_PROP_FAIL;
					break;
				}
			}
			if(ERROR_SUCCESS != iOutRet)
			{
				break;
			}
		}

		ZeroMemory(&VideoFrameInfoForce, sizeof(VideoFrameInfoForce));
		RMinsShiftBool(&(VideoFrameInfoForce.ForceMask), TRUE, EMHWLIB_FRAMEINFO_BIT_Stereoscopic3D);
		VideoFrameInfoForce.FrameInfo.Stereoscopic3D.Format = EMhwlibStereoscopicFormat_OverUnderHalf;
		{			
			UINT64_t uiStartTimeMs = GetSysUpTimeMs();
			while(TRUE)
			{
				eRMstatus = RUASetProperty(pMainContext->pRUA, pMainContext->display_conf->dig_config.OutputModuleID,
					EMHWLIB_GENERIC_PROPERTY(FrameInfoForce), &VideoFrameInfoForce, sizeof(VideoFrameInfoForce), 0);
				if(RMSUCCEEDED(eRMstatus))
				{
					break;
				}
				else if(RM_PENDING == eRMstatus && (1*1000 > (GetSysUpTimeMs() - uiStartTimeMs)))
				{
					usleep(5*1000);
				}
				else
				{
					iOutRet = ERR_RUA_SET_PROP_FAIL;
					break;
				}
			}
			if(ERROR_SUCCESS != iOutRet)
			{
				break;
			}
		}
		{			
			UINT64_t uiStartTimeMs = GetSysUpTimeMs();
			while(TRUE)
			{
				eRMstatus = RUASetProperty(pMainContext->pRUA, MainMixerModuleId,
					EMHWLIB_GENERIC_PROPERTY(FrameInfoForce), &VideoFrameInfoForce, sizeof(VideoFrameInfoForce), 0);
				if(RMSUCCEEDED(eRMstatus))
				{
					break;
				}
				else if(RM_PENDING == eRMstatus && (1*1000 > (GetSysUpTimeMs() - uiStartTimeMs)))
				{
					usleep(5*1000);
				}
				else
				{
					iOutRet = ERR_RUA_SET_PROP_FAIL;
					break;
				}
			}
			if(ERROR_SUCCESS != iOutRet)
			{
				break;
			}
		}

		eRMstatus = RUAGetProperty(m_RmfpMainContext.pRUA, pMainContext->display_conf->dig_config.OutputModuleID,
			EMHWLIB_GENERIC_PROPERTY(FrameInfo), &CurVideoFrameInfo, sizeof(CurVideoFrameInfo));
		if(RMFAILED(eRMstatus))
		{
			iOutRet = ERR_RUA_GET_PROP_FAIL;
			break;
		}
		LOG_BLINE("Module:%d,Stereoscopic3D.Fmt=%d\n", pMainContext->display_conf->dig_config.OutputModuleID, CurVideoFrameInfo.Stereoscopic3D.Format);

		eRMstatus = RUAGetProperty(m_RmfpMainContext.pRUA, MainMixerModuleId,
			EMHWLIB_GENERIC_PROPERTY(FrameInfo), &CurVideoFrameInfo, sizeof(CurVideoFrameInfo));
		if(RMFAILED(eRMstatus))
		{
			iOutRet = ERR_RUA_GET_PROP_FAIL;
			break;
		}
		LOG_BLINE("Module:%d,Stereoscopic3D.Fmt=%d\n", MainMixerModuleId, CurVideoFrameInfo.Stereoscopic3D.Format);
		*/
	}while(FALSE);
	
	return iOutRet;
}

/*
ThreadContext: main thread
*/
VOID CMediaSrv::DelayedSet_VcrDefaultSurface(OUT BOOL_t & bNeedUnregTimer)
{
	RMstatus eRMstatus = RM_OK;
	INT_t iRet;
	struct rmfp_main_thread_context_type *pMainContext = &m_RmfpMainContext;
	struct RUA * pRua = pMainContext->pRUA;
	RMuint32 DigLostPixelsSinceLast = 0;
	INT64_t ChkDigLostPixel_TimeDiff_Ms = 0;
	BOOL_t bLocked = FALSE;
	RMuint32 tryIntervalMsIfPending = 30;
	RMuint32 tryTimesIfPending = 5;
	
	bNeedUnregTimer = TRUE;

	do
	{
		if(FALSE == bLocked)
		{
			iRet = m_mutexVideoAudioIoSet.TryLock();
			if(ERROR_SUCCESS == iRet)
			{
				bLocked = TRUE;
			}
			else if(ERR_BUSY == iRet)
			{
				bNeedUnregTimer = FALSE;	//continue the timer check on next time
				break;
			}
			else
			{
				PRINT_BFILE_LINENO_IRET_STR;
				break;
			}
		}
		
		if(FALSE == (VO_MODE_SPLIT_MODE_MIN_BOUNDARY < m_eVoMode && m_eVoMode < VO_MODE_SPLIT_MODE_MAX_BOUNDARY))
		{
			break;
		}
		if(VO_MODE_SPLIT_HdmiMain_1080p60_VgaVcr == m_eVoMode)
		{
			bNeedUnregTimer = TRUE;	//stop the timer
			break;
		}
		
		struct RMFPOptions *pRmfpOptions = &m_RmfpOptions;
		struct RMFPVideoOptions * pRmfpVideoOpts = &(pRmfpOptions->video_options);
		RMuint32 VideoDecoderModuleId = EMHWLIB_MODULE(VideoDecoder, (2 * pRmfpVideoOpts->EngineIndex) + pRmfpVideoOpts->DecoderIndex);
		RMuint32 VidDecFrameCnt;
		eRMstatus = RUAGetProperty2(pRua, VideoDecoderModuleId, RMVideoDecoderPropertyID_FrameCounter, 
			&VidDecFrameCnt, sizeof(VidDecFrameCnt));
		if(RMFAILED(eRMstatus))
		{
			PRINT_BFILE_LINENO_RMSTATUS;
			VidDecFrameCnt = 0;
		}
		//LOG_BLINE("VidDecModuleId:0x%08x,FrameCnt=%d\n", VideoDecoderModuleId, VidDecFrameCnt);
		RMuint32 DispDigOutModuleId = EMHWLIB_MODULE(DispDigitalOut, 0);
		RMuint32 DigLostPixels;
		eRMstatus = RUAGetProperty2(pRua, DispDigOutModuleId, RMGenericPropertyID_LostPixel, &DigLostPixels, sizeof(DigLostPixels));
		if(RMFAILED(eRMstatus))
		{
			PRINT_BFILE_LINENO_RMSTATUS;
			DigLostPixels = 0;
		}
		//LOG_BLINE("DigLostPixels=%d\n", DigLostPixels);
		if(DigLostPixels > m_Cur_DigLostPixels)
		{
			DigLostPixelsSinceLast = DigLostPixels - m_Cur_DigLostPixels;
		}
		else if(DigLostPixels < m_Cur_DigLostPixels)
		{
			DigLostPixelsSinceLast = (0xFFFFFFFFU - (m_Cur_DigLostPixels - DigLostPixels));
		}
		else
		{
			DigLostPixelsSinceLast = 0;
		}
		m_Cur_DigLostPixels = DigLostPixels;
		if(0 == m_Prev_ChkDigLostPixel_TimeMs)
		{
			ChkDigLostPixel_TimeDiff_Ms = 0;
		}
		else
		{
			ChkDigLostPixel_TimeDiff_Ms = GetSysUpTimeMs() - m_Prev_ChkDigLostPixel_TimeMs;
		}
		m_Prev_ChkDigLostPixel_TimeMs = GetSysUpTimeMs();
		//LOG_BLINE("VidDecFrameCnt=%lu,DigLostPixelsSinceLast=%lu,ChkDigLostPixel_TimeDiff_Ms=%lld\n", 
		//	VidDecFrameCnt, DigLostPixelsSinceLast, ChkDigLostPixel_TimeDiff_Ms);
		if(80 <= VidDecFrameCnt && (0 == DigLostPixelsSinceLast && (2*1000) <= ChkDigLostPixel_TimeDiff_Ms))
		{
			//VideoDecoder has played for a while and no pixels lost and time elapsed for more than 2 seconds, so we can set DefaultSurface.
			RMuint32 VcrScalerModuleId = EMHWLIB_MODULE(DispVCRMultiScaler, 0);
			RMuint32 VcrDefaultSurface = 0;
			struct DisplayBlock_SurfaceSize_in_type DispBlk_SurfaceSize_in;
			struct DisplayBlock_SurfaceSize_out_type DispBlk_SurfaceSize_out;
			RMuint32 BlkSurface_LumaAddr = 0;
			BOOL_t bBlackSurface_LumaAddr_IsLocked = FALSE;
			RMuint32 BlkSurface_LumaSize = 0;
			RMuint8 * pBlkSurface_Luma_VirAddr = 0;
			BOOL_t bBlkSurface_LumaAddr_IsMapped = FALSE;
			
			do
			{
				eRMstatus = RUAGetProperty2(pRua, VcrScalerModuleId, RMGenericPropertyID_DefaultSurface, &VcrDefaultSurface, sizeof(VcrDefaultSurface));
				if(RMSUCCEEDED(eRMstatus))
				{					
				}
				else
				{
					PRINT_BFILE_LINENO_RMSTATUS;
					VcrDefaultSurface = 0;
					break;
				}
				if(VcrDefaultSurface)	//set already
				{
					break;
				}
				
				ZeroMemory(&DispBlk_SurfaceSize_in, sizeof(DispBlk_SurfaceSize_in));
				DispBlk_SurfaceSize_in.ColorMode = EMhwlibColorMode_TrueColor;
				DispBlk_SurfaceSize_in.ColorFormat = EMhwlibColorFormat_32BPP;
				DispBlk_SurfaceSize_in.SamplingMode = EMhwlibSamplingMode_None;
				DispBlk_SurfaceSize_in.Width = 1;
				DispBlk_SurfaceSize_in.Height = 1;
			
				eRMstatus = RUAExchangeProperty2(pRua, DisplayBlock, RMDisplayBlockPropertyID_SurfaceSize, &DispBlk_SurfaceSize_in,
					sizeof(DispBlk_SurfaceSize_in), &DispBlk_SurfaceSize_out, sizeof(DispBlk_SurfaceSize_out));
				if(RMFAILED(eRMstatus))
				{
					PRINT_BFILE_LINENO_RMSTATUS;
					break;
				}
			
				if(m_BlackSurfaceAddr)
				{
					RUAFree(pRua, m_BlackSurfaceAddr);
					m_BlackSurfaceAddr = 0;
				}
			
				m_BlackSurfaceAddr = RUAMalloc(pMainContext->pRUA, 0, RUA_DRAM_UNCACHED, DispBlk_SurfaceSize_out.BufferSize);
				if(0 == m_BlackSurfaceAddr)
				{
					LOG_BLINE("Failed to RUAMalloc(%d).\n", DispBlk_SurfaceSize_out.BufferSize);
					break;
				}
			
				struct DisplayBlock_InitSurface_in_type DispBlk_InitSurface_in;
				struct DisplayBlock_InitSurface_out_type DispBlk_InitSurface_out;
				ZeroMemory(&DispBlk_InitSurface_in, sizeof(DispBlk_InitSurface_in));
				DispBlk_InitSurface_in.ColorMode = DispBlk_SurfaceSize_in.ColorMode;
				DispBlk_InitSurface_in.ColorFormat = DispBlk_SurfaceSize_in.ColorFormat;
				DispBlk_InitSurface_in.SamplingMode = DispBlk_SurfaceSize_in.SamplingMode;
				DispBlk_InitSurface_in.Width = DispBlk_SurfaceSize_in.Width;
				DispBlk_InitSurface_in.Height = DispBlk_SurfaceSize_in.Height;
				DispBlk_InitSurface_in.Address = m_BlackSurfaceAddr;
				DispBlk_InitSurface_in.LumaSize = DispBlk_SurfaceSize_out.LumaSize;
				DispBlk_InitSurface_in.ChromaSize = DispBlk_SurfaceSize_out.ChromaSize;
				DispBlk_InitSurface_in.ColorSpace = EMhwlibColorSpace_RGB_0_255;
				DispBlk_InitSurface_in.PixelAspectRatio.X = 0;
				DispBlk_InitSurface_in.PixelAspectRatio.Y = 0;
				eRMstatus = RUAExchangeProperty2(pMainContext->pRUA, DisplayBlock, RMDisplayBlockPropertyID_InitSurface,
					&DispBlk_InitSurface_in, sizeof(DispBlk_InitSurface_in), &DispBlk_InitSurface_out, sizeof(DispBlk_InitSurface_out));
				if(RMFAILED(eRMstatus))
				{
					PRINT_BFILE_LINENO_RMSTATUS;
					break;
				}
			
				BlkSurface_LumaAddr = DispBlk_InitSurface_out.LumaAddress;
				BlkSurface_LumaSize = DispBlk_InitSurface_in.LumaSize;
				if(FALSE == bBlackSurface_LumaAddr_IsLocked)
				{					
					eRMstatus = RUALock(pRua, DispBlk_InitSurface_out.LumaAddress, DispBlk_InitSurface_in.LumaSize);
					if(RMFAILED(eRMstatus))
					{
						PRINT_BFILE_LINENO_RMSTATUS;
						break;
					}
					bBlackSurface_LumaAddr_IsLocked = TRUE;
				}				
				pBlkSurface_Luma_VirAddr = RUAMap(pRua, DispBlk_InitSurface_out.LumaAddress, DispBlk_InitSurface_in.LumaSize);
				if(NULL == pBlkSurface_Luma_VirAddr)
				{
					LOG_BLINE("RuaMap(0x%08x,%d) err\n", DispBlk_InitSurface_out.LumaAddress, DispBlk_InitSurface_in.LumaSize);
					break;
				}
				bBlkSurface_LumaAddr_IsMapped = TRUE;
				ZeroMemory((PVOID)(pBlkSurface_Luma_VirAddr), DispBlk_InitSurface_in.LumaSize);
				if(bBlkSurface_LumaAddr_IsMapped)
				{
					bBlkSurface_LumaAddr_IsMapped = FALSE;
					if(pBlkSurface_Luma_VirAddr)
					{
						RUAUnMap(pRua, pBlkSurface_Luma_VirAddr, BlkSurface_LumaSize);
						pBlkSurface_Luma_VirAddr = NULL;
					}
				}
				if(bBlackSurface_LumaAddr_IsLocked)
				{
					bBlackSurface_LumaAddr_IsLocked = FALSE;
					if(BlkSurface_LumaAddr && 0 < BlkSurface_LumaSize)
					{
						eRMstatus = RUAUnLock(pRua, BlkSurface_LumaAddr, BlkSurface_LumaSize);
						if(RMFAILED(eRMstatus))
						{
							PRINT_BFILE_LINENO_RMSTATUS;
						}
					}
				}
				RMuint32 NullSurfaceAddr = 0;
				eRMstatus = RuaSetProp5(pMainContext->pRUA, VcrScalerModuleId, RMGenericPropertyID_DefaultSurface,
					&NullSurfaceAddr, sizeof(NullSurfaceAddr), tryTimesIfPending, tryIntervalMsIfPending);
				if(RMSUCCEEDED(eRMstatus))
				{
					eRMstatus = RuaSetProp5(pMainContext->pRUA, VcrScalerModuleId, RMGenericPropertyID_Validate, NULL, 0, 
						tryTimesIfPending, tryIntervalMsIfPending);
					if(RMFAILED(eRMstatus))
					{
						PRINT_BFILE_LINENO_RMSTATUS;
					}
				}
				else
				{
					PRINT_BFILE_LINENO_RMSTATUS;
				}
				eRMstatus = RuaSetProp5(pMainContext->pRUA, VcrScalerModuleId, RMGenericPropertyID_DefaultSurface,
					&m_BlackSurfaceAddr, sizeof(m_BlackSurfaceAddr), tryTimesIfPending, tryIntervalMsIfPending);
				if(RMSUCCEEDED(eRMstatus))
				{
					eRMstatus = RuaSetProp5(pMainContext->pRUA, VcrScalerModuleId, RMGenericPropertyID_Validate, NULL, 0, 
						tryTimesIfPending, tryIntervalMsIfPending);
					if(RMSUCCEEDED(eRMstatus))
					{
						eRMstatus = RUAGetProperty2(pMainContext->pRUA, VcrScalerModuleId, RMGenericPropertyID_DefaultSurface, 
							&VcrDefaultSurface, sizeof(VcrDefaultSurface));
						if(RMSUCCEEDED(eRMstatus))
						{
							
						}
						else
						{
							PRINT_BFILE_LINENO_RMSTATUS;
							VcrDefaultSurface = 0;
						}
						LOG_BLINE("VcrDefaultSurface=0x%08x\n", VcrDefaultSurface);
					}
					else
					{
						PRINT_BFILE_LINENO_RMSTATUS;
					}
				}
				else
				{
					PRINT_BFILE_LINENO_RMSTATUS;
				}
			}while(FALSE);
			
			if(bBlkSurface_LumaAddr_IsMapped)
			{
				bBlkSurface_LumaAddr_IsMapped = FALSE;
				if(pBlkSurface_Luma_VirAddr)
				{
					RUAUnMap(pRua, pBlkSurface_Luma_VirAddr, BlkSurface_LumaSize);
					pBlkSurface_Luma_VirAddr = NULL;
				}
			}
			
			if(bBlackSurface_LumaAddr_IsLocked)
			{
				bBlackSurface_LumaAddr_IsLocked = FALSE;
				if(BlkSurface_LumaAddr && 0 < BlkSurface_LumaSize)
				{
					eRMstatus = RUAUnLock(pRua, BlkSurface_LumaAddr, BlkSurface_LumaSize);
					if(RMFAILED(eRMstatus))
					{
						PRINT_BFILE_LINENO_RMSTATUS;
					}
				}
			}
			break;
		}
		bNeedUnregTimer = FALSE;	//continue the timer
	}while(FALSE);

	if(bLocked)
	{
		iRet = m_mutexVideoAudioIoSet.Unlock();
		if(ERROR_SUCCESS == iRet)
		{
			bLocked = FALSE;
		}
		else
		{
			PRINT_BFILE_LINENO_IRET_STR;
		}
	}	
}

INT_t CMediaSrv::getCpuSerialNo(OUT CStackBufString & strCpuSerialNo)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	char szLrroXenvData[LRRO_SIZE];
	XENV_RECORD_LIST oLrroXenvRecordList;
	XENV_RECORD_LIST::iterator itXenvRecordItem;
	SharedPtr <XENV_RECORD_ITEM> XenvRecordItem_sp;
	BOOL_t bFound = FALSE;

	do
	{
		if(NULL == m_pGbus)
		{
			iOutRet = ERROR_INVALID_STATE;
			break;
		}
		gbus_read_data8(m_pGbus, (REG_BASE_cpu_block+LR_XENV2_RO), (RMuint8 *)szLrroXenvData, sizeof(szLrroXenvData));
		iRet = getXenvRecordList((PBYTE)szLrroXenvData, sizeof(szLrroXenvData), OUT oLrroXenvRecordList);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}
		for(itXenvRecordItem = oLrroXenvRecordList.begin(); itXenvRecordItem != oLrroXenvRecordList.end(); itXenvRecordItem++)
		{
			XenvRecordItem_sp = *itXenvRecordItem;
			if(XenvRecordItem_sp.isNull())
			{
				PRINT_BFILE_LINENO_BUG_STR;
				continue;
			}
			if(XenvRecordItem_sp->Name.Equal("lrro.serial"))
			{
				//LOG_BLINE("lrro.serial->DataSize=%d\n", XenvRecordItem_sp->Value.GetSize());
				if(16 <= XenvRecordItem_sp->Value.GetSize())
				{
					bFound = TRUE;
					iRet = strCpuSerialNo.Format("%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x",
						XenvRecordItem_sp->Value[15], XenvRecordItem_sp->Value[14], XenvRecordItem_sp->Value[13],
						XenvRecordItem_sp->Value[12], XenvRecordItem_sp->Value[11], XenvRecordItem_sp->Value[10],
						XenvRecordItem_sp->Value[9], XenvRecordItem_sp->Value[8], XenvRecordItem_sp->Value[7], 
						XenvRecordItem_sp->Value[6], XenvRecordItem_sp->Value[5], XenvRecordItem_sp->Value[4], 
						XenvRecordItem_sp->Value[3], XenvRecordItem_sp->Value[2], XenvRecordItem_sp->Value[1], 
						XenvRecordItem_sp->Value[0]);
					if(ERROR_SUCCESS != iRet)
					{
						iOutRet = iRet;
						break;
					}
				}
				break;
			}
		}
		if(ERROR_SUCCESS != iOutRet)
		{
			break;
		}
		if(FALSE == bFound)
		{
			iOutRet = ERROR_NOT_FOUND;
			break;
		}
	}while(FALSE);

	return iOutRet;
}

INT_t CMediaSrv::getOsdImgSurfaceInfo(SharedPtr <CImageSurface> & ImgSurface_sp)
{
	INT_t iOutRet = ERROR_SUCCESS;
	RMstatus eRMstatus;
	struct rmfp_main_thread_context_type *pMainContext = &m_RmfpMainContext;
	RMuint32 OsdScalerModuleId;
	RMuint32 OsdSurfaceAddr;
	struct DisplayBlock_SurfaceInfo_out_type OsdSurfaceInfo;

	do
	{
		if(ImgSurface_sp.isNull())
		{
			ImgSurface_sp = SharedPtr <CImageSurface> (new CImageSurface);
			if(ImgSurface_sp.isNull())
			{
				iOutRet = ERROR_OUT_OF_MEMORY;
				break;
			}
		}
		eRMstatus = DCCGetScalerModuleID(pMainContext->pDCC, DCCRoute_Main, DCCSurface_OSD, 0, &OsdScalerModuleId);
		if(RMFAILED(eRMstatus))
		{
			PRINT_BFILE_LINENO_RMSTATUS;
			iOutRet = ERROR_INVALID_STATE;
			break;
		}
		eRMstatus = RUAGetProperty2(pMainContext->pRUA, OsdScalerModuleId, RMGenericPropertyID_Surface,
			&OsdSurfaceAddr, sizeof(OsdSurfaceAddr));
		if(RMFAILED(eRMstatus))
		{
			PRINT_BFILE_LINENO_RMSTATUS;
			iOutRet = ERROR_INVALID_STATE;
			break;
		}
		eRMstatus = RUAExchangeProperty(pMainContext->pRUA, DisplayBlock, RMDisplayBlockPropertyID_SurfaceInfo, 
			&OsdSurfaceAddr, sizeof(OsdSurfaceAddr), &OsdSurfaceInfo, sizeof(OsdSurfaceInfo));
		if(RMFAILED(eRMstatus))
		{
			iOutRet = ERR_RUA_EXCHANGE_PROP_FAIL;
			break;
		}
		ImgSurface_sp->m_pImgBufVirtAddr = (typeof(ImgSurface_sp->m_pImgBufVirtAddr))OsdSurfaceInfo.LumaAddress;
		if(EMhwlibColorMode_TrueColor == OsdSurfaceInfo.ColorMode && 
			EMhwlibColorFormat_32BPP == OsdSurfaceInfo.ColorFormat)
		{
			ImgSurface_sp->m_eColorFmtType = COLOR_FMT_32BPP_ARGB;
		}
		else
		{
			ImgSurface_sp->m_eColorFmtType = COLOR_FMT_UNKNOWN;
		}
		ImgSurface_sp->m_ImgWidth = OsdSurfaceInfo.Width;
		ImgSurface_sp->m_ImgHeight = OsdSurfaceInfo.Height;
	}while(FALSE);

	return iOutRet;
}

VOID CMediaSrv::OnTimer(UINT_t TimerId)
{
	if(TimerId == m_idProcessTunerTaskTimer)
	{
#ifdef ENABLE_DTV
		ProcessEventForTuneProgram();
#endif	//ENABLE_DTV
	}
}

INT_t CMediaSrv::setHdmi3DTvMode(CONST HDMI_3D_TV_MODE eHdmi3DTvMode)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	struct rmfp_main_thread_context_type *pMainContext = &m_RmfpMainContext;

	CAutoLock AutoRangeLocker(&m_mutexVideoAudioIoSet);

	do
	{
		if(FALSE == (H3DTvMode_MinValue <= eHdmi3DTvMode && H3DTvMode_MaxValue >= eHdmi3DTvMode))
		{
			iOutRet = ERROR_INVALID_PARAMETER;
			break;
		}
		if(VO_MODE_SPLIT_MODE_MIN_BOUNDARY < m_eVoMode && VO_MODE_SPLIT_MODE_MAX_BOUNDARY > m_eVoMode)	//split HDMI+VGA
		{
			//need not switch to 2D
			break;
		}
		m_eHdmi3DTvMode = eHdmi3DTvMode;
		if(H3DTvMode_Normal == m_eHdmi3DTvMode)
		{
			iRet = setStereoscopic3DFormat(&m_CurRightStereoscopic3D);
			if(CC_UNLIKELY(ERROR_SUCCESS != iRet))
			{
				PRINT_BFILE_LINENO_IRET_STR;
			}
		}
		else if(H3DTvMode_Force2D == m_eHdmi3DTvMode)
		{
			//no arguments, will use default 2D.
			iRet = setStereoscopic3DFormat();
			if(CC_UNLIKELY(ERROR_SUCCESS != iRet))
			{
				PRINT_BFILE_LINENO_IRET_STR;
			}
		}
	}while(FALSE);

	return iOutRet;
}

/*
Thread context: any
*/
INT_t CMediaSrv::setAnalogAudioMute(CONST BOOL_t bMute)
{	
	INT_t iOutRet = ERROR_SUCCESS, iRet;

	CAutoLock AutoRangeLocker(&m_mutexVideoAudioIoSet);

	do
	{
		CSmp86xxGpioCtrl gpioCtrl;
		do
		{
			if (FALSE == gpioCtrl.ChkInit()) {
				iOutRet = ERR_INIT_FAIL;
				break;
			}
		
			iRet = gpioCtrl.setGpioDirection(GPIOId_Sys_10, GPIO_OUTPUT);
			if (ERROR_SUCCESS != iRet) {
				iOutRet = iRet;
				break;
			}
			iRet = gpioCtrl.setGpioData(GPIOId_Sys_10, (bMute?1:0));
			if (ERROR_SUCCESS != iRet) {
				iOutRet = iRet;
				break;
			}
		}while(FALSE);
	}while(FALSE);

	return iOutRet;
}

INT_t CMediaSrv::setMruaOutputSpdifMode(INT_t iSnmpOutSpdifMode)
{
	INT_t iOutRet = ERROR_SUCCESS;
	RMstatus eRMstatus;
	struct rmfp_main_thread_context_type *pMainContext = &m_RmfpMainContext;	

	pMainContext->display_opt->audio_options.SPDIF = getMruaOutSpdifTypeFromSnmpMode((Mp7xxCommon::SNMP_OUTPUT_SPDIF_MODE)iSnmpOutSpdifMode);
	RMinsShiftBool(&(pMainContext->display_opt->audio_options.SPDIF), pMainContext->display_opt->audio_options.HDMIPassThrough, 8);
	pMainContext->display_opt->audio_options.SPDIFSET = TRUE;

	//LOG_BLINE("SPDIF=%04x\n", pMainContext->display_opt->audio_options.SPDIF);

	if(OutputSpdif_Disable == pMainContext->display_opt->audio_options.SPDIF) {
	} else {	
		if(-1 != pMainContext->display_opt->audio_options.EngineIndex)
		{
			eRMstatus = Rmoutput_AudEng_setOutputMode(pMainContext->dh_info, pMainContext->pHWLib, &(pMainContext->display_opt->audio_options));
			if(RMFAILED(eRMstatus))
			{
				PRINT_BFILE_LINENO_RMSTATUS;
			}
		}
	}
	eRMstatus = Rmoutput_AudEng_setSpdifOut(pMainContext->dh_info, pMainContext->pHWLib, &(pMainContext->display_opt->audio_options));
	if(RMFAILED(eRMstatus))
	{
		PRINT_BFILE_LINENO_RMSTATUS;
	}

	return iOutRet;
}

INT_t CMediaSrv::setMruaVideoRotationMode(INT_t iSnmpVideoRotationMode)
{
	INT_t iOutRet = ERROR_SUCCESS;
	RMstatus eRMstatus;
	struct rmfp_main_thread_context_type *pMainContext = &m_RmfpMainContext;
	pMainContext->pOptions->playback_options.PTOrientation=getMruaVideoRotationTypeFromSnmpMode((Mp7xxCommon::VIDEO_ROTATION_t)iSnmpVideoRotationMode);   
	pMainContext->pOptions->playback_options.PTEnable=TRUE;
	if(EMhwlibPictureOrientation_0 == pMainContext->pOptions->playback_options.PTOrientation)
		pMainContext->pOptions->playback_options.PTEnable=FALSE; 

	m_Cur_PTOrientation=pMainContext->pOptions->playback_options.PTOrientation;
	m_Cur_PTEnable=pMainContext->pOptions->playback_options.PTEnable;

	return iOutRet;    
}

INT_t CMediaSrv::setEnAudio6Channel(BOOL_t iEnAudio6ChFlag)
{
	INT_t iOutRet = ERROR_SUCCESS;
	RMstatus eRMstatus;
	struct rmfp_main_thread_context_type *pMainContext = &m_RmfpMainContext;	
	if(iEnAudio6ChFlag)
	{
		pMainContext->display_opt->audio_options.ChannelConfig=Audio_Out_Ch_LCRLsRsSs;
		pMainContext->display_opt->audio_options.ChannelConfigSET=TRUE;
		pMainContext->display_opt->audio_options.LFESET=TRUE;
		pMainContext->display_opt->audio_options.LFE=TRUE;
	}
	else
	{
		pMainContext->display_opt->audio_options.ChannelConfig=Audio_Out_Ch_LR;
		pMainContext->display_opt->audio_options.ChannelConfigSET=TRUE;
		pMainContext->display_opt->audio_options.LFESET=TRUE;
		pMainContext->display_opt->audio_options.LFE=FALSE;
	}
	return iOutRet;
}

INT_t CMediaSrv::setPlayPrebufMax(CONST UINT32_t prebufMaxInBytes)
{
	INT_t iOutRet = ERR_SUCCESS;
	struct rmfp_main_thread_context_type *pMainContext = &m_RmfpMainContext;	

	pMainContext->pOptions->playback_options.prebuf_max = prebufMaxInBytes;

	return iOutRet;
}

INT_t CMediaSrv::setHdmiCecCtrl(CONST HDMI_CEC_CTRL_CMD eHdmiCecCtrlCmd)
{
	INT_t iOutRet = ERROR_SUCCESS;
	struct rmfp_main_thread_context_type *pMainContext = &m_RmfpMainContext;	
	int iOutUpdateCnt = 0;

	do
	{
		CAutoLock AutoRangeLocker(&m_mutexVideoAudioIoSet);
		
		if(NULL == pMainContext->dh_info->hdmi)
		{
			iOutRet = ERROR_INVALID_STATE;
			break;
		}
		if(HdmiCecCtrlCmd_ImageViewOn == eHdmiCecCtrlCmd)
		{
			pMainContext->dh_info->CEC.RequestImageViewOn = TRUE;
			iOutUpdateCnt++;
			pMainContext->dh_info->CEC.RequestStandby = FALSE;
		}
		else if(HdmiCecCtrlCmd_Standby == eHdmiCecCtrlCmd)
		{
			pMainContext->dh_info->CEC.RequestStandby = TRUE;
			iOutUpdateCnt++;
			pMainContext->dh_info->CEC.RequestImageViewOn = FALSE;
		}
		else if(HdmiCecCtrlCmd_VolumeUp == eHdmiCecCtrlCmd)
		{
			pMainContext->dh_info->CEC.RequestAudioVolumeUpPressed = TRUE;
			iOutUpdateCnt++;
			pMainContext->dh_info->CEC.RequestAudioVolumeUpReleased = TRUE;
			iOutUpdateCnt++;
			pMainContext->dh_info->CEC.RequestAudioMutePressed = FALSE;
			pMainContext->dh_info->CEC.RequestAudioMuteReleased = FALSE;
		}
		else if(HdmiCecCtrlCmd_VolumeDown == eHdmiCecCtrlCmd)
		{
			pMainContext->dh_info->CEC.RequestAudioVolumeDownPressed = TRUE;
			iOutUpdateCnt++;
			pMainContext->dh_info->CEC.RequestAudioVolumeDownReleased = TRUE;
			iOutUpdateCnt++;
			pMainContext->dh_info->CEC.RequestAudioMutePressed = FALSE;
			pMainContext->dh_info->CEC.RequestAudioMuteReleased = FALSE;
		}
		else if(HdmiCecCtrlCmd_VolumeMute == eHdmiCecCtrlCmd)
		{
			pMainContext->dh_info->CEC.RequestAudioMutePressed = TRUE;
			iOutUpdateCnt++;
			pMainContext->dh_info->CEC.RequestAudioMuteReleased = TRUE;
			iOutUpdateCnt++;
			pMainContext->dh_info->CEC.RequestAudioVolumeUpPressed = FALSE;
			pMainContext->dh_info->CEC.RequestAudioVolumeUpReleased = FALSE;
			pMainContext->dh_info->CEC.RequestAudioVolumeDownPressed = FALSE;
			pMainContext->dh_info->CEC.RequestAudioVolumeDownReleased = FALSE;
		}
		else
		{
			iOutRet = ERROR_INVALID_PARAMETER;
			break;
		}
		//apply immediately
		{
			int iCnt = iOutUpdateCnt;
			while(0 < iCnt--)
			{
				OutputDisplayUpdate();
				usleep(0);
			}
		}
	}while(false);
	
	return iOutRet;
}

INT_t CMediaSrv::setShowClosedCaption(CONST ClosedCaption_SELECTION eCcSel)
{
	INT_t iOutRet = ERR_SUCCESS, iRet;
	SharedPtr <CGenericMsgData> MsgData_sp(new CGenericMsgData);
	SharedPtr<CMessageQueueItem> ThreadMsg_sp(new CMessageQueueItem);

	if(MsgData_sp.isNull() || ThreadMsg_sp.isNull())
	{
		iOutRet = ERROR_OUT_OF_MEMORY;
		goto EXIT_PROC;
	}
	
	MsgData_sp->m_uiMsgId = MSG_CMD_setShowClosedCaption;
	MsgData_sp->m_uiParam = eCcSel;
	iRet = ThreadMsg_sp->SetMessageData(MsgData_sp);
	if(ERROR_SUCCESS != iRet)
	{
		iOutRet = iRet;
		goto EXIT_PROC;
	}
	
	iRet = SendMessage(ThreadMsg_sp);
	if(ERROR_SUCCESS != iRet)
	{
		iOutRet = iRet;
		goto EXIT_PROC;
	}
	iOutRet = MsgData_sp->m_iOutRet;

EXIT_PROC:
	return iOutRet;
}

INT_t CMediaSrv::getShowClosedCaption(ClosedCaption_SELECTION &eCcSel)
{
	INT_t iRet = ERROR_SUCCESS;

	do
	{
		eCcSel = m_eShowClosedCaption;
	}while(FALSE);

	return iRet;
}

#if 1 /*------Add by xuweiwei 2014-2-18------*/
INT_t CMediaSrv::setVideoRotation(IN const INT32_t VideoRotationMode)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	SharedPtr <CMsgData_setVideoRotation> MsgData_setVideoRotation_sp(new CMsgData_setVideoRotation);
	SharedPtr<CMessageQueueItem> ThreadMsg_sp(new CMessageQueueItem);
	SharedPtr <CGenericMsgData> MsgData_sp;

	do
	{
		if(MsgData_setVideoRotation_sp.isNull() || ThreadMsg_sp.isNull())
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}
		MsgData_setVideoRotation_sp->m_uiMsgId = MSG_CMD_setVideoRotation;
		MsgData_setVideoRotation_sp->m_iVideoRotationMode = VideoRotationMode;
		MsgData_sp = MsgData_setVideoRotation_sp;
		iRet = ThreadMsg_sp->SetMessageData(MsgData_sp);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}
		iRet = SendMessage(ThreadMsg_sp);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}       
		iOutRet = MsgData_sp->m_iOutRet;
	}while(FALSE);    
	return iOutRet;
}

INT_t CMediaSrv::getVideoRotation(INT32_t * pVideoRotationMode)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	DECLARE_CLS_STACK_BUF_STRING(strVideoRotationMode, 64);
	CStackBufString::SCANF_PARAM oScanfParam;
	CStackBufString::ScanfParam_Init(&oScanfParam);

	do{
		if(NULL == pVideoRotationMode)
		{
			iOutRet = ERROR_INVALID_PARAMETER;
			break;
		}
		
		iRet = SysProp_get(SysProp_KEY_VideoRotationMode, OUT strVideoRotationMode);
		if(ERROR_SUCCESS == iRet)
		{
			iRet = strVideoRotationMode.Scanf(IN OUT oScanfParam, "%d", pVideoRotationMode);
			if(ERROR_SUCCESS != iRet)
			{
				//PRINT_BFILE_LINENO_IRET_STR;
				iOutRet = iRet;
				break;
			}
		}
		else
		{
			*pVideoRotationMode = 0;
		}
	}while(FALSE);

	return iOutRet;
}

#endif

INT_t CMediaSrv::setEnableAudio6Ch(BOOL_t iEnAudio6ChFlag)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	SharedPtr <CMsgData_setEnableAudio6Ch> MsgData_setEnableAudio6Ch_sp(new CMsgData_setEnableAudio6Ch);
	SharedPtr<CMessageQueueItem> ThreadMsg_sp(new CMessageQueueItem);
	SharedPtr <CGenericMsgData> MsgData_sp;

	do
	{
		if(MsgData_setEnableAudio6Ch_sp.isNull() || ThreadMsg_sp.isNull())
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}
		MsgData_setEnableAudio6Ch_sp->m_uiMsgId = MSG_CMD_setEnableAudio6Ch;
		MsgData_setEnableAudio6Ch_sp->m_iEnAudio6ChFlag = iEnAudio6ChFlag;
		MsgData_sp = MsgData_setEnableAudio6Ch_sp;
		iRet = ThreadMsg_sp->SetMessageData(MsgData_sp);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}
		iRet = SendMessage(ThreadMsg_sp);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}       
		iOutRet = MsgData_sp->m_iOutRet;
	}while(FALSE);    
	return iOutRet;
}

INT_t CMediaSrv::getEnableAudio6Ch(BOOL_t& oEnAudio6ChFlag)
{
    INT_t iOutRet = ERROR_SUCCESS, iRet;
    SharedPtr<CMessageQueueItem> ThreadMsg_sp(new CMessageQueueItem);
    SharedPtr <CGenericMsgData> MsgData_sp;

    do
    {
        if(ThreadMsg_sp.isNull())
        {
            iOutRet = ERROR_OUT_OF_MEMORY;
            break;
        }

        MsgData_sp = SharedPtr <CGenericMsgData> (new CGenericMsgData);
        if(MsgData_sp.isNull())
        {
            iOutRet = ERROR_OUT_OF_MEMORY;
            break;
        }
		
        MsgData_sp->m_uiMsgId = MSG_CMD_getEnableAudio6Ch;
        iRet = ThreadMsg_sp->SetMessageData(MsgData_sp);
        if(ERROR_SUCCESS != iRet)
        {
            iOutRet = iRet;
            break;
        }

        iRet = SendMessage(ThreadMsg_sp);
        if(ERROR_SUCCESS != iRet)
        {
            iOutRet = iRet;
            break;
        }
        iOutRet = MsgData_sp->m_iOutRet;
	 oEnAudio6ChFlag = (BOOL_t)(MsgData_sp->m_uiParam);
    }while(FALSE);

	return iOutRet;
}

INT_t CMediaSrv::createSecondOsd()
{
	INT_t iOutRet = ERR_SUCCESS, iRet;
	BOOL_t bGlobalStatusIsLocked = FALSE;
	CMp7xxGlobalStatus::P_MP7XX_GLOBAL_STATUS_INFO pStatusInfo = NULL;
	RMstatus eRMstatus = RM_OK;
	struct DisplayBlock_SurfaceSize_in_type dispBlk_SurfaceSize_in;
	struct DisplayBlock_SurfaceSize_out_type dispBlk_SurfaceSize_out;
	struct rmfp_main_thread_context_type *pMainContext = &m_RmfpMainContext;
	struct RUA * pRua = pMainContext->pRUA;
	RMuint32 dispBlkModuleId = EMHWLIB_MODULE(DisplayBlock, 0);

	if(FALSE == bGlobalStatusIsLocked)
	{
		iRet = Mp7xxGlobalStatus_Lock();
		if(ERR_SUCCESS == iRet)
		{
			bGlobalStatusIsLocked = TRUE;
		}
		else
		{
			PRINT_BFILE_LINENO_IRET_STR;
		}
	}

	pStatusInfo = Mp7xxGlobalStatus_getStatusInfo(FALSE/*not need lock*/);
	if(NULL == pStatusInfo)
	{
		iOutRet = ERR_INVALID_STATE;
		goto EXIT_PROC;
	}

	if(pStatusInfo->secondOsdInfo.surfaceAddr)
	{
		if(FALSE == (CSmp86xxMemRscInfo::GbusAddrIsAllocated(pStatusInfo->secondOsdInfo.surfaceAddr)))
		{
			LOG_BLINE("SurAddr(0x%08x) is using but not alloc, drop it.\n", pStatusInfo->secondOsdInfo.surfaceAddr);
			pStatusInfo->secondOsdInfo.surfaceAddr = NULL;
			pStatusInfo->secondOsdInfo.surfaceLumaAddr = NULL;
			pStatusInfo->secondOsdInfo.surfaceLumaSize = NULL;
			pStatusInfo->secondOsdInfo.surfaceWidth = NULL;
			pStatusInfo->secondOsdInfo.surfaceHeight = NULL;
			ZeroMemory(pStatusInfo->secondOsdInfo.usingCnt, sizeof(pStatusInfo->secondOsdInfo.usingCnt));
		}
	}

	if(pStatusInfo->secondOsdInfo.surfaceAddr)	//already
	{
		goto EXIT_PROC;
	}

	ZeroMemory(&dispBlk_SurfaceSize_in, sizeof(dispBlk_SurfaceSize_in));
	dispBlk_SurfaceSize_in.ColorMode = EMhwlibColorMode_TrueColor;
	dispBlk_SurfaceSize_in.ColorFormat = EMhwlibColorFormat_32BPP;
	dispBlk_SurfaceSize_in.SamplingMode = EMhwlibSamplingMode_None;
	//QHD resolution
	dispBlk_SurfaceSize_in.Width = 960;
	dispBlk_SurfaceSize_in.Height = 540;

	eRMstatus = RUAExchangeProperty2(pRua, dispBlkModuleId, RMDisplayBlockPropertyID_SurfaceSize, &dispBlk_SurfaceSize_in,
		sizeof(dispBlk_SurfaceSize_in), &dispBlk_SurfaceSize_out, sizeof(dispBlk_SurfaceSize_out));
	if(RMFAILED(eRMstatus))
	{
		PRINT_BFILE_LINENO_RMSTATUS;
		iOutRet = ERR_RUA_EXCHANGE_PROP_FAIL;
		goto EXIT_PROC;
	}

	pStatusInfo->secondOsdInfo.surfaceLumaAddr = 0;
	pStatusInfo->secondOsdInfo.surfaceLumaSize = 0;
	pStatusInfo->secondOsdInfo.surfaceAddr = RUAMalloc(pRua, 0/*DRAM 0*/, RUA_DRAM_UNCACHED, dispBlk_SurfaceSize_out.BufferSize);
	if(0 == pStatusInfo->secondOsdInfo.surfaceAddr)
	{
		LOG_BLINE("Failed to RUAMalloc(%d).\n", dispBlk_SurfaceSize_out.BufferSize);
		iOutRet = ERR_OUT_OF_MEMORY;
		goto EXIT_PROC;
	}

	struct DisplayBlock_InitSurface_in_type dispBlk_InitSurface_in;
	struct DisplayBlock_InitSurface_out_type dispBlk_InitSurface_out;
	ZeroMemory(&dispBlk_InitSurface_in, sizeof(dispBlk_InitSurface_in));
	dispBlk_InitSurface_in.ColorMode = dispBlk_SurfaceSize_in.ColorMode;
	dispBlk_InitSurface_in.ColorFormat = dispBlk_SurfaceSize_in.ColorFormat;
	dispBlk_InitSurface_in.SamplingMode = dispBlk_SurfaceSize_in.SamplingMode;
	dispBlk_InitSurface_in.Width = dispBlk_SurfaceSize_in.Width;
	dispBlk_InitSurface_in.Height = dispBlk_SurfaceSize_in.Height;
	dispBlk_InitSurface_in.Address = pStatusInfo->secondOsdInfo.surfaceAddr;
	dispBlk_InitSurface_in.LumaSize = dispBlk_SurfaceSize_out.LumaSize;
	dispBlk_InitSurface_in.ChromaSize = dispBlk_SurfaceSize_out.ChromaSize;
	dispBlk_InitSurface_in.ColorSpace = EMhwlibColorSpace_RGB_0_255;
	dispBlk_InitSurface_in.PixelAspectRatio.X = 0;
	dispBlk_InitSurface_in.PixelAspectRatio.Y = 0;
	eRMstatus = RUAExchangeProperty2(pRua, dispBlkModuleId, RMDisplayBlockPropertyID_InitSurface,
		&dispBlk_InitSurface_in, sizeof(dispBlk_InitSurface_in), &dispBlk_InitSurface_out, sizeof(dispBlk_InitSurface_out));
	if(RMFAILED(eRMstatus))
	{
		PRINT_BFILE_LINENO_RMSTATUS;
		iOutRet = ERR_RUA_EXCHANGE_PROP_FAIL;
		goto EXIT_PROC;
	}
	pStatusInfo->secondOsdInfo.surfaceLumaAddr = dispBlk_InitSurface_out.LumaAddress;
	pStatusInfo->secondOsdInfo.surfaceLumaSize = dispBlk_InitSurface_in.LumaSize;;
	pStatusInfo->secondOsdInfo.surfaceWidth = dispBlk_SurfaceSize_in.Width;
	pStatusInfo->secondOsdInfo.surfaceHeight = dispBlk_SurfaceSize_in.Height;
	
EXIT_PROC:
	if(ERR_SUCCESS != iOutRet)
	{
		if(pStatusInfo->secondOsdInfo.surfaceAddr)
		{
			RUAFree(pRua, pStatusInfo->secondOsdInfo.surfaceAddr);
			pStatusInfo->secondOsdInfo.surfaceAddr = 0;
		}
	}
	
	if(bGlobalStatusIsLocked)
	{
		iRet = Mp7xxGlobalStatus_Unlock();
		if(ERR_SUCCESS == iRet)
		{
			bGlobalStatusIsLocked = FALSE;
		}
		else
		{
			PRINT_BFILE_LINENO_IRET_STR;
		}
	}
	
	return iOutRet;
}

INT_t CMediaSrv::secondOsd_ClearScr()
{
	INT_t iOutRet = ERR_SUCCESS, iRet;
	BOOL_t bGlobalStatusIsLocked = FALSE;
	CMp7xxGlobalStatus::P_MP7XX_GLOBAL_STATUS_INFO pStatusInfo = NULL;
	RMstatus eRMstatus = RM_OK;
	struct rmfp_main_thread_context_type *pMainContext = &m_RmfpMainContext;
	struct RUA * pRua = pMainContext->pRUA;
	BOOL_t bSurface_LumaAddr_IsLocked = FALSE;
	BOOL_t bSurface_LumaAddr_IsMapped = FALSE;
	RMuint8 * pSurfaceLumaVirtAddr = NULL;

	if(FALSE == bGlobalStatusIsLocked)
	{
		iRet = Mp7xxGlobalStatus_Lock();
		if(ERR_SUCCESS == iRet)
		{
			bGlobalStatusIsLocked = TRUE;
		}
		else
		{
			PRINT_BFILE_LINENO_IRET_STR;
		}
	}

	pStatusInfo = Mp7xxGlobalStatus_getStatusInfo(FALSE/*not need lock*/);
	if(NULL == pStatusInfo)
	{
		iOutRet = ERR_INVALID_STATE;
		goto EXIT_PROC;
	}

	if(0 == pStatusInfo->secondOsdInfo.surfaceAddr || 0 == pStatusInfo->secondOsdInfo.surfaceLumaAddr) //not ready
	{
		iOutRet = ERR_NOT_READY;
		goto EXIT_PROC;
	}

	if(FALSE == bSurface_LumaAddr_IsLocked)
	{
		eRMstatus = RUALock(pRua, pStatusInfo->secondOsdInfo.surfaceLumaAddr, pStatusInfo->secondOsdInfo.surfaceLumaSize);
		if(RMFAILED(eRMstatus))
		{
			iOutRet = ERR_RUA_LOCK_FAIL;
			goto EXIT_PROC;
		}
		bSurface_LumaAddr_IsLocked = TRUE;
	}

	if(FALSE == bSurface_LumaAddr_IsMapped)
	{
		pSurfaceLumaVirtAddr = RUAMap(pRua, pStatusInfo->secondOsdInfo.surfaceLumaAddr, pStatusInfo->secondOsdInfo.surfaceLumaSize);
		if(NULL == pSurfaceLumaVirtAddr)
		{
			iOutRet = ERR_RUA_MAP_FAIL;
			goto EXIT_PROC;
		}
		bSurface_LumaAddr_IsMapped = TRUE;
	}

	ZeroMemory(pSurfaceLumaVirtAddr, pStatusInfo->secondOsdInfo.surfaceLumaSize);
	/*
	{
		RMint32 rowId, colId;
		RMuint32 bytesPerPixel = 4;
		RMuint32 * pPixelAddr;
		for(rowId=0; rowId<(typeof(rowId))pStatusInfo->secondOsdInfo.surfaceHeight; rowId++)
		{
			pPixelAddr = (typeof(pPixelAddr))
				&(pSurfaceLumaVirtAddr[((bytesPerPixel*pStatusInfo->secondOsdInfo.surfaceWidth)*rowId)+(bytesPerPixel*pStatusInfo->secondOsdInfo.surfaceWidth/2)]);
			*pPixelAddr = 0xFFFFFFFF;
		}
		memset(&(pSurfaceLumaVirtAddr[(pStatusInfo->secondOsdInfo.surfaceHeight/2)*(bytesPerPixel*pStatusInfo->secondOsdInfo.surfaceWidth)]),
			0xFF, bytesPerPixel*pStatusInfo->secondOsdInfo.surfaceWidth);
	}
	*/

EXIT_PROC:

	if(bSurface_LumaAddr_IsMapped)
	{
		if(pSurfaceLumaVirtAddr)
		{
			RUAUnMap(pRua, pSurfaceLumaVirtAddr, pStatusInfo->secondOsdInfo.surfaceLumaSize);
			pSurfaceLumaVirtAddr = NULL;
		}
		bSurface_LumaAddr_IsMapped = FALSE;
	}

	if(bSurface_LumaAddr_IsLocked)
	{
		eRMstatus = RUAUnLock(pRua, pStatusInfo->secondOsdInfo.surfaceLumaAddr, pStatusInfo->secondOsdInfo.surfaceLumaSize);
		if(RMSUCCEEDED(eRMstatus))
		{
			bSurface_LumaAddr_IsLocked = FALSE;
		}
		else
		{
			PRINT_BFILE_LINENO_RMSTATUS;
		}
	}

	if(bGlobalStatusIsLocked)
	{
		iRet = Mp7xxGlobalStatus_Unlock();
		if(ERR_SUCCESS == iRet)
		{
			bGlobalStatusIsLocked = FALSE;
		}
		else
		{
			PRINT_BFILE_LINENO_IRET_STR;
		}
	}

	return iOutRet;
}

INT_t CMediaSrv::releaseSecondOsd()
{
	INT_t iOutRet = ERR_SUCCESS, iRet;
	BOOL_t bGlobalStatusIsLocked = FALSE;
	CMp7xxGlobalStatus::P_MP7XX_GLOBAL_STATUS_INFO pStatusInfo = NULL;
	RMstatus eRMstatus = RM_OK;
	struct rmfp_main_thread_context_type *pMainContext = &m_RmfpMainContext;
	struct RUA * pRua = pMainContext->pRUA;
	INT_t iId;
	INT32_t surfaceRefCnt = 0;

	if(FALSE == bGlobalStatusIsLocked)
	{
		iRet = Mp7xxGlobalStatus_Lock();
		if(ERR_SUCCESS == iRet)
		{
			bGlobalStatusIsLocked = TRUE;
		}
		else
		{
			PRINT_BFILE_LINENO_IRET_STR;
		}
	}

	pStatusInfo = Mp7xxGlobalStatus_getStatusInfo(FALSE/*not need lock*/);
	if(NULL == pStatusInfo)
	{
		iOutRet = ERR_INVALID_STATE;
		goto EXIT_PROC;
	}

	if(0 == pStatusInfo->secondOsdInfo.surfaceAddr) 
	{
 		goto EXIT_PROC;
	}

	for(iId=0; iId<ARRAY_COUNT(pStatusInfo->secondOsdInfo.usingCnt); iId++)
	{
		if(pStatusInfo->secondOsdInfo.usingCnt[iId].processId)
		{
			surfaceRefCnt += pStatusInfo->secondOsdInfo.usingCnt[iId].refCnt;
		}
	}
	if(0 < surfaceRefCnt)
	{
		iOutRet = ERR_IS_USING;
		goto EXIT_PROC;
	}

	RUAFree(pRua, pStatusInfo->secondOsdInfo.surfaceAddr);	
	pStatusInfo->secondOsdInfo.surfaceAddr = 0;
	pStatusInfo->secondOsdInfo.surfaceLumaAddr = 0;
	pStatusInfo->secondOsdInfo.surfaceLumaSize = 0;

EXIT_PROC:

 	if(bGlobalStatusIsLocked)
	{
		iRet = Mp7xxGlobalStatus_Unlock();
		if(ERR_SUCCESS == iRet)
		{
			bGlobalStatusIsLocked = FALSE;
		}
		else
		{
			PRINT_BFILE_LINENO_IRET_STR;
		}
	}

	return iOutRet;
}

INT_t CMediaSrv::bindSecondOsdToDispScaler(RMuint32 dispScalerModuleId)
{
	INT_t iOutRet = ERR_SUCCESS, iRet;
	BOOL_t bGlobalStatusIsLocked = FALSE;
	CMp7xxGlobalStatus::P_MP7XX_GLOBAL_STATUS_INFO pStatusInfo = NULL;
	RMstatus eRMstatus = RM_OK;
	struct rmfp_main_thread_context_type *pMainContext = &m_RmfpMainContext;
	struct RUA * pRua = pMainContext->pRUA;
	RMuint32 nullSurfaceAddr = 0;
	RMuint32 tryTimesIfPending = 3, tryIntervalMs = 30;
 
	if(FALSE == bGlobalStatusIsLocked)
	{
		iRet = Mp7xxGlobalStatus_Lock();
		if(ERR_SUCCESS == iRet)
		{
			bGlobalStatusIsLocked = TRUE;
		}
		else
		{
			PRINT_BFILE_LINENO_IRET_STR;
		}
	}

	pStatusInfo = Mp7xxGlobalStatus_getStatusInfo(FALSE/*not need lock*/);
	if(NULL == pStatusInfo)
	{
		iOutRet = ERR_INVALID_STATE;
		goto EXIT_PROC;
	}

	if(0 == pStatusInfo->secondOsdInfo.surfaceAddr) 
	{
		iOutRet = ERR_INVALID_STATE;
		goto EXIT_PROC;
	}

	eRMstatus = RuaSetProp5(pMainContext->pRUA, dispScalerModuleId, RMGenericPropertyID_Surface,
		&nullSurfaceAddr, sizeof(nullSurfaceAddr), tryTimesIfPending, tryIntervalMs);
	if(RMFAILED(eRMstatus))
	{
		PRINT_BFILE_LINENO_RMSTATUS;
		iOutRet = ERR_RUA_SET_PROP_FAIL;
		goto EXIT_PROC;
	}

	eRMstatus = RuaSetProp5(pRua, dispScalerModuleId, RMGenericPropertyID_Surface,
		&(pStatusInfo->secondOsdInfo.surfaceAddr), sizeof(pStatusInfo->secondOsdInfo.surfaceAddr), 
		tryTimesIfPending, tryIntervalMs);
	if(RMFAILED(eRMstatus))
	{
		LOG_BLINE("%s,mid=0x%08x,sur=0x%08x\n", RMstatusToString(eRMstatus), dispScalerModuleId, pStatusInfo->secondOsdInfo.surfaceAddr);
		iOutRet = ERR_RUA_SET_PROP_FAIL;
		goto EXIT_PROC;
	}
	eRMstatus = RuaSetProp5(pMainContext->pRUA, dispScalerModuleId, RMGenericPropertyID_Validate,
		NULL, 0, tryTimesIfPending, tryIntervalMs);
	if(RMFAILED(eRMstatus))
	{
		PRINT_BFILE_LINENO_RMSTATUS;
		iOutRet = ERR_RUA_SET_PROP_FAIL;
		goto EXIT_PROC;
	}

EXIT_PROC:

	if(bGlobalStatusIsLocked)
	{
		iRet = Mp7xxGlobalStatus_Unlock();
		if(ERR_SUCCESS == iRet)
		{
			bGlobalStatusIsLocked = FALSE;
		}
		else
		{
			PRINT_BFILE_LINENO_IRET_STR;
		}
	}

	return iOutRet;
}

SharedPtr <IMediaFileInfoCache> getMediaFileInfoCacheSrvSp()
{
	return g_MediaSrv_wp.Promote();
}

MONITOR_MANUFACTURER_ID getMonitorManufacturerId(LPCSTR pszManufacturerName)
{
	MONITOR_MANUFACTURER_ID eMonitorManufacturerId = MONITOR_MANUFACTURER_ID_UNDEFINED;

	if(NULL == pszManufacturerName)
	{
	}

	return eMonitorManufacturerId;
}

