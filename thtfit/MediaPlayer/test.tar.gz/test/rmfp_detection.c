/*****************************************
 Copyright 2001-2007
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   stream_type_detection.c
  @brief  This detection API uses RMdetector3api and can fill RMFPStreamType and RMFPStreamInfo.


  @author Sebastian Frias Feltrer
  @date   2007-09-13
*/



#include "rmfp_internal.h"
#include "rmdetector3api/include/rmdetector3api.h"




#define LOCALDBG ENABLE
#define DETECTIONDBG DISABLE

#define ALWAYS_FORCE_CODECS_FOR_PSFDEMUX 0

#define RMFP_DETECTION_FORCE_SW_DEMUX 0

#define RMFP_DETECTION_THRESHOLD      (512*1024)
#define RMFP_DETECTION_VERBOSE_ENABLE TRUE

#define RMFP_DETECTION_PREALLOCATE_STREAMS 2

struct stream_type_detection_context {
	struct RMFPHandle *pHandle;

	RMbool verbose;
	RMuint32 nestingLevel;
	RMuint32 currentRootStreamID;

	struct RMFPStreamType *pStreamType;

	RMuint32 AllocatedSystemStreams;
	RMuint32 AllocatedVideoStreams;
	RMuint32 AllocatedAudioStreams;
	RMuint32 AllocatedDataStreams;

	struct RMFPStreamInfo *pStreamInfo;

	RMbool isSystemTypeKnown;
};


#ifdef _DEBUG
static RMuint8 *print_type(enum RMdetector3_streamType type);
#endif


static RMstatus progress_callback(void *pContext, RMint32 Progress, RMbool *pAbort);

static void system_stream_callback(void *pContext, struct RMDetector3_Specific_Info *pInfo, RMuint32 parentStreamID, RMuint32 streamID);
static void video_stream_callback(void *pContext, struct RMDetector3_Specific_Info *pInfo, RMuint32 parentStreamID, RMuint32 streamID);
static void audio_stream_callback(void *pContext, struct RMDetector3_Specific_Info *pInfo, RMuint32 parentStreamID, RMuint32 streamID);
static void data_stream_callback(void *pContext, struct RMDetector3_Specific_Info *pInfo, RMuint32 parentStreamID, RMuint32 streamID);

/*
   if oldSize = 0, then it works like a malloc;
   if buffer = NULL, then it works like a malloc;
   else if oldSize > 0 and size > oldSize, the memory area will be extended from oldSize to size
   Note that after reallocation the input buffer is no longer valid, always use the returned value
*/
static void *_realloc(void *buffer, RMuint32 size, RMuint32 oldSize);

static struct RMFPStreamInfo_System *get_system_info_ptr(struct stream_type_detection_context *pDetectionContext);
static struct RMFPStreamInfo_Video *get_video_info_ptr(struct stream_type_detection_context *pDetectionContext);
static struct RMFPStreamInfo_Audio *get_audio_info_ptr(struct stream_type_detection_context *pDetectionContext);




RMstatus rmfp_internal_get_stream_info(struct RMFPHandle *pHandle,
				       RMfile fileHandle,
				       const RMascii *pFilename,
				       RMint32 ParsingLength,
				       RMbool AvoidSeeking,
				       struct RMFPStreamType *pStreamType,
				       struct RMFPStreamInfo **ppStreamInfo)
{
	RMstatus status = RM_ERROR;
	struct RMdetector3Handle *pDetectorHandle = NULL;
	struct stream_type_detection_context detectionContext = { 0, };
	RMint64 position;

	detectionContext.pHandle = pHandle;
	detectionContext.verbose = RMFP_DETECTION_VERBOSE_ENABLE;
	detectionContext.nestingLevel = 0;
	detectionContext.currentRootStreamID = 0;
	detectionContext.pStreamType = pStreamType;
	detectionContext.pStreamInfo = (struct RMFPStreamInfo *) _realloc(NULL, sizeof(struct RMFPStreamInfo), 0);
	detectionContext.isSystemTypeKnown = FALSE;

	if (detectionContext.pStreamInfo) {
		RMMemset((void*)detectionContext.pStreamInfo, 0, sizeof(struct RMFPStreamInfo));

		detectionContext.AllocatedSystemStreams = RMFP_DETECTION_PREALLOCATE_STREAMS;
		detectionContext.pStreamInfo->pSystem = (struct RMFPStreamInfo_System *) _realloc(NULL, sizeof(struct RMFPStreamInfo_System) * detectionContext.AllocatedSystemStreams, 0);

		detectionContext.AllocatedVideoStreams = RMFP_DETECTION_PREALLOCATE_STREAMS;
		detectionContext.pStreamInfo->pVideo = (struct RMFPStreamInfo_Video *) _realloc(NULL, sizeof(struct RMFPStreamInfo_Video) * detectionContext.AllocatedVideoStreams, 0);

		detectionContext.AllocatedAudioStreams = RMFP_DETECTION_PREALLOCATE_STREAMS;
		detectionContext.pStreamInfo->pAudio = (struct RMFPStreamInfo_Audio *) _realloc(NULL, sizeof(struct RMFPStreamInfo_Audio) * detectionContext.AllocatedAudioStreams, 0);

		detectionContext.AllocatedDataStreams = RMFP_DETECTION_PREALLOCATE_STREAMS;
		detectionContext.pStreamInfo->pData = (struct RMFPStreamInfo_Data *) _realloc(NULL, sizeof(struct RMFPStreamInfo_Data) * detectionContext.AllocatedDataStreams, 0);
	}


	if (!ParsingLength)
		ParsingLength = RMFP_DETECTION_THRESHOLD;
	else
		RMDBGLOG((ENABLE, "ParsingLength %ld\n", ParsingLength));



	if (fileHandle) {

		if (!AvoidSeeking) {
			RMGetCurrentPositionOfFile(fileHandle, &position);
			RMDBGLOG((LOCALDBG, "current position %lld\n", position));
		}
		else
			RMDBGLOG((ENABLE, "AvoidSeeking = TRUE\n"));

		status = RMDetector3Create(&pDetectorHandle);
		if (status != RM_OK) {
			RMNOTIFY((NULL, status, "Cannot create dectector instance\n"));
			goto exit;
		}

		status = RMDetector3RegisterCallbacks(pDetectorHandle,
						      &detectionContext,
						      system_stream_callback,
						      video_stream_callback,
						      audio_stream_callback,
						      data_stream_callback,
						      progress_callback);
		if (status != RM_OK) {
			RMNOTIFY((NULL, status, "Failed to register detection callbacks\n"));
			goto exit;
		}

		status = RMDetector3DetectOpenFile(pDetectorHandle, fileHandle, pFilename, AvoidSeeking, 0, ParsingLength);

		// NOTE: this 'status' is the one that will be returned.
	}


 exit:

	if (fileHandle && !AvoidSeeking) {
		// put the file pointer where it was
		RMSeekFile(fileHandle, position, RM_FILE_SEEK_START);
	}

	if (pDetectorHandle) {
		RMstatus localStatus;
		localStatus = RMDetector3Destroy(pDetectorHandle);
		if (localStatus != RM_OK)
			RMNOTIFY((NULL, localStatus, "Cannot destroy detector instance\n"));
	}

	*ppStreamInfo = detectionContext.pStreamInfo;

	(*ppStreamInfo)->Version = GET_VERSION_FROM_MAGIC(RMFP_STREAMINFO_VERSION);


	if (!detectionContext.isSystemTypeKnown) {
		// then check for a known elementary stream

		if (detectionContext.pStreamInfo->VideoStreamCount && detectionContext.pStreamInfo->AudioStreamCount) {
			RMDBGLOG((ENABLE, "Video and audio were detected!, cannot decide\n"));
			return RM_NOT_KNOWN;
		}
		else if (detectionContext.pStreamInfo->VideoStreamCount == 1) {
			// video elementary detected, select main_video app

			RMDBGLOG((LOCALDBG, "video elementary detected\n"));

			if (detectionContext.pStreamType)
				detectionContext.pStreamType->application_type = RMFP_application_type_VIDEO;

			return status;

		}
		else if (detectionContext.pStreamInfo->AudioStreamCount == 1) {
			// audio elementary detected, select main_audio app

			RMDBGLOG((LOCALDBG, "audio elementary detected\n"));

			if (detectionContext.pStreamType)
				detectionContext.pStreamType->application_type = RMFP_application_type_AUDIO;

			return status;
		}
		else if (detectionContext.pStreamInfo->DataStreamCount == 1) {
			// picture elementary detected, select main_picture app

			RMDBGLOG((LOCALDBG, "picture elementary detected\n"));

			if (detectionContext.pStreamType)
				detectionContext.pStreamType->application_type = RMFP_application_type_PICTURE;
			RMDBGLOG((LOCALDBG,"picture elementary detected %s",RMstatusToString(status)));
			return status;
		}
		else {
			RMDBGLOG((ENABLE, "Detection yielded nothing\n"));
			return RM_NOT_KNOWN;
		}
	}

	// hide some non fatal errors
	if (status == RM_ASF_WITHOUT_INDEX) {
		RMDBGLOG((ENABLE, "Info: ASF stream has no index\n"));
		return RM_OK;
	}

	if (status == RM_ERRORENDOFFILE) {
		RMDBGLOG((ENABLE, "Info: stream seems to be too short\n"));
		return RM_OK;
	}

	if (status != RM_OK)
		RMNOTIFY((NULL, status, "Cannot detect\n"));

	return status;
}


RMstatus rmfp_internal_apply_stream_info_to_options( struct RMFPHandle *pHandle,
						     RMfile fileHandle,
						     struct RMFPStreamType *pStreamType,
						     struct RMFPStreamInfo *pStreamInfo,
						     struct RMFPOptions *pOptions)
{
	RMstatus status = RM_OK;

	pHandle->pStreamInfo = (struct RMFPStreamInfo *) RMMalloc(sizeof(struct RMFPStreamInfo));

	pHandle->pStreamInfo->pVideo = NULL;
	pHandle->pStreamInfo->pAudio = NULL;
	pHandle->pStreamInfo->pData = NULL;
	pHandle->pStreamInfo->pSystem = NULL;

	if (pStreamInfo->VideoStreamCount)
		pHandle->pStreamInfo->pVideo = (struct RMFPStreamInfo_Video *) RMMalloc(pStreamInfo->VideoStreamCount * sizeof(struct RMFPStreamInfo_Video));

	if (pStreamInfo->AudioStreamCount)
		pHandle->pStreamInfo->pAudio = (struct RMFPStreamInfo_Audio *) RMMalloc(pStreamInfo->AudioStreamCount * sizeof(struct RMFPStreamInfo_Audio));

	if (pStreamInfo->DataStreamCount)
		pHandle->pStreamInfo->pData = (struct RMFPStreamInfo_Data *) RMMalloc(pStreamInfo->DataStreamCount * sizeof(struct RMFPStreamInfo_Data));
	
	if (pStreamInfo->SystemStreamCount)
		pHandle->pStreamInfo->pSystem = (struct RMFPStreamInfo_System *) RMMalloc(pStreamInfo->SystemStreamCount * sizeof(struct RMFPStreamInfo_System));

	pHandle->pStreamInfo->Version = pStreamInfo->Version;
	pHandle->pStreamInfo->VideoStreamCount  = pStreamInfo->VideoStreamCount;
	pHandle->pStreamInfo->AudioStreamCount  = pStreamInfo->AudioStreamCount;
	pHandle->pStreamInfo->DataStreamCount   = pStreamInfo->DataStreamCount;
	pHandle->pStreamInfo->SystemStreamCount = pStreamInfo->SystemStreamCount;

	if (pHandle->pStreamInfo->pVideo && pStreamInfo->pVideo)
		RMMemcpy(pHandle->pStreamInfo->pVideo, pStreamInfo->pVideo, pHandle->pStreamInfo->VideoStreamCount * sizeof(struct RMFPStreamInfo_Video));

	if (pHandle->pStreamInfo->pAudio && pStreamInfo->pAudio)
		RMMemcpy(pHandle->pStreamInfo->pAudio, pStreamInfo->pAudio, pHandle->pStreamInfo->AudioStreamCount * sizeof(struct RMFPStreamInfo_Audio));

	if (pHandle->pStreamInfo->pData && pStreamInfo->pData)
		RMMemcpy(pHandle->pStreamInfo->pData, pStreamInfo->pData, pHandle->pStreamInfo->DataStreamCount * sizeof(struct RMFPStreamInfo_Data));

	if (pHandle->pStreamInfo->pSystem && pStreamInfo->pSystem)
		RMMemcpy(pHandle->pStreamInfo->pSystem, pStreamInfo->pSystem, pHandle->pStreamInfo->SystemStreamCount * sizeof(struct RMFPStreamInfo_System));
	

	switch (pStreamType->application_type) {

	case RMFP_application_type_ASF:
	case RMFP_application_type_MP4:
	case RMFP_application_type_HLS:
		// no need for parameters

		break;

	case RMFP_application_type_MKV:

		// use SkipNCP from detection

		if (pStreamInfo->VideoStreamCount && pStreamInfo->pVideo) {

			// NOTE: currently we support only one video stream in AVI
			if (pStreamInfo->pVideo[0].skipNCP) {
				RMDBGLOG((LOCALDBG, "SkipNCP = 1\n"));

				pOptions->video_options.skipNCP = TRUE;
			}
		}

		break;

	case RMFP_application_type_RIFF:
	case RMFP_application_type_AVI:
		// use SkipNCP from detection

		if (pStreamInfo->VideoStreamCount && pStreamInfo->pVideo) {

			// NOTE: currently we support only one video stream in AVI
			if (pStreamInfo->pVideo[0].skipNCP) {
				RMDBGLOG((LOCALDBG, "SkipNCP = 1\n"));

				pOptions->video_options.skipNCP = TRUE;
			}
		}

		if (pStreamInfo->SystemStreamCount && pStreamInfo->pSystem) {

			switch (pStreamInfo->pSystem[0].DemuxMode) {
			case RMSystemDetector_RIFF_Type_WAVE:
				RMDBGLOG((ENABLE, "RIFF/WAVE\n"));

				if (pStreamInfo->AudioStreamCount && pStreamInfo->pAudio) {
					// use DTS type from detection
					if (pStreamInfo->pAudio[0].Codec == AudioDecoder_Codec_DTS) {

						RMDBGLOG((ENABLE, "WAVE/DTS\n"));

						pOptions->audio_options.Codec    = pStreamInfo->pAudio[0].Codec;
						pOptions->audio_options.SubCodec = pStreamInfo->pAudio[0].SubCodec;

						if (pStreamInfo->pAudio[0].BitsPerSample == 14)
							pOptions->audio_options.DTS_CD = TRUE;
						else if (pStreamInfo->pAudio[0].BitsPerSample == 16)
							pOptions->audio_options.DTS_CD = FALSE;

						pOptions->audio_options.MsbFirst = pStreamInfo->pAudio[0].MSBFirst;
					}
					// use DRA type from detection
					if (pStreamInfo->pAudio[0].Codec == AudioDecoder_Codec_DRA) {

						RMDBGLOG((ENABLE, "WAVE/DRA\n"));

						pOptions->audio_options.Codec    = pStreamInfo->pAudio[0].Codec;
						pOptions->audio_options.SubCodec = pStreamInfo->pAudio[0].SubCodec;
					}
				}

				break;
			case RMSystemDetector_RIFF_Type_AVI:
				RMDBGLOG((ENABLE, "RIFF/AVI\n"));
				break;
			}
		}

		break;

	case RMFP_application_type_VIDEO:

		// we need the codec
		if (pStreamInfo->VideoStreamCount && pStreamInfo->pVideo) {
			// elementary can only be one stream

			pOptions->video_options.vcodec            = pStreamInfo->pVideo[0].Codec;
			pOptions->video_options.vcodec_max_width  = pStreamInfo->pVideo[0].MaxWidth;
			pOptions->video_options.vcodec_max_height = pStreamInfo->pVideo[0].MaxHeight;
			pOptions->video_options.vcodec_profile    = pStreamInfo->pVideo[0].Profile;
			pOptions->video_options.vcodec_level      = pStreamInfo->pVideo[0].Level;

			// use SkipNCP from detection
			if (pStreamInfo->pVideo[0].skipNCP) {
				RMDBGLOG((LOCALDBG, "SkipNCP = 1\n"));

				pOptions->video_options.skipNCP = TRUE;
			}
		}

		break;

	case RMFP_application_type_AUDIO:

		// we need the codec
		if (pStreamInfo->AudioStreamCount && pStreamInfo->pAudio) {

			{
				RMuint32 i;
				RMuint32 SupportedCounter = 0;

				for (i = 0; i < pStreamInfo->AudioStreamCount; i++) {
					if (pStreamInfo->pAudio[i].isSupported)
						SupportedCounter++;
				}

				/* otherwise exit with RM_NOT_SUPPORTED */
				if (!SupportedCounter)
					return RM_NOT_SUPPORTED;
			}

			// elementary can only be one stream

			pOptions->audio_options.Codec    = pStreamInfo->pAudio[0].Codec;
			pOptions->audio_options.SubCodec = pStreamInfo->pAudio[0].SubCodec;

			if (pOptions->audio_options.Codec == AudioDecoder_Codec_DTS) {
				if (pStreamInfo->pAudio[0].BitsPerSample == 14)
					pOptions->audio_options.DTS_CD = TRUE;
				else if (pStreamInfo->pAudio[0].BitsPerSample == 16)
					pOptions->audio_options.DTS_CD = FALSE;

				pOptions->audio_options.MsbFirst = pStreamInfo->pAudio[0].MSBFirst;
			}


			// we also want the duration if available

			if (pStreamInfo->pAudio[0].Bitrate && !pStreamInfo->pAudio[0].isVBR) {
				RMint64 FileSize;

				status = RMSizeOfOpenFile(fileHandle, &FileSize);
				if (status == RM_OK) {
					pOptions->playback_options.duration = (FileSize * 8) / pStreamInfo->pAudio[0].Bitrate;

					RMDBGLOG((ENABLE, "Estimated duration %lu seconds\n", pOptions->playback_options.duration));

					pOptions->playback_options.duration *= 1000;

				}
				else {
					// notify error but do not fail for it
					RMNOTIFY((NULL, status, "Cannot get size of file\n"));
					status = RM_OK;
				}
			} else if (pStreamInfo->pAudio[0].isVBR && pStreamInfo->pAudio[0].VBRDuration) {
				pOptions->playback_options.duration = pStreamInfo->pAudio[0].VBRDuration * 1000;
			}

			if (pStreamInfo->SystemStreamCount && pStreamInfo->pSystem) {
				// for WAVE files (which currently are redirected to main_audio.c) we need to set the skip

				if (pStreamInfo->pSystem[0].SkipFirstNBytes) {
					RMDBGLOG((ENABLE, "Skip first %lu bytes\n", pStreamInfo->pSystem[0].SkipFirstNBytes));
					pOptions->audio_options.skip_first_n_bytes = pStreamInfo->pSystem[0].SkipFirstNBytes;
				}

				if (pStreamInfo->pSystem[0].SendNBytes) {
					RMDBGLOG((ENABLE, "Send %lu bytes\n", pStreamInfo->pSystem[0].SendNBytes));
					pOptions->audio_options.send_n_bytes = pStreamInfo->pSystem[0].SendNBytes;
				}

				// since the detection can only detect PCM inside a container, this is probably for WAVE
				if (pStreamInfo->pAudio[0].Codec == AudioDecoder_Codec_PCM) {

					pOptions->audio_options.SignedPCM = TRUE;
					pOptions->audio_options.MsbFirst = FALSE;

					RMDBGLOG((ENABLE, "PCM: Channels %lu\n", pStreamInfo->pAudio[0].Channels));

					switch (pStreamInfo->pAudio[0].Channels) {
					case 1:
						pOptions->audio_options.ChannelAssign = PcmCda1_C;
						break;
					case 2:
						pOptions->audio_options.ChannelAssign = PcmCda2_LR;
						break;
					case 6:
						pOptions->audio_options.ChannelAssign = PcmCda6_LfRfCLfeLsRs;
						break;
					default:
						RMDBGLOG((LOCALDBG, "Number of channels %lu not supported!\n", pStreamInfo->pAudio[0].Channels));
						status = RM_ERROR;
						break;
					}

					pOptions->audio_options.bit_per_sample = pStreamInfo->pAudio[0].BitsPerSample;
					pOptions->audio_options.PCMSamplingFrequency = pStreamInfo->pAudio[0].SampleRate;

				}
			}

		}



		break;


	case RMFP_application_type_SOFTDEMUX:

		// we only need to setup the demux mode and tsskip

		if (pStreamInfo->SystemStreamCount && pStreamInfo->pSystem) {

			if (pStreamInfo->pSystem[0].TSSkip) {
				RMDBGLOG((LOCALDBG, "TSSkip = %lu\n", pStreamInfo->pSystem[0].TSSkip));
				pOptions->demux_options.ts_skip = pStreamInfo->pSystem[0].TSSkip;
			}

			//TODO: review this
			pOptions->demux_options.system_type = pStreamInfo->pSystem[0].DemuxMode;
		}


		break;

	case RMFP_application_type_PSFDEMUX:

		// we need to setup the demux mode, tsskip, video codec, audio codec and audio subid

		if (pStreamInfo->SystemStreamCount && pStreamInfo->pSystem) {

			if (pStreamInfo->pSystem[0].TSSkip) {
				RMDBGLOG((LOCALDBG, "TSSkip = %lu\n", pStreamInfo->pSystem[0].TSSkip));
				pOptions->demux_options.ts_skip = pStreamInfo->pSystem[0].TSSkip;
			}

			//TODO: review this
			pOptions->demux_options.system_type = pStreamInfo->pSystem[0].DemuxMode;
		}

		/* set default pmt pid if and only if the user doesnt uses the -pmt_option option */
		if (pStreamInfo->pSystem[0].default_pmt_pid && (pOptions->demux_options.pmt_pid==0) && (pOptions->demux_options.pmt_index==0)) {
			pOptions->demux_options.default_pmt_pid = pStreamInfo->pSystem[0].default_pmt_pid;
		}

#if 1
		// Temporary, ugly workaround for bug 32989 until AudioDecoder and/or psfdemux are adapted
		// accordingly. Find the first track which does not share its PID with another one, then force it.
		if ((pStreamInfo->AudioStreamCount >= 3) && pStreamInfo->pAudio && (pStreamInfo->pSystem[0].DemuxMode == RM_SYSTEM_MPEG2_TRANSPORT)) {
			RMuint32 i,j = 0;

			for (i = 0; i < pStreamInfo->AudioStreamCount; i++) {
				for (j = 0; j < pStreamInfo->AudioStreamCount; j++) {
					if ( pStreamInfo->pAudio[i].PID == pStreamInfo->pAudio[j].PID ) {
						if ((pStreamInfo->pAudio[i].SubID == 0x72) || (pStreamInfo->pAudio[j].SubID == 0x72))
							// No can do :(
							break;
					}
				}

				if (j == pStreamInfo->AudioStreamCount)
					break;
			}

			// If the first track was not OK and we have found a suitable replacement,
			// force the demux to use this track. Otherwise, let's just hope we can
			// live with it (that's the case of the tsPriority bit is managed properly).
			if ((i != 0) && (i < pStreamInfo->AudioStreamCount)) {
				if (!pOptions->demux_options.audio_pid) {
					RMDBGLOG((ENABLE, "Found potentially unsupported First Audio track, "
							  "forcing audio PID to something we can manage (like PID %lx)\n", pStreamInfo->pAudio[i].PID));

					pOptions->demux_options.audio_pid = pStreamInfo->pAudio[i].PID;
					pOptions->audio_options.Codec     = pStreamInfo->pAudio[i].Codec;
					pOptions->audio_options.SubCodec  = pStreamInfo->pAudio[i].SubCodec;
					pOptions->demux_options.audio_subid = 0;
				}
			}

			for (i = 0; i < pStreamInfo->AudioStreamCount; i++) {
				pStreamInfo->pAudio[i].SubID = 0;
			}
		}
#endif
		if ((pStreamInfo->pSystem[0].DemuxMode == RM_SYSTEM_MPEG2_TRANSPORT)
		    && !ALWAYS_FORCE_CODECS_FOR_PSFDEMUX)
			return RM_OK;

		// setup the first video stream
		if (pStreamInfo->VideoStreamCount && pStreamInfo->pVideo) {

			RMDBGLOG((DETECTIONDBG, "Forcing video codec\n"));

			pOptions->video_options.vcodec            = pStreamInfo->pVideo[0].Codec;
			pOptions->video_options.vcodec_max_width  = pStreamInfo->pVideo[0].MaxWidth;
			pOptions->video_options.vcodec_max_height = pStreamInfo->pVideo[0].MaxHeight;
			pOptions->video_options.vcodec_profile    = pStreamInfo->pVideo[0].Profile;
			pOptions->video_options.vcodec_level      = pStreamInfo->pVideo[0].Level;
		}


#if 0 // don't force audio codec.
		// setup the first audio stream
		if (pStreamInfo->AudioStreamCount && pStreamInfo->pAudio) {

			RMDBGLOG((DETECTIONDBG, "Forcing audio codec\n"));
			
			if (pOptions->demux_options.audio_subid == 0) {
				pOptions->audio_options.Codec     = pStreamInfo->pAudio[0].Codec;
				pOptions->audio_options.SubCodec  = pStreamInfo->pAudio[0].SubCodec;
				pOptions->demux_options.audio_subid = pStreamInfo->pAudio[0].SubID;
				
				// setup parameters for PCM codec only
				if (pOptions->audio_options.Codec == AudioDecoder_Codec_PCM) {
					/*
					the file: /media/storage_dir/f951cf11c552981b2090592c5ddfc1bcee0d4242.bin reports channels=0 and is Mono
					the file: /media/program/vob/pcm96k_24_Angela.vob reports channels=1 and is stereo
					*/
					switch (pStreamInfo->pAudio[0].Channels) {
					case 0:
						pOptions->audio_options.ChannelAssign = LpcmVob1_C;
						break;
					case 1:
						pOptions->audio_options.ChannelAssign = LpcmVob2_LR;
						break;
					default:
						RMDBGLOG((LOCALDBG, "Number of channels %lu not supported!\n", pStreamInfo->pAudio[0].Channels));
						status = RM_ERROR;
						break;
					}
	
					pOptions->audio_options.bit_per_sample = pStreamInfo->pAudio[0].BitsPerSample;
					pOptions->audio_options.PCMSamplingFrequency = pStreamInfo->pAudio[0].SampleRate;
	
				}
			}
		}
#endif

		break;

	case RMFP_application_type_PICTURE:
		if (pStreamInfo->DataStreamCount && pStreamInfo->pData) {

			pOptions->playback_options.PictureFormat = pStreamInfo->pData->Parameters.picture.format;

			if (pOptions->playback_options.PictureFormat == RMFPPictureFormat_JPEG) {

				// setup the first video stream

				RMDBGLOG((DETECTIONDBG, "Forcing jpeg codec\n"));

				pOptions->video_options.vcodec_orientation = 1;

				pOptions->video_options.vcodec            = EMhwlibJPEGCodec;
				pOptions->video_options.vcodec_max_width  = pStreamInfo->pData[0].Parameters.picture.Width;
				pOptions->video_options.vcodec_max_height = pStreamInfo->pData[0].Parameters.picture.Height;

				switch (pStreamInfo->pData[0].Parameters.picture.ColorSampling) {
				case RMFPPictureColorSampling_UNKNOWN:
				case RMFPPictureColorSampling_RGB:
					pOptions->video_options.vcodec_profile = EMhwlibJPEGProfile_Unknown;
					break;

				case RMFPPictureColorSampling_444:
					pOptions->video_options.vcodec_profile = EMhwlibJPEGProfile_2222;
					break;

				case RMFPPictureColorSampling_420:
					pOptions->video_options.vcodec_profile = EMhwlibJPEGProfile_2211;
					break;

				case RMFPPictureColorSampling_422:
					pOptions->video_options.vcodec_profile = EMhwlibJPEGProfile_2212;
					break;

				case RMFPPictureColorSampling_422Half:
					pOptions->video_options.vcodec_profile = EMhwlibJPEGProfile_2111;
					break;

				case RMFPPictureColorSampling_422Rotated:
					pOptions->video_options.vcodec_profile = EMhwlibJPEGProfile_2221;
					break;

				case RMFPPictureColorSampling_422HalfRotated:
					pOptions->video_options.vcodec_profile = EMhwlibJPEGProfile_1211;
					break;
				};

				if (pStreamInfo->pData[0].Parameters.picture.Profile == RMFPPictureProfile_Progressive) {
#if (EM86XX_CHIP>=EM86XX_CHIPID_TANGO3)
					RMDBGLOG((DETECTIONDBG, "Using progressive profile\n"));

					switch (pOptions->video_options.vcodec_profile) {
					case EMhwlibJPEGProfile_2222:
						pOptions->video_options.vcodec_profile = EMhwlibJPEGProfile_2222p;
						break;
					case EMhwlibJPEGProfile_2211:
						pOptions->video_options.vcodec_profile = EMhwlibJPEGProfile_2211p;
						break;

					case EMhwlibJPEGProfile_2212:
						pOptions->video_options.vcodec_profile = EMhwlibJPEGProfile_2212p;
						break;

					case EMhwlibJPEGProfile_2111:
						pOptions->video_options.vcodec_profile = EMhwlibJPEGProfile_2111p;
						break;

					case EMhwlibJPEGProfile_2221:
						pOptions->video_options.vcodec_profile = EMhwlibJPEGProfile_2221p;
						break;

					case EMhwlibJPEGProfile_1211:
						pOptions->video_options.vcodec_profile = EMhwlibJPEGProfile_1211p;
						break;
					};
#else
					RMDBGLOG((ENABLE, "This chip doesn't support progressive profile\n"));
#endif
				}
			}
		}

		break;

	case RMFP_application_type_UNKNOWN:
	case RMFP_application_type_ASF_STREAMING:
		// impossible, detection cannot yield this
		RMNOTIFY((NULL, RM_ERROR, "Got impossible value, exit!\n"));
		status = RM_ERROR;
		break;
	case RMFP_application_type_FLV:
		RMDBGLOG((ENABLE, "do nothing, flv\n"));
		break;
	case RMFP_application_type_REALMEDIA:
		RMDBGLOG((ENABLE, "do nothing, realmedia\n"));
		break;

	case RMFP_application_type_OGG:
		RMDBGLOG((ENABLE, "OGG\n"));

		if (pStreamInfo->VideoStreamCount || pStreamInfo->DataStreamCount) {
			RMDBGLOG((ENABLE, "\tOGV/OGM\n"));
		} else if (pStreamInfo->AudioStreamCount) {
			RMuint32 i;
			RMbool vorbis_only = TRUE;

			for (i = 0; i < pStreamInfo->AudioStreamCount; i++) {
				if (pStreamInfo->pAudio[i].Codec != AudioDecoder_Codec_VORBIS) {
					vorbis_only = FALSE;
					break;
				}
			}

			if (!vorbis_only) {
				RMDBGLOG((ENABLE, "\tOGA\n"));
			} else {
				/* TODO: OGG With only one audio tracks are still a bit buggy right now so we stcik with main audio */
				RMDBGLOG((ENABLE, "\tELEMENTARY VORBIS\n"));
			}
		}

		// use SkipNCP from detection
		if (pStreamInfo->VideoStreamCount && pStreamInfo->pVideo) {

			// NOTE: currently we support only one video stream in AVI
			if (pStreamInfo->pVideo[0].skipNCP) {
				RMDBGLOG((LOCALDBG, "SkipNCP = 1\n"));
				pOptions->video_options.skipNCP = TRUE;
			}
		}

		break;
	};
	

	return status;
}

RMstatus rmfp_internal_release_stream_info(struct RMFPHandle *pHandle,
										   struct RMFPStreamInfo *pStreamInfo)
{
	if (pStreamInfo) {
		if (pStreamInfo->pSystem)
			RMFree(pStreamInfo->pSystem);
		if (pStreamInfo->pVideo)
			RMFree(pStreamInfo->pVideo);
		if (pStreamInfo->pAudio)
			RMFree(pStreamInfo->pAudio);
		if (pStreamInfo->pData)
			RMFree(pStreamInfo->pData);

		RMFree(pStreamInfo);
	}

	return RM_OK;
}

RMstatus rmfp_internal_release_stream_info2(struct RMFPStreamInfo *pStreamInfo)
{
	if (pStreamInfo) {
		if (pStreamInfo->pSystem)
		{
			RMFree(pStreamInfo->pSystem);
			pStreamInfo->pSystem = NULL;
		}
		if (pStreamInfo->pVideo)
		{
			RMFree(pStreamInfo->pVideo);
			pStreamInfo->pVideo = NULL;
		}
		if (pStreamInfo->pAudio)
		{
			RMFree(pStreamInfo->pAudio);
			pStreamInfo->pAudio = NULL;
		}
		if (pStreamInfo->pData)
		{
			RMFree(pStreamInfo->pData);
			pStreamInfo->pData = NULL;
		}

		RMFree(pStreamInfo);
		pStreamInfo = NULL;
	}

	return RM_OK;
}

static RMstatus progress_callback(void *pContext, RMint32 Progress, RMbool *pAbort)
{
	struct stream_type_detection_context *pDetectionContext = NULL;
	struct RMFPHandle *pHandle = NULL;
	struct RMFPProgress rmfp_progress = {0, };


	ASSERT_NULL_POINTER(pContext);

	pDetectionContext = (struct stream_type_detection_context *)pContext;
	pHandle = pDetectionContext->pHandle;

	rmfp_progress.progress_type = RMFP_progress_type_detection;
	rmfp_progress.info_type = RMFP_progress_info_type_percentage;
	rmfp_progress.progress.percentage = Progress;

	return rmfp_internal_notify_progress_handler(pHandle, &rmfp_progress, pAbort);
}


/*
   if oldSize = 0 or buffer = NULL, then it works like a malloc;
   else if buffer != NULL and oldSize > 0:
   - if newSize > oldSize, the memory area will be extended from oldSize to newSize
   - if newSize < oldSize, the memory area will be reduced from oldSize to newSize. In this
   case data past newSize WILL BE LOST.

   If the returned value is NULL, buffer is preserved, that is, if it was valid, it still is, but
   reallocation didn't happen

   Note that after sucessful reallocation the input buffer is no longer valid (it is freed
   internally), always use the returned value

*/
static void *_realloc(void *buffer, RMuint32 newSize, RMuint32 oldSize)
{

	RMDBGLOG((LOCALDBG, "realloc(%p, %lu, %lu)\n", buffer, newSize, oldSize));

	if (!buffer || !oldSize) {
		void *temp = NULL;

		temp = RMMalloc(newSize);

		if (temp)
			RMMemset(temp, 0, newSize);

		return temp;
	}
	else if (buffer && newSize) {
		if (newSize > oldSize) {
			void *temp = NULL;

			// extend

			temp = RMMalloc(newSize);
			if (!temp)
				return temp;

			RMMemcpy(temp, buffer, oldSize);
			RMMemset(temp + oldSize, 0, newSize - oldSize);
			RMFree(buffer);
			return temp;

		}
		else if (newSize < oldSize) {
			void *temp = NULL;

			// reduce

			temp = RMMalloc(newSize);
			if (!temp)
				return temp;

			RMMemcpy(temp, buffer, newSize);
			RMFree(buffer);
			return temp;
		}
		else
			// nothing to do
			return buffer;
	}

	return NULL;
}


static struct RMFPStreamInfo_System *get_system_info_ptr(struct stream_type_detection_context *pDetectionContext)
{

	if (pDetectionContext->pStreamInfo) {

		if (pDetectionContext->pStreamInfo->SystemStreamCount >= pDetectionContext->AllocatedSystemStreams) {
			void *temp = NULL;
			void *buffer = (void*)pDetectionContext->pStreamInfo->pSystem;
			RMuint32 oldSize = sizeof(struct RMFPStreamInfo_System) * pDetectionContext->AllocatedSystemStreams;
			RMuint32 newSize = oldSize * 2;


			RMDBGLOG((LOCALDBG, "Needs reallocation!\n"));

			temp = _realloc(buffer, newSize, oldSize);
			if (temp) {
				pDetectionContext->pStreamInfo->pSystem = (struct RMFPStreamInfo_System *)temp;
				pDetectionContext->AllocatedSystemStreams *= 2;
				RMMemset(temp + oldSize, 0, newSize - oldSize);
			}
			else {
				RMNOTIFY((NULL, RM_ERROR, "realloc failed, further data will be lost\n"));
				return (struct RMFPStreamInfo_System *)NULL;
			}

		}


		return &(pDetectionContext->pStreamInfo->pSystem[pDetectionContext->pStreamInfo->SystemStreamCount++]);

	}

	return (struct RMFPStreamInfo_System *)NULL;
}



static struct RMFPStreamInfo_Video *get_video_info_ptr(struct stream_type_detection_context *pDetectionContext)
{

	if (pDetectionContext->pStreamInfo) {

		if (pDetectionContext->pStreamInfo->VideoStreamCount >= pDetectionContext->AllocatedVideoStreams) {
			void *temp = NULL;
			void *buffer = (void*)pDetectionContext->pStreamInfo->pVideo;
			RMuint32 oldSize = sizeof(struct RMFPStreamInfo_Video) * pDetectionContext->AllocatedVideoStreams;
			RMuint32 newSize = oldSize * 2;


			RMDBGLOG((LOCALDBG, "Needs reallocation!\n"));

			temp = _realloc(buffer, newSize, oldSize);
			if (temp) {
				pDetectionContext->pStreamInfo->pVideo = (struct RMFPStreamInfo_Video *)temp;
				pDetectionContext->AllocatedVideoStreams *= 2;
				RMMemset(temp + oldSize, 0, newSize - oldSize);
			}
			else {
				RMNOTIFY((NULL, RM_ERROR, "realloc failed, further data will be lost\n"));
				return (struct RMFPStreamInfo_Video *)NULL;
			}

		}


		return &(pDetectionContext->pStreamInfo->pVideo[pDetectionContext->pStreamInfo->VideoStreamCount++]);

	}

	return (struct RMFPStreamInfo_Video *)NULL;
}


static struct RMFPStreamInfo_Audio *get_audio_info_ptr(struct stream_type_detection_context *pDetectionContext)
{

	if (pDetectionContext->pStreamInfo) {

		if (pDetectionContext->pStreamInfo->AudioStreamCount >= pDetectionContext->AllocatedAudioStreams) {
			void *temp = NULL;
			void *buffer = (void*)pDetectionContext->pStreamInfo->pAudio;
			RMuint32 oldSize = sizeof(struct RMFPStreamInfo_Audio) * pDetectionContext->AllocatedAudioStreams;
			RMuint32 newSize = oldSize * 2;


			RMDBGLOG((LOCALDBG, "Needs reallocation!\n"));

			temp = _realloc(buffer, newSize, oldSize);
			if (temp) {
				pDetectionContext->pStreamInfo->pAudio = (struct RMFPStreamInfo_Audio *)temp;
				pDetectionContext->AllocatedAudioStreams *= 2;
				RMMemset(temp + oldSize, 0, newSize - oldSize);
			}
			else {
				RMNOTIFY((NULL, RM_ERROR, "realloc failed, further data will be lost\n"));
				return (struct RMFPStreamInfo_Audio *)NULL;
			}

		}


		return &(pDetectionContext->pStreamInfo->pAudio[pDetectionContext->pStreamInfo->AudioStreamCount++]);

	}

	return (struct RMFPStreamInfo_Audio *)NULL;
}


static struct RMFPStreamInfo_Data *get_data_info_ptr(struct stream_type_detection_context *pDetectionContext)
{

	if (pDetectionContext->pStreamInfo) {

		if (pDetectionContext->pStreamInfo->DataStreamCount >= pDetectionContext->AllocatedDataStreams) {
			void *temp = NULL;
			void *buffer = (void*)pDetectionContext->pStreamInfo->pData;
			RMuint32 oldSize = sizeof(struct RMFPStreamInfo_Data) * pDetectionContext->AllocatedDataStreams;
			RMuint32 newSize = oldSize * 2;


			RMDBGLOG((LOCALDBG, "Needs reallocation!\n"));

			temp = _realloc(buffer, newSize, oldSize);
			if (temp) {
				pDetectionContext->pStreamInfo->pData = (struct RMFPStreamInfo_Data *)temp;
				pDetectionContext->AllocatedDataStreams *= 2;
				RMMemset(temp + oldSize, 0, newSize - oldSize);
			}
			else {
				RMNOTIFY((NULL, RM_ERROR, "realloc failed, further data will be lost\n"));
				return (struct RMFPStreamInfo_Data *)NULL;
			}

		}


		return &(pDetectionContext->pStreamInfo->pData[pDetectionContext->pStreamInfo->DataStreamCount++]);

	}

	return (struct RMFPStreamInfo_Data *)NULL;
}


#ifdef _DEBUG
static RMuint8 *print_type(enum RMdetector3_streamType type)
{
	switch (type) {
	case RMdetector3_streamType_UNKNOWN:
		return (RMuint8 *)"unknown";
	case RMdetector3_streamType_ELEMENTARY_AUDIO:
		return (RMuint8 *)"elementary_audio";
	case RMdetector3_streamType_ELEMENTARY_VIDEO:
		return (RMuint8 *)"elementary_video";
	case RMdetector3_streamType_ELEMENTARY_PICTURE:
		return (RMuint8 *)"elementary_picture";
	case RMdetector3_streamType_SYSTEM:
		return (RMuint8 *)"system";

	// pictures
	case RMdetector3_streamType_BMP:
		return (RMuint8 *)"bmp";
	case RMdetector3_streamType_JPEG:
		return (RMuint8 *)"jpeg";
	case RMdetector3_streamType_TIFF:
		return (RMuint8 *)"tiff";
	case RMdetector3_streamType_PNG:
		return (RMuint8 *)"png";
	case RMdetector3_streamType_GIF:
		return (RMuint8 *)"gif";

	// subpicture
	case RMdetector3_streamType_SPU_DVD:
		return (RMuint8 *)"DVD subpicture";
	case RMdetector3_streamType_SPU_Bluray:
		return (RMuint8 *)"Bluray subpicture";
	case RMdetector3_streamType_SPU_DVB:
		return (RMuint8 *)"DVB subpicture";

	// elementary audio
	case RMdetector3_streamType_AUDIO_AC3:
		return (RMuint8 *)"audio_ac3";
	case RMdetector3_streamType_AUDIO_ADIF:
		return (RMuint8 *)"audio_adif";
	case RMdetector3_streamType_AUDIO_ADTS:
		return (RMuint8 *)"audio_adts";
	case RMdetector3_streamType_AUDIO_DTS:
		return (RMuint8 *)"audio_dts";
	case RMdetector3_streamType_AUDIO_DVD:
		return (RMuint8 *)"audio_dvd";
	case RMdetector3_streamType_AUDIO_LATM:
		return (RMuint8 *)"audio_latm";
	case RMdetector3_streamType_AUDIO_MPEG:
		return (RMuint8 *)"audio_mpeg";
	case RMdetector3_streamType_AUDIO_MPEG1:
		return (RMuint8 *)"audio_mpeg1";
	case RMdetector3_streamType_AUDIO_MPEG1_LAYER3:
		return (RMuint8 *)"audio_mpeg1_layer3";
	case RMdetector3_streamType_AUDIO_MPEG2:
		return (RMuint8 *)"audio_mpeg2";
	case RMdetector3_streamType_AUDIO_MPEG2_LAYER1:
		return (RMuint8 *)"audio_mpeg2_layer1";
	case RMdetector3_streamType_AUDIO_MPEG2_LAYER2:
		return (RMuint8 *)"audio_mpeg2_layer2";
	case RMdetector3_streamType_AUDIO_MPEG2_LAYER3:
		return (RMuint8 *)"audio_mpeg2_layer3";
	case RMdetector3_streamType_AUDIO_PCM:
		return (RMuint8 *)"audio_pcm";
	case RMdetector3_streamType_AUDIO_REVERSE_PCM:
		return (RMuint8 *)"audio_reverse_pcm";
	case RMdetector3_streamType_AUDIO_WMA:
		return (RMuint8 *)"audio_wma";
	case RMdetector3_streamType_AUDIO_WMAPRO:
		return (RMuint8 *)"audio_wmapro";
	case RMdetector3_streamType_AUDIO_WMATS:
		return (RMuint8 *)"audio_wmats";
	case RMdetector3_streamType_AUDIO_EAC3:
		return (RMuint8 *)"audio_eac3";
	case RMdetector3_streamType_AUDIO_MLP:
		return (RMuint8 *)"audio_mlp";
	case RMdetector3_streamType_AUDIO_TrueHD:
		return (RMuint8 *)"audio_truehd";
	case RMdetector3_streamType_AUDIO_Vorbis:
		return (RMuint8 *)"audio_vorbis";
	case RMdetector3_streamType_AUDIO_FLAC:
		return (RMuint8 *)"audio_flac";
	case RMdetector3_streamType_AUDIO_DRA:
		return (RMuint8 *)"audio_dra";
	case RMdetector3_streamType_AUDIO_AG711_ULAW:
		return (RMuint8 *)"audio_ag711_ulaw";


	// elementary video
	case RMdetector3_streamType_VIDEO_AVS:
		return (RMuint8 *)"video_avs";
	case RMdetector3_streamType_VIDEO_DIVX3:
		return (RMuint8 *)"video_divx3";
	case RMdetector3_streamType_VIDEO_DIVX4:
		return (RMuint8 *)"video_divx4";
	case RMdetector3_streamType_VIDEO_H263:
		return (RMuint8 *)"video_h263";
	case RMdetector3_streamType_VIDEO_H264:
		return (RMuint8 *)"video_h264";
	case RMdetector3_streamType_VIDEO_MJPEG:
		return (RMuint8 *)"video_mjpeg";
	case RMdetector3_streamType_VIDEO_MPEG12:
		return (RMuint8 *)"video_mpeg2";
	case RMdetector3_streamType_VIDEO_MPEG4:
		return (RMuint8 *)"video_mpeg4";
	case RMdetector3_streamType_VIDEO_VC1:
		return (RMuint8 *)"video_vc1";
	case RMdetector3_streamType_VIDEO_WMV:
		return (RMuint8 *)"video_wmv";
	case RMdetector3_streamType_VIDEO_XVID:
		return (RMuint8 *)"video_xvid";

	// system
	case RMdetector3_streamType_SYSTEM_ASF:
		return (RMuint8 *)"system_asf";
	case RMdetector3_streamType_SYSTEM_DVD:
		return (RMuint8 *)"system_dvd";
	case RMdetector3_streamType_SYSTEM_ID3:
		return (RMuint8 *)"system_id3";
	case RMdetector3_streamType_SYSTEM_M1S:
		return (RMuint8 *)"system_m1s";
	case RMdetector3_streamType_SYSTEM_M2P:
		return (RMuint8 *)"system_m2p";
	case RMdetector3_streamType_SYSTEM_M2T:
		return (RMuint8 *)"system_m2t";
	case RMdetector3_streamType_SYSTEM_MKV:
		return (RMuint8 *)"system_mkv";
	case RMdetector3_streamType_SYSTEM_MP4:
		return (RMuint8 *)"system_mp4";
	case RMdetector3_streamType_SYSTEM_RIFF:
		return (RMuint8 *)"system_riff";
	case RMdetector3_streamType_SYSTEM_FLV:
		return (RMuint8 *)"system_FLV";
	case RMdetector3_streamType_SYSTEM_OGG:
		return (RMuint8 *)"system_OGG";
	case RMdetector3_streamType_SYSTEM_RealMedia:
		return (RMuint8 *)"system_RealMedia";
	case RMdetector3_streamType_SYSTEM_HLS:
		return (RMuint8 *)"system_HLS";

	}
	return (RMuint8 *)"unknown";
}
#endif



static void system_stream_callback(void *pContext, struct RMDetector3_Specific_Info *pInfo, RMuint32 parentStreamID, RMuint32 streamID)
{
	RMuint32 i;
	struct stream_type_detection_context *pDetectionContext = NULL;
	struct RMFPStreamInfo_System *pSystemInfo = NULL;

	if (!pContext)
		return;

	pDetectionContext = (struct stream_type_detection_context *)pContext;

	RMDBGLOG((ENABLE, "system(PSID %lu, SID %lu)\n", parentStreamID, streamID));

	if (pDetectionContext->verbose) {
		if (parentStreamID == streamID)
			pDetectionContext->currentRootStreamID = streamID;

		if (parentStreamID != pDetectionContext->currentRootStreamID) {
			pDetectionContext->nestingLevel++;

			for (i = 0; i < pDetectionContext->nestingLevel; i++)
				RMDBGPRINT((ENABLE, "\t"));
		}

		pDetectionContext->currentRootStreamID = streamID;

		RMDBGPRINT((ENABLE, "[%2lu %2lu ] %s\n", parentStreamID, streamID, print_type(pInfo->Type)));
	}

	// get specific data.


	if (pDetectionContext->pStreamInfo) {

		pSystemInfo = get_system_info_ptr(pDetectionContext);
		if (!pSystemInfo)
			return;

		pSystemInfo->Version        = GET_VERSION_FROM_MAGIC(RMFP_STREAMINFO_SYSTEM_VERSION);
		pSystemInfo->StreamID       = streamID;
		pSystemInfo->ParentStreamID = parentStreamID;

	}

	pDetectionContext->isSystemTypeKnown = TRUE;


	switch (pInfo->Type) {
	case RMdetector3_streamType_UNKNOWN:
		pDetectionContext->isSystemTypeKnown = FALSE;
		break;

	case RMdetector3_streamType_ELEMENTARY_AUDIO:
	case RMdetector3_streamType_ELEMENTARY_VIDEO:
	case RMdetector3_streamType_ELEMENTARY_PICTURE:
	case RMdetector3_streamType_SYSTEM:
		pDetectionContext->isSystemTypeKnown = FALSE;
		break;

	// elementary audio
	case RMdetector3_streamType_AUDIO_AC3:
	case RMdetector3_streamType_AUDIO_ADIF:
	case RMdetector3_streamType_AUDIO_ADTS:
	case RMdetector3_streamType_AUDIO_DTS:
	case RMdetector3_streamType_AUDIO_DVD:
	case RMdetector3_streamType_AUDIO_LATM:
	case RMdetector3_streamType_AUDIO_MPEG:
	case RMdetector3_streamType_AUDIO_MPEG1: //unused?
	case RMdetector3_streamType_AUDIO_MPEG1_LAYER3:
	case RMdetector3_streamType_AUDIO_MPEG2: //unused?
	case RMdetector3_streamType_AUDIO_MPEG2_LAYER1:
	case RMdetector3_streamType_AUDIO_MPEG2_LAYER2:
	case RMdetector3_streamType_AUDIO_MPEG2_LAYER3:
	case RMdetector3_streamType_AUDIO_PCM:
	case RMdetector3_streamType_AUDIO_REVERSE_PCM:
	case RMdetector3_streamType_AUDIO_WMA:
	case RMdetector3_streamType_AUDIO_WMAPRO:
	case RMdetector3_streamType_AUDIO_WMATS:
	case RMdetector3_streamType_AUDIO_EAC3:
	case RMdetector3_streamType_AUDIO_MLP:
	case RMdetector3_streamType_AUDIO_TrueHD:
	case RMdetector3_streamType_AUDIO_Vorbis:
	case RMdetector3_streamType_AUDIO_FLAC:
	case RMdetector3_streamType_AUDIO_DRA:
	case RMdetector3_streamType_AUDIO_AG711_ULAW:
		pDetectionContext->isSystemTypeKnown = FALSE;
		break;

	// pictures
	case RMdetector3_streamType_BMP:
	case RMdetector3_streamType_JPEG:
	case RMdetector3_streamType_TIFF:
	case RMdetector3_streamType_PNG:
	case RMdetector3_streamType_GIF:
		pDetectionContext->isSystemTypeKnown = FALSE;
		break;

	// subpicture
	case RMdetector3_streamType_SPU_DVD:
	case RMdetector3_streamType_SPU_Bluray:
	case RMdetector3_streamType_SPU_DVB:
		pDetectionContext->isSystemTypeKnown = FALSE;
		break;

	// elementary video
	case RMdetector3_streamType_VIDEO_AVS:
	case RMdetector3_streamType_VIDEO_DIVX3:
	case RMdetector3_streamType_VIDEO_DIVX4:
	case RMdetector3_streamType_VIDEO_H263:
	case RMdetector3_streamType_VIDEO_H264:
	case RMdetector3_streamType_VIDEO_MJPEG:
	case RMdetector3_streamType_VIDEO_MPEG12:
	case RMdetector3_streamType_VIDEO_MPEG4:
	case RMdetector3_streamType_VIDEO_VC1:
	case RMdetector3_streamType_VIDEO_WMV:
	case RMdetector3_streamType_VIDEO_XVID:
		pDetectionContext->isSystemTypeKnown = FALSE;
		break;

	// system
	case RMdetector3_streamType_SYSTEM_ASF:
		if (pDetectionContext->pStreamType)
			pDetectionContext->pStreamType->application_type = RMFP_application_type_ASF;
		break;
	case RMdetector3_streamType_SYSTEM_DVD:

		if (pDetectionContext->pStreamType) {
#if RMFP_DETECTION_FORCE_SW_DEMUX
			pDetectionContext->pStreamType->application_type = RMFP_application_type_SOFTDEMUX;
#else
			pDetectionContext->pStreamType->application_type = RMFP_application_type_PSFDEMUX;
#endif
		}

		if (pSystemInfo) {

			pSystemInfo->DemuxMode = RM_SYSTEM_MPEG2_DVD;

			//pDetectionContext->pStreamInfo->SystemStreamCount++;

		}

		break;
	case RMdetector3_streamType_SYSTEM_ID3:

		if (pDetectionContext->pStreamType) {

			if (pInfo->Data.System.Info.Type == RMSystemDetector_Type_ID3) {

				pDetectionContext->pStreamType->application_type = RMFP_application_type_AUDIO;

				if (pSystemInfo) {

					pSystemInfo->SkipFirstNBytes = pInfo->Data.System.Info.Data.ID3.BitstreamOffset;

					RMDBGLOG((ENABLE, "Skip first %lu bytes\n", pSystemInfo->SkipFirstNBytes));

					//pDetectionContext->pStreamInfo->SystemStreamCount++;

				}
			}
			else
				RMDBGLOG((ENABLE, "Not ID3!?\n"));
		}

		break;

	case RMdetector3_streamType_SYSTEM_M1S:
		if (pDetectionContext->pStreamType) {
#if RMFP_DETECTION_FORCE_SW_DEMUX
			pDetectionContext->pStreamType->application_type = RMFP_application_type_SOFTDEMUX;
#else
			pDetectionContext->pStreamType->application_type = RMFP_application_type_PSFDEMUX;
#endif
		}


		if (pSystemInfo) {

			pSystemInfo->DemuxMode = RM_SYSTEM_MPEG1;

			//pDetectionContext->pStreamInfo->SystemStreamCount++;

		}


		break;

	case RMdetector3_streamType_SYSTEM_M2P:
		if (pDetectionContext->pStreamType) {
#if RMFP_DETECTION_FORCE_SW_DEMUX
			pDetectionContext->pStreamType->application_type = RMFP_application_type_SOFTDEMUX;
#else
			pDetectionContext->pStreamType->application_type = RMFP_application_type_PSFDEMUX;
#endif
		}


		if (pSystemInfo) {

			pSystemInfo->DemuxMode = RM_SYSTEM_MPEG2_PROGRAM;

			//pDetectionContext->pStreamInfo->SystemStreamCount++;

		}


		break;

	case RMdetector3_streamType_SYSTEM_M2T:
		if (pDetectionContext->pStreamType) {
#if RMFP_DETECTION_FORCE_SW_DEMUX
			pDetectionContext->pStreamType->application_type = RMFP_application_type_SOFTDEMUX;
#else
			pDetectionContext->pStreamType->application_type = RMFP_application_type_PSFDEMUX;
#endif
		}


		if (pSystemInfo) {

			pSystemInfo->DemuxMode = RM_SYSTEM_MPEG2_TRANSPORT;

			if (pInfo->Data.System.Info.Data.M2T.Skip) {
				RMDBGLOG((ENABLE, "TSSkip %lu\n", pInfo->Data.System.Info.Data.M2T.Skip));
				pSystemInfo->TSSkip = pInfo->Data.System.Info.Data.M2T.Skip;
			}
			
			pSystemInfo->default_pmt_pid = pInfo->Data.System.default_pmt_pid;
			//pDetectionContext->pStreamInfo->SystemStreamCount++;

		}

		break;
	case RMdetector3_streamType_SYSTEM_MP4:
		RMDBGLOG((ENABLE, "System MP4 found !!!!\n"));
		if (pDetectionContext->pStreamType)
			pDetectionContext->pStreamType->application_type = RMFP_application_type_MP4;
		RMDBGLOG((ENABLE, "type : %d (%d)\n", pDetectionContext->pStreamType->application_type, RMFP_application_type_MP4));
		break;
	case RMdetector3_streamType_SYSTEM_MKV:
		if (pDetectionContext->pStreamType)
			pDetectionContext->pStreamType->application_type = RMFP_application_type_MKV;
		break;

	case RMdetector3_streamType_SYSTEM_RIFF:
		if (pDetectionContext->pStreamType) {

			if (pInfo->Data.System.Info.Type == RMSystemDetector_Type_RIFF) {
				RMDBGLOG((ENABLE, "RIFF\n"));
				switch (pInfo->Data.System.Info.Data.RIFF.Type) {
				case RMSystemDetector_RIFF_Type_AVI:
					RMDBGLOG((ENABLE, "AVI\n"));
#if ((defined WITH_OLD_AVI_LIB) && (WITH_OLD_AVI_LIB == 1))
					pDetectionContext->pStreamType->application_type = RMFP_application_type_AVI;
#else
					pDetectionContext->pStreamType->application_type = RMFP_application_type_RIFF;
#endif
					break;
				case RMSystemDetector_RIFF_Type_CDXA:
					RMDBGLOG((ENABLE, "CDXA\n"));
					break;
				case RMSystemDetector_RIFF_Type_WAVE:
					RMDBGLOG((ENABLE, "WAVE\n"));
#if ((defined WITH_OLD_AVI_LIB) && (WITH_OLD_AVI_LIB == 1))
					pDetectionContext->pStreamType->application_type = RMFP_application_type_AUDIO;
#else
					pDetectionContext->pStreamType->application_type = RMFP_application_type_RIFF;
#endif

					if ((pSystemInfo) && (pInfo->Data.System.Info.Data.RIFF.Type == RMSystemDetector_RIFF_Type_WAVE)) {


						pSystemInfo->SkipFirstNBytes = pInfo->Data.System.Info.Data.RIFF.Data.WAVE.PayloadOffset;
						pSystemInfo->SendNBytes = pInfo->Data.System.Info.Data.RIFF.Data.WAVE.PayloadLength;

						RMDBGLOG((ENABLE, "Skip first %lu bytes\n", pSystemInfo->SkipFirstNBytes));
						RMDBGLOG((ENABLE, "Send %lu bytes\n", pSystemInfo->SendNBytes));

						//pDetectionContext->pStreamInfo->SystemStreamCount++;

					}

					break;
				case RMSystemDetector_RIFF_Type_AIFF:
					RMDBGLOG((ENABLE, "AIFF\n"));
					pDetectionContext->pStreamType->application_type = RMFP_application_type_RIFF;
					break;
				case RMSystemDetector_RIFF_Type_UNKNOWN:
					RMDBGLOG((ENABLE, "UNKNOWN\n"));
					break;
				}


				if (pSystemInfo) {

					pSystemInfo->DemuxMode = (RMuint32)pInfo->Data.System.Info.Data.RIFF.Type;

					//pDetectionContext->pStreamInfo->SystemStreamCount++;

				}


			}
		}

		break;
	case RMdetector3_streamType_SYSTEM_FLV:
		if (pDetectionContext->pStreamType) {
			pDetectionContext->pStreamType->application_type = RMFP_application_type_FLV;
		}
		break;

	case RMdetector3_streamType_SYSTEM_OGG:
		if (pDetectionContext->pStreamType) {
			RMDBGLOG((ENABLE, "OGG\n"));

			pDetectionContext->pStreamType->application_type = RMFP_application_type_OGG;
		}
		break;

	case RMdetector3_streamType_SYSTEM_RealMedia:
		if (pDetectionContext->pStreamType) {
			pDetectionContext->pStreamType->application_type = RMFP_application_type_REALMEDIA;
		}
		break;

	case RMdetector3_streamType_SYSTEM_HLS:
		if (pDetectionContext->pStreamType) {
			pDetectionContext->pStreamType->application_type = RMFP_application_type_HLS;
		}
		break;
	}


	return;
}

static void video_stream_callback(void *pContext, struct RMDetector3_Specific_Info *pInfo, RMuint32 parentStreamID, RMuint32 streamID)
{
	RMuint32 i;
	struct stream_type_detection_context *pDetectionContext = NULL;
	struct RMFPStreamInfo_Video *pVideoInfo = NULL;

	if (!pContext)
		return;

	pDetectionContext = (struct stream_type_detection_context *)pContext;

	RMDBGLOG((ENABLE, "video(PSID %lu, SID %lu)\n", parentStreamID, streamID));

	if (pDetectionContext->verbose) {

		if (parentStreamID == pDetectionContext->currentRootStreamID) {

			for (i = 0; i < pDetectionContext->nestingLevel + 1; i++)
				RMDBGPRINT((ENABLE, "\t"));
		}

		RMDBGPRINT((ENABLE, "[%2lu %2lu ] %s", parentStreamID, streamID, print_type(pInfo->Type)));


		if (!pInfo->Data.Video.PID_INFO_VALID)
			RMDBGPRINT((ENABLE, "\n"));
		else
			RMDBGPRINT((ENABLE, " (pid=%lu [0x%lx] subid=%lu [0x%lx] pidType=%lu [0x%lx])\n",
				    pInfo->Data.Video.pid,
				    pInfo->Data.Video.pid,
				    pInfo->Data.Video.subid,
				    pInfo->Data.Video.subid,
				    pInfo->Data.Video.pidType,
				    pInfo->Data.Video.pidType));
	}



	if (pDetectionContext->pStreamInfo) {
		// common video info

		pVideoInfo = get_video_info_ptr(pDetectionContext);
		if (!pVideoInfo) {
			RMNOTIFY((NULL, RM_ERROR, "Cannot get video info ptr\n"));
			return;
		}

		pVideoInfo->Version        = GET_VERSION_FROM_MAGIC(RMFP_STREAMINFO_VIDEO_VERSION);
		pVideoInfo->StreamID       = streamID;
		pVideoInfo->ParentStreamID = parentStreamID;

		if (pInfo->Data.Video.PID_INFO_VALID) {
			pVideoInfo->PID     = pInfo->Data.Video.pid;
			pVideoInfo->SubID   = pInfo->Data.Video.subid;
			pVideoInfo->PIDType = pInfo->Data.Video.pidType;
		}
	}


	if (pVideoInfo) 
		pVideoInfo->isSupported = TRUE;

	// get specific data
	//RMDetector3GetStreamSpecificInfo(context, streamNum, type, &info);

	// big switch...
	switch (pInfo->Type) {
	case RMdetector3_streamType_UNKNOWN:
	case RMdetector3_streamType_ELEMENTARY_AUDIO:
	case RMdetector3_streamType_ELEMENTARY_VIDEO:
	case RMdetector3_streamType_ELEMENTARY_PICTURE:
	case RMdetector3_streamType_SYSTEM:
		if (pVideoInfo) 
			pVideoInfo->isSupported = FALSE;
		break;

	// elementary audio
	case RMdetector3_streamType_AUDIO_AC3:
	case RMdetector3_streamType_AUDIO_ADIF:
	case RMdetector3_streamType_AUDIO_ADTS:
	case RMdetector3_streamType_AUDIO_DTS:
	case RMdetector3_streamType_AUDIO_DVD:
	case RMdetector3_streamType_AUDIO_LATM:
	case RMdetector3_streamType_AUDIO_MPEG:
	case RMdetector3_streamType_AUDIO_MPEG1: //unused?
	case RMdetector3_streamType_AUDIO_MPEG1_LAYER3:
	case RMdetector3_streamType_AUDIO_MPEG2: //unused?
	case RMdetector3_streamType_AUDIO_MPEG2_LAYER1:
	case RMdetector3_streamType_AUDIO_MPEG2_LAYER2:
	case RMdetector3_streamType_AUDIO_MPEG2_LAYER3:
	case RMdetector3_streamType_AUDIO_PCM:
	case RMdetector3_streamType_AUDIO_REVERSE_PCM:
	case RMdetector3_streamType_AUDIO_WMA:
	case RMdetector3_streamType_AUDIO_WMAPRO:
	case RMdetector3_streamType_AUDIO_WMATS:
	case RMdetector3_streamType_AUDIO_EAC3:
	case RMdetector3_streamType_AUDIO_MLP:
	case RMdetector3_streamType_AUDIO_TrueHD:
	case RMdetector3_streamType_AUDIO_Vorbis:
	case RMdetector3_streamType_AUDIO_FLAC:
	case RMdetector3_streamType_AUDIO_DRA:
	case RMdetector3_streamType_AUDIO_AG711_ULAW:
		if (pVideoInfo) 
			pVideoInfo->isSupported = FALSE;
		break;

	// pictures
	case RMdetector3_streamType_BMP:
	case RMdetector3_streamType_JPEG:
	case RMdetector3_streamType_TIFF:
	case RMdetector3_streamType_PNG:
	case RMdetector3_streamType_GIF:
		if (pVideoInfo) 
			pVideoInfo->isSupported = FALSE;
		break;

	// subpicture
	case RMdetector3_streamType_SPU_DVD:
	case RMdetector3_streamType_SPU_Bluray:
	case RMdetector3_streamType_SPU_DVB:
		if (pVideoInfo) 
			pVideoInfo->isSupported = FALSE;
		break;

	// elementary video
	case RMdetector3_streamType_VIDEO_AVS:

		if (pVideoInfo) {
			pVideoInfo->Codec = EMhwlibVideoCodec_AVS;
			pVideoInfo->MaxWidth = 1920;
			pVideoInfo->MaxHeight = 1080;

			//pDetectionContext->pStreamInfo->VideoStreamCount++;

		}

		break;

	case RMdetector3_streamType_VIDEO_XVID:
	case RMdetector3_streamType_VIDEO_DIVX4:
	case RMdetector3_streamType_VIDEO_MPEG4:

		if (pVideoInfo) {

			pVideoInfo->skipNCP = pInfo->Data.Video.Info.Data.MPEG4.SkipNCP;

			pVideoInfo->Codec = EMhwlibVideoCodec_MPEG4;
			pVideoInfo->MaxWidth = 1920;
			pVideoInfo->MaxHeight = 1080;

			//pDetectionContext->pStreamInfo->VideoStreamCount++;

		}


		if (pDetectionContext->verbose) {
			if (pInfo->Data.Video.Info.Data.MPEG4.SkipNCP)
				RMDBGPRINT((ENABLE, "\tMPEG4 skip NCP = 1\n"));
		}

		break;

	case RMdetector3_streamType_VIDEO_DIVX3:

		if (pVideoInfo) {

			pVideoInfo->Codec = EMhwlibVideoCodec_DIVX3;
			pVideoInfo->MaxWidth = 1920;
			pVideoInfo->MaxHeight = 1080;

			//pDetectionContext->pStreamInfo->VideoStreamCount++;

		}

		break;
	case RMdetector3_streamType_VIDEO_H263:

		if (pVideoInfo) {

			// H263 is MPEG4 codec
			pVideoInfo->Codec = EMhwlibVideoCodec_MPEG4;
			pVideoInfo->MaxWidth = 1920;
			pVideoInfo->MaxHeight = 1080;

			//pDetectionContext->pStreamInfo->VideoStreamCount++;

		}

		break;

	case RMdetector3_streamType_VIDEO_H264:

		if (pVideoInfo) {

			pVideoInfo->Codec = EMhwlibVideoCodec_H264;
			pVideoInfo->Profile = EMhwlib_H264_BaselineProfile;
			pVideoInfo->Level = EMhwlib_H264_Level_4;
			pVideoInfo->MaxWidth = 1920;
			pVideoInfo->MaxHeight = 1080;


			//pDetectionContext->pStreamInfo->VideoStreamCount++;

		}

		break;

	case RMdetector3_streamType_VIDEO_MJPEG:

		if (pVideoInfo) {

			//pDetectionContext->pStreamInfo->VideoStreamCount++;
		}

		break;

	case RMdetector3_streamType_VIDEO_MPEG12:

		if (pVideoInfo) {

			pVideoInfo->Codec = EMhwlibVideoCodec_MPEG2;
			pVideoInfo->MaxWidth = 1920;
			pVideoInfo->MaxHeight = 1080;


			//pDetectionContext->pStreamInfo->VideoStreamCount++;

		}

		break;


	case RMdetector3_streamType_VIDEO_VC1:

		if (pVideoInfo) {

			pVideoInfo->Codec = EMhwlibVideoCodec_VC1;
			pVideoInfo->MaxWidth = 1920;
			pVideoInfo->MaxHeight = 1080;

			//pDetectionContext->pStreamInfo->VideoStreamCount++;

		}

		break;

	case RMdetector3_streamType_VIDEO_WMV:

		if (pVideoInfo) {

			pVideoInfo->Codec = EMhwlibVideoCodec_WMV;
			pVideoInfo->MaxWidth = 1920;
			pVideoInfo->MaxHeight = 1080;


			//pDetectionContext->pStreamInfo->VideoStreamCount++;

		}

		break;


	// system
	case RMdetector3_streamType_SYSTEM_ASF:
	case RMdetector3_streamType_SYSTEM_DVD:
	case RMdetector3_streamType_SYSTEM_ID3:
	case RMdetector3_streamType_SYSTEM_M1S:
	case RMdetector3_streamType_SYSTEM_M2P:
	case RMdetector3_streamType_SYSTEM_M2T:
	case RMdetector3_streamType_SYSTEM_MKV:
	case RMdetector3_streamType_SYSTEM_MP4:
	case RMdetector3_streamType_SYSTEM_RIFF:
	case RMdetector3_streamType_SYSTEM_FLV:
	case RMdetector3_streamType_SYSTEM_OGG:
	case RMdetector3_streamType_SYSTEM_RealMedia:
	case RMdetector3_streamType_SYSTEM_HLS:
		if (pVideoInfo) 
			pVideoInfo->isSupported = FALSE;
		break;
	}


	return;
}

static void audio_stream_callback(void *pContext, struct RMDetector3_Specific_Info *pInfo, RMuint32 parentStreamID, RMuint32 streamID)
{
	RMuint32 i;
	struct stream_type_detection_context *pDetectionContext = NULL;
	struct RMFPStreamInfo_Audio *pAudioInfo = NULL;

	if (!pContext)
		return;

	pDetectionContext = (struct stream_type_detection_context *)pContext;

	RMDBGLOG((ENABLE, "audio(PSID %lu, SID %lu)\n", parentStreamID, streamID));

	if (pDetectionContext->verbose) {

		if (parentStreamID == pDetectionContext->currentRootStreamID) {

			for (i = 0; i < pDetectionContext->nestingLevel + 1; i++)
				RMDBGPRINT((ENABLE, "\t"));
		}

		RMDBGPRINT((ENABLE, "[%2lu %2lu ] %s", parentStreamID, streamID, print_type(pInfo->Type)));

		if (!pInfo->Data.Audio.PID_INFO_VALID)
			RMDBGPRINT((ENABLE, "\n"));
		else
			RMDBGPRINT((ENABLE, " (pid=%lu [0x%lx] subid=%lu [0x%lx] pidType=%lu [0x%lx])\n",
				    pInfo->Data.Audio.pid,
				    pInfo->Data.Audio.pid,
				    pInfo->Data.Audio.subid,
				    pInfo->Data.Audio.subid,
				    pInfo->Data.Audio.pidType,
				    pInfo->Data.Audio.pidType));
	}


	if (pDetectionContext->pStreamInfo) {

		pAudioInfo = get_audio_info_ptr(pDetectionContext);
		if (!pAudioInfo) {
			RMNOTIFY((NULL, RM_ERROR, "Cannot get audio info ptr\n"));
			return;
		}

		pAudioInfo->Version        = GET_VERSION_FROM_MAGIC(RMFP_STREAMINFO_AUDIO_VERSION);
		pAudioInfo->StreamID       = streamID;
		pAudioInfo->ParentStreamID = parentStreamID;

		if (pInfo->Data.Audio.PID_INFO_VALID) {
			pAudioInfo->PID     = pInfo->Data.Audio.pid;
			pAudioInfo->SubID   = pInfo->Data.Audio.subid;
			pAudioInfo->PIDType = pInfo->Data.Audio.pidType;
			pAudioInfo->TSPriority = pInfo->Data.Audio.tsPriority;
		}

	}

	if (pAudioInfo) 
		pAudioInfo->isSupported = TRUE;

	switch (pInfo->Type) {
	case RMdetector3_streamType_UNKNOWN:
	case RMdetector3_streamType_ELEMENTARY_AUDIO:
	case RMdetector3_streamType_ELEMENTARY_VIDEO:
	case RMdetector3_streamType_ELEMENTARY_PICTURE:
	case RMdetector3_streamType_SYSTEM:
		if (pAudioInfo) 
			pAudioInfo->isSupported = FALSE;
		break;

		// elementary audio
	case RMdetector3_streamType_AUDIO_AC3:

		if (pAudioInfo) {
			pAudioInfo->Codec = AudioDecoder_Codec_AC3;

			if (pInfo->Data.Audio.SPECIFIC_INFO_VALID) {

				pAudioInfo->SampleRate = pInfo->Data.Audio.Info.Data.AC3.SampleRate;
				pAudioInfo->Channels   = pInfo->Data.Audio.Info.Data.AC3.Channels;
				pAudioInfo->Bitrate    = pInfo->Data.Audio.Info.Data.AC3.Bitrate;

				if (pDetectionContext->verbose)
					RMDBGPRINT((ENABLE, "\tAC3: SampleRate %lu, Channels %lu, Bitrate %lu\n",
						    pInfo->Data.Audio.Info.Data.AC3.SampleRate,
						    pInfo->Data.Audio.Info.Data.AC3.Channels,
						    pInfo->Data.Audio.Info.Data.AC3.Bitrate));
			}

			//pDetectionContext->pStreamInfo->AudioStreamCount++;

		}

		break;

	case RMdetector3_streamType_AUDIO_EAC3:

		if (pAudioInfo) {
			pAudioInfo->Codec = AudioDecoder_Codec_AC3;

			if (pInfo->Data.Audio.SPECIFIC_INFO_VALID) {

				pAudioInfo->SampleRate = pInfo->Data.Audio.Info.Data.EAC3.SampleRate;
				pAudioInfo->Channels   = pInfo->Data.Audio.Info.Data.EAC3.Channels;
				pAudioInfo->Bitrate    = pInfo->Data.Audio.Info.Data.EAC3.Bitrate;

				if (pDetectionContext->verbose)
					RMDBGPRINT((ENABLE, "\tEAC3: SampleRate %lu, Channels %lu, Bitrate %lu\n",
						    pInfo->Data.Audio.Info.Data.EAC3.SampleRate,
						    pInfo->Data.Audio.Info.Data.EAC3.Channels,
						    pInfo->Data.Audio.Info.Data.EAC3.Bitrate));
			}

			//pDetectionContext->pStreamInfo->AudioStreamCount++;

		}

		break;

	case RMdetector3_streamType_AUDIO_ADIF:

		if (pAudioInfo) {
			pAudioInfo->Codec = AudioDecoder_Codec_AAC;
			pAudioInfo->SubCodec = 0;

			if (pInfo->Data.Audio.SPECIFIC_INFO_VALID) {

				pAudioInfo->SampleRate = pInfo->Data.Audio.Info.Data.ADIF.SampleRate;
				pAudioInfo->Channels   = pInfo->Data.Audio.Info.Data.ADIF.Channels;
				pAudioInfo->Bitrate    = pInfo->Data.Audio.Info.Data.ADIF.Bitrate;
				pAudioInfo->isVBR      = pInfo->Data.Audio.Info.Data.ADIF.isVBR;

				if (pDetectionContext->verbose)
					RMDBGPRINT((ENABLE, "\tADIF: SampleRate %lu, Channels %lu, Bitrate %lu, isVBR %lu\n",
						    pInfo->Data.Audio.Info.Data.ADIF.SampleRate,
						    pInfo->Data.Audio.Info.Data.ADIF.Channels,
						    pInfo->Data.Audio.Info.Data.ADIF.Bitrate,
						    (RMuint32)pInfo->Data.Audio.Info.Data.ADIF.isVBR));

			}

			//pDetectionContext->pStreamInfo->AudioStreamCount++;

		}

		break;
	case RMdetector3_streamType_AUDIO_ADTS:

		if (pAudioInfo) {
			pAudioInfo->Codec = AudioDecoder_Codec_AAC;
			pAudioInfo->SubCodec = 1;

			if (pInfo->Data.Audio.SPECIFIC_INFO_VALID) {

				pAudioInfo->SampleRate = pInfo->Data.Audio.Info.Data.ADTS.SampleRate;
				pAudioInfo->Channels   = pInfo->Data.Audio.Info.Data.ADTS.Channels;
				pAudioInfo->isVBR      = pInfo->Data.Audio.Info.Data.ADTS.isVBR;

				if (pDetectionContext->verbose)
					RMDBGPRINT((ENABLE, "\tADTS: SampleRate %lu, Channels %lu, isVBR %lu\n",
						    pInfo->Data.Audio.Info.Data.ADTS.SampleRate,
						    pInfo->Data.Audio.Info.Data.ADTS.Channels,
						    (RMuint32)pInfo->Data.Audio.Info.Data.ADTS.isVBR));
			}

			//pDetectionContext->pStreamInfo->AudioStreamCount++;

		}


		break;
	case RMdetector3_streamType_AUDIO_DTS:

		if (pAudioInfo) {
			pAudioInfo->Codec = AudioDecoder_Codec_DTS;

			if (pInfo->Data.Audio.SPECIFIC_INFO_VALID) {

				pAudioInfo->SampleRate = pInfo->Data.Audio.Info.Data.DTS.SampleRate;
				pAudioInfo->Channels   = pInfo->Data.Audio.Info.Data.DTS.Channels;
				pAudioInfo->Bitrate    = pInfo->Data.Audio.Info.Data.DTS.Bitrate;

				pAudioInfo->BitsPerSample = pInfo->Data.Audio.Info.Data.DTS.BitsPerSample;
				pAudioInfo->MSBFirst      = pInfo->Data.Audio.Info.Data.DTS.MSBFirst;

				if (pDetectionContext->verbose)
					RMDBGPRINT((ENABLE, "\tDTS: SampleRate %lu, Channels %lu, Bitrate %lu, BitsPerSample %lu, MSBFirst %lu\n",
						    pInfo->Data.Audio.Info.Data.DTS.SampleRate,
						    pInfo->Data.Audio.Info.Data.DTS.Channels,
						    pInfo->Data.Audio.Info.Data.DTS.Bitrate,
						    pInfo->Data.Audio.Info.Data.DTS.BitsPerSample,
						    pInfo->Data.Audio.Info.Data.DTS.MSBFirst));
			}

			//pDetectionContext->pStreamInfo->AudioStreamCount++;
		}


		break;
	case RMdetector3_streamType_AUDIO_DVD:
		break;
	case RMdetector3_streamType_AUDIO_LATM:

		if (pAudioInfo) {
			pAudioInfo->Codec    = AudioDecoder_Codec_AAC;
			pAudioInfo->SubCodec = 3;

			//pDetectionContext->pStreamInfo->AudioStreamCount++;

		}


		break;
	case RMdetector3_streamType_AUDIO_MPEG: // the more generic

		if (pAudioInfo) {
			pAudioInfo->Codec = AudioDecoder_Codec_MPEG1;

			if (pInfo->Data.Audio.SPECIFIC_INFO_VALID) {

				pAudioInfo->SampleRate = pInfo->Data.Audio.Info.Data.MPEGAudio.SampleRate;
				pAudioInfo->Channels   = pInfo->Data.Audio.Info.Data.MPEGAudio.Channels;
				pAudioInfo->Bitrate    = pInfo->Data.Audio.Info.Data.MPEGAudio.Bitrate;
				pAudioInfo->isVBR      = pInfo->Data.Audio.Info.Data.MPEGAudio.isVBR;
				pAudioInfo->VBRDuration= pInfo->Data.Audio.Info.Data.MPEGAudio.VBRDuration;

				if (pDetectionContext->verbose)
					RMDBGPRINT((ENABLE, "\tMPEG [ID 0x%lx, Layer %lu]: SampleRate %lu, Channels %lu, Bitrate %lu, isVBR %lu\n",
						    pInfo->Data.Audio.Info.Data.MPEGAudio.ID,
						    pInfo->Data.Audio.Info.Data.MPEGAudio.Layer,
						    pInfo->Data.Audio.Info.Data.MPEGAudio.SampleRate,
						    pInfo->Data.Audio.Info.Data.MPEGAudio.Channels,
						    pInfo->Data.Audio.Info.Data.MPEGAudio.Bitrate,
						    (RMuint32)pInfo->Data.Audio.Info.Data.MPEGAudio.isVBR));

			}

			//pDetectionContext->pStreamInfo->AudioStreamCount++;

		}

		break;

	case RMdetector3_streamType_AUDIO_MPEG1: //unused?

		if (pAudioInfo) {
			pAudioInfo->Codec = AudioDecoder_Codec_MPEG1;

			if (pInfo->Data.Audio.SPECIFIC_INFO_VALID) {

				pAudioInfo->SampleRate = pInfo->Data.Audio.Info.Data.MPEGAudio.SampleRate;
				pAudioInfo->Channels   = pInfo->Data.Audio.Info.Data.MPEGAudio.Channels;
				pAudioInfo->Bitrate    = pInfo->Data.Audio.Info.Data.MPEGAudio.Bitrate;
				pAudioInfo->isVBR      = pInfo->Data.Audio.Info.Data.MPEGAudio.isVBR;

				if (pDetectionContext->verbose)
					RMDBGPRINT((ENABLE, "\tMPEG1: SampleRate %lu, Channels %lu, Bitrate %lu, isVBR %lu\n",
						    pInfo->Data.Audio.Info.Data.MPEGAudio.SampleRate,
						    pInfo->Data.Audio.Info.Data.MPEGAudio.Channels,
						    pInfo->Data.Audio.Info.Data.MPEGAudio.Bitrate,
						    (RMuint32)pInfo->Data.Audio.Info.Data.MPEGAudio.isVBR));

			}

			//pDetectionContext->pStreamInfo->AudioStreamCount++;

		}

		break;
	case RMdetector3_streamType_AUDIO_MPEG1_LAYER3:

		if (pAudioInfo) {
			pAudioInfo->Codec = AudioDecoder_Codec_MPEG1;

			if (pInfo->Data.Audio.SPECIFIC_INFO_VALID) {

				pAudioInfo->SampleRate = pInfo->Data.Audio.Info.Data.MPEGAudio.SampleRate;
				pAudioInfo->Channels   = pInfo->Data.Audio.Info.Data.MPEGAudio.Channels;
				pAudioInfo->Bitrate    = pInfo->Data.Audio.Info.Data.MPEGAudio.Bitrate;
				pAudioInfo->isVBR      = pInfo->Data.Audio.Info.Data.MPEGAudio.isVBR;

				if (pDetectionContext->verbose)
					RMDBGPRINT((ENABLE, "\tMPEG1layer3: SampleRate %lu, Channels %lu, Bitrate %lu, isVBR %lu\n",
						    pInfo->Data.Audio.Info.Data.MPEGAudio.SampleRate,
						    pInfo->Data.Audio.Info.Data.MPEGAudio.Channels,
						    pInfo->Data.Audio.Info.Data.MPEGAudio.Bitrate,
						    (RMuint32)pInfo->Data.Audio.Info.Data.MPEGAudio.isVBR));

			}

			//pDetectionContext->pStreamInfo->AudioStreamCount++;

		}


		break;
	case RMdetector3_streamType_AUDIO_MPEG2: //unused?

		if (pAudioInfo) {
			pAudioInfo->Codec = AudioDecoder_Codec_MPEG1;

			if (pInfo->Data.Audio.SPECIFIC_INFO_VALID) {

				pAudioInfo->SampleRate = pInfo->Data.Audio.Info.Data.MPEGAudio.SampleRate;
				pAudioInfo->Channels   = pInfo->Data.Audio.Info.Data.MPEGAudio.Channels;
				pAudioInfo->Bitrate    = pInfo->Data.Audio.Info.Data.MPEGAudio.Bitrate;
				pAudioInfo->isVBR      = pInfo->Data.Audio.Info.Data.MPEGAudio.isVBR;

				if (pDetectionContext->verbose)
					RMDBGPRINT((ENABLE, "\tMPEG2: SampleRate %lu, Channels %lu, Bitrate %lu, isVBR %lu\n",
						    pInfo->Data.Audio.Info.Data.MPEGAudio.SampleRate,
						    pInfo->Data.Audio.Info.Data.MPEGAudio.Channels,
						    pInfo->Data.Audio.Info.Data.MPEGAudio.Bitrate,
						    (RMuint32)pInfo->Data.Audio.Info.Data.MPEGAudio.isVBR));

			}

			//pDetectionContext->pStreamInfo->AudioStreamCount++;

		}

		break;
	case RMdetector3_streamType_AUDIO_MPEG2_LAYER1:

		if (pAudioInfo) {
			pAudioInfo->Codec = AudioDecoder_Codec_MPEG1;

			if (pInfo->Data.Audio.SPECIFIC_INFO_VALID) {

				pAudioInfo->SampleRate = pInfo->Data.Audio.Info.Data.MPEGAudio.SampleRate;
				pAudioInfo->Channels   = pInfo->Data.Audio.Info.Data.MPEGAudio.Channels;
				pAudioInfo->Bitrate    = pInfo->Data.Audio.Info.Data.MPEGAudio.Bitrate;
				pAudioInfo->isVBR      = pInfo->Data.Audio.Info.Data.MPEGAudio.isVBR;

				if (pDetectionContext->verbose)
					RMDBGPRINT((ENABLE, "\tMPEG2layer1: SampleRate %lu, Channels %lu, Bitrate %lu, isVBR %lu\n",
						    pInfo->Data.Audio.Info.Data.MPEGAudio.SampleRate,
						    pInfo->Data.Audio.Info.Data.MPEGAudio.Channels,
						    pInfo->Data.Audio.Info.Data.MPEGAudio.Bitrate,
						    (RMuint32)pInfo->Data.Audio.Info.Data.MPEGAudio.isVBR));

			}

			//pDetectionContext->pStreamInfo->AudioStreamCount++;

		}


		break;
	case RMdetector3_streamType_AUDIO_MPEG2_LAYER2:

		if (pAudioInfo) {
			pAudioInfo->Codec = AudioDecoder_Codec_MPEG1;

			if (pInfo->Data.Audio.SPECIFIC_INFO_VALID) {

				pAudioInfo->SampleRate = pInfo->Data.Audio.Info.Data.MPEGAudio.SampleRate;
				pAudioInfo->Channels   = pInfo->Data.Audio.Info.Data.MPEGAudio.Channels;
				pAudioInfo->Bitrate    = pInfo->Data.Audio.Info.Data.MPEGAudio.Bitrate;
				pAudioInfo->isVBR      = pInfo->Data.Audio.Info.Data.MPEGAudio.isVBR;

				if (pDetectionContext->verbose)
					RMDBGPRINT((ENABLE, "\tMPEG2layer2: SampleRate %lu, Channels %lu, Bitrate %lu, isVBR %lu\n",
						    pInfo->Data.Audio.Info.Data.MPEGAudio.SampleRate,
						    pInfo->Data.Audio.Info.Data.MPEGAudio.Channels,
						    pInfo->Data.Audio.Info.Data.MPEGAudio.Bitrate,
						    (RMuint32)pInfo->Data.Audio.Info.Data.MPEGAudio.isVBR));

			}

			//pDetectionContext->pStreamInfo->AudioStreamCount++;

		}

		break;
	case RMdetector3_streamType_AUDIO_MPEG2_LAYER3:

		if (pAudioInfo) {
			pAudioInfo->Codec = AudioDecoder_Codec_MPEG1;

			if (pInfo->Data.Audio.SPECIFIC_INFO_VALID) {

				pAudioInfo->SampleRate = pInfo->Data.Audio.Info.Data.MPEGAudio.SampleRate;
				pAudioInfo->Channels   = pInfo->Data.Audio.Info.Data.MPEGAudio.Channels;
				pAudioInfo->Bitrate    = pInfo->Data.Audio.Info.Data.MPEGAudio.Bitrate;
				pAudioInfo->isVBR      = pInfo->Data.Audio.Info.Data.MPEGAudio.isVBR;

				if (pDetectionContext->verbose)
					RMDBGPRINT((ENABLE, "\tMPEG2layer3: SampleRate %lu, Channels %lu, Bitrate %lu, isVBR %lu\n",
						    pInfo->Data.Audio.Info.Data.MPEGAudio.SampleRate,
						    pInfo->Data.Audio.Info.Data.MPEGAudio.Channels,
						    pInfo->Data.Audio.Info.Data.MPEGAudio.Bitrate,
						    (RMuint32)pInfo->Data.Audio.Info.Data.MPEGAudio.isVBR));

			}

			//pDetectionContext->pStreamInfo->AudioStreamCount++;

		}
		break;

	case RMdetector3_streamType_AUDIO_PCM:


		// check if we have to select PCM or WAVE data, we pick WAVE if system=elementary_audio, else PCM
		if (pDetectionContext->pStreamInfo && pInfo->Data.Audio.SPECIFIC_INFO_VALID) {

			if ((pDetectionContext->pStreamInfo->SystemStreamCount)
			    || (pDetectionContext->pStreamType->application_type != RMFP_application_type_AUDIO)) {

				RMDBGLOG((ENABLE, "app type %lu\n", pDetectionContext->pStreamType->application_type));

				// PCM

				if (pAudioInfo) {
					pAudioInfo->Codec         = AudioDecoder_Codec_PCM;
					pAudioInfo->SubCodec      = pInfo->Data.Audio.Info.Data.PCM.Format;
					pAudioInfo->Channels      = pInfo->Data.Audio.Info.Data.PCM.Channels;
					pAudioInfo->SampleRate    = pInfo->Data.Audio.Info.Data.PCM.SampleRate;
					pAudioInfo->BitsPerSample = pInfo->Data.Audio.Info.Data.PCM.BitsPerSample;

					//pDetectionContext->pStreamInfo->AudioStreamCount++;

				}

				if (pDetectionContext->verbose) {
					RMDBGPRINT((ENABLE, "\tPCM: subcodec %lu, SampleRate %lu, Channels %lu, BitsPerSample %lu\n",
						    pInfo->Data.Audio.Info.Data.PCM.Format,
						    pInfo->Data.Audio.Info.Data.PCM.SampleRate,
						    pInfo->Data.Audio.Info.Data.PCM.Channels,
						    pInfo->Data.Audio.Info.Data.PCM.BitsPerSample));
				}



			}
			else {

				// WAVE/PCM

// TODO: review this

				RMDBGLOG((ENABLE, "app type %lu\n", pDetectionContext->pStreamType->application_type));

				if (pAudioInfo) {
					pAudioInfo->Codec         = AudioDecoder_Codec_PCM;
					pAudioInfo->SubCodec      = pInfo->Data.Audio.Info.Data.PCM.Format;
					pAudioInfo->Channels      = pInfo->Data.Audio.Info.Data.PCM.Channels;
					pAudioInfo->SampleRate    = pInfo->Data.Audio.Info.Data.PCM.SampleRate;
					pAudioInfo->BitsPerSample = pInfo->Data.Audio.Info.Data.PCM.BitsPerSample;

					//pDetectionContext->pStreamInfo->AudioStreamCount++;

				}

				if (pDetectionContext->verbose) {
					RMDBGPRINT((ENABLE, "\tPCM: subcodec %lu, SampleRate %lu, Channels %lu, BitsPerSample %lu\n",
						    pInfo->Data.Audio.Info.Data.PCM.Format,
						    pInfo->Data.Audio.Info.Data.PCM.SampleRate,
						    pInfo->Data.Audio.Info.Data.PCM.Channels,
						    pInfo->Data.Audio.Info.Data.PCM.BitsPerSample));
				}
			}
		}



		break;
	case RMdetector3_streamType_AUDIO_REVERSE_PCM:

		RMDBGLOG((ENABLE, "UNUSED?\n"));

		break;
	case RMdetector3_streamType_AUDIO_WMA:

		if (pAudioInfo) {
			pAudioInfo->Codec = AudioDecoder_Codec_WMA;

			if (pInfo->Data.Audio.SPECIFIC_INFO_VALID) {

				pAudioInfo->SampleRate    = pInfo->Data.Audio.Info.Data.WMA.SampleRate;
				pAudioInfo->Channels      = pInfo->Data.Audio.Info.Data.WMA.Channels;
				pAudioInfo->Bitrate       = pInfo->Data.Audio.Info.Data.WMA.Bitrate;
				pAudioInfo->BitsPerSample = pInfo->Data.Audio.Info.Data.WMA.BitsPerSample;

				if (pDetectionContext->verbose)
					RMDBGPRINT((ENABLE, "\tWMA: SampleRate %lu, Channels %lu, BitsPerSample %lu, Bitrate %lu\n",
						    pInfo->Data.Audio.Info.Data.WMA.SampleRate,
						    pInfo->Data.Audio.Info.Data.WMA.Channels,
						    pInfo->Data.Audio.Info.Data.WMA.BitsPerSample,
						    pInfo->Data.Audio.Info.Data.WMA.Bitrate));

			}

			//pDetectionContext->pStreamInfo->AudioStreamCount++;

		}


		break;
	case RMdetector3_streamType_AUDIO_WMAPRO:


		if (pAudioInfo) {
			pAudioInfo->Codec = AudioDecoder_Codec_WMAPRO;

			if (pInfo->Data.Audio.SPECIFIC_INFO_VALID) {

				pAudioInfo->SampleRate    = pInfo->Data.Audio.Info.Data.WMA.SampleRate;
				pAudioInfo->Channels      = pInfo->Data.Audio.Info.Data.WMA.Channels;
				pAudioInfo->Bitrate       = pInfo->Data.Audio.Info.Data.WMA.Bitrate;
				pAudioInfo->BitsPerSample = pInfo->Data.Audio.Info.Data.WMA.BitsPerSample;

				if (pDetectionContext->verbose)
					RMDBGPRINT((ENABLE, "\tWMAPro: SampleRate %lu, Channels %lu, BitsPerSample %lu, Bitrate %lu\n",
						    pInfo->Data.Audio.Info.Data.WMA.SampleRate,
						    pInfo->Data.Audio.Info.Data.WMA.Channels,
						    pInfo->Data.Audio.Info.Data.WMA.BitsPerSample,
						    pInfo->Data.Audio.Info.Data.WMA.Bitrate));

			}

			//pDetectionContext->pStreamInfo->AudioStreamCount++;

		}


		break;
	case RMdetector3_streamType_AUDIO_WMATS:

		if (pAudioInfo) {
// TODO: fix WMATS
			pAudioInfo->Codec    = AudioDecoder_Codec_WMA;
			pAudioInfo->SubCodec = 0x7a23;

			//pDetectionContext->pStreamInfo->AudioStreamCount++;

		}

		break;
	case RMdetector3_streamType_AUDIO_MLP:

		if (pAudioInfo) {
			pAudioInfo->Codec = AudioDecoder_Codec_DVDA;

			if (pInfo->Data.Audio.SPECIFIC_INFO_VALID) {

				pAudioInfo->SampleRate    = pInfo->Data.Audio.Info.Data.MLP.SampleRate;
				pAudioInfo->Channels      = pInfo->Data.Audio.Info.Data.MLP.Channels;
				pAudioInfo->Bitrate       = pInfo->Data.Audio.Info.Data.MLP.Bitrate;
				pAudioInfo->BitsPerSample = pInfo->Data.Audio.Info.Data.MLP.BitsPerSample;
				pAudioInfo->isVBR         = pInfo->Data.Audio.Info.Data.MLP.isVBR;

				if (pDetectionContext->verbose)
					RMDBGPRINT((ENABLE, "\tMLP: sampleRate %lu, Channels %lu, BitsPerSample %lu, Bitrate %lu, isVBR %lu\n",
						    pInfo->Data.Audio.Info.Data.MLP.SampleRate,
						    pInfo->Data.Audio.Info.Data.MLP.Channels,
						    pInfo->Data.Audio.Info.Data.MLP.BitsPerSample,
						    pInfo->Data.Audio.Info.Data.MLP.Bitrate,
						    pInfo->Data.Audio.Info.Data.MLP.isVBR));
			}

			//pDetectionContext->pStreamInfo->AudioStreamCount++;

		}

		break;
// not needed anymore since rmdetector has already seperate AC3 and MLP inside this TrueHD
	case RMdetector3_streamType_AUDIO_TrueHD: 

		if (pAudioInfo) {
			pAudioInfo->Codec = AudioDecoder_Codec_DVDA;

			if (pInfo->Data.Audio.SPECIFIC_INFO_VALID) {

				pAudioInfo->SampleRate    = pInfo->Data.Audio.Info.Data.TrueHD.SampleRate;
				pAudioInfo->Channels      = pInfo->Data.Audio.Info.Data.TrueHD.Channels;
				pAudioInfo->Bitrate       = pInfo->Data.Audio.Info.Data.TrueHD.Bitrate;
				pAudioInfo->BitsPerSample = pInfo->Data.Audio.Info.Data.TrueHD.BitsPerSample;
				pAudioInfo->isVBR         = pInfo->Data.Audio.Info.Data.TrueHD.isVBR;

				if (pDetectionContext->verbose)
					RMDBGPRINT((ENABLE, "\tTrueHD: sampleRate %lu, Channels %lu, BitsPerSample %lu, Bitrate %lu, isVBR %lu\n",
						    pInfo->Data.Audio.Info.Data.TrueHD.SampleRate,
						    pInfo->Data.Audio.Info.Data.TrueHD.Channels,
						    pInfo->Data.Audio.Info.Data.TrueHD.BitsPerSample,
						    pInfo->Data.Audio.Info.Data.TrueHD.Bitrate,
						    pInfo->Data.Audio.Info.Data.TrueHD.isVBR));
			}

			//pDetectionContext->pStreamInfo->AudioStreamCount++;

		}

		break;

	case RMdetector3_streamType_AUDIO_Vorbis:
	        if (pAudioInfo) {
			pAudioInfo->Codec         = AudioDecoder_Codec_VORBIS;
			pAudioInfo->SampleRate    = pInfo->Data.Audio.Info.Data.Vorbis.SampleRate;
			pAudioInfo->Channels      = pInfo->Data.Audio.Info.Data.Vorbis.Channels;
 
		}
		break;
	case RMdetector3_streamType_AUDIO_FLAC:
		if (pAudioInfo) 
			pAudioInfo->Codec = AudioDecoder_Codec_FLAC;
		break;
	case RMdetector3_streamType_AUDIO_DRA:
		if (pAudioInfo) {
			pAudioInfo->Codec	= AudioDecoder_Codec_DRA;
			pAudioInfo->SampleRate	= pInfo->Data.Audio.Info.Data.DRA.SampleRate;
			pAudioInfo->Channels	= pInfo->Data.Audio.Info.Data.DRA.Channels;
		}
		break;
	case RMdetector3_streamType_AUDIO_AG711_ULAW:
		if (pAudioInfo)
			pAudioInfo->Codec = AudioDecoder_Codec_AG711;
		break;

	// pictures
	case RMdetector3_streamType_BMP:
	case RMdetector3_streamType_JPEG:
	case RMdetector3_streamType_TIFF:
	case RMdetector3_streamType_PNG:
	case RMdetector3_streamType_GIF:

	// subpicture
	case RMdetector3_streamType_SPU_DVD:
	case RMdetector3_streamType_SPU_Bluray:
	case RMdetector3_streamType_SPU_DVB:

	// elementary video
	case RMdetector3_streamType_VIDEO_AVS:
	case RMdetector3_streamType_VIDEO_DIVX3:
	case RMdetector3_streamType_VIDEO_DIVX4:
	case RMdetector3_streamType_VIDEO_H263:
	case RMdetector3_streamType_VIDEO_H264:
	case RMdetector3_streamType_VIDEO_MJPEG:
	case RMdetector3_streamType_VIDEO_MPEG12:
	case RMdetector3_streamType_VIDEO_MPEG4:
	case RMdetector3_streamType_VIDEO_VC1:
	case RMdetector3_streamType_VIDEO_WMV:
	case RMdetector3_streamType_VIDEO_XVID:

	// system
	case RMdetector3_streamType_SYSTEM_ASF:
	case RMdetector3_streamType_SYSTEM_DVD:
	case RMdetector3_streamType_SYSTEM_ID3:
	case RMdetector3_streamType_SYSTEM_M1S:
	case RMdetector3_streamType_SYSTEM_M2P:
	case RMdetector3_streamType_SYSTEM_M2T:
	case RMdetector3_streamType_SYSTEM_MKV:
	case RMdetector3_streamType_SYSTEM_MP4:
	case RMdetector3_streamType_SYSTEM_RIFF:
	case RMdetector3_streamType_SYSTEM_FLV:
	case RMdetector3_streamType_SYSTEM_OGG:
	case RMdetector3_streamType_SYSTEM_RealMedia:
	case RMdetector3_streamType_SYSTEM_HLS:
		if (pAudioInfo) 
			pAudioInfo->isSupported = FALSE;
		break;
	}


	return;
}

static void data_stream_callback(void *pContext, struct RMDetector3_Specific_Info *pInfo, RMuint32 parentStreamID, RMuint32 streamID)
{
	RMuint32 i;
	struct stream_type_detection_context *pDetectionContext = NULL;
	struct RMFPStreamInfo_Data *pDataInfo = NULL;

	if (!pContext)
		return;

	pDetectionContext = (struct stream_type_detection_context *)pContext;

	RMDBGLOG((ENABLE, "data(PSID %lu, SID %lu)\n", parentStreamID, streamID));

	if (pDetectionContext->verbose) {

		if (parentStreamID == pDetectionContext->currentRootStreamID) {

			for (i = 0; i < pDetectionContext->nestingLevel + 1; i++)
				RMDBGPRINT((ENABLE, "\t"));
		}

		RMDBGPRINT((ENABLE, "[%2lu %2lu ] %s", parentStreamID, streamID, print_type(pInfo->Type)));

		if (!pInfo->Data.Picture.PID_INFO_VALID)
			RMDBGPRINT((ENABLE, "\n"));
		else
			RMDBGPRINT((ENABLE, " (pid=%lu [0x%lx] subid=%lu [0x%lx] pidType=%lu [0x%lx])\n",
				    pInfo->Data.Picture.pid,
				    pInfo->Data.Picture.pid,
				    pInfo->Data.Picture.subid,
				    pInfo->Data.Picture.subid,
				    pInfo->Data.Picture.pidType,
				    pInfo->Data.Picture.pidType));
	}


	if (pDetectionContext->pStreamInfo) {

		pDataInfo = get_data_info_ptr(pDetectionContext);
		if (!pDataInfo) {
			RMNOTIFY((NULL, RM_ERROR, "Cannot get data info ptr\n"));
			return;
		}

		pDataInfo->StreamID       = streamID;
		pDataInfo->ParentStreamID = parentStreamID;

		if (pInfo->Data.Audio.PID_INFO_VALID) {
			pDataInfo->PID     = pInfo->Data.Picture.pid;
			pDataInfo->SubID   = pInfo->Data.Picture.subid;
			pDataInfo->PIDType = pInfo->Data.Picture.pidType;
		}

		pDataInfo->Version = GET_VERSION_FROM_MAGIC(RMFP_STREAMINFO_DATA_VERSION);

	}

	if (pDataInfo) {
		pDataInfo->isSupported = TRUE;
		pDataInfo->Type = RMFPStreamInfoData_Unknown;
	}

	switch (pInfo->Type) {
	case RMdetector3_streamType_UNKNOWN:
	case RMdetector3_streamType_ELEMENTARY_AUDIO:
	case RMdetector3_streamType_ELEMENTARY_VIDEO:
	case RMdetector3_streamType_ELEMENTARY_PICTURE:
	case RMdetector3_streamType_SYSTEM:
		if (pDataInfo) 
			pDataInfo->isSupported = FALSE;
		break;

	// elementary audio
	case RMdetector3_streamType_AUDIO_AC3:
	case RMdetector3_streamType_AUDIO_ADIF:
	case RMdetector3_streamType_AUDIO_ADTS:
	case RMdetector3_streamType_AUDIO_DTS:
	case RMdetector3_streamType_AUDIO_DVD:
	case RMdetector3_streamType_AUDIO_LATM:
	case RMdetector3_streamType_AUDIO_MPEG:
	case RMdetector3_streamType_AUDIO_MPEG1: //unused?
	case RMdetector3_streamType_AUDIO_MPEG1_LAYER3:
	case RMdetector3_streamType_AUDIO_MPEG2: //unused?
	case RMdetector3_streamType_AUDIO_MPEG2_LAYER1:
	case RMdetector3_streamType_AUDIO_MPEG2_LAYER2:
	case RMdetector3_streamType_AUDIO_MPEG2_LAYER3:
	case RMdetector3_streamType_AUDIO_PCM:
	case RMdetector3_streamType_AUDIO_REVERSE_PCM:
	case RMdetector3_streamType_AUDIO_WMA:
	case RMdetector3_streamType_AUDIO_WMAPRO:
	case RMdetector3_streamType_AUDIO_WMATS:
	case RMdetector3_streamType_AUDIO_EAC3:
	case RMdetector3_streamType_AUDIO_MLP:
	case RMdetector3_streamType_AUDIO_TrueHD:
	case RMdetector3_streamType_AUDIO_Vorbis:
	case RMdetector3_streamType_AUDIO_FLAC:
	case RMdetector3_streamType_AUDIO_DRA:
	case RMdetector3_streamType_AUDIO_AG711_ULAW:
		if (pDataInfo)
			pDataInfo->isSupported = FALSE;
		break;

	// pictures
	case RMdetector3_streamType_BMP:
		if (pDataInfo) {
			pDataInfo->Type = RMFPStreamInfoData_Picture;
			pDataInfo->Parameters.picture.format = RMFPPictureFormat_BMP;
			//pDetectionContext->pStreamInfo->DataStreamCount++;
		}
		break;
	case RMdetector3_streamType_JPEG:
		if (pDataInfo) {
			pDataInfo->Type = RMFPStreamInfoData_Picture;
			pDataInfo->Parameters.picture.format = RMFPPictureFormat_JPEG;

			if (pInfo->Data.Picture.SPECIFIC_INFO_VALID) {
				RMascii *pProfileString = "\0";
				RMascii *pSamplingModeString = "\0";
				struct RMPictureDetector_JPEG_specific_info *pJPEG = &(pInfo->Data.Picture.Info.Data.JPEG);

				pDataInfo->Parameters.picture.Width  = pJPEG->Width;
				pDataInfo->Parameters.picture.Height = pJPEG->Height;

				pDataInfo->Parameters.picture.Precision     = pJPEG->Precision;
				pDataInfo->Parameters.picture.Profile       = RMFPPictureProfile_UNKNOWN;
				pDataInfo->Parameters.picture.ColorSampling = RMFPPictureColorSampling_UNKNOWN;

				// profile
				switch (pJPEG->Profile) {
				case RMPictureDetector_JPEG_Profile_Baseline:
					pProfileString = "Baseline";
					pDataInfo->Parameters.picture.Profile = RMFPPictureProfile_Baseline;
					break;

				case RMPictureDetector_JPEG_Profile_Progressive:
					pProfileString = "Progressive";
					pDataInfo->Parameters.picture.Profile = RMFPPictureProfile_Progressive;
					break;
				};

				// sampling mode
				if (pJPEG->Components != 3)
					pSamplingModeString = "Unknown sampling mode";
				else {
					if ((pJPEG->ComponentID[0] == 82)
					    && (pJPEG->ComponentID[1] == 71)
					    && (pJPEG->ComponentID[2] == 66)) {
						// RGB
						pSamplingModeString = "RGB";
						pDataInfo->Parameters.picture.ColorSampling = RMFPPictureColorSampling_RGB;
					}
					else if ((pJPEG->ComponentHSampling[1] != pJPEG->ComponentHSampling[2])
						 || (pJPEG->ComponentVSampling[1] != pJPEG->ComponentVSampling[2])) {
						// YCbCr with different sampling factor for Cb and Cr
						pSamplingModeString = "YCbCr with Cb!=Cr";
					}
					else if ((pJPEG->ComponentHSampling[0] == 1)
						 && (pJPEG->ComponentVSampling[0] == 1)
						 && (pJPEG->ComponentHSampling[1] == 1)
						 && (pJPEG->ComponentVSampling[1] == 1)) {
						// 444
						pSamplingModeString = "444";
						pDataInfo->Parameters.picture.ColorSampling = RMFPPictureColorSampling_444;
					}
					else if ((pJPEG->ComponentHSampling[0] == 2)
						 && (pJPEG->ComponentVSampling[0] == 2)
						 && (pJPEG->ComponentHSampling[1] == 1)
						 && (pJPEG->ComponentVSampling[1] == 1)) {
						// 420
						pSamplingModeString = "420";
						pDataInfo->Parameters.picture.ColorSampling = RMFPPictureColorSampling_420;
					}
					else if ((pJPEG->ComponentHSampling[0] == 2)
						 && (pJPEG->ComponentVSampling[0] == 2)
						 && (pJPEG->ComponentHSampling[1] == 1)
						 && (pJPEG->ComponentVSampling[1] == 2)) {
						// 422
						pSamplingModeString = "422";
						pDataInfo->Parameters.picture.ColorSampling = RMFPPictureColorSampling_422;
					}
					else if ((pJPEG->ComponentHSampling[0] == 2)
						 && (pJPEG->ComponentVSampling[0] == 1)
						 && (pJPEG->ComponentHSampling[1] == 1)
						 && (pJPEG->ComponentVSampling[1] == 1)) {
						// 422 half
						pSamplingModeString = "422 Half";
						pDataInfo->Parameters.picture.ColorSampling = RMFPPictureColorSampling_422Half;
					}
					else if ((pJPEG->ComponentHSampling[0] == 1)
						 && (pJPEG->ComponentVSampling[0] == 2)
						 && (pJPEG->ComponentHSampling[1] == 1)
						 && (pJPEG->ComponentVSampling[1] == 1)) {
						// 422 half rotated
						pSamplingModeString = "422 Half Rotated";
						pDataInfo->Parameters.picture.ColorSampling = RMFPPictureColorSampling_422HalfRotated;
					}
					else if ((pJPEG->ComponentHSampling[0] == 2)
						 && (pJPEG->ComponentVSampling[0] == 2)
						 && (pJPEG->ComponentHSampling[1] == 2)
						 && (pJPEG->ComponentVSampling[1] == 1)) {
						// 422 rotated
						pSamplingModeString = "422 Rotated";
						pDataInfo->Parameters.picture.ColorSampling = RMFPPictureColorSampling_422Rotated;
					}
					else {
						pSamplingModeString = "Unknown";
					}
				}

				if (pDetectionContext->verbose) {

					RMDBGPRINT((ENABLE, "\tJPEG: size %lu x %lu, %lu bits, %s, %lu components, sampling '%s'\n",
						    pDataInfo->Parameters.picture.Width, pDataInfo->Parameters.picture.Height,
						    pInfo->Data.Picture.Info.Data.JPEG.Precision,
						    pProfileString,
						    pInfo->Data.Picture.Info.Data.JPEG.Components,
						    pSamplingModeString));

					for (i = 0; i < pInfo->Data.Picture.Info.Data.JPEG.Components; i++) {
						RMDBGPRINT((ENABLE, "\tJPEG: component[%lu]: ID 0x%lx, HSampling %lu, VSampling %lu\n",
							    i,
							    pInfo->Data.Picture.Info.Data.JPEG.ComponentID[i],
							    pInfo->Data.Picture.Info.Data.JPEG.ComponentHSampling[i],
							    pInfo->Data.Picture.Info.Data.JPEG.ComponentVSampling[i]));
					}


				}

			}

			//pDetectionContext->pStreamInfo->DataStreamCount++;
		}
		break;
	case RMdetector3_streamType_TIFF:
		break;
	case RMdetector3_streamType_PNG:
		if (pDataInfo) {
			pDataInfo->Type = RMFPStreamInfoData_Picture;
			pDataInfo->Parameters.picture.format = RMFPPictureFormat_PNG;

			//pDetectionContext->pStreamInfo->DataStreamCount++;
		}
		break;
	case RMdetector3_streamType_GIF:
		if (pDataInfo) {
			pDataInfo->Type = RMFPStreamInfoData_Picture;
			pDataInfo->Parameters.picture.format = RMFPPictureFormat_GIF;

			//pDetectionContext->pStreamInfo->DataStreamCount++;
		}
		break;

	// subpicture
	case RMdetector3_streamType_SPU_DVD:
	case RMdetector3_streamType_SPU_Bluray:
	case RMdetector3_streamType_SPU_DVB:

		if (pDataInfo) {
			pDataInfo->Type = RMFPStreamInfoData_SPU;
			RMDBGPRINT((ENABLE, " (pid=%lu [0x%lx] subid=%lu [0x%lx] pidType=%lu [0x%lx])\n",
						pDataInfo->PID,
						pDataInfo->PID,
						pDataInfo->SubID,
						pDataInfo->SubID,
						pDataInfo->PIDType,
						pDataInfo->PIDType));
		}
		break;

	// elementary video
	case RMdetector3_streamType_VIDEO_AVS:
	case RMdetector3_streamType_VIDEO_XVID:
	case RMdetector3_streamType_VIDEO_DIVX4:
	case RMdetector3_streamType_VIDEO_MPEG4:
	case RMdetector3_streamType_VIDEO_DIVX3:
	case RMdetector3_streamType_VIDEO_H263:
	case RMdetector3_streamType_VIDEO_H264:
	case RMdetector3_streamType_VIDEO_MJPEG:
	case RMdetector3_streamType_VIDEO_MPEG12:
	case RMdetector3_streamType_VIDEO_VC1:
	case RMdetector3_streamType_VIDEO_WMV:
		if (pDataInfo) 
			pDataInfo->isSupported = FALSE;
		break;


	// system
	case RMdetector3_streamType_SYSTEM_ASF:
	case RMdetector3_streamType_SYSTEM_DVD:
	case RMdetector3_streamType_SYSTEM_ID3:
	case RMdetector3_streamType_SYSTEM_M1S:
	case RMdetector3_streamType_SYSTEM_M2P:
	case RMdetector3_streamType_SYSTEM_M2T:
	case RMdetector3_streamType_SYSTEM_MKV:
	case RMdetector3_streamType_SYSTEM_MP4:
	case RMdetector3_streamType_SYSTEM_RIFF:
	case RMdetector3_streamType_SYSTEM_FLV:
	case RMdetector3_streamType_SYSTEM_OGG:
	case RMdetector3_streamType_SYSTEM_RealMedia:
	case RMdetector3_streamType_SYSTEM_HLS:
		if (pDataInfo) 
			pDataInfo->isSupported = FALSE;
		break;
	}

	return;
}


