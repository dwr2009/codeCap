/*****************************************
 Copyright 2001-2009
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   ciphers.c
  @brief  This file provides an example of implementation of the cipher callbacks

	  This file is part of the test_rmfp suite

  @author Aurelia Popa Radu, Gilles VIEIRA
  @date   2009-04-29
*/

/*
  **********************************************
  DISCLAIMER:

  - THIS IS TEST CODE, provided as sample code
  to help you understand what you should do to
  develop your own application based in RMFP.

  - This is NOT production grade code; It is not
  even a library, so any API defined here, CAN
  and WILL CHANGE without notice.

  **********************************************
*/


#ifndef __TESTRMFP_CIPHERS_H__
#define __TESTRMFP_CIPHERS_H__


#include <rmdef/rmdef.h>
#include "rmfp.h"

/*
 * Defines
 */
#define MAX_CIPHERS 8
#define MAX_KEYS_PER_CIPHER 2

enum cipher_test_type {
	cipher_test_none = 0,
	cipher_test_midcipher_fixed,     // 1
	cipher_test_midcipher_ecm,       // 2
	cipher_test_precipher_fixed,     // 3
	cipher_test_precipher_ivdr,      // 4
};

enum cipher_ecm_protocol_type {
	ecm_protocol_nagra_fixed_keys_0x80_even_0x81_odd,
	ecm_protocol_nagra,
	ecm_protocol_arib_fixed_keys_0x80_even_0x81_odd,
	ecm_protocol_arib,
};

/*
 * Stuctures
 */
struct rmfp_key_params {
	RMuint32 index;
	RMuint32 scrambling_bits;
};

struct rmfp_cipher_params {
	RMuint32 index;
	enum EMhwlibCipher type;         // EMhwlibCipher_DES, EMhwlibCipher_AES, ..
	RMuint32 mode;                   // enum EMhwlibDESCipherMode, enum EMhwlibAESCipherMode, ..
	RMuint32 encrypted_packet_format;// enum EMhwlibAESEncryptedPacketFormat
	RMuint32 key_size;
	RMuint32 block_size;
	RMuint32 round_value;

	RMuint32 key_count;
	RMbool swap_key;
	struct rmfp_key_params key_entry[MAX_KEYS_PER_CIPHER];

	// key ladder related
	RMbool kl_otp; // if TRUE the key ladder decrypts the keys based on otp objects
	RMbool authentication;
	enum EMhwlibCipher kl_cipher_type; // EMhwlibCipher_AES or EMhwlibCipher_DES
	RMuint8 kl_data_A[16];
	RMuint32 kl_data_A_size; // 16 bytes
	RMuint8 kl_data_B[16];
	RMuint32 kl_data_B_size; // 16 bytes
	RMuint32 kl_data_C_size; // 16 bytes for AES and 8 bytes for TDES
	RMuint8 kl_secret_key[16];
	RMuint32 kl_secret_key_size; // 16 bytes
};

struct rmfp_cipher_context {
	enum cipher_test_type cipher_test;

	FILE *config_file;
	RMuint64 config_file_key_offset;

	RMuint32 pes_scrambling_control;
	RMuint32 encrypted_pat; // it should be RMbool
	RMuint32 encrypted_pmt;
	RMuint32 encrypted_vpid;
	RMuint32 encrypted_apid;
	RMuint32 encrypted_subpictures;
	RMuint32 encrypted_ttx;
	RMuint32 ecm_vpid;
	RMuint32 ecm_apid;
	enum cipher_ecm_protocol_type ecm_protocol;

	RMuint32 demux_task; // module_id
	RMuint32 byte_counter;

	RMuint32 cipher_count;
	RMuint32 kl_cipher_count;
	struct rmfp_cipher_params cipher_entry[MAX_CIPHERS];

	RMuint32 recipher_count;
	RMuint32 recipher_mode;
	RMuint32 recipher_scrambling_bits;
	RMuint32 recipher_pat; // it should be RMbool
	RMuint32 recipher_pmt;
	RMuint32 recipher_vpid;
	RMuint32 recipher_apid;

	//precipher test related
	RMuint32 change_key_block_size;

	//iVDR test related
	RMuint32 refresh_iv_block_size;
	RMuint32 refresh_key_iv_block_count;
	RMuint32 iv_block_count; // total number of iv blocks

	RMbool valid_ecm_pid_handle;
	RMuint32 ecm_pid_handle;
	RMuint8 prev_table_id;
	struct PSFMatchSection_type ecm_section;

#ifdef USE_XPU_WRITE_KEY
	RMuint32 xrpc_base_addr; // memory needed for xrpc communication
#endif /* USE_XPU_WRITE_KEY */
};

RM_EXTERN_C_BLOCKSTART

/*
 * Exported functions
 */

RMstatus cipher_resources_handler(void *pContext, struct RMFPDemuxCipherResourcesProfile *pProfile);
RMstatus release_cipher_resources_handler(void *pContext, struct RMFPDemuxCipherResourcesProfile *pProfile);

RMstatus notify_pid_creation(void *pContext, struct RMFPPID *pPID);
RMstatus notify_send_data(void *pContext, struct RMFPSendData *pSendData);

RM_EXTERN_C_BLOCKEND

#endif // __TESTRMFP_CIPHERS_H__

