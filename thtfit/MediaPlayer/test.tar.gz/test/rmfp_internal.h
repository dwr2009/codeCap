/*****************************************
 Copyright 2001-2007
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   rmfp_internal.h
  @brief


  @author Sebastian Frias Feltrer
  @date   2007-08-07
*/


#ifndef __RMFP_INTERNAL_H__
#define __RMFP_INTERNAL_H__

#define COMMANDS_FIFO_SIZE	50

// if set to 0 then all ASSERT_NULL_POINTER() calls will be disabled
#define CHECK_NULL_POINTERS 1


// this includes rmdef, rmcore, rmlibcw, rmdetector3 and the function prototypes
#include "rmfp.h"


// default values
#include "rmfp_default_values.h"


// provides playback functionality
#include <rmlibplay/include/rmlibplay.h>



#ifdef WITH_THREADS
#include <rmlibcw/include/rmsemaphores.h>


#define DEBUG_BLOCKING_SEMAPHORES 0


#define ENTER_CS(x) do {						\
		if (x)							\
			RMEnterCriticalSection(x);			\
		else							\
			RMDBGLOG((ENABLE, "Critical Section NULL!\n"));	\
	} while (0)

#define LEAVE_CS(x) do {						\
		if (x)							\
			RMLeaveCriticalSection(x);			\
		else							\
			RMDBGLOG((ENABLE, "Critical Section NULL!\n"));	\
	} while (0)

#define SEMAPHORE_P(x) do {						\
		if (x)							\
			RMReleaseSemaphore(x, 1);			\
		else							\
			RMDBGLOG((ENABLE, "Semaphore NULL!\n"));	\
	} while (0)

#if DEBUG_BLOCKING_SEMAPHORES
#define SEMAPHORE_V(x) do {						\
		if (x) {						\
			while (RMTryWaitForSemaphore(x) == RM_SEMAPHORELOCKED) { \
				RMDBGLOG((ENABLE, "wait on %p\n", x));	\
				RMMicroSecondSleep(10 * 1000);		\
			}						\
		}							\
		else							\
			RMDBGLOG((ENABLE, "Semaphore NULL!\n"));	\
	} while (0)

#else
#define SEMAPHORE_V(x) do {						\
		if (x)							\
			RMWaitForSemaphore(x);				\
		else							\
			RMDBGLOG((ENABLE, "Semaphore NULL!\n"));	\
	} while (0)
#endif //DEBUG_BLOCKING_SEMAPHORES


#else
#define ENTER_CS(x) do { } while(0)
#define LEAVE_CS(x) do { } while(0)
#define SEMAPHORE_P(x) do { } while(0)
#define SEMAPHORE_V(x) do { } while(0)
#endif







#define ASSERTDBG DISABLE

#if ((defined(CHECK_NULL_POINTERS) && (CHECK_NULL_POINTERS == 1)))
#define ASSERT_NULL_POINTER(ptr)					\
	do {								\
		RMDBGLOG((ASSERTDBG, "%s = %p\n", #ptr, ptr));		\
		if (!(ptr)) {						\
			RMNOTIFY((NULL, RM_FATALINVALIDPOINTER, "got NULL pointer for %s\n", #ptr)); \
			return RM_FATALINVALIDPOINTER;			\
		}							\
	} while(0)
#else
#define ASSERT_NULL_POINTER(ptr) do { } while(0)
#endif



#define MustBeEqual(x, y, message)					\
	typedef RMascii __ERROR__ ## message ## _Y_is_smaller_than_X_[(y)-(x)]; \
	typedef RMascii __ERROR__ ## message ## _X_is_smaller_than_Y_[(x)-(y)];


#define CREATE_STRUCT_MAGIC(version, size) ((size << 16) | (version & 0xFFFF))
#define GET_VERSION_FROM_MAGIC(magic) (magic & 0xFFFF)
#define GET_SIZE_FROM_MAGIC(magic) ((magic >> 16) & 0xFFFF)


/*
  These #defines are used for struct versioning, the first parameter
  to CREATE_STRUCT_MAGIC is the version; the second parameter is the
  size of the struct.

  Please change the version whenever you upgrade the struct.

  *** Remember *** to update the corresponding comment in rmfp.h also.



  NOTE:

  To know the size of the structs, use the show_rmfp_struct_sizes
  application that can be found in rmfp/test, see it's code for more
  information.

*/


#define RMFP_VIDEO_RESOURCES_PROFILE_VERSION			CREATE_STRUCT_MAGIC(1, 68)
#ifdef RMFEATURE_HAS_AUDIO_ENGINE_2
#define RMFP_AUDIO_INSTANCES_PROFILE_VERSION			CREATE_STRUCT_MAGIC(1, 56)
#define RMFP_AUDIO_RESOURCES_PROFILE_VERSION			CREATE_STRUCT_MAGIC(2, 220)
#elif defined RMFEATURE_HAS_AUDIO_ENGINE_1
#define RMFP_AUDIO_INSTANCES_PROFILE_VERSION			CREATE_STRUCT_MAGIC(1, 40)
#define RMFP_AUDIO_RESOURCES_PROFILE_VERSION			CREATE_STRUCT_MAGIC(2, 152)
#else
#define RMFP_AUDIO_INSTANCES_PROFILE_VERSION			CREATE_STRUCT_MAGIC(1, 24)
#define RMFP_AUDIO_RESOURCES_PROFILE_VERSION			CREATE_STRUCT_MAGIC(2, 84)
#endif
#define RMFP_DEMUX_RESOURCES_PROFILE_VERSION			CREATE_STRUCT_MAGIC(1, 36)
#define RMFP_DEMUX_CIPHER_RESOURCES_PROFILE_VERSION		CREATE_STRUCT_MAGIC(1, 36)
#define RMFP_DEMUX_OUTPUT_RESOURCES_PROFILE_VERSION		CREATE_STRUCT_MAGIC(1, 36)
#define RMFP_SPU_RESOURCES_PROFILE_VERSION			CREATE_STRUCT_MAGIC(1, 28)
#define RMFP_CCFIFO_RESOURCES_PROFILE_VERSION			CREATE_STRUCT_MAGIC(1, 24)
#define RMFP_TTX_RESOURCES_PROFILE_VERSION			CREATE_STRUCT_MAGIC(1, 20)

#define RMFP_DOUBLEBUFFER_OSD_PROFILE_VERSION			CREATE_STRUCT_MAGIC(1, 48)
#define RMFP_OSD_PROFILE_VERSION				CREATE_STRUCT_MAGIC(1, 4)
#define RMFP_SURFACE_PROFILE_VERSION				CREATE_STRUCT_MAGIC(1, 8)
#define RMFP_TEXT_SUBTITLES_VERSION				CREATE_STRUCT_MAGIC(1, 12)
#define RMFP_PAT_VERSION					CREATE_STRUCT_MAGIC(1, 8)
#define RMFP_PMT_VERSION					CREATE_STRUCT_MAGIC(1, 8)
#define RMFP_PID_VERSION					CREATE_STRUCT_MAGIC(1, 8)
#define RMFP_SEND_DATA_VERSION					CREATE_STRUCT_MAGIC(1, 12)

#if (EM86XX_CHIP < EM86XX_CHIPID_TANGO3)
#define RMFP_CURRENT_STREAMS_PROPERTIES_VERSION			CREATE_STRUCT_MAGIC(1, 344)
#else
#define RMFP_CURRENT_STREAMS_PROPERTIES_VERSION			CREATE_STRUCT_MAGIC(1, 356)
#endif

#define RMFP_STREAM_METADATA_VERSION				CREATE_STRUCT_MAGIC(1, 7336)

#define RMFP_STREAMINFO_VIDEO_VERSION				CREATE_STRUCT_MAGIC(1, 52)
#define RMFP_STREAMINFO_AUDIO_VERSION				CREATE_STRUCT_MAGIC(1, 64)
#define RMFP_STREAMINFO_SYSTEM_VERSION				CREATE_STRUCT_MAGIC(1, 32)
#define RMFP_STREAMINFO_DATA_VERSION				CREATE_STRUCT_MAGIC(1, 8)
#define RMFP_STREAMINFO_VERSION					CREATE_STRUCT_MAGIC(1, 36)
#define RMFP_PROGRESS_VERSION					CREATE_STRUCT_MAGIC(1, 24)
#define RMFP_PICTURE_TRANSFORM_RESOURCES_PROFILE_VERSION 	CREATE_STRUCT_MAGIC(1, 36)
#define RMFP_PPF_RESOURCES_PROFILE_VERSION 			CREATE_STRUCT_MAGIC(1, 52)

#define RMFP_RMWMDRM_PROFILE_VERSION				CREATE_STRUCT_MAGIC(1, 28)
#define RMFP_RMWMDRM_RESOURCES_PROFILE_VERSION 			CREATE_STRUCT_MAGIC(1, 12)
#define RMFP_DMAPOOL_PROFILE_VERSION			        CREATE_STRUCT_MAGIC(1, 20)


MustBeEqual(sizeof(struct RMFPVideoResourcesProfile),		GET_SIZE_FROM_MAGIC(RMFP_VIDEO_RESOURCES_PROFILE_VERSION),		_1_);
//MustBeEqual(sizeof(struct RMFPMultipleAudioInstancesProfile),	GET_SIZE_FROM_MAGIC(RMFP_AUDIO_INSTANCES_PROFILE_VERSION),		_2_);
//MustBeEqual(sizeof(struct RMFPMultipleAudioResourcesProfile),	GET_SIZE_FROM_MAGIC(RMFP_AUDIO_RESOURCES_PROFILE_VERSION),		_3_);
MustBeEqual(sizeof(struct RMFPDemuxResourcesProfile),		GET_SIZE_FROM_MAGIC(RMFP_DEMUX_RESOURCES_PROFILE_VERSION),		_4_);
//MustBeEqual(sizeof(struct RMFPDemuxCipherResourcesProfile), 	GET_SIZE_FROM_MAGIC(RMFP_DEMUX_CIPHER_RESOURCES_PROFILE_VERSION),	_5_);
MustBeEqual(sizeof(struct RMFPDemuxOutputResourcesProfile), 	GET_SIZE_FROM_MAGIC(RMFP_DEMUX_OUTPUT_RESOURCES_PROFILE_VERSION),	_6_);
MustBeEqual(sizeof(struct RMFPSPUResourcesProfile),		GET_SIZE_FROM_MAGIC(RMFP_SPU_RESOURCES_PROFILE_VERSION),		_7_);
MustBeEqual(sizeof(struct RMFPCCFIFOResourcesProfile),		GET_SIZE_FROM_MAGIC(RMFP_CCFIFO_RESOURCES_PROFILE_VERSION),		_8_);
MustBeEqual(sizeof(struct RMFPTTXResourcesProfile),         	GET_SIZE_FROM_MAGIC(RMFP_TTX_RESOURCES_PROFILE_VERSION),		_9_);

MustBeEqual(sizeof(struct RMFPOSDSource),			GET_SIZE_FROM_MAGIC(RMFP_OSD_PROFILE_VERSION),				_10_);
MustBeEqual(sizeof(struct RMFPSurfaceProfile),			GET_SIZE_FROM_MAGIC(RMFP_SURFACE_PROFILE_VERSION),			_11_);

MustBeEqual(sizeof(struct RMFPPAT),				GET_SIZE_FROM_MAGIC(RMFP_PAT_VERSION),					_12_);
MustBeEqual(sizeof(struct RMFPPMT),				GET_SIZE_FROM_MAGIC(RMFP_PMT_VERSION),					_13_);

MustBeEqual(sizeof(struct RMFPPID),				GET_SIZE_FROM_MAGIC(RMFP_PID_VERSION),					_14_);

//MustBeEqual(sizeof(struct RMFPStreamProperties),		GET_SIZE_FROM_MAGIC(RMFP_CURRENT_STREAMS_PROPERTIES_VERSION),		_15_);
// TODO : check why its not the same size on Tango2 XLU
//MustBeEqual(sizeof(struct RMFPStreamMetadata),		GET_SIZE_FROM_MAGIC(RMFP_STREAM_METADATA_VERSION),			_16_);

MustBeEqual(sizeof(struct RMFPStreamInfo_Video),		GET_SIZE_FROM_MAGIC(RMFP_STREAMINFO_VIDEO_VERSION),			_17_);
MustBeEqual(sizeof(struct RMFPStreamInfo_Audio),		GET_SIZE_FROM_MAGIC(RMFP_STREAMINFO_AUDIO_VERSION),			_18_);
MustBeEqual(sizeof(struct RMFPStreamInfo_System),		GET_SIZE_FROM_MAGIC(RMFP_STREAMINFO_SYSTEM_VERSION),			_19_);
//MustBeEqual(sizeof(struct RMFPStreamInfo_Data),		GET_SIZE_FROM_MAGIC(RMFP_STREAMINFO_DATA_VERSION),			_20_);
MustBeEqual(sizeof(struct RMFPStreamInfo),			GET_SIZE_FROM_MAGIC(RMFP_STREAMINFO_VERSION),				_21_);
//MustBeEqual(sizeof(struct RMFPProgress),			GET_SIZE_FROM_MAGIC(RMFP_PROGRESS_VERSION),				_22_);
MustBeEqual(sizeof(struct RMFPPictureTransformResourcesProfile),GET_SIZE_FROM_MAGIC(RMFP_PICTURE_TRANSFORM_RESOURCES_PROFILE_VERSION),	_23_);
MustBeEqual(sizeof(struct RMFPRMWMDRMProfile),			GET_SIZE_FROM_MAGIC(RMFP_RMWMDRM_PROFILE_VERSION),			_24_);
MustBeEqual(sizeof(struct RMFPRMWMDRMResourcesProfile),		GET_SIZE_FROM_MAGIC(RMFP_RMWMDRM_RESOURCES_PROFILE_VERSION),		_25_);
MustBeEqual(sizeof(struct RMFPSendData),			GET_SIZE_FROM_MAGIC(RMFP_SEND_DATA_VERSION),				_26_);
MustBeEqual(sizeof(struct RMFPDMAPoolProfile),		        GET_SIZE_FROM_MAGIC(RMFP_DMAPOOL_PROFILE_VERSION),		        _27_);
MustBeEqual(sizeof(struct RMFPPPFResourcesProfile), GET_SIZE_FROM_MAGIC(RMFP_PPF_RESOURCES_PROFILE_VERSION),	_28_);


struct RMFPSoftTXTRenderProfile {
	struct RMFPHandle *pHandle;
	RMuint32 Version;
	RMbool UseMultipleBuffering;
};

struct RMFPVideoResources {

	RMuint32 scheduler_memory_address;
	RMuint32 scheduler_memory_size;
	RMbool   free_scheduler;

	RMuint32 shared_memory_address;
	RMuint32 shared_memory_size;
	RMbool   free_shared;

	RMuint32 picture_memory_address;
	RMuint32 picture_memory_size;
	RMbool   free_picture;

	RMuint32 bitstream_memory_address;
	RMuint32 bitstream_memory_size;
	RMbool   free_bitstream;

	RMuint32 unprotected_memory_address;
	RMuint32 unprotected_memory_size;
	RMbool   free_unprotected;

	RMuint32 postprocessing_memory_address;
	RMuint32 postprocessing_memory_size;
	RMbool   free_postprocessing;

	RMuint32 dram;

	RMuint32 engine_index;
	RMuint32 engine_module_ID;
	RMuint32 decoder_index;
	RMuint32 decoder_module_ID;
};

struct RMFPPictureTransformResources {

	RMuint32 data_memory_address;
	RMuint32 data_memory_size;
	RMbool   free_data;

	RMuint32 interface_memory_address;
	RMuint32 interface_memory_size;
	RMbool   free_interface;

	RMuint32 dram;

	RMuint32 engine_index;
	RMuint32 engine_module_ID;
	RMuint32 decoder_index;
	RMuint32 decoder_module_ID;
};

struct RMFPPPFResources {

	RMuint32 engine_memory_address;
	RMuint32 engine_memory_size;
	RMbool   free_engine;

	RMuint32 input_memory_address;
	RMuint32 input_memory_size;
	RMbool   free_input;

	RMuint32 output_memory_address;
	RMuint32 output_memory_size;
	RMbool   free_output;

	RMuint32 data_memory_address;
	RMuint32 data_memory_size;
	RMbool   free_data;

	RMuint32 dram;

	RMuint32 engine_index;
	RMuint32 engine_module_ID;
	RMuint32 decoder_index;
	RMuint32 decoder_module_ID;
};


struct RMFPAudioResources {

	struct
	{
		RMuint32 dram;
		RMbool   free_shared;
	} engine[MAX_AUDIO_ENGINE_INSTANCES];

	struct
	{
		RMuint32 dram;
		RMbool   free_protected;
		RMbool   free_unprotected;
	} instance[MAX_AUDIO_DECODER_INSTANCES];
};

struct RMFPDemuxResources {
	RMbool free_protected;
	RMbool free_unprotected;

	RMuint32 dram;
};

struct RMFPSPUResources {
	RMuint32 unprotected_memory_address;
	RMuint32 unprotected_memory_size;
	RMbool   free_unprotected;

	RMuint32 dram;

	RMuint32 engine_index;
	RMuint32 engine_module_ID;
	RMuint32 decoder_index;
	RMuint32 decoder_module_ID;
};

#define RMFP_MAX_OUTPUTS	32

struct RMFPDemuxOutputResources {
	struct {
		void*	handle;
		RMbool free_protected;
		RMbool free_unprotected;
		RMuint32 dram;
	} entry[RMFP_MAX_OUTPUTS];
};


#define RMFP_MAX_NUMBER_OF_PREFETCHABLE_URL 32


struct RMFPPrefetchHandle {
	struct RMFPPrefetchProfile Profile;
	RMuint32 URLPrefetchSize;
	RMfile PrefetchFileHandleTable[RMFP_MAX_NUMBER_OF_PREFETCHABLE_URL];
	RMcriticalsection CriticalSection;
};

struct RMFPSoftCCRenderHandle;

struct RMFPSoftTXTRenderHandle;

enum RMFPCommand_execution_status
{
	RMFPCommand_execution_status_completed = 598,
	RMFPCommand_execution_status_to_be_processed,
	RMFPCommand_execution_status_in_progress
};


struct RMFPHandle {

    // detected stream properties
    struct RMFPStreamInfo *pStreamInfo;

    // stream type
    struct RMFPStreamType streamType;

    // options
    // trimmed versions of *_opt from libsamples1

    struct RMFPPlayOptions  playback_options;
    struct RMFPVideoOptions video_options;
    struct RMFPAudioOptions audio_options;
    struct RMFPDemuxOptions demux_options;

    struct RMLibPlayHandle *pRMLibPlayHandle;

    struct RMFPPrefetchHandle PrefetchHandle;

    // for software close caption rendering
    struct RMFPSoftCCRenderHandle *pSoftCCRenderHandle;

    // for software teletext rendering
    struct RMFPSoftTXTRenderHandle *pSoftTXTRenderHandle;

    // resource tracking
    struct RMFPVideoResources video_resources;
    struct RMFPPictureTransformResources picture_transform_resources;
    struct RMFPPPFResources ppf_resources;
    struct RMFPAudioResources audio_resources;
    struct RMFPDemuxResources demux_resources;
    struct RMFPDemuxOutputResources demux_output_resources;
    struct RMFPSPUResources spu_resources;
    RMbool FreeRMWMDRMResources;

    struct RMFPProfile profile;

    // Fifo of commands to be executed
    enum RMFPCommand_execution_status command_execution_status;
    struct RMFPPlaybackCommand command;
    struct RMFPCommandStatus command_status;

    // Fonts
    struct RMFontRenderHandle *pFontRenderHandle;
    RMint32 default_font_slotID;    // -1 if none
    RMint32 cc_font_slotID; // -1 if none

    // for http playback
    struct RMLibCURLHandle *pCURLHandle;
    RMuint8 *pHttpCache;

    // Debug Statistics
    RMbool  PrintPlaybackDebug;
};

RM_EXTERN_C_BLOCKSTART

// handlers related to resources

/* inside rmfp_resources_video.c */
RMstatus rmfp_internal_get_video_decoder_handler(void *pContext, struct RMLibPlayVideoSource *pVideoSource, struct RMLibPlayVideoProfile *pVideoProfile);
RMstatus rmfp_internal_release_video_decoder_handler(void *pContext, struct RMLibPlayVideoSource *pVideoSource);

/* inside rmfp_resources_audio.c */
RMstatus rmfp_internal_get_audio_decoder_handler(void *pContext, struct RMLibPlayMultipleAudioSource *pMultipleAudioSource, struct RMLibPlayAudioProfile *pAudioProfile);
RMstatus rmfp_internal_release_audio_decoder_handler(void *pContext, struct RMLibPlayMultipleAudioSource *pAudioSource);
RMstatus rmfp_internal_update_audio_decoder_outport(void *pContext, struct RMLibPlayMultipleAudioSource *pMultipleAudioSource, RMuint32 ModuleID);

/* inside rmfp_resources_stc.c */
RMstatus rmfp_internal_get_stc_handler(void *pContext, struct RMLibPlaySTC *pSTC, struct RMLibPlaySTCProfile *pSTCProfile);
RMstatus rmfp_internal_release_stc_handler(void *pContext, struct RMLibPlaySTC *pSTC);

/* inside rmfp_resources_dmapool.c */
RMstatus rmfp_internal_get_dmapool_handler(void *pContext, struct RMLibPlayDMAPool *pDMAPool, struct RMLibPlayDMAPoolProfile *pDMAPoolProfile);
RMstatus rmfp_internal_release_dmapool_handler(void *pContext, struct RMLibPlayDMAPool *pDMAPool);

/* inside rmfp_resources_spu.c */
RMstatus rmfp_internal_get_spu_decoder_handler(void *pContext, struct RMLibPlaySPUSource *pSPUSource, struct RMLibPlaySPUProfile *pSPUProfile);
RMstatus rmfp_internal_release_spu_decoder_handler(void *pContext, struct RMLibPlaySPUSource *pSPUSource);

/* inside rmfp_resources_osd.c */
RMstatus rmfp_internal_open_osd_handler(void *pContext, struct RMLibPlayOSDProfile *pProfile, struct RMLibPlayOSDSource *pOSDSource);
RMstatus rmfp_internal_close_osd_handler(void *pContext, struct RMLibPlayOSDSource *pOSDSource);
RMstatus rmfp_internal_get_osd_picture_handler(void *pContext, struct RMLibPlayOSDSource *pOSDSource, struct RMLibPlayOSDPicture *pPicture);
RMstatus rmfp_internal_set_osd_picture_handler(void *pContext, struct RMLibPlayOSDSource *pOSDSource, struct RMLibPlayOSDPicture *pPicture);


/* inside rmfp_resources_nerospu.c */
RMstatus rmfp_internal_open_nero_spu_handler(void *pContext, RMuint32 width, RMuint32 height, struct RMLibPlayNeroSPU *pNeroSPU);
RMstatus rmfp_internal_blend_nero_spu_handler(void *pContext, struct RMLibPlayNeroSPU *pNeroSPU, RMuint8 *pBuffer);
RMstatus rmfp_internal_clear_nero_spu_handler(void *pContext, struct RMLibPlayNeroSPU *pNeroSPU);
RMstatus rmfp_internal_close_nero_spu_handler(void *pContext, struct RMLibPlayNeroSPU *pNeroSPU);

/* inside rmfp_resources_ccfifo.c */
RMstatus rmfp_internal_get_ccfifo_handler(void *pContext, struct RMLibPlayCCFIFOSource *pCCSource, struct RMLibPlayCCFIFOProfile *pCCProfile);
RMstatus rmfp_internal_refresh_ccfifo_handler(void *pContext, struct RMLibPlayCCFIFOSource *pCCFIFOSource);
RMstatus rmfp_internal_clear_ccfifo_handler(void *pContext, struct RMLibPlayCCFIFOSource *pCCFIFOSource);
RMstatus rmfp_internal_release_ccfifo_handler(void *pContext, struct RMLibPlayCCFIFOSource *pCCSource);

/* inside rmfp_resources_teletext.c */
RMstatus rmfp_internal_get_teletext_handler(void *pContext, struct RMLibPlayTTXSource *pTTXSource, struct RMLibPlayTTXProfile *pCCProfile);
RMstatus rmfp_internal_teletext_decode(void *pContext, struct RMLibPlayTTXSource *pTTXSource, RMuint8* buffer, RMuint32 buffer_size);
RMstatus rmfp_internal_teletext_flush(void *pContext, struct RMLibPlayTTXSource *pTTXSource);
RMstatus rmfp_internal_release_teletext_handler(void *pContext, struct RMLibPlayTTXSource *pTTXSource);
RMstatus rmfp_internal_teletext_refresh(void *pContext, struct RMLibPlayTTXSource *pTTXSource, RMuint32 magazine, RMuint32 page, RMuint64 STC);

/* inside rmfp_resources_demux.c */
RMstatus rmfp_internal_get_demux_handler(void *pContext, struct RMLibPlayDemuxSource *pDemuxSource, struct RMLibPlayDemuxProfile *pDemuxProfile);
RMstatus rmfp_internal_release_demux_handler(void *pContext, struct RMLibPlayDemuxSource *pDemuxSource);
RMstatus rmfp_internal_get_demux_output_handler(void *pContext, struct RMLibPlayDemuxOutputSource *pDemuxOutputSource, struct RMLibPlayDemuxOutputProfile *pDemuxOutputProfile);
RMstatus rmfp_internal_release_demux_output_handler(void *pContext, struct RMLibPlayDemuxOutputSource *pDemuxOutputSource);

/* inside rmfp_resources_rmwmdrm.c */
RMstatus rmfp_internal_get_rmwmdrm_handle_handler(void *pContext, struct RMLibPlayRMWMDRMProfile *pProfile, struct RMWMDRMHandle **ppRMWMDRMHandle);
RMstatus rmfp_internal_rmwmdrm_acquire_url_license(void *pContext, struct RMWMDRMURLHandle *pRMWMDRMURLHandle);
RMstatus rmfp_internal_release_rmwmdrm_handle_handler(void *pContext, struct RMWMDRMHandle *pRMWMDRMHandle);

/* inside rmfp_resources_surface.c */
RMstatus rmfp_internal_connect_surface(void *pContext, RMuint32 output_surface, struct RMFPSurfaceEventsSource *pSurfaceEventsSource);
RMstatus rmfp_internal_disconnect_surface(void *pContext, RMuint32 surface);

/* inside rmfp_detection.c */
RMstatus rmfp_internal_get_stream_info(struct RMFPHandle *pHandle, RMfile fileHandle, const RMascii *pFilename, RMint32 ParsingLength, RMbool AvoidSeeking, struct RMFPStreamType *pStreamType, struct RMFPStreamInfo **ppStreamInfo);
RMstatus rmfp_internal_apply_stream_info_to_options( struct RMFPHandle *pHandle, RMfile fileHandle, struct RMFPStreamType *pStreamType, struct RMFPStreamInfo *pStreamInfo, struct RMFPOptions *pOptions);
RMstatus rmfp_internal_release_stream_info(struct RMFPHandle *pHandle, struct RMFPStreamInfo *pStreamInfo);
RMstatus rmfp_internal_release_stream_info2(struct RMFPStreamInfo *pStreamInfo);

/* inside rmfp_prefetch.c */
RMstatus rmfp_internal_prefetch_init(struct RMFPHandle *pHandle, struct RMFPPrefetchProfile *pProfile);
RMstatus rmfp_internal_prefetch_get_resources(struct RMFPHandle *pHandle, struct RMFPPrefetchResources *pResources);
RMstatus rmfp_internal_prefetch_uninit(struct RMFPHandle *pHandle);
RMstatus rmfp_internal_prefetch_open_file(struct RMFPHandle *pHandle, RMfile inputFileHandle, RMfile *pPrefetchedFileHandle);
RMstatus rmfp_internal_prefetch_start(struct RMFPHandle *pHandle, RMfile PrefetchedFileHandle, RMuint32 timeout);
RMstatus rmfp_internal_prefetch_stop(struct RMFPHandle *pHandle, RMfile PrefetchedFileHandle);

/* inside rmfp_softcc_render.c */
RMstatus rmfp_internal_open_softcc_render(struct RMFPHandle *pHandle);
RMstatus rmfp_internal_process_close_caption_entry(void *pContext, struct CCFifo_CCEntry_type *pCloseCaptionEntry);
RMstatus rmfp_internal_close_softcc_render(struct RMFPHandle *pHandle);

/* inside rmfp_softtxt_render.c */
RMstatus rmfp_internal_open_softtxt_render(struct RMFPSoftTXTRenderHandle **ppHandle, struct RMFPSoftTXTRenderProfile *pProfile);
RMstatus rmfp_internal_close_softtxt_render(struct RMFPHandle *pHandle);
RMstatus rmfp_internal_softtxt_render_decode(struct RMFPSoftTXTRenderHandle * pSoftTXTRenderHandle, RMuint8 * buffer, RMuint32 buffer_size);
RMstatus rmfp_internal_softtxt_refreshTXT(struct RMFPHandle * pHandle, RMuint32 magazineNumber, RMuint32 pageNumber, RMuint64 STC);

/* inside rmfp_internal.c */
RMstatus rmfp_internal_get_command_handler(void *pContext, struct RMFPPlaybackCommand *pCommand, RMuint32 TimeOutInMicroSeconds);
RMstatus rmfp_internal_notify_command_status_handler(void *pContext, struct RMFPCommandStatus *pComand);
RMstatus rmfp_internal_notify_event_handler(void *pContext, struct RUAEvent *pEvent);
RMstatus rmfp_internal_notify_playback_status_handler(void *pContext, struct RMFPPlaybackStatus *pStatus);
RMstatus rmfp_internal_notify_playback_start_handler(void *pContext);
RMstatus rmfp_internal_notify_playback_eos_handler(void *pContext);
RMstatus rmfp_internal_notify_current_streams_properties_handler(void *pContext, struct RMFPStreamProperties *pStreamProperties);
RMstatus rmfp_internal_notify_stream_metadata(void *pContext, struct RMFPStreamMetadata *pStreamMetadata);
RMstatus rmfp_internal_notify_pat_handler(void *pContext, struct RMFPPAT *pPAT);
RMstatus rmfp_internal_notify_pmt_handler(void *pContext, struct RMFPPMT *pPMT);
RMstatus rmfp_internal_notify_pid_creation_handler(void *pContext, struct RMFPPID *pPID);
RMstatus rmfp_internal_notify_send_data_handler(void *pContext, struct RMFPSendData *pSendData);
RMstatus rmfp_internal_notify_available_commands_handler(void *pContext, RMuint32 mask);
RMstatus rmfp_internal_disk_control_handler(void *pContext, enum RMFPDiskControl_action action);
RMstatus rmfp_internal_notify_progress_handler(void *pContext, struct RMFPProgress* pProgress, RMbool *pAbort);
RMstatus rmfp_internal_get_route(struct RMFPHandle *pHandle, enum DCCRoute *pDCCRoute);
RMstatus rmfp_internal_hls_get_key( void* pContext, RMascii *url, RMuint8 *key, RMuint32 keylength);

/* BDSP decoder */
RMstatus rmfp_internal_open_bdspu_decoder(void *pContext);
RMstatus rmfp_internal_close_bdspu_decoder(void *pContext);
RMstatus rmfp_internal_send_bdspu_decoder(void *pContext, RMuint8* pBuffer, RMuint32 Size);
RMstatus rmfp_internal_flush_bdspu_decoder(void *pContext);

/* inside rmfp_resources_picture_transform.c */
RMstatus rmfp_internal_open_picture_transform(struct RMFPHandle *pHandle, RMuint32 *input_surface, RMuint32 *output_surface);
RMstatus rmfp_internal_close_picture_transform(struct RMFPHandle *pHandle);
RMstatus rmfp_gt_initialize_mpeg_engine(struct RMFPHandle *pHandle, struct MpegEngine_DecoderSharedMemory_type *shared, struct MpegEngine_SchedulerSharedMemory_type *schedmem, int dram_index);
RMstatus rmfp_gt_term_mpeg_engine( struct RMFPHandle *pHandle, struct MpegEngine_DecoderSharedMemory_type *shared, struct MpegEngine_SchedulerSharedMemory_type *schedmem);

/* inside rmfp_resources_ppf.c */
RMstatus rmfp_internal_open_ppf(struct RMFPHandle *pHandle, struct RMLibPlayVideoSource *pVideoSource, RMuint32 input_surface, RMuint32 *output_surface);
RMstatus rmfp_internal_close_ppf(struct RMFPHandle *pHandle, struct RMLibPlayVideoSource *pVideoSource);

RMstatus rmfp_internal_getVideoScalerModuleId(struct RMFPHandle *pHandle, RMuint32 * pVidScalerModuleId, enum DCCRoute * pDccRoute);
RMstatus RmfpInternal_AudioEngine_setSampleFreq(struct RMFPHandle *pHandle, RMbool bUseCurCfg, 
	RMbool bAutoSetFromStream, RMuint32 audioSampleFreq);

RM_EXTERN_C_BLOCKEND

#endif // __RMFP_INTERNAL_H__
