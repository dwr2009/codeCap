/*****************************************
 Copyright 2001-2007
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   rmfp_resources_video.c
  @brief


  @author Sebastian Frias Feltrer
  @date   2007-11-05
*/

#ifndef	ALLOW_OS_CODE
#define	ALLOW_OS_CODE
#endif	//ALLOW_OS_CODE

#include "rmfp_internal.h"
#include <DateTime.h>

#define LOCALDBG DISABLE


#define ALWAYS_TRY_TO_FREE_SHARED_MEMORY (0)

#define TIMEOUT_US (500 * 1000)
#define RETRY_THRESHOLD (16)

#define RUA_ADDRESS_ID_TAG(tag, engine) ((engine << 16) | (tag))

static RMuint32 H264_levels[] = {
	EMhwlib_H264_Level_1,
	EMhwlib_H264_Level_11,
	EMhwlib_H264_Level_12,
	EMhwlib_H264_Level_13,
	EMhwlib_H264_Level_2,
	EMhwlib_H264_Level_21,
	EMhwlib_H264_Level_22,
	EMhwlib_H264_Level_3,
	EMhwlib_H264_Level_31,
	EMhwlib_H264_Level_32,
	EMhwlib_H264_Level_4,
	EMhwlib_H264_Level_41,
	EMhwlib_H264_Level_42,
	EMhwlib_H264_Level_5,
	EMhwlib_H264_Level_51
};

static RMuint32 AVS_levels[] = {
	EMhwlib_AVS_Level_2,
	EMhwlib_AVS_Level_4,
	EMhwlib_AVS_Level_42,
	EMhwlib_AVS_Level_6,
	EMhwlib_AVS_Level_62
};

static RMstatus rmfp_apply_video_profile(struct RMFPHandle *pHandle, struct RMLibPlayVideoSource *pVideoSource, struct RMLibPlayVideoProfile *pVideoProfile);
static RMstatus rmfp_apply_video_options(struct RMFPHandle *pHandle, struct RMLibPlayVideoSource *pVideoSource);
static RMstatus rmfp_print_rmlibplay_video_decoder_profile(struct RMLibPlayVideoProfile *pVideoProfile);
static RMstatus rmfp_print_dcc_video_decoder_profile(struct DCCXVideoProfile *pVideoProfile);
static RMstatus get_video_resources_required(struct RMFPHandle *pHandle,
                                             struct RMLibPlayVideoProfile *pVideoProfile,
                                             struct DCCXVideoProfile* pDCCVideoProfile,
                                             struct DCCVideoResources *pDCCVideoResources);

RMstatus rmfp_internal_get_video_decoder_handler(void *pContext,
						 struct RMLibPlayVideoSource *pVideoSource,
						 struct RMLibPlayVideoProfile *pVideoProfile)
{
	struct RMFPHandle *pHandle = NULL;
	struct RMFPVideoResourcesProfile rmfp_video_resources_profile = { 0, };

	struct DCCVideoSource *pDCCVideoSource = NULL;
	struct DCCXVideoProfile DCCVideoProfile = { 0, };
	struct DCCVideoResources dcc_video_resources = { 0, };

	struct RMFPVideoOptions *pVideoOptions = NULL;
	struct RMFPPlayOptions *pPlayOptions = NULL;

	struct DCC *pDCC = NULL;
	struct RUA *pRUA = NULL;

	RMuint32 module_ID = 0;

	RMstatus status;

	RMDBGLOG((LOCALDBG, "rmfp_get_video_decoder()\n"));

	ASSERT_NULL_POINTER(pContext);
	ASSERT_NULL_POINTER(pVideoSource);
	ASSERT_NULL_POINTER(pVideoProfile);

	pHandle = (struct RMFPHandle *)pContext;

	pRUA = pHandle->profile.pRUA;
	pDCC = pHandle->profile.pDCC;

	pVideoOptions = &(pHandle->video_options);
	pPlayOptions = &(pHandle->playback_options);
        
        if (pVideoOptions->ForceMaxMem) {
		RMDBGLOG((ENABLE, "Forcing MaxMem for Video\n"));

		switch(pVideoProfile->Codec) {
		case EMhwlibVideoCodec_H264:
			pVideoProfile->MaxWidth  = 1920;
			pVideoProfile->MaxHeight = 1080;
			pVideoProfile->Profile   = EMhwlib_H264_MaxProfile;
			pVideoProfile->Level     = EMhwlib_H264_MaxLevel;
			break;

		case EMhwlibVideoCodec_AVS:
			pVideoProfile->MaxWidth  = 1920;
			pVideoProfile->MaxHeight = 1080;
			pVideoProfile->Profile   = EMhwlib_AVS_MaxProfile;
			pVideoProfile->Level     = EMhwlib_AVS_MaxLevel;
			break;

		case EMhwlibVideoCodec_WMV:
		case EMhwlibVideoCodec_DIVX3:
		case EMhwlibVideoCodec_MPEG2:
		case EMhwlibVideoCodec_MPEG4:
		case EMhwlibVideoCodec_MPEG4_Padding:
		case EMhwlibVideoCodec_VC1:
		case EMhwlibVideoCodec_H261:
			pVideoProfile->MaxWidth  = 1920;
			pVideoProfile->MaxHeight = 1080;
			break;

		case EMhwlibJPEGCodec:
		case EMhwlibDVDSpuCodec:
		case EMhwlibBDRLECodec:
			break;
		};

	}

	/* check COMMON_FLAGS_START_DISPLAY_AT_SYSTEM_PTS */
	if (pVideoProfile->StartDisplayAtSystemPTS)
		pVideoOptions->common_flags |= COMMON_FLAGS_START_DISPLAY_AT_SYSTEM_PTS;

	rmfp_print_rmlibplay_video_decoder_profile(pVideoProfile);

	// Get required resources for the requested codec
	status = get_video_resources_required(pHandle, pVideoProfile, &DCCVideoProfile, &dcc_video_resources);
	if (status != RM_OK) {
		RMNOTIFY((NULL, status, "Cannot get required resources for video\n"));
		goto exit;
	}

	// take DCCVideoResources and DCCVideoProfile to create a RMFPVideoResourcesProfile

	rmfp_video_resources_profile.Version                    = GET_VERSION_FROM_MAGIC(RMFP_VIDEO_RESOURCES_PROFILE_VERSION);

	rmfp_video_resources_profile.dram                       = pPlayOptions->DRAMIndex;

	rmfp_video_resources_profile.scheduler_memory_address   = dcc_video_resources.SchedulerSharedMemoryAddress;
	rmfp_video_resources_profile.scheduler_memory_size      = dcc_video_resources.SchedulerSharedMemorySize;

	rmfp_video_resources_profile.shared_memory_address      = dcc_video_resources.DecoderSharedMemoryAddress;
	rmfp_video_resources_profile.shared_memory_size         = dcc_video_resources.DecoderSharedMemorySize;

	rmfp_video_resources_profile.picture_memory_address     = dcc_video_resources.PictureProtectedMemoryAddress;
        rmfp_video_resources_profile.picture_memory_size        = dcc_video_resources.PictureProtectedMemorySize;
        
	rmfp_video_resources_profile.bitstream_memory_address   = dcc_video_resources.BitstreamProtectedMemoryAddress;
    rmfp_video_resources_profile.bitstream_memory_size      = dcc_video_resources.BitstreamProtectedMemorySize;

    rmfp_video_resources_profile.unprotected_memory_address = dcc_video_resources.UnprotectedMemoryAddress;
    if (pHandle->video_options.custom_memunp) {
        rmfp_video_resources_profile.unprotected_memory_size    = pHandle->video_options.custom_memunp;
        RMDBGLOG((ENABLE, "Allocating custom unprotected buffer memory size of %ldB\n", pHandle->video_options.custom_memunp ));
    } else {
        rmfp_video_resources_profile.unprotected_memory_size    = dcc_video_resources.UnprotectedMemorySize;
    }

        rmfp_video_resources_profile.postprocessing_memory_address = dcc_video_resources.PostProcessingMemoryAddress;
	rmfp_video_resources_profile.postprocessing_memory_size    = dcc_video_resources.PostProcessingMemorySize;

	rmfp_video_resources_profile.engine_index               = DCCVideoProfile.MpegEngineID;
	rmfp_video_resources_profile.decoder_index              = DCCVideoProfile.VideoDecoderID;

	rmfp_video_resources_profile.STC_index                  = pPlayOptions->STCIndex + pPlayOptions->STCEngine*3;

	// then present the RMFPVideoResourcesProfile to the application if the callback was defined
	if (pHandle->profile.rmfp_video_resources_callback) {
		status = pHandle->profile.rmfp_video_resources_callback(pHandle->profile.callback_context, &rmfp_video_resources_profile);
		if (status != RM_OK) {
			RMNOTIFY((NULL, status, "Failed to get resources from application\n"));
			goto exit;
		}
	}
#if (!((EM86XX_CHIP == EM86XX_CHIPID_TANGO3) && (defined XBOOT2_SMP865X)))
	// Check parameters consistency
	if (rmfp_video_resources_profile.dram != rmfp_video_resources_profile.engine_index) {
		RMNOTIFY((NULL, RM_ERROR, "Invalid configuration selected: DRAMIndex %lu != EngineIndex %lu, they must be equal\n",
			    rmfp_video_resources_profile.dram,
			    rmfp_video_resources_profile.engine_index));
		return RM_ERROR;
	}
#endif
	// If unprotected memory is lower than expected, try to get a valid level for it
	if (rmfp_video_resources_profile.unprotected_memory_size < dcc_video_resources.UnprotectedMemorySize) {

		RMuint32* pLevelsTable = NULL;
		RMuint32 levels_table_size = 0;
		RMuint32 current_level_index;
		RMint32 cnt;

		// Get the right table respect to codec
		switch (pVideoProfile->Codec) {
		case EMhwlibVideoCodec_H264:
			pLevelsTable = H264_levels;
			levels_table_size = sizeof(H264_levels) / sizeof(RMuint32);
			break;
		case EMhwlibVideoCodec_AVS:
			pLevelsTable = AVS_levels;
			levels_table_size = sizeof(AVS_levels) / sizeof(RMuint32);
			break;
		default:
			RMNOTIFY((NULL, RM_ERROR, "Reducing unprotected memory size for codec %d is not allowed\n", pVideoProfile->Codec));
			return RM_ERROR;
		}

		// First locate the current level in list
		for (current_level_index=0; current_level_index < levels_table_size; current_level_index++) {
			if (pLevelsTable[current_level_index] == pVideoProfile->Level)
				break;
		}

		// Level not found in list ?
		if (current_level_index == levels_table_size) {
			RMNOTIFY((NULL, RM_ERROR, "Unable to reduce unprotected memory size for an unsupported level %d\n", pVideoProfile->Level));
			return RM_ERROR;
		}

		// Is it the first in list ?
		if (current_level_index == 0) {
			RMNOTIFY((NULL, RM_ERROR, "Unable to reduce unprotected memory size for the already lowest level %d\n", pVideoProfile->Level));
			return RM_ERROR;
		}

		// Try to get a level corresponding to the requested size
		for (cnt = (RMint32)(current_level_index-1); cnt >=0; cnt--) {

			// Set new candidate
			pVideoProfile->Level = pLevelsTable[cnt];

			// Get required resources for the requested codec
			status = get_video_resources_required(pHandle, pVideoProfile, &DCCVideoProfile, &dcc_video_resources);
			if (status == RM_OK) {
				if (dcc_video_resources.UnprotectedMemorySize <= rmfp_video_resources_profile.unprotected_memory_size) {
					RMDBGLOG((ENABLE, "Using a video level %d using %d bytes of unprotected memory\n",
							pVideoProfile->Level, dcc_video_resources.UnprotectedMemorySize));
					break;
				}
			}
		}

		// Unable to find a correct level
		if (cnt == -1) {
			RMNOTIFY((NULL, RM_ERROR, "Unable to find a level using %d bytes or less of unprotected memory\n", rmfp_video_resources_profile.unprotected_memory_size));
			return RM_ERROR;
		}
	}

	// then allocate the resources and create a video source

	// scheduler shared
	if ((!rmfp_video_resources_profile.scheduler_memory_address) &&
	    (rmfp_video_resources_profile.scheduler_memory_size)) {
		RMuint32 addr;
		RMuint32 tag = RUA_ADDRESS_ID_TAG(RUA_ADDRESS_ID_VIDEO_SCHEDULER_SHARED, DCCVideoProfile.MpegEngineID);

		addr = RUAGetAddressID(pHandle->profile.pRUA, tag);
		if (addr) {
			RMDBGLOG((ENABLE, "Found SchedulerSharedMem by ID @ 0x%lx, reusing it\n", addr));

			pHandle->video_resources.scheduler_memory_address = addr;

			/* since both addr and size are set, then DCCOpenVideoSourceWithResources will use
			   RMMpegEnginePropertyID_SchedulerSharedMemory to set the mem, just as if it had been
			   allocated here
			*/
		}
		else {

			pHandle->video_resources.scheduler_memory_address = DCCMalloc(pDCC,
										      rmfp_video_resources_profile.dram,
										      RUA_DRAM_UNCACHED,
										      rmfp_video_resources_profile.scheduler_memory_size);

			if (!pHandle->video_resources.scheduler_memory_address) {
				RMNOTIFY((NULL, RM_FATALOUTOFMEMORY, "Can't allocate %lu bytes in DRAM %lu\n",
					  rmfp_video_resources_profile.scheduler_memory_size,
					  rmfp_video_resources_profile.dram));

				return RM_FATALOUTOFMEMORY;
			}
			else
				RMDBGLOG((LOCALDBG, "allocated %lu bytes for decoder scheduler\n", rmfp_video_resources_profile.scheduler_memory_size));

			// Free shared only if this instance allocated it
			pHandle->video_resources.free_scheduler = TRUE;

			// set ID so that other processes can find the memory
			status = RUASetAddressID(pHandle->profile.pRUA, pHandle->video_resources.scheduler_memory_address, tag);
			if (status != RM_OK) {
				RMNOTIFY((NULL, status, "Can't set addressID 0x%lx to address 0x%lx\n", tag, pHandle->video_resources.scheduler_memory_address));
				return status;
			}

			/* Acquire address so that it is not released from the RUA register table */
			status = RUAAcquireAddress(pHandle->profile.pRUA, pHandle->video_resources.scheduler_memory_address);
			if (status != RM_OK) {
				RMNOTIFY((NULL, status, "Can't acquire shared memory\n"));
				return status;
			}
		}

	}
	else {
		if (rmfp_video_resources_profile.scheduler_memory_address)
			RMDBGLOG((LOCALDBG, "Reusing SchedulerSharedMem @ 0x%lx\n",
				  rmfp_video_resources_profile.scheduler_memory_address));

		pHandle->video_resources.scheduler_memory_address = rmfp_video_resources_profile.scheduler_memory_address;
	}

	dcc_video_resources.SchedulerSharedMemoryAddress = pHandle->video_resources.scheduler_memory_address;
	dcc_video_resources.SchedulerSharedMemorySize = rmfp_video_resources_profile.scheduler_memory_size;

	RMDBGLOG((LOCALDBG, "Scheduler Shared Memory: %lu bytes at %p\n",
		  dcc_video_resources.SchedulerSharedMemorySize,
		  dcc_video_resources.SchedulerSharedMemoryAddress));


	// decoder shared
	if ((!rmfp_video_resources_profile.shared_memory_address) &&
	    (rmfp_video_resources_profile.shared_memory_size)) {
		RMuint32 addr;
		RMuint32 tag = RUA_ADDRESS_ID_TAG(RUA_ADDRESS_ID_VIDEO_DECODER_SHARED, DCCVideoProfile.MpegEngineID);

		addr = RUAGetAddressID(pHandle->profile.pRUA, tag);
		if (addr) {
			RMDBGLOG((ENABLE, "Found DecoderSharedMem by ID @ 0x%lx, reusing it\n", addr));

			pHandle->video_resources.shared_memory_address = addr;

			/* since both addr and size are set, then DCCOpenVideoSourceWithResources will use
			   RMMpegEnginePropertyID_DecoderSharedMemory to set the mem, just as if it had been
			   allocated here
			*/
		}
		else {

			pHandle->video_resources.shared_memory_address = DCCMalloc(pDCC,
										   rmfp_video_resources_profile.dram,
										   RUA_DRAM_UNCACHED,
										   rmfp_video_resources_profile.shared_memory_size);

			if (!pHandle->video_resources.shared_memory_address) {
				RMNOTIFY((NULL, RM_FATALOUTOFMEMORY, "Can't allocate %lu bytes in DRAM %lu\n",
					  rmfp_video_resources_profile.shared_memory_size,
					  rmfp_video_resources_profile.dram));

				return RM_FATALOUTOFMEMORY;
			}
			else
				RMDBGLOG((LOCALDBG, "allocated %lu bytes for decoder shared memory\n", rmfp_video_resources_profile.shared_memory_size));

			// Free shared only if this instance allocated it
			pHandle->video_resources.free_shared = TRUE;

			// set ID so that other processes can find the memory
			status = RUASetAddressID(pHandle->profile.pRUA, pHandle->video_resources.shared_memory_address, tag);
			if (status != RM_OK) {
				RMNOTIFY((NULL, status, "Can't set addressID 0x%lx to address 0x%lx\n", tag, pHandle->video_resources.shared_memory_address));
				return status;
			}

			/* Acquire address so that it is not released from the RUA register table */
			status = RUAAcquireAddress(pHandle->profile.pRUA, pHandle->video_resources.shared_memory_address);
			if (status != RM_OK) {
				RMNOTIFY((NULL, status, "Can't acquire shared memory\n"));
				return status;
			}
		}
	}
	else {
		if (rmfp_video_resources_profile.shared_memory_address)
			RMDBGLOG((ENABLE, "Reusing DecoderSharedMem @ 0x%lx\n",
				  rmfp_video_resources_profile.shared_memory_address));

		pHandle->video_resources.shared_memory_address = rmfp_video_resources_profile.shared_memory_address;
	}


	dcc_video_resources.DecoderSharedMemoryAddress = pHandle->video_resources.shared_memory_address;
	dcc_video_resources.DecoderSharedMemorySize = rmfp_video_resources_profile.shared_memory_size;

	RMDBGLOG((LOCALDBG, "Decoder Shared Memory: %lu bytes at %p\n",
		  dcc_video_resources.DecoderSharedMemorySize,
		  dcc_video_resources.DecoderSharedMemoryAddress));


#if ALWAYS_TRY_TO_FREE_SHARED_MEMORY
	/* Try to free scheduler and shared anyway when exiting */
	pHandle->video_resources.free_shared    = TRUE;
	pHandle->video_resources.free_scheduler = TRUE;
#endif


	// picture
	if ((!rmfp_video_resources_profile.picture_memory_address) &&
	    (rmfp_video_resources_profile.picture_memory_size)) {
		pHandle->video_resources.picture_memory_address = DCCMalloc(pDCC,
									    rmfp_video_resources_profile.dram,
									    RUA_DRAM_UNCACHED,
									    rmfp_video_resources_profile.picture_memory_size);

		if (!pHandle->video_resources.picture_memory_address) {
			RMNOTIFY((NULL, RM_FATALOUTOFMEMORY, "Can't allocate %lu bytes in DRAM %lu\n",
				    rmfp_video_resources_profile.picture_memory_size,
				    rmfp_video_resources_profile.dram));
			return RM_FATALOUTOFMEMORY;
		}
		else
			RMDBGLOG((LOCALDBG, "allocated %lu bytes for pictures\n", rmfp_video_resources_profile.picture_memory_size));

		pHandle->video_resources.free_picture = TRUE;
	}
	else
		pHandle->video_resources.picture_memory_address = rmfp_video_resources_profile.picture_memory_address;

	dcc_video_resources.PictureProtectedMemoryAddress = pHandle->video_resources.picture_memory_address;
	dcc_video_resources.PictureProtectedMemorySize = rmfp_video_resources_profile.picture_memory_size;

	RMDBGLOG((LOCALDBG, "Picture Protected Memory: %lu bytes at %p\n",
		  dcc_video_resources.PictureProtectedMemorySize,
		  dcc_video_resources.PictureProtectedMemoryAddress));


	// bitstream
	if ((!rmfp_video_resources_profile.bitstream_memory_address) &&
	    (rmfp_video_resources_profile.bitstream_memory_size)) {
		pHandle->video_resources.bitstream_memory_address = DCCMalloc(pDCC,
									      rmfp_video_resources_profile.dram,
									      RUA_DRAM_UNCACHED,
									      rmfp_video_resources_profile.bitstream_memory_size);

		if (!pHandle->video_resources.bitstream_memory_address) {
			RMNOTIFY((NULL, RM_FATALOUTOFMEMORY, "Can't allocate %lu bytes in DRAM %lu\n",
				    rmfp_video_resources_profile.bitstream_memory_size,
				    rmfp_video_resources_profile.dram));
			return RM_FATALOUTOFMEMORY;
		}
		else
			RMDBGLOG((LOCALDBG, "allocated %lu bytes for bitstream\n", rmfp_video_resources_profile.bitstream_memory_size));

		pHandle->video_resources.free_bitstream = TRUE;
	}
	else
		pHandle->video_resources.bitstream_memory_address = rmfp_video_resources_profile.bitstream_memory_address;

	dcc_video_resources.BitstreamProtectedMemoryAddress = pHandle->video_resources.bitstream_memory_address;
	dcc_video_resources.BitstreamProtectedMemorySize = rmfp_video_resources_profile.bitstream_memory_size;

	RMDBGLOG((LOCALDBG, "Bitstream Protected Memory: %lu bytes at %p\n",
		  dcc_video_resources.BitstreamProtectedMemorySize,
		  dcc_video_resources.BitstreamProtectedMemoryAddress));

	// unprotected
	if ((!rmfp_video_resources_profile.unprotected_memory_address) &&
	    (rmfp_video_resources_profile.unprotected_memory_size)) {
		pHandle->video_resources.unprotected_memory_address = DCCMalloc(pDCC,
										rmfp_video_resources_profile.dram,
										RUA_DRAM_UNCACHED,
										rmfp_video_resources_profile.unprotected_memory_size);

		if (!pHandle->video_resources.unprotected_memory_address) {
			RMNOTIFY((NULL, RM_FATALOUTOFMEMORY, "Can't allocate %lu bytes in DRAM %lu\n",
				    rmfp_video_resources_profile.unprotected_memory_size,
				    rmfp_video_resources_profile.dram));
			return RM_FATALOUTOFMEMORY;
		}
		else
			RMDBGLOG((LOCALDBG, "allocated %lu bytes for unprotected memory\n", rmfp_video_resources_profile.unprotected_memory_size));

		pHandle->video_resources.free_unprotected = TRUE;
	}
	else
		pHandle->video_resources.unprotected_memory_address = rmfp_video_resources_profile.unprotected_memory_address;

	dcc_video_resources.UnprotectedMemoryAddress = pHandle->video_resources.unprotected_memory_address;
	dcc_video_resources.UnprotectedMemorySize = rmfp_video_resources_profile.unprotected_memory_size;

	RMDBGLOG((LOCALDBG, "UnProtected Memory: %lu bytes at %p\n",
		  dcc_video_resources.UnprotectedMemorySize,
		  dcc_video_resources.UnprotectedMemoryAddress));

	// postprocessing
	if ((!rmfp_video_resources_profile.postprocessing_memory_address) &&
	    (rmfp_video_resources_profile.postprocessing_memory_size)) {
		pHandle->video_resources.postprocessing_memory_address = DCCMalloc(pDCC,
									    rmfp_video_resources_profile.dram,
									    RUA_DRAM_UNCACHED,
									    rmfp_video_resources_profile.postprocessing_memory_size);

		if (!pHandle->video_resources.postprocessing_memory_address) {
			RMNOTIFY((NULL, RM_FATALOUTOFMEMORY, "Can't allocate %lu bytes in DRAM %lu\n",
				    rmfp_video_resources_profile.postprocessing_memory_size,
				    rmfp_video_resources_profile.dram));
			return RM_FATALOUTOFMEMORY;
		}
		else
			RMDBGLOG((LOCALDBG, "allocated %lu bytes for postprocessing\n", rmfp_video_resources_profile.postprocessing_memory_size));

		pHandle->video_resources.free_postprocessing = TRUE;
	}
	else
		pHandle->video_resources.postprocessing_memory_address = rmfp_video_resources_profile.postprocessing_memory_address;

	dcc_video_resources.PostProcessingMemoryAddress = pHandle->video_resources.postprocessing_memory_address;
	dcc_video_resources.PostProcessingMemorySize = rmfp_video_resources_profile.postprocessing_memory_size;

	RMDBGLOG((LOCALDBG, "PostProcessing Memory: %lu bytes at %p\n",
		  dcc_video_resources.PostProcessingMemorySize,
		  dcc_video_resources.PostProcessingMemoryAddress));



// Update used dram index
	pHandle->video_resources.dram = rmfp_video_resources_profile.dram;

	pHandle->video_resources.engine_index = rmfp_video_resources_profile.engine_index;
	pHandle->video_resources.decoder_index = rmfp_video_resources_profile.decoder_index;

	status = DCCVideoGetModuleIDsFromIndexes(pDCC,
						  rmfp_video_resources_profile.engine_index,
						  rmfp_video_resources_profile.decoder_index,
						  &(pHandle->video_resources.engine_module_ID),
						  &(pHandle->video_resources.decoder_module_ID));
	if (status != RM_OK) {
		RMNOTIFY((NULL, status, "Couldn't get module IDs\n"));
		goto exit;
	}

	// Update indexes
	DCCVideoProfile.MpegEngineID            = rmfp_video_resources_profile.engine_index;
	DCCVideoProfile.VideoDecoderID          = rmfp_video_resources_profile.decoder_index;

  // open a dcc video source with the resources

	status = DCCOpenVideoDecoderSourceWithResources(pDCC, &DCCVideoProfile, &dcc_video_resources, &(pDCCVideoSource));
	if (status != RM_OK) {
		RMNOTIFY((NULL, status, "Cannot open video decoder source with resources\n"));
		goto exit;
	}

	{
		UINT64_t uiStartTimeMs = GetSysUpTimeMs();
		while(TRUE)
		{
			status = DCCXSetVideoDecoderSourceCodec(pDCCVideoSource, DCCVideoProfile.Codec);
			if(RMSUCCEEDED(status))
			{
				break;
			}
			else if(RM_PENDING == status && (1*1000 > (GetSysUpTimeMs() - uiStartTimeMs)))
			{
				usleep(5*1000);
			}
			else if (status != RM_OK) {
				RMNOTIFY((NULL, status, "Cannot set video source codec\n"));
				goto exit;
			}
		}
	}

	/* get surface from application */
	if (pHandle->profile.rmfp_get_surface_events_callback) {
		struct RMFPSurfaceProfile SurfaceProfile;
		struct RMFPSurfaceEventsSource SurfaceEventsSource;
		RMuint32 surface;

		status = DCCGetSurfaceSource(pDCC, pDCCVideoSource, &surface);
		if (status != RM_OK) {
			RMNOTIFY((NULL, status, "Cannot get surface\n"));
			goto exit;
		}

		SurfaceProfile.Version = GET_VERSION_FROM_MAGIC(RMFP_SURFACE_PROFILE_VERSION);

		if (pPlayOptions->PTEnable == TRUE) {
			RMuint32 output_surface;

			pVideoOptions->vcodec_max_width = pVideoProfile->MaxWidth;
			pVideoOptions->vcodec_max_height = pVideoProfile->MaxHeight;

			status = rmfp_internal_open_picture_transform(pHandle, &surface, &output_surface);
			if (status != RM_OK) {
				RMNOTIFY((NULL, status, "Cannot set the Picture Transform\n"));
				goto exit;
			}

			SurfaceProfile.surface = (struct EMhwlibSurface *)output_surface;
			pVideoSource->surface = (struct EMhwlibSurface *) output_surface;
		}
		else if(pPlayOptions->watermark == TRUE)
		{
			RMuint32 output_surface_addr;

			status = rmfp_internal_open_ppf(pHandle, pVideoSource, surface, &output_surface_addr);
			if (status != RM_OK) {
				RMNOTIFY((NULL, status, "Cannot open the PPF module\n"));
				goto exit;
			}

			SurfaceProfile.surface = (struct EMhwlibSurface *)output_surface_addr;
			pVideoSource->surface = (struct EMhwlibSurface *) output_surface_addr;
		}
		else {
			SurfaceProfile.surface = (struct EMhwlibSurface *)surface;
			pVideoSource->surface = (struct EMhwlibSurface *)surface;
		}

		status = pHandle->profile.rmfp_get_surface_events_callback(pHandle->profile.callback_context , &SurfaceProfile, &SurfaceEventsSource);
		if (status != RM_OK) {
			RMNOTIFY((NULL, status, "Cannot get surface from application\n"));
			goto exit;
		}

		if (SurfaceProfile.surface != pVideoSource->surface) {
			RMDBGLOG((ENABLE, "The application changed the surface, updating\n"));

			pVideoSource->surface = SurfaceProfile.surface;
		}


		RMMemcpy(pVideoSource->event, SurfaceEventsSource.event, RMLIBPLAY_NB_DISPLAY_EVENTS * sizeof(struct RUAEvent));
	}
	else if (pVideoOptions->VideoScalerID){
		RMuint32 surface;

		status = DCCGetSurfaceSource(pDCC, pDCCVideoSource, &surface);
		if (status != RM_OK) {
			RMNOTIFY((NULL, status, "Cannot get surface\n"));
			goto exit;
		}

		/* if we specify scaler */
		RMDBGLOG((LOCALDBG, "Linking surface to scaler %lu\n", pVideoOptions->VideoScalerID));
		status = DCCSetSurfaceSource(pDCC, pVideoOptions->VideoScalerID, pDCCVideoSource);
		if (status != RM_OK) {
			RMNOTIFY((NULL, status, "Cannot set the surface source\n"));
			goto exit;
		}

		if (pPlayOptions->PTEnable == TRUE) {
			RMuint32 output_surface;

			status = rmfp_internal_open_picture_transform(pHandle, &surface, &output_surface);
			if (status != RM_OK) {
				RMNOTIFY((NULL, status, "Cannot set the Picture Transform\n"));
				goto exit;
			}

			pVideoSource->surface = (struct EMhwlibSurface *)output_surface;

		}
		else if(pPlayOptions->watermark == TRUE){
			RMuint32 output_surface_addr;

			status = rmfp_internal_open_ppf(pHandle, pVideoSource, surface, &output_surface_addr);
			if (status != RM_OK) {
				RMNOTIFY((NULL, status, "Cannot open the PPF module\n"));
				goto exit;
			}

			pVideoSource->surface = (struct EMhwlibSurface *)output_surface_addr;
		}
		else{
			pVideoSource->surface = (struct EMhwlibSurface *)surface;
		}

		pVideoSource->event[RMLIBPLAY_EVENT_INDEX_DISPLAY_EVENT].ModuleID = EMHWLIB_MODULE(DisplayBlock, 0);
		pVideoSource->event[RMLIBPLAY_EVENT_INDEX_DISPLAY_EVENT].Mask     = EMHWLIB_DISPLAY_EVENT_ID(pVideoOptions->VideoScalerID);

		pVideoSource->event[RMLIBPLAY_EVENT_INDEX_NEW_PICTURE].ModuleID   = EMHWLIB_MODULE(DisplayBlock, 0);
		pVideoSource->event[RMLIBPLAY_EVENT_INDEX_NEW_PICTURE].Mask       = EMHWLIB_DISPLAY_NEW_PICTURE_EVENT_ID(pVideoOptions->VideoScalerID);

		pVideoSource->event[RMLIBPLAY_EVENT_INDEX_EOS].ModuleID           = EMHWLIB_MODULE(DisplayBlock, 0);
		pVideoSource->event[RMLIBPLAY_EVENT_INDEX_EOS].Mask               = EMHWLIB_DISPLAY_INBAND_COMMAND_EVENT_ID(pVideoOptions->VideoScalerID);
	}

	RMDBGLOG((LOCALDBG, "get video decoder source info\n"));
	status = DCCGetVideoDecoderSourceInfo(pDCCVideoSource, &module_ID, NULL, NULL);
	if (status != RM_OK) {
		RMNOTIFY((NULL, status, "Cannot get video decoder source information\n"));
		goto exit;
	}

	pVideoSource->source = (void *)pDCCVideoSource;
	pVideoSource->ModuleID = module_ID;

	status = rmfp_apply_video_profile(pHandle, pVideoSource, pVideoProfile);
	if (status != RM_OK) {
		RMNOTIFY((NULL, status, "Cannot apply video decoder profile\n"));
		goto exit;
	}

	status = rmfp_apply_video_options(pHandle, pVideoSource);
	if (status != RM_OK) {
		RMNOTIFY((NULL, status, "Cannot apply video decoder options\n"));
		goto exit;
	}

#if	0
	{
		struct llad * pLlad = NULL;
		struct gbus * pGbus = NULL;
		RMuint32 dispBlkModuleId = EMHWLIB_MODULE(DisplayBlock, 0);
		struct DisplayBlock_SurfaceFrameInfoForce_type oSurfaceFrameInfoForce;
		struct EMhwlibSurface * pEmhwlibSurface = (typeof(pEmhwlibSurface))pVideoSource->surface;
		{
			pLlad = llad_open((RMascii *)"0");
			if(NULL == pLlad)
			{
				RMLOGFL((ENABLE, "llad_open err\n"));
			}
		}
		if(pLlad)
		{
			pGbus = gbus_open(pLlad);
			if(NULL == pGbus)
			{
				RMLOGFL((ENABLE, "gbus_open err\n"));
			}
		}
		RMLOGFL((ENABLE, "Surface: 0x%08x\n", pEmhwlibSurface));
		RMLOGFL((ENABLE, "  module_id: 0x%08x\n", gbus_read_uint32(pGbus, &(pEmhwlibSurface->module_id))));
		RMLOGFL((ENABLE, "  stc_id: 0x%08x\n", gbus_read_uint32(pGbus, &(pEmhwlibSurface->stc_id))));
		RMLOGFL((ENABLE, "  forced_flags: 0x%08x\n", gbus_read_uint32(pGbus, &(pEmhwlibSurface->forced_flags))));
		RMLOGFL((ENABLE, "  ar\n"));
		RMLOGFL((ENABLE, "    par\n"));
		RMLOGFL((ENABLE, "      x=%d\n", gbus_read_uint32(pGbus, &(pEmhwlibSurface->ar.par.X))));
		RMLOGFL((ENABLE, "      y=%d\n", gbus_read_uint32(pGbus, &(pEmhwlibSurface->ar.par.Y))));
		RMLOGFL((ENABLE, "    dar\n"));
		RMLOGFL((ENABLE, "      x=%d\n", gbus_read_uint32(pGbus, &(pEmhwlibSurface->ar.dar.X))));
		RMLOGFL((ENABLE, "      y=%d\n", gbus_read_uint32(pGbus, &(pEmhwlibSurface->ar.dar.Y))));
		RMLOGFL((ENABLE, "  tiled: 0x%08x\n", gbus_read_uint32(pGbus, &(pEmhwlibSurface->tiled))));
		RMLOGFL((ENABLE, "  force_Y_addr: 0x%08x\n", gbus_read_uint32(pGbus, &(pEmhwlibSurface->force_Y_addr))));
		RMLOGFL((ENABLE, "  force_UV_addr: 0x%08x\n", gbus_read_uint32(pGbus, &(pEmhwlibSurface->force_UV_addr))));
		RMLOGFL((ENABLE, "  valid_force_addr: 0x%08x\n", gbus_read_uint32(pGbus, &(pEmhwlibSurface->valid_force_addr))));
		RMLOGFL((ENABLE, "  phase_associated_surface: 0x%08x\n", gbus_read_uint32(pGbus, &(pEmhwlibSurface->phase_associated_surface))));
		RMMemset(&oSurfaceFrameInfoForce, 0x00, sizeof(oSurfaceFrameInfoForce));
		oSurfaceFrameInfoForce.surface = (typeof(oSurfaceFrameInfoForce.surface))pVideoSource->surface;
		//RMinsShiftBool(&(oSurfaceFrameInfoForce.FrameInfoForce.ClearMask), TRUE, EMHWLIB_FRAMEINFO_BIT_AspectRatio);
		RMinsShiftBool(&(oSurfaceFrameInfoForce.FrameInfoForce.ForceMask), TRUE, EMHWLIB_FRAMEINFO_BIT_AspectRatio);
		oSurfaceFrameInfoForce.FrameInfoForce.FrameInfo.AFD.FrameAspectRatio.X = 4;
		oSurfaceFrameInfoForce.FrameInfoForce.FrameInfo.AFD.FrameAspectRatio.Y = 3;
		oSurfaceFrameInfoForce.FrameInfoForce.FrameInfo.AFD.PixelAspectRatio.X = 0;
		oSurfaceFrameInfoForce.FrameInfoForce.FrameInfo.AFD.PixelAspectRatio.Y = 0;
		//*
		RMLOGFL((ENABLE, "SurfaceFrameInfoForce\n"));
		status = RUASetProperty(pRUA, dispBlkModuleId, RMDisplayBlockPropertyID_SurfaceFrameInfoForce,
			&oSurfaceFrameInfoForce, sizeof(oSurfaceFrameInfoForce), 0);
		if(RMFAILED(status))
		{
			RMLOGFL((ENABLE, "%s\n", RMstatusToString(status)));
		}
		//*/
		/*
		status = RUASetProperty(pRUA, dispBlkModuleId, RMGenericPropertyID_Validate, NULL, 0, 0);
		if(RMFAILED(status))
		{
			RMLOGFL((ENABLE, "%s\n", RMstatusToString(status)));
		}
		*/
		RMLOGFL((ENABLE, "Surface: 0x%08x\n", pEmhwlibSurface));
		RMLOGFL((ENABLE, "  module_id: 0x%08x\n", gbus_read_uint32(pGbus, &(pEmhwlibSurface->module_id))));
		RMLOGFL((ENABLE, "  stc_id: 0x%08x\n", gbus_read_uint32(pGbus, &(pEmhwlibSurface->stc_id))));
		RMLOGFL((ENABLE, "  forced_flags: 0x%08x\n", gbus_read_uint32(pGbus, &(pEmhwlibSurface->forced_flags))));
		RMLOGFL((ENABLE, "  ar\n"));
		RMLOGFL((ENABLE, "    par\n"));
		RMLOGFL((ENABLE, "      x=%d\n", gbus_read_uint32(pGbus, &(pEmhwlibSurface->ar.par.X))));
		RMLOGFL((ENABLE, "      y=%d\n", gbus_read_uint32(pGbus, &(pEmhwlibSurface->ar.par.Y))));
		RMLOGFL((ENABLE, "    dar\n"));
		RMLOGFL((ENABLE, "      x=%d\n", gbus_read_uint32(pGbus, &(pEmhwlibSurface->ar.dar.X))));
		RMLOGFL((ENABLE, "      y=%d\n", gbus_read_uint32(pGbus, &(pEmhwlibSurface->ar.dar.Y))));
		RMLOGFL((ENABLE, "  tiled: 0x%08x\n", gbus_read_uint32(pGbus, &(pEmhwlibSurface->tiled))));
		RMLOGFL((ENABLE, "  force_Y_addr: 0x%08x\n", gbus_read_uint32(pGbus, &(pEmhwlibSurface->force_Y_addr))));
		RMLOGFL((ENABLE, "  force_UV_addr: 0x%08x\n", gbus_read_uint32(pGbus, &(pEmhwlibSurface->force_UV_addr))));
		RMLOGFL((ENABLE, "  valid_force_addr: 0x%08x\n", gbus_read_uint32(pGbus, &(pEmhwlibSurface->valid_force_addr))));
		RMLOGFL((ENABLE, "  phase_associated_surface: 0x%08x\n", gbus_read_uint32(pGbus, &(pEmhwlibSurface->phase_associated_surface))));

		//gbus_write_uint32(pGbus, &(pEmhwlibSurface->ar.par.X), 0);
		//gbus_write_uint32(pGbus, &(pEmhwlibSurface->ar.par.Y), 0);

		RMLOGFL((ENABLE, "Surface: 0x%08x\n", pEmhwlibSurface));
		RMLOGFL((ENABLE, "  module_id: 0x%08x\n", gbus_read_uint32(pGbus, &(pEmhwlibSurface->module_id))));
		RMLOGFL((ENABLE, "  stc_id: 0x%08x\n", gbus_read_uint32(pGbus, &(pEmhwlibSurface->stc_id))));
		RMLOGFL((ENABLE, "  forced_flags: 0x%08x\n", gbus_read_uint32(pGbus, &(pEmhwlibSurface->forced_flags))));
		RMLOGFL((ENABLE, "  ar\n"));
		RMLOGFL((ENABLE, "    par\n"));
		RMLOGFL((ENABLE, "      x=%d\n", gbus_read_uint32(pGbus, &(pEmhwlibSurface->ar.par.X))));
		RMLOGFL((ENABLE, "      y=%d\n", gbus_read_uint32(pGbus, &(pEmhwlibSurface->ar.par.Y))));
		RMLOGFL((ENABLE, "    dar\n"));
		RMLOGFL((ENABLE, "      x=%d\n", gbus_read_uint32(pGbus, &(pEmhwlibSurface->ar.dar.X))));
		RMLOGFL((ENABLE, "      y=%d\n", gbus_read_uint32(pGbus, &(pEmhwlibSurface->ar.dar.Y))));
		RMLOGFL((ENABLE, "  tiled: 0x%08x\n", gbus_read_uint32(pGbus, &(pEmhwlibSurface->tiled))));
		RMLOGFL((ENABLE, "  force_Y_addr: 0x%08x\n", gbus_read_uint32(pGbus, &(pEmhwlibSurface->force_Y_addr))));
		RMLOGFL((ENABLE, "  force_UV_addr: 0x%08x\n", gbus_read_uint32(pGbus, &(pEmhwlibSurface->force_UV_addr))));
		RMLOGFL((ENABLE, "  valid_force_addr: 0x%08x\n", gbus_read_uint32(pGbus, &(pEmhwlibSurface->valid_force_addr))));
		RMLOGFL((ENABLE, "  phase_associated_surface: 0x%08x\n", gbus_read_uint32(pGbus, &(pEmhwlibSurface->phase_associated_surface))));
		
		if(pGbus)
		{
			gbus_close(pGbus);
			pGbus = NULL;
		}
		if(pLlad)
		{
			llad_close(pLlad);
			pLlad = NULL;
		}
	}
#endif

exit:

	pVideoSource->source = (void *)pDCCVideoSource;
	pVideoSource->ModuleID = module_ID;

	return status;
}

RMstatus rmfp_internal_release_video_decoder_handler(void *pContext, struct RMLibPlayVideoSource *pVideoSource)
{

	struct RMFPHandle *pHandle = NULL;
	struct RMFPVideoResourcesProfile rmfp_resources_profile = { 0, };
	struct DCCVideoSource *pDCCVideoSource = NULL;
	struct RMFPPlayOptions *pPlayOptions = NULL;
	struct RMFPVideoOptions *pVideoOptions = NULL;
	struct RUA *pRUA = NULL;
	struct DCC *pDCC = NULL;
	RMstatus status;

	RMDBGLOG((LOCALDBG, "rmfp_release_video_decoder()\n"));
	RMDBGLOG((LOCALDBG, "dcc_with_resources\n"));

	ASSERT_NULL_POINTER(pContext);
	ASSERT_NULL_POINTER(pVideoSource);

	pHandle = (struct RMFPHandle *)pContext;
	pDCCVideoSource = (struct DCCVideoSource *)pVideoSource->source;
	pRUA = pHandle->profile.pRUA;
	pDCC = pHandle->profile.pDCC;
	pPlayOptions = &(pHandle->playback_options);
	pVideoOptions = &(pHandle->video_options);

	/* Disconnect surface */
	if (pHandle->profile.rmfp_disconnect_surface_callback) {
		status = pHandle->profile.rmfp_disconnect_surface_callback(pHandle->profile.callback_context , (RMuint32) pVideoSource->surface);
		if (status != RM_OK) {
			RMNOTIFY((NULL, status, "rmfp_get_surface_events_callback\n"));
			return status;
		}
	}
	else if (pVideoOptions->VideoScalerID) {
		RMuint32 surface = 0;

		status = RUASetProperty(pRUA,
					pVideoOptions->VideoScalerID,
					RMGenericPropertyID_Surface,
					&surface,
					sizeof(surface),
					0);
		if (status != RM_OK) {
			RMNOTIFY((NULL, status, "RMGenericPropertyID_Surface\n"));
			return status;
		}
	}

	status = DCCCloseVideoSource(pDCCVideoSource);
	if (status != RM_OK)
		RMNOTIFY((NULL, status, "Failed to close video source but continue to release the resources\n"));

	if (pPlayOptions->PTEnable == TRUE) {
		rmfp_internal_close_picture_transform(pHandle);
		}
	else if(pPlayOptions->watermark == TRUE){

		/* Close the xform */
		status = rmfp_internal_close_ppf(pHandle, pVideoSource);
		if (status != RM_OK)
			RMNOTIFY((NULL, status, "Cannot unset the PPF module (%s)\n", RMstatusToString(status)));
	}


  // free everything we allocated internally

	if (pHandle->video_resources.free_postprocessing) {
		RMDBGLOG((LOCALDBG, "Free video postprocessing memory at %p\n", pHandle->video_resources.postprocessing_memory_address));
		DCCFree(pDCC, pHandle->video_resources.postprocessing_memory_address);
		pHandle->video_resources.postprocessing_memory_address = 0;
	}

	if (pHandle->video_resources.free_picture) {
		RMDBGLOG((LOCALDBG, "Free video picture memory at %p\n", pHandle->video_resources.picture_memory_address));
		DCCFree(pDCC, pHandle->video_resources.picture_memory_address);
		pHandle->video_resources.picture_memory_address = 0;
	}

	if (pHandle->video_resources.free_bitstream) {
		RMDBGLOG((LOCALDBG, "Free video bitstream memory at %p\n", pHandle->video_resources.bitstream_memory_address));
		DCCFree(pDCC, pHandle->video_resources.bitstream_memory_address);
		pHandle->video_resources.bitstream_memory_address = 0;
	}

	if (pHandle->video_resources.free_unprotected) {
		RMDBGLOG((LOCALDBG, "Free video unprotected memory at %p\n", pHandle->video_resources.unprotected_memory_address));
		DCCFree(pDCC, pHandle->video_resources.unprotected_memory_address);
		pHandle->video_resources.unprotected_memory_address = 0;
	}


	if (pHandle->video_resources.free_shared) {
		struct MpegEngine_DecoderSharedMemory_type shared;
		RMuint32 address;

		status = RUAGetProperty(pRUA,
					pHandle->video_resources.engine_module_ID,
					RMMpegEnginePropertyID_DecoderSharedMemory,
					&shared,
					sizeof(shared));

		if (status != RM_OK) {
			RMNOTIFY((NULL, status, "Cannot get DecoderSharedMemory\n"));
			return status;
		}

		if (shared.Address) {
			RMuint32 connected_task_count;

			address = shared.Address;

			status = RUAGetProperty(pRUA,
						pHandle->video_resources.engine_module_ID,
						RMMpegEnginePropertyID_ConnectedTaskCount,
						&connected_task_count,
						sizeof(connected_task_count));
			if (status != RM_OK) {
				RMNOTIFY((NULL, status, "Cannot get RMMpegEnginePropertyID_ConnectedTaskCount for %lu\n", pHandle->video_resources.engine_module_ID));
				return status;
			}

			if (connected_task_count == 0) {

				/* Release address */
				status = RUAReleaseAddress(pHandle->profile.pRUA, address);
				if (status != RM_OK) {
					RMNOTIFY((NULL, status, "Can't release shared memory\n"));
					return status;
				}

				// reset ID because we'll free the mem
				status = RUASetAddressID(pHandle->profile.pRUA, address, 0);
				if (status != RM_OK) {
					RMNOTIFY((NULL, status, "Can't reset addressID for address 0x%lx\n", address));
					return status;
				}


				RMDBGLOG((LOCALDBG, "Free video shared memory at %p (video module index %lu)\n",
					shared.Address,
					EMHWLIB_MODULE_INDEX(pHandle->video_resources.engine_module_ID)));

				shared.Address = 0;
				shared.Size = 0;

				status = RUASetProperty(pRUA,
							pHandle->video_resources.engine_module_ID,
							RMMpegEnginePropertyID_DecoderSharedMemory,
							&shared,
							sizeof(shared),
							0);
				if (status != RM_OK) {
					RMNOTIFY((NULL, status, "Can't unset the Decoder Shared Memory\n"));
					return status;
				}

				DCCFree(pDCC, address);
				pHandle->video_resources.shared_memory_address = 0;
			}
			else {
				RMDBGLOG((ENABLE, "Don't free memory for scheduler 0x%lx. There are still %lu video tasks opened depending on it\n",
					  EMHWLIB_MODULE_INDEX(pHandle->video_resources.engine_module_ID), connected_task_count));
			}

		}
	}

	if (pHandle->video_resources.free_scheduler) {
		struct MpegEngine_SchedulerSharedMemory_type schedmem;
		RMuint32 address;

		status = RUAGetProperty(pRUA,
					pHandle->video_resources.engine_module_ID,
					RMMpegEnginePropertyID_SchedulerSharedMemory,
					&schedmem,
					sizeof(schedmem));
		if (status != RM_OK) {
			RMNOTIFY((NULL, status, "Cannot get SchedulerSharedMemory\n"));
			return status;
		}

		if (schedmem.Address) {
			RMuint32 connected_task_count;

			address = schedmem.Address;

			status = RUAGetProperty(pRUA,
						pHandle->video_resources.engine_module_ID,
						RMMpegEnginePropertyID_ConnectedTaskCount,
						&connected_task_count,
						sizeof(connected_task_count));
			if (status != RM_OK) {
				RMNOTIFY((NULL, status, "Cannot get RMMpegEnginePropertyID_ConnectedTaskCount for %lu\n", pHandle->video_resources.engine_module_ID));
				return status;
			}

			if (connected_task_count == 0) {

				/* Release address */
				status = RUAReleaseAddress(pHandle->profile.pRUA, address);
				if (status != RM_OK) {
					RMNOTIFY((NULL, status, "Can't release shared memory\n"));
					return status;
				}

				// reset ID because we'll free the mem
				status = RUASetAddressID(pHandle->profile.pRUA, address, 0);
				if (status != RM_OK) {
					RMNOTIFY((NULL, status, "Can't reset addressID for address 0x%lx\n", address));
					return status;
				}


				RMDBGLOG((LOCALDBG, "Free video scheduler memory at %p (video module index %lu)\n",
					schedmem.Address,
					EMHWLIB_MODULE_INDEX(pHandle->video_resources.engine_module_ID)));

				schedmem.Address = 0;
				schedmem.Size = 0;

				status = RUASetProperty(pRUA,
							pHandle->video_resources.engine_module_ID,
							RMMpegEnginePropertyID_SchedulerSharedMemory,
							&schedmem,
							sizeof(schedmem),
							0);

				DCCFree(pDCC, address);
				pHandle->video_resources.scheduler_memory_address = 0;
			}
			else {
				RMDBGLOG((ENABLE, "Don't free memory for scheduler 0x%lx. There are still %lu video tasks opened depending on it.\n",
					  EMHWLIB_MODULE_INDEX(pHandle->video_resources.engine_module_ID), connected_task_count));
			}

		}
	}



  // convert from RMFPVideoResources to RMFPVideoResourcesProfile

	rmfp_resources_profile.Version = GET_VERSION_FROM_MAGIC(RMFP_VIDEO_RESOURCES_PROFILE_VERSION);

	rmfp_resources_profile.dram = pHandle->video_resources.dram;

	rmfp_resources_profile.scheduler_memory_address = pHandle->video_resources.scheduler_memory_address;
	rmfp_resources_profile.scheduler_memory_size = pHandle->video_resources.scheduler_memory_size;

	rmfp_resources_profile.shared_memory_address = pHandle->video_resources.shared_memory_address;
	rmfp_resources_profile.shared_memory_size = pHandle->video_resources.shared_memory_size;

	rmfp_resources_profile.picture_memory_address = pHandle->video_resources.picture_memory_address;
	rmfp_resources_profile.picture_memory_size = pHandle->video_resources.picture_memory_size;

	rmfp_resources_profile.bitstream_memory_address = pHandle->video_resources.bitstream_memory_address;
	rmfp_resources_profile.bitstream_memory_size = pHandle->video_resources.bitstream_memory_size;

	rmfp_resources_profile.unprotected_memory_address = pHandle->video_resources.unprotected_memory_address;
	rmfp_resources_profile.unprotected_memory_size = pHandle->video_resources.unprotected_memory_size;

	rmfp_resources_profile.engine_index = pHandle->video_resources.engine_index;
	rmfp_resources_profile.decoder_index = pHandle->video_resources.decoder_index;

	rmfp_resources_profile.STC_index = pPlayOptions->STCIndex + pPlayOptions->STCEngine*3;

  // then present the RMFPVideoResourcesProfile to the application if the callback was defined
	if (pHandle->profile.rmfp_release_video_resources_callback) {
		status = pHandle->profile.rmfp_release_video_resources_callback(pHandle->profile.callback_context, &rmfp_resources_profile);
		if (status != RM_OK) {
			RMNOTIFY((NULL, status, "The application failed to release the resources\n"));
			return status;
		}
	}


	return status;


}


static RMstatus rmfp_apply_video_profile(struct RMFPHandle *pHandle, struct RMLibPlayVideoSource *pVideoSource, struct RMLibPlayVideoProfile *pVideoProfile)
{
	RMstatus status;
	struct RUA *pRUA = NULL;
	struct RMFPVideoOptions *pVideoOptions = NULL;

	RMDBGLOG((LOCALDBG, "rmfp_apply_video_profile\n"));

	ASSERT_NULL_POINTER(pHandle);
	ASSERT_NULL_POINTER(pVideoSource);
	ASSERT_NULL_POINTER(pVideoProfile);

	pRUA = pHandle->profile.pRUA;
	pVideoOptions = &(pHandle->video_options);

	if (pVideoProfile->PTSTimeScale && pVideoProfile->PTSTimeIncrement) {
		struct VideoDecoder_VopInfo_type VOPInfo; //TODO it'd be nice to have a property with a more clear name

		RMDBGLOG((LOCALDBG, "Fixed frame rate = %lu / %lu\n", pVideoProfile->PTSTimeScale, pVideoProfile->PTSTimeIncrement));

		VOPInfo.VopTimeIncrementResolution = pVideoProfile->PTSTimeScale;
		VOPInfo.FixedVopTimeIncrement      = pVideoProfile->PTSTimeIncrement;
		VOPInfo.FixedVopRate               = TRUE;

		status = RUASetProperty(pRUA, pVideoSource->ModuleID, RMVideoDecoderPropertyID_VopInfo, &VOPInfo, sizeof(VOPInfo), 0);

		if (status != RM_OK)
			RMNOTIFY((NULL, status, "Cannot set fixed frame rate: %lu / %lu\n", pVideoProfile->PTSTimeScale, pVideoProfile->PTSTimeIncrement));
	}
	else if (pVideoProfile->PTSTimeScale) {
		struct VideoDecoder_VideoTimeScale_type TimeScaleInfo;

		RMDBGLOG((LOCALDBG, "Time scale = %lu\n", pVideoProfile->PTSTimeScale));

		TimeScaleInfo.time_resolution = pVideoProfile->PTSTimeScale;
		TimeScaleInfo.enable          = TRUE;

		status = RUASetProperty(pRUA, pVideoSource->ModuleID, RMVideoDecoderPropertyID_VideoTimeScale, &TimeScaleInfo, sizeof(TimeScaleInfo), 0 );
#if 0
		if (status != RM_OK)
			RMNOTIFY((NULL, status, "Cannot set time scale: %lu\n", pVideoProfile->PTSTimeScale));
#endif

	}

	if (pVideoProfile->SkipNCP) {
		RMbool dummy = TRUE;

		RMDBGLOG((LOCALDBG, "SkipNotCodedPFrames\n"));

		status = RUASetProperty(pRUA, pVideoSource->ModuleID, RMVideoDecoderPropertyID_SkipNotCodedPFrames, &dummy, sizeof(dummy), 0);

		if (status != RM_OK)
			RMNOTIFY((NULL, status, "Cannot set skip not coded P frames\n"));
	}

	switch(pVideoProfile->Codec) {
	case EMhwlibVideoCodec_WMV:
		RMDBGLOG((LOCALDBG, "WMV9 properties: %lu x %lu, seqhdr 0x%lx\n",
			  pVideoProfile->params.WMV9.Image_Width,
			  pVideoProfile->params.WMV9.Image_Height,
			  pVideoProfile->params.WMV9.Sequence));

		status = RUASetProperty(pRUA, pVideoSource->ModuleID, RMVideoDecoderPropertyID_WMV9VSProp, &(pVideoProfile->params.WMV9), sizeof(struct VideoDecoder_WMV9VSProp_type), 0);
		if (status != RM_OK) {
			RMNOTIFY((NULL, status, "Cannot set WMV9 parameters\n"));
			return status;
		}

		break;
	case EMhwlibVideoCodec_DIVX3:
		RMDBGLOG((LOCALDBG, "Divx3.11 properties: %lu x %lu\n",
			  pVideoProfile->params.DIVX3.Image_Width,
			  pVideoProfile->params.DIVX3.Image_Height));

		status = RUASetProperty(pRUA, pVideoSource->ModuleID, RMVideoDecoderPropertyID_DIVX3VSProp, &(pVideoProfile->params.DIVX3), sizeof(struct VideoDecoder_DIVX3VSProp_type), 0);
		if (status != RM_OK) {
			RMNOTIFY((NULL, status, "Cannot set DIVX parameters\n"));
			return status;
		}

		break;
	case EMhwlibVideoCodec_MPEG2:
		break;
	case EMhwlibVideoCodec_MPEG4:
	case EMhwlibVideoCodec_MPEG4_Padding:
		break;
	case EMhwlibVideoCodec_H264:
		status = RUASetProperty(pRUA, pVideoSource->ModuleID, RMVideoDecoderPropertyID_H264Flags, &(pVideoOptions->h264_flags), sizeof(pVideoOptions->h264_flags), 0);
		if (status != RM_OK) {
			RMNOTIFY((NULL, status, "Cannot set H264 parameters\n"));
			return status;
		}
		break;
	case EMhwlibVideoCodec_VC1:
		break;
	case EMhwlibJPEGCodec:
		break;
	case EMhwlibDVDSpuCodec:
		break;
	case EMhwlibBDRLECodec:
		break;
	case EMhwlibVideoCodec_AVS:
		break;
	case EMhwlibVideoCodec_H261:
		break;
	};
	return RM_OK;
}


static RMstatus rmfp_apply_video_options(struct RMFPHandle *pHandle, struct RMLibPlayVideoSource *pVideoSource)
{
	RMstatus status;
	struct RUA *pRUA = NULL;
	struct RMFPVideoOptions *pVideoOptions = NULL;

	RMDBGLOG((LOCALDBG, "rmfp_apply_video_options\n"));

	ASSERT_NULL_POINTER(pHandle);
	ASSERT_NULL_POINTER(pVideoSource);

	pRUA = pHandle->profile.pRUA;
	pVideoOptions = &(pHandle->video_options);


	status = RUASetProperty(pRUA, pVideoSource->ModuleID, RMVideoDecoderPropertyID_DisplayErrorThreshold, &(pVideoOptions->display_error_threshold), sizeof(pVideoOptions->display_error_threshold), 0);
	if (status != RM_OK)
		RMNOTIFY((NULL, status, "Cannot set Display Error Threshold\n"));

	status = RUASetProperty(pRUA, pVideoSource->ModuleID, RMVideoDecoderPropertyID_AnchorErrPropagation, &(pVideoOptions->anchor_error_propagation), sizeof(pVideoOptions->anchor_error_propagation), 0);
	if (status != RM_OK)
		RMNOTIFY((NULL, status, "Cannot set Anchor Error Propagation\n"));

	status = RUASetProperty(pRUA, pVideoSource->ModuleID, RMVideoDecoderPropertyID_InterlacedProgressiveAlgorithm, &(pVideoOptions->interlaced_progressive_algorithm), sizeof(pVideoOptions->interlaced_progressive_algorithm), 0);
	if (status != RM_OK)
		RMNOTIFY((NULL, status, "Cannot set Interlaced/Progressive Algorithm\n"));

	if (pVideoOptions->force_input_color_space) {
		struct VideoDecoder_ForceColorSpace_type prop;

		prop.Enable = TRUE;
		prop.ColorSpace = pVideoOptions->input_color_space;
		status = RUASetProperty(pRUA, pVideoSource->ModuleID, RMVideoDecoderPropertyID_ForceColorSpace, &prop, sizeof(prop), 0);
		if (status != RM_OK)
			RMNOTIFY((NULL, status, "Cannot set Input Color Space\n"));
	}

	status = RUASetProperty(pRUA, pVideoSource->ModuleID, RMVideoDecoderPropertyID_ScanMode, &(pVideoOptions->input_scan_mode), sizeof(pVideoOptions->input_scan_mode), 0);
	if (status != RM_OK)
		RMNOTIFY((NULL, status, "Cannot set Scan Mode\n"));

	{
		struct RUAEvent event = { 0, };
		RMuint32 RetryCount = 0;
		struct DisplayBlock_SurfaceDisplayInterval_type video_time_interval;
		struct DisplayBlock_SurfaceDefaultColorSpaceAlgorithm_type surface_cs_algo;

		video_time_interval.Surface = (RMuint32)(pVideoSource->surface);
		video_time_interval.TimeInterval.Mode = EMhwlibDisplayIntervalMode_None;

		event.ModuleID = pVideoSource->event[RMLIBPLAY_EVENT_INDEX_DISPLAY_EVENT].ModuleID;
		event.Mask = pVideoSource->event[RMLIBPLAY_EVENT_INDEX_DISPLAY_EVENT].Mask;
		RUAResetEvent(pRUA, &event);

		RetryCount = 0;
		while (RM_PENDING == (status = RUASetProperty(pRUA, EMHWLIB_MODULE(DisplayBlock, 0), RMDisplayBlockPropertyID_SurfaceDisplayInterval, &(video_time_interval), sizeof(video_time_interval), 0))) {
			RuaWaitFor_DispBlk_DispEvt_ThrdSync(pRUA, &event, 1, TIMEOUT_US, NULL);
			RMDBGPRINT((LOCALDBG, "."));

			if (RetryCount++ > RETRY_THRESHOLD) {
				RMNOTIFY((NULL, RM_TIMEOUT, "Retry count overrun\n"));
				break;
			}
		};
		
		surface_cs_algo.Surface = (RMuint32)(pVideoSource->surface);
		surface_cs_algo.Algorithm = pVideoOptions->cs_algo;
		status = RUASetProperty(pRUA, EMHWLIB_MODULE(DisplayBlock, 0), RMDisplayBlockPropertyID_SurfaceDefaultColorSpaceAlgorithm, &(surface_cs_algo), sizeof(surface_cs_algo), 0);
	}
	
	if (pVideoOptions->ForceAFD || pVideoOptions->ForceAsp || pVideoOptions->ForceBarInfo || pVideoOptions->ForceScanInfo || pVideoOptions->Force3D) {
		RMuint32 ModuleID, PropertyID;
#ifdef RMBUILD_USE_HWLIB_V2
		struct EMhwlibDispSurface_SurfaceFrameInfoForce_type SurfaceFrameInfoForce;
		ModuleID = EMHWLIB_MODULE(EMhwlibDispSurface, 0);
		PropertyID = RMPropertyID_SurfaceFrameInfoForce;
#else // RMBUILD_USE_HWLIB_V2
		struct DisplayBlock_SurfaceFrameInfoForce_type SurfaceFrameInfoForce;
		ModuleID = EMHWLIB_MODULE(DisplayBlock, 0);
		PropertyID = RMDisplayBlockPropertyID_SurfaceFrameInfoForce;
#endif // RMBUILD_USE_HWLIB_V2
		
		RMMemset(&SurfaceFrameInfoForce, 0, sizeof(SurfaceFrameInfoForce));
		SurfaceFrameInfoForce.surface = (RMuint32)(pVideoSource->surface);
		
		if (pVideoOptions->ForceAFD) {
			RMDBGLOG((ENABLE, "Forcing AFD on surface\n"));
			SurfaceFrameInfoForce.FrameInfoForce.ForceMask |= EMHWLIB_FRAMEINFO_MASK_ActiveFormat;
		}
		if (pVideoOptions->ForceAsp) {
			RMDBGLOG((ENABLE, "Forcing aspect ratio on surface\n"));
			SurfaceFrameInfoForce.FrameInfoForce.ForceMask |= EMHWLIB_FRAMEINFO_MASK_AspectRatio;
		}
		if (pVideoOptions->ForceBarInfo) {
			RMDBGLOG((ENABLE, "Forcing bar info on surface\n"));
			SurfaceFrameInfoForce.FrameInfoForce.ForceMask |= EMHWLIB_FRAMEINFO_MASK_BarData;
		}
		if (pVideoOptions->ForceScanInfo) {
			RMDBGLOG((ENABLE, "Forcing scan info on surface\n"));
			SurfaceFrameInfoForce.FrameInfoForce.ForceMask |= EMHWLIB_FRAMEINFO_MASK_ScanInfo;
		}
		if (pVideoOptions->Force3D) {
			RMDBGLOG((ENABLE, "Forcing 3D format on surface\n"));
			SurfaceFrameInfoForce.FrameInfoForce.ForceMask |= EMHWLIB_FRAMEINFO_MASK_Stereoscopic3D;
		}
		SurfaceFrameInfoForce.FrameInfoForce.FrameInfo.AFD = pVideoOptions->afd;
		SurfaceFrameInfoForce.FrameInfoForce.FrameInfo.BarInfo = pVideoOptions->BarInfo;
		SurfaceFrameInfoForce.FrameInfoForce.FrameInfo.ScanInfo = pVideoOptions->ScanInfo;
		SurfaceFrameInfoForce.FrameInfoForce.FrameInfo.Stereoscopic3D = pVideoOptions->Stereoscopic3D;
		
		status = RUASetProperty(pRUA, ModuleID, PropertyID, &(SurfaceFrameInfoForce), sizeof(SurfaceFrameInfoForce), 0);
		if (RMFAILED(status)) {
			RMNOTIFY((NULL, status, "Can not set SurfaceFrameInfoForce on %p\n", pVideoSource->surface));
		}
	} else {
		RMDBGLOG((ENABLE, "Not forcing anything on surface\n"));
	}

	// Common flags
	status = RUASetProperty(pRUA, pVideoSource->ModuleID, RMVideoDecoderPropertyID_CommonFlags, &(pVideoOptions->common_flags), sizeof(pVideoOptions->common_flags), 0);
	if (status != RM_OK)
		RMNOTIFY((NULL, status, "Cannot apply common flags to video decoder\n"));

	//status = RUASetProperty(pRUA, pVideoSource->event[0].ModuleID, RMGenericPropertyID_Validate, NULL, 0, 0);
	//if (status != RM_OK) {
	//	RMNOTIFY((NULL, status, "Cannot validate display\n"));
	//}

	return RM_OK;
}


static RMstatus rmfp_print_dcc_video_decoder_profile(struct DCCXVideoProfile *pVideoProfile)
{
	ASSERT_NULL_POINTER(pVideoProfile);

	RMDBGPRINT((LOCALDBG, "DCCVideoProfile:\n"));
	RMDBGPRINT((LOCALDBG, "\tEngineIndex             %lu\n", pVideoProfile->MpegEngineID));
	RMDBGPRINT((LOCALDBG, "\tDecoderIndex            %lu\n", pVideoProfile->VideoDecoderID));
	RMDBGPRINT((LOCALDBG, "\tSTCIndex                %lu\n", pVideoProfile->STCID));

	RMDBGPRINT((LOCALDBG, "\tCodec                   0x%lx\n", (RMuint32)pVideoProfile->Codec));
	RMDBGPRINT((LOCALDBG, "\tProfile                 %lu\n", pVideoProfile->Profile));
	RMDBGPRINT((LOCALDBG, "\tLevel                   %lu\n", pVideoProfile->Level));
	RMDBGPRINT((LOCALDBG, "\tMaxWidth                %lu\n", pVideoProfile->MaxWidth));
	RMDBGPRINT((LOCALDBG, "\tMaxHeight               %lu\n", pVideoProfile->MaxHeight));
	RMDBGPRINT((LOCALDBG, "\tExtraPictureBufferCount %lu\n", pVideoProfile->ExtraPictureBufferCount));

	RMDBGPRINT((LOCALDBG, "\tBitstreamFIFOSize       %lu\n", pVideoProfile->BitstreamFIFOSize));
	RMDBGPRINT((LOCALDBG, "\tXferFIFOCount           %lu\n", pVideoProfile->XferFIFOCount));
	RMDBGPRINT((LOCALDBG, "\tPtsFIFOCount            %lu\n", pVideoProfile->PtsFIFOCount));
	RMDBGPRINT((LOCALDBG, "\tInbandFIFOCount         %lu\n", pVideoProfile->InbandFIFOCount));


	RMDBGPRINT((LOCALDBG, "\tXtaskID                 0x%lx\n", pVideoProfile->XtaskID));
	RMDBGPRINT((LOCALDBG, "\tProtectedFlags          0x%lx\n", pVideoProfile->ProtectedFlags));
	RMDBGPRINT((LOCALDBG, "\tXtaskInbandFIFOCount    %lu\n", pVideoProfile->XtaskInbandFIFOCount));

	RMDBGPRINT((LOCALDBG, "\tSPUBitstreamFIFOSize    %lu\n", pVideoProfile->SPUBitstreamFIFOSize));
	RMDBGPRINT((LOCALDBG, "\tSPUXferFIFOCount        %lu\n", pVideoProfile->SPUXferFIFOCount));

	RMDBGPRINT((LOCALDBG, "\tPostProcessing          %lu\n", pVideoProfile->pp_enabled));
	RMDBGPRINT((LOCALDBG, "\tPostProcessing nb pic   %lu\n", pVideoProfile->pp_nb_pictures));

	return RM_OK;

}


static RMstatus rmfp_print_rmlibplay_video_decoder_profile(struct RMLibPlayVideoProfile *pVideoProfile)
{

	ASSERT_NULL_POINTER(pVideoProfile);

	RMDBGPRINT((LOCALDBG, "RMlibPlayVideoProfile:\n"));

	RMDBGPRINT((LOCALDBG, "\tCodec                   0x%lx\n", (RMuint32)pVideoProfile->Codec));
	RMDBGPRINT((LOCALDBG, "\tProfile                 %lu\n", pVideoProfile->Profile));
	RMDBGPRINT((LOCALDBG, "\tLevel                   %lu\n", pVideoProfile->Level));
	RMDBGPRINT((LOCALDBG, "\tMaxWidth                %lu\n", pVideoProfile->MaxWidth));
	RMDBGPRINT((LOCALDBG, "\tMaxHeight               %lu\n", pVideoProfile->MaxHeight));
	RMDBGPRINT((LOCALDBG, "\tExtraPictureBufferCount %lu\n", pVideoProfile->ExtraPictureBufferCount));

	RMDBGPRINT((LOCALDBG, "\tBitstreamFIFOSize       %lu\n", pVideoProfile->BitstreamFIFOSize));
	RMDBGPRINT((LOCALDBG, "\tXferFIFOCount           %lu\n", pVideoProfile->XferFIFOCount));
	RMDBGPRINT((LOCALDBG, "\tPtsFIFOCount            %lu\n", pVideoProfile->PtsFIFOCount));
	RMDBGPRINT((LOCALDBG, "\tInbandFIFOCount         %lu\n", pVideoProfile->InbandFIFOCount));

	RMDBGPRINT((LOCALDBG, "\tProtectedFlags          0x%lx\n", pVideoProfile->ProtectedFlags));

	RMDBGPRINT((LOCALDBG, "\tFixedFrameRate          %lu/%lu\n", pVideoProfile->PTSTimeScale, pVideoProfile->PTSTimeIncrement));
	RMDBGPRINT((LOCALDBG, "\tTimeScale               %lu\n", pVideoProfile->PTSTimeScale));
	RMDBGPRINT((LOCALDBG, "\tSkipNCP                 %lu\n", pVideoProfile->SkipNCP));

	RMDBGPRINT((LOCALDBG, "\tStartDisplayAtSystemPTS %lu\n", pVideoProfile->StartDisplayAtSystemPTS));

	switch(pVideoProfile->Codec) {
	case EMhwlibVideoCodec_WMV:

		RMDBGPRINT((LOCALDBG, "\t\tWMV9 properties: %lu x %lu, seqhdr 0x%lx\n",
			  pVideoProfile->params.WMV9.Image_Width,
			  pVideoProfile->params.WMV9.Image_Height,
			  pVideoProfile->params.WMV9.Sequence));

		break;
	case EMhwlibVideoCodec_DIVX3:

		RMDBGPRINT((LOCALDBG, "\t\tDivx3.11 properties: %lu x %lu\n",
			  pVideoProfile->params.DIVX3.Image_Width,
			  pVideoProfile->params.DIVX3.Image_Height));

		break;

	case EMhwlibVideoCodec_MPEG2:
		break;

	case EMhwlibVideoCodec_MPEG4:
		break;

	case EMhwlibVideoCodec_H264:
		break;

	case EMhwlibVideoCodec_VC1:
		break;

	case EMhwlibVideoCodec_AVS:
		break;

	default:
		// there shouldn't be a default but this enum is incomplete
		break;
	}


	return RM_OK;
}

static RMstatus get_video_resources_required(struct RMFPHandle *pHandle,
                                             struct RMLibPlayVideoProfile *pVideoProfile,
                                             struct DCCXVideoProfile* pDCCVideoProfile,
                                             struct DCCVideoResources *pDCCVideoResources)
{
	RMstatus status;
	struct RMFPVideoOptions *pVideoOptions = NULL;
	struct RMFPPlayOptions *pPlayOptions = NULL;
	struct DCC *pDCC = NULL;

	pDCC = pHandle->profile.pDCC;
	pVideoOptions = &(pHandle->video_options);
	pPlayOptions = &(pHandle->playback_options);

	// make a dcc video profile
	pDCCVideoProfile->MpegEngineID            = pVideoOptions->EngineIndex; //RMFP_DEFAULT_VIDEO_ENGINE_INDEX;
	pDCCVideoProfile->VideoDecoderID          = pVideoOptions->DecoderIndex; //RMFP_DEFAULT_VIDEO_DECODER_INDEX;
	pDCCVideoProfile->STCID                   = pPlayOptions->STCIndex + pPlayOptions->STCEngine*3;
	pDCCVideoProfile->XtaskID                 = 0;
	pDCCVideoProfile->ProtectedFlags          = 0;
	pDCCVideoProfile->XtaskInbandFIFOCount    = 0;
	pDCCVideoProfile->SPUBitstreamFIFOSize    = 0; //we don't want a spu decoder, won't fill the related fields
	pDCCVideoProfile->SPUXferFIFOCount        = 0;

	pDCCVideoProfile->BitstreamFIFOSize       = pVideoProfile->BitstreamFIFOSize;
	pDCCVideoProfile->XferFIFOCount           = pVideoProfile->XferFIFOCount;

	pDCCVideoProfile->PtsFIFOCount            = pVideoProfile->PtsFIFOCount;
	pDCCVideoProfile->InbandFIFOCount         = pVideoProfile->InbandFIFOCount;

	pDCCVideoProfile->Codec                   = pVideoProfile->Codec;
	pDCCVideoProfile->Profile                 = pVideoProfile->Profile;
	pDCCVideoProfile->Level                   = pVideoProfile->Level;
	pDCCVideoProfile->MaxWidth                = pVideoProfile->MaxWidth;
	pDCCVideoProfile->MaxHeight               = pVideoProfile->MaxHeight;
	pDCCVideoProfile->ExtraPictureBufferCount = pVideoProfile->ExtraPictureBufferCount;

	pDCCVideoProfile->pp_enabled              = pVideoOptions->pp_enabled;
	pDCCVideoProfile->pp_nb_pictures		= 10; /* TODO */
	if (pDCCVideoProfile->pp_enabled)
		pDCCVideoProfile->Level |= COMMON_FLAGS_ENABLE_POST_PROCESSING;

	rmfp_print_dcc_video_decoder_profile(pDCCVideoProfile);

	status = DCCGetVideoResourcesRequired(pDCC, pDCCVideoProfile, pDCCVideoResources);
	if (status != RM_OK) {
		RMNOTIFY((NULL, status, "Cannot get required resources for video\n"));
		return status;
	}

	return RM_OK;
}


