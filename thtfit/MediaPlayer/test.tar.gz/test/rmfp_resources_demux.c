/*****************************************
 Copyright 2001-2007
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   rmfp_resources_demux.c
  @brief


  @author Sebastian Frias Feltrer
  @date   2007-11-05
*/

#include "rmfp_internal.h"

#if 0
#define LOCALDBG ENABLE
#else
#define LOCALDBG DISABLE
#endif



static RMstatus rmfp_apply_demux_profile(struct RMFPHandle *pHandle, struct RMLibPlayDemuxSource *pDemuxSource, struct RMLibPlayDemuxProfile *pDemuxProfile);
static RMstatus rmfp_apply_demux_options(struct RMFPHandle *pHandle, struct RMLibPlayDemuxSource *pDemuxSource);
static RMstatus rmfp_print_rmlibplay_demux_profile(struct RMLibPlayDemuxProfile *pDemuxProfile);
static RMstatus rmfp_print_dcc_demux_profile(struct DCCDemuxTaskProfile *pDemuxProfile);

static RMstatus rmfp_apply_demux_output_profile(struct RMFPHandle *pHandle, struct RMLibPlayDemuxOutputSource *pDemuxOutputSource, struct RMLibPlayDemuxOutputProfile *pDemuxOutputProfile);
static RMstatus rmfp_apply_demux_output_options(struct RMFPHandle *pHandle, struct RMLibPlayDemuxOutputSource *pDemuxOutputSource);



RMstatus rmfp_internal_get_demux_handler(void *pContext, struct RMLibPlayDemuxSource *pDemuxSource, struct RMLibPlayDemuxProfile *pDemuxProfile)
{

	struct RMFPHandle *pHandle = NULL;
	struct RMFPDemuxResourcesProfile rmfp_demux_resources_profile = { 0, };
	struct RMFPDemuxCipherResourcesProfile rmfp_demux_cypher_resources_profile = {0, };
	struct DCCDemuxTaskResources dcc_demux_resources = { 0, };

	struct DCCDemuxTask *pDCCDemuxTask = NULL;
	struct DCCDemuxTaskProfile dccDemuxProfile = { 0, };

	struct RMFPDemuxOptions *pDemuxOptions = NULL;
	struct RMFPPlayOptions *pPlayOptions = NULL;

	RMuint32 protected_memory_address;
	RMuint32 unprotected_memory_address;

	struct DCC *pDCC = NULL;
	struct RUA *pRUA = NULL;

	RMuint32 module_ID = 0;
	RMuint32 dummy;

	RMstatus status;

	RMDBGLOG((LOCALDBG, "rmfp_get_demux_handler() %lx %lx %lx \n", pContext, pDemuxSource, pDemuxProfile));
	ASSERT_NULL_POINTER(pContext);
	ASSERT_NULL_POINTER(pDemuxSource);
	ASSERT_NULL_POINTER(pDemuxProfile);

	pHandle = (struct RMFPHandle *)pContext;

	pRUA = pHandle->profile.pRUA;
	pDCC = pHandle->profile.pDCC;

	pDemuxOptions = &(pHandle->demux_options);
	pPlayOptions = &(pHandle->playback_options);


	rmfp_print_rmlibplay_demux_profile(pDemuxProfile);

	/*
	 * make a dcc demux profile
	 */
	dccDemuxProfile.DemuxTaskID             = pDemuxOptions->task_id;
	dccDemuxProfile.DemuxEngineID           = pDemuxOptions->engine_id;

	dccDemuxProfile.ProtectedFlags          = pDemuxProfile->ProtectedFlags;
	dccDemuxProfile.BitstreamFIFOSize       = pDemuxProfile->BitstreamFIFOSize;
	dccDemuxProfile.XferFIFOCount           = pDemuxProfile->XferFIFOCount;
	dccDemuxProfile.InbandFIFOCount         = pDemuxProfile->InbandFIFOCount;

	dccDemuxProfile.InputPort               = pDemuxOptions->input_port;
	dccDemuxProfile.PrimaryMPM              = pDemuxOptions->task_id;
	dccDemuxProfile.SecondaryMPM            = pDemuxOptions->spi ? dccDemuxProfile.PrimaryMPM : 3;;

	rmfp_print_dcc_demux_profile(&dccDemuxProfile);

	status = DCCGetDemuxTaskResourcesRequired(pDCC, &dccDemuxProfile, &dcc_demux_resources);
	if (status != RM_OK) {
		RMNOTIFY((NULL, status, "Cannot get required resources for demux\n"));
		return status;
	}

	/*
	 * Take DCCDemuxTaskResources and DCCDemuxTaskProfile to create a RMFPDemuxResourcesProfile
	 */

	rmfp_demux_resources_profile.Version                    = GET_VERSION_FROM_MAGIC(RMFP_DEMUX_RESOURCES_PROFILE_VERSION);

	rmfp_demux_resources_profile.dram                       = pPlayOptions->DRAMIndex;

	rmfp_demux_resources_profile.protected_memory_address   = dcc_demux_resources.BitstreamProtectedMemoryAddress;
	rmfp_demux_resources_profile.protected_memory_size      = dcc_demux_resources.BitstreamProtectedMemorySize;

	rmfp_demux_resources_profile.unprotected_memory_address = dcc_demux_resources.UnprotectedMemoryAddress;
	rmfp_demux_resources_profile.unprotected_memory_size    = dcc_demux_resources.UnprotectedMemorySize;

	rmfp_demux_resources_profile.engine_index               = dccDemuxProfile.DemuxEngineID;
	rmfp_demux_resources_profile.task_index                 = dccDemuxProfile.DemuxTaskID;

	rmfp_demux_resources_profile.STC_index                  = pPlayOptions->STCIndex + pPlayOptions->STCEngine*3;

	/*
  	 * Then present the RMFPDemuxResourcesProfile to the application if the callback was defined
	 */
	if (pHandle->profile.rmfp_demux_resources_callback) {
		status = pHandle->profile.rmfp_demux_resources_callback(pHandle->profile.callback_context, &rmfp_demux_resources_profile);
		if (status != RM_OK) {
			RMNOTIFY((NULL, status, "Failed to get resources from application\n"));
			return status;
		}
	}

	// Check parameters consistency
	if (rmfp_demux_resources_profile.engine_index != pPlayOptions->STCEngine) {
		RMNOTIFY((NULL, RM_ERROR, "Invalid configuration selected: demux engine %lu != stc engine %lu, they must be equal\n",
			    rmfp_demux_resources_profile.engine_index,
			    pPlayOptions->STCEngine));
		return RM_ERROR;
	}
	
	/*
	 * Then, we must take care of a possible encryption of the file
	 */
	rmfp_demux_cypher_resources_profile.Version = GET_VERSION_FROM_MAGIC(RMFP_DEMUX_CIPHER_RESOURCES_PROFILE_VERSION);
	rmfp_demux_cypher_resources_profile.engine_index  = rmfp_demux_resources_profile.engine_index;
	rmfp_demux_cypher_resources_profile.task_index    = rmfp_demux_resources_profile.task_index;
	DCCGetDemuxTaskModuleIDsFromIndexes(	pDCC,
						rmfp_demux_resources_profile.engine_index,
						rmfp_demux_resources_profile.task_index,
						&dummy,
						&rmfp_demux_cypher_resources_profile.demux_task);
	if (pHandle->profile.rmfp_demux_cipher_resources_callback) {
		status = pHandle->profile.rmfp_demux_cipher_resources_callback(pHandle->profile.callback_context, &rmfp_demux_cypher_resources_profile);
		if (status != RM_OK) {
			RMNOTIFY((NULL, status, "Failed to get cipher resources from application\n"));
			return status;
		}
	}
  
	/* Now fill xtask part */
	dccDemuxProfile.XTaskInbandFIFOCount    = rmfp_demux_cypher_resources_profile.XTaskInbandFIFOCount;
	dccDemuxProfile.XTaskContext            = rmfp_demux_cypher_resources_profile.XTaskContext;
	dccDemuxProfile.XTaskModuleId           = rmfp_demux_cypher_resources_profile.XTaskModuleId;

	/*
	 * then allocate the resources and create a demux source
	 */

	/* protected */
	if ((!rmfp_demux_resources_profile.protected_memory_address) &&
	    (rmfp_demux_resources_profile.protected_memory_size)) {
		protected_memory_address = DCCMalloc(	pDCC,
							rmfp_demux_resources_profile.dram,
							RUA_DRAM_UNCACHED,
							rmfp_demux_resources_profile.protected_memory_size);

		if (!protected_memory_address) {
			RMNOTIFY((NULL, RM_FATALOUTOFMEMORY, "Can't allocate %lu bytes in DRAM %lu\n",
				    rmfp_demux_resources_profile.protected_memory_size,
				    pPlayOptions->DRAMIndex));
			return RM_FATALOUTOFMEMORY;
		}
		else
			RMDBGLOG((LOCALDBG, "allocated %lu bytes for protected\n", rmfp_demux_resources_profile.protected_memory_size));

		pHandle->demux_resources.free_protected = TRUE;
	}
	else
	{
		protected_memory_address = rmfp_demux_resources_profile.protected_memory_address;
		pHandle->demux_resources.free_protected = FALSE;
	}

	dcc_demux_resources.BitstreamProtectedMemoryAddress = protected_memory_address;
	dcc_demux_resources.BitstreamProtectedMemorySize = rmfp_demux_resources_profile.protected_memory_size;

	RMDBGLOG((LOCALDBG, "Bitstream Protected Memory: %lu bytes at %p\n",
		  dcc_demux_resources.BitstreamProtectedMemorySize,
		  dcc_demux_resources.BitstreamProtectedMemoryAddress));

	/* unprotected */
	if ((!rmfp_demux_resources_profile.unprotected_memory_address) &&
	    (rmfp_demux_resources_profile.unprotected_memory_size)) {
		unprotected_memory_address = DCCMalloc(	pDCC,
							rmfp_demux_resources_profile.dram,
							RUA_DRAM_UNCACHED,
							rmfp_demux_resources_profile.unprotected_memory_size);

		if (!unprotected_memory_address) {
			RMNOTIFY((NULL, RM_FATALOUTOFMEMORY, "Can't allocate %lu bytes in DRAM %lu\n",
				    rmfp_demux_resources_profile.unprotected_memory_size,
				    pPlayOptions->DRAMIndex));
			return RM_FATALOUTOFMEMORY;
		}
		else
			RMDBGLOG((LOCALDBG, "allocated %lu bytes for unprotected memory\n", rmfp_demux_resources_profile.unprotected_memory_size));

		pHandle->demux_resources.free_unprotected = TRUE;
	}
	else
	{
		unprotected_memory_address = rmfp_demux_resources_profile.unprotected_memory_address;
		pHandle->demux_resources.free_unprotected = FALSE;
	}

	dcc_demux_resources.UnprotectedMemoryAddress = unprotected_memory_address;
	dcc_demux_resources.UnprotectedMemorySize = rmfp_demux_resources_profile.unprotected_memory_size;

	RMDBGLOG((LOCALDBG, "UnProtected Memory: %lu bytes at %p\n",
		  dcc_demux_resources.UnprotectedMemorySize,
		  dcc_demux_resources.UnprotectedMemoryAddress));

	/* Store used dram index */
	pHandle->demux_resources.dram = rmfp_demux_resources_profile.dram;

	/* Update engine and task index */
	dccDemuxProfile.DemuxEngineID = rmfp_demux_resources_profile.engine_index;
	dccDemuxProfile.DemuxTaskID = rmfp_demux_resources_profile.task_index;

	/*
	 * Open a dcc demux source with the resources
	 */
	status = DCCOpenDemuxTaskWithResources(pDCC, &dccDemuxProfile, &dcc_demux_resources, &(pDCCDemuxTask));
	if (status != RM_OK) {
		RMNOTIFY((NULL, status, "Can't open demux decoder source with resources\n"));
		return status;
	}

	status = DCCGetDemuxTaskInfo(pDCCDemuxTask, &module_ID);
	if (status != RM_OK) {
		RMNOTIFY((NULL, status, "Cannot get demux decoder source information\n"));
		return status;
	}
	RMDBGLOG((LOCALDBG, "get demux decoder source info 0x%lx\n", module_ID));

	pDemuxSource->source = (void *)pDCCDemuxTask;

	status = rmfp_apply_demux_profile(pHandle, pDemuxSource, pDemuxProfile);
	if (status != RM_OK) {
		RMNOTIFY((NULL, status, "Cannot apply demux decoder profile\n"));
		return status;
	}

	status = rmfp_apply_demux_options(pHandle, pDemuxSource);
	if (status != RM_OK) {
		RMNOTIFY((NULL, status, "Cannot apply demux decoder options\n"));
		return status;
	}

	return RM_OK;
}


RMstatus rmfp_internal_release_demux_handler(void *pContext, struct RMLibPlayDemuxSource *pDemuxSource)
{

	struct RMFPHandle *pHandle = NULL;
	struct RMFPDemuxResourcesProfile rmfp_resources_profile = { 0, };
	struct RMFPDemuxCipherResourcesProfile rmfp_cipher_resources_profile = { 0, };
	struct DCCDemuxTask *pDCCDemuxTask = NULL;
	struct DCCDemuxTaskResources dcc_demux_resources= { 0, };
	struct RUA *pRUA = NULL;
	struct DCC *pDCC = NULL;
	struct RMFPDemuxOptions *pDemuxOptions = NULL;
	struct RMFPPlayOptions *pPlayOptions = NULL;
	RMstatus status;
	RMuint32 dummy;

	RMDBGLOG((LOCALDBG, "rmfp_release_demux_handler()\n"));

	ASSERT_NULL_POINTER(pContext);
	ASSERT_NULL_POINTER(pDemuxSource);

	pHandle = (struct RMFPHandle *)pContext;
	pDCCDemuxTask = (struct DCCDemuxTask *)pDemuxSource->source;
	pRUA = pHandle->profile.pRUA;
	pDCC = pHandle->profile.pDCC;

	pDemuxOptions = &(pHandle->demux_options);
	pPlayOptions = &(pHandle->playback_options);

	/* Get resources */
	status = DCCGetDemuxTaskResources(pDCCDemuxTask, &dcc_demux_resources);
	if (status != RM_OK)
		RMNOTIFY((NULL, status, "Failed to get demux task resources to free but close the demux task\n"));

	/*
	 * Release all external cipher allocation
	 */
	rmfp_cipher_resources_profile.Version = GET_VERSION_FROM_MAGIC(RMFP_DEMUX_CIPHER_RESOURCES_PROFILE_VERSION);
	rmfp_cipher_resources_profile.engine_index         = pDemuxOptions->engine_id;;
	rmfp_cipher_resources_profile.task_index           = pDemuxOptions->task_id;
	DCCGetDemuxTaskModuleIDsFromIndexes(	pDCC,
						pDemuxOptions->engine_id,
						pDemuxOptions->task_id,
						&dummy,
						&rmfp_cipher_resources_profile.demux_task);
	rmfp_cipher_resources_profile.XTaskModuleId        = dcc_demux_resources.XTaskModuleId;
	if (pHandle->profile.rmfp_release_demux_cipher_resources_callback) {
		status = pHandle->profile.rmfp_release_demux_cipher_resources_callback(pHandle->profile.callback_context, &rmfp_cipher_resources_profile);
		if (status != RM_OK)
			RMNOTIFY((NULL, status, "The application failed to release the cipher resources\n"));
	}

	/* Close demux task */
	status = DCCCloseDemuxTask(pDCCDemuxTask);
	if (status != RM_OK)
		RMNOTIFY((NULL, status, "Failed to close demux source but continue to release the resources\n"));

	/*
	 * free everything we allocated internally
	 */
	if (pHandle->demux_resources.free_protected) {
		RMDBGLOG((LOCALDBG, "Free demux protected memory at %p\n", dcc_demux_resources.BitstreamProtectedMemoryAddress));
		DCCFree(pDCC, dcc_demux_resources.BitstreamProtectedMemoryAddress);
	}

	if (pHandle->demux_resources.free_unprotected) {
		RMDBGLOG((LOCALDBG, "Free demux unprotected memory at %p\n", dcc_demux_resources.UnprotectedMemoryAddress));
		DCCFree(pDCC, dcc_demux_resources.UnprotectedMemoryAddress);
	}

	/*
	 * convert from RMFPDemuxResources to RMFPDemuxResourcesProfile
	 */

	rmfp_resources_profile.Version = GET_VERSION_FROM_MAGIC(RMFP_DEMUX_RESOURCES_PROFILE_VERSION);

	rmfp_resources_profile.dram = pHandle->demux_resources.dram;

	rmfp_resources_profile.protected_memory_address = dcc_demux_resources.BitstreamProtectedMemoryAddress;
	rmfp_resources_profile.protected_memory_size = dcc_demux_resources.BitstreamProtectedMemorySize;

	rmfp_resources_profile.unprotected_memory_address = dcc_demux_resources.UnprotectedMemoryAddress;
	rmfp_resources_profile.unprotected_memory_size = dcc_demux_resources.UnprotectedMemorySize;

	rmfp_resources_profile.engine_index  = pDemuxOptions->engine_id;
	rmfp_resources_profile.task_index = pDemuxOptions->task_id;

	rmfp_resources_profile.STC_index = pPlayOptions->STCIndex + pPlayOptions->STCEngine*3;

	/*
	 * then present the RMFPDemuxResourcesProfile to the application if the callback was defined
	 */
	if (pHandle->profile.rmfp_release_demux_resources_callback) {
		status = pHandle->profile.rmfp_release_demux_resources_callback(pHandle->profile.callback_context, &rmfp_resources_profile);
		if (status != RM_OK) {
			RMNOTIFY((NULL, status, "The application failed to release the resources\n"));
			return status;
		}
	}

	return status;
}

static RMstatus rmfp_apply_demux_profile(struct RMFPHandle *pHandle, struct RMLibPlayDemuxSource *pDemuxSource, struct RMLibPlayDemuxProfile *pDemuxProfile)
{
	RMstatus status = RM_OK;

	RMDBGLOG((LOCALDBG, "rmfp_apply_demux_profile\n"));

	ASSERT_NULL_POINTER(pHandle);
	ASSERT_NULL_POINTER(pDemuxSource);
	ASSERT_NULL_POINTER(pDemuxProfile);

	return status;
}

static RMstatus rmfp_apply_demux_options(struct RMFPHandle *pHandle, struct RMLibPlayDemuxSource *pDemuxSource)
{
	RMstatus status = RM_OK;
	struct RUA *pRUA = NULL;
	struct RMFPDemuxOptions *pDemuxOptions = NULL;

	RMDBGLOG((LOCALDBG, "rmfp_apply_demux_options\n"));

	ASSERT_NULL_POINTER(pHandle);
	ASSERT_NULL_POINTER(pDemuxSource);

	pRUA = pHandle->profile.pRUA;
	pDemuxOptions = &(pHandle->demux_options);

	return status;
}


static RMstatus rmfp_print_dcc_demux_profile(struct DCCDemuxTaskProfile *pDemuxProfile)
{
	ASSERT_NULL_POINTER(pDemuxProfile);


	RMDBGPRINT((LOCALDBG, "DCCDemuxTaskProfile:\n"));

	RMDBGPRINT((LOCALDBG, "\tDemuxTaskID             %lu\n", pDemuxProfile->DemuxTaskID));
	RMDBGPRINT((LOCALDBG, "\tDemuxEngineID           %lu\n", pDemuxProfile->DemuxEngineID));

	RMDBGPRINT((LOCALDBG, "\tProtectedFlags          0x%lx\n", pDemuxProfile->ProtectedFlags));
	RMDBGPRINT((LOCALDBG, "\tBitstreamFIFOSize       %lu\n", pDemuxProfile->BitstreamFIFOSize));
	RMDBGPRINT((LOCALDBG, "\tXferFIFOCount           %lu\n", pDemuxProfile->XferFIFOCount));
	RMDBGPRINT((LOCALDBG, "\tInbandFIFOCount         %lu\n", pDemuxProfile->InbandFIFOCount));


	RMDBGPRINT((LOCALDBG, "\tInputPort               %lu\n", pDemuxProfile->InputPort));
	RMDBGPRINT((LOCALDBG, "\tPrimaryMPM              %lu\n", pDemuxProfile->PrimaryMPM));
	RMDBGPRINT((LOCALDBG, "\tSecondaryMPM            %lu\n", pDemuxProfile->SecondaryMPM));

	return RM_OK;
}



static RMstatus rmfp_print_rmlibplay_demux_profile(struct RMLibPlayDemuxProfile *pDemuxProfile)
{

	ASSERT_NULL_POINTER(pDemuxProfile);

	RMDBGPRINT((LOCALDBG, "RMlibPlayDemuxProfile:\n"));

	RMDBGPRINT((LOCALDBG, "\tProtectedFlags          0x%lx\n", pDemuxProfile->ProtectedFlags));
	RMDBGPRINT((LOCALDBG, "\tBitstreamFIFOSize       %lu\n", pDemuxProfile->BitstreamFIFOSize));
	RMDBGPRINT((LOCALDBG, "\tXferFIFOCount           %lu\n", pDemuxProfile->XferFIFOCount));
	RMDBGPRINT((LOCALDBG, "\tInbandFIFOCount         %lu\n", pDemuxProfile->InbandFIFOCount));

	return RM_OK;
}


RMstatus rmfp_internal_get_demux_output_handler(void *pContext, struct RMLibPlayDemuxOutputSource *pDemuxOutputSource, struct RMLibPlayDemuxOutputProfile *pDemuxOutputProfile)
{

	RMuint32 cnt;
	struct RMFPHandle *pHandle = NULL;
	struct RMFPDemuxOutputResourcesProfile rmfp_demux_output_resources_profile = { 0, };
	struct DCCDemuxOutputResources dcc_demux_output_resources = { 0, };

	struct DCCDemuxOutput *pDCCDemuxOutput = NULL;
	struct DCCDemuxOutputProfile dccDemuxOutputProfile = { 0, };

	struct RMFPDemuxOptions *pDemuxOptions = NULL;
	struct RMFPPlayOptions *pPlayOptions = NULL;

	RMuint32 protected_memory_address;
	RMuint32 unprotected_memory_address;
	RMbool free_protected;
	RMbool free_unprotected;

	struct DCC *pDCC = NULL;
	struct RUA *pRUA = NULL;

	RMstatus status;
	RMDBGLOG((LOCALDBG, "rmfp_internal_get_demux_output_handler() %lx %lx %lx \n", pContext, pDemuxOutputSource, pDemuxOutputProfile));

	ASSERT_NULL_POINTER(pContext);
	ASSERT_NULL_POINTER(pDemuxOutputSource);
	ASSERT_NULL_POINTER(pDemuxOutputProfile);

	pHandle = (struct RMFPHandle *)pContext;

	pRUA = pHandle->profile.pRUA;
	pDCC = pHandle->profile.pDCC;

	pDemuxOptions = &(pHandle->demux_options);
	pPlayOptions = &(pHandle->playback_options);


  // make a dcc demux profile

	dccDemuxOutputProfile.data_type = pDemuxOutputProfile->data_type;

	switch (pDemuxOutputProfile->profile_type)
	{
		case RMLibPlayDemuxOutputType_decoder:

			dccDemuxOutputProfile.profile_type = DCCDemuxOutputType_decoder;
			dccDemuxOutputProfile.profile.decoder.consumer_module_id = pDemuxOutputProfile->profile.decoder.consumer_module_id;
			dccDemuxOutputProfile.profile.decoder.pts_enabled = pDemuxOutputProfile->profile.decoder.pts_enabled;
			dccDemuxOutputProfile.profile.decoder.audio_ts_priority = pDemuxOutputProfile->profile.decoder.audio_ts_priority;

			break;

		case RMLibPlayDemuxOutputType_dma:

			dccDemuxOutputProfile.profile_type = DCCDemuxOutputType_dma;
			dccDemuxOutputProfile.profile.dma.ProtectedFlags = pDemuxOutputProfile->profile.dma.ProtectedFlags;
			dccDemuxOutputProfile.profile.dma.BitstreamFIFOSize = pDemuxOutputProfile->profile.dma.BitstreamFIFOSize;
			dccDemuxOutputProfile.profile.dma.XferFIFOCount = pDemuxOutputProfile->profile.dma.XferFIFOCount;
			dccDemuxOutputProfile.profile.dma.PTSFIFOCount = pDemuxOutputProfile->profile.dma.PTSFIFOCount;
			dccDemuxOutputProfile.profile.dma.InbandFIFOCount = pDemuxOutputProfile->profile.dma.InbandFIFOCount;
			dccDemuxOutputProfile.profile.dma.stc_module_id = pDemuxOutputProfile->profile.dma.stc_module_id;
			dccDemuxOutputProfile.profile.dma.buffer_count = pDemuxOutputProfile->profile.dma.buffer_count;
			dccDemuxOutputProfile.profile.dma.buffer_size_log2 = pDemuxOutputProfile->profile.dma.buffer_size_log2;
			dccDemuxOutputProfile.profile.dma.partial_read = pDemuxOutputProfile->profile.dma.partial_read;
			dccDemuxOutputProfile.profile.dma.threshold = pDemuxOutputProfile->profile.dma.threshold;
			dccDemuxOutputProfile.profile.dma.pCallback = pDemuxOutputProfile->profile.dma.pCallback;
			dccDemuxOutputProfile.profile.dma.pContext = pDemuxOutputProfile->profile.dma.pContext;
			switch (pDemuxOutputProfile->profile.dma.receive_mode)
			{
				case RMLibPlayReceiveData_dma_backward_compatible :
					dccDemuxOutputProfile.profile.dma.receive_mode = DCCReceiveData_dma_backward_compatible;
					break;
				case RMLibPlayReceiveData_dma_full_buffer :
					dccDemuxOutputProfile.profile.dma.receive_mode = DCCReceiveData_dma_full_buffer;
					break;
				case RMLibPlayReceiveData_dma_no_delay :
					dccDemuxOutputProfile.profile.dma.receive_mode = DCCReceiveData_dma_no_delay;
					break;
				case RMLibPlayReceiveData_dma_minimum_size :
					dccDemuxOutputProfile.profile.dma.receive_mode = DCCReceiveData_dma_minimum_size;
					break;
				case RMLibPlayReceiveData_dma_exact_size :
					dccDemuxOutputProfile.profile.dma.receive_mode = DCCReceiveData_dma_exact_size;
					break;
			}
			break;

		case RMLibPlayDemuxOutputType_nodma:
		{
			/* TODO */
			RMDBGLOG((ENABLE, "Error: RMLibPlayDemuxOutputType_nodma not yet impletemented"));
			return RM_NOTIMPLEMENTED;
		}

	}

	status = DCCGetDemuxOutputResourcesRequired(pDemuxOutputProfile->demux_source, &dccDemuxOutputProfile, &dcc_demux_output_resources);
	if (status != RM_OK) {
		RMNOTIFY((NULL, status, "Cannot get required resources for demux output\n"));
		return status;
	}

  // take DCCDemuxOutputResources and DCCDemuxOutputProfile to create a RMFPDemuxResourcesProfile

	rmfp_demux_output_resources_profile.Version                    = GET_VERSION_FROM_MAGIC(RMFP_DEMUX_OUTPUT_RESOURCES_PROFILE_VERSION);

	rmfp_demux_output_resources_profile.dram                       = pPlayOptions->DRAMIndex;

	rmfp_demux_output_resources_profile.protected_memory_address   = dcc_demux_output_resources.BitstreamProtectedMemoryAddress;
	rmfp_demux_output_resources_profile.protected_memory_size      = dcc_demux_output_resources.BitstreamProtectedMemorySize;

	rmfp_demux_output_resources_profile.unprotected_memory_address = dcc_demux_output_resources.UnprotectedMemoryAddress;
	rmfp_demux_output_resources_profile.unprotected_memory_size    = dcc_demux_output_resources.UnprotectedMemorySize;

 	rmfp_demux_output_resources_profile.engine_index               = pDemuxOptions->engine_id;
	rmfp_demux_output_resources_profile.task_index                 = pDemuxOptions->task_id;

	rmfp_demux_output_resources_profile.STC_index                  = pPlayOptions->STCIndex + pPlayOptions->STCEngine*3;

	// then present the RMFPDemuxOutputResourcesProfile to the application if the callback was defined
	if (pHandle->profile.rmfp_demux_output_resources_callback) {
		status = pHandle->profile.rmfp_demux_output_resources_callback(pHandle->profile.callback_context, &rmfp_demux_output_resources_profile);
		if (status != RM_OK) {
			RMNOTIFY((NULL, status, "Failed to get resources from application\n"));
			return status;
		}
	}

  // then allocate the resources and create a demux source

	// protected
	if ((!rmfp_demux_output_resources_profile.protected_memory_address) &&
	    (rmfp_demux_output_resources_profile.protected_memory_size)) {
		protected_memory_address = DCCMalloc(	pDCC,
							rmfp_demux_output_resources_profile.dram,
							RUA_DRAM_UNCACHED,
							rmfp_demux_output_resources_profile.protected_memory_size);

		if (!protected_memory_address) {
			RMNOTIFY((NULL, RM_FATALOUTOFMEMORY, "Can't allocate %lu bytes in DRAM %lu\n",
				    rmfp_demux_output_resources_profile.protected_memory_size,
				    pPlayOptions->DRAMIndex));
			return RM_FATALOUTOFMEMORY;
		}
		else
			RMDBGLOG((LOCALDBG, "allocated %lu bytes for protected\n", rmfp_demux_output_resources_profile.protected_memory_size));

		free_protected = TRUE;
	}
	else
	{
		protected_memory_address = rmfp_demux_output_resources_profile.protected_memory_address;
		free_protected = FALSE;
	}

	dcc_demux_output_resources.BitstreamProtectedMemoryAddress = protected_memory_address;
	dcc_demux_output_resources.BitstreamProtectedMemorySize = rmfp_demux_output_resources_profile.protected_memory_size;

	RMDBGLOG((LOCALDBG, "Bitstream Protected Memory: %lu bytes at %p\n",
		  dcc_demux_output_resources.BitstreamProtectedMemorySize,
		  protected_memory_address));

	// unprotected
	if ((!rmfp_demux_output_resources_profile.unprotected_memory_address) &&
	    (rmfp_demux_output_resources_profile.unprotected_memory_size)) {
		unprotected_memory_address = DCCMalloc(	pDCC,
							rmfp_demux_output_resources_profile.dram,
							RUA_DRAM_UNCACHED,
							rmfp_demux_output_resources_profile.unprotected_memory_size);

		if (!unprotected_memory_address) {
			RMNOTIFY((NULL, RM_FATALOUTOFMEMORY, "Can't allocate %lu bytes in DRAM %lu\n",
				    rmfp_demux_output_resources_profile.unprotected_memory_size,
				    pPlayOptions->DRAMIndex));
			return RM_FATALOUTOFMEMORY;
		}
		else
			RMDBGLOG((LOCALDBG, "allocated %lu bytes for unprotected memory\n", rmfp_demux_output_resources_profile.unprotected_memory_size));

		free_unprotected = TRUE;
	}
	else
	{
		unprotected_memory_address = rmfp_demux_output_resources_profile.unprotected_memory_address;
		free_unprotected = FALSE;
	}

	dcc_demux_output_resources.UnprotectedMemoryAddress = unprotected_memory_address;
	dcc_demux_output_resources.UnprotectedMemorySize = rmfp_demux_output_resources_profile.unprotected_memory_size;

	RMDBGLOG((LOCALDBG, "UnProtected Memory: %lu bytes at %p\n",
		  dcc_demux_output_resources.UnprotectedMemorySize,
		  unprotected_memory_address));

  // open a dcc demux output source with the resources

	status = DCCOpenDemuxOutputWithResources(pDemuxOutputProfile->demux_source, &dccDemuxOutputProfile, &dcc_demux_output_resources, &(pDCCDemuxOutput));
	if (status != RM_OK) {
		RMNOTIFY((NULL, status, "Can't open demux decoder source with resources\n"));
		return status;
	}

	pDemuxOutputSource->source = (void *)pDCCDemuxOutput;

	/* Store resources parameters in a free slot */
	for (cnt=0; cnt<RMFP_MAX_OUTPUTS; cnt++)
	{
		if (pHandle->demux_output_resources.entry[cnt].handle == NULL)
		{
			pHandle->demux_output_resources.entry[cnt].handle = pDCCDemuxOutput;
			pHandle->demux_output_resources.entry[cnt].free_protected = free_protected;
			pHandle->demux_output_resources.entry[cnt].free_unprotected = free_unprotected;
			pHandle->demux_output_resources.entry[cnt].dram = rmfp_demux_output_resources_profile.dram;
			break;
		}
	}


	if (cnt == RMFP_MAX_OUTPUTS)
	{
		RMNOTIFY((NULL, RM_ERROR, "Cannot store demux output resources info\n"));
		return status;
	}

	status = rmfp_apply_demux_output_profile(pHandle, pDemuxOutputSource, pDemuxOutputProfile);
	if (status != RM_OK) {
		RMNOTIFY((NULL, status, "Cannot apply demux output profile\n"));
		return status;
	}

	status = rmfp_apply_demux_output_options(pHandle, pDemuxOutputSource);
	if (status != RM_OK) {
		RMNOTIFY((NULL, status, "Cannot apply demux output options\n"));
		return status;
	}


	return RM_OK;

}


RMstatus rmfp_internal_release_demux_output_handler(void *pContext, struct RMLibPlayDemuxOutputSource *pDemuxOutputSource)
{

	struct RMFPHandle *pHandle = NULL;
	struct RMFPDemuxOutputResourcesProfile rmfp_resources_profile = { 0, };
	struct DCCDemuxOutput *pDCCDemuxOutput = NULL;
	struct DCCDemuxOutputResources dcc_demux_output_resources = { 0, };
	struct RUA *pRUA = NULL;
	struct DCC *pDCC = NULL;
	struct RMFPDemuxOptions *pDemuxOptions = NULL;
	struct RMFPPlayOptions *pPlayOptions = NULL;
	RMuint32 cnt;
	RMstatus status;

	RMDBGLOG((LOCALDBG, "rmfp_release_demux_output_handler()\n"));

	ASSERT_NULL_POINTER(pContext);
	ASSERT_NULL_POINTER(pDemuxOutputSource);

	pHandle = (struct RMFPHandle *)pContext;
	pDCCDemuxOutput = (struct DCCDemuxOutput *)pDemuxOutputSource->source;
	pRUA = pHandle->profile.pRUA;
	pDCC = pHandle->profile.pDCC;

	pDemuxOptions = &(pHandle->demux_options);
	pPlayOptions = &(pHandle->playback_options);

	/* Get resources */
	status = DCCGetDemuxOutputResources(pDemuxOutputSource->source, &dcc_demux_output_resources);
	if (status != RM_OK)
		RMNOTIFY((NULL, status, "Failed to get demux task resources to free but close the demux task\n"));

	/* Get resources parameters */
	for (cnt=0; cnt<RMFP_MAX_OUTPUTS; cnt++)
	{
		if (((struct DCCDemuxOutput *)pHandle->demux_output_resources.entry[cnt].handle) == pDCCDemuxOutput)
			break;
	}

	if (cnt == RMFP_MAX_OUTPUTS)
	{
		RMNOTIFY((NULL, RM_ERROR, "Cannot find demux output resources info\n"));
		status = DCCCloseDemuxOutput(pDCCDemuxOutput);
		if (status != RM_OK)
			RMNOTIFY((NULL, status, "Failed to close demux output source\n"));
		return RM_ERROR;
	}

	status = DCCCloseDemuxOutput(pDCCDemuxOutput);
	if (status != RM_OK)
		RMNOTIFY((NULL, status, "Failed to close demux output source but continue to release the resources\n"));


	// free everything we allocated internally

	if (pHandle->demux_output_resources.entry[cnt].free_protected) {
		RMDBGLOG((LOCALDBG, "Free demux output protected memory at %p\n", dcc_demux_output_resources.BitstreamProtectedMemoryAddress));
		DCCFree(pDCC, dcc_demux_output_resources.BitstreamProtectedMemoryAddress);
	}

	if (pHandle->demux_output_resources.entry[cnt].free_unprotected) {
		RMDBGLOG((LOCALDBG, "Free demux output_unprotected memory at %p\n", dcc_demux_output_resources.UnprotectedMemoryAddress));
		DCCFree(pDCC, dcc_demux_output_resources.UnprotectedMemoryAddress);
	}

  // convert from RMFPDemuxResources to RMFPDemuxResourcesProfile

	rmfp_resources_profile.Version = GET_VERSION_FROM_MAGIC(RMFP_DEMUX_OUTPUT_RESOURCES_PROFILE_VERSION);

	rmfp_resources_profile.dram = pHandle->demux_output_resources.entry[cnt].dram;

	rmfp_resources_profile.protected_memory_address = dcc_demux_output_resources.BitstreamProtectedMemoryAddress;
	rmfp_resources_profile.protected_memory_size = dcc_demux_output_resources.BitstreamProtectedMemorySize;

	rmfp_resources_profile.unprotected_memory_address = dcc_demux_output_resources.UnprotectedMemoryAddress;
	rmfp_resources_profile.unprotected_memory_size = dcc_demux_output_resources.UnprotectedMemorySize;

	rmfp_resources_profile.engine_index = pDemuxOptions->engine_id;
	rmfp_resources_profile.task_index = pDemuxOptions->task_id;

	rmfp_resources_profile.STC_index  = pPlayOptions->STCIndex + pPlayOptions->STCEngine*3;

	/* Reset table entry */
	pHandle->demux_output_resources.entry[cnt].handle = NULL;
	pHandle->demux_output_resources.entry[cnt].free_protected = FALSE;
	pHandle->demux_output_resources.entry[cnt].free_unprotected = FALSE;

  // then present the RMFPDemuxResourcesProfile to the application if the callback was defined
	if (pHandle->profile.rmfp_release_demux_output_resources_callback) {
		status = pHandle->profile.rmfp_release_demux_output_resources_callback(pHandle->profile.callback_context, &rmfp_resources_profile);
		if (status != RM_OK) {
			RMNOTIFY((NULL, status, "The application failed to release the resources\n"));
			return status;
		}
	}

	return status;
}

static RMstatus rmfp_apply_demux_output_profile(struct RMFPHandle *pHandle, struct RMLibPlayDemuxOutputSource *pDemuxOutputSource, struct RMLibPlayDemuxOutputProfile *pDemuxOutputProfile)
{
	RMstatus status = RM_OK;

	RMDBGLOG((LOCALDBG, "rmfp_apply_demux_output_profile\n"));

	ASSERT_NULL_POINTER(pHandle);
	ASSERT_NULL_POINTER(pDemuxOutputSource);
	ASSERT_NULL_POINTER(pDemuxOutputProfile);

	return status;
}

static RMstatus rmfp_apply_demux_output_options(struct RMFPHandle *pHandle, struct RMLibPlayDemuxOutputSource *pDemuxOutputSource)
{
	RMstatus status = RM_OK;
	struct RUA *pRUA = NULL;
	struct RMFPDemuxOptions *pDemuxOptions = NULL;

	RMDBGLOG((LOCALDBG, "rmfp_apply_demux_output_options\n"));

	ASSERT_NULL_POINTER(pHandle);
	ASSERT_NULL_POINTER(pDemuxOutputSource);

	pRUA = pHandle->profile.pRUA;
	pDemuxOptions = &(pHandle->demux_options);

	return status;
}
