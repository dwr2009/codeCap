#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <assert.h>
#include <dbus/dbus.h>
#include <arpa/inet.h>

#ifndef	ALLOW_OS_CODE
#define	ALLOW_OS_CODE
#endif	//ALLOW_OS_CODE

// rmoutput includes (RUA implementation)
#include <rmoutput/rua/include/output_rua.h>
#include <rmoutput/debugger/include/rmoutput_debugger.h>

// rmfp includes
#include "rmfp.h"
#include <rmfontrender/include/rmfontrender.h>
#include <rmlibhttp/include/rmlibhttp.h>
#include <rmlibcurl/include/rmlibcurl.h>
#include <rmdtcpapi/include/rmdtcpapi.h>
#include <rmriff/include/rmriff.h>
#include <rmlibcw/include/rmthreads.h>

/*
 * Internal application functions
 */
#include "test_rmfp.h"
#include "get_key.h"
#include "rmmmimplementation.h"
#include "parse_command_line.h"
#include "callbacks.h"
#include "resources.h"
#include "surface.h"

#include <BaseTypeDef.h>
#include "MediaPlayerApp.h"
#include <signal.h>
#include "LinuxSignalHandlerEx.h"
#include <BaseErrDef.h>
#include <SignalInfo.h>

static SharedPtr <CMediaPlayerApp> g_MediaPlayerApp_sp;

int main(int argc, char * argv[])
{
	INT_t iRet;

	do
	{
		g_MediaPlayerApp_sp = SharedPtr <CMediaPlayerApp> (new CMediaPlayerApp(argc, argv));
		if(NULL == g_MediaPlayerApp_sp.get())
		{			
			break;
		}

		g_MediaPlayerApp_sp->m_this_wp = g_MediaPlayerApp_sp;
		iRet = g_MediaPlayerApp_sp->InitInstance();
		if(ERROR_SUCCESS != iRet)
		{			
			PRINT_BFILE_LINENO_IRET_STR;
			break;
		}

		iRet = g_MediaPlayerApp_sp->Run();
		if(ERROR_SUCCESS != iRet)
		{
			PRINT_BFILE_LINENO_IRET_STR;
			break;
		}
	}while(FALSE);

	if(g_MediaPlayerApp_sp.isValid())
	{
		iRet = g_MediaPlayerApp_sp->ExitInstance();
		if(ERROR_SUCCESS != iRet)
		{
			PRINT_BFILE_LINENO_IRET_STR;
		}
	}

	g_MediaPlayerApp_sp.Release();
	
	return 0;
}

