/*****************************************
 Copyright 2001-2007
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   rmfp_resources_ccfifo.c
  @brief


  @author Sebastian Frias Feltrer
  @date   2007-11-20
*/


#include "rmfp_internal.h"

#define LOCALDBG DISABLE

struct RMFPCCFIFO {
	RMuint32 unprotected_memory_address;
	RMuint32 unprotected_memory_size;
	RMbool free_unprotected;

	RMuint32 DRAMIndex;
	RMuint32 STCIndex;
	RMuint32 ModuleIndex;

	RMuint32 ModuleID;
};

struct RMFPCCFIFOSource {
	struct RMFPCCFIFO In;
	struct RMFPCCFIFO Out;

	RMuint32 VideoDecoderModuleID;
};

// NOTE: there is no DCC lib for the CCFIFO so we emulate the behaviour here

#define WAIT_COMMAND_TIMEOUT_US (200 * 1000)
#define RETRY_THRESHOLD (2)

static RMstatus rmfp_set_pending_prop(struct RMFPHandle *pHandle, RMuint32 ModuleID, RMuint32 PropertyID, void *pValue, RMuint32 ValueSize, RMascii waiting_char)
{
	struct RUAEvent evt;
	RMstatus err;
	RMuint32 n;
	RMuint32 MixerModuleID = 0;
	enum DCCRoute dcc_route;
	struct DCC *pDCC = NULL;
	struct RUA *pRUA = NULL;

	pRUA = pHandle->profile.pRUA;
	pDCC = pHandle->profile.pDCC;

	err = rmfp_internal_get_route(pHandle, &dcc_route);
	if (err != RM_OK)
		return err;

	err = DCCGetMixerModuleID(pDCC, dcc_route, &MixerModuleID);
	if (err != RM_OK) {
		RMDBGLOG((ENABLE, "Cannot get MixerModuleID from route (%s)\n", RMstatusToString(err)));
		return err;
	}

	evt.Mask = EMHWLIB_DISPLAY_EVENT_ID(MixerModuleID);
	if (evt.Mask > 0) {
		evt.ModuleID = EMHWLIB_MODULE(DisplayBlock, 0);
		err = RUAResetEvent(pRUA, &evt);
		if (RMFAILED(err)) {
			RMNOTIFY((NULL, err, "Can not reset display event\n"));
			return err;
		}
	}

	//RMLOGFL((ENABLE, "Jiffies=%lu,ModuleID=0x%08x,PropertyID=%d\n", times(NULL), ModuleID, PropertyID));	

	n=0;
	err = RUASetProperty(pRUA, ModuleID, PropertyID, pValue, ValueSize, 0);
	if(RMFPCloseCaptionMode_ShowInOSD == pHandle->video_options.CloseCaptionMode && 
		EMHWLIB_MODULE(CCFifo, 1) == ModuleID && 
		(RMCCFifoPropertyID_Flush == PropertyID || RMCCFifoPropertyID_Clear == PropertyID))	
	{
		//CCFifo OUT
		usleep(0);
		err = RM_OK;
	}
	else
	{
		while (err == RM_PENDING) {
			RMuint32 index;

			/* RMDBGLOG((LOCALDBG, "Property %ld on ModuleID 0x%08lX still pending, trying again...\n", PropertyID, ModuleID)); */
			RMDBGPRINT((LOCALDBG, "%c", waiting_char));

			err = RuaWaitFor_DispBlk_DispEvt_ThrdSync(pRUA, &evt, 1, WAIT_COMMAND_TIMEOUT_US, &index);
			if (RMFAILED(err) && err != RM_PENDING) {
				RMNOTIFY((NULL, err, "Wait for display update event completion failed, ModuleID 0x%08lX\n", ModuleID));
				return err;
			}

			if (n++ > RETRY_THRESHOLD) {
				RMNOTIFY((NULL, RM_TIMEOUT, "Retry count overrun\n"));
				break;
			}
			err = RUASetProperty(pRUA, ModuleID, PropertyID, pValue, ValueSize, 0);
		}
	}

	//RMLOGFL((ENABLE, "Jiffies=%lu,ModuleID=0x%08x,PropertyID=%d\n", times(NULL), ModuleID, PropertyID));	

	if (RMFAILED(err)) {
		RMNOTIFY((NULL, err, "Can not set Property %ld on ModuleID 0x%08lX\n", PropertyID, ModuleID));
	}
	
	return err;
}

static RMstatus rmfp_print_rmlibplay_ccfifo_profile(struct RMLibPlayCCFIFOProfile *pCCFIFOProfile);

static RMstatus rmfp_open_ccfifo(struct RMFPHandle *pHandle, RMuint32 CCFIFOModuleIndex, struct RMLibPlayCCFIFOProfile *pCCFIFOProfile, struct RMFPCCFIFO *pRMFPCCFIFO);

static RMstatus rmfp_clear_ccfifo(struct RMFPHandle *pHandle, struct RMFPCCFIFO *pRMFPCCFIFO);

static RMstatus rmfp_close_ccfifo(struct RMFPHandle *pHandle, struct RMFPCCFIFO *pRMFPCCFIFO);


RMstatus rmfp_internal_get_ccfifo_handler(void *pContext,
					  struct RMLibPlayCCFIFOSource *pCCFIFOSource,
					  struct RMLibPlayCCFIFOProfile *pCCFIFOProfile)
{
	struct RMFPHandle *pHandle = NULL;
	struct RMFPCCFIFOSource *pRMFPCCFIFOSource = NULL;

	struct RMFPVideoOptions *pVideoOptions = NULL;
	struct DCC *pDCC = NULL;
	struct RUA *pRUA = NULL;

	RMuint32 MixerModuleID = 0;
	RMuint32 CCFIFOModuleIDIn  = 0;
	RMuint32 CCFIFOModuleIDOut = 0;
	enum DCCRoute dcc_route;

	RMstatus status;



	RMDBGLOG((LOCALDBG, "rmfp_internal_get_ccfifo_handler\n"));

	ASSERT_NULL_POINTER(pContext);
	ASSERT_NULL_POINTER(pCCFIFOSource);
	ASSERT_NULL_POINTER(pCCFIFOProfile);


	pHandle = (struct RMFPHandle *)pContext;
	pRUA = pHandle->profile.pRUA;
	pDCC = pHandle->profile.pDCC;
	pVideoOptions = &(pHandle->video_options);



	pRMFPCCFIFOSource = (struct RMFPCCFIFOSource *)RMMalloc(sizeof(struct RMFPCCFIFOSource));
	if (!pRMFPCCFIFOSource) {
		RMNOTIFY((NULL, RM_FATALOUTOFMEMORY, "Out of memory\n"));
		return RM_FATALOUTOFMEMORY;
	}

	RMMemset((void *)pRMFPCCFIFOSource, 0, sizeof(struct RMFPCCFIFOSource));

	//TODO: we're using index 0 and 1 here, maybe we should use some parameter

	RMDBGLOG((LOCALDBG, "open first CC FIFO\n"));
	status = rmfp_open_ccfifo(pHandle, 0, pCCFIFOProfile, &(pRMFPCCFIFOSource->In));
	if (status != RM_OK) {
		RMNOTIFY((NULL, status, "Cannot open CC FIFO (In)\n"));
		goto exit_with_error;
	}

	CCFIFOModuleIDIn = pRMFPCCFIFOSource->In.ModuleID;


	{
		struct CCFifo_AllowedTypes_type allowed_types;

		allowed_types.Allow608 = pCCFIFOProfile->EnableEIA608;
		allowed_types.Allow708 = pCCFIFOProfile->EnableEIA708;

		status = RUASetProperty(pRUA, CCFIFOModuleIDIn, RMCCFifoPropertyID_AllowedTypes, &(allowed_types), sizeof(allowed_types), 0);
		if (status != RM_OK) {
			RMNOTIFY((NULL, status, "Cannot set CCFIFO allowed types\n"));
			goto exit_with_error;
		}
	}



	RMDBGLOG((LOCALDBG, "open second CC FIFO\n"));
	status = rmfp_open_ccfifo(pHandle, 1, pCCFIFOProfile, &(pRMFPCCFIFOSource->Out));
	if (status != RM_OK) {
		RMNOTIFY((NULL, status, "Cannot open CC FIFO (Out)\n"));
		goto exit_with_error;
	}

	CCFIFOModuleIDOut = pRMFPCCFIFOSource->Out.ModuleID;


	/* Get route from application */
	status = rmfp_internal_get_route(pHandle, &dcc_route);
	if (status != RM_OK)
		goto exit_with_error;
	
	status = DCCGetMixerModuleID(pDCC, dcc_route, &MixerModuleID);
	if (status != RM_OK) {
		RMDBGLOG((ENABLE, "Cannot get MixerModuleID from route (%s)\n", RMstatusToString(status)));
		goto exit_with_error;
	}

	RMDBGLOG((LOCALDBG, "CCFIFO ModuleID IN: 0x%lx OUT: 0x%lx MixerModuleID 0x%lx VideoDecoderModuleID 0x%lx\n",
		  CCFIFOModuleIDIn,
		  CCFIFOModuleIDOut,
		  MixerModuleID,
		  pCCFIFOProfile->VideoDecoderModuleID));

	RMDBGLOG((LOCALDBG, "connect CC FIFO 0x%lx to mixer 0x%lx", CCFIFOModuleIDOut, MixerModuleID));
	status = rmfp_set_pending_prop(pHandle, MixerModuleID, RMGenericPropertyID_CCFifo, &CCFIFOModuleIDOut, sizeof(CCFIFOModuleIDOut), '.');
	if (status != RM_OK) {
		RMNOTIFY((NULL, status, "Cannot connect CC FIFO to mixer\n"));
		goto exit_with_error;
	}
	
	status = rmfp_set_pending_prop(pHandle, MixerModuleID, RMGenericPropertyID_Validate, NULL, 0, '.');
	if (status != RM_OK) {
		RMNOTIFY((NULL, status, "Cannot validate mixer settings\n"));
		goto exit_with_error;
	}

	RMDBGPRINT((LOCALDBG, "\n"));

	RMDBGLOG((LOCALDBG, "connect CC FIFO 0x%lx to video decoder 0x%lx\n", CCFIFOModuleIDIn, pCCFIFOProfile->VideoDecoderModuleID));

	status = RUASetProperty(pRUA, pCCFIFOProfile->VideoDecoderModuleID, RMGenericPropertyID_CCFifo, &CCFIFOModuleIDIn, sizeof(CCFIFOModuleIDIn), 0);
	if (status != RM_OK) {
		RMNOTIFY((NULL, status, "Cannot connect CC FIFO to video decoder\n"));
		goto exit_with_error;
	}

	pRMFPCCFIFOSource->VideoDecoderModuleID = pCCFIFOProfile->VideoDecoderModuleID;

	pCCFIFOSource->source = (void *)pRMFPCCFIFOSource;

	return RM_OK;

exit_with_error:
	if (CCFIFOModuleIDIn)
		status = rmfp_close_ccfifo(pHandle, &(pRMFPCCFIFOSource->In));

	if (CCFIFOModuleIDOut)
		status = rmfp_close_ccfifo(pHandle, &(pRMFPCCFIFOSource->Out));

	if (pRMFPCCFIFOSource)
		RMFree(pRMFPCCFIFOSource);

	return status;

}


RMstatus rmfp_internal_refresh_ccfifo_handler(void *pContext, struct RMLibPlayCCFIFOSource *pCCFIFOSource)
{
	struct RMFPHandle *pHandle = NULL;
	struct RMFPCCFIFOSource *pRMFPCCFIFOSource = NULL;

	struct CCFifo_CCEntry_type CloseCaptionEntry;

	struct RMFPVideoOptions *pVideoOptions = NULL;
	struct RUA *pRUA = NULL;

	RMstatus status = RM_OK;


	RMDBGLOG((DISABLE, "rmfp_internal_refresh_ccfifo_handler\n"));


	ASSERT_NULL_POINTER(pContext);
	ASSERT_NULL_POINTER(pCCFIFOSource);


	pHandle = (struct RMFPHandle *)pContext;
	pRUA = pHandle->profile.pRUA;
	pVideoOptions = &(pHandle->video_options);
	pRMFPCCFIFOSource = (struct RMFPCCFIFOSource *)pCCFIFOSource->source;


	ASSERT_NULL_POINTER(pRMFPCCFIFOSource);


	while (1) {

		status = RUAGetProperty(pRUA, pRMFPCCFIFOSource->In.ModuleID, RMCCFifoPropertyID_CCEntry, &CloseCaptionEntry, sizeof(CloseCaptionEntry));

		if (status != RM_OK)
			break;

		switch (pVideoOptions->CloseCaptionMode) {
		case RMFPCloseCaptionMode_Disabled:
			return RM_OK;
		case RMFPCloseCaptionMode_SendToTV:

			status = RUASetProperty(pRUA, pRMFPCCFIFOSource->Out.ModuleID, RMCCFifoPropertyID_CCEntry, &CloseCaptionEntry, sizeof(CloseCaptionEntry), 0);

			if (status != RM_OK) {

				RMNOTIFY((NULL, status, "Failed to pass through CC entry!\n"));

				if (status == RM_PENDING) {
					// probably a STC discontinuity, flush old CC data

					status = rmfp_clear_ccfifo(pHandle, &(pRMFPCCFIFOSource->Out));
					if (status != RM_OK)
						RMNOTIFY((NULL, status, "Cannot clear CC FIFO\n"));
				}
			}

			break;

		case RMFPCloseCaptionMode_ShowInOSD:

			// send the entry to RMFP's Soft CC render

			status = rmfp_internal_process_close_caption_entry(pHandle, &CloseCaptionEntry);
			if (status != RM_OK)
				RMNOTIFY((NULL, status, "Couldn't process entry\n"));

			break;

		case RMFPCloseCaptionMode_UseCallback:

			// send the entry to the application

			if (pHandle->profile.rmfp_ccfifo_entry_callback) {
				status = pHandle->profile.rmfp_ccfifo_entry_callback(pHandle->profile.callback_context, &CloseCaptionEntry);
				if (status != RM_OK) {
					RMNOTIFY((NULL, status, "Failed to signal new Close Caption entry to the application\n"));
					return status;
				}
			}

			break;
		};

	}

	return status;
}

RMstatus rmfp_internal_clear_ccfifo_handler(void *pContext, struct RMLibPlayCCFIFOSource *pCCFIFOSource)
{

	struct RMFPHandle *pHandle = NULL;
	struct RMFPCCFIFOSource *pRMFPCCFIFOSource = NULL;

	RMstatus ReturnStatus = RM_OK;
	RMstatus status;

	RMDBGLOG((LOCALDBG, "rmfp_internal_clear_ccfifo_handler()\n"));

	ASSERT_NULL_POINTER(pContext);
	ASSERT_NULL_POINTER(pCCFIFOSource);

	pHandle = (struct RMFPHandle *)pContext;

	pRMFPCCFIFOSource = (struct RMFPCCFIFOSource *)pCCFIFOSource->source;

	ASSERT_NULL_POINTER(pRMFPCCFIFOSource);

	if (pRMFPCCFIFOSource->In.ModuleID) {

		status = rmfp_clear_ccfifo(pHandle, &(pRMFPCCFIFOSource->In));
		if (status != RM_OK) {
			RMNOTIFY((NULL, status, "Cannot clear CC FIFO\n"));
			ReturnStatus = status;
		}
	}

	if (pRMFPCCFIFOSource->Out.ModuleID) {

		status = rmfp_clear_ccfifo(pHandle, &(pRMFPCCFIFOSource->Out));
		if (status != RM_OK) {
			RMNOTIFY((NULL, status, "Cannot clear CC FIFO\n"));
			ReturnStatus = status;
		}
	}

	return ReturnStatus;
}


RMstatus rmfp_internal_release_ccfifo_handler(void *pContext, struct RMLibPlayCCFIFOSource *pCCFIFOSource)
{
	struct RMFPHandle *pHandle = NULL;
	struct RMFPCCFIFOSource *pRMFPCCFIFOSource = NULL;

	RMstatus ReturnStatus = RM_OK;
	RMstatus status;


	RMDBGLOG((LOCALDBG, "rmfp_internal_release_ccfifo_handler()\n"));

	ASSERT_NULL_POINTER(pContext);
	ASSERT_NULL_POINTER(pCCFIFOSource);

	pHandle = (struct RMFPHandle *)pContext;
	pRMFPCCFIFOSource = (struct RMFPCCFIFOSource *)pCCFIFOSource->source;


	status = rmfp_internal_clear_ccfifo_handler(pContext, pCCFIFOSource);
	if (status != RM_OK)
		RMNOTIFY((NULL, status, "Cannot clear CC FIFO\n"));

// shouldn't we need to disconnect it from the video decoder first?

	if (pRMFPCCFIFOSource) {
		if (pRMFPCCFIFOSource && pRMFPCCFIFOSource->In.ModuleID) {

			RMDBGLOG((LOCALDBG, "Closing CC FIFO 0x%lx:\n", pRMFPCCFIFOSource->In.ModuleID));

			status = rmfp_close_ccfifo(pHandle, &(pRMFPCCFIFOSource->In));
			if (status != RM_OK) {
				RMNOTIFY((NULL, status, "Failed to close CC FIFO\n"));
				ReturnStatus = status;
			}
		}

		if (pRMFPCCFIFOSource && pRMFPCCFIFOSource->Out.ModuleID) {

			RMDBGLOG((LOCALDBG, "Closing CC FIFO 0x%lx:\n", pRMFPCCFIFOSource->Out.ModuleID));

			status = rmfp_close_ccfifo(pHandle, &(pRMFPCCFIFOSource->Out));
			if (status != RM_OK) {
				RMNOTIFY((NULL, status, "Failed to close CC FIFO\n"));
				ReturnStatus = status;
			}
		}

		RMFree(pRMFPCCFIFOSource);
	}

	return ReturnStatus;
}


static RMstatus rmfp_open_ccfifo(struct RMFPHandle *pHandle, RMuint32 CCFIFOModuleIndex, struct RMLibPlayCCFIFOProfile *pCCFIFOProfile, struct RMFPCCFIFO *pRMFPCCFIFO)
{
	struct RMFPCCFIFOResourcesProfile rmfp_ccfifo_resources_profile = { 0, };

	struct RMFPPlayOptions *pPlayOptions = NULL;

	struct CCFifo_Open_type cc_profile = { 0, };
	RMuint32 EntryCount = 0;
	RMuint32 FIFOSize = 0;
	RMuint32 STCModuleID = 0;
	RMuint32 CCFIFOModuleID = 0;

	struct RUA *pRUA = NULL;

	RMstatus status;


	RMDBGLOG((LOCALDBG, "rmfp_open_ccfifo\n"));

	ASSERT_NULL_POINTER(pHandle);
	ASSERT_NULL_POINTER(pCCFIFOProfile);
	ASSERT_NULL_POINTER(pRMFPCCFIFO);


	pRUA = pHandle->profile.pRUA;

	pPlayOptions = &(pHandle->playback_options);


	RMMemset((void *)pRMFPCCFIFO, 0, sizeof(struct RMFPCCFIFO));

	rmfp_print_rmlibplay_ccfifo_profile(pCCFIFOProfile);


	CCFIFOModuleID = EMHWLIB_MODULE(CCFifo, CCFIFOModuleIndex);
	EntryCount     = pCCFIFOProfile->EntryCount;
	FIFOSize       = 0;


	status = RUAExchangeProperty(pRUA, CCFIFOModuleID, RMCCFifoPropertyID_DRAMSize, &EntryCount, sizeof(EntryCount), &FIFOSize, sizeof(FIFOSize));
	if (status != RM_OK) {
		RMNOTIFY((NULL, status, "Cannot exchange property\n"));
		return status;
	}

	rmfp_ccfifo_resources_profile.Version                    = GET_VERSION_FROM_MAGIC(RMFP_CCFIFO_RESOURCES_PROFILE_VERSION);

	rmfp_ccfifo_resources_profile.dram                       = pPlayOptions->DRAMIndex;

	rmfp_ccfifo_resources_profile.unprotected_memory_address = 0;
	rmfp_ccfifo_resources_profile.unprotected_memory_size    = FIFOSize;

	rmfp_ccfifo_resources_profile.fifo_index                 = CCFIFOModuleIndex;

	rmfp_ccfifo_resources_profile.STC_index                  = pPlayOptions->STCIndex + pPlayOptions->STCEngine*3;

	if (pHandle->profile.rmfp_ccfifo_resources_callback) {
		status = pHandle->profile.rmfp_ccfifo_resources_callback(pHandle->profile.callback_context, &rmfp_ccfifo_resources_profile);
		if (status != RM_OK) {
			RMNOTIFY((NULL, status, "Failed to get resources from application\n"));
			return status;
		}
	}


	CCFIFOModuleID = EMHWLIB_MODULE(CCFifo, rmfp_ccfifo_resources_profile.fifo_index);
	STCModuleID    = EMHWLIB_MODULE(STC, rmfp_ccfifo_resources_profile.STC_index);

	RMDBGPRINT((LOCALDBG, "\n\tModuleID                0x%lx\n", CCFIFOModuleID));
	RMDBGPRINT((LOCALDBG, "\tSTCModuleID             0x%lx\n", STCModuleID));

	if ((!rmfp_ccfifo_resources_profile.unprotected_memory_address) &&
	    (rmfp_ccfifo_resources_profile.unprotected_memory_size)) {
		pRMFPCCFIFO->unprotected_memory_address = DCCMalloc(pHandle->profile.pDCC,
								    rmfp_ccfifo_resources_profile.dram,
								    RUA_DRAM_UNCACHED,
								    rmfp_ccfifo_resources_profile.unprotected_memory_size);

		if (!pRMFPCCFIFO->unprotected_memory_address) {
			RMNOTIFY((NULL, RM_FATALOUTOFMEMORY, "Can't allocate %lu bytes in DRAM %lu\n",
				    rmfp_ccfifo_resources_profile.unprotected_memory_size,
				    rmfp_ccfifo_resources_profile.dram));
			return RM_FATALOUTOFMEMORY;
		}
		else
			RMDBGLOG((LOCALDBG, "allocated %lu bytes for unprotected memory\n", rmfp_ccfifo_resources_profile.unprotected_memory_size));

		pRMFPCCFIFO->free_unprotected = TRUE;
	}
	else {
		pRMFPCCFIFO->unprotected_memory_address = rmfp_ccfifo_resources_profile.unprotected_memory_address;
		pRMFPCCFIFO->free_unprotected = FALSE;
	}

	pRMFPCCFIFO->unprotected_memory_size = rmfp_ccfifo_resources_profile.unprotected_memory_size;

	RMDBGLOG((LOCALDBG, "UnProtected Memory: %lu bytes at %p\n",
		  pRMFPCCFIFO->unprotected_memory_size,
		  pRMFPCCFIFO->unprotected_memory_address));


	cc_profile.EntryCount      = EntryCount;
	cc_profile.STCModuleId     = STCModuleID;

	cc_profile.UncachedAddress = pRMFPCCFIFO->unprotected_memory_address;
	cc_profile.UncachedSize    = pRMFPCCFIFO->unprotected_memory_size;


	status = RUASetProperty(pRUA, CCFIFOModuleID, RMCCFifoPropertyID_Open, &cc_profile, sizeof(cc_profile), 0);
	if (status != RM_OK) {
		RMNOTIFY((NULL, status, "Cannot open CC FIFO\n"));
		return status;
	}


	pRMFPCCFIFO->ModuleID    = CCFIFOModuleID;
	pRMFPCCFIFO->DRAMIndex   = rmfp_ccfifo_resources_profile.dram;
	pRMFPCCFIFO->STCIndex    = rmfp_ccfifo_resources_profile.STC_index;
	pRMFPCCFIFO->ModuleIndex = rmfp_ccfifo_resources_profile.fifo_index;


	return RM_OK;
}

static RMstatus rmfp_clear_ccfifo(struct RMFPHandle *pHandle, struct RMFPCCFIFO *pRMFPCCFIFO)
{
	struct RUA *pRUA = NULL;
	struct DCC *pDCC = NULL;
	struct RUAEvent event;

	RMuint32 MixerModuleID = 0;
	RMuint32 CCFIFOModuleID = 0;
	RMbool Enable;
	RMbool Mute;
	RMbool FIFOEmpty;
	enum DCCRoute dcc_route;

	RMuint32 RetryCount = 0;
	RMstatus status;

	ASSERT_NULL_POINTER(pHandle);
	ASSERT_NULL_POINTER(pRMFPCCFIFO);

	pRUA = pHandle->profile.pRUA;
	pDCC = pHandle->profile.pDCC;
	CCFIFOModuleID = pRMFPCCFIFO->ModuleID;

	RMDBGLOG((LOCALDBG, "rmfp_clear_ccfifo(0x%lx)\n", CCFIFOModuleID));

	/* Get route from application */
	status = rmfp_internal_get_route(pHandle, &dcc_route);
	if (status != RM_OK)
		return status;
	
	status = DCCGetMixerModuleID(pDCC, dcc_route, &MixerModuleID);
	if (status != RM_OK) {
		RMDBGLOG((ENABLE, "Cannot get MixerModuleID from route (%s)\n", RMstatusToString(status)));
		return status;
	}

	event.ModuleID = EMHWLIB_MODULE(DisplayBlock, 0);
	event.Mask = EMHWLIB_DISPLAY_EVENT_ID(MixerModuleID);

	status = RUAResetEvent(pRUA, &event);
	if(RMFAILED(status))
	{
		RMLOGFL((ENABLE, "ResetEvt %s\n", RMstatusToString(status)));
	}

	RMDBGLOG((LOCALDBG, "Flushing and clearing CC FIFO ModuleID 0x%lx: ", CCFIFOModuleID));

#if 1
	Enable = FALSE;
	status = rmfp_set_pending_prop(pHandle, CCFIFOModuleID, RMCCFifoPropertyID_Enable, &Enable, sizeof(Enable), 'a');
	if (status != RM_OK)
		RMNOTIFY((NULL, status, "Cannot disable CC FIFO\n"));
#endif

	Mute = TRUE;
	status = rmfp_set_pending_prop(pHandle, CCFIFOModuleID, RMCCFifoPropertyID_Mute, &Mute, sizeof(Mute), 'b');
	if (status != RM_OK)
		RMNOTIFY((NULL, status, "Cannot mute CC FIFO\n"));

	status = rmfp_set_pending_prop(pHandle, CCFIFOModuleID, RMCCFifoPropertyID_Flush, NULL, 0, 'c');
	if (status != RM_OK)
		RMNOTIFY((NULL, status, "Cannot flush CC FIFO\n"));

#if 1
	status = rmfp_set_pending_prop(pHandle, CCFIFOModuleID, RMCCFifoPropertyID_Clear, NULL, 0, 'd');
	if (status != RM_OK)
		RMNOTIFY((NULL, status, "Cannot clear CC FIFO\n"));
#endif

	//RMLOGFL((ENABLE, "Jiffies=%lu,CCFIFOModuleID=%lu\n", times(NULL), CCFIFOModuleID));
	if(RMFPCloseCaptionMode_ShowInOSD == pHandle->video_options.CloseCaptionMode && 
		EMHWLIB_MODULE(CCFifo, 1) == CCFIFOModuleID)	//CCFifo OUT
	{
		status = RUAGetProperty(pRUA, CCFIFOModuleID, RMCCFifoPropertyID_FifoEmpty, &FIFOEmpty, sizeof(FIFOEmpty));
		if(RMSUCCEEDED(status))
		{
			if(FALSE == FIFOEmpty)
			{
				usleep(0);
			}
		}
		else	//err
		{
			RMLOGFL((ENABLE, "%s\n", RMstatusToString(status)));
		}
	}
	else	//CCFifo IN
	{
		RetryCount = 0;
		while(1) {
			status = RUAGetProperty(pRUA, CCFIFOModuleID, RMCCFifoPropertyID_FifoEmpty, &FIFOEmpty, sizeof(FIFOEmpty));
			if ((status == RM_OK) && (!FIFOEmpty)) {
				//RMLOGFL((ENABLE, "%s,FE=%d\n", RMstatusToString(status), FIFOEmpty));
				RMuint32 waitCmdTimeoutUs = (40*1000);
				status = RUAWaitForMultipleEvents(pRUA, &event, 1, waitCmdTimeoutUs, NULL);
				if(RMFAILED(status))
				{
					RMLOGFL((ENABLE, "%s\n", RMstatusToString(status)));
				}
				RMDBGPRINT((LOCALDBG, "e"));
			}
			else
				break;

			if (RetryCount++ > RETRY_THRESHOLD) {
				RMNOTIFY((NULL, RM_TIMEOUT, "Retry count overrun\n"));
				//RMLOGFL((ENABLE, "Jiffies=%lu\n", times(NULL)));
				break;
			}
		};
	}
	//RMLOGFL((ENABLE, "Jiffies=%lu,CCFIFOModuleID=%lu\n", times(NULL), CCFIFOModuleID));

#if 1
	Enable = TRUE;
	status = rmfp_set_pending_prop(pHandle, CCFIFOModuleID, RMCCFifoPropertyID_Enable, &Enable, sizeof(Enable), 'f');
	if (status != RM_OK)
		RMNOTIFY((NULL, status, "Cannot enable CC FIFO\n"));
#endif

	Mute = FALSE;
	status = rmfp_set_pending_prop(pHandle, CCFIFOModuleID, RMCCFifoPropertyID_Mute, &Mute, sizeof(Mute), 'g');
	if (status != RM_OK)
		RMNOTIFY((NULL, status, "Cannot unmute CC FIFO\n"));

	RMDBGPRINT((LOCALDBG, " done\n"));

	return RM_OK;
}

static RMstatus rmfp_close_ccfifo(struct RMFPHandle *pHandle, struct RMFPCCFIFO *pRMFPCCFIFO)
{
	struct RMFPCCFIFOResourcesProfile rmfp_ccfifo_resources_profile = { 0, };
	struct DCC *pDCC = NULL;
	struct RMFPPlayOptions *pPlayOptions = NULL;

	RMuint32 MixerModuleID = 0;
	enum DCCRoute dcc_route;

	RMstatus status = RM_OK;

	RMDBGLOG((LOCALDBG, "rmfp_close_ccfifo()\n"));

	ASSERT_NULL_POINTER(pHandle);
	ASSERT_NULL_POINTER(pRMFPCCFIFO);

	pDCC = pHandle->profile.pDCC;
	pPlayOptions = &(pHandle->playback_options);

	/* Get route from application */
	status = rmfp_internal_get_route(pHandle, &dcc_route);
	if (status != RM_OK)
		return status;
	
	status = DCCGetMixerModuleID(pDCC, dcc_route, &MixerModuleID);
	if (status != RM_OK) {
		RMDBGLOG((ENABLE, "Cannot get MixerModuleID from route (%s)\n", RMstatusToString(status)));
		return status;
	}

	status = rmfp_set_pending_prop(pHandle, pRMFPCCFIFO->ModuleID, RMCCFifoPropertyID_Close, NULL, 0, '.');
	RMDBGPRINT((LOCALDBG, "done\n"));
	if (status != RM_OK)
		RMNOTIFY((NULL, status, "Cannot close CC FIFO\n"));

	if (pRMFPCCFIFO->free_unprotected) {
		RMDBGLOG((LOCALDBG, "Free CC FIFO unprotected memory at %p\n", pRMFPCCFIFO->unprotected_memory_address));
		DCCFree(pDCC, pRMFPCCFIFO->unprotected_memory_address);
		pRMFPCCFIFO->unprotected_memory_address = 0;
		pRMFPCCFIFO->unprotected_memory_size = 0;
	}

	rmfp_ccfifo_resources_profile.Version                    = GET_VERSION_FROM_MAGIC(RMFP_CCFIFO_RESOURCES_PROFILE_VERSION);

	rmfp_ccfifo_resources_profile.dram                       = pRMFPCCFIFO->DRAMIndex;

	rmfp_ccfifo_resources_profile.unprotected_memory_address = pRMFPCCFIFO->unprotected_memory_address;
	rmfp_ccfifo_resources_profile.unprotected_memory_size    = pRMFPCCFIFO->unprotected_memory_size;

	rmfp_ccfifo_resources_profile.fifo_index                 = pRMFPCCFIFO->ModuleIndex;

	rmfp_ccfifo_resources_profile.STC_index                  = pPlayOptions->STCIndex + pPlayOptions->STCEngine*3;

	if (pHandle->profile.rmfp_ccfifo_resources_callback) {
		status = pHandle->profile.rmfp_release_ccfifo_resources_callback(pHandle->profile.callback_context, &rmfp_ccfifo_resources_profile);
		if (status != RM_OK) {
			RMNOTIFY((NULL, status, "Failed to get resources from application\n"));
			return status;
		}
	}

	return RM_OK;
}



static RMstatus rmfp_print_rmlibplay_ccfifo_profile(struct RMLibPlayCCFIFOProfile *pCCFIFOProfile)
{
	ASSERT_NULL_POINTER(pCCFIFOProfile);


	RMDBGPRINT((LOCALDBG, "CCFIFOProfile:\n"));
	RMDBGPRINT((LOCALDBG, "\tEntries                 %lu\n", pCCFIFOProfile->EntryCount));
	RMDBGPRINT((LOCALDBG, "\tVideoDecoderModuleID    0x%lx\n", pCCFIFOProfile->VideoDecoderModuleID));

	return RM_OK;

}
