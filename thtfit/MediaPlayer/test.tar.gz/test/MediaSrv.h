#ifndef	_MEDIA_SRV_H_
#define	_MEDIA_SRV_H_

#include <MsgThread.h>
#include <String.h>
#include "test_rmfp.h"
#include <dbus/dbus.h>
#include "DBusInterfaceDef.h"
#include "GenericTimer.h"
#include "MPGenericMsgId.h"
#include "Rtc.h"
#include <memory.h>
#include "CnkB85Lcm.h"
#include "MediaPlayerAppDef.h"
#include "Smp8xxxChipInfo.h"
#include "MediaFileInfoCache.h"
#include "MediaSrvInterface.h"
#include "TunerSrv.h"
#include <PlayCtrlCtx/include/PlayCtrlCtx.h>
#include "GraphicsScreen.h"
#include <GenericTimer.h>
#include <Mp7xxGlobalStatus.h>
#include <Api/MediaPlayerApi.h>

using namespace MediaPlayer;

#define	LED_CTRL_MCP23017_I2C_ADDR			0x48
#define	I2C_MODULE_INDEX_SOFTWARE			0
#define	I2C_MODULE_INDEX_HARDWARE			1
#define	I2C_MODULE_INDEX_INTERNAL			2

extern enum RMdebuglevel edid_dbg;
extern enum RMdebuglevel rmoutput_dbg;
extern enum RMdebuglevel hdmi_dbg;

#ifdef ENABLE_DTV
class IMediaSrvScanProgressListener
{
public:
	virtual ~IMediaSrvScanProgressListener(){};
	virtual INT_t NotifyScanProgress(UINT32_t PgmNum,UINT32_t Progress) = 0;
	virtual INT_t Tuner_StartScan() = 0;
	virtual INT_t Tuner_StopScan() = 0;
	virtual INT_t NotifyTuPlayerPropmtMsg(UINT32_t MsgTag) = 0;
};
#endif

class IMediaSrvEventListener
{
public:
	virtual ~IMediaSrvEventListener() {};
	virtual INT_t PlaybackStart() = 0;
	virtual INT_t PlaybackEos(LPCSTR pszFileName, UINT32_t PlaybackId, BOOL_t bIsCompletePlaybackEos) = 0;
	virtual INT_t PlayNextFile() = 0;
	virtual INT_t HdmiStereoscopic3DFmt_Changed() = 0;
	virtual INT_t On_VideoOutputModeIsSet() = 0;
#if 1/*added by lxj 2013-1-8*/
	virtual INT_t PlaybackReadyToPlay() = 0;
#endif
};

class CMediaSrv : public CMsgThread, public IMediaFileInfoCache, 	public CppBase::CGenericTimer, public CppBase::ITimerListener
{
public:
	typedef struct
	{
		INT_t LoopCount;
#if 1/*added by lxj 2013-1-8*/
		bool bPauseAfterBuffering;
#endif
	}PLAY_PARAMS, *P_PLAY_PARAMS;
	typedef enum
	{
		PLAY_SOURCE_UNKNOWN,
		PLAY_SOURCE_FILE,
		PLAY_SOURCE_TUNER_IN,
	}PLAY_SOURCE_TYPE, *P_PLAY_SOURCE_TYPE;
public:
	CMediaSrv();
	virtual ~CMediaSrv();
	//ThreadContext: OtherThread
	virtual INT_t InitInstance();	
	virtual INT_t ExitInstance();
	virtual INT_t StartThread();
	virtual INT_t StopThread();
	virtual INT_t setDataSource(LPCSTR pszDataSrcUrl);
	virtual INT_t Prepare();
	virtual INT_t Play(OUT UINT32_t * pPlaybackId = NULL, IN CMediaSrv::P_PLAY_PARAMS pPlayParams = NULL);
	virtual INT_t Stop(OUT UINT32_t * pPlaybackId = NULL, OUT CStackBufString * pStrUrl = NULL);
	virtual INT_t setEventListener(WeakPtr <IMediaSrvEventListener> MediaSrvEvtListener_wp);
#ifdef ENABLE_DTV
	virtual INT_t PlayTuner( OUT UINT32_t * pPlaybackId/* = NULL*/);
	virtual INT_t TunerScan();
	virtual INT_t SetChannelUp();
	virtual INT_t SetChannelDown();
	virtual INT_t ResetDuration();
	virtual INT_t GetTunerChannelStrength(OUT UINT32_t *pStrength);
	virtual INT_t TunerMode(IN INT32_t iStdMode);
	virtual INT_t GetTunerMode(OUT INT32_t *pStdMode);
	virtual INT_t  SetScanProgressListner(WeakPtr <IMediaSrvScanProgressListener> MediaScanProgressListener_wp);
	virtual INT_t  ReLoadProgramTable();
	virtual INT_t Get_EntryChannelInfo(IN INT32_t EntryId ,OUT INT32_t *pChannelNumber,OUT INT32_t *pSubChannelCount,OUT CStackBufString &StrProgramPids);
	virtual INT_t GetFirstChNumber(OUT UINT32_t *pOutMajor,OUT UINT32_t *pOutMinor);
	virtual INT_t setTunerChannelMode(INT32_t iTunerChMode);
	virtual INT_t getTunerChannelMode(INT32_t *pOChannelMode);
#endif
	INT_t setVideoPosition(INT32_t x, INT32_t y, INT32_t Width, INT32_t Height,
		OUT struct EMhwlibDisplayWindow * pDispOutputWindowToUpdate = NULL);
	INT_t setOsdPosition(INT32_t x, INT32_t y, INT32_t Width, INT32_t Height,
		OUT struct EMhwlibDisplayWindow * pDispOutputWindowToUpdate = NULL);
	INT_t setVideoPositionAsync(INT32_t x, INT32_t y, INT32_t Width, INT32_t Height);
	INT_t setVideoInputWindowSize(CONST INT32_t inWinX, CONST INT32_t inWinY, CONST INT32_t inWinW, CONST INT32_t inWinH);
	INT_t ChangeVolume(INT32_t VolumePercentToChange, INT32_t * pNewVolumePercent, BOOL_t * pbVolChanged = NULL);
	INT_t ChangeVidOutMode(VIDEO_OUTPUT_MODE eVoMode, VIDEO_OUTPUT_MODE * peNewVoMode = NULL, 
		VIDEO_OUTPUT_MODE * peOldVoMode = NULL);
	INT_t ChangeVidOutModeAsync(VIDEO_OUTPUT_MODE eVoMode, VIDEO_OUTPUT_MODE * peNewVoMode = NULL, 
		VIDEO_OUTPUT_MODE * peOldVoMode = NULL);
	RMbool RMKeyAvailable(INT_t TimeoutUs);
	RMascii RMGetKey();
	INT_t setHwRtcTime(P_SET_TIME_IN_PARAM pSetTimeInParam);
	INT_t setGpioLedStatus(CONST UINT32_t GpioLedStatusToSet, OUT UINT32_t & ActualLedStatus);
	INT_t DisplayOnLedScreen(LPCSTR strContentToDisp, CONST INT_t StartPosToDisp);
	INT_t DispOnLedScrAsync(LPCSTR strContentToDisp, CONST INT_t StartPosToDisp);
	INT_t getMonitorInfo(OUT CString & strMonitorType);
	INT_t setPlayMode(MediaPlayer::PlayMode ePlayMode);
	INT_t getPlayMode(MediaPlayer::PlayMode & ePlayMode);
	INT_t setDisplayParam(DISP_PARAM_TYPE eDispParamType, INT_t iValue);
	INT_t getDisplayParam(DISP_PARAM_TYPE eDispParamType, OUT INT_t & iValue);
	INT_t getDisplayPosition(RUA_DISPLAY_TYPE eRuaDispType, OUT int & x, OUT int & y, OUT int & w, OUT int & h);
	INT_t OutputDisplayUpdate();
	virtual INT_t FindStreamInfoInCache(CONST IMediaFileInfoCache::P_FIND_STREAM_INFO_IN_PARAM pFindInParam, 
		IMediaFileInfoCache::P_FIND_STREAM_INFO_OUT_PARAM pFindOutParam);
	virtual INT_t AddMediaInfoCache(const RMascii * pszFileName, CONST struct RMFPStreamType * pRmfpStreamType, 
		CONST struct RMFPStreamInfo * pRmfpStreamInfo);
	INT_t setMonitorType(MONITOR_MANUFACTURER_ID eMonitorManufacturerId);
	INT_t getMonitorType(OUT MONITOR_MANUFACTURER_ID & eMonitorManufacturerId);
	INT_t setPlaySpeedCtrlAsync(int Speed);
	INT_t getPlaySpeedCtrl(OUT int & Speed);
	INT_t setOutputSpdifMode(IN const INT32_t OutputSpdifMode);
	INT_t getOutputSpdifMode(INT32_t *pOutSpdifMode);
	INT_t setVideoDispAspectRatio(DISPLAY_ASPECT_RATIO eVideoDispAspectRato, UINT32_t OptFlag);
#if 1/*added by lxj 2012-9-28*/
	INT_t getVideoDispAspectRatio(DISPLAY_ASPECT_RATIO &eVideoDispAspectRato);
#endif
	INT_t setHdmiAudioOutput(BOOL_t bEnable);
	INT_t setStereoscopic3DFormat(struct EMhwlibStereoscopic3D * pStereoscopic3D = NULL);
	VOID DelayedSet_VcrDefaultSurface(OUT BOOL_t & bNeedUnregTimer);
	INT_t getCpuSerialNo(OUT CStackBufString & strCpuSerialNo);
	INT_t getOsdImgSurfaceInfo(SharedPtr <CImageSurface> & ImgSurface_sp);
	virtual VOID OnTimer(UINT_t TimerId);
	INT_t setHdmi3DTvMode(CONST HDMI_3D_TV_MODE eHdmi3DTvMode);
	INT_t setAnalogAudioMute(CONST BOOL_t bMute);
	INT_t setHdmiCecCtrl(CONST HDMI_CEC_CTRL_CMD eHdmiCecCtrlCmd);
	INT_t setShowClosedCaption(CONST ClosedCaption_SELECTION eCcSel);
	INT_t getShowClosedCaption(OUT ClosedCaption_SELECTION &eCcSel);
	INT_t setPlayPrebufMax(CONST UINT32_t prebufMaxInBytes);
#if 1 /*------Add by xuweiwei 2014-2-18------*/
	INT_t setVideoRotation(IN const INT32_t VideoRotationMode);
	INT_t getVideoRotation(INT32_t * pVideoRotationMode);
#endif

#if 1 /*Add by xuweiwei 2014-3-17 */
    INT_t setEnableAudio6Ch(BOOL_t iEnAudio6ChFlag);
    INT_t getEnableAudio6Ch(BOOL_t &oEnAudio6Chflg);
#endif

#if 0/*added by lxj 2013-1-15*/
	INT_t getVideoPosition(INT32_t *x, INT32_t *y, INT32_t *Width, INT32_t *Height);
#endif
protected:
	RMstatus InitDisplayContext();
	virtual INT_t RmfpInit();
	INT_t RmfpUninit();
	//ThreadContext: ThisThread
	//local calls
	virtual PVOID ThreadLoop();
	virtual VOID ProcessMsg(SharedPtr<CMessageQueueItem> & TransactionMsg);
private:
	INT_t ClearAllMessage();
	INT_t On_setDataSource(SharedPtr<CGenericMsgData> & GenMsgData_sp);
	INT_t On_Prepare(SharedPtr<CGenericMsgData> & GenMsgData_sp);
	INT_t On_Play(SharedPtr<CGenericMsgData> & GenMsgData_sp, SharedPtr<CMessageQueueItem> & TransactionMsg);
	INT_t On_Stop(SharedPtr<CGenericMsgData> & GenMsgData_sp);
	INT_t onQuitPlay(SharedPtr<CMessageQueueItem> & TransactionMsg, SharedPtr<CGenericMsgData> & GenMsgData_sp);
	INT_t On_setPlayMode(SharedPtr<CMessageQueueItem> & TransactionMsg);
	INT_t On_getPlayMode(SharedPtr<CMessageQueueItem> & TransactionMsg);
	INT_t On_setVideoPosition(SharedPtr<CMessageQueueItem> & TransactionMsg);
	INT_t On_setVideoInputWindowSize(SharedPtr<CMessageQueueItem> & TransactionMsg);
	INT_t On_ChangeVidOutMode(SharedPtr<CMessageQueueItem> & TransactionMsg);
	INT_t On_setPlaySpeedCtrl(SharedPtr<CMessageQueueItem> & TransactionMsg);
	INT_t On_getPlaySpeedCtrl(SharedPtr<CMessageQueueItem> & TransactionMsg);
	INT_t On_DispOnLedScr(SharedPtr<CMessageQueueItem> & TransactionMsg);
	INT_t On_SetOutputSpdifMode(SharedPtr<CMessageQueueItem> & TransactionMsg);
	INT_t On_setShowClosedCaption(SharedPtr<CMessageQueueItem> & TransactionMsg);
	INT_t On_setVideoRotation(SharedPtr<CMessageQueueItem> & TransactionMsg);
#if 1 /*Add by xuweiwei 2014-3-17*/
	INT_t On_setEnableAudio6Ch(SharedPtr<CMessageQueueItem> & TransactionMsg);              
	INT_t On_getEnableAudio6Ch(SharedPtr<CMessageQueueItem> & TransactionMsg);
#endif


#ifdef ENABLE_DTV
	INT_t InitTunerPlayer();
	INT_t On_PlayTuner(SharedPtr<CGenericMsgData> & GenMsgData_sp, SharedPtr<CMessageQueueItem> & TransactionMsg);
	INT_t FindChannelIndexInScanedTable(LPCSTR pChStrIndex,RMbool *pFound);
	INT_t SetChannelInfoAndLockFreq();
	INT_t StartScanProgram();
	INT_t PsfPlayback();
	INT_t OpenTunerPlayer();
	INT_t On_TunerScan(SharedPtr<CGenericMsgData> & GenMsgData_sp, SharedPtr<CMessageQueueItem> & TransactionMsg);
	INT_t On_ResetDuration(SharedPtr<CGenericMsgData> & GenMsgData_sp, SharedPtr<CMessageQueueItem> & TransactionMsg);
	INT_t On_GetSignalStrength(SharedPtr<CGenericMsgData> & GenMsgData_sp,SharedPtr<CMessageQueueItem> & TransactionMsg);
	INT_t On_SetTunerStandardMode(SharedPtr<CGenericMsgData> & GenMsgData_sp,SharedPtr<CMessageQueueItem> & TransactionMsg);
	INT_t On_GetTunerStandardMode(SharedPtr<CGenericMsgData> & GenMsgData_sp,SharedPtr<CMessageQueueItem> & TransactionMsg);
	INT_t On_GetFirstChNum(SharedPtr<CGenericMsgData> & GenMsgData_sp,SharedPtr<CMessageQueueItem> & TransactionMsg);
	INT_t On_SetChannelUp(SharedPtr<CMessageQueueItem> & TransactionMsg);
	INT_t On_SetChannelDown(SharedPtr<CMessageQueueItem> & TransactionMsg);
	INT_t On_SetTunerChannelMode(SharedPtr<CGenericMsgData> & GenMsgData_sp,SharedPtr<CMessageQueueItem> & TransactionMsg);
	INT_t On_GetTunerChannelMode(SharedPtr<CGenericMsgData> & GenMsgData_sp,SharedPtr<CMessageQueueItem> & TransactionMsg);
	INT_t StopTunerPlayer();
	INT_t CloseDemux();
	INT_t ProcessEventForTuneProgram();
	INT_t ConfigPsfDemuxPara(struct rmfp_main_thread_context_type *pMainContext);
	static void CallBackScanProgress(UINT16_t *pRrogramNum,UINT16_t *pScanRrogress);
	void FN_cbScanProgress(UINT16_t *pRrogramNum,UINT16_t *pScanRrogress);
	INT_t On_ReLoadProgramTable(SharedPtr<CMessageQueueItem> & TransactionMsg);
	INT_t On_GetEntryChannelInfo(SharedPtr<CGenericMsgData> & GenMsgData_sp,SharedPtr<CMessageQueueItem> & TransactionMsg);
#endif
	INT_t ChangeVideoOutputMode(VIDEO_OUTPUT_MODE eVoMode, VIDEO_OUTPUT_MODE * peNewVoMode = NULL, 
		VIDEO_OUTPUT_MODE * peOldVoMode = NULL);
	INT_t EmitVidOutModeChangedEvent(VIDEO_OUTPUT_MODE eCurMode);
	INT_t setVideoOutputMode();
	INT_t setPlaySpeedCtrl(int iSpeed);
	INT_t getPlaySpeed(OUT int & iSpeed);
	//Callbacks called by rmfp
	static RMstatus Cb_getCommand(void* pContext, struct RMFPPlaybackCommand *pCommand, RMuint32 TimeOutInMicroSeconds);
	RMstatus getCommand(struct RMFPPlaybackCommand *pCommand, RMuint32 TimeOutInMicroSeconds);
	INT_t TranslateToRmfpCmd(SharedPtr<CMessageQueueItem> & TransactionMsg, struct RMFPPlaybackCommand *pCommand);
	INT_t TranslateToRmasciiKey(SharedPtr<CMessageQueueItem> & TransactionMsg, RMascii * pKey);
	static RMstatus Cb_notifyCommandStatus(void *pContext, struct RMFPCommandStatus *pStatus);
	RMstatus notifyCommandStatus(struct RMFPCommandStatus *pStatus);
	static RMstatus Cb_notify_playback_start(void *pContext);
	static RMstatus Cb_notify_playback_eos(void *pContext);
	static void Cb_DataIoTimeoutCallback(P_DATA_IO_CB_INFO pDataIoCbInfo, OUT P_DATA_IO_CB_ACTION pDataIoCbAction);
	void DataIoTimeoutCallback(P_DATA_IO_CB_INFO pDataIoCbInfo, OUT P_DATA_IO_CB_ACTION pDataIoCbAction);
#if 1/*added by lxj 2013-1-8*/
	static RMstatus Cb_notify_progress(void *pContext, struct RMFPProgress* pProgress, RMbool *pAbort);
	RMstatus NotifyPlaybackProgress(struct RMFPProgress* pProgress, RMbool *pAbort);
#endif
	RMstatus NotifyPlaybackStart();
	RMstatus NotifyPlaybackEos();
	INT_t SendEvt_PlaybackEos();
	INT_t SendEvt_PlayNextFile();
	RMstatus RMFPOptions_RestoreSet(struct RMFPOptions *pOption);
	VOID DBusConnWakeUp_ClearMsg();	
	INT_t ProcessDBusMsg(DBusMessage * pDBusMsg);
	INT_t ProcessDBusMsg_DBusDBusIfCall(DBusMessage * pDBusMsg);
	INT_t On_DBusIf_Call(DBusMessage * pDBusMsg);
	RMstatus getVolumeLevel(RMuint32 * pVolumeLevel);
	RMstatus setVolumeLevel(RMuint32 VolumeLevel);
	INT_t WakeupMainThread();
	RMstatus InitVcrScaler();
	INT_t applyMixerDispAspectRatio(DISPLAY_ASPECT_RATIO eDispAspectRatio);
	INT_t applyVideoDispAspectRatio(DISPLAY_ASPECT_RATIO eDispAspectRatio,
		struct EMhwlibStereoscopic3D * pStereoscopic3D = NULL, BOOL_t bForce = FALSE);
	PlayMode getCurPlayMode();
	INT_t setMruaOutputSpdifMode(INT_t iSnmpOutSpdifMode);
	INT_t setMruaVideoRotationMode(INT_t iSnmpVideoRotationMode);
#if 1  /*Add by xuweiwei 2014-3-17*/
	INT_t setEnAudio6Channel(BOOL_t iEnAudio6ChFlag);       
#endif
	INT_t createSecondOsd();
	INT_t secondOsd_ClearScr();
	INT_t releaseSecondOsd();
	INT_t bindSecondOsdToDispScaler(RMuint32 dispScalerModuleId);
public:
	WeakPtr <CMediaSrv> m_this_wp;
	BOOL_t m_bNotApplyDispOpt;
	BOOL_t m_bDisableVcrMixerSrc;
	VIDEO_OUTPUT_MODE m_eVoMode;
protected:
	CMp7xxGlobalStatus m_Mp7xxGlobalStatusData;
	BOOL_t m_bShouldExitThread;
	INT_t m_iPlayStatus;
	PLAY_SOURCE_TYPE m_ePlaySourceType;
	CString m_strDataSrcUrl;
	CMutex2 m_SharedDataMutex;
	CMutex2 m_mutexVideoAudioIoSet;
	SharedPtr<CMessageQueueItem> m_CurTransactionMsg_sp;
	CEventEx m_PlayStatChangedEvent;
	BOOL_t m_bPlaybackEosIsSent;
	//rmfp related data structure
	struct rmfp_main_thread_context_type m_RmfpMainContext;	
	struct RMFPProfile m_RmfpProfile;
	struct RMFPStreamType m_RmfpStreamType;
	struct RMFPOptions m_RmfpOptions;
	struct RMFPOptions m_RmfpOptionsBackup;
	struct rmoutput_display_options m_Display_opt;  // display options
	struct rmoutput_display_config m_Display_conf;  // display configuration
private:
	CGenericTimer m_GenericTimer;
	WeakPtr <IMediaSrvEventListener> m_MediaSrvEvtListener_wp;
#ifdef ENABLE_DTV
	WeakPtr <IMediaSrvScanProgressListener> m_MediaSrvScanProgressListener_wp;
#endif
	DBusConnection * m_pDBusConnMediaSrv;
	BOOL_t m_bQuitPlay;
	UINT32_t m_PlaybackId;
	struct I2C_Send_type m_oI2cSendParam;	
	struct I2C_Read_in_type m_oI2cReadInParam;
	struct I2C_Read_out_type m_oI2cReadOutParam;
	RMuint32 m_uiI2CModuleId;
	SharedPtr <CCnkB85Lcm> m_CnkB85LcmLedScr_sp;
	SharedPtr <CSmp8xxxChipInfo> m_Smp8xxxChipInfo_sp;
	SharedPtr <CMediaFileInfoCache> m_MediaFileInfoCache_sp;
	MONITOR_MANUFACTURER_ID m_eMonitorManufacturerId;
	P_PLAY_CTRL_CTX m_pPlayCtrlCtx;
	BOOL_t m_bNeedApplyAudioCfgToHdmi;
	struct llad * m_pLlad;
	struct gbus * m_pGbus;
	DISPLAY_ASPECT_RATIO m_VidDispAspectRatioAtNextPlay;
	DISPLAY_ASPECT_RATIO m_CurVidDispAspectRatio;
	BOOL_t m_bVidDispAspectRatioAtNextPlay_Valid;
	BOOL_t m_bCanProcessMsgInDataIoTimeoutCb;
	RMuint32 m_BlackSurfaceAddr;
	RMuint32 m_Cur_DigLostPixels;
	UINT64_t m_Prev_ChkDigLostPixel_TimeMs;
#ifdef ENABLE_DTV
	SharedPtr<CTunerSrv> m_TunerSrv_sp;
	BOOL_t m_bTunerOpenSucc;
#endif
	BOOL_t m_bShouldApplyHdmi3DInfoFrame;	//we want to re-send Hdmi3D info frame on the start of playback
	UINT_t m_idProcessTunerTaskTimer;
	HDMI_3D_TV_MODE m_eHdmi3DTvMode;
	struct EMhwlibStereoscopic3D m_CurRightStereoscopic3D;
	CString::STD_STRING_LIST m_strDataSrcUrlList;
	CString::STD_STRING_LIST::iterator m_currIterator;
	INT_t m_CntNodeInUrlList;
	BOOL_t m_bIsCompletePlaybackEos;
	ClosedCaption_SELECTION m_eShowClosedCaption;
	enum EMhwlibPictureOrientation m_Cur_PTOrientation;
	RMbool m_Cur_PTEnable;
};

MONITOR_MANUFACTURER_ID getMonitorManufacturerId(LPCSTR pszManufacturerName);

#endif	//_MEDIA_SRV_H_

