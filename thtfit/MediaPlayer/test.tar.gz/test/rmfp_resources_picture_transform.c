/*****************************************
 Copyright 2001-2009
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   rmfp_resources_ppf.c
  @brief


  @author Francesco Iacopino
  @date   2009-12-03
*/

#include "rmfp_internal.h"

#define  PictureTransform_VE_VD_To_ModuleIndex(e,d) (((d)&1)|(((e)==0)?0:2)) 

#define TIMEOUT_US (500 * 1000)

#define LOCALDBG DISABLE

static RMstatus rmfp_gt_send_video_command(struct RUA *pRUA, RMuint32 video_decoder, enum VideoDecoder_Command_type v_command);
static RMstatus rmfp_internal_get_decoder_id_from_indexes(struct RUA *pRUA, RMuint32 engine_index, RMuint32 decoder_index, RMuint32 *pDecoderModuleID);

static RMstatus rmfp_gt_send_video_command(struct RUA *pRUA, RMuint32 video_decoder, enum VideoDecoder_Command_type v_command)
{
	struct RUAEvent evt;
	enum PictureTransform_State_type state;
	RMuint32 index;
	RMstatus err;
	RMstatus cmdStatus;

	evt.ModuleID = video_decoder;
	evt.Mask = RUAEVENT_COMMANDCOMPLETION;

	err = RUAResetEvent(pRUA, &evt);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot reset video command completion event, %s\n", RMstatusToString(err)));
		return err;
	}

	err = RUAGetProperty(pRUA, video_decoder, RMPictureTransformPropertyID_State, &state, sizeof(state));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot get video state, %s\n", RMstatusToString(err)));
		return err;
	}

	err = RUASetProperty(pRUA, video_decoder, RMPictureTransformPropertyID_Command, &v_command, sizeof(v_command), 0);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot send video command, %s\n", RMstatusToString(err)));
		return err;
	}

	evt.ModuleID = video_decoder;
	evt.Mask = RUAEVENT_COMMANDCOMPLETION;
	err = RUAWaitForMultipleEvents(pRUA, &evt, 1, TIMEOUT_US, &index);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "wait for video command completion failed, %s\n", RMstatusToString(err)));
		return err;
	}

	err = RUAGetProperty(pRUA, video_decoder, RMPictureTransformPropertyID_State, &state, sizeof(state));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot get video state, %s\n", RMstatusToString(err)));
		return err;
	}

	err = RUAGetProperty(pRUA, video_decoder, RMPictureTransformPropertyID_CommandStatus, &cmdStatus, sizeof(cmdStatus));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot get command status, %s\n", RMstatusToString(err)));
		return err;
	}

	return cmdStatus;
}

static RMstatus rmfp_internal_get_decoder_id_from_indexes(struct RUA *pRUA, RMuint32 engine_index, RMuint32 decoder_index, RMuint32 *pDecoderModuleID){

	RMuint32 nb_mpeg_engines, nb_video_decoders;
	RMuint32 temp;
	RMstatus status;

	ASSERT_NULL_POINTER(pRUA);

	// Get number of video engines and video decoders
	temp = MpegEngine;
	status = RUAExchangeProperty(pRUA,
				     Enumerator,
				     RMEnumeratorPropertyID_CategoryIDToNumberOfInstances,
				     &temp,
				     sizeof(temp),
				     &nb_mpeg_engines,
				     sizeof(nb_mpeg_engines));

	if (status != RM_OK) {
		RMDBGLOG((ENABLE, "Cannot exchange property RMEnumeratorPropertyID_CategoryIDToNumberOfInstances (%s)\n", RMstatusToString(status)));
		return status;
	}
	else {
		if (engine_index < nb_mpeg_engines)
			RMDBGLOG((LOCALDBG, "Number of video engines: %lu\n", nb_mpeg_engines));
		else {
			RMDBGLOG((ENABLE, "video engine index out of range! (%lu > %lu)\n",
				  engine_index,
				  nb_mpeg_engines));
			return RM_PARAMETER_OUT_OF_RANGE;
		}
	}

	temp = PictureTransform;
	status = RUAExchangeProperty(pRUA,
				     Enumerator,
				     RMEnumeratorPropertyID_CategoryIDToNumberOfInstances,
				     &temp,
				     sizeof(temp),
				     &nb_video_decoders,
				     sizeof(nb_video_decoders));

	if (status != RM_OK) {
		RMDBGLOG((ENABLE, "Cannot exchange property RMEnumeratorPropertyID_CategoryIDToNumberOfInstances (%s)\n", RMstatusToString(status)));
		return status;
	}
	else {
		if (decoder_index < (nb_video_decoders / nb_mpeg_engines))
			RMDBGLOG((LOCALDBG, "Number of video decoders: %lu\n", nb_video_decoders));
		else {
			RMDBGLOG((ENABLE, "Video decoder index out of range! (%lu > %lu)\n",
				  decoder_index,
				  (nb_video_decoders / nb_mpeg_engines)));
			return RM_PARAMETER_OUT_OF_RANGE;
		}
	}

	if (pDecoderModuleID) {
		// !!Hack!! We assume there are an equal amount of decoders per engine; (nb_video_decoders / nb_mpeg_engines)
		// gives the number of decoders per engine.

		*pDecoderModuleID = EMHWLIB_MODULE(PictureTransform, PictureTransform_VE_VD_To_ModuleIndex(engine_index, decoder_index));
	}

	RMDBGLOG((LOCALDBG, "CHANGE from 0x%lx to 0x%lx\n",
		  EMHWLIB_MODULE(PictureTransform, engine_index * (nb_video_decoders / nb_mpeg_engines) + decoder_index),
		  *pDecoderModuleID ));

	return RM_OK;
}

RMstatus rmfp_gt_initialize_mpeg_engine(struct RMFPHandle *pHandle, struct MpegEngine_DecoderSharedMemory_type *shared, struct MpegEngine_SchedulerSharedMemory_type *schedmem, int dram_index)
{
    RMstatus status;
    RMuint32 mpeg_engine;

    mpeg_engine = EMHWLIB_MODULE( MpegEngine, pHandle->video_options.EngineIndex);

    shared->Size    = 1 << 20;
    shared->Address = RUAMalloc(pHandle->profile.pRUA, dram_index, RUA_DRAM_UNCACHED, shared->Size);
    if ( shared->Address == 0 ) {
		RMDBGLOG((ENABLE, "ERROR: cannot allocate shared %lu bytes in DRAM!\n", shared->Address ));
		return RM_FATALOUTOFMEMORY;
    }
    RMDBGLOG(( LOCALDBG, "Allocated MPEG engine shared memory: @0x%08lx, %lu bytes\n",
    		shared->Address,
    		shared->Size ));

    status = RUASetProperty(pHandle->profile.pRUA, mpeg_engine, RMMpegEnginePropertyID_DecoderSharedMemory,
                          shared, sizeof (*shared), 0);
    if ( RMFAILED( status )) {
    	RMDBGLOG((ENABLE, "Cannot set MPEG engine shared memory %d\n", status ));
		return RM_FATALOUTOFMEMORY;
    }

    status = RUAGetProperty( pHandle->profile.pRUA, mpeg_engine,
						  RMMpegEnginePropertyID_SchedulerSharedMemory,
                          schedmem, sizeof (*schedmem));
    if ( RMFAILED( status )) {
    	RMDBGLOG((ENABLE, "Cannot get SchedulerSharedMemory, %s\n", RMstatusToString( status)));
		return status;
    }


    if ( schedmem->Address ) {
            // The MPEG Engine's Scheduler Shared Memory should NOT have been already allocated
            RMDBGLOG(( ENABLE, "DRAM SCHEDULER MEMORY is already set addr=0x%lx size=0x%lx!\n",
            		schedmem->Address, schedmem->Size ));
            return RM_ERROR;
    }
    else {
    	schedmem->Address = RUAMalloc( pHandle->profile.pRUA,
											dram_index,
                                          RUA_DRAM_UNCACHED,
                                          schedmem->Size );
            if ( schedmem->Address == 0 ) {
            	RMDBGLOG((ENABLE, "ERROR: could not allocate scheduler table!\n" ));
                    return status;
            }
            RMDBGLOG(( LOCALDBG, "Allocated MPEG engine scheduler memory: @0x%08lx, %lu bytes\n",
            		schedmem->Address, schedmem->Size ));

            status = RUASetProperty( pHandle->profile.pRUA,
                                  mpeg_engine,
                                  RMMpegEnginePropertyID_SchedulerSharedMemory,
                                  schedmem, sizeof (*schedmem), 0 );
            if ( RMFAILED( status )) {
            	RMDBGLOG((ENABLE, "Cannot set decoder scheduler memory %d\n", status ));
                    return status;
            }
    }

    return status;
}

RMstatus rmfp_gt_term_mpeg_engine(struct RMFPHandle *pHandle, struct MpegEngine_DecoderSharedMemory_type *shared, struct MpegEngine_SchedulerSharedMemory_type *schedmem)
{
		RMstatus status = RM_OK;
		RMuint32 mpeg_engine;

        mpeg_engine = EMHWLIB_MODULE( MpegEngine, pHandle->video_options.EngineIndex);

        if ( schedmem->Address ) {
                RMDBGLOG(( ENABLE, "Free MPEG engine schedmem memory\n" ));
                RUAFree( pHandle->profile.pRUA,
                		schedmem->Address );
                schedmem->Address = 0;
                status = RUASetProperty( pHandle->profile.pRUA,
                                      mpeg_engine,
                                      RMMpegEnginePropertyID_SchedulerSharedMemory,
                                      schedmem,
                                      sizeof (*schedmem), 0 );
                if ( RMFAILED( status ))
                        RMDBGLOG((ENABLE, "Cannot clear decoder scheduler memory %d\n", status ));
        }

        if ( shared->Address ) {
                RMDBGLOG(( ENABLE, "Free MPEG engine shared memory\n" ));
                RUAFree( pHandle->profile.pRUA,
                		shared->Address );
        }

        return status;
}

RMstatus rmfp_internal_open_picture_transform(struct RMFPHandle *pHandle, RMuint32 *input_surface, RMuint32 *output_surface){
	struct RMFPPictureTransformResourcesProfile rmfp_picture_transform_resources_profile = { 0, };
	RMuint32 xform_decoder = 0;

	struct PictureTransform_Open_type xform_profile;
	struct PictureTransform_DecoderMemory_in_type memory_in;
	struct PictureTransform_DecoderMemory_out_type memory_out;

	struct DisplayBlock_SurfaceInfo_out_type surface_info;
	struct PictureTransform_BufferSize_in_type pic_size_in;
	struct PictureTransform_BufferSize_out_type pic_size_out;
	RMuint32 picture_count;
	RMuint32 surface_size, BufferTypeFlag = 0;

	RMstatus status;
	enum EMhwlibPictureOrientation orientation = pHandle->playback_options.PTOrientation;

	struct RMFPVideoOptions *pVideoOptions = NULL;
	struct RMFPPlayOptions *pPlayOptions = NULL;

	pVideoOptions = &(pHandle->video_options);
	pPlayOptions = &(pHandle->playback_options);

		/*Set the picture_count field to 1 if the module will transform a signle picture,
		   e.g. a JPEG picture. Set it to 3 if the module will transform a set of pictures (i.e. a video)
		   and in all other cases*/		
		//Picture
		if(pHandle->pStreamInfo->DataStreamCount)
			picture_count = 1;
		//Video
		else if(pHandle->pStreamInfo->VideoStreamCount)
			picture_count = 3;
		//Default
		else			
			picture_count = 1;

	/* Get Picture Transform Resources Required */

	status = RUAExchangeProperty(pHandle->profile.pRUA, DisplayBlock, RMDisplayBlockPropertyID_SurfaceInfo, input_surface, sizeof(input_surface), &surface_info, sizeof(surface_info));
	if (RMFAILED(status)) {
		RMDBGLOG((ENABLE, "Error in exchange property RMDisplayBlockPropertyID_SurfaceInfo! %s\n", RMstatusToString(status)));
		return status;
	}

	status = RUAExchangeProperty(pHandle->profile.pRUA, DisplayBlock, RMDisplayBlockPropertyID_MultiplePictureSurfaceSize,
						&picture_count,
						sizeof(picture_count),
						&surface_size,
						sizeof(surface_size));
	if (RMFAILED(status)) {
		RMDBGLOG((ENABLE, "Cannot get the surface size\n"));
		return status;
	}

	rmfp_internal_get_decoder_id_from_indexes(pHandle->profile.pRUA,
											  pVideoOptions->EngineIndex,
											  pVideoOptions->DecoderIndex,
											  &xform_decoder);

	pic_size_in.ColorMode = surface_info.ColorMode;
	pic_size_in.ColorFormat = surface_info.ColorFormat;
	pic_size_in.SamplingMode = surface_info.SamplingMode;
	pic_size_in.ColorSpace = surface_info.ColorSpace;
	pic_size_in.InPlace = pPlayOptions->PTInPlace;
	pic_size_in.Orientation = orientation;
	pic_size_in.Width = pVideoOptions->vcodec_max_width;
	pic_size_in.Height = pVideoOptions->vcodec_max_height;

	status = RUAExchangeProperty(pHandle->profile.pRUA, xform_decoder, RMPictureTransformPropertyID_BufferSize, &pic_size_in, sizeof(pic_size_in), &pic_size_out, sizeof(pic_size_out));
	if (RMFAILED(status)) {
		RMDBGLOG((ENABLE, "Cannot get picture size %d\n", status));
		return status;
	}

	/* Get Picture Transform Resources Required */

	memory_in.TransformType = EMhwlibPictureTransformType_Orientation;
	memory_in.PictureSize = surface_size + picture_count*pic_size_out.BufferSize;
	memory_in.PictureCount = picture_count;
	memory_in.InPlace = pPlayOptions->PTInPlace;
	memory_in.InbandFIFOCount = 16;

	status = RUAExchangeProperty(pHandle->profile.pRUA, xform_decoder, RMPictureTransformPropertyID_DecoderMemory, &memory_in, sizeof(memory_in), &memory_out, sizeof(memory_out));
	if (RMFAILED(status)) {
		RMDBGLOG((ENABLE, "Error getting property RMVideoDecoderPropertyID_DecoderMemory! %s\n", RMstatusToString(status)));
		return status;
	}

	rmfp_picture_transform_resources_profile.Version	= GET_VERSION_FROM_MAGIC(RMFP_PICTURE_TRANSFORM_RESOURCES_PROFILE_VERSION);

	rmfp_picture_transform_resources_profile.dram	= pPlayOptions->DRAMIndex;

	rmfp_picture_transform_resources_profile.data_memory_address	= 0;
	rmfp_picture_transform_resources_profile.data_memory_size	= memory_out.DecoderDataSize;

	rmfp_picture_transform_resources_profile.interface_memory_address	= 0;
	rmfp_picture_transform_resources_profile.interface_memory_size	= memory_out.DecoderInterfaceSize;

	rmfp_picture_transform_resources_profile.engine_index	= pVideoOptions->EngineIndex;
	rmfp_picture_transform_resources_profile.decoder_index	= pVideoOptions->DecoderIndex;

	rmfp_picture_transform_resources_profile.STC_index	= pPlayOptions->STCIndex + pPlayOptions->STCEngine*3;

	// then present the RMFPPictureTransformResourcesProfile to the application if the callback was defined
	if (pHandle->profile.rmfp_picture_transform_resources_callback) {
		status = pHandle->profile.rmfp_picture_transform_resources_callback(pHandle->profile.callback_context, &rmfp_picture_transform_resources_profile);
		if (status != RM_OK) {
			RMNOTIFY((NULL, status, "Failed to get resources from application\n"));
			return status;
		}
	}


	// data
	if ((!rmfp_picture_transform_resources_profile.data_memory_address) &&
		(rmfp_picture_transform_resources_profile.data_memory_size)) {
		pHandle->picture_transform_resources.data_memory_address = DCCMalloc(pHandle->profile.pDCC,
										  rmfp_picture_transform_resources_profile.dram,
										  RUA_DRAM_UNCACHED,
										  rmfp_picture_transform_resources_profile.data_memory_size);

		if (!pHandle->picture_transform_resources.data_memory_address) {
			RMNOTIFY((NULL, RM_FATALOUTOFMEMORY, "Can't allocate %lu bytes in DRAM %lu\n",
					rmfp_picture_transform_resources_profile.data_memory_size,
					rmfp_picture_transform_resources_profile.dram));
			return RM_FATALOUTOFMEMORY;
		}
		else
			RMDBGLOG((LOCALDBG, "allocated %lu bytes for decoder data\n", rmfp_picture_transform_resources_profile.data_memory_size));

		pHandle->picture_transform_resources.free_data = TRUE;
	}
	else
		pHandle->picture_transform_resources.data_memory_address = rmfp_picture_transform_resources_profile.data_memory_address;


	xform_profile.DecoderDataAddress = pHandle->picture_transform_resources.data_memory_address;
	xform_profile.DecoderDataSize = rmfp_picture_transform_resources_profile.data_memory_size;

	RMDBGLOG((LOCALDBG, "Data Memory: %lu bytes at %p\n",
			xform_profile.DecoderDataSize,
		  xform_profile.DecoderDataAddress));

	// interface
	if ((!rmfp_picture_transform_resources_profile.interface_memory_address) &&
		(rmfp_picture_transform_resources_profile.interface_memory_size)) {
		pHandle->picture_transform_resources.interface_memory_address = DCCMalloc(pHandle->profile.pDCC,
									   rmfp_picture_transform_resources_profile.dram,
									   RUA_DRAM_UNCACHED,
									   rmfp_picture_transform_resources_profile.interface_memory_size);

		if (!pHandle->picture_transform_resources.interface_memory_address) {
			RMNOTIFY((NULL, RM_FATALOUTOFMEMORY, "Can't allocate %lu bytes in DRAM %lu\n",
					rmfp_picture_transform_resources_profile.interface_memory_size,
					rmfp_picture_transform_resources_profile.dram));
			return RM_FATALOUTOFMEMORY;
		}
		else
			RMDBGLOG((LOCALDBG, "allocated %lu bytes for decoder interface\n", rmfp_picture_transform_resources_profile.interface_memory_size));

		pHandle->picture_transform_resources.free_interface = TRUE;
	}
	else
		pHandle->picture_transform_resources.interface_memory_address = rmfp_picture_transform_resources_profile.interface_memory_address;

	xform_profile.DecoderInterfaceAddress = pHandle->picture_transform_resources.interface_memory_address;
	xform_profile.DecoderInterfaceSize = rmfp_picture_transform_resources_profile.interface_memory_size;

	RMDBGLOG((LOCALDBG, "Interface Memory: %lu bytes at %p\n",
			xform_profile.DecoderInterfaceSize,
			xform_profile.DecoderInterfaceAddress));

	xform_profile.STCId = 0;
	xform_profile.InbandFIFOCount = memory_in.InbandFIFOCount;
	xform_profile.InPlace = memory_in.InPlace;
	xform_profile.TransformType = memory_in.TransformType;
	xform_profile.InputSurface = *input_surface;

	while((status=RUASetProperty(pHandle->profile.pRUA, xform_decoder, RMPictureTransformPropertyID_Open, &(xform_profile), sizeof(xform_profile),0)) == RM_PENDING);
	if (status != RM_OK) {
		RMDBGLOG((ENABLE, "Cannot open the Picture Transform, %s\n", RMstatusToString(status)));
		return status;
	}


	status = RUAGetProperty(pHandle->profile.pRUA, xform_decoder, RMGenericPropertyID_Surface, output_surface, sizeof(output_surface));
	if (status != RM_OK) {
		RMDBGLOG((ENABLE, "Cannot get the video surface, %s\n", RMstatusToString(status)));
		return status;
	}

	/*
	* Set the buffer type
	*/

	BufferTypeFlag |= EMHWLIB_PICTURETRANSFORM_OUTBAND_FLAG_TILED_OUTPUT;

	status=RUASetProperty(pHandle->profile.pRUA, xform_decoder, RMPictureTransformPropertyID_OutBandFlags, &BufferTypeFlag, sizeof(&BufferTypeFlag),0);
	if (status != RM_OK) {
		RMDBGLOG((ENABLE, "Cannot set the buffer type, %s\n", RMstatusToString(status)));
		return status;
	}

	/*
	* Set the orientation. It can be changed "on-the-fly" if needed.
	*/

	while((status=RUASetProperty(pHandle->profile.pRUA, xform_decoder, RMPictureTransformPropertyID_OrientationMode, &orientation, sizeof(orientation),0)) == RM_PENDING);
	if (status != RM_OK) {
		RMDBGLOG((ENABLE, "Cannot get the video surface, %s\n", RMstatusToString(status)));
		return status;
	}

	/*
	* Obtain the output surface
	*/

	status = RUAGetProperty(pHandle->profile.pRUA, xform_decoder, RMGenericPropertyID_Surface, output_surface, sizeof(output_surface));
	if (status != RM_OK) {
		   RMDBGLOG((ENABLE, "Cannot get the video surface, %s\n", RMstatusToString(status)));
		   return status;
	}

	/*
	* Set the orientation. It can be changed "on-the-fly" if needed.
	*/

	while((status=RUASetProperty(pHandle->profile.pRUA, xform_decoder, RMPictureTransformPropertyID_OrientationMode, &orientation, sizeof(orientation),0)) == RM_PENDING);
	if (status != RM_OK) {
				   RMDBGLOG((ENABLE, "Cannot get the video surface, %s\n", RMstatusToString(status)));
				   return status;
	}

	/*
	* Set the PictureTransform ucode in play mode (initialize first)
	*/

	status = rmfp_gt_send_video_command(pHandle->profile.pRUA, xform_decoder, VideoDecoder_Command_Uninit);
	if (RMFAILED(status)) {
		RMDBGLOG((ENABLE, "Cannot send VideoDecoder_Command_Uninit, %s\n", RMstatusToString(status)));
		return status;
	}

	status = rmfp_gt_send_video_command(pHandle->profile.pRUA, xform_decoder, VideoDecoder_Command_Init);
	if (RMFAILED(status)) {
		RMDBGLOG((ENABLE, "Cannot send VideoDecoder_Command_Init, %s\n", RMstatusToString(status)));
		return status;
	}

	status = rmfp_gt_send_video_command(pHandle->profile.pRUA, xform_decoder, VideoDecoder_Command_PlayFwd);
	if (RMFAILED(status)) {
		RMDBGLOG((ENABLE, "Cannot send VideoDecoder_Command_Init, %s\n", RMstatusToString(status)));
		return status;
	}

	return RM_OK;

}

RMstatus rmfp_internal_close_picture_transform(struct RMFPHandle *pHandle){

	RMuint32 xform_decoder = 0;
	RMstatus status;
	struct RMFPPictureTransformResourcesProfile rmfp_picture_transform_resources_profile = { 0, };
	struct RMFPVideoOptions *pVideoOptions = &(pHandle->video_options);

	rmfp_internal_get_decoder_id_from_indexes(pHandle->profile.pRUA,
											  pVideoOptions->EngineIndex,
											  pVideoOptions->DecoderIndex,
											  &xform_decoder);

	status = rmfp_gt_send_video_command(pHandle->profile.pRUA, xform_decoder, VideoDecoder_Command_Stop);
	if (status != RM_OK){
		RMNOTIFY((NULL, status, "Failed to stop the Picture Transform\n"));
		return status;
	}

	/* Close the xform */
	while((status = RUASetProperty(pHandle->profile.pRUA, xform_decoder, RMPictureTransformPropertyID_Close, NULL, 0, 0)) == RM_PENDING);
	if (RMFAILED(status)) {
		RMDBGLOG((ENABLE, "Cannot stop video decoder %d\n", status));
		return status;
	}

	if (pHandle->picture_transform_resources.free_data) {
		RMDBGLOG((LOCALDBG, "Free picture transform data memory at %p\n", pHandle->picture_transform_resources.data_memory_address));
		DCCFree(pHandle->profile.pDCC, pHandle->picture_transform_resources.data_memory_address);
		pHandle->picture_transform_resources.data_memory_address = 0;
	}

	if (pHandle->picture_transform_resources.free_interface) {
		RMDBGLOG((LOCALDBG, "Free picture transform interface memory at %p\n", pHandle->picture_transform_resources.interface_memory_address));
		DCCFree(pHandle->profile.pDCC, pHandle->picture_transform_resources.interface_memory_address);
		pHandle->picture_transform_resources.interface_memory_address = 0;
	}

	rmfp_picture_transform_resources_profile.Version = GET_VERSION_FROM_MAGIC(RMFP_PICTURE_TRANSFORM_RESOURCES_PROFILE_VERSION);

	rmfp_picture_transform_resources_profile.dram = pHandle->picture_transform_resources.dram;

	rmfp_picture_transform_resources_profile.data_memory_address = pHandle->picture_transform_resources.data_memory_address;
	rmfp_picture_transform_resources_profile.data_memory_size = pHandle->picture_transform_resources.data_memory_size;

	rmfp_picture_transform_resources_profile.interface_memory_address = pHandle->picture_transform_resources.interface_memory_address;
	rmfp_picture_transform_resources_profile.interface_memory_size = pHandle->picture_transform_resources.interface_memory_size;

	rmfp_picture_transform_resources_profile.engine_index = pHandle->picture_transform_resources.engine_index;
	rmfp_picture_transform_resources_profile.decoder_index = pHandle->picture_transform_resources.decoder_index;

	rmfp_picture_transform_resources_profile.STC_index = pHandle->playback_options.STCIndex;

	// then present the RMFPPictureTransformResourcesProfile to the application if the callback was defined
	if (pHandle->profile.rmfp_release_picture_transform_resources_callback) {
		status = pHandle->profile.rmfp_release_picture_transform_resources_callback(pHandle->profile.callback_context, &rmfp_picture_transform_resources_profile);
		if (status != RM_OK) {
			RMNOTIFY((NULL, status, "The application failed to release the resources\n"));
			return status;
		}
	}

	return RM_OK;
}
