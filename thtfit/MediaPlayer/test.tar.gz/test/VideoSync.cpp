/*added by lxj 2012-12-28*/

#include <stdlib.h>
#include <unistd.h>
#include <math.h>
#include <sys/types.h>
#include <assert.h>
#include <memory2.h>
#include <SystemSrvApi.h>
#include <SysBaseSrvApi.h>
#include <NetAddrUtils.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <StackBufString.h>
#include <FdEvtNotifier.h>
#include <DateTime.h>
#include "DbgLogSwitchDef.h"

#include "VideoSync.h"

#define LOG_ERROR(fmt,...) LOG_BLINE("ERROR: " fmt,##__VA_ARGS__)
#define LOG_WARNING(fmt,...) LOG_BLINE("WARNING: " fmt,##__VA_ARGS__)

#define EXACTLY_CHECK_STATE_FOR_START 0

#if 1/*debug*/
#define LOG_INFO(fmt,...){\
	if(/*1*/Sw_LogVideoSync){\
		LOG_BLINE(fmt,##__VA_ARGS__);\
	}\
}
#else
#define LOG_INFO(fmt,...)
#endif

using namespace VideoSync;

CVideoSyncSlaveInfo::CVideoSyncSlaveInfo()
{
	memset(&m_SlaveInfo,0,sizeof(m_SlaveInfo));
}

CVideoSyncSlaveInfo::~CVideoSyncSlaveInfo()
{
}

CVideoSync::CVideoSync(SharedPtr <CMediaSrv> oMediaSrv_sp)
{
	m_oMediaSrv_sp = oMediaSrv_sp;

	m_strVideoSyncMaster = "";
	m_eVideoSyncMode = VidSyncMode_DISABLED;

	m_SlaveSendRegTimerId = 0;
	m_MasterWaitforTimerId = 0;

	m_VidSyncPacketSequenceNum = 0;
	ZeroMemory(&m_sckaddrVidSyncMaster, sizeof(m_sckaddrVidSyncMaster));

	m_CurrentState = eVideoSyncState_Idle;
	m_strURL = "";
	m_UnReadyToPlaySlaveCount = 0;

	m_bUdpActive = FALSE;
}

CVideoSync::~CVideoSync()
{
	//ExitInstance();
}

VIDEO_SYNC_MODE_t CVideoSync::getVideoSyncMode()
{
	return m_eVideoSyncMode;
}

CString CVideoSync::getVideoSyncMaster()
{
	return m_strVideoSyncMaster;
}

INT_t CVideoSync::setVideoSyncMode(VIDEO_SYNC_MODE_t eVideoSyncMode)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;

	do{
		if( m_bUdpActive || (m_CurrentState != eVideoSyncState_Idle) ){
			LOG_ERROR("is not idle\n");
			iOutRet = ERROR_INVALID_STATE;
			break;
		}

		if( m_eVideoSyncMode != eVideoSyncMode ){
			CString strVidoeSyncMode = eVideoSyncMode;
			iRet = SysProp_setPersistent(SysProp_KEY_MpVideoSyncMode, strVidoeSyncMode);
			if(ERROR_SUCCESS != iRet){
				LOG_ERROR("SysProp_setPersistent() strVidoeSyncMode fails\n");
				iOutRet = iRet;
				break;
			}
			m_eVideoSyncMode = eVideoSyncMode;/*It's OK*/
		}
	}while(FALSE);

	return iOutRet;
}

INT_t CVideoSync::setVideoSyncMaster(CString strVideoSyncMaster)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	SOCKADDR_IN sckaddrVidSyncMaster;

	do{
		if( m_bUdpActive || (m_CurrentState != eVideoSyncState_Idle) ){
			LOG_ERROR("is not idle\n");
			iOutRet = ERROR_INVALID_STATE;
			break;
		}

		if( m_strVideoSyncMaster != strVideoSyncMaster ){
			ZeroMemory(&sckaddrVidSyncMaster, sizeof(sckaddrVidSyncMaster));
			sckaddrVidSyncMaster.sin_family = AF_INET;
			sckaddrVidSyncMaster.sin_port = htons(VIDEO_SYNC_COMM_PORT);
			iRet = inet_aton((LPCSTR)strVideoSyncMaster, &(sckaddrVidSyncMaster.sin_addr));
			if(FALSE == iRet){
				LOG_ERROR("Invalid ip address \"%s\"\n", (LPCSTR)m_strVideoSyncMaster);
				iOutRet = ERROR_INVALID_PARAMETER;
				break;
			}

#if 1/*Disabled slave send broadcast*/
			if( (0 == sckaddrVidSyncMaster.sin_addr.s_addr) ||
				(0xffffffff == sckaddrVidSyncMaster.sin_addr.s_addr) ){
				LOG_ERROR("Invalid ip address \"%s\"\n", inet_ntoa(sckaddrVidSyncMaster.sin_addr));
				iOutRet = ERROR_INVALID_PARAMETER;
				break;
			}
#endif

			iRet = SysProp_setPersistent(SysProp_KEY_MpVideoSyncMaster, strVideoSyncMaster);
			if(ERROR_SUCCESS != iRet){
				LOG_ERROR("SysProp_setPersistent() strVideoSyncMaster fails\n");
				iOutRet = iRet;
				break;
			}

			if( m_bUdpActive ){/*Tell old Master i will quit then join to new Master*/
				tVideoSyncCommCmdUnReg CmdUnReg={0};
				INT_t iSendSize = 0;

				PACKET_COMM_HEAD(&CmdUnReg,eVideoSyncCmd_UnReg);
				iSendSize = sizeof(CmdUnReg);

				iRet = SlaveSendTo((PBYTE)(&CmdUnReg), iSendSize);
				if( ERROR_SUCCESS != iRet ){
					LOG_WARNING("iRet=%d\n",iRet);
				}
			}

			memcpy(&m_sckaddrVidSyncMaster,&sckaddrVidSyncMaster,sizeof(m_sckaddrVidSyncMaster));
			m_strVideoSyncMaster = strVideoSyncMaster;/*It's OK*/

			if(m_bUdpActive && (VidSyncMode_SLAVE == m_eVideoSyncMode) ){
				iRet = OnSlaveSendRegToMasterTimer();/*join to new Master*/
				if( ERROR_SUCCESS != iRet ){
					LOG_WARNING("iRet=%d\n",iRet);
				}
			}
		}
	}while(FALSE);

	return iOutRet;
}

INT_t CVideoSync::SlaveListClearAll()
{
	INT_t iOutRet = ERROR_SUCCESS;
	IP_SLAVE_LIST_MAP::iterator itList;

	do{
		for( itList = m_SlaveListMap.begin(); itList != m_SlaveListMap.end(); itList++ ){
			m_SlaveListMap.erase( itList->first );
		}

		m_UnReadyToPlaySlaveCount = 0;
	}while(FALSE);

	return iOutRet;
}

INT_t CVideoSync::RegisterTimer(UINT_t &TimerId,INT_t TimeoutMs)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;

	do{
		if(0 < TimerId){
			iRet = UnregisterTimer(TimerId);
			if(ERROR_SUCCESS != iRet){
				LOG_ERROR("iRet=%d\n",iRet);
				iOutRet = iRet;
				break;
			}
		}

		iRet = CFdEvtNotifier::RegisterTimer((WeakPtr<ITimerListener>)m_this_wp, OUT TimerId, TimeoutMs);
		if(ERROR_SUCCESS != iRet){
			LOG_ERROR("Register Timer fails, iRet=%d,TimerId=%u\n", iRet, TimerId);
			iOutRet = iRet;
			break;
		}
	}while(FALSE);

	return iOutRet;
}

INT_t CVideoSync::UnregisterTimer(UINT_t &TimerId)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;

	do{
		if(0 < TimerId){
			iRet = CFdEvtNotifier::UnregisterTimer(TimerId);
			if(ERROR_SUCCESS != iRet){
				LOG_ERROR("Unregister Timer fails, iRet=%d,TimerId=%u\n", iRet, TimerId);
				iOutRet = iRet;
				break;
			}
			TimerId = 0;
		}
	}while(FALSE);

	return iOutRet;
}

INT_t CVideoSync::MasterSendTo(LPBYTE pSendBuf, size_t iBufSize)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	SOCKADDR_IN sckAddrTarget;

	do{
		if( !m_bUdpActive ){
			LOG_ERROR("Udp is not active\n");
			iOutRet = ERROR_INVALID_STATE;
			break;
		}

		/*Broadcast to slave*/
		sckAddrTarget.sin_family = AF_INET;
		sckAddrTarget.sin_port = htons(VIDEO_SYNC_COMM_PORT);
		sckAddrTarget.sin_addr.s_addr = INADDR_BROADCAST;

		iRet = m_sckVideoSyncComm.SendTo(pSendBuf, iBufSize, 0, (P_SOCKADDR)(&sckAddrTarget), sizeof(sckAddrTarget));
		if( (0 > iRet) || (iRet != iBufSize) ){/*No need try again if send fails*/
			LOG_ERROR("MasterSendTo error,ReqSize=%d,SentSize=%d,LastError=%d(%s)\n", iBufSize, iRet, m_sckVideoSyncComm.GetLastLocalErrNo(), strerror(m_sckVideoSyncComm.GetLastCrtErrNo()));
			iOutRet = ERROR_SOCKET_SEND_FAIL;
			break;
		}

		LOG_INFO("%s(),send=%d,bufsize=%d\n",__func__,iRet,iBufSize);
	}while(FALSE);

	return iOutRet;
}

INT_t CVideoSync::SlaveSendTo(LPBYTE pSendBuf, size_t iBufSize)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;

	do{
		if( !m_bUdpActive ){
			LOG_ERROR("Udp is not active\n");
			iOutRet = ERROR_INVALID_STATE;
			break;
		}

		/*Send to own master only*/
		iRet = m_sckVideoSyncComm.SendTo(pSendBuf, iBufSize, 0, (P_SOCKADDR)(&m_sckaddrVidSyncMaster), sizeof(m_sckaddrVidSyncMaster));
		if( (0 > iRet) || (iRet != iBufSize) ){/*No need try again if send fails*/
			LOG_ERROR("SlaveSendTo error,ReqSize=%d,SentSize=%d,LastError=%d(%s)\n", iBufSize, iRet, m_sckVideoSyncComm.GetLastLocalErrNo(), strerror(m_sckVideoSyncComm.GetLastCrtErrNo()));
			iOutRet = ERROR_SOCKET_SEND_FAIL;
			break;
		}

		//LOG_INFO("%s(), send=%d,bufsize=%d\n",__func__,iRet,iBufSize);
	}while(FALSE);

	return iOutRet;
}

INT_t CVideoSync::StartMasterMode()
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;

	do{
		if( m_CurrentState != eVideoSyncState_Idle ){
			LOG_ERROR("is not idle\n");
			iOutRet = ERROR_INVALID_STATE;
			break;
		}

		if( VidSyncMode_MASTER != m_eVideoSyncMode ){
			LOG_ERROR("is not Master Mode\n");
			iOutRet = ERROR_INVALID_STATE;
			break;
		}

		SlaveListClearAll();

		iRet = OpenUdp();
		if( ERROR_SUCCESS != iRet ){
			LOG_ERROR("iRet=%d\n",iRet);
			iOutRet = iRet;
			StopVideoSync();
			break;
		}

#if 0/*for debug*/
		INT32_t x,y,w,h;
		m_oMediaSrv_sp->getVideoPosition(&x,&y,&w,&h);
#endif

		LOG_INFO("%s()\n",__func__);
	}while(FALSE);

	return iOutRet;
}

INT_t CVideoSync::StartSlaveMode()
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;

	do{
		if( m_CurrentState != eVideoSyncState_Idle ){
			LOG_ERROR("is not idle\n");
			iOutRet = ERROR_INVALID_STATE;
			break;
		}

		if( VidSyncMode_SLAVE != m_eVideoSyncMode ){
			LOG_ERROR("is not Slave Mode\n");
			iOutRet = ERROR_INVALID_STATE;
			break;
		}

		iRet = OpenUdp();
		if( ERROR_SUCCESS != iRet ){
			LOG_ERROR("iRet=%d\n",iRet);
			iOutRet = iRet;
			StopVideoSync();
			break;
		}

		iRet = OnSlaveSendRegToMasterTimer();
		if(ERROR_SUCCESS != iRet){
			LOG_WARNING("iRet=%d\n",iRet);
		}

		/*Keep-alive reg timer*/
		iRet = RegisterTimer( m_SlaveSendRegTimerId, SLAVE_REG_TIMEROUT_MS );
		if( ERROR_SUCCESS != iRet ){
			LOG_ERROR("iRet=%d\n",iRet);
			StopVideoSync();
			iOutRet = iRet;
			break;
		}

		LOG_INFO("%s(),Master=%s,m_SlaveSendRegTimerId=%d\n",__func__,(LPCSTR)m_strVideoSyncMaster,m_SlaveSendRegTimerId);
	}while(FALSE);

	return iOutRet;
}

INT_t CVideoSync::StopMasterMode()
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	tVideoSyncCommCmdStopPlay CmdStopPlay={0};
	INT_t iSendSize = 0;

	do{
		if( m_bUdpActive ){
			PACKET_COMM_HEAD(&CmdStopPlay,eVideoSyncCmd_StopPlay);
			iSendSize = sizeof(CmdStopPlay);

			iRet = MasterSendTo((PBYTE)(&CmdStopPlay), iSendSize);
			if( ERROR_SUCCESS != iRet ){
				LOG_WARNING("iRet=%d\n",iRet);
			}
		}

		if(0 < m_MasterWaitforTimerId){
			iRet = UnregisterTimer(m_MasterWaitforTimerId);
			if( ERROR_SUCCESS != iRet ){
				LOG_ERROR("iRet=%d\n",iRet);
				iOutRet = iRet;
				break;
			}
		}

		iRet = CloseUdp();
		if( ERROR_SUCCESS != iRet ){
			LOG_ERROR("iRet=%d\n",iRet);
			iOutRet = iRet;
			break;
		}

		SlaveListClearAll();
		m_CurrentState = eVideoSyncState_Idle;

		LOG_INFO("%s()\n",__func__);
	}while(FALSE);

	return iOutRet;
}

INT_t CVideoSync::StopSlaveMode()
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	tVideoSyncCommCmdUnReg CmdUnReg={0};
	INT_t iSendSize = 0;

	do{
		if( m_bUdpActive ){
			PACKET_COMM_HEAD(&CmdUnReg,eVideoSyncCmd_UnReg);
			iSendSize = sizeof(CmdUnReg);

			iRet = SlaveSendTo((PBYTE)(&CmdUnReg), iSendSize);
			if( ERROR_SUCCESS != iRet ){
				LOG_WARNING("iRet=%d\n",iRet);
			}
		}

		if(0 < m_SlaveSendRegTimerId){
			iRet = UnregisterTimer(m_SlaveSendRegTimerId);
			if( ERROR_SUCCESS != iRet ){
				LOG_ERROR("iRet=%d\n",iRet);
				iOutRet = iRet;
				break;
			}
		}

		iRet = CloseUdp();
		if( ERROR_SUCCESS != iRet ){
			LOG_ERROR("iRet=%d\n",iRet);
			iOutRet = iRet;
			break;
		}

		m_CurrentState = eVideoSyncState_Idle;

		LOG_INFO("%s()\n",__func__);
	}while(FALSE);

	return iOutRet;
}

INT_t CVideoSync::OpenUdp()
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	bool bBroadcast = FALSE;

	do{
		if( m_bUdpActive ){
			LOG_WARNING("sckVideoSyncComm is already actived\n");
			break;
		}

		/*Create the socket for video sync communication*/
		iRet = m_sckVideoSyncComm.Create(NULL, VIDEO_SYNC_COMM_PORT);
		if(ERROR_SUCCESS != iRet){
			LOG_ERROR("Create sckVideoSyncComm fails, iRet=%d\n", iRet);
			iOutRet = iRet;
			StopVideoSync();
			break;
		}

		if(INVALID_SOCKET == m_sckVideoSyncComm.GetSocketHandle()){
			LOG_ERROR("GetSocketHandle() is INVALID_SOCKET\n");
			iOutRet = ERR_INVALID_HANDLE;
			StopVideoSync();
			break;
		}

		/*Register socket event notification*/
		iRet = CFdEvtNotifier::RegisterFdNotify( m_sckVideoSyncComm.GetSocketHandle(), IFileDescriptorEventIf::FD_EVT_READABLE, m_this_wp );
		if(ERROR_SUCCESS != iRet){
			LOG_ERROR("Register socket fd(%d) Notify fails\n",m_sckVideoSyncComm.GetSocketHandle());
			iOutRet = iRet;
			StopVideoSync();
			break;
		}

		switch ( m_eVideoSyncMode ){
			case VidSyncMode_MASTER:
				bBroadcast = TRUE;
				break;
			case VidSyncMode_SLAVE:
				bBroadcast = TRUE;
				break;
			default:
				bBroadcast = FALSE;
				break;
		}

		iRet = m_sckVideoSyncComm.setBroadcastFeature(bBroadcast);
		if(ERROR_SUCCESS != iRet){
			LOG_ERROR("setBroadcastFeature() fails\n");
			iOutRet = iRet;
			StopVideoSync();
			break;
		}

		m_bUdpActive = TRUE;/*It's OK*/
		LOG_INFO("%s()\n",__func__);
	}while(FALSE);

	return iOutRet;
}

INT_t CVideoSync::CloseUdp()
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;

	do{
		iRet = CFdEvtNotifier::UnregisterFdNotify(m_sckVideoSyncComm.GetSocketHandle());
		if(ERROR_SUCCESS != iRet){
			LOG_WARNING("iRet=%d\n",iRet);
		}

		iRet = m_sckVideoSyncComm.Close();
		if(ERROR_SUCCESS != iRet){
			LOG_ERROR("iRet=%d\n",iRet);
			iOutRet = iRet;
			break;
		}

		m_bUdpActive = FALSE;/*It's OK*/
		LOG_INFO("%s()\n",__func__);
	}while(FALSE);

	return iOutRet;
}

INT_t CVideoSync::StartVideoSync()
{
	INT_t iOutRet = ERROR_SUCCESS;

	do{
		switch ( m_eVideoSyncMode ){
			case VidSyncMode_MASTER:
				iOutRet = StartMasterMode();
				break;
			case VidSyncMode_SLAVE:
				iOutRet = StartSlaveMode();
				break;
			default:
				break;
		}
	}while(FALSE);

	return iOutRet;
}

INT_t CVideoSync::StopVideoSync()
{
	INT_t iOutRet = ERROR_SUCCESS;

	do{
		switch ( m_eVideoSyncMode ){
			case VidSyncMode_MASTER:
				iOutRet = StopMasterMode();
				break;
			case VidSyncMode_SLAVE:
				iOutRet = StopSlaveMode();
				break;
			default:
				break;
		}
	}while(FALSE);

	return iOutRet;
}

INT_t CVideoSync::InitInstance()
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	VIDEO_SYNC_MODE_t eVideoSyncMode = VidSyncMode_DISABLED;
	CString strVideoSyncMaster="";

	LOG_INFO("%s()\n",__func__);

	do{
		/*Read the setting value of VideoSync*/
		iRet = SysProp_get(SysProp_KEY_MpVideoSyncMaster, OUT strVideoSyncMaster);
		if(ERROR_NOT_FOUND == iRet)
		{
			strVideoSyncMaster = "";
		}
		else if(ERROR_SUCCESS != iRet){
			LOG_WARNING("iRet=%d\n",iRet);
		}
		iRet = setVideoSyncMaster(strVideoSyncMaster);
		if( ERROR_SUCCESS != iRet ){
			LOG_ERROR("iRet=%d\n",iRet);
			iOutRet = iRet;
			break;
		}

		DECLARE_CLS_STACK_BUF_STRING(strValue, 64);
		iRet = SysProp_get(SysProp_KEY_MpVideoSyncMode, OUT strValue);
		if(ERROR_SUCCESS == iRet)
		{
		    eVideoSyncMode = (typeof(m_eVideoSyncMode))(INT_t)strValue;
		}
		else if(ERROR_NOT_FOUND == iRet)
		{
		}
		else if(ERROR_SUCCESS != iRet){
		    LOG_WARNING("iRet=%d\n",iRet);
		}
		iRet = setVideoSyncMode(eVideoSyncMode);
		if( ERROR_SUCCESS != iRet ){
			LOG_ERROR("iRet=%d\n",iRet);
			iOutRet = iRet;
			break;
		}

		iRet = StartVideoSync();
		if( ERROR_SUCCESS != iRet ){
			LOG_ERROR("iRet=%d\n",iRet);
			iOutRet = iRet;
			break;
		}
	}while(FALSE);

	return 	iOutRet;
}

INT_t CVideoSync::ExitInstance()
{
	INT_t iOutRet = ERROR_SUCCESS;

	do{
		iOutRet = StopVideoSync();
		m_oMediaSrv_sp.Clear();
	}while(FALSE);

	return iOutRet;
}

VOID CVideoSync::OnTimer(UINT_t TimerId)
{
	INT_t iRet;

	//LOG_INFO("%s()\n",__func__);

	if(m_SlaveSendRegTimerId == TimerId){
		iRet = OnSlaveSendRegToMasterTimer();
		if(ERROR_SUCCESS != iRet){
			LOG_WARNING("iRet=%d\n",iRet);
		}
	}else if(m_MasterWaitforTimerId == TimerId){
		iRet = OnMasterWaitforTimer();
		if(ERROR_SUCCESS != iRet){
			LOG_WARNING("iRet=%d\n",iRet);
		}
	}else{
		LOG_WARNING("BUG,unprocessed timer id(%u)\n", TimerId);
	}
}

INT_t CVideoSync::OnMasterWaitforTimer()
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;

	do{
		if( 0 < m_MasterWaitforTimerId ){
			iRet = UnregisterTimer(m_MasterWaitforTimerId);
			if( ERROR_SUCCESS != iRet ){
				LOG_ERROR("iRet=%d\n",iRet);
				iOutRet = iRet;
				break;
			}
		}

		if( VidSyncMode_MASTER != m_eVideoSyncMode ){/*Video Sync Master Mode*/
			iOutRet = iRet = ERROR_INVALID_STATE;
			LOG_ERROR("iRet=%d\n",iRet);
			break;
		}

		switch( m_CurrentState ){
			case eVideoSyncState_Idle:
			case eVideoSyncState_PrepareToPlay:
				LOG_INFO("Master PrepareToPlay spend time too long\n");
				break;
			case eVideoSyncState_ReadyToPlay:
				LOG_INFO("Waitfor all slave ReadyToPlay timeout, let's go to play now\n");
				iRet = OnMasterStartPlay();
				if( ERROR_SUCCESS != iRet ){
					LOG_ERROR("iRet=%d\n",iRet);
					iOutRet = iRet;
				}
				break;
			case eVideoSyncState_Running:
				LOG_INFO("All slave is ReaddyToPlay and Master is running now\n");
				break;
			default:
				break;
		}
	}while(FALSE);

	return iOutRet;
}

INT_t CVideoSync::OnSlaveSendRegToMasterTimer()
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	tVideoSyncCommCmdReg CmdReg={0};
	INT_t iSendSize = 0;

	do{
		if(VidSyncMode_SLAVE != m_eVideoSyncMode){
			LOG_ERROR("is not Slave Mode\n");
			iOutRet = ERROR_INVALID_STATE;
			break;
		}

#if 1/*Disabled slave send broadcast*/
		if( (0 == m_sckaddrVidSyncMaster.sin_addr.s_addr) ||
			(0xffffffff == m_sckaddrVidSyncMaster.sin_addr.s_addr) ){
			LOG_ERROR("Invalid Master address(%s)\n",inet_ntoa(m_sckaddrVidSyncMaster.sin_addr));
			iOutRet = ERROR_INVALID_PARAMETER;
			break;
		}
#endif

		PACKET_COMM_HEAD(&CmdReg,eVideoSyncCmd_Reg);
		CmdReg.SlaveState = m_CurrentState;
		iSendSize = sizeof(CmdReg);

		iRet = SlaveSendTo((PBYTE)(&CmdReg), iSendSize);
		if( ERROR_SUCCESS != iRet){
			LOG_ERROR("iRet=%d\n",iRet);
			iOutRet = iRet;
			break;
		}
	}while(FALSE);

	return iOutRet;
}

INT_t CVideoSync::OnFdEvent(int iFd, CONST IFileDescriptorEventIf::FD_EVENT_FLAGS FdEvtFlags)
{
	INT_t iOutRet = ERROR_SUCCESS;

	//LOG_INFO("%s()\n",__func__);

	do{
		if(m_sckVideoSyncComm.GetSocketHandle() == iFd){
			iOutRet = OnCommVideoSyncRead();
		}else{
			LOG_ERROR("BUG,unprocessed fd(%d) event(0x%08x)\n", iFd, FdEvtFlags);
			iOutRet = ERROR_INVALID_PARAMETER;
			break;
		}
	}while(FALSE);

	return iOutRet;
}

INT_t CVideoSync::OnMasterPrepareToPlay()
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;

	LOG_INFO("%s()\n",__func__);

	do{
		m_CurrentState = eVideoSyncState_PrepareToPlay;
	}while(FALSE);

	return iOutRet;
}

INT_t CVideoSync::OnMasterTellSlavePrepareToPlay()
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	tVideoSyncCommCmdPrepareToPlay CmdPrepareToPlay={0};
	INT_t iSendSize = 0;
	IP_SLAVE_LIST_MAP::iterator itList;
	SharedPtr <CVideoSyncSlaveInfo> slaveInfo_sp;

	LOG_INFO("%s()\n",__func__);

	do{
		m_UnReadyToPlaySlaveCount = 0;
		for( itList = m_SlaveListMap.begin(); itList != m_SlaveListMap.end(); itList++ ){
			slaveInfo_sp = itList->second;
			if( slaveInfo_sp.isValid() ){
				UINT64_t diffMs,nowMs;
				nowMs = GetSysUpTimeMs();
				diffMs = (nowMs >= slaveInfo_sp->m_SlaveInfo.LastTickMs) ?
				         (nowMs - slaveInfo_sp->m_SlaveInfo.LastTickMs) :
				         (((UINT64_t)(-1)) - slaveInfo_sp->m_SlaveInfo.LastTickMs + nowMs);
#if 1/*for debug*/
				struct in_addr addr;
				addr.s_addr=(in_addr_t)itList->first;
				LOG_INFO("Slave(%s) diffMs=%llu,state=%d\n",inet_ntoa(addr),diffMs,slaveInfo_sp->m_SlaveInfo.SlaveState);
#endif
				if( ( (SLAVE_CHECK_ALIVE_MS) ) >= ( diffMs ) ){/*Slave is valid and active*/
					m_UnReadyToPlaySlaveCount++;
					slaveInfo_sp->m_SlaveInfo.SlaveState = eVideoSyncState_PrepareToPlay;
				}else{/*Slave is reg timeout and not active*/
					m_SlaveListMap.erase(itList->first);
				}
			}
		}

		PACKET_COMM_HEAD(&CmdPrepareToPlay,eVideoSyncCmd_PrepareToPlay);
		strncpy(CmdPrepareToPlay.strURL,m_strURL,sizeof(CmdPrepareToPlay.strURL)-1);
		iSendSize = sizeof(CmdPrepareToPlay);

		iRet = MasterSendTo((PBYTE)(&CmdPrepareToPlay), iSendSize);
		if( ERROR_SUCCESS != iRet ){
			LOG_ERROR("iRet=%d\n",iRet);
			iOutRet = iRet;
			break;
		}
	}while(FALSE);

	return iOutRet;
}

INT_t CVideoSync::OnMasterReadyToPlay()
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;

	LOG_INFO("%s()\n",__func__);

	do{
		if( eVideoSyncState_Idle == m_CurrentState ){
			iOutRet = iRet = ERROR_INVALID_STATE;
			LOG_ERROR("m_CurrentState=%d\n",m_CurrentState);
			break;
		}

#if EXACTLY_CHECK_STATE_FOR_START
		if( eVideoSyncState_PrepareToPlay != m_CurrentState ){
			LOG_WARNING("m_CurrentState=%d\n",m_CurrentState);
			break;
		}
#endif

		m_CurrentState = eVideoSyncState_ReadyToPlay;

		/*Tell Slave to prepare*/
		iRet = OnMasterTellSlavePrepareToPlay();
		if( ERROR_SUCCESS != iRet ){
			LOG_ERROR("iRet=%d\n",iRet);
			iOutRet = iRet;
			break;
		}
		iRet = RegisterTimer(m_MasterWaitforTimerId, MASTER_WAITFOR_TIMEOUT_MS);
		if(ERROR_SUCCESS != iRet){
			LOG_ERROR("iRet=%d\n",iRet);
			iOutRet = iRet;
			StopVideoSync();
			break;
		}

#if 1/*No slave or all slave is ready OK*/
		if( (eVideoSyncState_ReadyToPlay == m_CurrentState) &&
			(0 == m_UnReadyToPlaySlaveCount) ){
			iRet = OnMasterStartPlay();
			if( ERROR_SUCCESS != iRet ){
				LOG_ERROR("iRet=%d\n",iRet);
				iOutRet = iRet;
				break;
			}
		}
#endif
	}while(FALSE);

	return iOutRet;
}

INT_t CVideoSync::OnSlaveReadyToPlay()
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	tVideoSyncCommCmdReadyToPlay CmdReadyToPlay={0};
	INT_t iSendSize = 0;

	LOG_INFO("%s()\n",__func__);

	do{
		if( eVideoSyncState_Idle == m_CurrentState ){/*Maybe from User Normal Play in the Idle state*/
			//LOG_WARNING("m_CurrentState=%d,Maybe from User Normal Play in the Idle state\n",m_CurrentState);
			break;
		}

#if EXACTLY_CHECK_STATE_FOR_START
		if( eVideoSyncState_PrepareToPlay != m_CurrentState ){
			iOutRet = iRet = ERROR_INVALID_STATE;
			LOG_ERROR("m_CurrentState=%d\n",m_CurrentState);
			break;
		}
#endif

		PACKET_COMM_HEAD(&CmdReadyToPlay,eVideoSyncCmd_ReadyToPlay);
		iSendSize = sizeof(CmdReadyToPlay);

		iRet = SlaveSendTo((PBYTE)(&CmdReadyToPlay), iSendSize);
		if( ERROR_SUCCESS != iRet ){
			LOG_ERROR("iRet=%d\n",iRet);
			iOutRet = iRet;
			break;
		}

		m_CurrentState = eVideoSyncState_ReadyToPlay;
	}while(FALSE);

	return iOutRet;
}

INT_t CVideoSync::OnMasterStartPlay()
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	tVideoSyncCommCmdStartPlay CmdStartPlay={0};
	INT_t iSendSize = 0;

	do{
		if( eVideoSyncState_ReadyToPlay != m_CurrentState ){
			iOutRet = iRet = ERROR_INVALID_STATE;
			LOG_ERROR("m_CurrentState=%d\n",m_CurrentState);
			break;
		}

		if(0 < m_MasterWaitforTimerId){
			iRet = UnregisterTimer(m_MasterWaitforTimerId);
			if( ERROR_SUCCESS != iRet ){
				LOG_ERROR("iRet=%d\n",iRet);
				iOutRet = iRet;
				break;
			}
		}

		if( m_oMediaSrv_sp.isNull() ){
			iOutRet = iRet = ERROR_INVALID_PARAMETER;
			LOG_ERROR("iRet=%d\n",iRet);
			break;
		}

		PACKET_COMM_HEAD(&CmdStartPlay,eVideoSyncCmd_StartPlay);
		iSendSize = sizeof(CmdStartPlay);

		iRet = MasterSendTo((PBYTE)(&CmdStartPlay), iSendSize);
		if( ERROR_SUCCESS != iRet ){
			LOG_ERROR("iRet=%d\n",iRet);
			iOutRet = iRet;
			break;
		}

		iRet = m_oMediaSrv_sp->setPlayMode(MediaPlayer::PlayMode_Normal);
		if( ERROR_SUCCESS != iRet ){
			LOG_ERROR("iRet=%d\n",iRet);
			iOutRet = iRet;
			break;
		}

		m_CurrentState = eVideoSyncState_Running;
		LOG_INFO("%s()\n",__func__);
	}while(FALSE);

	return iOutRet;
}

INT_t CVideoSync::OnMasterStopPlay()
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	tVideoSyncCommCmdStopPlay CmdStopPlay={0};
	INT_t iSendSize = 0;

	do{
		if(0 < m_MasterWaitforTimerId){
			iRet = UnregisterTimer(m_MasterWaitforTimerId);
			if( ERROR_SUCCESS != iRet ){
				LOG_ERROR("iRet=%d\n",iRet);
				iOutRet = iRet;
				break;
			}
		}

		if( eVideoSyncState_Idle != m_CurrentState ){
			PACKET_COMM_HEAD(&CmdStopPlay,eVideoSyncCmd_StopPlay);
			iSendSize = sizeof(CmdStopPlay);

			iRet = MasterSendTo((PBYTE)(&CmdStopPlay), iSendSize);
			if( ERROR_SUCCESS != iRet ){
				LOG_ERROR("iRet=%d\n",iRet);
				iOutRet = iRet;
				break;
			}

			m_CurrentState = eVideoSyncState_Idle;
		}

		LOG_INFO("%s()\n",__func__);
	}while(FALSE);

	return iOutRet;
}

INT_t CVideoSync::OnUiSetDataSource(LPCSTR pszDataSrcUrl)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;

	LOG_INFO("%s()\n",__func__);

	do{
		if( m_oMediaSrv_sp.isNull() ){
			iOutRet = iRet = ERROR_INVALID_PARAMETER;
			LOG_ERROR("iRet=%d\n",iRet);
			break;
		}

		if( NULL == pszDataSrcUrl ){
			iOutRet = iRet = ERROR_INVALID_PARAMETER;
			LOG_ERROR("iRet=%d\n",iRet);
			break;
		}

		if( VidSyncMode_MASTER == m_eVideoSyncMode ){/*Video Sync Master Mode*/
			iRet = m_oMediaSrv_sp->setDataSource(pszDataSrcUrl);
			if( ERROR_SUCCESS != iRet ){
				LOG_ERROR("iRet=%d\n",iRet);
				iOutRet = iRet;
				break;
			}
			m_strURL = pszDataSrcUrl;
		}else if( VidSyncMode_SLAVE == m_eVideoSyncMode ){/*Video Sync Slave Mode*/
			if( eVideoSyncState_Idle != m_CurrentState ){
				LOG_WARNING("VideoSyncSlaveMode is not idle\n");
				iOutRet = ERROR_INVALID_STATE;
				break;
			}
			iOutRet = m_oMediaSrv_sp->setDataSource(pszDataSrcUrl);
		}else{/*Normal*/
			iOutRet = m_oMediaSrv_sp->setDataSource(pszDataSrcUrl);
		}
	}while(FALSE);

	return iOutRet;
}

INT_t CVideoSync::OnUiPrepare()
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;

	LOG_INFO("%s()\n",__func__);

	do{
		if( m_oMediaSrv_sp.isNull() ){
			iOutRet = iRet = ERROR_INVALID_PARAMETER;
			LOG_ERROR("iRet=%d\n",iRet);
			break;
		}

		if( VidSyncMode_MASTER == m_eVideoSyncMode ){/*Video Sync Master Mode*/
			iRet = m_oMediaSrv_sp->Prepare();
			if( ERROR_SUCCESS != iRet ){
				LOG_ERROR("iRet=%d\n",iRet);
				iOutRet = iRet;
				break;
			}
		}else if( VidSyncMode_SLAVE == m_eVideoSyncMode ){/*Video Sync Slave Mode*/
			if( eVideoSyncState_Idle != m_CurrentState ){
				LOG_WARNING("VideoSyncSlaveMode is not idle\n");
				iOutRet = ERROR_INVALID_STATE;
				break;
			}
			iOutRet = m_oMediaSrv_sp->Prepare();
		}else{/*Normal*/
			iOutRet = m_oMediaSrv_sp->Prepare();
		}
	}while(FALSE);

	return iOutRet;
}

INT_t CVideoSync::OnUiPlay(OUT UINT32_t * pPlaybackId/* = NULL*/, IN CMediaSrv::P_PLAY_PARAMS pPlayParams/* = NULL*/)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	CMediaSrv::PLAY_PARAMS DefaultPlayParams = { 0 };

	LOG_INFO("%s()\n",__func__);

	DefaultPlayParams.LoopCount = 1;
	DefaultPlayParams.bPauseAfterBuffering = FALSE;

	do{
		if( m_oMediaSrv_sp.isNull() ){
			iOutRet = iRet = ERROR_INVALID_PARAMETER;
			LOG_ERROR("iRet=%d\n",iRet);
			break;
		}

		if( VidSyncMode_MASTER == m_eVideoSyncMode ){/*Video Sync Master Mode*/
			if( NULL == pPlayParams ){
				pPlayParams = &DefaultPlayParams;
			}
			iRet = OnMasterPrepareToPlay();
			if( ERROR_SUCCESS != iRet ){
				LOG_ERROR("iRet=%d\n",iRet);
				iOutRet = iRet;
				break;
			}
			LOG_INFO("MASTER URL: \"%s\",LoopCount=%d\n",(LPCSTR)(m_strURL),pPlayParams->LoopCount);

			pPlayParams->bPauseAfterBuffering = TRUE;
			iRet = m_oMediaSrv_sp->Play(pPlaybackId,pPlayParams);
			if( ERROR_SUCCESS != iRet ){
				LOG_ERROR("iRet=%d\n",iRet);
				iOutRet = iRet;
				break;
			}
		}else if( VidSyncMode_SLAVE == m_eVideoSyncMode ){/*Video Sync Slave Mode*/
			if( eVideoSyncState_Idle != m_CurrentState ){
				LOG_WARNING("VideoSyncSlaveMode is not idle\n");
				iOutRet = ERROR_INVALID_STATE;
				break;
			}
			iOutRet = m_oMediaSrv_sp->Play(pPlaybackId,pPlayParams);
		}else{/*Normal*/
			iOutRet = m_oMediaSrv_sp->Play(pPlaybackId,pPlayParams);
		}
	}while(FALSE);

	return iOutRet;
}

INT_t CVideoSync::OnUiStop(OUT UINT32_t * pPlaybackId/* = NULL*/, OUT CStackBufString * pStrUrl/* = NULL*/)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;

	LOG_INFO("%s()\n",__func__);

	do{
		if( m_oMediaSrv_sp.isNull() ){
			iOutRet = iRet = ERROR_INVALID_PARAMETER;
			LOG_ERROR("iRet=%d\n",iRet);
			break;
		}

		if( VidSyncMode_MASTER == m_eVideoSyncMode ){/*Video Sync Master Mode, tell slave to stop*/
			iRet= m_oMediaSrv_sp->Stop(pPlaybackId, pStrUrl);
			if( ERROR_SUCCESS != iRet ){
				LOG_ERROR("iRet=%d\n",iRet);
				iOutRet = iRet;
				break;
			}
		}else if( VidSyncMode_SLAVE == m_eVideoSyncMode ){/*Video Sync Slave Mode, can't stop by UI*/
			if( eVideoSyncState_Idle != m_CurrentState ){
				LOG_WARNING("VideoSyncSlaveMode is not idle\n");
				iOutRet = ERROR_INVALID_STATE;
				break;
			}
			iOutRet = m_oMediaSrv_sp->Stop(pPlaybackId, pStrUrl);
		}else{/*Normal*/
			iOutRet = m_oMediaSrv_sp->Stop(pPlaybackId, pStrUrl);
		}
	}while(FALSE);

	return iOutRet;
}

INT_t CVideoSync::OnPlaybackReadyToPlay()
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;

	LOG_INFO("%s()\n",__func__);

	do{
		if( m_oMediaSrv_sp.isNull() ){
			iOutRet = iRet = ERROR_INVALID_PARAMETER;
			LOG_ERROR("iRet=%d\n",iRet);
			break;
		}

		switch ( m_eVideoSyncMode ){
			case VidSyncMode_MASTER:
				iRet = OnMasterReadyToPlay();
				if( ERROR_SUCCESS != iRet ){
					LOG_ERROR("iRet=%d\n",iRet);
					iOutRet = iRet;
				}
				break;
			case VidSyncMode_SLAVE:
				iRet = OnSlaveReadyToPlay();
				if( ERROR_SUCCESS != iRet ){
					LOG_ERROR("iRet=%d\n",iRet);
					iOutRet = iRet;
				}
				break;
			default:
				iOutRet = m_oMediaSrv_sp->setPlayMode(MediaPlayer::PlayMode_Normal);
				break;
		}
	}while(FALSE);

	return iOutRet;
}

INT_t CVideoSync::OnPlaybackEos()
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;

	LOG_INFO("%s()\n",__func__);

	do{
		if( m_oMediaSrv_sp.isNull() ){
			iOutRet = iRet = ERROR_INVALID_PARAMETER;
			LOG_ERROR("iRet=%d\n",iRet);
			break;
		}

		if( VidSyncMode_MASTER == m_eVideoSyncMode ){/*Video Sync Master Mode tell slave to stop*/
			iRet = OnMasterStopPlay();
			if( ERROR_SUCCESS != iRet ){
				LOG_ERROR("iRet=%d\n",iRet);
				iOutRet = iRet;
				break;
			}
		}else if( VidSyncMode_SLAVE == m_eVideoSyncMode ){/*Video Sync Slave Mode*/

		}else{/*Normal*/

		}
	}while(FALSE);

	return iOutRet;
}

INT_t CVideoSync::OnCommRegFromSlave(UINT32_t uIpAddr,p_tVideoSyncCommCmdReg pCmdReg)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	IP_SLAVE_LIST_MAP::iterator itList;
	SharedPtr <CVideoSyncSlaveInfo> slaveInfo_sp;

	//LOG_INFO("%s()\n",__func__);

	do{
		if( NULL == pCmdReg ){
			iOutRet = ERROR_INVALID_PARAMETER;
			break;
		}

		if( VidSyncMode_MASTER != m_eVideoSyncMode ){/*Video Sync Master Mode*/
			iOutRet = iRet = ERROR_INVALID_STATE;
			LOG_ERROR("iRet=%d\n",iRet);
			break;
		}

		itList = m_SlaveListMap.find(uIpAddr);
		if( m_SlaveListMap.end() != itList ){
			slaveInfo_sp = itList->second;
		}else{
			slaveInfo_sp = SharedPtr <CVideoSyncSlaveInfo> (new CVideoSyncSlaveInfo);
			if( slaveInfo_sp.isNull() ){
				LOG_ERROR("out of memory\n");
				iOutRet = ERROR_OUT_OF_MEMORY;
				break;
			}
			m_SlaveListMap[uIpAddr] = slaveInfo_sp;
		}

		if( slaveInfo_sp.isNull() ){
			LOG_ERROR("out of memory\n");
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}

		slaveInfo_sp->m_SlaveInfo.LastTickMs = GetSysUpTimeMs();
		slaveInfo_sp->m_SlaveInfo.SlaveState = pCmdReg->SlaveState;
	}while(FALSE);

	return iOutRet;
}

INT_t CVideoSync::OnCommUnRegFromSlave(UINT32_t uIpAddr)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;

	LOG_INFO("%s()\n",__func__);

	do{
		if( VidSyncMode_MASTER != m_eVideoSyncMode ){/*Video Sync Master Mode*/
			iOutRet = iRet = ERROR_INVALID_STATE;
			LOG_ERROR("iRet=%d\n",iRet);
			break;
		}

		m_SlaveListMap.erase(uIpAddr);
	}while(FALSE);

	return iOutRet;
}

INT_t CVideoSync::OnCommPrepareToPlayFromMaster(p_tVideoSyncCommCmdPrepareToPlay pCmdPrepareToPlay)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	UINT32_t PlaybackId=0;
	CMediaSrv::PLAY_PARAMS PlayParams = { 0 };
	MediaPlayer::PlayMode ePlayMode=MediaPlayer::PlayMode_Stopped;

	LOG_INFO("%s()\n",__func__);

	do{
		if( m_oMediaSrv_sp.isNull() ){
			iOutRet = iRet = ERROR_INVALID_PARAMETER;
			LOG_ERROR("iRet=%d\n",iRet);
			break;
		}

		if( NULL == pCmdPrepareToPlay ){
			iOutRet = iRet = ERROR_INVALID_PARAMETER;
			LOG_ERROR("iRet=%d\n",iRet);
			break;
		}

		if( NULL == pCmdPrepareToPlay->strURL ){
			iOutRet = iRet = ERROR_INVALID_PARAMETER;
			LOG_ERROR("iRet=%d\n",iRet);
			break;
		}

		if( VidSyncMode_SLAVE != m_eVideoSyncMode ){/*Video Sync Slave Mode*/
			iOutRet = iRet = ERROR_INVALID_STATE;
			LOG_ERROR("iRet=%d\n",iRet);
			break;
		}

		iRet = m_oMediaSrv_sp->getPlayMode(OUT ePlayMode);
		if( ERROR_SUCCESS != iRet ){
			LOG_ERROR("iRet=%d\n",iRet);
			iOutRet = iRet;
			break;
		}

		if( MediaPlayer::PlayMode_Stopped != ePlayMode ){
			iRet = m_oMediaSrv_sp->Stop();
			if( ERROR_SUCCESS != iRet ){
				LOG_ERROR("iRet=%d\n",iRet);
				iOutRet = iRet;
				break;
			}
		}

		iRet = m_oMediaSrv_sp->setDataSource((LPCSTR)(pCmdPrepareToPlay->strURL));
		if( ERROR_SUCCESS != iRet ){
			LOG_ERROR("iRet=%d\n",iRet);
			iOutRet = iRet;
			break;
		}

		iRet = m_oMediaSrv_sp->Prepare();
		if( ERROR_SUCCESS != iRet ){
			LOG_ERROR("iRet=%d\n",iRet);
			iOutRet = iRet;
			break;
		}

		PlayParams.LoopCount =  1;
		PlayParams.bPauseAfterBuffering = TRUE;

		iRet = m_oMediaSrv_sp->Play(&PlaybackId,&PlayParams);
		if( ERROR_SUCCESS != iRet ){
			LOG_ERROR("iRet=%d\n",iRet);
			iOutRet = iRet;
			break;
		}

		m_CurrentState = eVideoSyncState_PrepareToPlay;
		LOG_INFO("SLAVE URL: \"%s\"\n",pCmdPrepareToPlay->strURL);
	}while(FALSE);

	return iOutRet;
}

INT_t CVideoSync::OnCommReadyToPlayFromSlave(UINT32_t uIpAddr,p_tVideoSyncCommCmdReadyToPlay pCmdReadyToPlay)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	SharedPtr <CVideoSyncSlaveInfo> slaveInfo_sp;
	IP_SLAVE_LIST_MAP::iterator itList;

	LOG_INFO("%s()\n",__func__);

	do{
		if( m_oMediaSrv_sp.isNull() ){
			iOutRet = iRet = ERROR_INVALID_PARAMETER;
			LOG_ERROR("iRet=%d\n",iRet);
			break;
		}

		if( NULL == pCmdReadyToPlay ){
			iOutRet = iRet = ERROR_INVALID_PARAMETER;
			LOG_ERROR("iRet=%d\n",iRet);
			break;
		}

		if( VidSyncMode_MASTER != m_eVideoSyncMode ){/*Video Sync Master Mode*/
			iOutRet = iRet = ERROR_INVALID_STATE;
			LOG_ERROR("iRet=%d\n",iRet);
			break;
		}

		if( eVideoSyncState_Idle == m_CurrentState ){
			iOutRet = iRet = ERROR_INVALID_STATE;
			LOG_ERROR("iRet=%d\n",iRet);
			break;
		}

		itList = m_SlaveListMap.find(uIpAddr);
		if( m_SlaveListMap.end() != itList ){
			slaveInfo_sp = itList->second;
			if( slaveInfo_sp.isValid() ){
				slaveInfo_sp->m_SlaveInfo.SlaveState = eVideoSyncState_ReadyToPlay;
				if( m_UnReadyToPlaySlaveCount ){
					m_UnReadyToPlaySlaveCount--;
				}
				if( (eVideoSyncState_ReadyToPlay == m_CurrentState ) &&
					(0 == m_UnReadyToPlaySlaveCount) ){/*a last slave is ready OK*/
					iRet = OnMasterStartPlay();
					if( ERROR_SUCCESS != iRet ){
						LOG_ERROR("iRet=%d\n",iRet);
						iOutRet = iRet;
						break;
					}
				}
			}
		}
	}while(FALSE);

	return iOutRet;
}

INT_t CVideoSync::OnCommStartPlayFromMaster(p_tVideoSyncCommCmdStartPlay pCmdStartPlay)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;

	LOG_INFO("%s()\n",__func__);

	do{
		if( m_oMediaSrv_sp.isNull() ){
			iOutRet = iRet = ERROR_INVALID_PARAMETER;
			LOG_ERROR("iRet=%d\n",iRet);
			break;
		}

		if( NULL == pCmdStartPlay ){
			iOutRet = iRet = ERROR_INVALID_PARAMETER;
			LOG_ERROR("iRet=%d\n",iRet);
			break;
		}

		if( VidSyncMode_SLAVE != m_eVideoSyncMode ){/*Video Sync Slave Mode*/
			iOutRet = iRet = ERROR_INVALID_STATE;
			LOG_ERROR("iRet=%d\n",iRet);
			break;
		}

		if( eVideoSyncState_Idle == m_CurrentState ){
			iOutRet = iRet = ERROR_INVALID_STATE;
			LOG_ERROR("m_CurrentState=%d\n",m_CurrentState);
			break;
		}

#if EXACTLY_CHECK_STATE_FOR_START
		if( eVideoSyncState_ReadyToPlay != m_CurrentState ){
			iOutRet = iRet = ERROR_INVALID_STATE;
			LOG_ERROR("m_CurrentState=%d\n",m_CurrentState);
			break;
		}
#endif

		iRet = m_oMediaSrv_sp->setPlayMode(MediaPlayer::PlayMode_Normal);
		if( ERROR_SUCCESS != iRet ){
			LOG_ERROR("iRet=%d\n",iRet);
			iOutRet = iRet;
			break;
		}

		m_CurrentState = eVideoSyncState_Running;
		LOG_INFO("SlaveStartPlay\n");
	}while(FALSE);

	return iOutRet;
}

INT_t CVideoSync::OnCommPlayingInfoFromMaster(p_tVideoSyncCommCmdPlayingInfo pCmdPlayingInfo)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;

	LOG_INFO("%s()\n",__func__);

	do{
		if( m_oMediaSrv_sp.isNull() ){
			iOutRet = iRet = ERROR_INVALID_PARAMETER;
			LOG_ERROR("iRet=%d\n",iRet);
			break;
		}

		if( NULL == pCmdPlayingInfo ){
			iOutRet = iRet = ERROR_INVALID_PARAMETER;
			LOG_ERROR("iRet=%d\n",iRet);
			break;
		}

		if( VidSyncMode_SLAVE != m_eVideoSyncMode ){/*Video Sync Slave Mode*/
			iOutRet = iRet = ERROR_INVALID_STATE;
			LOG_ERROR("iRet=%d\n",iRet);
			break;
		}

	}while(FALSE);

	return iOutRet;
}

INT_t CVideoSync::OnCommStopPlayFromMaster(p_tVideoSyncCommCmdStopPlay pCmdStopPlay)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;

	LOG_INFO("%s()\n",__func__);

	do{
		if( m_oMediaSrv_sp.isNull() ){
			iOutRet = iRet = ERROR_INVALID_PARAMETER;
			LOG_ERROR("iRet=%d\n",iRet);
			break;
		}

		if( NULL == pCmdStopPlay ){
			iOutRet = iRet = ERROR_INVALID_PARAMETER;
			LOG_ERROR("iRet=%d\n",iRet);
			break;
		}

		if( VidSyncMode_SLAVE != m_eVideoSyncMode ){/*Video Sync Slave Mode*/
			iOutRet = iRet = ERROR_INVALID_STATE;
			LOG_ERROR("iRet=%d\n",iRet);
			break;
		}

		iRet = m_oMediaSrv_sp->Stop();
		if( ERROR_SUCCESS != iRet ){
			LOG_ERROR("iRet=%d\n",iRet);
			iOutRet = iRet;
			break;
		}

		m_CurrentState = eVideoSyncState_Idle;
	}while(FALSE);

	return iOutRet;
}

INT_t CVideoSync::OnCommVideoSyncRead()
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	BYTE szRecvBuf[VIDEO_SYNC_COMM_MAX_PACKET_LEN];
	INT_t iBytesRead;
	SOCKADDR_IN SckAddrIn;
	socklen_t SckAddrLen;
	p_tVideoSyncCommCmdHead pCmd;

	//LOG_INFO("%s()\n",__func__);

	do{
		SckAddrLen = sizeof(SckAddrIn);
		iRet = m_sckVideoSyncComm.RecvFrom(szRecvBuf, sizeof(szRecvBuf), 0, (P_SOCKADDR)(&SckAddrIn), &SckAddrLen);
		if(0 == iRet){/*udp zero-length packet*/
			LOG_ERROR("Recv error %d\n",m_sckVideoSyncComm.GetLastLocalErrNo());
			iOutRet = ERROR_SOCKET_RECV_FAIL;
			break;
		}

		if(0 > iRet){/*SOCKET_ERROR*/
			if(EAGAIN == errno || EWOULDBLOCK == errno || EINTR == errno){
				LOG_ERROR("Recv error %d(%s)\n",errno,strerror(errno));
				iOutRet = ERROR_SOCKET_RECV_FAIL;
				break;
			}else{/*fatal error*/
				LOG_ERROR("Recv fatal %d(%s)\n",errno,strerror(errno));
				iOutRet = ERROR_SOCKET_RECV_FAIL;
				iRet = StopVideoSync();
				if(ERROR_SUCCESS != iRet){
					LOG_ERROR("iRet=%d\n",iRet);
					iOutRet = iRet;
				}
				break;
			}
		}

		if(SckAddrLen != sizeof(SckAddrIn)){
			LOG_ERROR("Recv invalid packet,ScdAddrLen=%d,sizeof(SckAddrIn)=%d,sourceAddr=%s\n", SckAddrLen, sizeof(SckAddrIn),inet_ntoa(SckAddrIn.sin_addr));
			iOutRet = ERROR_SOCKET_RECV_FAIL;
			break;
		}

		/*Parse the packet*/
		iBytesRead = iRet;
		if( iBytesRead < sizeof(tVideoSyncCommCmdHead) ){
#if 0/*for debug*/
			LOG_ERROR("Recved invalid packet head,iBytesRead=%d,PacketCommHeadLength=%d,sourceAddr=%s\n", iBytesRead, sizeof(tVideoSyncCommCmdHead),inet_ntoa(SckAddrIn.sin_addr));
			iOutRet = ERROR_SOCKET_RECV_FAIL;
#endif
			break;
		}

		pCmd = (p_tVideoSyncCommCmdHead)(&szRecvBuf);
		if( pCmd->Magic != VIDEO_SYNC_COMM_MAGIC ){
			LOG_ERROR("Unrecognized packet, Magic: 0x%08x != 0x%08x,sourceAddr=%s\n", pCmd->Magic, VIDEO_SYNC_COMM_MAGIC,inet_ntoa(SckAddrIn.sin_addr));
			iOutRet = ERROR_SOCKET_RECV_FAIL;
			break;
		}

		if( ( iBytesRead != ( sizeof(tVideoSyncCommCmdHead) + pCmd->DataLen ) ) ){
			LOG_ERROR("Recved invalid packet,iBytesRead=%d,PacketLength=%d,sourceAddr=%s\n", iBytesRead, sizeof(tVideoSyncCommCmdHead) + pCmd->DataLen,inet_ntoa(SckAddrIn.sin_addr));
			iOutRet = ERROR_SOCKET_RECV_FAIL;
			break;
		}

		UINT32_t SourceIpAddr = /*ntohl*/(SckAddrIn.sin_addr.s_addr);
		UINT32_t MasterIpAddr = /*ntohl*/(m_sckaddrVidSyncMaster.sin_addr.s_addr);

		/*Process Action*/
		switch ( m_eVideoSyncMode ){
			case VidSyncMode_MASTER:
				switch( pCmd->Cmd ){
					case eVideoSyncCmd_Reg:
						iOutRet = OnCommRegFromSlave(SourceIpAddr,(p_tVideoSyncCommCmdReg)pCmd);
						break;
					case eVideoSyncCmd_UnReg:
						iOutRet = OnCommUnRegFromSlave(SourceIpAddr);
						break;
					case eVideoSyncCmd_ReadyToPlay:
						iOutRet = OnCommReadyToPlayFromSlave(SourceIpAddr,(p_tVideoSyncCommCmdReadyToPlay)pCmd);
						break;
					default:
#if 0/*for debug*/
						LOG_INFO("Unrecognized command(%d) on VideoSyncMasterMode,sourceAddr=%s\n",pCmd->Cmd,inet_ntoa(SckAddrIn.sin_addr));
						iOutRet = ERR_INVALID_CMD;
#endif
						break;
				}
				break;
			case VidSyncMode_SLAVE:
				if( SourceIpAddr != MasterIpAddr ){
#if 0/*for debug*/
					LOG_INFO("Unrecognized Master(%s), My Master(%s)\n",inet_ntoa(SckAddrIn.sin_addr),inet_ntoa(m_sckaddrVidSyncMaster.sin_addr));
					iOutRet = ERROR_INVALID_PARAMETER;
#endif
					break;
				}
				switch( pCmd->Cmd ){
					case eVideoSyncCmd_PrepareToPlay:
						iOutRet = OnCommPrepareToPlayFromMaster((p_tVideoSyncCommCmdPrepareToPlay)pCmd);
						break;
					case eVideoSyncCmd_StartPlay:
						iOutRet = OnCommStartPlayFromMaster((p_tVideoSyncCommCmdStartPlay)pCmd);
						break;
					case eVideoSyncCmd_PlayingInfo:
						iOutRet = OnCommPlayingInfoFromMaster((p_tVideoSyncCommCmdPlayingInfo)pCmd);
						break;
					case eVideoSyncCmd_StopPlay:
						iOutRet = OnCommStopPlayFromMaster((p_tVideoSyncCommCmdStopPlay)pCmd);
						break;
					default:
#if 0/*for debug*/
						LOG_INFO("Unrecognized command(%d) on VideoSyncSlaveMode,sourceAddr=%s\n",pCmd->Cmd,inet_ntoa(SckAddrIn.sin_addr));
						iOutRet = ERR_INVALID_CMD;
#endif
						break;
				}
				break;
			default:
				break;
		}
	}while(FALSE);

	return iOutRet;
}
