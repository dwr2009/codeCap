/*
 *
 * Copyright (c) Sigma Designs, Inc. 2003. All rights reserved.
 *
 */

/**
	@file get_key.h
	@brief non-blocking character read from terminal

	@author Christian Wolff
*/

/*
  **********************************************
  DISCLAIMER:

  - THIS IS TEST CODE, provided as sample code
  to help you understand what you should do to
  develop your own application based in RMFP.

  - This is NOT production grade code; It is not
  even a library, so any API defined here, CAN
  and WILL CHANGE without notice.

  **********************************************
*/

#ifndef __GET_KEY_H__
#define __GET_KEY_H__

#include <rmdef/rmdef.h>

RM_EXTERN_C_BLOCKSTART


/**
   initialize the terminal to pass keypresses directly, without echo
   and to ignore ctrl-C.

   @param block_int  TRUE: block ctrl-C, FALSE: issue SIGINT on ctrl-C
   @param use_term   TRUE: no need to press ENTER, FALSE: regular input mode
*/
void RMTermInit(RMbool block_int, RMbool use_term);

/**
   undo the terminal initialization
*/
void RMTermExit(void);

/**
   catch all terminating signals and call a termination function instead
   RMTermExit() is always called, cleanup() only if pointer is non-zero.

   @param cleanup  function to handle signal occurence
   @param param
*/
void RMSignalInit(void (*cleanup)(void *param), void *param);

/**
   keypress availability

   NOTE:
   if "TimeOutInMicroSeconds == -1" then it will block indefinitely.

   @return TRUE if at least one character is available
*/
RMbool RMKeyAvailable(RMuint32 TimeOutInMicroSeconds);

/**
   keypress retreival

   @return value of the next keypress character, or '\\0' on error
*/
RMascii RMGetKey(void);
RMascii RMGetKeyExtended(RMbool* pIsSpecialChar);

/**
   retreive keypress character, if available

   @param pKey
   @return TRUE if *pKey contains next keypress character, FALSE on unavailable or error
*/
RMbool RMGetKeyNoWait(RMascii *pKey);

/**
   enable echo for a terminal
*/
void RMTermEnableEcho(void);

/**
   disable echo for a terminal
*/
void RMTermDisableEcho(void);

/**
   get a int32 from stdin

   @param data
*/
void RMTermGetInt32(RMint32 *data);

RM_EXTERN_C_BLOCKEND

#endif  // __GET_KEY_H__
