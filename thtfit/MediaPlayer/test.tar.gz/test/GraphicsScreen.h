#ifndef	_GRAPHICS_SCREEN_H_
#define	_GRAPHICS_SCREEN_H_

#include <SharedPtr.h>
#include <BaseTypeDef.h>
#include <ColorFormat.h>

using namespace CppBase;

namespace MediaPlayer
{

class CImageSurface
{
public:
	CImageSurface();
	virtual ~CImageSurface();
public:
	PBYTE m_pImgBufVirtAddr;
	COLOR_FORMAT_TYPE m_eColorFmtType;
	INT_t m_ImgWidth;
	INT_t m_ImgHeight;
};

class CGraphicsScreen
{
public:
	CGraphicsScreen();
	virtual ~CGraphicsScreen();
	virtual INT_t setMainImgSurface(SharedPtr <CImageSurface> MainImgSurface_sp);
private:
	SharedPtr <CImageSurface> m_MainImgSurface_sp;
};

}

#endif	//_GRAPHICS_SCREEN_H_
