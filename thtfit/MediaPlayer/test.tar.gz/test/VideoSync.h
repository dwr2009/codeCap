/*added by lxj 2012-12-28*/

#ifndef	_MP_VIDEO_SYNC_H_
#define	_MP_VIDEO_SYNC_H_

#ifndef	ALLOW_OS_CODE
#define	ALLOW_OS_CODE
#endif

#include <BaseTypeDef.h>
#include <SharedPtr.h>
#include <map>
#include <UdpSocket.h>
#include <SnmpCmdConv.h>
#include <FileDescriptorEventIf.h>
#include "MediaSrv.h"

using namespace Mp7xxCommon;
#ifdef	__cplusplus
namespace VideoSync{
#endif

#define	VIDEO_SYNC_COMM_PORT                    (5005)
#define VIDEO_SYNC_COMM_MAGIC                   (0xAAAA5555) /*1010101010101010 0101010101010101*/
#define VIDEO_SYNC_COMM_MAX_PACKET_LEN          (8*1024)
#define VIDEO_SYNC_COMM_MAX_URL_PATH_LEN        (256)

#define SLAVE_REG_TIMEROUT_MS                   (3*1000)
#define SLAVE_CHECK_ALIVE_MS                    ((SLAVE_REG_TIMEROUT_MS)+1000)
#define MASTER_WAITFOR_TIMEOUT_MS               (1*1000)

typedef enum{
	eVideoSyncState_Idle,
	eVideoSyncState_PrepareToPlay,
	eVideoSyncState_ReadyToPlay,
	eVideoSyncState_Running,
}eVideoSyncState;

typedef enum{
	eVideoSyncCmd_Nothing,
	eVideoSyncCmd_Reg,
	eVideoSyncCmd_UnReg,
	eVideoSyncCmd_PrepareToPlay,
	eVideoSyncCmd_ReadyToPlay,
	eVideoSyncCmd_StartPlay,
	eVideoSyncCmd_PlayingInfo,
	eVideoSyncCmd_StopPlay,
}eVideoSyncCommCmd;

typedef struct{
	UINT64_t LastTickMs;
	eVideoSyncState SlaveState;
}tVideoSyncSlaveInfo,*p_tVideoSyncSlaveInfo;

typedef struct{
	UINT32_t Magic;                /*Prevent port conflict from other communication also use the same ports, so the verify is not necessarily, the CRC depend on IP Protocol Stack*/
	UINT32_t DataLen;              /*Only the data lengths follow the CmdHead*/
	UINT32_t PacketSequenceNum;    /*Packet Sequence number, unique*/
	eVideoSyncCommCmd Cmd;         /*What's can i do*/
}tVideoSyncCommCmdHead,*p_tVideoSyncCommCmdHead;

#define PACKET_COMM_HEAD(pCmdHead,cmd){ \
	(pCmdHead)->CmdHead.Magic = VIDEO_SYNC_COMM_MAGIC; \
	(pCmdHead)->CmdHead.DataLen = sizeof(*(pCmdHead)) - sizeof(tVideoSyncCommCmdHead); \
	(pCmdHead)->CmdHead.PacketSequenceNum = m_VidSyncPacketSequenceNum++; \
	(pCmdHead)->CmdHead.Cmd = cmd; \
}

typedef struct{
	tVideoSyncCommCmdHead CmdHead;
	eVideoSyncState SlaveState;
}tVideoSyncCommCmdReg,*p_tVideoSyncCommCmdReg;

typedef struct{
	tVideoSyncCommCmdHead CmdHead;
}tVideoSyncCommCmdUnReg,*p_tVideoSyncCommCmdUnReg;

typedef struct{
	tVideoSyncCommCmdHead CmdHead;
	INT8 strURL[VIDEO_SYNC_COMM_MAX_URL_PATH_LEN];
}tVideoSyncCommCmdPrepareToPlay,*p_tVideoSyncCommCmdPrepareToPlay;

typedef struct{
	tVideoSyncCommCmdHead CmdHead;
}tVideoSyncCommCmdReadyToPlay,*p_tVideoSyncCommCmdReadyToPlay;

typedef struct{
	tVideoSyncCommCmdHead CmdHead;
}tVideoSyncCommCmdStartPlay,*p_tVideoSyncCommCmdStartPlay;

typedef struct{
	tVideoSyncCommCmdHead CmdHead;
}tVideoSyncCommCmdPlayingInfo,*p_tVideoSyncCommCmdPlayingInfo;

typedef struct{
	tVideoSyncCommCmdHead CmdHead;
}tVideoSyncCommCmdStopPlay,*p_tVideoSyncCommCmdStopPlay;

class CVideoSyncSlaveInfo
{
public:
	tVideoSyncSlaveInfo m_SlaveInfo;

public:
	CVideoSyncSlaveInfo();
	virtual ~CVideoSyncSlaveInfo();
};

typedef map < UINT32_t, SharedPtr <CVideoSyncSlaveInfo> > IP_SLAVE_LIST_MAP;

class CVideoSync : public ITimerListener, public IFileDescriptorEventIf
{
private:
	SharedPtr <CMediaSrv> m_oMediaSrv_sp;

	VIDEO_SYNC_MODE_t m_eVideoSyncMode;
	CString m_strVideoSyncMaster;

	bool m_bUdpActive;

	CUdpSocket m_sckVideoSyncComm;
	SOCKADDR_IN m_sckaddrVidSyncMaster;
	UINT16_t m_VidSyncPacketSequenceNum;

	UINT_t m_SlaveSendRegTimerId;
	UINT_t m_MasterWaitforTimerId;

	eVideoSyncState m_CurrentState;
	CString m_strURL;
	UINT_t m_UnReadyToPlaySlaveCount;

	IP_SLAVE_LIST_MAP m_SlaveListMap;

private:
	INT_t OpenUdp();
	INT_t CloseUdp();

	INT_t StartMasterMode();
	INT_t StartSlaveMode();

	INT_t StopMasterMode();
	INT_t StopSlaveMode();

	INT_t SlaveListClearAll();

	INT_t RegisterTimer(UINT_t &TimerId,INT_t TimeoutMs);
	INT_t UnregisterTimer(UINT_t &TimerId);

	INT_t MasterSendTo(LPBYTE pSendBuf, size_t iBufSize);
	INT_t SlaveSendTo(LPBYTE pSendBuf, size_t iBufSize);

	/*Communication*/
	INT_t OnCommVideoSyncRead();/*Socket FD*/

	INT_t OnCommRegFromSlave(UINT32_t uIpAddr,p_tVideoSyncCommCmdReg pCmdReg);
	INT_t OnCommUnRegFromSlave(UINT32_t uIpAddr);
	INT_t OnCommReadyToPlayFromSlave(UINT32_t uIpAddr,p_tVideoSyncCommCmdReadyToPlay pCmdReadyToPlay);

	INT_t OnCommPrepareToPlayFromMaster(p_tVideoSyncCommCmdPrepareToPlay pCmdPrepareToPlay);
	INT_t OnCommStartPlayFromMaster(p_tVideoSyncCommCmdStartPlay pCmdStartPlay);
	INT_t OnCommPlayingInfoFromMaster(p_tVideoSyncCommCmdPlayingInfo pCmdPlayingInfo);
	INT_t OnCommStopPlayFromMaster(p_tVideoSyncCommCmdStopPlay pCmdStopPlay);

	/*Video sync Slave*/
	INT_t OnSlaveSendRegToMasterTimer();
	INT_t OnSlaveReadyToPlay();

	/*Video sync Master*/
	INT_t OnMasterWaitforTimer();
	INT_t OnMasterTellSlavePrepareToPlay();

	INT_t OnMasterPrepareToPlay();
	INT_t OnMasterReadyToPlay();
	INT_t OnMasterStartPlay();
	INT_t OnMasterStopPlay();

public:
	WeakPtr <CVideoSync> m_this_wp;

public:
	virtual VOID OnTimer(UINT_t TimerId);/*Override ITimerListener*/
	virtual INT_t OnFdEvent(int iFd, CONST IFileDescriptorEventIf::FD_EVENT_FLAGS FdEvtFlags);/*Override IFileDescriptorEventIf*/

public:
	/*For MediaPlayer Interface*/
	CVideoSync(SharedPtr <CMediaSrv> oMediaSrv_sp);
	virtual ~CVideoSync();

	INT_t InitInstance();
	INT_t ExitInstance();

	VIDEO_SYNC_MODE_t getVideoSyncMode();
	CString getVideoSyncMaster();

	INT_t setVideoSyncMode(VIDEO_SYNC_MODE_t eVideoSyncMode);
	INT_t setVideoSyncMaster(CString strVideoSyncMaster);

	INT_t StartVideoSync();
	INT_t StopVideoSync();

	INT_t OnPlaybackReadyToPlay();
	INT_t OnPlaybackEos();

public:
	/*For User Interface*/
	INT_t OnUiSetDataSource(LPCSTR pszDataSrcUrl);
	INT_t OnUiPrepare();
	INT_t OnUiPlay(OUT UINT32_t * pPlaybackId = NULL, IN CMediaSrv::P_PLAY_PARAMS pPlayParams = NULL);
	INT_t OnUiStop(OUT UINT32_t * pPlaybackId = NULL, OUT CStackBufString * pStrUrl = NULL);
};

#ifdef	__cplusplus
}
#endif
#endif	//_MP_VIDEO_SYNC_H_