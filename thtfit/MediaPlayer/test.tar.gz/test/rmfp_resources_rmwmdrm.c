/*****************************************
 Copyright 2001-2007
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   rmfp_resources_rmwmdrm.c
  @brief


  @author Sebastian Frias Feltrer
  @date   2008-11-03
*/

#include "rmfp_internal.h"


#define LOCALDBG DISABLE


#define MAX_PATH_SIZE 1024


RMstatus rmfp_internal_get_rmwmdrm_handle_handler(void *pContext, struct RMLibPlayRMWMDRMProfile *pProfile, struct RMWMDRMHandle **ppRMWMDRMHandle)
{
	struct RMFPHandle *pHandle = NULL;
	RMstatus status = RM_OK;

	struct RMWMDRMProfile DRMProfile = { 0, };
	struct RMWMDRMResourcesProfile DRMResourcesProfile = { 0, };
	struct RMWMDRMResourcesRequired DRMResourcesRequired = { 0, };
	struct RMWMDRMResources DRMResources = { 0, };

	struct RMWMDRMHandle *pDRMHandle = NULL;

	RMascii PathToCertificates[MAX_PATH_SIZE];

	struct RMFPRMWMDRMProfile RMFPRMWMDRMProfile = { 0, };




	RMDBGLOG((LOCALDBG, "rmfp_internal_get_rmwmdrm_handle_handler()\n"));

	ASSERT_NULL_POINTER(pContext);
	ASSERT_NULL_POINTER(pProfile);
	ASSERT_NULL_POINTER(ppRMWMDRMHandle);

	pHandle = (struct RMFPHandle *)pContext;


	switch (pProfile->Type) {
	case RMWMDRM_type_Janus:
	case RMWMDRM_type_PlayReady: //bug 32090

		if (pHandle->profile.rmfp_get_rmwmdrm_profile_callback) {

			RMFPRMWMDRMProfile.Version                   = GET_VERSION_FROM_MAGIC(RMFP_RMWMDRM_PROFILE_VERSION);

			RMFPRMWMDRMProfile.pPathToCertificates       = &(PathToCertificates[0]);
			RMFPRMWMDRMProfile.PathToCertificatesMAXSIZE = MAX_PATH_SIZE;

			status = pHandle->profile.rmfp_get_rmwmdrm_profile_callback(pHandle->profile.callback_context,
										    pProfile->Type,
										    &RMFPRMWMDRMProfile);

			if (status != RM_OK) {
				RMNOTIFY((NULL, status, "Failed to get RMWMDRM profile from application\n"));
				goto exit;
			}
		}
		else {
#if 1
			status = RM_ERROR;
			RMNOTIFY((NULL, status, "Missing rmfp_get_rmwmdrm_profile_callback!, cannot get RMWMDRM profile\n"));
			goto exit;
#else

			RMDBGLOG((ENABLE, "Using default values for RMWMDRM profile\n"));

			RMFPRMWMDRMProfile.Flags               = RMWMDRM_flag_SW_decrypt;
			RMFPRMWMDRMProfile.FlashSector         = -1;
			RMFPRMWMDRMProfile.Slot                = 0;
			RMFPRMWMDRMProfile.WithPreload         = FALSE;
			RMFPRMWMDRMProfile.pPathToCertificates = NULL;
#endif
		}


		DRMProfile.Type                = pProfile->Type;
		DRMProfile.pRUA                = pHandle->profile.pRUA;

		DRMProfile.flags               = RMFPRMWMDRMProfile.Flags;
		DRMProfile.FlashSector         = RMFPRMWMDRMProfile.FlashSector;
		DRMProfile.Slot                = RMFPRMWMDRMProfile.Slot;
		DRMProfile.WithPreload         = RMFPRMWMDRMProfile.WithPreload;
		DRMProfile.pPathToCertificates = RMFPRMWMDRMProfile.pPathToCertificates;


		status = RMWMDRM_init_drm(&DRMProfile, &(pDRMHandle));
		if (status != RM_OK) {
			RMNOTIFY((NULL, status, "Failed to init RMWMDRM\n"));
			goto exit;
		}


		DRMResourcesProfile.PacketFIFOEntries = pProfile->PacketFIFOEntries;

		status = RMWMDRM_get_resources_required(pDRMHandle, &DRMResourcesProfile, &DRMResourcesRequired);
		if (status != RM_OK) {
			RMNOTIFY((NULL, status, "Failed to get resources for RMWMDRM\n"));
			goto exit;
		}


		// request resource allocation to the application

		DRMResources.pAddress = NULL;
		DRMResources.Size = 0;

		if (pHandle->profile.rmfp_rmwmdrm_resources_callback) {
			struct RMFPRMWMDRMResourcesProfile rmfp_resources = { 0, };

			rmfp_resources.Version = GET_VERSION_FROM_MAGIC(RMFP_RMWMDRM_RESOURCES_PROFILE_VERSION);

			rmfp_resources.Size = DRMResourcesRequired.Size;


			status = pHandle->profile.rmfp_rmwmdrm_resources_callback(pHandle->profile.callback_context,
										  &rmfp_resources);
			if (status != RM_OK) {
				RMNOTIFY((NULL, status, "Failed to get resources from application\n"));
				goto exit;
			}

			DRMResources.pAddress = (RMuint8*)rmfp_resources.Address;
		}

		if (!DRMResources.pAddress) {
			RMDBGLOG((ENABLE, "Let RMWMDRM allocate its resources\n"));

			DRMResources.Size = 0;

			pHandle->FreeRMWMDRMResources = FALSE;
		}
		else
			pHandle->FreeRMWMDRMResources = TRUE;


		status = RMWMDRM_set_resources(pDRMHandle, &DRMResourcesProfile, &DRMResources);
		if (status != RM_OK) {
			RMNOTIFY((NULL, status, "Failed to set resources for RMWMDRM\n"));
			goto exit;
		}

		*ppRMWMDRMHandle = pDRMHandle;

		break;

	case RMWMDRM_type_Cardea:
		// CARDEA is not supported this way since the application is supposed to pass the CARDEA handle
		status = RM_NOT_SUPPORTED;
		RMNOTIFY((NULL, status, "CARDEA NOT SUPPORTED\n"));
		break;
	};


 exit:
	return status;
}

RMstatus rmfp_internal_rmwmdrm_acquire_url_license(void *pContext, struct RMWMDRMURLHandle *pRMWMDRMURLHandle)
{
	struct RMFPHandle *pHandle = NULL;
	RMstatus status = RM_OK;

	RMDBGLOG((LOCALDBG, "rmfp_internal_rmwmdrm_acquire_url_license()\n"));

	ASSERT_NULL_POINTER(pContext);
	ASSERT_NULL_POINTER(pRMWMDRMURLHandle);

	pHandle = (struct RMFPHandle *)pContext;

	if (pHandle->profile.rmfp_rmwmdrm_url_acquire_license_callback) {
		struct RMFPRMWMDRMURLHandle URLHandle;

		URLHandle.pURLHandle = pRMWMDRMURLHandle;

		// callback the application
		status = pHandle->profile.rmfp_rmwmdrm_url_acquire_license_callback(pHandle->profile.callback_context,
										    &URLHandle);

		if (status == RM_NOTIMPLEMENTED) {
			RMDBGLOG((LOCALDBG, "Callback chose default handling for license acquisition\n"));
		}
		else {
			if (status != RM_OK) {
				RMNOTIFY((NULL, status, "Callback failed to acquire license\n"));
			}

			return status;
		}
	}

	// default handler
	status = RMWMDRM_url_acquire_license(pRMWMDRMURLHandle);
	if (status != RM_OK) {
		RMNOTIFY((NULL, status, "Failed to acquire license\n"));
	}

	return status;
}


RMstatus rmfp_internal_release_rmwmdrm_handle_handler(void *pContext, struct RMWMDRMHandle *pRMWMDRMHandle)
{
	struct RMFPHandle *pHandle = NULL;
	RMstatus status = RM_OK;

	RMDBGLOG((LOCALDBG, "rmfp_internal_release_rmwmdrm_handle_handler()\n"));

	ASSERT_NULL_POINTER(pContext);
	ASSERT_NULL_POINTER(pRMWMDRMHandle);

	pHandle = (struct RMFPHandle *)pContext;


	if (pHandle->FreeRMWMDRMResources) {
		struct RMWMDRMResources DRMResources = { 0, };

		status = RMWMDRM_get_resources(pRMWMDRMHandle, &DRMResources);
		if (status != RM_OK) {
			RMNOTIFY((NULL, status, "Failed to get resources from RMWMDRM lib\n"));
			goto exit;
		}

		// close the lib to mark the resources as unused
		status = RMWMDRM_close_drm(pRMWMDRMHandle);
		if (status != RM_OK)
			RMNOTIFY((NULL, status, "Failed to close RMWMDRM lib\n"));

		if (pHandle->profile.rmfp_release_rmwmdrm_resources_callback) {
			struct RMFPRMWMDRMResourcesProfile rmfp_resources = { 0, };

			rmfp_resources.Version  = GET_VERSION_FROM_MAGIC(RMFP_RMWMDRM_RESOURCES_PROFILE_VERSION);

			rmfp_resources.Address  = (RMuint32)DRMResources.pAddress;
			rmfp_resources.Size     = DRMResources.Size;

			status = pHandle->profile.rmfp_release_rmwmdrm_resources_callback(pHandle->profile.callback_context,
											  &rmfp_resources);
			if (status != RM_OK) {
				RMNOTIFY((NULL, status, "Failed to release resources from application\n"));
				goto exit;
			}
		}
		else {
			status = RM_ERROR;
			RMNOTIFY((NULL, status, "Missing rmfp_release_rmwmdrm_resources_callback!, cannot release resources\n"));
		}
	}
	else
		status = RMWMDRM_close_drm(pRMWMDRMHandle);

 exit:

	return status;
}

