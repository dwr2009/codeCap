#include "GraphicsScreen.h"
#include <BaseErrDef.h>

namespace MediaPlayer
{

CImageSurface::CImageSurface()
{
	m_pImgBufVirtAddr = NULL;
	m_eColorFmtType = COLOR_FMT_UNKNOWN;
	m_ImgWidth = 0;
	m_ImgHeight = 0;
}

CImageSurface::~CImageSurface()
{

}

CGraphicsScreen::CGraphicsScreen()
{
}

CGraphicsScreen::~CGraphicsScreen()
{
}

INT_t CGraphicsScreen::setMainImgSurface(SharedPtr <CImageSurface> MainImgSurface_sp)
{
	INT_t iOutRet = ERROR_SUCCESS;

	do
	{
		m_MainImgSurface_sp = MainImgSurface_sp;
	}while(FALSE);

	return iOutRet;
}

}

