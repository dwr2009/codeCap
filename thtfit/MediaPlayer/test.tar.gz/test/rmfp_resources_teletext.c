/*****************************************
 Copyright 2001-2007
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
*****************************************/
/**
   @file   rmfp_resources_teletext.c
   @brief


   @author Sebastian Frias Feltrer , Faizal Zakaria
   @date   2007-11-20

   @TODO:
   - Regroup the parser of TV decoder & Software decoder
   - Use 'data field for EBU Teletext'(as per spec ETSI EN 300 472)
     as the input parameter in the decoder function rather 'PES'
*/


#include "rmfp_internal.h"
#include <rmsofttxt/include/rmsofttxt.h>

#if 0
#define LOCALDBG ENABLE
#else
#define LOCALDBG DISABLE
#endif

#if 0
#define DEBUG_TTXDECODING ENABLE
#else
#define DEBUG_TTXDECODING DISABLE
#endif

#define TTX_BUFFER_SIZE 0x1000
#define EBU_LINE_COUNT 16 // per field
#define EBU_BYTES_PER_DATA_FIELD 44
#define EBU_SANE_BUF_SIZE ((EBU_BYTES_PER_DATA_FIELD+2)*EBU_LINE_COUNT + 10000000)

#define RMuint8mirrorBits( bits )					\
	( ( ((bits)&0x01)<<7 )  |  ( ((bits)&0x02)<<5 )  |  ( ((bits)&0x04)<<3 )  |  ( ((bits)&0x08)<<1 ) | \
	  ( ((bits)&0x10)>>1 )  |  ( ((bits)&0x20)>>3 )  |  ( ((bits)&0x40)>>5 )  |  ( ((bits)&0x80)>>7 )  )


struct RMFPTTXSource {
		struct RMFPSoftTXTRenderHandle *pSoftTXTRender;

		enum RMFPTeletextMode TeletextMode;
		RMuint32 unprotected_memory_address;
		RMuint32 unprotected_memory_size;
		RMbool free_unprotected;

		RMuint32 fifo_module_id;
		RMuint8 decode_buffer[TTX_BUFFER_SIZE];
		RMuint32 decode_buffer_size;
		struct EMhwlibTTXPicture current_ttx;

		RMuint32 DRAMIndex;
};


static RMstatus _rmfp_print_rmlibplay_teletext_profile(struct RMLibPlayTTXProfile *pTTXProfile);
static void _rmfp_teletext_init_picture(struct EMhwlibTTXPicture * pic);
static RMstatus _rmfp_teletext_decode_payload(struct RMFPTTXSource* pRMFPTTXSource, RMuint8* buf, RMuint32 size, RMuint64 pts );
static void _rmfp_teletext_ttx_data_field(RMuint8* buf, RMuint32 size, struct EMhwlibTTXPicture * pic);
static RMstatus _rmfp_internal_get_teletext_handler_vbi(void *pContext,
							struct RMLibPlayTTXSource *pTTXSource,
							struct RMLibPlayTTXProfile *pTTXProfile);

static RMstatus _rmfp_internal_get_teletext_handler_osd(void *pContext,
							struct RMLibPlayTTXSource *pTTXSource,
							struct RMLibPlayTTXProfile *pTTXProfile);
static RMstatus _rmfp_internal_release_teletext_handler_vbi(void *pContext, struct RMLibPlayTTXSource *pTTXSource);
static RMstatus _rmfp_internal_release_teletext_handler_osd(void *pContext, struct RMLibPlayTTXSource *pTTXSource);


static RMstatus _rmfp_internal_teletext_decode_vbi(void *pContext, struct RMLibPlayTTXSource *pTTXSource, RMuint8* buffer, RMuint32 buffer_size);
static RMstatus _rmfp_internal_teletext_decode_osd(void *pContext, struct RMLibPlayTTXSource *pTTXSource, RMuint8* buffer, RMuint32 buffer_size);

static RMstatus _rmfp_internal_teletext_flush_vbi(void *pContext, struct RMLibPlayTTXSource *pTTXSource);
static RMstatus _rmfp_internal_teletext_flush_osd(void *pContext, struct RMLibPlayTTXSource *pTTXSource);

RMstatus rmfp_internal_get_teletext_handler(void *pContext,
					    struct RMLibPlayTTXSource *pTTXSource,
					    struct RMLibPlayTTXProfile *pTTXProfile)
{
	struct RMFPHandle *pHandle = NULL;
	struct RMFPDemuxOptions *pDemuxOptions = NULL;
	struct RMFPTTXSource *pRMFPTTXSource = NULL;
	RMstatus status = RM_OK;
	ASSERT_NULL_POINTER(pContext);

	pHandle = (struct RMFPHandle *)pContext; 
	pDemuxOptions = &(pHandle->demux_options);
	RMDBGLOG((LOCALDBG, "rmfp_internal_get_teletext_handler %p\n", pDemuxOptions->TeletextMode));
	switch (pDemuxOptions->TeletextMode) {
	case RMFPTeletextMode_ShowInOSD:
		status = _rmfp_internal_get_teletext_handler_osd(pContext, pTTXSource, pTTXProfile);
		break;
	case RMFPTeletextMode_SendToTV:
		status = _rmfp_internal_get_teletext_handler_vbi(pContext, pTTXSource, pTTXProfile);		
		break;
	case RMFPTeletextMode_Disabled:
		return RM_OK;
	default:
		return RM_INVALID_PARAMETER;
	}

	pRMFPTTXSource = (struct RMFPTTXSource *)pTTXSource->source;
	pRMFPTTXSource->TeletextMode = pDemuxOptions->TeletextMode;
	
	return status; /* should not be there */
}

static RMstatus _rmfp_internal_get_teletext_handler_osd(void *pContext,
							struct RMLibPlayTTXSource *pTTXSource,
							struct RMLibPlayTTXProfile *pTTXProfile)
{

	RMDBGLOG((LOCALDBG, "rmfp_internal_get_teletext_handler_osd\n"));


	struct RMFPTTXSource *pRMFPTTXSource = NULL;
	struct RMFPHandle *pHandle = NULL;
	struct RMFPSoftTXTRenderProfile pRMFPTXTRenderProfile = {0, }; // create render profile


	ASSERT_NULL_POINTER(pContext);
	ASSERT_NULL_POINTER(pTTXSource);
	ASSERT_NULL_POINTER(pTTXProfile);

	pHandle = (struct RMFPHandle *)pContext;

	pRMFPTXTRenderProfile.pHandle = pHandle;
	pRMFPTXTRenderProfile.Version = 1;
	pRMFPTXTRenderProfile.UseMultipleBuffering = FALSE;

/* Allocate source (RMFPTTXSource)*/
	pRMFPTTXSource = (struct RMFPTTXSource *)RMMalloc(sizeof(struct RMFPTTXSource));
	if (!pRMFPTTXSource) {
		RMNOTIFY((NULL, RM_FATALOUTOFMEMORY, "Out of memory\n"));
		return RM_FATALOUTOFMEMORY;
	}
	RMMemset((void *)pRMFPTTXSource, 0, sizeof(struct RMFPTTXSource));
	pTTXSource->source = (void *)pRMFPTTXSource; // save RMFPTTXSource address to pTTXSource->source

	rmfp_internal_open_softtxt_render( &pRMFPTTXSource->pSoftTXTRender , &pRMFPTXTRenderProfile );


	return RM_OK;

}	

RMstatus _rmfp_internal_get_teletext_handler_vbi(void *pContext,
						 struct RMLibPlayTTXSource *pTTXSource,
						 struct RMLibPlayTTXProfile *pTTXProfile)
{
	struct RMFPHandle *pHandle = NULL;
	struct RMFPPlayOptions *pPlayOptions = NULL;
	struct RMFPTTXSource *pRMFPTTXSource = NULL;
	struct RMFPTTXResourcesProfile rmfp_teletext_resources_profile = { 0, };
	struct RUA *pRUA = NULL;
	struct DCC *pDCC = NULL;
	struct TTXFifo_Open_type teletext_profile;
	RMuint32 ttx_fifo_size = TTX_FIFO_SIZE;
	RMuint32 memorysize = 0;
	RMuint32 MixerModuleID = 0;
	RMstatus status;
	enum DCCRoute dcc_route;

	RMDBGLOG((LOCALDBG, "rmfp_internal_get_teletext_handler_vbi\n"));


	ASSERT_NULL_POINTER(pContext);
	ASSERT_NULL_POINTER(pTTXSource);
	ASSERT_NULL_POINTER(pTTXProfile);

	pHandle = (struct RMFPHandle *)pContext;
	pPlayOptions = &(pHandle->playback_options);
	pRUA = pHandle->profile.pRUA;
	pDCC = pHandle->profile.pDCC;

	/* Print profile */
	_rmfp_print_rmlibplay_teletext_profile(pTTXProfile);

	/* Allocate source */
	pRMFPTTXSource = (struct RMFPTTXSource *)RMMalloc(sizeof(struct RMFPTTXSource));
	if (!pRMFPTTXSource) {
		RMNOTIFY((NULL, RM_FATALOUTOFMEMORY, "Out of memory\n"));
		return RM_FATALOUTOFMEMORY;
	}

	RMMemset((void *)pRMFPTTXSource, 0, sizeof(struct RMFPTTXSource));

	/*
	 * Memory allocation
	 */

	/* Get needed size */
	status = RUAExchangeProperty(pRUA, EMHWLIB_MODULE(TTXFifo, 0), RMTTXFifoPropertyID_DRAMSize, &ttx_fifo_size, sizeof(ttx_fifo_size), &memorysize, sizeof(memorysize));
	if (status != RM_OK)
	{
		RMNOTIFY((NULL, status, "RMTTXFifoPropertyID_DRAMSize\n"));
		return status;
	}

	/* Fill resources profile and get resources from application */
	rmfp_teletext_resources_profile.Version                    = GET_VERSION_FROM_MAGIC(RMFP_TTX_RESOURCES_PROFILE_VERSION);

	rmfp_teletext_resources_profile.dram                       = pPlayOptions->DRAMIndex;

	rmfp_teletext_resources_profile.unprotected_memory_address = 0;
	rmfp_teletext_resources_profile.unprotected_memory_size    = memorysize;

	rmfp_teletext_resources_profile.STC_index                  = pPlayOptions->STCIndex + pPlayOptions->STCEngine*3;

	if (pHandle->profile.rmfp_teletext_resources_callback)
	{
		status = pHandle->profile.rmfp_teletext_resources_callback(pHandle->profile.callback_context, &rmfp_teletext_resources_profile);
		if (status != RM_OK)
		{
			RMNOTIFY((NULL, status, "Failed to get resources from application\n"));
			return status;
		}
	}

	if ((!rmfp_teletext_resources_profile.unprotected_memory_address) &&
	    (rmfp_teletext_resources_profile.unprotected_memory_size))
	{
		pRMFPTTXSource->unprotected_memory_address = DCCMalloc(	pDCC,
									rmfp_teletext_resources_profile.dram,
									RUA_DRAM_UNCACHED,
									rmfp_teletext_resources_profile.unprotected_memory_size);

		if (!pRMFPTTXSource->unprotected_memory_address)
		{
			RMNOTIFY((NULL, RM_FATALOUTOFMEMORY, "Can't allocate %lu bytes in DRAM %lu\n",
				    rmfp_teletext_resources_profile.unprotected_memory_size,
				    rmfp_teletext_resources_profile.dram));
			return RM_FATALOUTOFMEMORY;
		}
		else
			RMDBGLOG((LOCALDBG, "allocated %lu bytes for unprotected memory\n", rmfp_teletext_resources_profile.unprotected_memory_size));

		pRMFPTTXSource->free_unprotected = TRUE;
	}
	else
	{
		pRMFPTTXSource->unprotected_memory_address = rmfp_teletext_resources_profile.unprotected_memory_address;
		pRMFPTTXSource->free_unprotected = FALSE;
	}

	pRMFPTTXSource->unprotected_memory_size = rmfp_teletext_resources_profile.unprotected_memory_size;

	/* Now open the module */
	teletext_profile.EntryCount = ttx_fifo_size;
	teletext_profile.UncachedAddress = pRMFPTTXSource->unprotected_memory_address;
	teletext_profile.UncachedSize =  pRMFPTTXSource->unprotected_memory_size;
	teletext_profile.STCModuleId = 0; // does not use stc at the memont

	status = RUASetProperty(pRUA, EMHWLIB_MODULE(TTXFifo, 0), RMTTXFifoPropertyID_Open, &teletext_profile, sizeof(teletext_profile), 0);
	if (status != RM_OK)
	{
		RMNOTIFY((NULL, status, "RMTTXFifoPropertyID_Open\n"));
		return status;
	}

	/* Fill values */
	pRMFPTTXSource->fifo_module_id = EMHWLIB_MODULE(TTXFifo, 0);
	pRMFPTTXSource->decode_buffer_size = 0;
	_rmfp_teletext_init_picture(&pRMFPTTXSource->current_ttx);
	pRMFPTTXSource->DRAMIndex = rmfp_teletext_resources_profile.dram;

	/*
	 * Now link it to mixer
	 */
	
	/* Get route from application */
	status = rmfp_internal_get_route(pHandle, &dcc_route);
	if (status != RM_OK)
		return status;
	
	status = DCCGetMixerModuleID(pDCC, dcc_route, &MixerModuleID);
	if (status != RM_OK)
	{
		RMNOTIFY((NULL, status, "Cannot get MixerModuleID from route\n"));
		return status;
	}

	status = RUASetProperty(pRUA, MixerModuleID, RMGenericPropertyID_TTXFifo, &(pRMFPTTXSource->fifo_module_id), sizeof(RMuint32), 0);
	if (status != RM_OK)
	{
		RMNOTIFY((NULL, status, "RMGenericPropertyID_TTXFifo failed\n"));
		return status;
	}

	pTTXSource->source = (void *)pRMFPTTXSource;

	return RM_OK;


}

RMstatus rmfp_internal_release_teletext_handler(void *pContext, struct RMLibPlayTTXSource *pTTXSource)
{

	ASSERT_NULL_POINTER(pTTXSource);

	struct RMFPTTXSource * pRMFPTTXSource = (struct RMFPTTXSource *) pTTXSource->source;

	switch (pRMFPTTXSource->TeletextMode) {
	case RMFPTeletextMode_ShowInOSD:
		return _rmfp_internal_release_teletext_handler_osd(pContext, pTTXSource);
	case RMFPTeletextMode_SendToTV:
		return _rmfp_internal_release_teletext_handler_vbi(pContext, pTTXSource);
	case RMFPTeletextMode_Disabled:
		return RM_ERROR;
	default:
		return RM_INVALID_PARAMETER;
	}
	return RM_ERROR; /* should not be there */
}

static RMstatus _rmfp_internal_release_teletext_handler_osd(void *pContext, struct RMLibPlayTTXSource *pTTXSource)
{
	struct RMFPHandle * pHandle = NULL;
	struct RMFPTTXSource * pRMFPTTXSource = NULL;
	
   
	RMDBGLOG((ENABLE, "rmfp_internal_release_teletext_handler_osd()\n"));

	ASSERT_NULL_POINTER(pContext);
	ASSERT_NULL_POINTER(pTTXSource);
		
	pHandle = (struct RMFPHandle *) pContext;
	pRMFPTTXSource = (struct RMFPTTXSource *)pTTXSource->source;

	rmfp_internal_close_softtxt_render(pHandle);

	RMFree(pRMFPTTXSource);

	return RM_OK;
	
}

static RMstatus _rmfp_internal_release_teletext_handler_vbi(void *pContext, struct RMLibPlayTTXSource *pTTXSource)
{
	struct RMFPHandle *pHandle = NULL;
	struct RMFPTTXSource *pRMFPTTXSource = NULL;
	struct RUA *pRUA = NULL;
	struct DCC *pDCC = NULL;
	struct RMFPTTXResourcesProfile rmfp_teletext_resources_profile = { 0, };
	struct RMFPPlayOptions *pPlayOptions = NULL;
	RMstatus ReturnStatus = RM_OK;
	RMstatus status;

	RMDBGLOG((ENABLE, "rmfp_internal_release_teletext_handler_vbi()\n"));

	ASSERT_NULL_POINTER(pContext);
	ASSERT_NULL_POINTER(pTTXSource);

	pHandle = (struct RMFPHandle *)pContext;
	pRUA = pHandle->profile.pRUA;
	pDCC = pHandle->profile.pDCC;
	pRMFPTTXSource = (struct RMFPTTXSource *)pTTXSource->source;

	pPlayOptions = &(pHandle->playback_options);

	ASSERT_NULL_POINTER(pRMFPTTXSource);

	/* Close it */
	status = RUASetProperty(pRUA, pRMFPTTXSource->fifo_module_id, RMTTXFifoPropertyID_Close, 0, 0, 0);
	if (status != RM_OK)
		RMNOTIFY((NULL, status, "RMTTXFifoPropertyID_Close\n"));

	/* Free memory */
	if (pRMFPTTXSource->free_unprotected)
	{
		RMDBGLOG((LOCALDBG, "Free TTX unprotected memory at %p\n", pRMFPTTXSource->unprotected_memory_address));
		DCCFree(pDCC, pRMFPTTXSource->unprotected_memory_address);
		pRMFPTTXSource->unprotected_memory_address = 0;
		pRMFPTTXSource->unprotected_memory_size = 0;
	}

	/* Call application handler */
	rmfp_teletext_resources_profile.Version                    = GET_VERSION_FROM_MAGIC(RMFP_TTX_RESOURCES_PROFILE_VERSION);

	rmfp_teletext_resources_profile.dram                       = pRMFPTTXSource->DRAMIndex;

	rmfp_teletext_resources_profile.unprotected_memory_address = pRMFPTTXSource->unprotected_memory_address;
	rmfp_teletext_resources_profile.unprotected_memory_size    = pRMFPTTXSource->unprotected_memory_size;

	rmfp_teletext_resources_profile.STC_index                  = pPlayOptions->STCIndex + pPlayOptions->STCEngine*3;

	if (pHandle->profile.rmfp_release_teletext_resources_callback)
	{
		status = pHandle->profile.rmfp_release_teletext_resources_callback(pHandle->profile.callback_context, &rmfp_teletext_resources_profile);
		if (status != RM_OK)
		{
			RMNOTIFY((NULL, status, "Failed to get resources from application\n"));
			return status;
		}
	}

	/* Free source */
	RMFree(pRMFPTTXSource);

	return ReturnStatus;
}

RMstatus rmfp_internal_teletext_decode(void *pContext, struct RMLibPlayTTXSource *pTTXSource, RMuint8* buffer, RMuint32 buffer_size)
{
	ASSERT_NULL_POINTER(pTTXSource);
	struct RMFPTTXSource * pRMFPTTXSource = (struct RMFPTTXSource *) pTTXSource->source;
	
	/* Check source */
	ASSERT_NULL_POINTER(pTTXSource->source);
	
	RMDBGLOG((DISABLE, "rmfp_internal_teletext_decode %p\n", pRMFPTTXSource->TeletextMode));
 	
	switch (pRMFPTTXSource->TeletextMode) {
	case RMFPTeletextMode_ShowInOSD:
 		return _rmfp_internal_teletext_decode_osd(pContext, pTTXSource, buffer, buffer_size);
	case RMFPTeletextMode_SendToTV:
		return _rmfp_internal_teletext_decode_vbi(pContext, pTTXSource, buffer, buffer_size);
	case RMFPTeletextMode_Disabled:
		return RM_ERROR;
	default:
		return RM_INVALID_PARAMETER;

	}

	return RM_ERROR; /* should not be there */
}

static RMstatus _rmfp_internal_teletext_decode_osd(void *pContext, struct RMLibPlayTTXSource *pTTXSource, RMuint8* buffer, RMuint32 buffer_size)
{
  	RMDBGLOG((LOCALDBG, "rmfp_internal_teletext_decode_osd\n"));

	struct RMFPTTXSource *pRMFPTTXSource = NULL;
	
	ASSERT_NULL_POINTER(pContext);
	ASSERT_NULL_POINTER(pTTXSource);

	/* put parser here */
	

	pRMFPTTXSource = (struct RMFPTTXSource *)pTTXSource->source;


	return rmfp_internal_softtxt_render_decode(pRMFPTTXSource->pSoftTXTRender, buffer, buffer_size);
}

static RMstatus _rmfp_internal_teletext_decode_vbi(void *pContext, struct RMLibPlayTTXSource *pTTXSource, RMuint8* buffer, RMuint32 buffer_size)
{

	struct RMFPHandle *pHandle = NULL;
	struct RMFPTTXSource *pRMFPTTXSource = NULL;
	struct RUA *pRUA = NULL;
	RMstatus status = RM_OK;

	RMDBGLOG((DISABLE, "rmfp_internal_teletext_decode\n"));
	ASSERT_NULL_POINTER(pContext);
	ASSERT_NULL_POINTER(pTTXSource);

	pHandle = (struct RMFPHandle *)pContext;
	pRUA = pHandle->profile.pRUA;
	pRMFPTTXSource = (struct RMFPTTXSource *) pTTXSource->source;

	ASSERT_NULL_POINTER(pRMFPTTXSource);
	ASSERT_NULL_POINTER(pRUA);

	/* if there is left over from last time use the leftover first */
	if (pRMFPTTXSource->decode_buffer_size )
	{
		if( buffer_size+pRMFPTTXSource->decode_buffer_size <= TTX_BUFFER_SIZE )
		{
			RMMemcpy( pRMFPTTXSource->decode_buffer+pRMFPTTXSource->decode_buffer_size, buffer, buffer_size );
			buffer = pRMFPTTXSource->decode_buffer;
			buffer_size += pRMFPTTXSource->decode_buffer_size;
		}
		else
			RMDBGLOG((DEBUG_TTXDECODING, "rmlibplay_demux_common_ttx_decode out of buffer space size %d \n", buffer_size+pRMFPTTXSource->decode_buffer_size ));

		pRMFPTTXSource->decode_buffer_size = 0;
	}

	/* decode a buffer with multiple PES packet */
	while (buffer_size > 0 )
	{
		RMuint32 length = 0;
		RMuint64 pts = 0;

		/* less than minimum PES length */
		if( buffer_size < 6 )
			return RM_ERROR;

		while( ! (buffer[0]==0x00 && buffer[1]==0x00 && buffer[2]==0x01 && buffer[3]==0xbd) )
		{
			buffer++;
			buffer_size--;
			if( buffer_size < 6 )
			{
				RMDBGLOG((DEBUG_TTXDECODING, "rmlibplay_demux_common_ttx_decode Error No PES sync\n"));
				return RM_OK;
			}
		}

		buffer += 4;
		buffer_size -= 4;
		length = ((RMuint32)buffer[0] << 8) | (RMuint32)buffer[1] ;

		RMDBGLOG((DEBUG_TTXDECODING, "rmlibplay_demux_common_ttx_decode PES packet length %ld  buffer_size %ld \n", length, buffer_size));

		buffer += 2;
		buffer_size -= 2;

		/* incomplete pes */
		if( buffer_size < length )
		{
			buffer_size += 6;
			RMDBGLOG((DEBUG_TTXDECODING, "rmlibplay_demux_common_ttx_decode imcomplete PES packet, keep data in the decode buffer, buffer_size %d \n", buffer_size));
			RMMemcpy(pRMFPTTXSource->decode_buffer, buffer-6, buffer_size);
			pRMFPTTXSource->decode_buffer_size = buffer_size;
			return RM_OK;
		}

		/*
		 * get pts
		 */

		/* pts exist */
		if( buffer[1] & 0x80 )
		{
			pts = ( (RMuint64)(buffer[3] & 0x0e) << 30 ) // bit 32:30  3
			| ( (RMuint64)(buffer[4] & 0xff) << 22 ) // bit 29:22  8
			| ( (RMuint64)(buffer[5] & 0xfe) << 15 ) // bit 21:15  7
			| ( (RMuint64)(buffer[6] & 0xff) << 7  ) // bit 14:7   8
			| ( (RMuint64)(buffer[7] & 0xfe) >> 1  );// bit  6:0   7

			RMDBGLOG((DEBUG_TTXDECODING, "rmlibplay_demux_common_ttx_decode PES pts 0x%llx\n", pts));
		}
		else
			RMDBGLOG((DEBUG_TTXDECODING, "rmlibplay_demux_common_ttx_decode Error No PTS\n"));

		pRMFPTTXSource->current_ttx.pts = pts;

		if (_rmfp_teletext_decode_payload(pRMFPTTXSource, buffer+(buffer[2]+3), length-(buffer[2]+3), pts ) != RM_OK)
		{
			RMDBGLOG((ENABLE, "rmlibplay_demux_common_ttx_decode payload error\n"));
			return RM_ERROR;
		}

		if( pRMFPTTXSource->current_ttx.fields[0].line_mask != 0 )
		{
			struct EMhwlibTTXPicture *pic = &(pRMFPTTXSource->current_ttx);

			/* Notify application if possible, else send it to fifo */
			if (pHandle->profile.rmfp_teletext_entry_callback)
			{
				status = pHandle->profile.rmfp_teletext_entry_callback(pHandle->profile.callback_context, pic);
				if (status != RM_OK)
				{
					RMNOTIFY((NULL, status, "Failed to signal a new teletext picture to the application\n"));
					return status;
				}
			}
			else
			{

				status = RUASetProperty(pRUA, pRMFPTTXSource->fifo_module_id, RMTTXFifoPropertyID_TTXPicture, pic, sizeof(*pic), 0);
				if (status != RM_OK)
				{
					RMNOTIFY((NULL, status, "RMTTXFifoPropertyID_TTXPicture\n"));
					return status;
				}
			}

			RMDBGLOG((DEBUG_TTXDECODING, "TTX decoded pts:0x%llx fc:0x%x mask1 0x%lx mask0 0x%lx\n",
				  pRMFPTTXSource->current_ttx.pts,
				  pRMFPTTXSource->current_ttx.fields[1].framing_code,
				  pRMFPTTXSource->current_ttx.fields[1].line_mask,
				  pRMFPTTXSource->current_ttx.fields[0].line_mask  ));

			/* clean the memory contents */
			_rmfp_teletext_init_picture(&pRMFPTTXSource->current_ttx);
		}

		buffer += length;
		buffer_size -= length;
	}

	return RM_OK;
}

RMstatus rmfp_internal_teletext_flush(void *pContext, struct RMLibPlayTTXSource *pTTXSource)
{

	ASSERT_NULL_POINTER(pTTXSource);
	struct RMFPTTXSource * pRMFPTTXSource = (struct RMFPTTXSource *) pTTXSource->source;
	switch (pRMFPTTXSource->TeletextMode) {
	case RMFPTeletextMode_ShowInOSD:
		RMDBGLOG((LOCALDBG, "FLUSH OSD\n"));
		return _rmfp_internal_teletext_flush_osd(pContext, pTTXSource);
	case RMFPTeletextMode_SendToTV:
		RMDBGLOG((LOCALDBG, "FLUSH TV\n"));
		return _rmfp_internal_teletext_flush_vbi(pContext, pTTXSource);
	case RMFPTeletextMode_Disabled:
		RMDBGLOG((LOCALDBG, "FLUSH DISABLED\n"));
		return RM_ERROR;
	default:
		return RM_INVALID_PARAMETER;

	}
	return RM_ERROR; /* should not be there */
}

RMstatus _rmfp_internal_teletext_flush_osd(void *pContext, struct RMLibPlayTTXSource *pTTXSource) 
{
	ASSERT_NULL_POINTER(pTTXSource);
	ASSERT_NULL_POINTER(pContext);

	RMDBGLOG((LOCALDBG, "rmfp_internal_teletext_flush_osd\n"));

	struct RMFPHandle *pHandle = NULL;
	pHandle = (struct RMFPHandle *)pContext;
		
	return RM_OK;
}

RMstatus _rmfp_internal_teletext_flush_vbi(void *pContext, struct RMLibPlayTTXSource *pTTXSource) 
{
	struct RMFPHandle *pHandle = NULL;
	struct RMFPTTXSource *pRMFPTTXSource = NULL;
	struct RUA *pRUA = NULL;
	RMstatus status = RM_OK;

	RMDBGLOG((DISABLE, "rmfp_internal_teletext_decode\n"));

	ASSERT_NULL_POINTER(pContext);
	ASSERT_NULL_POINTER(pTTXSource);

	pHandle = (struct RMFPHandle *)pContext;
	pRUA = pHandle->profile.pRUA;
	pRMFPTTXSource = (struct RMFPTTXSource *)pTTXSource->source;

	ASSERT_NULL_POINTER(pRMFPTTXSource);
	ASSERT_NULL_POINTER(pRUA);

	pRMFPTTXSource->decode_buffer_size = 0;

	status = RUASetProperty(pRUA, pRMFPTTXSource->fifo_module_id, RMTTXFifoPropertyID_Flush, 0, 0, 0);
	if (status != RM_OK)
	{
		RMNOTIFY((NULL, status, "RMTTXFifoPropertyID_Flush\n"));
		return status;
	}

	return RM_OK;
}

static RMstatus _rmfp_print_rmlibplay_teletext_profile(struct RMLibPlayTTXProfile *pTTXProfile)
{
	ASSERT_NULL_POINTER(pTTXProfile);

	return RM_OK;
}

static void _rmfp_teletext_init_picture(struct EMhwlibTTXPicture * pic)
{
	RMuint32 i;

	for( i=0; i<2 ; i++ )
	{
		pic->fields[i].field_parity = 0xff;
		pic->fields[i].framing_code = 0xff;
		pic->fields[i].line_mask = 0x00000000;
		RMMemset( (void*)(pic->fields[i].data), 0, TTX_MAX_LINES*TTX_MAX_BYTES_PER_LINE );
		pic->fields[i].display_flags = 0x00000000;
	}

	pic->pts = 0;
}

/* etsi en 300 472 implementation */
static RMstatus _rmfp_teletext_decode_payload(struct RMFPTTXSource* pRMFPTTXSource, RMuint8* buf, RMuint32 size, RMuint64 pts )
{
	ASSERT_NULL_POINTER(pRMFPTTXSource);
	ASSERT_NULL_POINTER(buf);

	if( size == 0 || size > EBU_SANE_BUF_SIZE )
	{
		RMDBGLOG((ENABLE, "_ttx_decode_payload empty buffer\n"));
		return RM_OK;
	}

	/* check data identifier for EBU teletext data only */
	if( *buf < 0x10 || *buf > 0x1f )
	{
		RMDBGLOG((ENABLE, "_ttx_decode_payload non-EBU data %d bytes\n", size));
		return RM_OK;
	}

	buf ++;
	size --;

	/* start parsing data fields */
	while( size > 0 && size < EBU_SANE_BUF_SIZE )
	{
		RMuint8 data_unit_id;
		RMuint8 data_unit_length;
		data_unit_id = *buf;
		buf++;
		data_unit_length = *buf;
		buf++;
		size -=2;

		//RMassert( data_unit_length == EBU_BYTES_PER_DATA_FIELD );
		// data_unit_id defined by en300472
		if( data_unit_id == 0x02    // non-subtitle data, sent to composite out
		    || data_unit_id == 0x03    // subtitle data
		    || data_unit_id == 0xc0
		    || data_unit_id == 0xc1
		  ) {
			RMDBGLOG((DEBUG_TTXDECODING, "data id 0x%x\n", data_unit_id  ));
			_rmfp_teletext_ttx_data_field(buf, data_unit_length, &(pRMFPTTXSource->current_ttx) );
		}
		else if( data_unit_id == 0xc3 )
		{
			RMDBGLOG((DEBUG_TTXDECODING, "vps data id 0x%x\n",data_unit_id ));
			//vps_data_field( pic );
		}
		else if( data_unit_id == 0xc4 )
		{
			RMDBGLOG((DEBUG_TTXDECODING, "wss data id 0x%x\n",data_unit_id ));
			//wss_data_field( pic );
		}
		else if( data_unit_id == 0xc5 )
		{
			RMDBGLOG((DEBUG_TTXDECODING, "cc data id 0x%x\n",data_unit_id ));
			//closed_captioning_data_field( pic );
		}
		else if( data_unit_id == 0xc6 )
		{
			RMDBGLOG((DEBUG_TTXDECODING, "monochrome data id 0x%x\n",data_unit_id ));
			//monochrome_data_field( pic );
		}
		else if( data_unit_id == 0xff )
		{
			//stuffing_data_field( pic );
		}
		else
		{ // ignoreable data
			RMDBGLOG((DEBUG_TTXDECODING, "ignor data id 0x%x\n",data_unit_id ));
		}

		buf += data_unit_length;
		size -= data_unit_length;
	}

	return RM_OK;
}

static void _rmfp_teletext_ttx_data_field(RMuint8* buf, RMuint32 size, struct EMhwlibTTXPicture * pic)
{
	RMuint32* linestart = 0;
	RMuint8 fp = 0;
	RMuint8 line = 0;
	RMuint32 i;
	RMuint8 tembuf[TTX_MAX_BYTES_PER_LINE];

	fp = (*buf & 0x20)>>5 ; // field_parity 0 or 1
	line = (*buf & 0x1f);   // line_offset 0 - 17 depending on tv system

	/* line is not defined */
	if( line < TTX_LINE_NUMBER_BASE || line >= TTX_MAX_LINES+TTX_LINE_NUMBER_BASE )
	{
		RMDBGLOG((DEBUG_TTXDECODING, "line number %d undefined or exceed max %d\n", line, TTX_MAX_LINES));
		return;
	}

	if( size >TTX_MAX_BYTES_PER_LINE )
	{
		RMDBGLOG((DEBUG_TTXDECODING, "line size %d exceed max, chop to %d \n", size, TTX_MAX_BYTES_PER_LINE));
		size = TTX_MAX_BYTES_PER_LINE;
	}

	line -= TTX_LINE_NUMBER_BASE; // pic->data starts from line 6 (or 318) regardless of tv system

	pic->fields[fp].line_mask |= (1<<line);
	pic->fields[fp].framing_code = *(buf+1); // frmaing code should not change
	buf += 2;
	size -= 2;

	linestart = pic->fields[fp].data;
	linestart += TTX_MAX_DWORD_PER_LINE * line;
	RMMemset( tembuf, 0, TTX_MAX_BYTES_PER_LINE );

	/*
	 * arrange the bit order and byte order of ttx data to be the same as the ttx ram's arrangement
	 * so less computation is needed in the irq
	 */

	for( i = 0; i < size; i++ )
		tembuf[i] = RMuint8mirrorBits(buf[i]);
	for( i = 0; i < TTX_MAX_DWORD_PER_LINE; i++ )
		linestart[i] = RMleBufToUint32( &tembuf[i*4] );

	RMDBGLOG((DEBUG_TTXDECODING, "fp:%d, lo:%d, fc:0x%x mask 0x%lx  data 0x%08x 0x%08x ... 0x%08x 0x%x\n",
		  fp, line, pic->fields[fp].framing_code, pic->fields[fp].line_mask,  linestart[0], linestart[1], linestart[TTX_MAX_DWORD_PER_LINE-2], linestart[TTX_MAX_DWORD_PER_LINE-1] ));
	return ;
}

/*
 * Refresh teletext page
 */
RMstatus rmfp_internal_teletext_refresh(void *pContext, struct RMLibPlayTTXSource *pTTXSource, RMuint32 magazine, RMuint32 page, RMuint64 STC) 
{
	ASSERT_NULL_POINTER(pTTXSource);
	ASSERT_NULL_POINTER(pContext);

	RMDBGLOG((LOCALDBG, "rmfp_internal_teletext_flush_osd\n"));

	struct RMFPHandle *pHandle = NULL;
	pHandle = (struct RMFPHandle *)pContext;
		
	rmfp_internal_softtxt_refreshTXT(pHandle, magazine, page, STC);
	return RM_OK;
}
