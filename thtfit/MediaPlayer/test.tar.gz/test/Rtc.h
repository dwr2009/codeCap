#ifndef	_RTC_ISL1208_H_
#define	_RTC_ISL1208_H_

#include "rua/include/rua.h"
#include "rmdef/rmdef.h"
#include "rmcore/include/rmstatustostring.h"
#include "emhwlib/include/emhwlib_globaltypes.h"
#include "emhwlib/include/emhwlib_I2C_types.h"

typedef struct
{
	RMuint32 uiYear;
	RMuint32 uiMonth;
	RMuint32 uiDay;
	RMuint32 uiHour;
	RMuint32 uiMinute;
	RMuint32 uiSecond;
}GET_TIME_OUT_PARAM, *P_GET_TIME_OUT_PARAM;

typedef struct
{
	RMuint32 uiYear;
	RMuint32 uiMonth;
	RMuint32 uiDay;
	RMuint32 uiHour;
	RMuint32 uiMinute;
	RMuint32 uiSecond;
}SET_TIME_IN_PARAM, *P_SET_TIME_IN_PARAM;

class CRtcISL1208
{
public:
	CRtcISL1208();
	 ~CRtcISL1208();
	 RMstatus getTime(struct RUA *pRUA, P_GET_TIME_OUT_PARAM pGetTimeOutParam);
	 RMstatus setTime(struct RUA *pRUA, P_SET_TIME_IN_PARAM pSetTimeInParam);
private:
	RMstatus EnableWRTC(struct RUA *pRUA, RMbool bEnable);	
private:
	struct I2C_Read_in_type m_oI2CReadInParam;	
	struct I2C_Send_type m_oI2CSendParam;
	RMuint32 m_uiI2CModuleId;
};

#endif	//_RTC_ISL1208_H_
