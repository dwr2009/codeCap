/*****************************************
 Copyright 2001-2007
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   rmfp_resources_nerospu.c
  @brief  

  
  @author Sebastian Frias Feltrer
  @date   2007-11-05
*/

#include "rmfp_internal.h"

#if 0
#define LOCALDBG ENABLE
#else
#define LOCALDBG DISABLE
#endif









RMstatus rmfp_internal_open_nero_spu_handler(void *pContext, RMuint32 width, RMuint32 height, struct RMLibPlayNeroSPU *pNeroSPU)
{
	struct RMFPHandle *pHandle = NULL;
	struct RMLibPlayOSDProfile LibPlayProfile = { 0, };
	struct RMLibPlayOSDSource *pOSDSource = NULL;
	RMstatus status;


	RMDBGLOG((LOCALDBG, "rmfp_open_nero_spu(%lu x %lu)\n", width, height));

	ASSERT_NULL_POINTER(pContext);
	ASSERT_NULL_POINTER(pNeroSPU);

	pHandle = (struct RMFPHandle *)pContext;
	pNeroSPU->handler = NULL;

	pOSDSource = (struct RMLibPlayOSDSource *)RMMalloc(sizeof(struct RMLibPlayOSDSource));
	if (!pOSDSource) {
		RMNOTIFY((NULL, RM_FATALOUTOFMEMORY, "Cannot allocate RMLibPlayOSDSource\n"));
		return RM_FATALOUTOFMEMORY;
	}
	RMMemset(pOSDSource, 0, sizeof(struct RMLibPlayOSDSource));

	LibPlayProfile.NumberOfPictures = 2;
	LibPlayProfile.ForcedOSDSize = TRUE;

	LibPlayProfile.Profile.ColorSpace = EMhwlibColorSpace_YUV_601;
	LibPlayProfile.Profile.SamplingMode = EMhwlibSamplingMode_444;
	if (pHandle->playback_options.yuv_palette_subs)
		LibPlayProfile.Profile.ColorMode = EMhwlibColorMode_LUT_4BPP;
	else
		LibPlayProfile.Profile.ColorMode = EMhwlibColorMode_TrueColor;
	LibPlayProfile.Profile.ColorFormat = EMhwlibColorFormat_32BPP;
	LibPlayProfile.Profile.PixelAspectRatio.X = 1;
	LibPlayProfile.Profile.PixelAspectRatio.Y = 1;
	
	LibPlayProfile.Profile.Width = width;
	LibPlayProfile.Profile.Height = height;
	

	status = rmfp_internal_open_osd_handler(pContext, &LibPlayProfile, pOSDSource);
	if (status != RM_OK) {
		RMNOTIFY((NULL, status, "Cannot open osd\n"));

		rmfp_internal_close_osd_handler(pContext, pOSDSource);

		RMFree(pOSDSource);
		pOSDSource = NULL;

		return status;
	}

	pNeroSPU->handler = (void *)pOSDSource;

	return RM_OK;
}


RMstatus rmfp_internal_blend_nero_spu_handler(void *pContext, struct RMLibPlayNeroSPU *pNeroSPU, RMuint8 *pBuffer)
{
	struct RMFPHandle *pHandle = NULL;
	struct RMLibPlayOSDSource *pOSDSource = NULL;
	struct RMLibPlayOSDPicture Picture;
	RMstatus status;
	RMuint8 *buf_map;
	RMuint32 buf_size, buf_addr;

	RMDBGLOG((LOCALDBG, "rmfp_blend_nero_spu()\n"));

	ASSERT_NULL_POINTER(pContext);
	ASSERT_NULL_POINTER(pNeroSPU);
	ASSERT_NULL_POINTER(pNeroSPU->handler);

	pHandle = (struct RMFPHandle *)pContext;
	pOSDSource = (struct RMLibPlayOSDSource *)pNeroSPU->handler;

	status = rmfp_internal_get_osd_picture_handler(pContext, pOSDSource, &Picture);
	if (status != RM_OK) {
		RMNOTIFY((NULL, status, "Cannot get osd picture\n"));
		return status;
	}

	buf_size = Picture.LumaBufferSize;
	buf_addr = Picture.LumaBufferAddress;
	RMDBGLOG((DISABLE, "osd source : w %lu, h %lu, totalw %lu\n", pOSDSource->Width, pOSDSource->Height, pOSDSource->TotalWidth));

	status = RUALock(pHandle->profile.pRUA, buf_addr, buf_size);
	if (status != RM_OK) {
		RMNOTIFY((NULL, status, "Can't lock OSD buffer at 0x%08lX (0x%08lX bytes)\n", buf_addr, buf_size));
		return status;
	}
	
	buf_map = RUAMap(pHandle->profile.pRUA, buf_addr, buf_size);
	if (buf_map == NULL) {
		RMNOTIFY((NULL, RM_ERROR, "Can't mapp OSD buffer at 0x%08lX (0x%08lX bytes)\n", buf_addr, buf_size));
		return RM_ERROR;
	}
	

	if (pHandle->playback_options.yuv_palette_subs) {
		//palette subs
		RMuint32 bitmap_size = (pOSDSource->Width * pOSDSource->Height) >> 1;
		RMuint32 i = 0;

		for (i=0; i<bitmap_size; i++) {
			buf_map[i] = pBuffer[i];
		}

		Picture.pPalette = (RMuint32 *)(&(pBuffer[bitmap_size]));
	}
	else {
		// reorder Y,V,U,A planes into UYVA,UYVA,... pixels
		RMuint32 bitmap_size = pOSDSource->Width * pOSDSource->Height;
		RMuint8 *buf_Y = pBuffer;
		RMuint8 *buf_V = buf_Y + (bitmap_size);
		RMuint8 *buf_U = buf_V + (bitmap_size);
		RMuint8 *buf_A = buf_U + (bitmap_size);
		RMuint32 i = 0;

		while (i < (bitmap_size*4)) {
			*(buf_map+i) = *buf_U++;    // bleu
			*(buf_map+i+1) = *buf_Y++;  
			*(buf_map+i+2) = *buf_V++;  // rouge?

			// alpha values are in the [0,16] range, convert them to [0,255]
			if (*buf_A) 
				*(buf_map+i+3) = RMmin(*buf_A * 16, 255);
			else
				*(buf_map+i+3) = 0;
			buf_A++;

			i+=4;
		}
	}
	

	RUAUnMap(pHandle->profile.pRUA, buf_map, buf_size);
	status = RUAUnLock(pHandle->profile.pRUA, buf_addr, buf_size);
	if (status != RM_OK) {
		RMNOTIFY((NULL, status, "Can't unlock OSD buffer at 0x%08lX (0x%08lX bytes)\n", buf_addr, buf_size));
		return status;
	}
	
	status = rmfp_internal_set_osd_picture_handler(pContext, pOSDSource, &Picture);
	if (status != RM_OK) {
		RMNOTIFY((NULL, status, "Cannot set osd picture\n"));
		return status;
	}

	return RM_OK;
}


RMstatus rmfp_internal_clear_nero_spu_handler(void *pContext, struct RMLibPlayNeroSPU *pNeroSPU)
{
	struct RMFPHandle *pHandle = NULL;
	struct RMLibPlayOSDSource *pOSDSource = NULL;
	struct RMLibPlayOSDPicture Picture;
	RMstatus status;
	RMuint8 *buf_map;
	RMuint32 buf_size, buf_addr;

	RMDBGLOG((LOCALDBG, "rmfp_clear_nero_spu()\n"));

	ASSERT_NULL_POINTER(pContext);
	ASSERT_NULL_POINTER(pNeroSPU);
	ASSERT_NULL_POINTER(pNeroSPU->handler);
	
	pHandle = (struct RMFPHandle *)pContext;
	pOSDSource = (struct RMLibPlayOSDSource *)pNeroSPU->handler;

	status = rmfp_internal_get_osd_picture_handler(pContext, pOSDSource, &Picture);
	if (status != RM_OK) {
		RMNOTIFY((NULL, status, "Cannot get osd picture\n"));
		return status;
	}

	buf_size = Picture.LumaBufferSize;
	buf_addr = Picture.LumaBufferAddress;

	status = RUALock(pHandle->profile.pRUA, buf_addr, buf_size);
	if (status != RM_OK) {
		RMNOTIFY((NULL, status, "Can't lock OSD buffer at 0x%08lX (0x%08lX bytes)\n", buf_addr, buf_size));
		return status;
	}
	
	buf_map = RUAMap(pHandle->profile.pRUA, buf_addr, buf_size);
	if (buf_map == NULL) {
		RMNOTIFY((NULL, RM_ERROR, "Can't map OSD buffer at 0x%08lX (0x%08lX bytes)\n", buf_addr, buf_size));
		return RM_ERROR;
	}

	// clear buffer
	RMMemset(buf_map, 0, buf_size);
	// No need palette for cleaning
	Picture.pPalette = NULL;

	RUAUnMap(pHandle->profile.pRUA, buf_map, buf_size);
	status = RUAUnLock(pHandle->profile.pRUA, buf_addr, buf_size);
	if (status != RM_OK) {
		RMNOTIFY((NULL, status, "Can't unlock OSD buffer at 0x%08lX (0x%08lX bytes)\n", buf_addr, buf_size));
		return status;
	}

	status = rmfp_internal_set_osd_picture_handler(pContext, pOSDSource, &Picture);
	if (status != RM_OK) {
		RMNOTIFY((NULL, status, "Cannot set osd picture\n"));
		return status;
	}
	
	return RM_OK;

}


RMstatus rmfp_internal_close_nero_spu_handler(void *pContext, struct RMLibPlayNeroSPU *pNeroSPU)
{
	struct RMLibPlayOSDSource *pOSDSource = NULL;

	RMDBGLOG((LOCALDBG, "rmfp_close_nero_spu()\n"));

	ASSERT_NULL_POINTER(pContext);
	ASSERT_NULL_POINTER(pNeroSPU);
	ASSERT_NULL_POINTER(pNeroSPU->handler);

	pOSDSource = (struct RMLibPlayOSDSource *)pNeroSPU->handler;

	rmfp_internal_close_osd_handler(pContext, pOSDSource);

	RMFree(pOSDSource);
	
	pNeroSPU->handler = NULL;
	
	return RM_OK;

}

