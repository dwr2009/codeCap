/*****************************************
 Copyright 2001-2007
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   rmfp_resources_osd.c
  @brief


  @author
  @date   2008-06-27
*/

#include "rmfp_internal.h"

#if 0
#define LOCALDBG ENABLE
#else
#define LOCALDBG DISABLE
#endif

#if ((defined(EM86XX_DEBUG_AUDIO) && (EM86XX_DEBUG_AUDIO == EM86XX_DEBUG_CHIP)) || \
	(defined(EM86XX_DEBUG_VIDEO) && (EM86XX_DEBUG_VIDEO==EM86XX_DEBUG_CHIP)) ||\
	(defined(EM86XX_DEBUG_DEMUX) && (EM86XX_DEBUG_DEMUX==EM86XX_DEBUG_CHIP)))
#define TIMEOUT_US (1000000 * (30 * 60))
#else
#define TIMEOUT_US (500 * 1000)
#endif

struct RMFPOSDHandle {

	RMuint32 NumberOfPictures;                 // for example: 2 for double buffering

	//struct DCCOSDProfile Profile;
	enum EMhwlibColorMode ColorMode;
	RMuint32 Width;
	RMuint32 Height;

	struct RMFPOSDSource Source;

	RMuint32 BufferOnScreen;

	RMuint32 NextBuffer;

	//for PT
	struct MpegEngine_DecoderSharedMemory_type shared;
	struct MpegEngine_SchedulerSharedMemory_type schedmem;
	RMuint32 pt_input_surface;
};

RMstatus rmfp_internal_open_osd_handler(void *pContext, struct RMLibPlayOSDProfile *pProfile, struct RMLibPlayOSDSource *pOSDSource)
{
	struct RMFPHandle *pHandle = NULL;

	struct RMFPOSDProfile OSDProfile = { 0, };
	struct RMFPOSDHandle *pOSDHandle = NULL;

	RMstatus status;

	RMDBGLOG((LOCALDBG, "rmfp_internal_open_osd_handler\n"));

	ASSERT_NULL_POINTER(pContext);
	ASSERT_NULL_POINTER(pProfile);
	ASSERT_NULL_POINTER(pOSDSource);

	pHandle = (struct RMFPHandle *)pContext;

	pOSDHandle = (struct RMFPOSDHandle *)RMMalloc(sizeof(struct RMFPOSDHandle));
	if (!pOSDHandle) {
		RMNOTIFY((NULL, RM_FATALOUTOFMEMORY, "Not enough memory\n"));
		return RM_FATALOUTOFMEMORY;
	}
	RMMemset(pOSDHandle, 0, sizeof(struct RMFPOSDHandle));


	OSDProfile.Version = GET_VERSION_FROM_MAGIC(RMFP_OSD_PROFILE_VERSION);

	OSDProfile.NumberOfPictures = pProfile->NumberOfPictures;
	OSDProfile.ForcedOSDSize    = pProfile->ForcedOSDSize;

	RMMemcpy(&OSDProfile.Profile, &pProfile->Profile, sizeof(OSDProfile.Profile));

	RMDBGLOG((LOCALDBG, "Open OSD with profile :\n"
			    "\tSamplingMode : %d\n"
			    "\tColorMode : %d\n"
			    "\tColorFormat : %d\n"
			    "\tWidth : %d\n"
			    "\tHeight : %d\n"
			    "\tColorSpace : %d\n"
			    "\tPixelAspectRatio.X : %d\n"
			    "\tPixelAspectRatio.Y : %d\n",
			    OSDProfile.Profile.SamplingMode,
			    OSDProfile.Profile.ColorMode,
			    OSDProfile.Profile.ColorFormat,
			    OSDProfile.Profile.Width,
			    OSDProfile.Profile.Height,
			    OSDProfile.Profile.ColorSpace,
			    OSDProfile.Profile.PixelAspectRatio.X,
			    OSDProfile.Profile.PixelAspectRatio.Y));

	if (pHandle->profile.rmfp_open_osd_callback && pHandle->profile.rmfp_close_osd_callback) {
		status = pHandle->profile.rmfp_open_osd_callback(pHandle->profile.callback_context, &OSDProfile, &(pOSDHandle->Source));
		if (status != RM_OK) {
			RMNOTIFY((NULL, status, "Can't init buffered OSD (%s)\n", RMstatusToString(status)));

			pHandle->profile.rmfp_close_osd_callback(pHandle->profile.callback_context, &(pOSDHandle->Source));

			RMFree(pOSDHandle);
			pOSDHandle = NULL;

			return status;
		}
	}
	else
		return RM_NOTIMPLEMENTED;


	pOSDHandle->Width            = OSDProfile.Profile.Width;
	pOSDHandle->Height           = OSDProfile.Profile.Height;
	pOSDHandle->ColorMode        = OSDProfile.Profile.ColorMode;
	pOSDHandle->NumberOfPictures = OSDProfile.NumberOfPictures;
	pOSDHandle->NextBuffer       = 0;

	pOSDSource->Width = pOSDHandle->Width;
	pOSDSource->TotalWidth = pOSDHandle->Width;
	pOSDSource->Height = pOSDHandle->Height;

	pOSDSource->pHandler = pOSDHandle;


	return RM_OK;
}

RMstatus rmfp_internal_close_osd_handler(void *pContext, struct RMLibPlayOSDSource *pOSDSource)
{
	struct RMFPHandle *pHandle = NULL;
	struct RMFPOSDHandle *pOSDHandle = NULL;
	RMstatus status = RM_NOTIMPLEMENTED;

	RMDBGLOG((LOCALDBG, "rmfp_internal_close_osd_handler()\n"));

	ASSERT_NULL_POINTER(pContext);
	ASSERT_NULL_POINTER(pOSDSource);
	ASSERT_NULL_POINTER(pOSDSource->pHandler);

	pHandle = (struct RMFPHandle *)pContext;
	pOSDHandle = (struct RMFPOSDHandle *)pOSDSource->pHandler;

	if (pHandle->playback_options.PTEnable == TRUE) {

		rmfp_internal_close_picture_transform(pHandle);

		status = rmfp_gt_term_mpeg_engine(pHandle, &(pOSDHandle->shared), &(pOSDHandle->schedmem));
		if (RMFAILED(status))
		{
			RMDBGLOG((ENABLE, "Couldn't terminate the MPEG engine\n"));
			return status;
		}

		if(pOSDHandle->pt_input_surface)
			RUAFree(pHandle->profile.pRUA, pOSDHandle->pt_input_surface);
	}

	if (pHandle->profile.rmfp_close_osd_callback) {
		status = pHandle->profile.rmfp_close_osd_callback(pHandle->profile.callback_context, &(pOSDHandle->Source));
		if (status != RM_OK)
			RMNOTIFY((NULL, status, "Can't close buffered OSD\n"));
	}

	RMFree(pOSDHandle);

	pOSDSource->pHandler = NULL;

	return status;
}

RMstatus rmfp_internal_get_osd_picture_handler(void *pContext, struct RMLibPlayOSDSource *pOSDSource, struct RMLibPlayOSDPicture *pPicture)
{
	struct RMFPHandle *pRMFPHandle = NULL;
	struct RMFPOSDHandle *pOSDHandle = NULL;
	RMuint32 picture_address, luma_address, luma_size, chroma_address, chroma_size;
	RMstatus status;

	RMDBGLOG((LOCALDBG, "rmfp_internal_get_osd_picture_handler()\n"));

	ASSERT_NULL_POINTER(pContext);
	ASSERT_NULL_POINTER(pOSDSource);
	ASSERT_NULL_POINTER(pPicture);


	pRMFPHandle = (struct RMFPHandle *)pContext;
	pOSDHandle = (struct RMFPOSDHandle *)pOSDSource->pHandler;

	if (!pOSDHandle) {
		RMNOTIFY((NULL, RM_FATALINVALIDPOINTER, "OSD not opened\n"));
		return RM_FATALINVALIDPOINTER;
	}

	if (!pOSDHandle->NumberOfPictures) {
		RMNOTIFY((NULL, RM_ERROR, "No picture in OSD buffer\n"));
		return RM_ERROR;
	}

	if (!pOSDHandle->Source.pSource) {
		RMNOTIFY((NULL, RM_ERROR, "OSDsource not defined\n"));
		return RM_ERROR;
	}

	if (pOSDHandle->NumberOfPictures == 1) {
		RMDBGLOG((LOCALDBG, "Simple buffer mode\n"));

		status = DCCEnableVideoSource(pOSDHandle->Source.pSource, FALSE);
		if (status != RM_OK) {
			RMNOTIFY((NULL, status, "Cannot disable osd\n"));
			return status;
		}

		status = DCCGetOSDPictureInfo(pOSDHandle->Source.pSource,
					      0,
					      &picture_address,
					      &luma_address,
					      &luma_size,
					      &chroma_address,
					      &chroma_size);
		if (status != RM_OK) {
			RMNOTIFY((NULL, status, "Cannot get osd picture info\n"));
			return status;
		}

		pPicture->PictureID           = 0;
		pPicture->PictureAddress      = picture_address;
		pPicture->LumaBufferAddress   = luma_address;
		pPicture->LumaBufferSize      = luma_size;
		pPicture->ChromaBufferAddress = chroma_address;
		pPicture->ChromaBufferSize    = chroma_size;

	}
	else {
		RMDBGLOG((LOCALDBG, "Get info from picture %d\n", pOSDHandle->NextBuffer));

		if (pOSDHandle->NextBuffer == pOSDHandle->BufferOnScreen) {
			pOSDHandle->NextBuffer++;
			pOSDHandle->NextBuffer = pOSDHandle->NextBuffer % pOSDHandle->NumberOfPictures;
		}

		status = DCCGetOSDPictureInfo(pOSDHandle->Source.pSource,
					      pOSDHandle->NextBuffer,
					      &picture_address,
					      &luma_address,
					      &luma_size,
					      &chroma_address,
					      &chroma_size);

		if (status != RM_OK) {
			RMNOTIFY((NULL, status, "Cannot get osd picture info\n"));
			return status;
		}

		pPicture->PictureID           = pOSDHandle->NextBuffer;
		pPicture->PictureAddress      = picture_address;
		pPicture->LumaBufferAddress   = luma_address;
		pPicture->LumaBufferSize      = luma_size;
		pPicture->ChromaBufferAddress = chroma_address;
		pPicture->ChromaBufferSize    = chroma_size;

		pOSDHandle->NextBuffer ++;
		pOSDHandle->NextBuffer = pOSDHandle->NextBuffer%pOSDHandle->NumberOfPictures;
	}

	return RM_OK;
}

RMstatus rmfp_internal_set_osd_picture_handler(void *pContext, struct RMLibPlayOSDSource *pOSDSource, struct RMLibPlayOSDPicture *pPicture)
{
	struct RMFPHandle *pRMFPHandle = NULL;
	struct RMFPOSDHandle *pOSDHandle = NULL;
	RMstatus status;

	RMDBGLOG((LOCALDBG, "rmfp_internal_set_osd_picture_handler()\n"));

	ASSERT_NULL_POINTER(pContext);
	ASSERT_NULL_POINTER(pOSDSource);
	ASSERT_NULL_POINTER(pPicture);


	pRMFPHandle = (struct RMFPHandle *)pContext;
	pOSDHandle = (struct RMFPOSDHandle *)pOSDSource->pHandler;

	if (!pOSDHandle) {
		RMNOTIFY((NULL, RM_FATALINVALIDPOINTER, "OSD not opened\n"));
		return RM_FATALINVALIDPOINTER;
	}

	if (!pOSDHandle->NumberOfPictures) {
		RMNOTIFY((NULL, RM_ERROR, "No picture in osd buffer\n"));
		return RM_ERROR;
	}

	if (!pOSDHandle->Source.pSource) {
		RMNOTIFY((NULL, RM_ERROR, "Osdsource not defined\n"));
		return RM_ERROR;
	}


	if (pPicture->pPalette) {

		RMuint32 PaletteSize;

		if (0) {
			RMuint32 i;

			RMDBGLOG((ENABLE, "palette is:\n"));
			for (i = 0; i < 256; i++)
				RMDBGLOG((ENABLE, "[%lu (0x%lx)] = 0x%08lx\n", i, i, pPicture->pPalette[i]));
		}


		switch(pOSDHandle->ColorMode){
		case EMhwlibColorMode_LUT_1BPP:
			PaletteSize = 2*4;
			break;
		case EMhwlibColorMode_LUT_2BPP:
			PaletteSize = 4*4;
			break;
		case EMhwlibColorMode_LUT_4BPP:
			PaletteSize = 16*4;
			break;
		case EMhwlibColorMode_LUT_8BPP:
			PaletteSize = 256*4;
			break;
		default:
			PaletteSize = 0;
			break;
		}

		if (PaletteSize) {
			struct DisplayBlock_SetPaletteOnPicture_type palette;
			RMint32 try;

			palette.Picture = pPicture->PictureAddress;
			RMMemcpy(&(palette.Palette), pPicture->pPalette, sizeof(palette.Palette));
			palette.PaletteSize = PaletteSize;

			try = 5;
			while ((status = RUASetProperty(pRMFPHandle->profile.pRUA, DisplayBlock, RMDisplayBlockPropertyID_SetPaletteOnPicture, &(palette), sizeof(palette), 0)) == RM_PENDING)
				if (try-- < 0) break;
			if (RMFAILED(status)) {
				RMNOTIFY((NULL, status, "Cannot set palette\n"));
				return status;
			}
		}
	}


	if (pOSDHandle->NumberOfPictures == 1) {
		status = DCCEnableVideoSource(pOSDHandle->Source.pSource, TRUE);
		if (status != RM_OK) {
			RMNOTIFY((NULL, status, "Cannot enable osd\n"));
			return status;
		}
	}

	if (pRMFPHandle->playback_options.PTEnable == TRUE) {
		RMuint32 pt_output_surface, osd_surface;
		RMuint32 pic_addr, scaler;
		struct DisplayBlock_InsertPictureInSurfaceFifo_type param;
		struct DisplayBlock_SurfaceInfo_out_type surface_info;
		struct DisplayBlock_SurfaceSize_in_type dram_in;
		struct DisplayBlock_SurfaceSize_out_type dram_out;
		struct DisplayBlock_InitMultiplePictureSurfaceX_type Value;
		struct DCC *pDCC = pRMFPHandle->profile.pDCC;

		struct RMFPVideoOptions *pVideoOptions = NULL;

		pVideoOptions = &(pRMFPHandle->video_options);

		status = DCCGetOSDSurfaceInfo(pDCC, pOSDHandle->Source.pSource, NULL, &osd_surface, NULL);
		if (RMFAILED(status)) {
			RMDBGLOG((ENABLE, "Cannot get canvas surface info %d\n", status));
			return status;
		}

		status = RUAExchangeProperty(pRMFPHandle->profile.pRUA, DisplayBlock, RMDisplayBlockPropertyID_SurfaceInfo, &(osd_surface), sizeof(osd_surface), &surface_info, sizeof(surface_info));
		if (RMFAILED(status)) {
			RMDBGLOG((ENABLE, "Error in exchange property RMDisplayBlockPropertyID_SurfaceInfo! %s\n", RMstatusToString(status)));
			return status;
		}

		dram_in.ColorMode = surface_info.ColorMode;
		dram_in.ColorFormat = surface_info.ColorFormat;
		dram_in.SamplingMode = surface_info.SamplingMode;
		dram_in.Width = pOSDHandle->Width;
		dram_in.Height = pOSDHandle->Height;
		status = RUAExchangeProperty(pRMFPHandle->profile.pRUA, DisplayBlock, RMDisplayBlockPropertyID_SurfaceSize,
					  &dram_in, sizeof(dram_in), &dram_out, sizeof(dram_out));
		if (RMFAILED(status)) {
			RMDBGLOG((ENABLE, "Error Cannot get size to allocate the Intermediate surface, %s\n", RMstatusToString(status)));
			return status;
		}

		pOSDHandle->pt_input_surface = RUAMalloc(pRMFPHandle->profile.pRUA, pRMFPHandle->playback_options.DRAMIndex, RUA_DRAM_UNCACHED, dram_out.BufferSize);

		if(!pOSDHandle->pt_input_surface){
			RMDBGLOG((ENABLE,  "Error allocating intermediate surface\n"));
			return RM_FATALOUTOFMEMORY;
		}

		Value.ColorMode = dram_in.ColorMode;
		Value.ColorFormat = dram_in.ColorFormat;
		Value.SamplingMode = dram_in.SamplingMode;
		Value.Address = pOSDHandle->pt_input_surface;
		Value.PictureCount = 1;
		Value.STCModuleId = 0;
		Value.ColorSpace = surface_info.ColorSpace;
		Value.PixelAspectRatio.X = 0;
		Value.PixelAspectRatio.Y = 0;
		Value.Tiled = FALSE;
		status = RUASetProperty(pRMFPHandle->profile.pRUA, DisplayBlock, RMDisplayBlockPropertyID_InitMultiplePictureSurfaceX,
				&Value, sizeof(Value),0);
		if (RMFAILED(status)) {
			RMDBGLOG((ENABLE, "Cannot initialize Intermediate surface, %s\n", RMstatusToString(status)));
			return status;
		}

		status = DCCGetOSDPictureInfo(pOSDHandle->Source.pSource, pPicture->PictureID, &pic_addr, NULL, NULL, NULL, NULL);
		if (RMFAILED(status)) {
			RMDBGLOG((ENABLE, "Cannot get the osd picture info, %s\n", RMstatusToString(status)));
			return status;
		}

	    status = rmfp_gt_initialize_mpeg_engine(pRMFPHandle, &(pOSDHandle->shared), &(pOSDHandle->schedmem), pRMFPHandle->playback_options.DRAMIndex);
	    if (RMFAILED(status))
	    {
	        RMDBGLOG((ENABLE, "Couldn't find a suitable MPEG engine\n"));
	        return status;
	    }

		status = rmfp_internal_open_picture_transform(pRMFPHandle, &pOSDHandle->pt_input_surface, &pt_output_surface);
		if (status != RM_OK) {
			RMDBGLOG((ENABLE, "Cannot set the Picture Transform\n"));
			return status;
		}

		param.Surface = pOSDHandle->pt_input_surface;
		param.Picture = pic_addr;
		param.Pts = 0;
		status = RUASetProperty(pRMFPHandle->profile.pRUA, DisplayBlock, RMDisplayBlockPropertyID_InsertPictureInSurfaceFifo, &param, sizeof(param), 0);
		if (RMFAILED(status)){
			RMDBGLOG((ENABLE, "Cannot insert picture into surface, %s\n", RMstatusToString(status)));
			return status;
		}

		status = DCCSetOSDSurface(pOSDHandle->Source.pSource, pt_output_surface);
		if (RMFAILED(status)){
			RMDBGLOG((ENABLE, "Cannot set the OSD surface, %s\n", RMstatusToString(status)));
			return status;
		}

		scaler = pRMFPHandle->video_options.VideoScalerID;
#if 0
		status = DCCSetSurfaceSource(pDCC, scaler, pOSDHandle->Source.pSource);
		if (status != RM_OK) {
			RMDBGLOG((ENABLE, "Cannot set the surface source, %s\n", RMstatusToString(status)));
			return status;
		}
#endif
		
		if (pRMFPHandle->video_options.ForceAFD || pRMFPHandle->video_options.ForceAsp || pRMFPHandle->video_options.ForceBarInfo || pRMFPHandle->video_options.ForceScanInfo || pRMFPHandle->video_options.Force3D) {
			RMuint32 ModuleID, PropertyID;
#ifdef RMBUILD_USE_HWLIB_V2
			struct EMhwlibDispSurface_SurfaceFrameInfoForce_type SurfaceFrameInfoForce;
			ModuleID = EMHWLIB_MODULE(EMhwlibDispSurface, 0);
			PropertyID = RMPropertyID_SurfaceFrameInfoForce;
#else // RMBUILD_USE_HWLIB_V2
			struct DisplayBlock_SurfaceFrameInfoForce_type SurfaceFrameInfoForce;
			ModuleID = EMHWLIB_MODULE(DisplayBlock, 0);
			PropertyID = RMDisplayBlockPropertyID_SurfaceFrameInfoForce;
#endif // RMBUILD_USE_HWLIB_V2
			
			RMMemset(&SurfaceFrameInfoForce, 0, sizeof(SurfaceFrameInfoForce));
			SurfaceFrameInfoForce.surface = osd_surface;
			
			if (pRMFPHandle->video_options.ForceAFD) {
				RMDBGLOG((ENABLE, "Forcing AFD on surface\n"));
				SurfaceFrameInfoForce.FrameInfoForce.ForceMask |= EMHWLIB_FRAMEINFO_MASK_ActiveFormat;
			}
			if (pRMFPHandle->video_options.ForceAsp) {
				RMDBGLOG((ENABLE, "Forcing aspect ratio on surface\n"));
				SurfaceFrameInfoForce.FrameInfoForce.ForceMask |= EMHWLIB_FRAMEINFO_MASK_AspectRatio;
			}
			if (pRMFPHandle->video_options.ForceBarInfo) {
				RMDBGLOG((ENABLE, "Forcing bar info on surface\n"));
				SurfaceFrameInfoForce.FrameInfoForce.ForceMask |= EMHWLIB_FRAMEINFO_MASK_BarData;
			}
			if (pRMFPHandle->video_options.ForceScanInfo) {
				RMDBGLOG((ENABLE, "Forcing scan info on surface\n"));
				SurfaceFrameInfoForce.FrameInfoForce.ForceMask |= EMHWLIB_FRAMEINFO_MASK_ScanInfo;
			}
			if (pRMFPHandle->video_options.Force3D) {
				RMDBGLOG((ENABLE, "Forcing 3D format on surface\n"));
				SurfaceFrameInfoForce.FrameInfoForce.ForceMask |= EMHWLIB_FRAMEINFO_MASK_Stereoscopic3D;
			}
			SurfaceFrameInfoForce.FrameInfoForce.FrameInfo.AFD = pRMFPHandle->video_options.afd;
			SurfaceFrameInfoForce.FrameInfoForce.FrameInfo.BarInfo = pRMFPHandle->video_options.BarInfo;
			SurfaceFrameInfoForce.FrameInfoForce.FrameInfo.ScanInfo = pRMFPHandle->video_options.ScanInfo;
			SurfaceFrameInfoForce.FrameInfoForce.FrameInfo.Stereoscopic3D = pRMFPHandle->video_options.Stereoscopic3D;
			
			status = RUASetProperty(pRMFPHandle->profile.pRUA, ModuleID, PropertyID, &(SurfaceFrameInfoForce), sizeof(SurfaceFrameInfoForce), 0);
			if (RMFAILED(status)) {
				RMNOTIFY((NULL, status, "Can not set SurfaceFrameInfoForce on %p\n", osd_surface));
			}
		} else {
			RMDBGLOG((ENABLE, "Not forcing anything on surface\n"));
		}
	}
	else{
		status = DCCInsertPictureInMultiplePictureOSDVideoSource(pOSDHandle->Source.pSource, pPicture->PictureID, 0);
		if (status != RM_OK) {
			RMNOTIFY((NULL, status, "Can't insert picture inside surface\n"));
			return status;
		}
	}
	status = DCCEnableVideoSource(pOSDHandle->Source.pSource, TRUE);
	if (status != RM_OK){
		RMNOTIFY((NULL, status, "Error enabling OSD buffer\n"));
		return status;
	}

	pOSDHandle->BufferOnScreen = pPicture->PictureID;

	return RM_OK;
}

