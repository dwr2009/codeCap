/*****************************************
 Copyright 2001-2010
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   ciphers.c
  @brief  This file provides an example of implementation of the cipher callbacks

	  This file is part of the test_rmfp suite

  @author Aurelia Popa Radu, Gilles VIEIRA
  @date   2009-04-29
*/

/*
  **********************************************
  DISCLAIMER:

  - THIS IS TEST CODE, provided as sample code
  to help you understand what you should do to
  develop your own application based in RMFP.

  - This is NOT production grade code; It is not
  even a library, so any API defined here, CAN
  and WILL CHANGE without notice.

  **********************************************
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <ctype.h>

#define ALLOW_OS_CODE 1

#include "ciphers.h"
#include "test_rmfp.h"

#include <dcc/include/dcc_macros.h>

#ifdef USE_XPU_WRITE_KEY
#include <rmdemuxwritekey/rmdemuxwritekeyapi.h>
#define DEMUX_WRITE_KEY_XRPC_SIZE (64 * 1024)
#endif /* USE_XPU_WRITE_KEY */

#if 1
#define LOCALDBG ENABLE
#else
#define LOCALDBG DISABLE
#endif

#if 1
#define PARSE_CIPHER_DBG ENABLE
#else
#define PARSE_CIPHER_DBG DISABLE
#endif


/*
 * Define all the profiles version for which this file has been written
 */

#define RMFP_DEMUX_CIPHER_RESOURCES_PROFILE_VERSION		1

/*
 * Macros
 */
#define CHECK_VERSION(version)						\
	{								\
		if (pProfile->Version != version) {			\
			RMNOTIFY((NULL, RM_ERROR, "Got version 0x%lx, expected 0x%lx\n", pProfile->Version, version)); \
			return RM_ERROR;				\
		}							\
	}

#define READ_CONFIG(x) \
do { \
	if (EOF == fscanf(pCipher->config_file, "%s%ld%s", str, (RMuint32 *)&x, comment)) { \
		RMNOTIFY((NULL, RM_ERROR, "cipher config file early end\n")); \
		return RM_ERROR; \
	} \
	RMDBGLOG((PARSE_CIPHER_DBG, "%s %d %s\n", str, x, comment)); \
} while (0); \

#define READ_KEY(x, size, swap) \
do { \
	char key[128]; \
	RMuint32 k; \
	if (EOF == fscanf(pCipher->config_file, (size==32) ? "%64s" : ((size==16)? "%32s":"%16s"), key)) { \
		RMNOTIFY((NULL, RM_ERROR, "cipher config file early end\n")); \
		return RM_ERROR; \
	} \
	RMDBGLOG((PARSE_CIPHER_DBG, "key=%s\n", key)); \
	for(k=0;k<size;k++) { \
		RMuint32 m; \
		m = swap ? (2*size - 2*k - 2) : (2*k); \
		if(isdigit(key[m])) \
			x[k] = key[m] - '0'; \
		else \
			x[k] = key[m] - 'a' + 10; \
		x[k] <<=4; \
		if(isdigit(key[m+1])) \
			x[k] += key[m+1] - '0'; \
		else \
			x[k] += key[m+1] - 'a' + 10; \
	} \
	RMDBGLOG((DISABLE, "key= %02x %02x %02x %02x ...\n", x[0], x[1], x[2], x[3])); \
} while (0); \

#define READ_STR_KEY(x, size, swap) \
do { \
	char key[128]; \
	RMuint32 k; \
	if (EOF == fscanf(pCipher->config_file, (size==32) ? "%s%64s%s" : ((size==16)? "%s%32s%s":"%s%16s%s"), str, key, comment)) { \
		RMNOTIFY((NULL, RM_ERROR, "cipher config file early end\n")); \
		return RM_ERROR; \
	} \
	RMDBGLOG((PARSE_CIPHER_DBG, "%s %s %s\n", str, key, comment)); \
	for(k=0;k<size;k++) { \
		RMuint32 m; \
		m = swap ? (2*size - 2*k - 2) : (2*k); \
		if(isdigit(key[m])) \
			x[k] = key[m] - '0'; \
		else \
			x[k] = key[m] - 'a' + 10; \
		x[k] <<=4; \
		if(isdigit(key[m+1])) \
			x[k] += key[m+1] - '0'; \
		else \
			x[k] += key[m+1] - 'a' + 10; \
	} \
	RMDBGLOG((DISABLE, "%s%02x %02x %02x %02x ...\n", str, x[0], x[1], x[2], x[3])); \
} while (0); \


/******************************************* helper ******************************************/

#ifdef _DEBUG
static RMascii* _get_pid_type_string(enum RMFP_pid_type type)
{
	switch (type)
	{
		case RMFP_pid_type_pat:
			return "PAT  ";
		case RMFP_pid_type_pmt:
			return "PMT  ";
		case RMFP_pid_type_video:
			return "Video";
		case RMFP_pid_type_audio:
			return "Audio";
		case RMFP_pid_type_subpictures:
			return "Subpi";
		case RMFP_pid_type_pcr:
			return "PCR  ";
		case RMFP_pid_type_bifs:
			return "BIF  ";
		case RMFP_pid_type_od:
			return "OD   ";
		case RMFP_pid_type_ttx:
			return "Ttxt ";
		case RMFP_pid_type_ts:
			return "TS   ";
		case RMFP_pid_type_input_record:
			return "Input";
		case RMFP_pid_type_custom:
			return "Custom";
	}
	return "???";
}
#endif // _DEBUG

/*********************************** inband outband key change *******************************/

static RMstatus OutbandKeyChange(struct RUA *pRUA, struct rmfp_cipher_context *pCipher, RMuint32 cipher_entry, RMuint32 key_entry)
{
	RMstatus err;
	struct DemuxTask_OutbandKeyChange_type outband;

	outband.cipher_index = pCipher->cipher_entry[cipher_entry].index;
	outband.key_index = pCipher->cipher_entry[cipher_entry].key_entry[key_entry].index;
	outband.cipher_type = pCipher->cipher_entry[cipher_entry].type;
	outband.scrambling = pCipher->cipher_entry[cipher_entry].key_entry[key_entry].scrambling_bits;
	err = RUASetProperty(pRUA, pCipher->demux_task, RMDemuxTaskPropertyID_OutbandKeyChange,
		  &outband, sizeof(outband), 0);
	if (RMFAILED(err)) {
		RMNOTIFY((NULL, err, "Error OutbandKeyChange\n"));
	}
	return err;
}

static RMstatus InbandKeyChange(struct RUA *pRUA, struct rmfp_cipher_context *pCipher, RMuint32 cipher_entry, RMuint32 key_entry,
	enum EMhwlibInbandOffset offset_control, RMuint32 offset_value)
{
	RMstatus err;
	RMuint32 size;
	struct DemuxTask_InbandKeyChange_type ibc;

	RUAGetProperty(pRUA, pCipher->demux_task, RMDemuxTaskPropertyID_InbandFifoWritableSize, &size, sizeof(size));
	if (size == 0) {
		RMDBGLOG((LOCALDBG, "********************** insufficient InbandFifoWritableSize\n"));
		return RM_INSUFFICIENT_SIZE;
	}

	ibc.cipher_index = pCipher->cipher_entry[cipher_entry].index;
	ibc.key_index = pCipher->cipher_entry[cipher_entry].key_entry[key_entry].index;
	ibc.scrambling = pCipher->cipher_entry[cipher_entry].key_entry[key_entry].scrambling_bits;
	ibc.offset_control = offset_control;
	ibc.offset_value = offset_value;

	RMDBGLOG((DISABLE, "InbandKeyChange cipher_index=%ld key_index=%ld scrambling_bits=%ld\n",
		ibc.cipher_index, ibc.key_index, ibc.scrambling));
	err = RUASetProperty(pRUA, pCipher->demux_task, RMDemuxTaskPropertyID_InbandKeyChange,
		  &ibc, sizeof(ibc), 0);
	if (RMFAILED(err)) {
		RMNOTIFY((NULL, err, "Error InbandKeyChange\n"));
	}
	return err;

}
/****************************** read write keys - implementation *****************************/

#ifdef USE_XPU_WRITE_KEY

static RMstatus WriteKey(struct RUA *pRUA, struct rmfp_cipher_context *pCipher, RMuint32 cipher_entry, RMuint32 key_entry, void *pkey)
{
	RMstatus err = RM_OK;
	enum DEMUX_WRITE_XOS_Key_Type type;
	union Demux_Cipher_Key key;

	switch (pCipher->cipher_entry[cipher_entry].type) {

	case EMhwlibCipher_AES:
		if( pCipher->cipher_entry[cipher_entry].key_size == 256 ) {
			type = DEMUX_WRITE_AES_256BITS_KEY_IV;
			key.aes256BitKey.pKey = (RMuint32*)((struct DemuxTask_AESKey_type *)pkey)->key;
			key.aes256BitKey.pIV = (RMuint32*)((struct DemuxTask_AESKey_type *)pkey)->iv;
		}
		else if( pCipher->cipher_entry[cipher_entry].key_size == 128 ) {
			type = DEMUX_WRITE_AES_128BITS_KEY_IV;
			key.aes128BitKey.pKey = (RMuint32*)((struct DemuxTask_AESKey_type *)pkey)->key;
			key.aes128BitKey.pIV = (RMuint32*)((struct DemuxTask_AESKey_type *)pkey)->iv;
		}
		else {
			RMDBGLOG(( ENABLE, "Error XPUWriteKey: Unimplemented aes key size\n" ));
			return RM_ERROR;
		}
		break;
	case EMhwlibCipher_DES:
		// TDES not yet implemented in xtask
		type = DEMUX_WRITE_DES_64BITS;
		key.desKey.pKey = (RMuint32*)((struct DemuxTask_TDESKey_type *)pkey)->key1;
		break;

	case EMhwlibCipher_DVBCSA:
		{
			/* check for DVBCSA conformance mechanism */
			struct DemuxTask_DVBCSAKey_type *pKey = (struct DemuxTask_DVBCSAKey_type *)pkey;
			RMuint8 byte0 = (pKey->key[1] + pKey->key[2] + pKey->key[3])%256;
			RMuint8 byte4 = (pKey->key[5] + pKey->key[6] + pKey->key[7])%256;
			if ((pKey->key[0]!= byte0) || (pKey->key[4]!=byte4)) {
				RMDBGLOG((ENABLE, "forcing dvb csa conformance\n"));
				pKey->key[0] = byte0;
				pKey->key[4] = byte4;
			}
		}
		type = DEMUX_WRITE_DVB_64BITS;
		key.dvbKey.pKey = (RMuint32*)((struct DemuxTask_DVBCSAKey_type *)pkey)->key;
		key.dvbKey.key_space = 0; // 0 = even, 1 = odd
		break;

	case EMhwlibCipher_Multi2:
		type = DEMUX_WRITE_MULTI2;
		key.multi2Key.sysKey.pKey = (RMuint32*)((struct DemuxTask_Multi2Key_type *)pkey)->system_key;
		key.multi2Key.dataKey.pKey = (RMuint32*)((struct DemuxTask_Multi2Key_type *)pkey)->data_key;
		key.multi2Key.IV.pKey = (RMuint32*)((struct DemuxTask_Multi2Key_type *)pkey)->iv;
		break;

	default:
		RMDBGLOG(( ENABLE, "Error XPUWriteKey: Unknown cipher type \n" ));
		return RM_ERROR;
	}

#if (EM86XX_CHIP >= EM86XX_CHIPID_TANGO3)
	err = setDemuxCipherKey(&key, type, FALSE, pCipher->cipher_entry[cipher_entry].key_entry[key_entry].index, DWK_DEMUX_ENGINE_0);
#else // old api
	err = setDemuxCipherKey(&key, type, FALSE, pCipher->cipher_entry[cipher_entry].key_entry[key_entry].index);
#endif
	if ( err != RM_OK ) {
		RMDBGLOG(( ENABLE, "Error XPUWriteKey: setDemuxWriteKey\n" ));
	}

	return err;
}

#else /* no USE_XPU_WRITE_KEY */

static RMstatus WriteKey(struct RUA *pRUA, struct rmfp_cipher_context *pCipher, RMuint32 cipher_entry, RMuint32 key_entry, void *pkey)
{
	/* write the key at cipher_entry, key_entry */
	RMstatus err = RM_ERROR;

	switch (pCipher->cipher_entry[cipher_entry].type) {

	case EMhwlibCipher_AES:
		((struct DemuxTask_AESKey_type *)pkey)->key_index = pCipher->cipher_entry[cipher_entry].key_entry[key_entry].index;
		((struct DemuxTask_AESKey_type *)pkey)->key_size = pCipher->cipher_entry[cipher_entry].key_size / 8;
		err = RUASetProperty(pRUA, pCipher->demux_task, RMDemuxTaskPropertyID_AESKey,
			(struct DemuxTask_AESKey_type *)pkey, sizeof(struct DemuxTask_AESKey_type), 0);
		if (RMFAILED(err)) {
			RMNOTIFY((NULL, err, "Error AES EMhwlibWriteKey\n"));
		}
		break;

	case EMhwlibCipher_DES:
		((struct DemuxTask_TDESKey_type *)pkey)->key_index = pCipher->cipher_entry[cipher_entry].key_entry[key_entry].index;
		err = RUASetProperty(pRUA, pCipher->demux_task, RMDemuxTaskPropertyID_TDESKey,
			(struct DemuxTask_TDESKey_type *)pkey, sizeof(struct DemuxTask_TDESKey_type), 0);
		if (RMFAILED(err)) {
			RMNOTIFY((NULL, err, "Error TDES EMhwlibWriteKey\n"));
		}
		break;

	case EMhwlibCipher_DVBCSA:
		((struct DemuxTask_DVBCSAKey_type *)pkey)->key_index = pCipher->cipher_entry[cipher_entry].key_entry[key_entry].index;
		{
			/* check for DVBCSA conformance mechanism */
			struct DemuxTask_DVBCSAKey_type *pKey = (struct DemuxTask_DVBCSAKey_type *)pkey;
			RMuint8 byte0 = (pKey->key[1] + pKey->key[2] + pKey->key[3])%256;
			RMuint8 byte4 = (pKey->key[5] + pKey->key[6] + pKey->key[7])%256;
			if ((pKey->key[0]!= byte0) || (pKey->key[4]!=byte4)) {
				RMDBGLOG((ENABLE, "forcing dvb csa conformance\n"));
				pKey->key[0] = byte0;
				pKey->key[4] = byte4;
			}
		}

		err = RUASetProperty(pRUA, pCipher->demux_task, RMDemuxTaskPropertyID_DVBCSAKey,
			(struct DemuxTask_DVBCSAKey_type *)pkey, sizeof(struct DemuxTask_DVBCSAKey_type), 0);
		if (RMFAILED(err)) {
			RMNOTIFY((NULL, err, "Error DVBCSA EMhwlibWriteKey\n"));
		}
		break;

	case EMhwlibCipher_Multi2:
		((struct DemuxTask_Multi2Key_type *)pkey)->key_index = pCipher->cipher_entry[cipher_entry].key_entry[key_entry].index;
		err = RUASetProperty(pRUA, pCipher->demux_task, RMDemuxTaskPropertyID_Multi2Key,
			(struct DemuxTask_Multi2Key_type *)pkey, sizeof(struct DemuxTask_Multi2Key_type), 0);
		if (RMFAILED(err)) {
			RMNOTIFY((NULL, err, "Error Multi2 EMhwlibWriteKey\n"));
		}
		break;
	default:
		RMNOTIFY((NULL, err, "EMhwlibWriteKey Error - unsupported cipher type\n"));
		break;
	}
	return err;
}

#endif /* USE_XPU_WRITE_KEY */

static RMstatus WriteKLDataKey(struct RUA *pRUA, struct rmfp_cipher_context *pCipher, RMuint32 i, RMuint32 j, void *pCkey, RMuint32 Csize, void *piv, RMuint32 iv_size)
{
	/* decrypt the encrypted key using key ladder */
	RMstatus err = RM_ERROR;
	struct rmfp_cipher_params* pcipher_entry = &pCipher->cipher_entry[i];

	if (pcipher_entry->kl_otp) {
		struct DemuxTask_KLData_type kl;
		
		kl.authentication = FALSE;

		// key ladder cipher type: AES or TDES
		kl.kl_cipher_type = pcipher_entry->kl_cipher_type;
		
		// key ladder input data A or 1 = content key = 16 bytes
		kl.kl_data_A_size = pcipher_entry->kl_data_A_size; // 16 bytes
		RMMemcpy(kl.kl_data_A, pcipher_entry->kl_data_A, kl.kl_data_A_size);
		
		// key ladder input data B or 2 = content key = 16 bytes
		kl.kl_data_B_size = pcipher_entry->kl_data_B_size;
		RMMemcpy(kl.kl_data_B, pcipher_entry->kl_data_B, kl.kl_data_B_size);
		
		// key ladder input data C or 3 = encrypted key =  16 bytes for AES, 8 bytes for dvbcsa
		kl.kl_data_C_size = Csize;
		RMMemcpy(kl.kl_data_C, pCkey, Csize);
		
		// key ladder secret key
		kl.secret_key_size = pcipher_entry->kl_secret_key_size; // if size is 0 = no secret_key
		RMMemcpy(kl.secret_key, pcipher_entry->kl_secret_key, kl.secret_key_size);

		// cipher type for the output key (clear key): AES or DVBCSA
		kl.cipher_type = pcipher_entry->type;

		// key index for the output key (clear key in AES or DVBCSA tables)
		kl.key_index = pcipher_entry->key_entry[j].index;
		
		// key size for the output key (clear key)
		kl.key_size = pcipher_entry->key_size / 8;

		// iv for the output key. Not needed for DVBCSA.
		kl.iv_size = iv_size;
		RMMemcpy(kl.iv, piv, kl.iv_size);
		
		err = RUASetProperty(pRUA, pCipher->demux_task, RMDemuxTaskPropertyID_KLData,
			&kl, sizeof(kl), 0);
		if (RMFAILED(err)) {
			RMNOTIFY((NULL, RM_ERROR, "WriteKLDataKey: Error RMDemuxTaskPropertyID_KLData\n"));
			return err;
		}
		return RM_OK;
	}
	return RM_ERROR;
}

static RMstatus ReadKeyFromFileAndWriteKey(struct RUA *pRUA, struct rmfp_cipher_context *pCipher, RMuint32 cipher_entry, RMuint32 key_entry)
{
	/* read the key from file and write the key at cipher_entry, key_entry */
	RMstatus err = RM_ERROR;
	RMbool swap_key = pCipher->cipher_entry[cipher_entry].swap_key;

	switch (pCipher->cipher_entry[cipher_entry].type) {
		case EMhwlibCipher_DES:
		{
			struct DemuxTask_TDESKey_type tdes_key;

			/* read the key from file */
			READ_KEY(tdes_key.key1, 8, swap_key);
			READ_KEY(tdes_key.key2, 8, swap_key);
			READ_KEY(tdes_key.key3, 8, swap_key);
			READ_KEY(tdes_key.iv, 8, swap_key);

			/* write the key at cipher_entry, key_entry */
			err = WriteKey(pRUA, pCipher, cipher_entry, key_entry, &tdes_key);
			break;
		}
		case EMhwlibCipher_AES:
		{
			struct DemuxTask_AESKey_type aes_key;

			/* read the key from file */
			aes_key.key_size = pCipher->cipher_entry[cipher_entry].key_size / 8;
			READ_KEY(aes_key.key, aes_key.key_size, swap_key);
			READ_KEY(aes_key.iv, aes_key.key_size, swap_key);

			/* write the key at cipher_entry, key_entry */
			err = WriteKey(pRUA, pCipher, cipher_entry, key_entry, &aes_key);
			break;
		}
		case EMhwlibCipher_DVBCSA:
		{
			struct DemuxTask_DVBCSAKey_type dvbcsa_key;

			/* read the key from file */
			READ_KEY(dvbcsa_key.key, 8, swap_key);

			/* write the key at cipher_entry, key_entry */
			err = WriteKey(pRUA, pCipher, cipher_entry, key_entry, &dvbcsa_key);
			break;
		}
		case EMhwlibCipher_Multi2:
		{
			struct DemuxTask_Multi2Key_type multi2_key;

			/* read the key from file */
			READ_KEY(multi2_key.system_key, 32, swap_key);
			READ_KEY(multi2_key.data_key, 8, swap_key);
			READ_KEY(multi2_key.iv, 8, swap_key);

			/* write the key at cipher_entry, key_entry */
			err = WriteKey(pRUA, pCipher, cipher_entry, key_entry, &multi2_key);
			break;
		}
		default:
			RMNOTIFY((NULL, err, "Unsupported cipher type %ld", pCipher->cipher_entry[cipher_entry].type));
			break;
	}
	return err;
}

/********************************* midcipher_fixed *****************************
 The input streams are transport streams in clear or transport streams with encrypted
 payload (TS header in clear).
 The function midcipher_fixed() is called by notify_pid_creation.
 At PAT creation it reads the ciphers and the keys from the config file for both decipher and recipher process.
 It writes the keys and marks the pids for deciphering and/or reciphering.
 If recipher is present it is always allocated first.
 Test cases:
  * TDES_ECB - Bug 8603.
  The stream has all the packets encrypted (including PAT, PMT) with one key, TDES_ECB.
   test_rmfp -cmdline /users/aurelia/mpeg/cipher/config/midcipher_fixed/tdes_ecb.cmdline
  * AES_CBC - Bug 10138.
  The stream has video and audio pids encrypted with one key and iv, AES CBC.
  Every TS packet is encrypted on first 176 bytes. Last 8 bytes are clear.
   test_rmfp -cmdline /users/aurelia/mpeg/cipher/config/midcipher_fixed/aes_cbc.cmdline
  * AES_CBC decipher and recipher.
  By default the application will record the data in reciphered.ts file.
   test_rmfp -cmdline /users/aurelia/mpeg/cipher/config/midcipher_fixed/recipher_with_aes_cbc.cmdline
   To be able to play the file reciphered.ts run:
    test_rmfp -cipher  /users/aurelia/mpeg/cipher/config/midcipher_fixed/aes_cbc.config reciphered.ts,
   since the key for reciphering and deciphering are the same in the two config files.

  * AES_CBC decipher and AES_CBC with OFB recipher.
   test_rmfp -cmdline /users/aurelia/mpeg/cipher/config/midcipher_fixed/recipher_with_nagra_aes_cbc_ofb.cmdline
   To be able to play the file reciphered.ts modify run:
    test_rmfp -cipher  /users/aurelia/mpeg/cipher/config/midcipher_fixed/nagra_aes_cbc_ofb.config reciphered.ts,
   since the key for reciphering and deciphering are the same in the two config files.

  * other decipher only test cases:
	test_rmfp -cmdline /users/aurelia/mpeg/cipher/config/midcipher_fixed/nagra_aes_cbc.cmdline
	test_rmfp -cmdline /users/aurelia/mpeg/cipher/config/midcipher_fixed/nagra_aes_ecb.cmdline
	test_rmfp -cmdline /users/aurelia/mpeg/cipher/config/midcipher_fixed/aes_ctr_hdcp20_pes.cmdline
	test_rmfp -cmdline /users/aurelia/mpeg/cipher/config/midcipher_fixed/aes_cbc_ofb.cmdline (bug 11896)
*******************************************************************************/
static RMstatus midcipher_fixed(void *pContext, struct RMFPPID *pPID)
{
	struct rmfp_main_thread_context_type *pHandle;
	struct rmfp_cipher_context *pCipher;
	RMstatus err = RM_ERROR;
	struct DCCDemuxTaskPidEntryProfile pid_info;

	ASSERT_NULL_POINTER(pContext);
	ASSERT_NULL_POINTER(pPID);

	pHandle = (struct rmfp_main_thread_context_type *)pContext;
	pCipher = &(pHandle->cipher_context);

	err = DCCGetInfoPidEntry(pPID->pDCCPidEntry, &pid_info);
	if (err != RM_OK)
	{
		RMNOTIFY((NULL, err, "midcipher_fixed: DCCGetInfoPidEntry\n"));
		return err;
	}

	RMDBGLOG((LOCALDBG, "midcipher_fixed: new PID created 0x%x @ index=%d type=%ld (%s)\n",
		pid_info.pid, pid_info.pid_index, pid_info.type, _get_pid_type_string(pid_info.type)));

	if ( pid_info.type == RMFP_pid_type_pat ) {
		RMuint32 i, j;
		
		/* read all the keys from file for recipher and/or decipher entries */
		for( i=0; i<pCipher->cipher_count; i++) {
			for( j=0; j<pCipher->cipher_entry[i].key_count; j++) {
				if ( pCipher->cipher_entry[i].kl_otp ) {
					RMuint8 Ckey[16], iv[16];
					RMuint32 iv_size = 0;
					if ((pCipher->cipher_entry[i].type != EMhwlibCipher_DES) &&
						(pCipher->cipher_entry[i].type != EMhwlibCipher_AES)) {
						return RM_ERROR;
					}
					READ_KEY(Ckey, pCipher->cipher_entry[i].kl_data_C_size, pCipher->cipher_entry[i].swap_key);
					if (pCipher->cipher_entry[i].type != EMhwlibCipher_DVBCSA) {
						iv_size = pCipher->cipher_entry[i].key_size / 8;
						READ_KEY(iv, iv_size, pCipher->cipher_entry[i].swap_key);
					}
					err = WriteKLDataKey(pHandle->pRUA, pCipher, i, j, Ckey, pCipher->cipher_entry[i].kl_data_C_size, iv, iv_size);
				}
				else
					err = ReadKeyFromFileAndWriteKey(pHandle->pRUA, pCipher, i, j);
				if (RMFAILED(err)) {
					return err;
				}

				RMDBGLOG((LOCALDBG, "midcipher_fixed: OutbandKeyChange cipher=0x%lx key=0x%lx at byte_counter=0x%lx\n",
					pCipher->cipher_entry[i].index, pCipher->cipher_entry[i].key_entry[j].index, pCipher->byte_counter));
				/* announce the key change through outband command */
				err = OutbandKeyChange(pHandle->pRUA, pCipher, i, j);
				if (RMFAILED(err)) {
					return err;
				}
			}
		}
		if (pCipher->recipher_count) {
			/* setup the option for reciphering - always cipher_entry 0. */
			struct DemuxTask_RecipherOptions_type pidrecipheroptions;

			pidrecipheroptions.cipher_index = pCipher->cipher_entry[0].index;
			pidrecipheroptions.mode = pCipher->recipher_mode;
			pidrecipheroptions.scrambling_bits = pCipher->recipher_scrambling_bits;

			RMDBGLOG((LOCALDBG, "midcipher_fixed: RecipherOptions cipher=0x%lx recipher_mode=%ld recipher_scrambling_bits=%ld\n",
				pCipher->cipher_entry[0].index, pCipher->recipher_mode, pCipher->recipher_scrambling_bits));
			err = RUASetProperty(pHandle->pRUA, pCipher->demux_task, RMDemuxTaskPropertyID_RecipherOptions, &pidrecipheroptions, sizeof(pidrecipheroptions), 0);
			if (RMFAILED(err)) {
				RMNOTIFY((NULL, RM_ERROR, "midcipher_fixed: Error RMDemuxTaskPropertyID_RecipherOptions"));
				return err;
			}
		}

	}

	/* mark the pids for recipher */
	if (	pCipher->recipher_count &&
		(((pid_info.type == RMFP_pid_type_pat) && pCipher->recipher_pat) ||
		((pid_info.type == RMFP_pid_type_pmt) && pCipher->recipher_pmt) ||
		((pid_info.type == RMFP_pid_type_video) && pCipher->recipher_vpid) ||
		((pid_info.type == RMFP_pid_type_audio) && pCipher->recipher_apid)) ) {

		struct DemuxTask_PidEntryRecipher_type cipher;

		RMDBGLOG((LOCALDBG, "midcipher_fixed: mark PID for recipher: pid=0x%x pid_index=%ld pid_type=%ld (%s)\n",
			pid_info.pid, pid_info.pid_index, pid_info.type, _get_pid_type_string(pid_info.type)));

		cipher.index = pid_info.pid_index;
		cipher.enable = TRUE;
		err = RUASetProperty(pHandle->pRUA, pCipher->demux_task, RMDemuxTaskPropertyID_PidEntryRecipher, &cipher, sizeof(cipher), 0);
		if (RMFAILED(err)) {
			RMNOTIFY((NULL, RM_ERROR, "midcipher_fixed: Error RMDemuxTaskPropertyID_PidEntryRecipher pid=0x%x pid_index=%ld cipher_index=%ld\n",
				pid_info.pid, pid_info.pid_index, pCipher->cipher_entry[0].index));
			return err;
		}
	}
	if (pHandle->current_pmt.ecm_count) {
		// mark the pids as encrypted if there is ecm per program
		pCipher->encrypted_vpid = 1;
		pCipher->encrypted_apid = 1;
		pCipher->encrypted_subpictures = 1;
		pCipher->encrypted_ttx = 1;
	}
	if (	((pid_info.type == RMFP_pid_type_pat) && pCipher->encrypted_pat) ||
		((pid_info.type == RMFP_pid_type_pmt) && pCipher->encrypted_pmt) ||
		((pid_info.type == RMFP_pid_type_video) && pCipher->encrypted_vpid) ||
		((pid_info.type == RMFP_pid_type_audio) && pCipher->encrypted_apid) ||
		((pid_info.type == RMFP_pid_type_subpictures) && pCipher->encrypted_subpictures) ||
		((pid_info.type == RMFP_pid_type_ttx) && pCipher->encrypted_ttx) ) {

		struct DemuxTask_PidEntryAddCipher_type cipher;

		RMDBGLOG((LOCALDBG, "midcipher_fixed: mark PID for decipher pid=0x%x pid_index=%ld pid_type=%ld (%s)\n",
			pid_info.pid, pid_info.pid_index, pid_info.type, _get_pid_type_string(pid_info.type)));

		cipher.index = pid_info.pid_index;
		cipher.pid_cipher_index = 0;    /* only index 0 is permitted in current EMhwlib implementation */
		cipher.cipher_index = pCipher->cipher_entry[pCipher->recipher_count].index; /* use just first cipher entry */
		err = RUASetProperty(pHandle->pRUA, pCipher->demux_task, RMDemuxTaskPropertyID_PidEntryAddCipher,
			&cipher, sizeof(cipher), 0);
		if (RMFAILED(err)) {
			RMNOTIFY((NULL, RM_ERROR, "midcipher_fixed: Error RMDemuxTaskPropertyID_PidEntryAddCipher : pid=0x%x pid_index=%ld cipher_index=%ld\n",
				pid_info.pid, pid_info.pid_index, pCipher->cipher_entry[pCipher->recipher_count].index));
			return err;
		}
	}
	return RM_OK;
}

/*********************************** midcipher_ecm *****************************
 The streams have the TS header (4 bytes) in clear.
 The files have ECM pids that carry in the odd/even section the encrypted key.
 The function midcipher_ecm() is called by notify_pid_creation.
   At PAT creation it marks the pids for decipher.
 The function create_ecm_pid() is called by notify_send_data when bytecounter=0.
   It creates the ECM pid with the section filtering the table id 0x80 or 0x81.
 When the section is filtered the ecm_nagra_callback or ecm_arib_callback is called and the key is read and writen.

 Test cases:
  * DVBCSA - Bug 10138.
     test_rmfp -cmdline /users/aurelia/mpeg/cipher/config/midcipher_ecm/dvbcsa_4ecm.cmdline
  One single ECM for both video and audio pids.
  The clear keys are provided in the config file in correct order: even, odd, even, odd as the ECM is detected.
  * Multi2
     test_rmfp -cmdline /users/aurelia/mpeg/cipher/config/midcipher_ecm/multi2_BSwowow.cmdline
  * clear keys in ecm
     test_rmfp -cmdline /users/aurelia/mpeg/cipher/config/midcipher_ecm/nagra_dvbcsa.cmdline
  * encrypted keys in ecm
     test_rmfp -cmdline /users/aurelia/mpeg/cipher/config/midcipher_ecm/nagra_dvbcsa_kl_otp.cmdline
*******************************************************************************/
static RMstatus ecm_nagra_callback(RMuint8 *pBuffer1, RMuint32 size1, RMuint8 *pBuffer2, RMuint32 size2, void *pContext)
{
	RMstatus err = RM_OK;
	struct rmfp_main_thread_context_type *pHandle;
	struct rmfp_cipher_context *pCipher;
	RMuint8 *p;

	ASSERT_NULL_POINTER(pContext);
	ASSERT_NULL_POINTER(pBuffer1);

	pHandle = (struct rmfp_main_thread_context_type *)pContext;
	pCipher = &(pHandle->cipher_context);

	p = pBuffer1;

	if ( (*p == 0x80) || (*p == 0x81) ) {
		RMuint32 section_len, ecm_data_compare_len;

		section_len = ((*(p + 1) & 0x0F) << 8) | *(p + 2);
		if (section_len > 8)
			ecm_data_compare_len = RMmin(section_len - 8, 16);
		else
			ecm_data_compare_len = 0;

		/* Section part - filter for the other table_id */
		err = RMFPDeleteCustomPIDFilterSection(pHandle->pHandle, pCipher->ecm_pid_handle, &pCipher->ecm_section);
		if (RMFAILED(err)) {
			RMNOTIFY((NULL, RM_ERROR, "ecm_nagra_callback: Error RMFPDeleteCustomPIDFilterSection\n"));
			return err;
		}
		pCipher->ecm_section.mask[0] = 0xff; // ignore bit 0
		pCipher->ecm_section.mode[0] = 0xff; // positive mode
		pCipher->ecm_section.comp[0] = (*p) ^ 1; // filter for the other table_id
		err = RMFPAddCustomPIDFilterSection(pHandle->pHandle, pCipher->ecm_pid_handle, &pCipher->ecm_section);
		if (RMFAILED(err)) {
			RMNOTIFY((NULL, RM_ERROR, "ecm_nagra_callback: Error RMFPAddCustomPIDFilterSection\n"));
			return err;
		}

		if (pCipher->prev_table_id != *p) {
			pCipher->prev_table_id = *p;
			/* new key detected - we suppose only one cipher entry and the keys in clear */
			if (pCipher->ecm_protocol == ecm_protocol_nagra_fixed_keys_0x80_even_0x81_odd) {
				RMuint32 i, j;
				i = 0; // cipher entry
				j = (*p == 0x80) ? 0 : 1; // key entry
				RMDBGLOG((ENABLE, "ecm_%x ", *p));
				if ( pCipher->cipher_entry[i].kl_otp ) {
					RMuint8 Ckey[16], iv[16];
					RMuint32 iv_size = 0;
					if ((pCipher->cipher_entry[i].type != EMhwlibCipher_DES) &&
						(pCipher->cipher_entry[i].type != EMhwlibCipher_AES)) {
						return RM_ERROR;
					}
					READ_KEY(Ckey, pCipher->cipher_entry[i].kl_data_C_size, pCipher->cipher_entry[i].swap_key);
					if (pCipher->cipher_entry[i].type != EMhwlibCipher_DVBCSA) {
						iv_size = pCipher->cipher_entry[i].key_size / 8;
						READ_KEY(iv, iv_size, pCipher->cipher_entry[i].swap_key);
					}
					err = WriteKLDataKey(pHandle->pRUA, pCipher, i, j, Ckey, pCipher->cipher_entry[i].kl_data_C_size, iv, iv_size);
				}
				else
					err = ReadKeyFromFileAndWriteKey(pHandle->pRUA, pCipher, i, j);
				if (RMFAILED(err)) {
					return err;
				}

				/* announce the key change through outband command */
				err = OutbandKeyChange(pHandle->pRUA, pCipher, 0, (*p == 0x80) ? 0 : 1);
				if (RMFAILED(err)) {
					return err;
				}
			}
			else if (pCipher->ecm_protocol == ecm_protocol_nagra) {
				RMuint8 key[16], iv[16];
				RMuint32 i, size, key_entry, iv_size;

				size = pCipher->cipher_entry[0].kl_otp ? pCipher->cipher_entry[0].kl_data_C_size : (pCipher->cipher_entry[0].key_size / 8);
				iv_size = (pCipher->cipher_entry[0].type == EMhwlibCipher_DVBCSA)? 0 : size;
				if (pCipher->cipher_entry[0].type == EMhwlibCipher_DES) {
					size = 16; // read 16 bytes from ECM - specific nagra protocol
					iv_size = 8;
				}
				RMMemset(iv, 0, iv_size); // set to 0 for time being

				// read and write first key from ecm
				key_entry = (*p==0x80)?1:0;
				RMDBGPRINT((LOCALDBG, "ecm=0x%x cw1=%s=", *p, (*p==0x80)?" odd":"even" ));
				for (i=0;i<size;i++) {
					key[i] = *(p+6+size-i);
					RMDBGPRINT((LOCALDBG, "%02x", key[i] ));
				}
				if (pCipher->cipher_entry[0].kl_otp)
					err = WriteKLDataKey(pHandle->pRUA, pCipher, 0, key_entry, key, size, iv, iv_size);
				else if (pCipher->cipher_entry[0].type == EMhwlibCipher_AES) {
					struct DemuxTask_AESKey_type aes_key;
					aes_key.key_size = size;
					RMMemcpy(aes_key.key, key, size);
					RMMemset(aes_key.iv, 0, size);
					err = WriteKey(pHandle->pRUA, pCipher, 0, key_entry, &aes_key);
				}
				else if (pCipher->cipher_entry[0].type == EMhwlibCipher_DVBCSA) {
					struct DemuxTask_DVBCSAKey_type dvbcsa_key;
					RMMemcpy(dvbcsa_key.key, key, size);
					err = WriteKey(pHandle->pRUA, pCipher, 0, key_entry, &dvbcsa_key);
				}
				else if (pCipher->cipher_entry[0].type == EMhwlibCipher_DES) {
					struct DemuxTask_TDESKey_type tdes_key;
					RMMemcpy(tdes_key.key1, key+8, 8);
					RMMemcpy(tdes_key.key3, key+8, 8);
					RMMemcpy(tdes_key.key2, key, 8);
					RMMemset(tdes_key.iv, 0, size);
					err = WriteKey(pHandle->pRUA, pCipher, 0, key_entry, &tdes_key);
				}
				else {
					RMNOTIFY((NULL, RM_ERROR, "ecm_nagra_callback: unsupported cipher type\n"));
					return RM_ERROR;
				}

				err = OutbandKeyChange(pHandle->pRUA, pCipher, 0, key_entry);

				// read and write second key from ecm
				key_entry = (*p==0x80)?0:1;
				RMDBGPRINT((LOCALDBG, " cw2=%s=", (*p==0x80)?"even":" odd" ));
				for (i=0;i<size;i++) {
					key[i] = *(p+6+2*size-i);
					RMDBGPRINT((LOCALDBG, "%02x", key[i] ));
				}
				RMDBGPRINT((LOCALDBG, " %x %x\n", *(p+6+2*size+1), *(p+6+2*size+2) ));
				if (pCipher->cipher_entry[0].kl_otp)
					err = WriteKLDataKey(pHandle->pRUA, pCipher, 0, key_entry, key, size, iv, iv_size);
				else if (pCipher->cipher_entry[0].type == EMhwlibCipher_AES) {
					struct DemuxTask_AESKey_type aes_key;
					aes_key.key_size = size;
					RMMemcpy(aes_key.key, key, size);
					RMMemset(aes_key.iv, 0, size);
					err = WriteKey(pHandle->pRUA, pCipher, 0, key_entry, &aes_key);
				}
				else if (pCipher->cipher_entry[0].type == EMhwlibCipher_DVBCSA) {
					struct DemuxTask_DVBCSAKey_type dvbcsa_key;
					RMMemcpy(dvbcsa_key.key, key, size);
					err = WriteKey(pHandle->pRUA, pCipher, 0, key_entry, &dvbcsa_key);
				}
				else if (pCipher->cipher_entry[0].type == EMhwlibCipher_DES) {
					struct DemuxTask_TDESKey_type tdes_key;
					RMMemcpy(tdes_key.key1, key+8, 8);
					RMMemcpy(tdes_key.key3, key+8, 8);
					RMMemcpy(tdes_key.key2, key, 8);
					RMMemset(tdes_key.iv, 0, size);
					err = WriteKey(pHandle->pRUA, pCipher, 0, key_entry, &tdes_key);
				}
				else {
					RMNOTIFY((NULL, RM_ERROR, "ecm_nagra_callback: unsupported cipher type\n"));
					return RM_ERROR;
				}
				
				err = OutbandKeyChange(pHandle->pRUA, pCipher, 0, key_entry);
			}
			else {
				RMNOTIFY((NULL, RM_ERROR, "ecm_nagra_callback: unsupported ecm_protocol\n"));
				return RM_ERROR;
			}
		}
	}
	return err;
}

static RMstatus ecm_arib_callback(RMuint8 *pBuffer1, RMuint32 size1, RMuint8 *pBuffer2, RMuint32 size2, void *pContext)
{
	RMstatus err = RM_OK;
	struct rmfp_main_thread_context_type *pHandle;
	struct rmfp_cipher_context *pCipher;
	RMuint8 *p;

	ASSERT_NULL_POINTER(pContext);
	ASSERT_NULL_POINTER(pBuffer1);

	pHandle = (struct rmfp_main_thread_context_type *)pContext;
	pCipher = &(pHandle->cipher_context);

	p = pBuffer1;

	if (*p == 0x82) {
		static RMuint8 prev_encrypted_key[16];
		static RMuint32 key_index = 0;
		RMuint32 section_len;
		RMDBGLOG((ENABLE, "ecm_%x ", *p));

		section_len = ((*(p + 1) & 0x0F) << 8) | *(p + 2);
		if (section_len > 16) {
			if (RMMemcmp((void*)(p + 11), (void *)prev_encrypted_key, 16) != 0) {
				/* new key detected - we suppose only one cipher entry and the keys in clear */
				err = ReadKeyFromFileAndWriteKey(pHandle->pRUA, pCipher, 0, key_index);
				if (RMFAILED(err)) {
					return err;
				}

				/* announce the key change through outband command */
				err = OutbandKeyChange(pHandle->pRUA, pCipher, 0, key_index);

				if (RMFAILED(err)) {
					return err;
				}
				RMMemcpy(prev_encrypted_key, p + 11, 16);
				key_index ^= 1;
			}
		}
	}
	return err;
}

static RMstatus create_ecm_pid(void *pContext, RMuint32 pid)
{
	RMstatus err;
	struct rmfp_main_thread_context_type *pHandle;
	struct rmfp_cipher_context *pCipher;
	struct RMFPCustomPIDParameters params;

	ASSERT_NULL_POINTER(pContext);

	pHandle = (struct rmfp_main_thread_context_type *)pContext;
	pCipher = &(pHandle->cipher_context);

	params.PID = pid;
	params.data_type = EMhwlibData_PSI;

	if ((pCipher->ecm_protocol == ecm_protocol_nagra) || (pCipher->ecm_protocol == ecm_protocol_nagra_fixed_keys_0x80_even_0x81_odd))
		params.callback = ecm_nagra_callback;
	else if ((pCipher->ecm_protocol == ecm_protocol_arib) || (pCipher->ecm_protocol == ecm_protocol_arib_fixed_keys_0x80_even_0x81_odd))
		params.callback = ecm_arib_callback;
	else
		return RM_ERROR;

	params.pCallbackContext = pContext;

	params.buffer_count = 4;
	params.buffer_size_log2 = 14;
	params.pts_count = 0;
	params.inband_count = 0;

	params.partial_read = TRUE;
	params.threshold = 0; // ignored when partial_read is TRUE

	params.receive_data_type = DCCDemuxOutputType_dma;
	params.receive_mode.dma = DCCReceiveData_dma_no_delay;

	if (!pCipher->valid_ecm_pid_handle) {
		err = RMFPCreateCustomPIDFilter(pHandle->pHandle, &params, &pCipher->ecm_pid_handle);
		if (RMFAILED(err)) {
			RMNOTIFY((NULL, RM_ERROR, "create_ecm_pid: Error RMFPCreateCustomPidFilter\n"));
			return err;
		}
		pCipher->valid_ecm_pid_handle = TRUE;
	}

	if (pCipher->valid_ecm_pid_handle) {
		/* Section part */
		err = RMFPDeleteCustomPIDFilterSection(pHandle->pHandle, pCipher->ecm_pid_handle, &pCipher->ecm_section);
		if (RMFAILED(err)) {
			RMNOTIFY((NULL, RM_ERROR, "create_ecm_pid: Error RMFPDeleteCustomPIDFilterSection\n"));
			return err;
		}

		pCipher->prev_table_id = 0;

		RMMemset(&pCipher->ecm_section, 0, sizeof(pCipher->ecm_section));
		pCipher->ecm_section.expand_link_index = 0xff;
		pCipher->ecm_section.and_link_index = 0xff;
		if ((pCipher->ecm_protocol == ecm_protocol_nagra) || (pCipher->ecm_protocol == ecm_protocol_nagra_fixed_keys_0x80_even_0x81_odd))
			pCipher->ecm_section.mask[0] = 0xfe; // ignore bit 0
		else if ((pCipher->ecm_protocol == ecm_protocol_arib) || (pCipher->ecm_protocol == ecm_protocol_arib_fixed_keys_0x80_even_0x81_odd))
			pCipher->ecm_section.mask[0] = 0xfc; // ignore bits 1,0
		else
			return RM_ERROR;
		pCipher->ecm_section.mode[0] = 0xff; // positive mode
		pCipher->ecm_section.comp[0] = 0x80; // filter for both odd and even keys: 0x80 and 0x81
		err = RMFPAddCustomPIDFilterSection(pHandle->pHandle, pCipher->ecm_pid_handle, &pCipher->ecm_section);
		if (RMFAILED(err)) {
			RMNOTIFY((NULL, RM_ERROR, "create_ecm_pid: Error RMFPAddCustomPIDFilterSection\n"));
			return err;
		}
	}

	return RM_OK;
}

static RMstatus midcipher_ecm(void *pContext, struct RMFPPID *pPID)
{
	struct rmfp_main_thread_context_type *pHandle;
	struct rmfp_cipher_context *pCipher;
	RMstatus err = RM_ERROR;
	struct DCCDemuxTaskPidEntryProfile pid_info;

	ASSERT_NULL_POINTER(pContext);
	ASSERT_NULL_POINTER(pPID);

	pHandle = (struct rmfp_main_thread_context_type *)pContext;
	pCipher = &(pHandle->cipher_context);

	err = DCCGetInfoPidEntry(pPID->pDCCPidEntry, &pid_info);
	if (err != RM_OK)
	{
		RMNOTIFY((NULL, err, "midcipher_ecm: DCCGetInfoPidEntry\n"));
		return err;
	}

	RMDBGLOG((LOCALDBG, "midcipher_ecm: new %s created 0x%x @ index=%d type=%ld (%s)\n",
		(pid_info.type == RMFP_pid_type_custom)?"ECM PID":"PID", pid_info.pid, pid_info.pid_index, pid_info.type, _get_pid_type_string(pid_info.type)));

	if (pHandle->current_pmt.ecm_count) {
		// mark the pids as encrypted if there is ecm per program
		pCipher->encrypted_vpid = 1;
		pCipher->encrypted_apid = 1;
		pCipher->encrypted_subpictures = 1;
		pCipher->encrypted_ttx = 1;
	}
	if (	((pid_info.type == RMFP_pid_type_pat) && pCipher->encrypted_pat) ||
		((pid_info.type == RMFP_pid_type_pmt) && pCipher->encrypted_pmt) ||
		((pid_info.type == RMFP_pid_type_video) && pCipher->encrypted_vpid) ||
		((pid_info.type == RMFP_pid_type_audio) && pCipher->encrypted_apid) ||
		((pid_info.type == RMFP_pid_type_subpictures) && pCipher->encrypted_subpictures) ||
		((pid_info.type == RMFP_pid_type_ttx) && pCipher->encrypted_ttx) ) {

		struct DemuxTask_PidEntryAddCipher_type cipher;

		RMDBGLOG((LOCALDBG, "midcipher_ecm: mark PID for decipher pid=0x%x pid_index=%ld pid_type=%ld (%s)\n",
			pid_info.pid, pid_info.pid_index, pid_info.type, _get_pid_type_string(pid_info.type)));

		cipher.index = pid_info.pid_index;
		cipher.pid_cipher_index = 0;    /* only index 0 is permitted in current implementation */
		cipher.cipher_index = pCipher->cipher_entry[0].index;
		err = RUASetProperty(pHandle->pRUA, pCipher->demux_task, RMDemuxTaskPropertyID_PidEntryAddCipher,
			&cipher, sizeof(cipher), 0);
		if (RMFAILED(err)) {
			RMNOTIFY((NULL, RM_ERROR, "midcipher_ecm: Error RMDemuxTaskPropertyID_PidEntryAddCipher : pid=0x%x pid_index=%ld cipher_index=%ld\n",
				pid_info.pid, pid_info.pid_index, pCipher->cipher_entry[0].index));
			return err;
		}
	}
	return RM_OK;
}

/******************************** precipher_fixed *******************************
 The stream is completely encrypted (preciphered) with:
    - one fixed key.  The "change_key_block_size" should be 0.
    - two fixed keys changed alternatively every "change_key_block_size" bytes.
 The decryption implementation uses either one single key or two keys that are written alternatively.

 The function precipher_fixed() is called by notify_send_data.
 At bytecounter 0 it sets the precipher mode and it reads and writes the hardcoded keys from the config file.
 If the number of bytes sent is modulo of "change_key_block_size" bytes it switches the key through Inband command.
 The command line should contain the application type since the file detector cannot detect encrypted files.
 Test case:
  * AES_CBC - two hardcoded AES CBC keys are alternated for every 0x800000 bytes.
   test_rmfp -cmdline /users/aurelia/mpeg/cipher/config/precipher_fixed/aes_cbc.cmdline
  * other cases with single key - no need to alternate keys
   test_rmfp -cmdline /users/aurelia/mpeg/cipher/config/precipher_fixed/nagra_aes_cbc.cmdline
   test_rmfp -cmdline /users/aurelia/mpeg/cipher/config/precipher_fixed/nagra_aes_ecb.cmdline
   test_rmfp -cmdline /users/aurelia/mpeg/cipher/config/precipher_fixed/nagra_tdes_cbc.cmdline
   test_rmfp -cmdline /users/aurelia/mpeg/cipher/config/precipher_fixed/nagra_tdes_ecb.cmdline
*******************************************************************************/
static RMstatus precipher_fixed(void *pContext)
{
	struct rmfp_main_thread_context_type *pHandle;
	struct rmfp_cipher_context *pCipher;
	RMstatus err = RM_ERROR;

	ASSERT_NULL_POINTER(pContext);

	pHandle = (struct rmfp_main_thread_context_type *)pContext;
	pCipher = &(pHandle->cipher_context);

	if (pCipher->byte_counter == 0) {
		struct DemuxTask_PreprocessCipher_type ppc;
		RMuint32 j;

		ppc.enable = TRUE;
		ppc.cipher_index = pCipher->cipher_entry[0].index;
		err = RUASetProperty(pHandle->pRUA, pCipher->demux_task, RMDemuxTaskPropertyID_PreprocessCipher, &ppc, sizeof(ppc), 0);
		if (RMFAILED(err)) {
			RMNOTIFY((NULL, err, "precipher_fixed: Error RMDemuxTaskPropertyID_PreprocessCipher\n"));
			return RM_ERROR;
		}

		/* read the keys from file for the cipher_entry */
		for( j=0; j<pCipher->cipher_entry[0].key_count; j++) {
			err = ReadKeyFromFileAndWriteKey(pHandle->pRUA, pCipher, 0, j);
			if (RMFAILED(err)) {
				return err;
			}

			/* announce the key change through outband command */
			err = OutbandKeyChange(pHandle->pRUA, pCipher, 0, j);
			if (RMFAILED(err)) {
				return err;
			}
		}
	}

	if (pCipher->change_key_block_size) {
		if ((pCipher->byte_counter % pCipher->change_key_block_size) == 0) {
			RMuint32 key_entry = (pCipher->byte_counter / pCipher->change_key_block_size) & 1;

			RMDBGLOG((ENABLE, "precipher_fixed: InbandKeyChange bc=0x%lx cipher_index=0x%lx key_index=0x%lx\n", pCipher->byte_counter, pCipher->cipher_entry[0].index, key_entry));

			/* announce key change at cipher_entry 0, key_entry */
			err = InbandKeyChange(pHandle->pRUA, pCipher, 0, key_entry, EMhwlibInbandOffset_Ignore, 0);
			if (RMFAILED(err)) {
				return err;
			}
		}
	}

	return RM_OK;
}

/******************************* precipher_ivdr ********************************
 The stream is completely encrypted (preciphered).
 The key and iv changes every "refresh_key_iv_block_count * refresh_iv_block_size bytes".
 The iv is refreshed every "refresh_iv_block_size" or "CBC block chain size" bytes:

  <-- refresh_iv_block_size --><-- refresh_iv_block_size -->  ........<-- refresh_iv_block_size -->
   block 0                      block 1                      ........  block "refresh_key_iv_block_count"
  [xxxxxxxxxxxxxxxxxxxxxxxxxxx][xxxxxxxxxxxxxxxxxxxxxxxxxxx] ........ [xxxxxxxxxxxxxxxxxxxxxxxxxxx]

  key+iv                        iv                                     iv                         key+iv
  |----------------------------|---------------------------| ........ |---------------------------|

 The config file provides:
   - refresh_iv_block_size (in hex)
   - refresh_key_iv_block_count (in hex)
   - bytecounter, key and iv (in hex) on next lines. The keys will be read and swapped to match the hardware.
 The command line should contain the application type since the file detector cannot detect encrypted files.

 The function precipher_ivdr() is called by notify_send_data. It sets the precipher mode.
 At bytecounter 0 it sets the precipher mode and it reads and writes the keys from the config file and apply them at specific offsets in file.
 Test cases:
  * AES_CBC multiple keys
    test_rmfp -cmdline /users/aurelia/mpeg/cipher/config/precipher_ivdr/aes_cbc_1.cmdline
  * AES_CBC one key
    test_rmfp -cmdline /users/aurelia/mpeg/cipher/config/precipher_ivdr/aes_cbc_2.cmdline
*******************************************************************************/
static RMstatus precipher_ivdr(void *pContext, RMuint32 send_size)
{
	struct rmfp_main_thread_context_type *pHandle;
	struct rmfp_cipher_context *pCipher;
	RMstatus err = RM_ERROR;
	RMuint32 blocks_to_send, size, k, offset;

	ASSERT_NULL_POINTER(pContext);

	pHandle = (struct rmfp_main_thread_context_type *)pContext;
	pCipher = &(pHandle->cipher_context);

	if (pCipher->byte_counter == 0) {
		struct DemuxTask_PreprocessCipher_type ppc;

		ppc.enable = TRUE;
		ppc.cipher_index = pCipher->cipher_entry[0].index;
		err = RUASetProperty(pHandle->pRUA, pCipher->demux_task, RMDemuxTaskPropertyID_PreprocessCipher, &ppc, sizeof(ppc), 0);
		if (RMFAILED(err)) {
			RMNOTIFY((NULL, err, "precipher_ivdr: Error RMDemuxTaskPropertyID_PreprocessCipher\n"));
			return RM_ERROR;
		}
		pCipher->iv_block_count = 0;
	}

	/* don't send inbands in advance of data */
	if ( (pCipher->byte_counter + send_size) < pCipher->iv_block_count*pCipher->refresh_iv_block_size )
		return RM_OK;

	/* calculate the number of complete iv_blocks available for send including the incomplete one from the end */
	blocks_to_send = (pCipher->byte_counter + send_size - (pCipher->iv_block_count*pCipher->refresh_iv_block_size)) / pCipher->refresh_iv_block_size;
	if ( (pCipher->byte_counter + send_size) % pCipher->refresh_iv_block_size )
		blocks_to_send++;

	/* check if there are blocks_to_send empty entries in inband fifo for the next buffer */
	err = RUAGetProperty(pHandle->pRUA, pCipher->demux_task, RMDemuxTaskPropertyID_InbandFifoWritableSize, &size, sizeof(size));
	if ((size < blocks_to_send) || RMFAILED(err)) {
		RMDBGLOG((DISABLE, "precipher_ivdr: insufficient InbandFifoWritableSize= %ld blocks_to_send= %ld 0x%lx 0x%lx 0x%lx\n",
			size, blocks_to_send, pCipher->byte_counter, send_size, pCipher->iv_block_count*pCipher->refresh_iv_block_size));
		// the main thread will wait
		return RM_PENDING;
	}

	/* Inband Key Change or IV refresh - align the inband based on refresh_iv_block_size */
	offset = (pCipher->iv_block_count*pCipher->refresh_iv_block_size) - pCipher->byte_counter;

	for (k=0; k<blocks_to_send; k++) {
		RMuint32 key_entry;

		/* Alternate key_entry when pCipher->refresh_key_iv_block_count is reached.
		 It is assumed that the input demux buffer is smaller than the size of data encrypted with one key. */
		
		key_entry = (pCipher->iv_block_count / pCipher->refresh_key_iv_block_count) & 1;
		if (pCipher->iv_block_count % pCipher->refresh_key_iv_block_count == 0) {

			RMuint32 n;

			if (!feof(pCipher->config_file)) {
				if (EOF == fscanf(pCipher->config_file, "%lx", &n)) {
					RMDBGLOG((PARSE_CIPHER_DBG, "precipher_ivdr: key file end - use last key and refresh iv\n"));
					goto refresh_iv;
				}
			}
			RMDBGLOG((ENABLE, "n=%lx\n", n));

			/* try to read the key from file and write the keys to hardware */
			err = ReadKeyFromFileAndWriteKey(pHandle->pRUA, pCipher, 0, key_entry);
			if (RMFAILED(err)) {
				RMDBGLOG((PARSE_CIPHER_DBG, "precipher_ivdr: key file end - use last key and refresh iv\n"));
				goto refresh_iv;
			}
			/* inband with save IV option */
			pCipher->cipher_entry[0].key_entry[key_entry].scrambling_bits = EMhwlibScramblingBits_PreCipherSaveIV;
		}
		else {
refresh_iv:
			/* inband with refresh IV option */
			pCipher->cipher_entry[0].key_entry[key_entry].scrambling_bits = EMhwlibScramblingBits_PreCipherRefreshIV;
		}
		RMDBGLOG((DISABLE, "precipher_ivdr: AES InbandKeyChange %s iv_block_count=%ld bc=0x%lx offs=0x%lx 0x%lx\n",
			(pCipher->cipher_entry[0].key_entry[key_entry].scrambling_bits==EMhwlibScramblingBits_PreCipherSaveIV)?"save iv":"refresh iv",
			pCipher->iv_block_count, pCipher->byte_counter, offset, offset + pCipher->byte_counter));

		err = InbandKeyChange(pHandle->pRUA, pCipher, 0, key_entry, EMhwlibInbandOffset_Relative, offset);
		if (RMFAILED(err)) {
			return err;
		}
		offset += pCipher->refresh_iv_block_size;
		pCipher->iv_block_count++;
	}

	return RM_OK;
}

/**************************************************************************************************/

static RMstatus parse_cipher_config(void *pContext, struct RMFPDemuxCipherResourcesProfile *pProfile)
{
	struct rmfp_main_thread_context_type *pHandle;
	struct rmfp_cipher_context *pCipher;
	char str[80], comment[80];
	RMuint32 i, j, tmp, reserved;

	ASSERT_NULL_POINTER(pContext);
	ASSERT_NULL_POINTER(pProfile);

	pHandle = (struct rmfp_main_thread_context_type *)pContext;
	pCipher = &(pHandle->cipher_context);

	if (pCipher->config_file == NULL) {
		pCipher->config_file = fopen(pHandle->AppOptions.Playback.cipher_config_file_name, "r");
		if (pCipher->config_file == NULL) {
			RMNOTIFY((NULL, RM_ERROR, "cipher config file %s cannot open\n", pHandle->AppOptions.Playback.cipher_config_file_name));
			return RM_ERROR;
		}
	}
	READ_CONFIG(pCipher->cipher_test);
	READ_CONFIG(pCipher->pes_scrambling_control);
	READ_CONFIG(reserved);
	READ_CONFIG(reserved);
	READ_CONFIG(reserved);
	READ_CONFIG(reserved);

	// to parse from config file if needed
	pProfile->XTaskModuleId = 0;
	pProfile->XTaskContext = 0;
	pProfile->XTaskInbandFIFOCount = 0;

	
	/* check "recipher_count=" and/or ("cipher_count=" xor "kl_cipher_count=").
	   For time being kl_cipher and main_cipher are excluding each other for decipher.
	   For recipher we can use just main_cipher. */
	READ_CONFIG(tmp);
	if (!RMMemcmp((void*)str, (void *)"cipher_count=", strlen("cipher_count="))) {
		/* it is "cipher_count=". We don't look for recipher anymore. */
		pCipher->cipher_count = tmp;
	}
	else if (!RMMemcmp((void*)str, (void *)"kl_cipher_count=", strlen("kl_cipher_count="))) {
		/* it is "kl_cipher_count=". We don't look for recipher anymore. */
		pCipher->kl_cipher_count = tmp;
		pCipher->cipher_count = tmp;
	}
	else if (!RMMemcmp((void*)str, (void *)"recipher_count=", strlen("recipher_count="))) {
		/* it is "recipher_count=" */
		pCipher->recipher_count = tmp;
		if (pCipher->recipher_count == 1) {
			i = 0;
			READ_CONFIG(pCipher->cipher_entry[i].type);
			READ_CONFIG(pCipher->cipher_entry[i].mode);
			READ_CONFIG(pCipher->cipher_entry[i].encrypted_packet_format);
			READ_CONFIG(pCipher->cipher_entry[i].key_size);
			READ_CONFIG(pCipher->cipher_entry[i].block_size);
			READ_CONFIG(pCipher->cipher_entry[i].round_value); // Multi2
			READ_CONFIG(pCipher->cipher_entry[i].swap_key);
			READ_CONFIG(reserved);
			READ_CONFIG(reserved);
			READ_CONFIG(pCipher->cipher_entry[i].key_count);

			for(j = 0; j<pCipher->cipher_entry[i].key_count; j++) {
				READ_CONFIG(pCipher->cipher_entry[i].key_entry[j].scrambling_bits);
			}
			READ_CONFIG(pCipher->recipher_mode); //EMhwlibRecipher_passthrough or EMhwlibRecipher_always
			READ_CONFIG(pCipher->recipher_scrambling_bits);
			READ_CONFIG(pCipher->recipher_pat);
			READ_CONFIG(pCipher->recipher_pmt);
			READ_CONFIG(pCipher->recipher_vpid);
			READ_CONFIG(pCipher->recipher_apid);
		}
		else if (pCipher->recipher_count != 0) {
			RMNOTIFY((NULL, RM_ERROR, "parse_cipher_config: unsupported recipher_count %ld !\n", pCipher->recipher_count));
			return RM_ERROR;
		}
		/* at this point recipher_count is 0 or 1, search for "cipher_count=" and skip the recipher info if it is present */
		while (1) {
			READ_CONFIG(pCipher->cipher_count);
			if (RMMemcmp((void*)str, (void *)"cipher_count=", strlen("cipher_count="))) {
				RMDBGLOG((PARSE_CIPHER_DBG, "parse_cipher_config: skip this line and search for cipher_count !\n"));
			}
			else
				break;
		}
	}
	else {
		/* it isn't any of "cipher_count=" or "recipher_count=" */
		RMNOTIFY((NULL, RM_ERROR, "parse_cipher_config: no cipher_count or recipher_count !\n"));
		return RM_ERROR;
	}

	pCipher->cipher_count += pCipher->recipher_count;

	if (pCipher->cipher_count > MAX_CIPHERS) {
		RMNOTIFY((NULL, RM_ERROR, "parse_cipher_config: not enough ciphers %ld\n", pCipher->cipher_count));
		return RM_ERROR;
	}

	for(i = pCipher->recipher_count; i<pCipher->cipher_count; i++) {
		struct rmfp_cipher_params* pcipher_entry = &pCipher->cipher_entry[i];
		READ_CONFIG(pcipher_entry->type);
		READ_CONFIG(pcipher_entry->mode);
		READ_CONFIG(pcipher_entry->encrypted_packet_format);
		READ_CONFIG(pcipher_entry->key_size);
		READ_CONFIG(pcipher_entry->block_size);
		READ_CONFIG(pcipher_entry->round_value); // Multi2
		READ_CONFIG(pcipher_entry->swap_key);
		READ_CONFIG(reserved);
		if(pCipher->kl_cipher_count == 0) {
			READ_CONFIG(reserved);
		}
		else {
			READ_CONFIG(pcipher_entry->kl_otp);
		}
		if (pcipher_entry->kl_otp) {
			READ_CONFIG(reserved);
			READ_CONFIG(pcipher_entry->authentication);
			READ_CONFIG(pcipher_entry->kl_cipher_type);
			READ_CONFIG(pcipher_entry->kl_data_A_size);
			READ_STR_KEY(pcipher_entry->kl_data_A, pcipher_entry->kl_data_A_size, pcipher_entry->swap_key);
			READ_CONFIG(pcipher_entry->kl_data_B_size);
			READ_STR_KEY(pcipher_entry->kl_data_B, pcipher_entry->kl_data_B_size, pcipher_entry->swap_key);
			READ_CONFIG(pcipher_entry->kl_data_C_size);
			READ_CONFIG(pcipher_entry->kl_secret_key_size);
			READ_STR_KEY(pcipher_entry->kl_secret_key, pcipher_entry->kl_secret_key_size, pcipher_entry->swap_key);
			READ_CONFIG(reserved);
			READ_CONFIG(reserved);
		}
		READ_CONFIG(pcipher_entry->key_count);

		for(j = 0; j<pcipher_entry->key_count; j++) {
			READ_CONFIG(pcipher_entry->key_entry[j].scrambling_bits);
		}
	}

	switch (pCipher->cipher_test) {

	case cipher_test_midcipher_fixed:                   // 1

		READ_CONFIG(pCipher->encrypted_pat);
		READ_CONFIG(pCipher->encrypted_pmt);
		READ_CONFIG(pCipher->encrypted_vpid);
		READ_CONFIG(pCipher->encrypted_apid);
		break;

	case cipher_test_midcipher_ecm:                     // 2

		READ_CONFIG(pCipher->encrypted_pat);
		READ_CONFIG(pCipher->encrypted_pmt);
		READ_CONFIG(pCipher->encrypted_vpid);
		READ_CONFIG(pCipher->encrypted_apid);
		READ_CONFIG(pCipher->ecm_vpid);
		READ_CONFIG(pCipher->ecm_apid);
		READ_CONFIG(pCipher->ecm_protocol);
		break;

	case cipher_test_precipher_fixed:                   // 3

		READ_CONFIG(pCipher->change_key_block_size);
		break;

	case cipher_test_precipher_ivdr:                    // 4

		READ_CONFIG(pCipher->refresh_iv_block_size);
		READ_CONFIG(pCipher->refresh_key_iv_block_count);
		if ((pCipher->refresh_iv_block_size == 0) || (pCipher->refresh_key_iv_block_count == 0)) {
			RMNOTIFY((NULL, RM_ERROR, "parse_cipher_config: ERROR refresh_iv_block_size=%lx refresh_key_iv_block_count=%lx\n",
				pCipher->refresh_iv_block_size, pCipher->refresh_key_iv_block_count));
			return RM_ERROR;
		}
		RMDBGLOG((LOCALDBG, "refresh_iv_block_size=%lx refresh_key_iv_block_count=%lx\n",
			pCipher->refresh_iv_block_size, pCipher->refresh_key_iv_block_count));
		break;

	default:
		RMNOTIFY((NULL, RM_ERROR, "parse_cipher_config: unknown cipher_test %ld\n", pCipher->cipher_test));
		return RM_ERROR;
	}

	READ_CONFIG(reserved); // in the future - before reading the keys we can provide the cipher entry
	pCipher->config_file_key_offset = ftell(pCipher->config_file);

	return RM_OK;
}

/**************************************************************************************************/

RMstatus cipher_resources_handler(void *pContext, struct RMFPDemuxCipherResourcesProfile *pProfile)
{
	struct rmfp_cipher_context *pCipher;
	struct rmfp_main_thread_context_type *pHandle;
	RMstatus err = RM_ERROR;
	RMuint32 i, j;

	RMDBGLOG((LOCALDBG, "cipher_resources_handler()\n"));

	ASSERT_NULL_POINTER(pContext);
	ASSERT_NULL_POINTER(pProfile);

	pHandle = (struct rmfp_main_thread_context_type *)pContext;
	pCipher = &(pHandle->cipher_context);

	/* Check version of profile, so that we are sure we do not use a mismatched structure */
	CHECK_VERSION(RMFP_DEMUX_CIPHER_RESOURCES_PROFILE_VERSION);

	pCipher->demux_task = pProfile->demux_task;

	err = parse_cipher_config(pContext, pProfile);
	if (RMFAILED(err)) {
		RMNOTIFY((NULL, err, "cipher_resources_handler: Error parse_cipher_config\n"));
		goto cleanup;
	}

	/* allocate the required cipher entries */
	for( i=0; i<pCipher->cipher_count; i++) {
		if(pCipher->kl_cipher_count == 0)
			err = RUAGetProperty(pHandle->pRUA, pCipher->demux_task, RMDemuxTaskPropertyID_AllocateCipherEntry,
				&pCipher->cipher_entry[i].index, sizeof(pCipher->cipher_entry[i].index));
		else
			err = RUAGetProperty(pHandle->pRUA, pCipher->demux_task, RMDemuxTaskPropertyID_AllocateKLCipherEntry,
				&pCipher->cipher_entry[i].index, sizeof(pCipher->cipher_entry[i].index));

		if (RMFAILED(err)) {
			RMNOTIFY((NULL, err, "Error RMDemuxTaskPropertyID_AllocateCipherEntry"));
			goto cleanup;
		}
		RMDBGLOG((LOCALDBG, "RMDemuxTaskPropertyID_AllocateCipherEntry index=0x%lx\n", pCipher->cipher_entry[i].index));

		/* set the specific type for the cipher entries */
		switch (pCipher->cipher_entry[i].type) {
		case EMhwlibCipher_DES:
		{
			struct DemuxTask_TDESCipherEntry_type cipher;

			cipher.index = pCipher->cipher_entry[i].index;
			cipher.mode = (enum EMhwlibDESCipherMode)pCipher->cipher_entry[i].mode;
			cipher.encrypted_packet_format = pCipher->cipher_entry[i].encrypted_packet_format;
			err = RUASetProperty(pHandle->pRUA, pCipher->demux_task, RMDemuxTaskPropertyID_TDESCipherEntry,
				&cipher, sizeof(cipher), 0);
			if (RMFAILED(err)) {
				RMNOTIFY((NULL, err, "Error RMDemuxTaskPropertyID_TDESCipherEntry"));
				goto cleanup;
			}

			break;
		}
		case EMhwlibCipher_AES:
		{
			struct DemuxTask_AESCipherEntry_type cipher;

			cipher.index = pCipher->cipher_entry[i].index;
			cipher.mode = (enum EMhwlibAESCipherMode)pCipher->cipher_entry[i].mode;
			cipher.encrypted_packet_format = pCipher->cipher_entry[i].encrypted_packet_format;
			cipher.key_size = pCipher->cipher_entry[i].key_size;
			cipher.block_size = pCipher->cipher_entry[i].block_size;
			err = RUASetProperty(pHandle->pRUA, pCipher->demux_task, RMDemuxTaskPropertyID_AESCipherEntry,
				&cipher, sizeof(cipher), 0);
			if (RMFAILED(err)) {
				RMNOTIFY((NULL, err, "Error RMDemuxTaskPropertyID_AESCipherEntry"));
				goto cleanup;
			}

			break;
		}
		case EMhwlibCipher_DVBCSA:
		{
			struct DemuxTask_DVBCSACipherEntry_type cipher;

			cipher.index = pCipher->cipher_entry[i].index;
			err = RUASetProperty(pHandle->pRUA, pCipher->demux_task, RMDemuxTaskPropertyID_DVBCSACipherEntry,
				&cipher, sizeof(cipher), 0);
			if (RMFAILED(err)) {
				RMNOTIFY((NULL, err, "Error RMDemuxTaskPropertyID_DVBCSACipherEntry"));
				goto cleanup;
			}

			break;
		}
		case EMhwlibCipher_Multi2:
		{
			struct DemuxTask_Multi2CipherEntry_type cipher;

			cipher.index = pCipher->cipher_entry[i].index;
			cipher.mode = (enum EMhwlibMulti2CipherMode)pCipher->cipher_entry[i].mode;
			cipher.round_value = pCipher->cipher_entry[i].round_value;
			err = RUASetProperty(pHandle->pRUA, pCipher->demux_task, RMDemuxTaskPropertyID_Multi2CipherEntry,
				&cipher, sizeof(cipher), 0);
			if (RMFAILED(err)) {
				RMNOTIFY((NULL, err, "Error RMDemuxTaskPropertyID_Multi2CipherEntry"));
				goto cleanup;
			}

			break;
		}
		default:
			RMNOTIFY((NULL, err, "Unsupported cipher type %ld", pCipher->cipher_entry[i].type));
			goto cleanup;
		}

		/* allocate the required keys */
		for( j=0; j<pCipher->cipher_entry[i].key_count; j++) {
			if (pCipher->kl_cipher_count == 0)
				err = RUAExchangeProperty(pHandle->pRUA, pCipher->demux_task, RMDemuxTaskPropertyID_AllocateKeyEntry,
					&(pCipher->cipher_entry[i].type), sizeof(pCipher->cipher_entry[i].type),
					&(pCipher->cipher_entry[i].key_entry[j].index), sizeof(pCipher->cipher_entry[i].key_entry[j].index));
			else
				err = RUAExchangeProperty(pHandle->pRUA, pCipher->demux_task, RMDemuxTaskPropertyID_AllocateKLKeyEntry,
					&(pCipher->cipher_entry[i].type), sizeof(pCipher->cipher_entry[i].type),
					&(pCipher->cipher_entry[i].key_entry[j].index), sizeof(pCipher->cipher_entry[i].key_entry[j].index));

			if (RMFAILED(err)) {
				RMNOTIFY((NULL, err, "Error RMDemuxTaskPropertyID_AllocateKeyEntry type=%ld index=0x%lx\n",
					pCipher->cipher_entry[i].type, pCipher->cipher_entry[i].key_entry[j].index));
				goto cleanup;
			}
			RMDBGLOG((LOCALDBG, "RMDemuxTaskPropertyID_AllocateKeyEntry type=%ld index=0x%lx\n",
				pCipher->cipher_entry[i].type, pCipher->cipher_entry[i].key_entry[j].index));
		}
	}
#ifdef USE_XPU_WRITE_KEY
	{
		#define DEMUX_WRITE_KEY_XRPC_SIZE (64 * 1024)
		RMuint32 xrpc_size = DEMUX_WRITE_KEY_XRPC_SIZE; // 64k
		/* Allocate RUA buffer for XRPC commuication */
		pCipher->xrpc_base_addr = RUAMalloc(pHandle->pRUA, 0, RUA_DRAM_UNPROTECTED, xrpc_size);
		if (pCipher->xrpc_base_addr == 0) {
			RMDBGLOG(( ENABLE, "Error cipher_resources_handler: RUAMalloc failed\n" ));
			goto cleanup;
		}

		err = initDemuxWriteKey(pCipher->xrpc_base_addr, xrpc_size, 1);
		if ( err != RM_OK ) {
			RMDBGLOG(( ENABLE, "Error cipher_resources_handler: initDemuxWriteKey\n" ));
			goto cleanup;
		}
	}
#endif /* USE_XPU_WRITE_KEY */

	return RM_OK;

cleanup:
	release_cipher_resources_handler(pContext, pProfile);
	return err;
}

/**************************************************************************************************/

RMstatus release_cipher_resources_handler(void *pContext, struct RMFPDemuxCipherResourcesProfile *pProfile)
{
	struct rmfp_main_thread_context_type *pHandle;
	struct rmfp_cipher_context *pCipher;
	RMstatus err = RM_ERROR;
	RMuint32 i, j;

	ASSERT_NULL_POINTER(pContext);
	ASSERT_NULL_POINTER(pProfile);

	pHandle = (struct rmfp_main_thread_context_type *)pContext;
	pCipher = &(pHandle->cipher_context);

	/* Check version of profile, so that we are sure we do not use a mismatched structure */
	CHECK_VERSION(RMFP_DEMUX_CIPHER_RESOURCES_PROFILE_VERSION);

	if ( pCipher->valid_ecm_pid_handle) {
		err = RMFPDeleteCustomPIDFilter(pHandle->pHandle, pCipher->ecm_pid_handle);
		if (RMFAILED(err))
			RMNOTIFY((NULL, RM_ERROR, "release_cipher_resources_handler: Error RMFPDeleteCustomPidFilter\n"));
		
		pCipher->valid_ecm_pid_handle = FALSE;
	}
	
	for( i=0; i<pCipher->cipher_count; i++) {
		err = RUASetProperty(pHandle->pRUA, pCipher->demux_task, RMDemuxTaskPropertyID_FreeCipherEntry,
			&pCipher->cipher_entry[i].index, sizeof(pCipher->cipher_entry[i].index), 0);
		if (RMFAILED(err)) {
			RMNOTIFY((NULL, err, "release_cipher_resources_handler: Error RMDemuxTaskPropertyID_FreeCipherEntry index=0x%lx", pCipher->cipher_entry[i].index));
		}
		RMDBGLOG((LOCALDBG, "release_cipher_resources_handler: RMDemuxTaskPropertyID_FreeCipherEntry index=0x%lx\n", pCipher->cipher_entry[i].index));

		/* free the keys */
		for( j=0; j<pCipher->cipher_entry[i].key_count; j++) {
			struct DemuxTask_FreeKeyEntry_type free_key;

			free_key.cipher_type = pCipher->cipher_entry[i].type;
			free_key.key_index = pCipher->cipher_entry[i].key_entry[j].index;
			err = RUASetProperty(pHandle->pRUA, pCipher->demux_task, RMDemuxTaskPropertyID_FreeKeyEntry,
				&free_key, sizeof(free_key), 0);
			if (RMFAILED(err)) {
				RMNOTIFY((NULL, err, "release_cipher_resources_handler: Error RMDemuxTaskPropertyID_FreeKeyEntry type=%ld index=0x%lx\n",
				pCipher->cipher_entry[i].type, pCipher->cipher_entry[i].key_entry[j].index));
			}
			RMDBGLOG((LOCALDBG, "release_cipher_resources_handler: RMDemuxTaskPropertyID_FreeKeyEntry type=%ld index=0x%lx\n",
				pCipher->cipher_entry[i].type, pCipher->cipher_entry[i].key_entry[j].index));
		}
		pCipher->cipher_entry[i].key_count = 0;
	}
	pCipher->cipher_count = 0;

	if (pCipher->config_file) {
		fclose(pCipher->config_file);
		pCipher->config_file = NULL;
	}

#ifdef USE_XPU_WRITE_KEY
	{
		err = termDemuxWriteKey();
		if ( err != RM_OK ) {
			RMDBGLOG(( ENABLE, "release_cipher_resources_handler: Error termDemuxWriteKey\n" ));
		}

		if( pCipher->xrpc_base_addr ) {
			RUAFree( pHandle->pRUA, pCipher->xrpc_base_addr );
		}
	}
#endif /* USE_XPU_WRITE_KEY */

	return err;
}

/**************************************************************************************************/

RMstatus notify_pid_creation(void *pContext, struct RMFPPID *pPID)
{
	struct rmfp_main_thread_context_type *pHandle;
	struct rmfp_cipher_context *pCipher;

	RMDBGLOG((LOCALDBG, "notify_pid_creation()\n"));

	ASSERT_NULL_POINTER(pContext);
	ASSERT_NULL_POINTER(pPID);

	pHandle = (struct rmfp_main_thread_context_type *)pContext;
	pCipher = &(pHandle->cipher_context);

	switch (pCipher->cipher_test) {

	case cipher_test_midcipher_fixed:                   // 1

		return midcipher_fixed(pContext, pPID);

	case cipher_test_midcipher_ecm:                     // 2

		return midcipher_ecm(pContext, pPID);

	default:
	case cipher_test_precipher_fixed:                   // 3
	case cipher_test_precipher_ivdr:                    // 4
		return RM_ERROR;
	}
}

/**************************************************************************************************/

RMstatus notify_send_data(void *pContext, struct RMFPSendData *pSendData)
{
	struct rmfp_main_thread_context_type *pHandle;
	struct rmfp_cipher_context *pCipher;

	RMDBGLOG((DISABLE, "notify_send_data() byte_counter=0x%lx send_size=0x%lx\n", pSendData->byte_counter, pSendData->send_size));

	ASSERT_NULL_POINTER(pContext);
	ASSERT_NULL_POINTER(pSendData);

	pHandle = (struct rmfp_main_thread_context_type *)pContext;
	pCipher = &(pHandle->cipher_context);

#if 0
	/* keep next code commented out for the case when we use inband command key change */
	if (pSendData->byte_counter && (pCipher->byte_counter == pSendData->byte_counter)) {
		RMDBGLOG((DISABLE, "notify_send_data() same byte_counter=0x%lx send_size=0x%lx\n", pSendData->byte_counter, pSendData->send_size));
		return RM_OK;
	}
#endif
	pCipher->byte_counter = pSendData->byte_counter;
	if (pCipher->byte_counter == 0) {
		// we suppose that when byte_counter=0 we start at the beggining of the file
		fseek(pCipher->config_file, pCipher->config_file_key_offset, SEEK_SET);
		RUASetProperty(pHandle->pRUA, pCipher->demux_task, RMDemuxTaskPropertyID_PESPacketScramblingControl,
			&pCipher->pes_scrambling_control, sizeof(pCipher->pes_scrambling_control), 0);
	}

	switch (pCipher->cipher_test) {

	case cipher_test_midcipher_ecm:                     // 2

		if (pCipher->byte_counter == 0) {
			RMuint32 i;
			// before sending data to demux we print and set the ECM pids
			for (i=0; i< pHandle->current_pmt.es_ecm_count; i++) {
				RMDBGLOG((ENABLE, "  ES_ECM    0x%04x      - 0x%04x\n",
					pHandle->current_pmt.es_ca_system_id[i], pHandle->current_pmt.es_ecm_pid[i]));
			}
			for (i=0; i< pHandle->current_pmt.ecm_count; i++) {
				RMDBGLOG((ENABLE, "  CA_ECM    0x%04x      - 0x%04x\n",
					pHandle->current_pmt.ca_system_id[i], pHandle->current_pmt.ecm_pid[i]));
			}

			if ((pCipher->ecm_vpid == pCipher->ecm_apid) && (pCipher->ecm_vpid != 0)) {
				RMDBGLOG((LOCALDBG, "notify_send_data: forced ecm\n"));
				return create_ecm_pid(pContext, pCipher->ecm_vpid);
			}
			else if (pHandle->current_pmt.ecm_count) {
				RMDBGLOG((LOCALDBG, "notify_send_data: ecm per program\n"));
				return create_ecm_pid(pContext, pHandle->current_pmt.ecm_pid[0]);
			}
			else if (pHandle->current_pmt.es_ecm_count) {
				// hack: use just first ECM; what about multiple ECM PIDs ????
				RMDBGLOG((LOCALDBG, "notify_send_data: ecm per elementary stream\n"));
				return create_ecm_pid(pContext, pHandle->current_pmt.es_ecm_pid[0]);
			}
			else {
				RMDBGLOG((LOCALDBG, "notify_send_data: ecm not set yet\n"));
				return RM_OK;
			}
		}
		break;

	case cipher_test_precipher_fixed:                   // 3

		return precipher_fixed(pContext);

	case cipher_test_precipher_ivdr:                    // 4
		return precipher_ivdr(pContext, pSendData->send_size);

	default:
	case cipher_test_midcipher_fixed:                   // 1
		return RM_OK;
	}
	return RM_OK;
}

