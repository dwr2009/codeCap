/*****************************************
 Copyright 2001-2007
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   rmfp_detection.h
  @brief  It uses RMdetector3api and can fill RMFPStreamType and RMFPStreamInfo. 
	  
   
  @author Sebastian Frias Feltrer
  @date   2007-09-13
*/

#ifndef __RMFP_DETECTION_H__
#define __RMFP_DETECTION_H__


#include "rmdef/rmdef.h"

#include "rmfp.h"



RMstatus stream_type_detection(RMascii *fileName,
			     RMfile fileHandle,
			     RMuint32 parsingLength, 
			     struct RMFPStreamType *pStreamType, 
			     struct RMFPStreamInfo *pStreamInfo,
			     RMbool verbose);


#endif // __RMFP_DETECTION_H__
