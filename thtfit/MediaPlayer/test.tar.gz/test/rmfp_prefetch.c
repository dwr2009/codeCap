/*****************************************
 Copyright 2001-2007
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   rmfp_prefetch.c
  @brief

  Code based on the previous version (samples/rmpfs.c)

  **************************
  NOTES:
  **************************

  -Any seek call will interrupt prefetching.
  -The library works with or without threads.
  -This library is for 'reading' streams only, it cannot write to files.


  @author Sebastian Frias Feltrer
  @date   2008-03-12




*/



#include "rmfp_internal.h"




#define LOCALDBG DISABLE

#define READDBG DISABLE

#define SEEKDBG DISABLE




/*
  if KEEP_CACHE_AND_FILE_IN_SYNC is set to 1 then the file pointer will be
  always synced with the cache pos;
  else, the file pointer will be synced with the cache pos only when a
  switch from cache to file is required.

  case 1) sync enabled:

  Everything works as usual until a seek call is performed. Prefetching will be
  interrupted to honor the seek. The file and pfs pointers will be set to the
  seeking destination.
  After this, all reads inside the cache will update the file pointer to match
  that of pfs.

  ************************ this case doesn't work for some reason (bugct #3040)



  case 2) sync disabled:

  Everything works as usual until a seek call is performed. Prefetching will be
  interrupted to honor the seek. The file and pfs pointers will be set to the
  seeking destination.
  After this, if a seek to a destination inside the cache is performed only the
  pfs pointer will be updated (thus the non-synced nature of this mode). The file
  and pfs pointers will be updated only when a switch from cache to file is needed.

  case 2) is default although there are no differences from the functionality point
  of view.

*/

#define KEEP_CACHE_AND_FILE_IN_SYNC 0



#define PREFETCH_CHUNK_SIZE (4 * 1024)


#define PREFETCH_VERSION CREATEMAGIC('p', 'f', 's', '2')



/* internal functions */

struct _prefetch_cookie {
	RMuint32 Version;

	RMuint32 SlotID;
	RMint64 Position;

	RMuint8 *pBuffer;
	RMuint32 BufferSize;

	RMfile InputFileHandle;

	/*
	  prefetch_start(slot) was called for this slotID, lock it to ignore futher calls
	  with the same slotID (for robustness since that shouldn't happen!)
	*/
	RMbool Locked;
	RMbool PrefetchDone;
	RMbool StopPrefetch;

	/*
	  the slot in being used thru RMFile* calls by an application
	*/
	RMbool InUse;

	/*
	  force all reads to be in sync with the original file handle
	*/
	RMbool ForceSyncReads;

	RMuint32 PrefetchedSize;

	RMsemaphore ReadSemaphore;
	RMcriticalsection CriticalSection;

	struct RMFPPrefetchHandle *pHandle;

};



static struct _prefetch_cookie *open_cookie(struct RMFPPrefetchHandle *pPrefetchHandle, RMfile InputFileHandle, RMuint32 SlotID);
static struct _prefetch_cookie *get_cookie(RMfile PrefetchedFileHandle);
static RMstatus close_cookie(struct _prefetch_cookie *pCookie);

static RMint32 prefetch_read(void *cookie, RMuint8 *buffer, RMuint32 size);
static RMint32 prefetch_write(void *cookie, const RMuint8 *buffer, RMuint32 size);
static RMint32 prefetch_seek(void *cookie, RMint64 *position, RMfileSeekPos whence);
static RMint32 prefetch_close(void *cookie);
static RMint32 prefetch_read_nonblocking(void *cookie, RMuint8 *buffer, RMuint32 size, RMuint32 timeout);


static RMFileOps InternalFileOperations = {
	prefetch_read,
	prefetch_write,
	prefetch_seek,
	prefetch_close,
	prefetch_read_nonblocking
};


RMstatus rmfp_internal_prefetch_init(struct RMFPHandle *pHandle, struct RMFPPrefetchProfile *pProfile)
{
	struct RMFPPrefetchHandle *pPrefetchHandle = NULL;
	RMstatus status;
	RMuint32 i;

	RMDBGLOG((LOCALDBG, "rmfp_internal_prefetch_init\n"));

	ASSERT_NULL_POINTER(pHandle);
	ASSERT_NULL_POINTER(pProfile);

	if (!pProfile->pPrefetchArea) {
		status = RM_FATALINVALIDPOINTER;
		RMNOTIFY((NULL, status, "PrefetchArea NULL!\n"));
		return status;
	}

	if (!pProfile->PrefetchAreaSize) {
		status = RM_INVALID_PARAMETER;
		RMNOTIFY((NULL, status, "PrefetchAreaSize 0!\n"));
		return status;
	}

	if (!pProfile->PrefetchSlots) {
		status = RM_INVALID_PARAMETER;
		RMNOTIFY((NULL, status, "PrefetchSlots 0!\n"));
		return status;
	}

	if (pProfile->PrefetchSlots > RMFP_MAX_NUMBER_OF_PREFETCHABLE_URL) {
		status = RM_INVALID_PARAMETER;
		RMNOTIFY((NULL, status, "PrefetchSlots %lu > %lu!\n", pProfile->PrefetchSlots, RMFP_MAX_NUMBER_OF_PREFETCHABLE_URL));
		return status;
	}


	pPrefetchHandle = &(pHandle->PrefetchHandle);

	RMMemcpy(&(pPrefetchHandle->Profile), pProfile, sizeof(struct RMFPPrefetchProfile));


	pPrefetchHandle->URLPrefetchSize = pProfile->PrefetchAreaSize / pProfile->PrefetchSlots;

	// round down
	pPrefetchHandle->URLPrefetchSize = (pPrefetchHandle->URLPrefetchSize / PREFETCH_CHUNK_SIZE) * PREFETCH_CHUNK_SIZE;



	RMDBGLOG((LOCALDBG, "RMFPPrefechInit: buffer @%p, size %lu, URLSize %lu, slots %lu\n",
		  pProfile->pPrefetchArea,
		  pProfile->PrefetchAreaSize,
		  pPrefetchHandle->URLPrefetchSize,
		  pProfile->PrefetchSlots));


	for (i = 0; i < pPrefetchHandle->Profile.PrefetchSlots; i++)
		pPrefetchHandle->PrefetchFileHandleTable[i] = NULL;



	//saveFile = fopen("read.dump", "wb");

#ifdef WITH_THREADS
	pPrefetchHandle->CriticalSection = RMCreateCriticalSection();

	RMDBGLOG((ENABLE, "Prefetch is thread-safe\n"));
#else
	RMDBGLOG((ENABLE, "Prefetch is NOT thread-safe!\n"));
#endif

	return RM_OK;

}

RMstatus rmfp_internal_prefetch_get_resources(struct RMFPHandle *pHandle, struct RMFPPrefetchResources *pResources)
{
	struct RMFPPrefetchHandle *pPrefetchHandle = NULL;
	RMuint32 i;


	RMDBGLOG((LOCALDBG, "rmfp_internal_prefetch_get_resources()\n"));

	ASSERT_NULL_POINTER(pHandle);
	ASSERT_NULL_POINTER(pResources);

	pPrefetchHandle = &(pHandle->PrefetchHandle);

	ENTER_CS(pPrefetchHandle->CriticalSection);

	pResources->pPrefetchArea = pPrefetchHandle->Profile.pPrefetchArea;
	pResources->Locked = FALSE;

	for (i = 0; i < pPrefetchHandle->Profile.PrefetchSlots; i++) {
		if (pPrefetchHandle->PrefetchFileHandleTable[i]) {
#if 0
			struct _prefetch_cookie *pCookie = NULL;

			pCookie = get_cookie(pPrefetchHandle->PrefetchFileHandleTable[i]);
			if (pCookie) {

#ifdef WITH_THREADS
				RMDBGLOG((ENABLE, "Semaphore[%lu] is %lu\n", pCookie->SlotID, RMGetSemaphoreValue(pCookie->ReadSemaphore)));
#endif
			}

#endif
			pResources->Locked = TRUE;
		}
	}

	LEAVE_CS(pPrefetchHandle->CriticalSection);

	return RM_OK;
}

RMstatus rmfp_internal_prefetch_uninit(struct RMFPHandle *pHandle)
{
	struct RMFPPrefetchHandle *pPrefetchHandle = NULL;
	RMuint32 i;
	RMstatus status;

	RMDBGLOG((LOCALDBG, "rmfp_internal_prefetch_uninit()\n"));

	ASSERT_NULL_POINTER(pHandle);


	pPrefetchHandle = &(pHandle->PrefetchHandle);

	ENTER_CS(pPrefetchHandle->CriticalSection);

// need to check if it's locked

	for (i = 0; i < pPrefetchHandle->Profile.PrefetchSlots; i++) {
		if (pPrefetchHandle->PrefetchFileHandleTable[i]) {
			RMDBGLOG((ENABLE, "index %lu was not properly closed, closing\n", i));

			status = RMCloseFile(pPrefetchHandle->PrefetchFileHandleTable[i]);
			if (status != RM_OK) {
				RMNOTIFY((NULL, status, "Close failed, abort\n"));
				return status;
			}

			pPrefetchHandle->PrefetchFileHandleTable[i] = NULL;
		}

	}


	RMMemset(&(pPrefetchHandle->Profile), 0, sizeof(struct RMFPPrefetchProfile));

	LEAVE_CS(pPrefetchHandle->CriticalSection);

#ifdef WITH_THREADS
	RMDeleteCriticalSection(pPrefetchHandle->CriticalSection);
	pPrefetchHandle->CriticalSection = NULL;
#endif

	return RM_OK;
}

RMstatus rmfp_internal_prefetch_open_file(struct RMFPHandle *pHandle, RMfile InputFileHandle, RMfile *pPrefetchedFileHandle)
{
	struct RMFPPrefetchHandle *pPrefetchHandle = NULL;
	RMstatus status = RM_OK;
	RMuint32 SlotID = 0;
	RMfile file = NULL;
	struct _prefetch_cookie *pCookie = NULL;
	RMuint32 i;

	RMDBGLOG((LOCALDBG, "rmfp_internal_prefetch_open_slot()\n"));

	ASSERT_NULL_POINTER(pHandle);
	ASSERT_NULL_POINTER(InputFileHandle);
	ASSERT_NULL_POINTER(pPrefetchedFileHandle);


	pPrefetchHandle = &(pHandle->PrefetchHandle);

	*pPrefetchedFileHandle = NULL;

	ENTER_CS(pPrefetchHandle->CriticalSection);

	if (!pPrefetchHandle->Profile.pPrefetchArea) {
		status = RM_ERROR;
		RMNOTIFY((NULL, status, "PrefetchArea NULL, need to init first!\n"));
		return status;
	}

	for (i = 0; i < pPrefetchHandle->Profile.PrefetchSlots; i++) {
		if (!pPrefetchHandle->PrefetchFileHandleTable[i])
			break;
	}

	if (i == pPrefetchHandle->Profile.PrefetchSlots) {
		status = RM_ERROR;
		RMNOTIFY((NULL, status, "There are no more free slots\n"));
		return status;
	}

	LEAVE_CS(pPrefetchHandle->CriticalSection);

	SlotID = i;


	RMDBGLOG((LOCALDBG, "internal open\n"));

	pCookie = open_cookie(pPrefetchHandle, InputFileHandle, SlotID);
	if (!pCookie) {
		RMNOTIFY((NULL, RM_FATALOUTOFMEMORY, "Cannot create cookie!\n"));
		return RM_FATALOUTOFMEMORY;
	}

	file = RMOpenFileCookie((void*)pCookie, RM_FILE_OPEN_READ, &InternalFileOperations);

	if (!file) {
		close_cookie(pCookie);

		status = RM_ERROR;
		RMNOTIFY((NULL, status, "OpenFileCookie failed!\n"));
		return status;
	}

	pPrefetchHandle->PrefetchFileHandleTable[SlotID] = file;

	*pPrefetchedFileHandle = file;

	return RM_OK;
}

RMstatus rmfp_internal_prefetch_start(struct RMFPHandle *pHandle, RMfile PrefetchedFileHandle, RMuint32 timeout)
{
	RMstatus status = RM_OK;
	RMfile file = NULL;
	RMuint64 start;
	struct _prefetch_cookie *pCookie = NULL;

	RMDBGLOG((LOCALDBG, "rmfp_internal_prefetch_start(%p)\n", PrefetchedFileHandle));

	ASSERT_NULL_POINTER(pHandle);
	ASSERT_NULL_POINTER(PrefetchedFileHandle);

	start = RMGetTimeInMicroSeconds( );

	pCookie = get_cookie(PrefetchedFileHandle);
	if (!pCookie) {
		status = RM_ERROR;
		RMNOTIFY((NULL, status, "Could not get cookie!\n"));
		return status;
	}

	if (!pCookie->pBuffer) {
		status = RM_ERROR;
		RMNOTIFY((NULL, status, "PrefetchArea NULL, need to init first!\n"));
		return status;
	}


	// this is for rebustness

	ENTER_CS(pCookie->CriticalSection);

	if (pCookie->Locked) {

		LEAVE_CS(pCookie->CriticalSection);

		status = RM_ERROR;
		RMNOTIFY((NULL, status, "SlotID %lu locked! another thread already called prefetch_start for this identifier\n", pCookie->SlotID));
		return status;
	}

	pCookie->Locked = TRUE;

	LEAVE_CS(pCookie->CriticalSection);


	file = pCookie->InputFileHandle;

	if (file) {
		RMuint32 count;
		RMuint32 bytesLeft = pCookie->BufferSize - pCookie->PrefetchedSize;
		RMuint32 bytesToRead = RMmin(bytesLeft, PREFETCH_CHUNK_SIZE);
		RMuint8 *buffer = pCookie->pBuffer;


		/*
		   using prefetchDone here is correct even if it can be modified by another thread since we
		   have a second check inside a critical section
		*/
		while (bytesLeft && !pCookie->PrefetchDone) {
			RMuint32 newtimeout = 0;
			RMuint64 now;

			ENTER_CS(pCookie->CriticalSection);

			// Timeout Control, timeout = 0 means no timeout
			now = RMGetTimeInMicroSeconds( );
			if (timeout) {
				if ( (RMuint32) ((now - start) / 1000) >= timeout ) {
					status = RM_PENDING;

					LEAVE_CS(pCookie->CriticalSection);
					break;
				} else {
					newtimeout = timeout - ((RMuint32) ((now - start) / 1000));
				}
			}

			if (pCookie->StopPrefetch) {
				RMDBGLOG((ENABLE, "prefetching for SlotID %lu interrupted\n", pCookie->SlotID));

				pCookie->PrefetchDone = TRUE;
			}

			if (!pCookie->PrefetchDone) {
				status = RMReadFile_WithTimeout(file, buffer + pCookie->PrefetchedSize, bytesToRead, &count, newtimeout);
				if (status == RM_ERRORENDOFFILE) {
					RMDBGLOG((LOCALDBG, "[%lu] EOF\n", pCookie->SlotID));
					pCookie->PrefetchDone = TRUE;
				}
				else if (status == RM_PENDING) {
					// pending is fine, contine, next iteration will exit gracefully
				}
				else if (status != RM_OK) {
					// do not do anything (just like EOF), pfs_read will fail by itself when switching to file reading
					RMDBGLOG((ENABLE, "Error %s for prefetch SlotID %lu, aborting\n", RMstatusToString(status), pCookie->SlotID));

					pCookie->PrefetchDone = TRUE;
				}

				bytesLeft -= count;
				pCookie->PrefetchedSize += count;
				bytesToRead = RMmin(bytesLeft, PREFETCH_CHUNK_SIZE);

			}

			// unblock pfs_read
			SEMAPHORE_P(pCookie->ReadSemaphore);


			LEAVE_CS(pCookie->CriticalSection);
			RMDBGPRINT((ENABLE, "%ld ", pCookie->SlotID));

			//RMMicroSecondSleep(10 * 1000);

		}

		if (status != RM_PENDING) {
			pCookie->PrefetchDone = TRUE;

#if 1
		// unblock pfs_read

		/*
		  Kind of workaround for the fact that there's one more semaphore_v than semaphore_p
		  we do semaphore_v each time (position % blocksize == 0) which is true also for position=0
		  we do semaphore_p for each block, thus we have one less.
		*/

			SEMAPHORE_P(pCookie->ReadSemaphore);

#endif
		}

		RMDBGLOG((LOCALDBG, "prefetch[%lu] end: cached %lu bytes\n", pCookie->SlotID, pCookie->PrefetchedSize));

		ENTER_CS(pCookie->CriticalSection);
		pCookie->Locked = FALSE;
		LEAVE_CS(pCookie->CriticalSection);



		if ((status == RM_OK) || (status == RM_ERRORENDOFFILE) || ((status == RM_PENDING) && timeout))
			return status;
	}
	else
		status = RM_ERROR;

	RMDBGLOG((ENABLE, "rmfp_internal_prefetch_start(%lu) error! (%s)\n", pCookie->SlotID, RMstatusToString(status)));

	return status;
}


RMstatus rmfp_internal_prefetch_stop(struct RMFPHandle *pHandle, RMfile PrefetchedFileHandle)
{
	struct RMFPPrefetchHandle *pPrefetchHandle = NULL;
	struct _prefetch_cookie *pCookie = NULL;
	RMstatus status;

	RMDBGLOG((LOCALDBG, "rmfp_internal_prefetch_stop(%p)\n", PrefetchedFileHandle));

	ASSERT_NULL_POINTER(pHandle);
	ASSERT_NULL_POINTER(PrefetchedFileHandle);

	pPrefetchHandle = &(pHandle->PrefetchHandle);

	pCookie = get_cookie(PrefetchedFileHandle);
	if (!pCookie) {
		status = RM_ERROR;
		RMNOTIFY((NULL, status, "Could not get cookie!\n"));
		return status;
	}

	if (!pCookie->pBuffer) {
		status = RM_ERROR;
		RMNOTIFY((NULL, status, "PrefetchArea NULL, need to init first!\n"));
		return status;
	}

	// stop the prefetching thread
	ENTER_CS(pCookie->CriticalSection);


	if (pCookie->PrefetchDone)
		RMDBGLOG((ENABLE, "Already finished, nothing to do\n"));
	else
		pCookie->StopPrefetch = TRUE;

	LEAVE_CS(pCookie->CriticalSection);


	return RM_OK;
}



/* internal functions */

static struct _prefetch_cookie *open_cookie(struct RMFPPrefetchHandle *pPrefetchHandle, RMfile InputFileHandle, RMuint32 SlotID)
{
	struct _prefetch_cookie *pCookie = NULL;


	RMDBGLOG((LOCALDBG, "open_cookie(%lu)\n", SlotID));

	if (!pPrefetchHandle)
		return NULL;

	pCookie = (struct _prefetch_cookie *) RMMalloc(sizeof(struct _prefetch_cookie));
	if (!pCookie) {
		RMNOTIFY((NULL, RM_FATALOUTOFMEMORY, "Cannot create cookie!\n"));
		return NULL;
	}

	pCookie->Version         = PREFETCH_VERSION;

	pCookie->SlotID          = SlotID;
	pCookie->Position        = 0;                        // maybe it should be set to 'get_position(InputFileHandle)'

	pCookie->BufferSize      = pPrefetchHandle->URLPrefetchSize;
	pCookie->pBuffer         = pPrefetchHandle->Profile.pPrefetchArea + (pPrefetchHandle->URLPrefetchSize * SlotID);

	pCookie->InputFileHandle = InputFileHandle;

	pCookie->Locked          = FALSE;
	pCookie->PrefetchDone    = FALSE;
	pCookie->StopPrefetch    = FALSE;
	pCookie->InUse           = FALSE;
	pCookie->ForceSyncReads  = FALSE;
	pCookie->PrefetchedSize  = 0;


#ifdef WITH_THREADS
	// create semaphore to block pfs_read calls until requested data has been prefetched
	pCookie->ReadSemaphore   = RMCreateSemaphore(0);

	// critical section
	pCookie->CriticalSection = RMCreateCriticalSection();
#endif

	pCookie->pHandle         = pPrefetchHandle;



	return pCookie;

}

static struct _prefetch_cookie *get_cookie(RMfile PrefetchedFileHandle)
{
	struct _prefetch_cookie *pCookie = NULL;
	RMstatus status;

	RMDBGLOG((LOCALDBG, "get_cookie(%p)\n", PrefetchedFileHandle));

	status = RMGetFileCookie(PrefetchedFileHandle, (void*)&pCookie);
	if (status != RM_OK) {
		RMNOTIFY((NULL, status, "Cannot get cookie\n"));
		return NULL;
	}

	if (pCookie->Version != PREFETCH_VERSION) {
		status = RM_ERROR;
		RMNOTIFY((NULL, status, "Cookie version mismatch! expected 0x%lx, got 0x%lx\n", PREFETCH_VERSION, pCookie->Version));
		return NULL;
	}

	return pCookie;
}



static RMstatus close_cookie(struct _prefetch_cookie *pCookie)
{
	struct RMFPPrefetchHandle *pPrefetchHandle = NULL;
	RMuint32 SlotID;

	RMDBGLOG((LOCALDBG, "close_cookie(%p)\n", pCookie));

	if (!pCookie)
		return RM_FATALINVALIDPOINTER;

	pPrefetchHandle = pCookie->pHandle;

	if (!pPrefetchHandle)
		return RM_FATALINVALIDPOINTER;


#ifdef WITH_THREADS
	RMDeleteSemaphore(pCookie->ReadSemaphore);
	RMDeleteCriticalSection(pCookie->CriticalSection);
#endif

	SlotID = pCookie->SlotID;

	RMFree(pCookie);

	pPrefetchHandle->PrefetchFileHandleTable[SlotID] = NULL;

	return RM_OK;
}


static RMint32 prefetch_read(void *cookie, RMuint8 *buffer, RMuint32 size)
{
	return prefetch_read_nonblocking(cookie, buffer, size, 0);
}


static RMint32 prefetch_read_nonblocking(void *cookie, RMuint8 *buffer, RMuint32 size, RMuint32 timeout)
{
	struct _prefetch_cookie *pCookie = (struct _prefetch_cookie *)cookie;
	RMstatus status = RM_OK;
	RMint64 actualFilePos;

	RMint32 bytesLeft = size;
	RMint64 cache_size;
	RMint64 read_from_cache;
	RMint32 read_from_file = 0;
	RMint32 offset = 0;
	RMuint32 count = 0;

	RMuint32 SlotID = 0;
	RMfile FileHandle = NULL;


	//RMDBGLOG((LOCALDBG, "prefetch_read()\n"));

	if (!buffer) {
		RMNOTIFY((NULL, RM_FATALINVALIDPOINTER, "buffer NULL!\n"));
		return -1;
	}

	if (!pCookie) {
		RMNOTIFY((NULL, RM_FATALINVALIDPOINTER, "cookie NULL!\n"));
		return -1;
	}

	if (pCookie->Version != PREFETCH_VERSION) {
		status = RM_ERROR;
		RMNOTIFY((NULL, status, "Cookie version mismatch! expected 0x%lx, got 0x%lx\n", PREFETCH_VERSION, pCookie->Version));
		return -1;
	}


	SlotID     = pCookie->SlotID;
	FileHandle = pCookie->InputFileHandle;



	RMGetCurrentPositionOfFile(FileHandle, &actualFilePos);

	RMDBGLOG((READDBG, ">>>>\n"));
	RMDBGLOG((READDBG, "prefetch_read(slot:%lu, size:%lu, buffer:%p)\n", SlotID, size, buffer));
	RMDBGLOG((READDBG, "pos %lld (actual %lld), range[%lld, %lld], prefetchedSize %lu/%lu prefetchDone %lu\n",
		  pCookie->Position,
		  actualFilePos,
		  pCookie->Position,
		  pCookie->Position + size,
		  pCookie->PrefetchedSize,
		  pCookie->BufferSize,
		  (RMuint32)pCookie->PrefetchDone));



	while (bytesLeft > 0 && ((status != RM_PENDING) || !timeout) ) {
		RMbool forceSyncReads = FALSE;

		RMDBGLOG((READDBG, "bytesLeft %lu, offset %lu, pos %lld\n",
			  bytesLeft,
			  offset,
			  pCookie->Position));


		if ((pCookie->Position % PREFETCH_CHUNK_SIZE) == 0) {
			RMDBGLOG((READDBG, "check semaphore\n"));

			if (!pCookie->PrefetchDone) {
				SEMAPHORE_V(pCookie->ReadSemaphore);
			}
		}
		cache_size = pCookie->PrefetchedSize;

		count = 0;
		read_from_cache = RMmin(PREFETCH_CHUNK_SIZE, bytesLeft);
		read_from_cache = RMmin(read_from_cache, cache_size - pCookie->Position);

		forceSyncReads = pCookie->ForceSyncReads;

#if 0
		if (forceSyncReads) {
			// all reads will be from the file, caching disabled
			RMDBGLOG((READDBG, "forcing sync reads\n"));
			read_from_cache = 0;
		}
#endif


		if (read_from_cache > 0) {
			// read from cache

			RMDBGLOG((READDBG, "A: read_from_cache %lld read_from_file %ld cache_size %lld\n",
				  read_from_cache,
				  read_from_file,
				  cache_size));

			// read_from_cache is positive, cast is legal
			RMMemcpy(buffer + offset,
				 (pCookie->pBuffer + pCookie->Position),
				 (RMuint32)read_from_cache);

			count = (RMuint32)read_from_cache;
			RMDBGLOG((READDBG, "read_from_cache %lu bytes\n", count));

		}
		else if (pCookie->PrefetchDone) {
			// read from file
			RMuint32 bytesRead;

			read_from_file = bytesLeft;

			RMDBGLOG((READDBG, "B: read_from_cache %lld read_from_file %ld cache_size %lld\n",
				  read_from_cache,
				  read_from_file,
				  cache_size));

			RMGetCurrentPositionOfFile(FileHandle, &actualFilePos);

			RMDBGLOG((READDBG, "read_from_file[%lu] cachePos %lld, actualPos %lld\n", SlotID, pCookie->Position, actualFilePos));

			if (actualFilePos != pCookie->Position) {
				RMDBGLOG((ENABLE, "[%lu] resyncing cache (%lld) and file (%lld) pointers\n", SlotID, pCookie->Position, actualFilePos));
				RMSeekFile(FileHandle, pCookie->Position, RM_FILE_SEEK_START);
			}

			status = RMReadFile_WithTimeout(FileHandle, buffer + offset, read_from_file, &bytesRead, timeout);
			if (status == RM_PENDING) {
				bytesRead = 0;
			}
			else if (status == RM_ERRORENDOFFILE) {
				RMDBGLOG((ENABLE, "[%lu] EOF\n", SlotID));
				//quit loop gracefully
				bytesLeft = bytesRead;
			}
			else if (status == RM_ERRORREADFILE) {
				RMDBGLOG((ENABLE, "error %s prefetch slot %lu, but CONTINUE\n", RMstatusToString(status), SlotID));
				//quit loop gracefully
				bytesLeft = bytesRead;
			}
			else if (status != RM_OK) {
				RMNOTIFY((NULL, status, "Read failed for slotID %lu, aborting\n", SlotID));
				return -1;
			}

			count = bytesRead;
			RMDBGLOG((READDBG, "read_from_file %lu bytes\n", count));
		}
		else
			RMDBGLOG((ENABLE, "need to wait\n"));

		if (bytesLeft)
			bytesLeft -= count;

		pCookie->Position += count;
		offset += count;

		if (bytesLeft < 0)
			RMDBGLOG((ENABLE, "bytesLeft %ld  is negative!!\n", bytesLeft));


#if KEEP_CACHE_AND_FILE_IN_SYNC
		if (forceSyncReads) {
			// sync read pointers

			RMGetCurrentPositionOfFile(FileHandle, &actualFilePos);

			if (actualFilePos != pCookie->Position) {
				RMDBGLOG((READDBG, "[%lu] Forced: resyncing cache (%lld) and file (%lld) pointers\n", SlotID, pCookie->Position, actualFilePos));
				RMSeekFile(FileHandle, pCookie->Position, RM_FILE_SEEK_START);
			}
		}
#endif
	}

	//fwrite(buffer, offset, 1, saveFile);

	RMGetCurrentPositionOfFile(FileHandle, &actualFilePos);

	RMDBGLOG((READDBG, "total bytes read %lu curretFilePos %lld currentCachePos %lld\n", offset, actualFilePos, pCookie->Position));
	RMDBGLOG((READDBG, "<<<<\n"));
	if (offset < 0)
		RMDBGLOG((ENABLE, "\n\noffset is negative! = %ld\n", offset));

	if (offset == 0 && (status == RM_PENDING))
		return -RM_PENDING;

	return offset;

}

static RMint32 prefetch_write(void *cookie, const RMuint8 *buffer, RMuint32 size)
{
	struct _prefetch_cookie *pCookie = (struct _prefetch_cookie *)cookie;
	RMuint32 SlotID = 0;
	RMstatus status;

	RMDBGLOG((LOCALDBG, "prefetch_write()\n"));


	if (!buffer) {
		RMNOTIFY((NULL, RM_FATALINVALIDPOINTER, "buffer NULL!\n"));
		return -1;
	}

	if (!pCookie) {
		RMNOTIFY((NULL, RM_FATALINVALIDPOINTER, "cookie NULL!\n"));
		return -1;
	}

	if (pCookie->Version != PREFETCH_VERSION) {
		status = RM_ERROR;
		RMNOTIFY((NULL, status, "Cookie version mismatch! expected 0x%lx, got 0x%lx\n", PREFETCH_VERSION, pCookie->Version));
		return -1;
	}


	SlotID = pCookie->SlotID;

	RMDBGLOG((LOCALDBG, "prefetch_write(slot:%lu) not handled!!\n", SlotID));

	return -1;
}

static RMint32 prefetch_seek(void *cookie, RMint64 *position, RMfileSeekPos whence)
{
	struct _prefetch_cookie *pCookie = (struct _prefetch_cookie *)cookie;
	RMstatus status;
	RMint64 currentPosition;
	RMint32 error = 0;
	RMuint32 SlotID = 0;
	RMfile FileHandle = NULL;


	RMDBGLOG((LOCALDBG, "prefetch_seek()\n"));


	if (!pCookie) {
		RMNOTIFY((NULL, RM_FATALINVALIDPOINTER, "cookie NULL!\n"));
		return -1;
	}

	if (pCookie->Version != PREFETCH_VERSION) {
		status = RM_ERROR;
		RMNOTIFY((NULL, status, "Cookie version mismatch! expected 0x%lx, got 0x%lx\n", PREFETCH_VERSION, pCookie->Version));
		return -1;
	}

	if (!position) {
		RMNOTIFY((NULL, RM_FATALINVALIDPOINTER, "buffer NULL!\n"));
		return -1;
	}


	SlotID     = pCookie->SlotID;
	FileHandle = pCookie->InputFileHandle;



	ENTER_CS(pCookie->CriticalSection);


	currentPosition = pCookie->Position;

	RMDBGLOG((SEEKDBG, "prefetch_seek(slot:%lu, pos:%lld, from:%lu [%s])\n",
		  SlotID,
		  *position,
		  (RMuint32)whence,
		  (whence == RM_FILE_SEEK_START) ? "from start": (whence == RM_FILE_SEEK_CURRENT) ? "current":"from the end" ));


	// if forceSyncReads is enabled, always perform real seeks
	if (KEEP_CACHE_AND_FILE_IN_SYNC && pCookie->ForceSyncReads)
		goto perform_real_seek;


	switch (whence) {
	case RM_FILE_SEEK_START:
		if (*position < 0) {
			RMDBGLOG((ENABLE, "trying to seek beyond start of file\n"));
			error = -1;
			goto exit;
		}

		if (*position < pCookie->PrefetchedSize) {
			// seek is within cached data
			currentPosition = *position;

			RMDBGLOG((SEEKDBG, "seek to %lld is inside cache [0;%lu]\n", currentPosition, pCookie->PrefetchedSize));

			goto exit;
		}
		// else perform a 'real' seek and stop prefetching

		break;
	case RM_FILE_SEEK_CURRENT:

		currentPosition += *position;

		if (currentPosition < 0) {
			RMDBGLOG((ENABLE, "trying to seek beyond start of file\n"));
			error = -1;
			goto exit;
		}

		if (currentPosition < pCookie->PrefetchedSize) {
			// seek is within cached data

			RMDBGLOG((SEEKDBG, "seek to %lld is inside cache [0;%lu]\n", currentPosition, pCookie->PrefetchedSize));

			goto exit;
		}
		// else perform a 'real' seek and stop prefetching

		break;
	case RM_FILE_SEEK_END:
		if (*position > 0) {
			RMDBGLOG((ENABLE, "trying to seek beyond end of file\n"));
			error = -1;
			goto exit;
		}

		/*
		   in order to handle this case correctly we'd need to know the length of the file,
		   we might not be able to do that in all cases, therefore we forward the request
		   straight to the 'real' seek
		*/

		break;
	};

	if (!pCookie->PrefetchDone)
		RMDBGLOG((ENABLE, "disabling prefetch for slot %lu (%lu bytes prefetched) since a real seek needs to be performed\n", SlotID, pCookie->PrefetchedSize));

	// stop prefetching the url because we're performing a 'real' seek

	pCookie->PrefetchDone = TRUE;

 perform_real_seek:
	RMDBGLOG((SEEKDBG, "real seek(%lld, %lu) for slot %lu\n", *position, (RMuint32)whence, SlotID));

	if (!pCookie->ForceSyncReads) {
		RMDBGLOG((ENABLE, "force sync reads for slot %lu due to seeking\n", SlotID));
		pCookie->ForceSyncReads = TRUE;
	}

	status = RMSeekFile(FileHandle, *position, whence);
	if (status != RM_OK) {
		RMDBGLOG((ENABLE, "error seeking\n"));
		error = -1;
		goto exit;
	}

	RMGetCurrentPositionOfFile(FileHandle, &currentPosition);

 exit:
	pCookie->Position = currentPosition;
	*position         = currentPosition;

	RMDBGLOG((SEEKDBG, "current position %lld\n", pCookie->Position));

	LEAVE_CS(pCookie->CriticalSection);

	return error;
}

static RMint32 prefetch_close(void *cookie)
{
	struct _prefetch_cookie *pCookie = (struct _prefetch_cookie *)cookie;
	RMuint32 SlotID = 0;
	RMstatus status;

	RMDBGLOG((LOCALDBG, "prefetch_close()\n"));

	if (!pCookie) {
		RMNOTIFY((NULL, RM_FATALINVALIDPOINTER, "cookie NULL!\n"));
		return -1;
	}

	if (pCookie->Version != PREFETCH_VERSION) {
		status = RM_ERROR;
		RMNOTIFY((NULL, status, "Cookie version mismatch! expected 0x%lx, got 0x%lx\n", PREFETCH_VERSION, pCookie->Version));
		return -1;
	}


	SlotID = pCookie->SlotID;


	RMDBGLOG((LOCALDBG, "prefetch_close(slot:%lu)\n", SlotID));

	ENTER_CS(pCookie->CriticalSection);

	if (pCookie->Locked && !pCookie->PrefetchDone) {
		RMDBGLOG((ENABLE, "Prefetching in progress, cannot close now!\n"));
		pCookie->StopPrefetch = TRUE;

		LEAVE_CS(pCookie->CriticalSection);
		return -1;
	}

	LEAVE_CS(pCookie->CriticalSection);


	status = close_cookie(pCookie);
	if (status != RM_OK) {
		RMNOTIFY((NULL, status, "Failed to close cookie\n"));
		return -1;
	}


	return 0;
}


