#ifndef	_MEDIA_FILE_INFO_CACHE_H_
#define	_MEDIA_FILE_INFO_CACHE_H_

#include "rmfp.h"
#include <map>
#include <SharedPtr.h>
#include <String.h>
#include <SharedPtr.h>
#include "MediaSrvInterface.h"
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <time.h>

using namespace std;
using namespace CppBase;

#if 1/*added by lxj 2012-11-5*/
#define MAX_PATH 256
#define MEDIA_INFO_CACHE_FILE_NAME "/data/MediaStreamInfoCache.bin"
#define MAX_MEDIA_INFO_CACHE_FILE_BUFFER_SIZE (sizeof(MediaFileInfoCacheRecord_t) * MAX_CACHE_ITEMS)

typedef struct{
	UINT32_t RecordSize;/*RecordSize=sizeof(MediaFileInfoCacheRecord_t) 1200Bytes*/
	char FilePathName[MAX_PATH];
	struct RMFPStreamType RmfpStreamType;
	struct RMFPStreamInfo2 RmfpStreamInfo;
	time_t FileModifiedTime;	/* time of last modification */
	UINT64_t LastUseTimeMs;
	UINT64_t FileSize;
	char reserved[76];
	UINT32_t check_crc;
}MediaFileInfoCacheRecord_t,*pMediaFileInfoCacheRecord_t;
#endif

class CMediaFileInfo
{
public:
	CMediaFileInfo();
	~CMediaFileInfo();
public:
#if 1/*modify by lxj 2012-11-6*/
	MediaFileInfoCacheRecord_t m_CacheRecord;
#endif
};

typedef map < CString, SharedPtr <CMediaFileInfo> > MediaFileInfo_map;

class CMediaFileInfoCache
{
public:
	CMediaFileInfoCache();
	~CMediaFileInfoCache();
	INT_t FindStreamInfoInCache(CONST IMediaFileInfoCache::P_FIND_STREAM_INFO_IN_PARAM pFindInParam,
		IMediaFileInfoCache::P_FIND_STREAM_INFO_OUT_PARAM pFindOutParam);
	INT_t AddMediaInfoCache(const RMascii * pszFileName, CONST struct RMFPStreamType * pRmfpStreamType,
		CONST struct RMFPStreamInfo * pRmfpStreamInfo);
private:
#if 1/*modify by lxj 2012-11-6*/
	int m_MediaFileInfoCacheHandle;
	struct RMFPStreamInfo * CloneRmfpStreamInfo(CONST struct RMFPStreamInfo2 * pOrigRmfpStreamInfo);
#endif
	INT_t RemoveOldCacheItems(CONST int ItemCntToRemove = 1);
#if 1/*added by lxj 2012-11-6*/
	INT_t LoadMediaInfoCacheFromFile(void);
	INT_t UnloadMediaInfoCacheFile(void);
	INT_t AddMediaInfoCacheToFile(const pMediaFileInfoCacheRecord_t pCacheRecord);
	INT_t RemoveOldCacheItemsFromFile(void);
#endif
public:
	static const int MAX_CACHE_ITEMS = 300;
private:
	MediaFileInfo_map m_MediaFileInfoMap;
};

#endif	//MediaFileInfoCache.cpp

