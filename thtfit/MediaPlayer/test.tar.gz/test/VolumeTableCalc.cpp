#include "VolumeTableCalc.h"
#include <emhwlib/include/Smp86xxVolumeTable.h>

RMint32 GetVolumeTableIndexSize()
{
	return (sizeof(VolumeTable) / sizeof(VolumeTable[0]));
}

RMuint32 GetVolumeVal(RMint32 idVolume)
{
	if(0 > idVolume) 
	{
		idVolume = 0;
	}
	else if(GetVolumeTableIndexSize() - 1 < idVolume) 
	{
		idVolume = GetVolumeTableIndexSize() - 1;
	}
		
	return VolumeTable[idVolume];
}

RMint32 getPercentFromVolVal(RMuint32 uiVolVal)
{
	RMint32 iOutVolPercent = 0;
	int iId = 0;

	for(iId = 0; iId < GetVolumeTableIndexSize(); iId++)
	{
		if(uiVolVal <= VolumeTable[iId])
		{
			iOutVolPercent = ((iId+1) * 100) / GetVolumeTableIndexSize();
			break;
		}
	}
	if(uiVolVal > VolumeTable[GetVolumeTableIndexSize() - 1])
	{
		iOutVolPercent = 100;
	}
	if(0 == iId)
	{
		iOutVolPercent = 0;
	}

	return iOutVolPercent;
}

RMuint32 getVolValFromPercent(RMint32 iVolPercent)
{
	RMuint32 uiOutVolVal = 0;
	RMint32 iVolId = 0;

	do
	{
		if(0 > iVolPercent)
		{
			iVolPercent = 0;
		}
		if(100 < iVolPercent)
		{
			iVolPercent = 100;
		}
		iVolId = GetVolumeTableIndexSize() * iVolPercent / 100 - 1;
		if(0 > iVolId)
		{
			iVolId = 0;
		}
		uiOutVolVal = VolumeTable[iVolId];
	}while(FALSE);

	return uiOutVolVal;
}

