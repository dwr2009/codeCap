#ifndef	ALLOW_OS_CODE
#define	ALLOW_OS_CODE
#endif	//ALLOW_OS_CODE

#include "Smp8xxxChipInfo.h"
#include <ErrPrintHelper.h>
#if (EM86XX_CHIP >= EM86XX_CHIPID_TANGO3)
#include <emhwlib_hal/include/tango3/emhwlib_registers_tango3.h>
#endif

CSmp8xxxChipInfo::CSmp8xxxChipInfo()
{
	m_pLlad = (typeof(m_pLlad))NULL;
	m_pGbus = (typeof(m_pGbus))NULL;
	m_bGotChipInfo = FALSE;
	m_ChipId = 0x0000;
}

CSmp8xxxChipInfo::~CSmp8xxxChipInfo()
{
	INT_t iRet;
	
	iRet = CloseGbus();
	if(ERROR_SUCCESS != iRet)
	{
		PRINT_BFILE_LINENO_IRET_STR;
	}
}

INT_t CSmp8xxxChipInfo::ReadChipInfo()
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;

	do
	{
		if(m_bGotChipInfo)
		{
			break;
		}

		iRet = OpenGbus();
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}

		m_ChipId = gbus_read_uint16(m_pGbus, REG_BASE_host_interface+PCI_REG0);
	}while(FALSE);

	iRet = CloseGbus();
	if(ERROR_SUCCESS != iRet)
	{
		PRINT_BFILE_LINENO_IRET_STR;
	}

	return iOutRet;
}

RMuint16 CSmp8xxxChipInfo::getChipId()
{
	return m_ChipId;
}

INT_t CSmp8xxxChipInfo::OpenGbus()
{
	INT_t iOutRet = ERROR_SUCCESS;

	do
	{
		if(NULL == m_pLlad)
		{
			m_pLlad = llad_open((RMascii *)"0");
			if(NULL == m_pLlad)
			{
				LOG("Failed to open llad dev\n");
				iOutRet = ERROR_FILE_OPEN_FAIL;
				break;
			}
		}
		if(NULL == m_pGbus)
		{
			m_pGbus = gbus_open(m_pLlad);
			if(NULL == m_pGbus)
			{
				LOG("Failed to open gbus\n");
				iOutRet = ERROR_FILE_OPEN_FAIL;
				break;
			}
		}
	}while(FALSE);

	return iOutRet;
}

INT_t CSmp8xxxChipInfo::CloseGbus()
{
	INT_t iOutRet = ERROR_SUCCESS;

	do
	{
		if(m_pGbus)
		{
			gbus_close(m_pGbus);
			m_pGbus = NULL;
		}
		if(m_pLlad)
		{
			llad_close(m_pLlad);
			m_pLlad = NULL;
		}
	}while(FALSE);

	return iOutRet;
}

