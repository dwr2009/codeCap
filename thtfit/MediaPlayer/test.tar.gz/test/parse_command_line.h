/*****************************************
 Copyright 2001-2007
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   parse_command_line.h
  @brief  this file is part of the test_rmfp suite

  @date   2007-10-17
*/

/*
  **********************************************
  DISCLAIMER:

  - THIS IS TEST CODE, provided as sample code
  to help you understand what you should do to
  develop your own application based in RMFP.

  - This is NOT production grade code; It is not
  even a library, so any API defined here, CAN
  and WILL CHANGE without notice.

  **********************************************
*/

#ifndef __TESTRMFP_PARSE_COMMAND_LINE_H__
#define __TESTRMFP_PARSE_COMMAND_LINE_H__


#ifndef	ALLOW_OS_CODE
#define ALLOW_OS_CODE 1
#endif	//ALLOW_OS_CODE

#include <stdio.h>
#include <stdlib.h>

#include <rmdef/rmdef.h>
#include "rmfp.h"

#include <rmoutput/rua/include/output_rua.h>
#include <rmoutput/debugger/include/rmoutput_debugger.h>

#define TEST_RMFP_DEFAULT_BOARD_INDEX 0
#define TEST_RMFP_DEFAULT_LOADUCODE TRUE
#define TEST_RMFP_MAX_ADDITIONAL_FONTS 16


enum TESTRMFP_UserSurfaceMode {
	TESTRMFP_UserSurfaceMode_None = 32,
	TESTRMFP_UserSurfaceMode_Dummy,
	TESTRMFP_UserSurfaceMode_Print,
	TESTRMFP_UserSurfaceMode_CRC32,
};


struct DisplayOptions {
	enum RMFPRouteType route;
	RMuint32 scaler_ID;
	RMuint32 osd_scaler_ID;
	struct EMhwlibDisplayWindow source_window;
	struct EMhwlibDisplayWindow output_window;
	struct EMhwlibDisplayWindow output_osd_window;
	enum EMhwlibDeinterlacingMode deinterlacingmode;
#ifdef RMFEATURE_HAS_DEDICATED_DEINTERLACING
	struct DispDeinterlacer_MotionAdaptativeConfig_type deinterlacing_motion_config;
	struct DeinterlacingWindow deinterlacing_window0;
	struct DeinterlacingWindow deinterlacing_window1;
#else
	struct DispMainVideoScaler_DeinterlacingMotionConfig_type deinterlacing_motion_config;
#endif
	struct DispMainVideoScaler_DeinterlacingProportion_type deinterlacing_proportion;

	RMuint32 lock_scaler;
	RMbool do_pulldown;
	RMbool force_mixer_color_space;				// Force mixer colorspace
	enum EMhwlibColorSpace mixer_color_space;		// Forced mixer colorspace
	RMuint32 color_degradation_boundary;

	RMint8 brightness;
	RMuint8 contrast;
	RMuint8 saturation_blue;
	RMuint8 saturation_red;

	struct EMhwlibNonLinearScalingMode nonlinearmode;
	struct EMhwlibBlackStripMode blackstrip;
	struct EMhwlibCutStripMode cutstrip;
	struct EMhwlibColorSpecification strip_color;
	enum EMhwlibScalerFieldSelection field_selection;
	enum EMhwlibScalingMode scalingmode;
	struct EMhwlibDownScalingMode downscalingmode;
	struct EMhwlibLumaKeying luma_key;
	RMuint32 video_alpha;
	RMuint32 OSD_alpha;
	struct EMhwlibDisplayTimeInterval time_interval;
	struct DispMainVideoScaler_FilterSelection_type filtermode;
	RMuint32 wide_bw_filter_boundary;
	RMuint32 subtitles_osd_height;

	RMuint32 SurfaceSoftEventIndex; // this is the soft event index for the surface events
	enum TESTRMFP_UserSurfaceMode UserSurfaceMode;

	RMbool do_key_color;
	struct EMhwlibKeyColor key_color;

};

struct AudioOptions {
	RMuint32 ExtraAudioEngine[MAX_AUDIO_DECODER_INSTANCES-1];
	RMuint32 ExtraAudioDecoder[MAX_AUDIO_DECODER_INSTANCES-1];
};

struct PlaybackOptions {
	RMbool   LoadUCODE;					// If set, loads microde at startup
	RMuint32 BoardIndex;					// Board index

	RMbool loop;						// Loop playback indefinitely
	RMint32 LoopCount;					// total times to play

	RMbool test_external_resources_allocation;

	RMbool dmapool_in_rua_mem;

	RMbool start_in_pause;
	RMbool recursive;
	RMbool is_directory;

	RMbool disable_debug_logging;

	RMbool detect_only;
	RMint32 detect_limit;

	RMbool use_http_caching;

	RMbool UseSoftwareJPEGDecoder;
	RMbool UseSoftwareDemux;
	RMbool UseTerminal;

	// JANUS/CARDEA
	RMbool RMWMDRMUseHWDecryption;

	struct
	{
		RMfile default_font_file_handle;				// File handle of the default font
		RMfile cc_font_file_handle;					// File handle of the CloseCaption font

		RMuint32 nb_additional_fonts;					// Number of additional fonts
		RMfile additional_font_file_handle[TEST_RMFP_MAX_ADDITIONAL_FONTS];	// File handles of additional fonts

		RMfile forced_font_file_handle;			// Force font
	} fonts;

	// ciphers
	RMascii* cipher_config_file_name;

	RMbool open_font_from_file;

	RMbool allow_special_keys;

	RMint32 hdmi_nice;  // niceness value for HDMI/display updater thread
	RMbool no_disp;  // do not set up outputs with rmoutput
	RMbool rmfp_in_a_thread;

	RMbool file_is_not_closed;
};

struct AppOptions {
	struct DisplayOptions Display;
	struct AudioOptions Audio;
	struct PlaybackOptions Playback;
};

struct CommandLineOptionSet;

RM_EXTERN_C_BLOCKSTART

RMstatus init_application_options(struct AppOptions *pAppOptions);
RMstatus parse_command_line(void *pContext, RMuint32 argc, RMascii **argv, struct RMFPStreamType *pStreamType, RMascii** fileName, RMbool WithOutput);
RMstatus is_option_marked_as_set(void *pContext, RMascii* option, RMbool* pIsSet);
RMstatus PlaybackOptions_Init(struct PlaybackOptions * pPlaybackOpts);

RM_EXTERN_C_BLOCKEND

#endif //__TESTRMFP_PARSE_COMMAND_LINE_H__

