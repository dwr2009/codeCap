/*****************************************
 Copyright 2001-2007
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   callbacks.h
  @brief  This file provides with sample code for implementing RMFP's callbacks

	  This file is part of the test_rmfp suite

  @author Sebastian Frias Feltrer
  @date   2007-10-29
*/

/*
  **********************************************
  DISCLAIMER:

  - THIS IS TEST CODE, provided as sample code
  to help you understand what you should do to
  develop your own application based in RMFP.

  - This is NOT production grade code; It is not
  even a library, so any API defined here, CAN
  and WILL CHANGE without notice.

  **********************************************
*/

#ifndef __TESTRMFP_CALLBACKS_H__
#define __TESTRMFP_CALLBACKS_H__


#include <rmdef/rmdef.h>
#include "rmfp.h"
#include "test_rmfp.h"

enum TEST_RMFP_progress_type {
	TEST_RMFP_progress_type_scanning_subs = RMFP_progress_type_buffering + 10000,
};

/**************************************************************************************************/
/*******************************	      Available keys	 ******************************/
/**************************************************************************************************/

#define KEY_COMMAND_QUIT_ALL		'Q'
#define KEY_COMMAND_QUIT		'q'
#define KEY_COMMAND_PLAY		'p'
#define KEY_COMMAND_PAUSE		' '
#define KEY_COMMAND_RESUME		'r'
#define KEY_COMMAND_STOP		's'
#define KEY_COMMAND_SEEK_TO_TIME	'f'
#define KEY_COMMAND_SEEK_TO_PERCENT	'F'
#define KEY_COMMAND_NEXT_PICT		'n'
#define KEY_COMMAND_FAST_FWD_ALL_FRAMES	'+'
#define KEY_COMMAND_FAST_FWD_WITH_AUDIO	':'
#define KEY_COMMAND_SLOW_FWD_ALL_FRAMES	'-'
#define KEY_COMMAND_SLOW_FWD_WITH_AUDIO	';'
#define KEY_COMMAND_IFRAMES_FWD		']'
#define KEY_COMMAND_IFRAMES_BWD		'['
#define KEY_COMMAND_SILENT_FWD		'>'
#define KEY_COMMAND_SILENT_BWD		'<'
#define KEY_COMMAND_SWITCH_VIDEO	'v'
#define KEY_COMMAND_SWITCH_AUDIO	'a'
#define KEY_COMMAND_SWITCH_PROGRAM	'm'
#define KEY_COMMAND_SWITCH_SUBS		'G'
#define KEY_COMMAND_SWITCH_MULTICAST	'k'
#define KEY_COMMAND_APPLY_AV_DELAY	'D'
#define KEY_COMMAND_SUBS_CHANGE_DELAY	'S'
#define KEY_COMMAND_SUBS_INCREASE_FONT_SIZE 'T'
#define KEY_COMMAND_SUBS_DECREASE_FONT_SIZE 't'
#define KEY_COMMAND_SUBS_INCREASE_POS_Y	'Y'
#define KEY_COMMAND_SUBS_DECREASE_POS_Y	'y'
#define KEY_COMMAND_SUBS_SWITCH_ENCODING 'e'
#define KEY_COMMAND_SUBS_RESET_ALL	'R'
#define KEY_COMMAND_SUBS_CHANGE_COLOR	'c'
#define KEY_COMMAND_DEBUG		'd'
#define KEY_COMMAND_PRINT_INFO		'i'
#define KEY_COMMAND_FULL_SCREEN		'7'
#define KEY_COMMAND_HALF_SCREEN		'1'
#define KEY_COMMAND_INCREASE_SIZE	'9'
#define KEY_COMMAND_DECREASE_SIZE	'3'
#define KEY_COMMAND_MOVE_LEFT		'4'
#define KEY_COMMAND_MOVE_RIGHT		'6'
#define KEY_COMMAND_MOVE_TOP		'8'
#define KEY_COMMAND_MOVE_BOTTOM		'2'
#define KEY_COMMAND_NONLINEAR_WIDTH	'w'
#define KEY_COMMAND_NONLINEAR_LEVEL	'W'
#define KEY_COMMAND_SWITCH_SCALER	'5'
#define KEY_COMMAND_HELP		'h'
#define KEY_COMMAND_PRINT_TXT		'M'
#define KEY_COMMAND_STANDBY		'b'
#define KEY_COMMAND_WAKEUP		'B'
#define KEY_COMMAND_SWITCH_VARIANT 'u'
#define KEY_COMMAND_PLAY_IFRAME '}'

/* rmoutput debugger occupies: '?' 'I' 'g' '%' '#' '$' '@' 'A' */

/* Special chars */
#define SPECIAL_KEY_COMMAND_IFRAMES_BWD		0x44
#define SPECIAL_KEY_COMMAND_IFRAMES_FWD		0x43
#define SPECIAL_KEY_COMMAND_NEXT_AUDIO		0x41
#define SPECIAL_KEY_COMMAND_NEXT_SUBS		0x42


RM_EXTERN_C_BLOCKSTART

RMstatus get_command(void* pContext, struct RMFPPlaybackCommand *pCommand, RMuint32 TimeOutInMicroSeconds);
RMstatus notify_available_commands(void *pContext, RMuint32 mask);
RMstatus notify_command_status(void *pContext, struct RMFPCommandStatus *pStatus);
RMstatus notify_playback_status(void *pContext, struct RMFPPlaybackStatus *pStatus);
RMstatus notify_playback_start(void *pContext);
RMstatus notify_playback_eos(void *pContext);
RMstatus notify_current_streams_properties(void *pContext, struct RMFPStreamProperties *pStreamProperties);
RMstatus notify_pat(void *pContext, struct RMFPPAT *pPAT);
RMstatus notify_pmt(void *pContext, struct RMFPPMT *pPMT);
RMstatus notify_progress(void *pContext, struct RMFPProgress* pProgress, RMbool *pAbort);
RMstatus disk_control(void *pContext, enum RMFPDiskControl_action action);

RMstatus get_route_handler(void *pContext, struct RMFPRoute *pRoute);
RMstatus get_surface_events_handler(void *pContext,struct RMFPSurfaceProfile *pSurfaceProfile, struct RMFPSurfaceEventsSource *pSurfaceEventsSource);
RMstatus disconnect_surface_handler(void *pContext, RMuint32 surface);

RMstatus notify_stream_metadata(void *pContext, struct RMFPStreamMetadata *pStreamMetadata);

RMstatus hls_get_key( void* pContext, RMascii *url, RMuint8 *key, RMuint32 keylength);

RMstatus open_osd(void *pContext, struct RMFPOSDProfile *pOSDProfile, struct RMFPOSDSource *pOSDSource);
RMstatus close_osd(void *pContext, struct RMFPOSDSource *pOSDSource);

RMstatus open_dmapool_handler(void *pContext, struct RMFPDMAPoolProfile *pProfile, struct RUABufferPool **ppDMAPool);
RMstatus close_dmapool_handler(void *pContext, struct RUABufferPool *pDMAPool);

RMstatus open_bdspu_decoder(void *pContext);
RMstatus close_bdspu_decoder(void *pContext);
RMstatus send_bdspu_decoder(void *pContext, RMuint8* pBuffer, RMuint32 Size);
RMstatus flush_bdspu_decoder(void *pContext);

RMstatus rmfp_getVideoScalerModuleId(void *pContext, RMuint32 * pVidScalerModuleId, enum DCCRoute * pDccRoute);
RMstatus Rmfp_AudioEngine_setSampleFreq(void *pContext, RMbool bUseCurCfg, 
	RMbool bAutoSetFromStream, RMuint32 audioSampleFreq);

RMstatus rmwmdrm_url_acquire_license(void *pContext, struct RMFPRMWMDRMURLHandle *pRMWMDRMURLHandle);


/* the functions below are not RMFP callbacks and SHOULD not be here; this file should ONLY contain callback implementations for RMFP */

RMstatus apply_common_scaler_option(struct rmfp_main_thread_context_type *pMainContext, struct DisplayOptions * pDisplayOptions, RMuint32 scaler_ID);
/* Exported function */
RMstatus apply_video_scaler_option(struct rmfp_main_thread_context_type *pMainContext);


void local_hdmi_update_loop(void *c);

RM_EXTERN_C_BLOCKEND

#endif // __TESTRMFP_RESOURCES_H__

