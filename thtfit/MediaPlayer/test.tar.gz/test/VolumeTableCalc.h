#ifndef	_VOLUME_TABLE_CALC_H_
#define	_VOLUME_TABLE_CALC_H_

#include <rmdef/rmdef.h>

RMint32 GetVolumeTableIndexSize();
RMuint32 GetVolumeVal(RMint32 idVolume);
RMint32 getPercentFromVolVal(RMuint32 uiVolVal);
RMuint32 getVolValFromPercent(RMint32 iVolPercent);

#endif	//_VOLUME_TABLE_CALC_H_

