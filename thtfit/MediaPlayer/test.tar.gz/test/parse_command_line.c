/*****************************************
 Copyright 2001-2007
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   parse_command_line.c
  @brief  this file is part of the test_rmfp suite

  @author Guillaume Paquereau, Gilles Vieira
  @date   2007-10-17
*/

/*
  **********************************************
  DISCLAIMER:

  - THIS IS TEST CODE, provided as sample code
  to help you understand what you should do to
  develop your own application based in RMFP.

  - This is NOT production grade code; It is not
  even a library, so any API defined here, CAN
  and WILL CHANGE without notice.

  **********************************************
*/

#include "parse_command_line.h"
#include "test_rmfp.h"
#include <ErrPrintHelper.h>
#include <Compiler.h>

#if 0
#define LOCALDBG ENABLE
#else
#define LOCALDBG DISABLE
#endif

#define NORMALMSG stdout
#define ERRORMSG  stderr

/*
 * Defines
 */
#define	PROFILE_ENTRY(name, value)	{ name, Profile_##value , VideoDecoder_Codec_##value, },
#define	PROFILE_END()			{ 0, 0, 0, },

// zoom helper defines and functions
#undef ZOOM_0
#undef ZOOM_1
#define ZOOM_0 4096  // 0% zoom position
#define ZOOM_1 8192  // 100% zoom position

/*
 * Enums
 */
enum _options_description_type
{
	_options_description_type_video = 11,
	_options_description_type_audio,
	_options_description_type_playback,
	_options_description_type_display,
	_options_description_type_demux,
	_options_description_type_output,
	_options_description_type_picture
};

enum _options_check_result
{
	_options_check_result_ok = 41,
	_options_check_result_missing,
	_options_check_result_misplaced,
	_options_check_result_duplicated,
	_options_check_result_not_implemented
};

/*
 * Structures
 */
struct profile_record {
	RMascii                         *profile_id;
	enum MPEG_Profile	     profile_profile;
	enum VideoDecoder_Codec_type profile_codec;
};

/* lookup table for video profiles */
struct profile_record	profile_table[] = {
	PROFILE_ENTRY("2sd",	MPEG2_SD)
	PROFILE_ENTRY("3sd",	DIVX3_SD)
	PROFILE_ENTRY("4sd",	MPEG4_SD)
	PROFILE_ENTRY("4sdr",	MPEG4_SD_Padding)
	PROFILE_ENTRY("2dvd",	MPEG2_DVD)
	PROFILE_ENTRY("2hd",	MPEG2_HD)
	PROFILE_ENTRY("3hd",	DIVX3_HD)
	PROFILE_ENTRY("4hd",	MPEG4_HD)
	PROFILE_ENTRY("4hdr",	MPEG4_HD_Padding)
	PROFILE_ENTRY("2sddi",	MPEG2_SD_DeInt)
	PROFILE_ENTRY("4sddi",	MPEG4_SD_DeInt)
	PROFILE_ENTRY("4sddir",	MPEG4_SD_DeInt_Padding)
	PROFILE_ENTRY("2dvddi",	MPEG2_DVD_DeInt)
	PROFILE_ENTRY("2hddi",	MPEG2_HD_DeInt)
	PROFILE_ENTRY("4hddi",	MPEG4_HD_DeInt)
	PROFILE_ENTRY("4hddir",	MPEG4_HD_DeInt_Padding)
	PROFILE_ENTRY("9sd",	WMV_SD)
	PROFILE_ENTRY("9816p",	WMV_816P)
	PROFILE_ENTRY("9hd",	WMV_HD)
	PROFILE_ENTRY("5sd",	H264_SD)
	PROFILE_ENTRY("5hd",	H264_HD)
	PROFILE_ENTRY("5sddi",	H264_SD_DeInt)
	PROFILE_ENTRY("5hddi",	H264_HD_DeInt)
	PROFILE_ENTRY("10sd",	VC1_SD)
	PROFILE_ENTRY("10hd",	VC1_HD)
#if (EM86XX_CHIP >= EM86XX_CHIPID_TANGO3)
	PROFILE_ENTRY("8sd",	AVS_SD)
	PROFILE_ENTRY("8hd",	AVS_HD)
	PROFILE_ENTRY("6sd",	H261_SD)
#endif

	PROFILE_END()
};

struct _audio_codec_entry {
	RMascii *codecName;
	enum AudioDecoder_Codec_type AudioCodec;
	RMuint32 SubCodec;
	RMuint32 bits_per_sample;
	RMuint32 channel_Assign;
};

static struct _audio_codec_entry audio_codec_table[] = {
	{	"aac",		AudioDecoder_Codec_AAC,		3,	0,	0,	},
	{	"aac0",		AudioDecoder_Codec_AAC,		0,	0,	0,	},
	{	"aac1",		AudioDecoder_Codec_AAC,		1,	0,	0,	},
	{	"aac2",		AudioDecoder_Codec_AAC,		2,	0,	0,	},
	{	"aac3",		AudioDecoder_Codec_AAC,		3,	0,	0,	},
	{	"ac3",		AudioDecoder_Codec_AC3,		0,	0,	0,	},
	{	"ac3_20",	AudioDecoder_Codec_AC3,		0,	0,	0,	},
	{	"ac3_32",	AudioDecoder_Codec_AC3,		0,	0,	0,	},
	{	"adif",		AudioDecoder_Codec_AAC,		0,	0,	0,	},
	{	"adts",		AudioDecoder_Codec_AAC,		1,	0,	0,	},
	{	"bdlpcm",	AudioDecoder_Codec_PCM,		3,	16,	PcmCda2_LR,	},
	{	"bsac",		AudioDecoder_Codec_BSAC,	0,	0,	0,	},
	{       "dra",          AudioDecoder_Codec_DRA,         0,      0,      0,      },
	{	"dts",		AudioDecoder_Codec_DTS,		0,	0,	0,	},
	{	"dts_cd",	AudioDecoder_Codec_DTS,		0,	0,	0,	},
	{       "dtslbr",       AudioDecoder_Codec_DTSLBR,      0,      0,      0,      },
	{	"dvda",		AudioDecoder_Codec_DVDA,	0,	0,	0,	},
	{	"eac3",		AudioDecoder_Codec_AC3,		0,	0,	0,	},
/*	{       "exac",         AudioDecoder_Codec_EXAC,        0,      0,      0,      },*/
	{       "flac",         AudioDecoder_Codec_FLAC,        0,      0,      0,      },
	{	"latm",		AudioDecoder_Codec_AAC,		3,	0,	0,	},
	{	"mpeg",		AudioDecoder_Codec_MPEG1,	0,	0,	0,	},
	{	"vorbis",	AudioDecoder_Codec_VORBIS,	0,	0,	0,	},
	{	"wma",		AudioDecoder_Codec_WMA,		0,	0,	0,	},
	{	"wmapro",	AudioDecoder_Codec_WMAPRO,	0,	0,	0,	},

// TODO: fix WMATS

	{	"wmats",	AudioDecoder_Codec_WMA,		0x7a23,	0,	0,	},

	{	"pcm",		AudioDecoder_Codec_PCM,		0,	0,	0,	},
	{	"pcm8",		AudioDecoder_Codec_PCM,		0,	8,	PcmCda2_LR,	},
	{	"pcm8_1",	AudioDecoder_Codec_PCM,		0,	8,	PcmCda1_C,	},
	{	"pcm8_2",	AudioDecoder_Codec_PCM,		0,	8,	PcmCda2_LR,	},
	{	"pcm16",	AudioDecoder_Codec_PCM,		0,	16,	PcmCda2_LR,	},
	{	"pcm16_1",	AudioDecoder_Codec_PCM,		0,	16,	PcmCda1_C,	},
	{	"pcm16_2",	AudioDecoder_Codec_PCM,		0,	16,	PcmCda2_LR,	},
	{	"pcm16_6",	AudioDecoder_Codec_PCM,		0,	16,	PcmCda6_LfRfCLfeLsRs,	},
	{	"pcm24",	AudioDecoder_Codec_PCM,		0,	24,	PcmCda2_LR,	},
	{	"pcm24_2",	AudioDecoder_Codec_PCM,		0,	24,	PcmCda2_LR,	},
	{	"pcm24_6",	AudioDecoder_Codec_PCM,		0,	24,	PcmCda6_LfRfCLfeLsRs,	},
	{	"lpcm",		AudioDecoder_Codec_PCM,		1,	0,	0,	},
	{	"lpcm16",	AudioDecoder_Codec_PCM,		1,	16,	LpcmVob2_LR,	},
	{	"lpcm16_1",	AudioDecoder_Codec_PCM,		1,	16,	LpcmVob1_C,	},
	{	"lpcm16_2",	AudioDecoder_Codec_PCM,		1,	16,	LpcmVob2_LR,	},
	{	"lpcm20",	AudioDecoder_Codec_PCM,		1,	20,	LpcmVob2_LR,	},
	{	"lpcm20_2",	AudioDecoder_Codec_PCM,		1,	20,	LpcmVob2_LR,	},
	{	"lpcm24",	AudioDecoder_Codec_PCM,		1,	24,	LpcmVob2_LR,	},
	{	"lpcm24_2",	AudioDecoder_Codec_PCM,		1,	24,	LpcmVob2_LR,	},
	{	"lpcma",	AudioDecoder_Codec_PCM,		2,	0,	0,	},
	{	"lpcma16_1",	AudioDecoder_Codec_PCM,		2,	16,	LpcmAob10_C,	},
	{	"lpcma16_2",	AudioDecoder_Codec_PCM,		2,	16,	LpcmAob20_LR,	},
	{	"lpcma24",	AudioDecoder_Codec_PCM,		2,	24,	LpcmAob20_LR,	},
	{	"lpcma24_2",	AudioDecoder_Codec_PCM,		2,	24,	LpcmAob20_LR,	},

	{	"pcmx",		AudioDecoder_Codec_PCMX,	0,	0,	0,	},
	{	"ttone",	AudioDecoder_Codec_TTONE,	0,	0,	0,	},

	{	"lpcmwfa",	AudioDecoder_Codec_PCM,		4,	16,	PcmCda2_LR,	},
/*	{	"dsi",		AudioDecoder_Codec_AAC,		2,	0,	0,	}, */

	{	0,		0,				0,	0,	0,	},
};

struct _option_description
{
	enum _options_description_type option_type;
	RMascii* option_name;
	RMascii* option_description;
	RMascii* parameters_description;
};

/*
 * Local routines prototypes
 */
//static RMbool fileName_is_directory(RMascii *fileName);
static RMstatus get_video_profile(const RMascii* prof, enum MPEG_Profile* profile);
static RMstatus _get_audio_codec(const RMascii *codec, struct _audio_codec_entry **ptr);
static RMstatus _get_option_description(	RMascii* option_name,
						RMascii** option_description,
						RMascii** parameters_description);
static RMstatus _print_matching_options_description(RMascii* option_partial_name, RMascii* pAppName);
static RMstatus check_and_show_options(enum _options_description_type option_type, RMbool show);
static RMstatus check_and_show_all_options(RMascii* app_name, RMbool show, RMbool WithOutput);
static RMstatus check_option(RMascii *option, enum _options_description_type option_type, enum _options_check_result* pResult);
static RMstatus option_allows_multiple_instances(RMascii* option, RMbool* pAllowMultipleInstances);
static RMstatus mark_option_as_set(struct rmfp_main_thread_context_type *pContext, RMascii* option);

static RMstatus parse_all_cmdline(RMuint32 argc,
				  RMascii **argv,
				  RMuint32 *index,
				  struct RMFPOptions *pOptions,
				  struct RMFPStreamType *pStreamType,
				  enum _options_description_type *current_option_type,
				  struct AppOptions * pAppOptions);
static RMstatus parse_audio_cmdline(RMuint32 argc, RMascii **argv, RMuint32 *index, struct RMFPAudioOptions *audio_options, struct AudioOptions *pTestRMFPAudio_options);
static RMstatus _store_video_profile(enum MPEG_Profile profile, struct RMFPVideoOptions *video_options);
static RMstatus parse_video_cmdline(RMuint32 argc, RMascii **argv, RMuint32 *index, struct RMFPVideoOptions *video_options);
static RMstatus parse_picture_cmdline(RMuint32 argc, RMascii **argv, RMuint32 *index, struct RMFPPictureOptions *picture_options);
static RMstatus parse_playback_cmdline(RMuint32 argc, RMascii **argv, RMuint32 *index, struct RMFPPlayOptions *playback_options, struct RMFPStreamType *pStreamType, struct PlaybackOptions *pTestRMFPPlayback_options);
static RMstatus parse_demux_cmdline(RMuint32 argc, RMascii **argv, RMuint32 *index, struct RMFPDemuxOptions *demux_options);
static RMstatus parse_display_cmdline(RMuint32 argc, RMascii **argv, RMuint32 *index, struct DisplayOptions *display_options);


/*
 * Statics
 */


/* List of parameters that can appear more than once in the command line */
static RMascii* _multiple_instances_options[] = {"-multicast", "-unicast", "-font", "-text_subs", "-extra_audio"};

#define _V_   _options_description_type_video
#define _A_   _options_description_type_audio
#define _P_   _options_description_type_playback
#define _D_   _options_description_type_display
#define _X_   _options_description_type_demux
#define _PIC_ _options_description_type_picture

static struct _option_description Options_description[] =
{
	/*Type*//* Option */		/* Options description */					/* Parameters description */

	/**************************************************************************** VIDEO OPTIONS ****************************************************************************/
#if (EM86XX_CHIP >= EM86XX_CHIPID_TANGO3)
	{_V_,	"-pv",			"Choose video codec",						"<2sd, 4sd, 4sdr, 2dvd, 2hd, 4hd, 4hdr, 2sddi, 4sddi, 4sddir, 2dvddi, 2hddi, 4hddi, 4hddir, 9sd, 9816p, 9hd, 3sd, 3hd, 5sd, 5hd, 10sd, 10hd, 8sd, 8hd, 6sd>"},
#else
	{_V_,	"-pv",			"Choose video codec",						"<2sd, 4sd, 4sdr, 2dvd, 2hd, 4hd, 4hdr, 2sddi, 4sddi, 4sddir, 2dvddi, 2hddi, 4hddi, 4hddir, 9sd, 9816p, 9hd, 3sd, 3hd, 5sd, 5hd, 10sd, 10hd>"},
#endif
	{_V_,	"-ve",			"Select the video engine (DSP) to be used",			"<[0], 1>"},
	{_V_,	"-vd",			"Select the video decoder (DSP) to be used",			"<[0], 1>"},
	{_V_,	"-video_track",		"Force video track (else, the first video stream will be played)","<value>"},
	{_V_,	"-fixvop",		"Force the VOP",						"<resolution per second> <increment per frame>"},
	{_V_,	"-vtimescale",		"Play m4v with pts expressed in vtimescale units.",		"<value>"},
	{_V_,	"-ics",			"Force the input colorspace.",					"<yuv_601, yuv_709, rgb_0_255, rgb_16_235>"},
	{_V_,	"-cc",			"Select the closed caption display mode.",			"<tv, soft, 608soft, cc1, cc2, cc3, cc4, 708soft, [off]>"},

	{_V_,	"-vcodec",		"Choose codec and size : -vcodec codec width height",		"<mpeg2, mpeg4, divx3, vc1, wmv, h264, jpeg, avs, h261> <value> <value>"},
	{_V_,	"-extrapict",		"Set number of extra pictures (regardless of motion adaptive deinterlacing mode)",					"<value>"},
	{_V_,	"-vprofile",		"Baseline h264",						"<[0], 1=main>"},
	{_V_,	"-vlevel",		"Level fo h264",						"<value from 0 to 14>"},
	{_V_,	"-vfifo",		"Select the video bitstream fifo size in KB.",			"<value>"},
	{_V_,	"-vxfer",		"Select the video xfer fifo count.",				"<value>"},
	{_V_,	"-ms",			"Enable playback of MS elementary with PTS files",		""},
	{_V_,	"-seq",		"WMV9 sequence parameter (Decimal or 0xXXXXXXXX Hexadecimal)",		"<value>"},
	{_V_,	"-scan",		"Set video scan mode",						"<source, frame, top, bot>"},
	{_V_,	"-displayerror",	"Set display error threshold",					"<value>"},
	{_V_,	"-err_prop_threshold",	"Set anchor error propagation threshold",			"<value>"},
	{_V_,	"-err_prop_length",	"Set anchor error propagation length",				"<value>"},
	{_V_,	"-intprog",		"Select the interlaced_progressive algorithm.",			"<std, mpeg2_prog_seq, mpeg2_menu_prog>"},
	{_V_,	"-use_afd",		"OBSOLETE: always enabled -- (Parse Active Format information from MPEG2 or H.264 streams and adjust the display accordingly)", ""}, 
	{_V_,	"-src_afd",  "Force active format for the content",  "<none, full, 16x9top, 14x9top, 64x27, 4x3, 16x9, 14x9, 4x3_14x9, 16x9_14x9, 16x9_4x3>"}, 
	{_V_,	"-act",  "Alternative option name for '-src_afd'",  "see '-src_afd'"}, 
	{_V_,	"-src_aspix",  "Force pixel aspect ratio for the content",  "<x> <y>"}, 
	{_V_,	"-src_asp",  "Force frame aspect ratio for the content",  "<x> <y>"}, 
	{_V_,	"-src_bar",  "Force bar info for the content (end and start of the respective bars, line/pixel count starts at 1)",  "<left> <right> <top> <bottom>"}, 
	{_V_,	"-src_scan",  "Force overscan info for the content: Overscanned=image needs to be cropped by the display, Underscanned=image does not need to be cropped, None=no info on scanning",  "<O|U|N>"}, 
	{_V_,	"-src_3d",  "Force Stereoscopic 3D format for the content: Format, sub sampling, arrangement order",  "<2D | Anaglyphic|Anaglyph | PageFlip | LineInterleave | ColumnInterleave | CheckerboardInterleave|Checkerboard | SideBySideHalf|SideBySide|SbS | OverUnderHalf|OverUnder|TopBottom|TnB | LineAlternative | ColumnAlternative | CheckerboardAlternative | SideBySideFull | OverUnderFull | FramePacking|FP | FieldAlternative | LPlusDepth | LPlusDepthPlusGraphics|LPlusGraphics> [<HorOLOR|HOO | HorOLER|HOE | HorELOR|HEO | HorELER|HEE | VerOLOR|VOO | VerOLER|VOE | VerELOR|VEO | VerELER|VEE | QuinOLOR|QOO | QuinOLER|QOE | QuinELOR|QEO | QuinELER|QEE> [<Left|L | Right|R>]]"}, 
	{_V_,	"-skipNCP",		"Skip NotCoded P-frames",					"<[0], 1>"},
#if (EM86XX_CHIP >= EM86XX_CHIPID_TANGO3)
	{_V_,	"-pp",			"Enable/Disable post processing of video",			"<[0], 1>"},
#endif
	{_V_,	"-ignore_h264bl",	"Ignore h264 broken link",					""},
	{_V_,	"-ignore_h264cpb",	"Ignore h264 cpb removal time",					""},
	{_V_,	"-pts_purge",		"PTS purge",							""},
	{_V_,	"-ignore_disp_size",	"Do not take in account display size from stream",		""},
	{_V_,	"-h264_svc",		"H264 SVC value",						"<value [0-31]>"},
	{_V_,	"-cs_algo",		"Selection algorithm for undefined content color spaces",						"<[601], 709, auto>"},
	{_V_,	"-rm_no_deblock",	"Disable RealMedia inloop deblocking",				""},
	{_V_,	"-rm_no_B_deblock",	"Disable RealMedia inloop deblocking for B frames",		""},
	{_V_,	"-vd_maxmem",	        "Forces the VideoDecoder to request the maximum memory",	""},
	{_V_,	"-vd_customem",	        "Allocate a custom amount of unprotected video decoding memory instead of using required values provided by DCC (B)",	"<value>"},

	/**************************************************************************** DISPLAY OPTIONS ****************************************************************************/
	{_D_,	"-bcss",		"Set the brightness, contrast, saturation_Cb, saturation_Cr.",	"<b> <c> <s_Cb> <s_Cr> [0 128 128 128]"},
	{_D_,	"-cdb",			"Set the color degradation boundary.",				"<value [0-255]>"},
	{_D_,	"-mcs",			"Force the mixer colorspace.",					"<yuv_601, yuv_709, rgb_0_255, rgb_16_235>"},
	{_D_,	"-route",		"Select the display route to use",				"<[main] vcr cb>"},
	{_D_,	"-vscaler",		"Select the scaler to use to display the video",		"<[mv] vcr gfx>"},
	{_D_,	"-oscaler",		"Select the scaler to use to display osd",			"<[gfx] osd mv vcr spu vp>"},
	{_D_,	"-zoom",		"Select the input window to display",				"<x> <y> <w> <h> [0 0 width height]"},
	{_D_,	"-window",		"Select the output window to display",			        "<x> <y> <w> <h> [0 0 width height]"},
	{_D_,	"-strips",		"Set display horizontal and vertical black strip mode",		"<h> <v> (h v in [0-4096] range)"},
	{_D_,	"-cutstrips",		"Set display horizontal and vertical cut strip mode",		"<h> <v> (h v in [0-4096] range)"},
	{_D_,	"-nonlin",		"Select non-linear scaling width (0..3) and level (0..3)",	"<w> <l>"},
	{_D_,	"-stripcolor",		"Select the color of the filler strips",			"<color> (RGB color: 0xRRGGBB, YCbCr601 color: <Y>/<Cb>/<Cr> or color names"},
	{_D_,	"-fs",			"Select the field selection algorithm",				"<[type] time one pseudo_interlaced_out>"},
	{_D_,	"-lock_scaler",		"Lock the scaling mode to the given scaler",			"<[none] mv gfx vcr crt spu osd>"},
	{_D_,	"-sm",			"Set display scaling mode",					"<[letterBox] panScan ARIB>"},
	{_D_,	"-luma_lpf",		"Force a low pass luma filter applied to the luma",		"<0 1 2 3 auto>"},
	{_D_,	"-va",			"Vide alpha level (0..255)",					"<value [128]>"},
	{_D_,	"-oa",			"OSD alpha level (0..255)",					"<value [128]>"},
	{_D_,	"-lumakey",		"Set the luma key range",					"<min> <max> (0xff 0x00)"},
	{_D_,	"-key_color",           "set key color, if applicable (TrueColor mode)",                "<B_Cb> <G_Y> <R_Cr> <Range>"},

	{_D_,	"-time_interval",	"Define the time interval to play",				">start-end>"},
	{_D_,	"-mv_filter",		"Force the type of filter applied to luma and chroma.",	"<0 1 2 3 auto>"},
	{_D_,	"-mv_wide_bw_filter_boundary",	"Determines scale boundary for mild, hi bandwidth filter applied to luma and chroma.",	"<[none] 1x upscale_2x upscale_4x>"},

#ifdef RMFEATURE_HAS_DEDICATED_DEINTERLACING
	{_D_,	"-D",			"Select the deinterlacing mode",				"<0=Bob, 2=motion adaptative, 4=motion adaptative using 4 field>"},
	{_D_,	"-motion_config",	"Configure the motion deinterlacer format -motion_config scale V16V8V4V0",	""},
#else
	{_D_,	"-D",			"Select the deinterlacing mode",				"<0=Bob, 2=motion adaptative>"},
	{_D_,	"-motion_config",	"Configure the motion deinterlacer format",			"<V16V8V4V0>"},
#endif
	{_D_,	"-d2_proportion",	"Configure the existing vs new field proportion in deinterlacing type", "<2:0xEFNF>"},
	{_D_,	"-32pd",		"Enable the 3:2 pulldown. Is only active in case of motion adaptative deinterlacing", ""},
#ifdef RMFEATURE_HAS_DEDICATED_DEINTERLACING
	{_D_,	"-D_window0",		"Configure deinterlacing window 0",				"<x> <y> <w> <h> [0 0 width height]"},
	{_D_,	"-D_window1",		"Configure deinterlacing window 1",				"<x> <y> <w> <h> [0 0 width height]"},
#endif
	{_D_,	"-subs_res",		"Force subtitle osd height size",				"<x>",},
	{_D_,	"-surface_event_index",	"SoftEvent Index for the Surface events",			"<value>",},
	{_D_,	"-user_surface",	"Use usermode Surface consumer",			        "<dummy, print, checksum>",},


	/**************************************************************************** AUDIO OPTIONS ****************************************************************************/
	{_A_,	"-ae",			"Select the audio engine (DSP) to be used",					"<[0], 1>"},
	{_A_,	"-ad",			"Select the audio decoder (DSP) to be used",					"<[0], 1>"},
	{_A_,	"-audio_track",		"Force audio track (else, the first audio stream will be played)",		"<value>"},



	{_A_,	"-c",			"Select the audio codec to be used",						"<aac0, aac1, aac2, aac3, ac3, adif, adts, bdlpcm, bsac, dra, dts, dts_cd, dtslbr, dvda, eac3, flac, latm, lpcm, lpcma, mpeg, pcm, ttone, vorbis, wma, wmapro, wmats>"},
	{_A_,	"-lsbfirst",		"Used only for audio pcm wave",							""},
	{_A_,	"-bits_per_sample",	"Set number of bits by sample in pcm stream",					"<16, 20, 24>"},
	{_A_,	"-pcm_frequency",	"Specified pcm sample frequency",						"<value>"},
	{_A_,	"-pcm_channel",		"Specified number of channels",							"<value>"},
	{_A_,	"-unsigned",		"Unsigned PCM data",								""},
	{_A_,	"-downsample",		"For DVD PCM playback protection by converting 24 bit to 16 bit PCM Format",	""},
	{_A_,	"-afifo",		"Select the audio bitstream fifo size in KB.",					"<value>"},
	{_A_,	"-axfer",		"Select the audio xfer fifo count.",						"<value>"},
	{_A_,	"-askip_first_n_bytes",	"Bytes to skip when reading the file from the beginning",			"<value>"},
	{_A_,	"-asend_n_bytes",	"Bytes to send",								"<value>"},
	{_A_,	"-aplay",		"Play mode",									"<0=disable, 1=play_from, 2=play_to, 3=play_from_to>"},
	{_A_,	"-astart",		"Play start PTS",								"<value>"},
	{_A_,	"-astop",		"Play stop PTS",								"<value>"},
	{_A_,	"-ac3compmode",		"AC3 comp mode ",								"<0=analog, 1=digital, 2=line out, 3=RF, 4=RF_iptv>"},
	{_A_,	"-ac3dynhi",		"Dynamic scale hi 4.28 hex representation",					""},
	{_A_,	"-ac3dynlo",		"Dynamic scale lo 4.28 hex representation",					""},
	{_A_,	"-ac3pcmscale",		"PCM scale lo 4.28 hex representation",						""},
	{_A_,	"-x",			"Channel Config",								"<2, 6, 8>"},
	{_A_,	"-drc",			"DRC Enable",									"<1, 2>"},
	{_A_,	"-boost",		"DRC Boost",									"<0-100>"},
	{_A_,	"-cut",			"DRC Cut",									"<0-100>"},
	{_A_,	"-dialref",		"1 to -31 DRC DialRef",								"<value>"},
	{_A_,	"-lossless",		"Lossless mode",								""},
	{_A_,	"-acmod2dual",		"force stereo play as dual-mono",						""},
	{_A_,	"-nosync",		"To disable sync to STC per decoder",						""},
	{_A_,	"-ttone_type",		"Tone mode",									"<0=white noise, 1=other>"},
	{_A_,	"-ttone_mask",		"Tone mask in hex",								"<0=disable, , 0x1=left, 0x2=right, 0x4=center 0x8=lfe 0x10=Lss 0x20=Rss 0x40=Lss 0x80=Rss>"},
	{_A_,	"-extra_audio",		"Add an extra audio decoder",							"<audio engine> <audio decoder>"},
	{_A_,	"-afs",			"Output Sample Frequency from Stream",						"<0=forced by '-sf' option, 1=follows stream sample rate> [1]"},

	/**************************************************************************** PLAYBACK OPTIONS ****************************************************************************/

	{_P_,	"-app",			"Select the file type",									"audio, video, riff (avi or wave), asf, mp4, swdemux, psfdemux, mkv, flv, realmedia, hls, ogg"},
	{_P_,	"-plugin",		"Select the plugin file to load",							"<file.so>"},
	{_P_,	"-m",			"Select the board number",								"<Board number>"},
//	{_P_,	"-L",			"Loop the file count times",								"<count>"},
	{_P_,	"-l",			"Loop the file infinitely",								""},
	{_P_,	"-softdemux",		"Use Soft demux instead of PSFDemux when using autodetection",			        ""},
	{_P_,	"-softjpeg",		"Use Soft JPEG decoder instead of hardware decoding when using autodetection",		""},
	{_P_,	"-data",		"Select which streams to send to decode",						"<n=none, a=audio, v=video, s=subs>"},
	{_P_,	"-ts",			"Select which streams to send PTS to decode",						"<n=none, a=audio, v=video, s=subs>"},
	{_P_,	"-savev",		"Save the video stream to the selected file",						"<file name>"},
	{_P_,	"-savea",		"Save the audio stream to the selected file",						"<file name>"},
	{_P_,	"-saves",		"Save the subtitles stream to the selected file",					"<file name>"},
//	{_P_,	"-saveformat",		"Add embedded pts and frame_size data to saved stream (selected by -savev,-savea,-saves)",	"<ms>"},
	{_P_,	"-speed",		"Set the speed factor to N/M",								"<N> <M>"},
	{_P_,	"-dram",		"Set the dram controller to use",							"<value>"},
//	{_P_,	"-manutest",		"Maunufacture testing mode",								""},
	{_P_,	"-nostcdrift",		"Disable correction of STC-to-PCR drift (SPI or Multicast only)",			""},
	{_P_,	"-vcxo",		"Configure STC-to-PCR drift correction and VCXO index ('stconly' means no clean dividers correction) (SPI or Multicast only)",		"<none, stconly, VCXO index>"},
	{_P_,	"-resetvcxo",		"Reset the VCXO regulation and set STC back to 1/1",					""},
//	{_P_,	"-stcdbg",		"Level of debug print",									"<[0], 1, 2, 3>"},
	{_P_,	"-dmapool",		"Set the count and the log2 size of the dma pool",					"<count> <log2size>"},
	{_P_,	"-disk_ctrl",		"Low threshold for HDD wakeup (in KBytes). This will enable HDDControl",                "<value>"},
	{_P_,	"-disk_ctrl_buf_size",	"Size (in KBytes) of the Buffer used for disk control",	                                "<value>"},
	{_P_,	"-stc_offset_ms",	"Set a signed offset to the STC: a negative value will be usefull to bufferize",	"<value>"},
	{_P_,	"-prebuf",		"Maximum size in kB read from media for prebuffering.",					"<value>"},
	{_P_,	"-sat",			"Send audio while in trickmodes",							""},
	{_P_,	"-past",		"Play any supported track",								""},
	{_P_,	"-noucode",		"Do not load microcode (meaningful only in legacy 'non-XLU' mode)",			""},
	{_P_,	"-STCIndex",		"Select the STC index to use",								"<value>"},
	{_P_,	"-STCEngine",		"Select the STC engine to use (For psfdemux, it MUST be the same as the demux engine)",	"<value>"},
	{_P_,	"-far",			"Fast audio recovery after trickmodes (performs a seek when resuming from trickmodes)",	"<value>"},
	{_P_,	"-duration",		"Set time duration of stream in ms",							"<value>"},
	{_P_,	"-accurate_seek",	"Accurate seek (seek precisely to time, not to Iframe)",				"<0, [1]>"},
	{_P_,	"-linear_mode",	        "Avoid seeking (no detection will be performed)",				        "<[0], 1>"},
	{_P_,	"-text_subs",           "Force external text subtitles (needs framerate for .sub and encoding for .srt (latin1 or utf8)","<file name> <.sub framerate num> <.sub framerate den> <encoding>"},
	{_P_,	"-truecolor_subs",	"Render the text subtitles in true color",						""},
	{_P_,	"-yuv_palette_subs",	"When truecolor_subs is not set, use a YUV palette for subs (needed for the SPU scaler)",""},
	{_P_,	"-no_prerendered_subs",	"Disable the prerendering in memory function for subtitles (to save memory)",		""},
#if (EM86XX_CHIP >= EM86XX_CHIPID_TANGO3)
	{_P_,	"-disable_ssa_anim",	"Disable the SSA/ASS subtitles animations",						""},
#endif
	{_P_,	"-subidx",		"Force external SUB/IDX subtitles",							"<SUB file name> <IDX file name> <lang index>"},
	{_P_,	"-external_subs_delayms", "Add a delay to external subtitles in ms (positive means later)",			"<value>"},
	{_P_,	"-extern_alloc",        "Test purpose: allocate resources in application instead of library",					""},
	{_P_,	"-picture_format",	"Chose picture type",									"<bmp, jpeg, gif, png, yuv>"},
	{_P_,	"-waitexit",		"Application doesn't stop and exit until q key is pressed",				""},
	{_P_,	"-pause",		"Start playback in pause state",							""},
	{_P_,	"-R",			"If filename is a directory, play its sub-directories recursively",			""},
	{_P_,	"-disable_RMDBG",	"Disable RMDBG* debug logging",			                                        ""},
	{_P_,	"-subtitles_track",	"Force subtitles track (else, the first subtitles stream will be played)",		"<value>"},
	{_P_,	"-nosubs",		"Disable embedded AND external subtitles",			                        ""},
	{_P_,	"-detect_only",		"Only perform detection (for testing the detection algorithm)",	                        ""},
	{_P_,	"-detect_limit",        "Parse this amount of KBytes for detection (default is 0, so RMFP will choose it)",     "<value>"},
	{_P_,	"-use_http_caching",	"Enable http caching",						                        "<0, [1]>"},
	{_P_,	"-extract_attachments",	"Specify the directory where to extract attachments",		                        "<directory name>"},
	{_P_,	"-default_font",	"Default font name, used when the required font is not found",				"<font filename>"},
	{_P_,	"-cc_font",		"Closecaption font name, used when the required font is not found",			"<font filename>"},
	{_P_,	"-forced_font",		"Force font name for all rendering",							"<font filename>"},
	{_P_,	"-font",		"Additionals fonts names",								"<font filename>"},
	{_P_,	"-noterm",		"Desactivate terminal IO settings to get a key",					""},
	{_P_,	"-orientation",	        "Enable PictureTransform and selects the given orientation (-inplace selects inplace rotation)", "<0, 90, 180, 270, hflip, vflip, bld, tld> [-inplace]"},
	{_P_,	"-rmdrm_hw_decrypt",	"Enable Hardware decryption for JANUS/CARDEA",						""},
	{_P_,	"-cipher",		"cipher configuration file",								"<cipher config filename>"},
	{_P_,	"-cmdline",		"command line file (option accepted only at the beggining of the command line)",	"<command line filename>"},
	{_P_,	"-font_from_file",	"Open font from file",								        "<0, [1]>"},
	{_P_,	"-special_keys",	"Allow special keys in application",						        ""},
	{_P_,	"-dmapool_ruamem",      "allocate DMAPool in RUA memory",					                ""},
	{_P_,   "-watermark",		"enable the video watermark",                                                           ""},
	{_P_,   "-folder",		"The filename is a folder",								""},
	{_P_,   "-hdmi_nice",           "\"Nice\" value for the HDMI updater thread",						"[0]"},
	{_P_,   "-no_disp",             "Do not change the outputs",								""},
	{_P_,   "-rmfp_in_a_thread",    "Launch RMFP in a thread",								"<[0], 1>"},
	{_P_,   "-file_is_not_closed",  "Consider the input file as not being closed (ie: it is still being written)",		""},
	{_P_,	"-reindex_mkv",	"reindex mkv if there is no CUE",    "<[0], 1>"},
	{_P_,	"-cache_mp4_index",	"Tell the mp4 lib to cache all the indexes",    "<[0], 1>"},
	{_P_,	"-force_linear_interleaving",	"Force the mp4 lib to read data linearly",    "<[0], 1>"},
	{_P_,	"-use_unseekable_file",	"Force the app to open the media file without seek support",    "<[0], 1>"},
	{_P_,	"-hls_key_url_options",	"Add options to the key's url for encrypted http live streaming",    "<url options>"},
	{_P_,	"-hls_key_encoding",	"Define a special encoding for the key in encrypted hls. KEY and IV must be hexadecimal string. (-base64 tell that the hls key is stored as base64 instead of binary). This option have no effect if an hls_get_key callback is set.",    "<[none], aes-128-cbc> <KEY> <IV> [-base64]"},
	{_P_,	"-hls_type",	"Force the type of a live http streaming. If the playlist precise a type, this type will be prefered",    "<VOD, EVENT, SLIDINGWIDOW>"},
	{_P_,	"-hls_thread_cache_memory",	"Set the size of memory allocated by the thread when reading hls file. Default is 10MB. (Only work if compile with thread support)",    "<Size in kBytes>"},
	{_P_,	"-hls_autoswitch_window",	"Set the window that will be used to choose when to auto switch variant in hls.\n\tThe window is set in signed percentage, the lib switch variant up if bandwitdh is greater than a bigger bandwidth+<upper_value>\n\tand switch down if the bandwidth is smaller than the current bandwidth+<lower_value>",    "<upper_value> <lower_value>"},
	{_P_,	"-rebuf",		"Configures Rebuffering (fifo=fifo fullness based, time=buffered duration based)",	"<[off], fifo, time>"},
	{_P_,	"-rebuf_fifo",		"With -rebuf fifo, overrides default rebuffering watermarks (in %)",			"<video_high> <video_low> <audio_high> <audio_low>"},
	{_P_,	"-rebuf_time",		"With -rebuf time, overrides default rebuffering watermarks (in ms). Fullness sets"
					"a fifo fullness limit in case the fifo is too small to read high watermarks",		"<video_high> <video_low> <audio_high> <audio_low> <fullness_limit>"},
	{_P_,	"-rebuf_timeout",	"With rebuffering enabled, overrides default timeout (s)",				"<timeout>"},
	{_P_,	"-read_timeout",	"Read timeout (in ms) for demuxes : will avoid blocking command processing if reading a "
					"chunk from the source file takes more than timeout ms. A timeout of 0 means wait "
					"indefinitely. All file sources are supported in MP4/MKV. Only http (+http cache) is supported "
					"in all other demuxes.",								"<timeout>"},
	{_P_,	"-lidx",		"Enable/Disable LiteIndex. LiteIndex is a small footprint on the fly indexing engine"
					"that allows to perform trickmodes without requiring the computation of a full (and therefore expensive)"
					"index. LiteIndex is available for systems without index such as Soft/PSFDemux.",	"<0, [1]>"},
	{_P_,	"-lidx_kickstart",	"Number of anchor points that are used to kickstart the LiteIndex. An higher"
					"value means higher reliability right away, at the expense of an increase in"
					"pre-buffering time. A lower value means less resilience against PTS disconti"
					"nuities, but limited effects on pre-buffering time. Default value is 40.",	"<value>"},
	{_P_,	"-lidx_trickfactor",	"Trickfactor is used to adjust the frame display rate in IFwd/IBwd mode with"
					"with liteindex enabled. The factor is in miliseconds. A factor of 500ms for"
					"instance means that whatever the requested playback speed the algorithm will"
					"attempt to produce a picture every 500 miliseconds. Higher values will produce"
					"more regular playback with less glitches (especially in backward mode). Lower"
					"values will result in more pictures, but more frequent glitches and potentially"
					"choppy playback",	"<value>"},
	{_P_,	"-seek",		"Initial seek in the file before playback.\n" 
					"\tAvailable types :\n"
					"\t\t 1:Seek To time, offset in ms",				"<type> <accurate> <offset>"},

	/**************************************************************************** PICTURE OPTIONS ****************************************************************************/

	{_PIC_,	"-ignore_picture_alpha_channel","Ignores alpha channel from picture ",							""},
	{_PIC_, "-yuv_size","provides yuv picture size (only for picture type yuv)  ",                                                  ""},
	{_PIC_, "-yuv_sampling_mode","provides yuv picture sampling_mode (only for picture type yuv)  ",                                ""},
	{_PIC_, "-yuv_has_alpha","tells that yuv picture already includes alpha (only for picture type yuv)  ",                         ""},

	/**************************************************************************** DEMUX OPTIONS ****************************************************************************/

	{_X_,	"-y",			"Choose demux type",								"<mpeg1, m2p, m2t, m2t192, dvd, aob>"},
	{_X_,	"-z",			"Repacketizes packets (needed for transport streams)",				"<0, [1]>"},
	{_X_,	"-vpid",		"Force video PID (the codec MUST be specified with the '-pv' option)",		"<value>"},
	{_X_,	"-apid",		"Force audio PID (the codec MUST be specified with the '-c' option)",		"<value>"},
	{_X_,	"-spid",		"Force subtitles PID",								"<value>"},
	{_X_,	"-asubid",		"Force audio substream ID",							"<value>"},
	{_X_,	"-ssubid",		"Force spu substream ID",							"<value>"},
	{_X_,	"-ttxpid",		"Force telext PID (else, the first teletext stream will be played) (PSF only)",	"<value>"},
	{_X_,	"-ttx",			"Enable teletext subltitles (PSF only)",					"<tv, soft, [off]>"},

	/* From PSF demux */
	{_X_,	"-de",			"Demux engine index (PSF only)",						"<[0], 1>"},
	{_X_,	"-task",		"Task index in selected engine (PSF only)",					"<[0], 1,...>"},
	{_X_,	"-tsskip",		"Number of padding bytes to discard between every 188 TS packets - use 4 for bluray(PSF only)",	"<value>"},
	{_X_,	"-rpid",		"Force PCR PID (else, the video pid will be used) (PSF only)",			"<value>"},
	{_X_,	"-spi",			"Select paralel SPI and index (PSF only)",					"<[0], 1>"},
	{_X_,	"-ssi",			"Select serial SPI and index (PSF only)",					"<[0], 1, 2>"},
	{_X_,	"-idleport",		"Select not used input port, needed for file playback (PSF only)",		"<0, 1, 2, [3]>"},
	{_X_,	"-input_protocol",	"Select the SPI input protocol (PSF only)",					"<[0=Data_Clock_Valid_Sync], 1=Data_Clock_Sync, 2=Data_Clock_Valid>"},
	{_X_,	"-ignore_pat",		"Ask the application to ignore the PAT and start playback right away. (PSF only)",""},
	{_X_,	"-pmt_index",		"Select the program for playback using given PMT index (If the index points to a network PID, next index will be used) (PSF only)","<value>"},
	{_X_,	"-pmt_pid",		"Select the program for playback using given PMT pid (PSF only)",		"<value>"},
	{_X_,	"-synclock",		"Select sync lock count for transport streams (Do not use zero for corrupted media) (PSF only)","<value>"},
	{_X_,	"-pcrdisc",		"PCR disc threshold in ms (PSF only)",						"<value [1000]>"},
	{_X_,	"-audiotspriority",	"Audio TS Priority (PSF only)",							"<value>"},
	{_X_,	"-send_scrambled",	"Send scrambled data (-ignore_subid cannot be used in this mode) (PSF only)",	""},
	{_X_,	"-ignore_subid",	"Ignore the subids for private_stream_1, valid only for program streams (-send_scrambled cannot be used in this mode) (PSF only)",""},
	{_X_,	"-waitpcr",		"Wait time1 in ms (maximum time to wait for PCR value in stream, then the first PTS is taken as PCR ) \
and time2 in ms (decrease the PTS for prebuffering, in case PCR was not found) (PSF only)",				"<value> <value>"},
	{_X_,	"-mmc",			"Use MPEG multichannel",							""},
	{_X_,	"-dfifo",		"Select the demux bitstream fifo size in KB (PSF only)",			"<value>"},
	{_X_,	"-dxfer",		"Select the demux xfer fifo count (PSF only)",					"<value>"},
	{_X_,	"-allpat",		"All PAT sections will be received by application, no matter the version (PSF only)",""},
	{_X_,	"-allpmt",		"All PMT sections will be received by application, no matter the version (PSF only)",""},
	{_X_,	"-savem",		"Save the unicast/multicast stream to the selected file (PSF only)","<file name>"},
	{_X_,	"-savep",		"Save any stream with the given PID to the selected file",			"<file name> <PID#>"},
	{_X_,	"-saved",		"Save the transport/program stream to the selected file(transport only) (PSF only)","<file name>"},
	{_X_,	"-saved192",		"Save the transport/program stream to the selected file(transport only) in 192 bytes mode, for ATS insersion (PSF only)","<file name>"},
	{_X_,	"-savedi",		"Save the transport/program stream to the selected file with index (transport only) (PSF only)","<file name> <index name>"},
	{_X_,	"-savedi192",		"Save the transport/program stream to the selected file with index (transport only) in 192 bytes mode, for ATS insersion  (PSF only)","<file name> <index name>"},
	{_X_,	"-savei",		"Save whole input from SPI to the selected file (PSF only in SPI mode)",	"<file name>"},
	{_X_,	"-savepat",		"Save the PAT stream to the selected file (transport only) (PSF only)",		"<file name>"},
	{_X_,	"-savepmt",		"Save the PMT stream to the selected file (transport only) (PSF only)",		"<file name>"},
	{_X_,	"-index",		"Specify a system index to use for trick modes",				"<file name>"},
	{_X_,	"-createindex",		"Specify a system index name to create from stream (PSF only)",			"<file name>>"},
	{_X_,	"-recoverindex",	"Specify a system index name to create from stream (PSF only), using entries from a previous index of the same name",	"<file name>>"},
	{_X_,	"-indexotf",		"DEBUG ONLY: Create and use a system index on the fly.This can affect playback of high bitrate files (PSF only)",	"<file name>"},
	{_X_,	"-multicast",		"Specify a multicast server to read from (PSF only)",				"<IP>:<Port>"},
	{_X_,	"-unicast",		"Specify an unicast IP to listen on (PSF only)",				"<IP>:<Port>"},
	{_X_,	"-iterative_seek",	"Iterative seek (seek to an Iframe without index). '-duration' must be set",	"<[0], 1>"},
	{_X_,	"-searchvpes",		"Set a special flag to search for PES headers in video payload",		""},
	{_X_,	"-ignore_ts_cc",	"Set a special flag to ignore TS continuity counter",				""},
	{_X_,	"-start_offset",	" Offset in byte where to start playing the file",				"<value>"}

};

#define NB_COMMAND_LINE_OPTIONS	(sizeof(Options_description)/sizeof(struct _option_description))

struct CommandLineOptionSet
{
	RMascii* option[NB_COMMAND_LINE_OPTIONS];
};

/**************************************************************************************************/

static RMstatus print_rmoutput_options(RMascii* options_name, struct rmoutput_options_description *pOptionsDescription, RMuint32 NumOptions)
{
	RMuint32 i;

	fprintf(NORMALMSG, "\nValid %s options are:\n", options_name);
	for (i = 0; i < NumOptions; i++) {
		if (pOptionsDescription[i].ParametersDescription[0] == '\0') {
			fprintf(NORMALMSG, "\t%s : %s\n",
				pOptionsDescription[i].OptionName,
				pOptionsDescription[i].OptionDescription);
		} else {
			fprintf(NORMALMSG, "\t%s %s : %s\n",
				pOptionsDescription[i].OptionName,
				pOptionsDescription[i].ParametersDescription,
				pOptionsDescription[i].OptionDescription);
		}
	}

	return RM_OK;
}

/**************************************************************************************************/

RMstatus init_application_options(struct AppOptions *pAppOptions)
{
	RMstatus eRMstatus = RM_OK;
	struct DisplayOptions *pDisplayOptions;
	struct PlaybackOptions * pPlaybackOptions;

	ASSERT_NULL_POINTER(pAppOptions);

	pPlaybackOptions = &(pAppOptions->Playback);
	pDisplayOptions = &(pAppOptions->Display);

	eRMstatus = PlaybackOptions_Init(pPlaybackOptions);
	if(CC_UNLIKELY(RMFAILED(eRMstatus)))
	{
		PRINT_BFILE_LINENO_RMSTATUS;
	}
	pPlaybackOptions->LoadUCODE = TEST_RMFP_DEFAULT_LOADUCODE;
	pPlaybackOptions->BoardIndex = TEST_RMFP_DEFAULT_BOARD_INDEX;
	pPlaybackOptions->loop = FALSE;
	pPlaybackOptions->test_external_resources_allocation = FALSE;
	pPlaybackOptions->dmapool_in_rua_mem = FALSE;

	pPlaybackOptions->start_in_pause = FALSE;
	pPlaybackOptions->recursive = FALSE;
	pPlaybackOptions->is_directory = FALSE;
	pPlaybackOptions->hdmi_nice = 0;
	pPlaybackOptions->no_disp = FALSE;
	pPlaybackOptions->disable_debug_logging = FALSE;
	pPlaybackOptions->detect_only = FALSE;
	pPlaybackOptions->detect_limit = 0;
	pPlaybackOptions->use_http_caching = FALSE;

	pPlaybackOptions->UseSoftwareDemux = FALSE;
	pPlaybackOptions->UseSoftwareJPEGDecoder = FALSE;
	pPlaybackOptions->UseTerminal = TRUE;

	pPlaybackOptions->RMWMDRMUseHWDecryption = FALSE;
	pPlaybackOptions->cipher_config_file_name = NULL;

	pPlaybackOptions->open_font_from_file =  TRUE;

	pPlaybackOptions->rmfp_in_a_thread = FALSE;
	pPlaybackOptions->file_is_not_closed = FALSE;


	pDisplayOptions->scaler_ID = 0;
	pDisplayOptions->route = RMFPRoute_Main;
	pDisplayOptions->osd_scaler_ID = EMHWLIB_MODULE(DispGFXMultiScaler, 0);

	pDisplayOptions->source_window.X = 0;
	pDisplayOptions->source_window.Y = 0;
	pDisplayOptions->source_window.Width = 4096;
	pDisplayOptions->source_window.Height = 4096;
	pDisplayOptions->source_window.XPositionMode = EMhwlibDisplayWindowPositionMode_FrontEdgeToBorder;
	pDisplayOptions->source_window.YPositionMode = EMhwlibDisplayWindowPositionMode_FrontEdgeToBorder;
	pDisplayOptions->source_window.XMode = EMhwlibDisplayWindowValueMode_Relative;
	pDisplayOptions->source_window.YMode = EMhwlibDisplayWindowValueMode_Relative;
	pDisplayOptions->source_window.WidthMode = EMhwlibDisplayWindowValueMode_Relative;
	pDisplayOptions->source_window.HeightMode = EMhwlibDisplayWindowValueMode_Relative;

	pDisplayOptions->output_window.X = 2048;
	pDisplayOptions->output_window.Y = 2048;
	pDisplayOptions->output_window.Width = 4096;
	pDisplayOptions->output_window.Height = 4096;
	pDisplayOptions->output_window.XPositionMode = EMhwlibDisplayWindowPositionMode_FrontEdgeToCenter;
	pDisplayOptions->output_window.YPositionMode = EMhwlibDisplayWindowPositionMode_FrontEdgeToCenter;
	pDisplayOptions->output_window.XMode = EMhwlibDisplayWindowValueMode_Relative;
	pDisplayOptions->output_window.YMode = EMhwlibDisplayWindowValueMode_Relative;
	pDisplayOptions->output_window.WidthMode = EMhwlibDisplayWindowValueMode_Relative;
	pDisplayOptions->output_window.HeightMode = EMhwlibDisplayWindowValueMode_Relative;

	pDisplayOptions->output_osd_window.X = 2048;
	pDisplayOptions->output_osd_window.Y = 2048;
	pDisplayOptions->output_osd_window.Width = 4096 /* * 9 / 10 */ ;
	pDisplayOptions->output_osd_window.Height = 4096 /* * 9 / 10 */ ;
	pDisplayOptions->output_osd_window.XPositionMode = EMhwlibDisplayWindowPositionMode_FrontEdgeToCenter;
	pDisplayOptions->output_osd_window.YPositionMode = EMhwlibDisplayWindowPositionMode_FrontEdgeToCenter;
	pDisplayOptions->output_osd_window.XMode = EMhwlibDisplayWindowValueMode_Relative;
	pDisplayOptions->output_osd_window.YMode = EMhwlibDisplayWindowValueMode_Relative;
	pDisplayOptions->output_osd_window.WidthMode = EMhwlibDisplayWindowValueMode_Relative;
	pDisplayOptions->output_osd_window.HeightMode = EMhwlibDisplayWindowValueMode_Relative;

	pDisplayOptions->deinterlacingmode = EMhwlibDeinterlacingMode_Discard_Bob;

	pDisplayOptions->deinterlacing_motion_config.Value0 = 0x00;
	pDisplayOptions->deinterlacing_motion_config.Value8 = 0x04;
	pDisplayOptions->deinterlacing_motion_config.Value16 = 0x40;
	pDisplayOptions->deinterlacing_motion_config.Value32 = 0xC0;
#ifdef RMFEATURE_HAS_DEDICATED_DEINTERLACING
	pDisplayOptions->deinterlacing_motion_config.Scale = 2;
#if (EM86XX_REVISION>2)
	pDisplayOptions->deinterlacing_window0.Xmin = 0;
	pDisplayOptions->deinterlacing_window0.Ymin = 0;
	pDisplayOptions->deinterlacing_window0.Xmax = 0;
	pDisplayOptions->deinterlacing_window0.Ymax = 0;
#else
	/* In ES1/ES2 tango3 chip we use window0 to replace main window */
	pDisplayOptions->deinterlacing_window0.Xmin = 0;
	pDisplayOptions->deinterlacing_window0.Ymin = 0;
	pDisplayOptions->deinterlacing_window0.Xmax = 4095;
	pDisplayOptions->deinterlacing_window0.Ymax = 4095;
#endif

	pDisplayOptions->deinterlacing_window1.Xmin = 0;
	pDisplayOptions->deinterlacing_window1.Ymin = 0;
	pDisplayOptions->deinterlacing_window1.Xmax = 0;
	pDisplayOptions->deinterlacing_window1.Ymax = 0;

#endif

	pDisplayOptions->deinterlacing_proportion.NewLineProportion = 10;
	pDisplayOptions->deinterlacing_proportion.ExistingLineProportion = 6;

	pDisplayOptions->mixer_color_space = EMhwlibColorSpace_None;
	pDisplayOptions->force_mixer_color_space = FALSE;
	pDisplayOptions->color_degradation_boundary = 0;

	pDisplayOptions->brightness = 0;
	pDisplayOptions->contrast = 128;
	pDisplayOptions->saturation_blue = 128;
	pDisplayOptions->saturation_red = 128;

	pDisplayOptions->lock_scaler = 0;
	pDisplayOptions->do_pulldown = FALSE;

	pDisplayOptions->nonlinearmode.Width = 0;
	pDisplayOptions->nonlinearmode.Level = 0;

	pDisplayOptions->blackstrip.Horizontal = 4096;
	pDisplayOptions->blackstrip.Vertical = 4096;

	pDisplayOptions->cutstrip.Horizontal = 4096;
	pDisplayOptions->cutstrip.Vertical = 4096;

	pDisplayOptions->strip_color.ColorSpace = EMhwlibColorSpace_YUV_601;
	pDisplayOptions->strip_color.Color.ComponentBitDepth = 8;
	pDisplayOptions->strip_color.Color.R_Cr = 0x80;
	pDisplayOptions->strip_color.Color.G_Y  = 0x10;
	pDisplayOptions->strip_color.Color.B_Cb = 0x80;

	pDisplayOptions->field_selection = EMhwlibScalerFieldSelection_BestFieldType;
	pDisplayOptions->scalingmode = EMhwlibScalingMode_LetterBox;

	pDisplayOptions->downscalingmode.Discard = FALSE;
	pDisplayOptions->downscalingmode.FilterBoundary[0] = 384;
	pDisplayOptions->downscalingmode.FilterBoundary[1] = 256;
	pDisplayOptions->downscalingmode.FilterBoundary[2] = 128;

	pDisplayOptions->video_alpha = 0xff;
	pDisplayOptions->OSD_alpha = 0xff;
	pDisplayOptions->luma_key.LumaMin = 0xff;
	pDisplayOptions->luma_key.LumaMax = 0x00;

	pDisplayOptions->time_interval.Mode = EMhwlibDisplayIntervalMode_None;
	pDisplayOptions->filtermode.Boundary_0_1 = 0x1400;
	pDisplayOptions->filtermode.Boundary_1_2 = 0x1c00;
	pDisplayOptions->filtermode.Boundary_2_3 = 0x2c00;
	pDisplayOptions->wide_bw_filter_boundary = 0x0; /* infinite upscale -> disabled by default */ 

	pDisplayOptions->subtitles_osd_height = 720;

	pDisplayOptions->SurfaceSoftEventIndex = 0;
	pDisplayOptions->UserSurfaceMode = TESTRMFP_UserSurfaceMode_None;

	pDisplayOptions->do_key_color = FALSE;
	pDisplayOptions->key_color.B_Cb = 0x00;
	pDisplayOptions->key_color.G_Y  = 0x00;
	pDisplayOptions->key_color.R_Cr = 0x00;
	pDisplayOptions->key_color.Range = 0x00;



	return RM_OK;
}

/**************************************************************************************************/

/* If the command line starts with "-cmdline filename_cmdline" we read the command line from file and
 we append the original command line. */
static RMstatus parse_command_line_from_file (RMuint32 argc, RMascii **argv, RMuint32 *argc_out, RMascii ***argv_out, RMascii **my_argv_ptr, RMascii *line, RMuint32 line_size)
{
	RMstatus err = RM_ERROR;

	if ((argc > 1) && RMCompareAscii(argv[1], "-cmdline")) {
		RMuint32 my_argc = 0;
		RMfile fileCmdLineHandle;

		if (argc < 2)
			return RM_ERROR;

		fileCmdLineHandle = RMOpenFile((const RMnonAscii*) argv[2], RM_FILE_OPEN_READ);
		if (!fileCmdLineHandle) {
			fprintf(ERRORMSG, "Error Open CmdLine file %s\n", argv[1]+1);
		}
		else {
			RMuint32 nCharRead, i;
			RMbool isSpace = TRUE;

			err = RMReadFile(fileCmdLineHandle, (RMuint8 *)line, line_size, &nCharRead);

			if (err != RM_OK) {
				fprintf(ERRORMSG, "Error RMReadFile %s\n", argv[1]+1);
			}
			else {
				fprintf(ERRORMSG, "CmdLine from file: %s\n", line);

				// keep first argument = "test_rmfp"
				my_argv_ptr[0] = argv[0];
				my_argc = 0;

				for (i=0 ; i<nCharRead ; i++) {
					/* check end line */
					if (line[i] == '\n') {
						line[i] = '\0';
						i++;
						my_argc++;
						break;
					}
					else if (line[i] == ' ') {
						isSpace = TRUE;
						line[i] = 0;
					}
					else {
						if (isSpace) {
							my_argc++;
							my_argv_ptr[my_argc] = line + i;
							isSpace = FALSE;
						}
					}
				}

				// append the arguments from the input command line, excepting the "-cmdline filename.cmdline"
				for (i=3 ; i<(RMuint32)argc ; i++) {
					my_argv_ptr[my_argc] = argv[i];
					my_argc++;
				}
				fprintf(ERRORMSG, "Final CmdLine: my_argc=%ld ", my_argc);
				for (i=0 ; i<my_argc ; i++) {
					fprintf(ERRORMSG, "%s ", my_argv_ptr[i]);
				}
				fprintf(ERRORMSG, "\n");

				// replace the application command line with the command line from file
				*argc_out = my_argc;
				*argv_out = my_argv_ptr;
			}
			RMCloseFile(fileCmdLineHandle);
		}
	}
	else
		return RM_OK;

	return err;
}

RMstatus parse_command_line(void *pContext, RMuint32 argc_in, RMascii **argv_in, struct RMFPStreamType *pStreamType, RMascii** fileName, RMbool WithOutput)
{
	#define TRY_HELP() fprintf(NORMALMSG,"Try `%s -help [playback,video,audio,demux,output,'option name']` or `%s -ghelp [pattern]` for more information.\n", app_name, app_name)
	#define TRY_HELP_SPECIFIC(type) fprintf(NORMALMSG,"Try `%s -help " type "` for more information.\n",app_name)

	RMstatus err;
	RMuint32 i;
	RMint32 cnt;
	RMascii* app_name;
	struct rmfp_main_thread_context_type *pMainContext = (struct rmfp_main_thread_context_type *) pContext;
	struct RMFPOptions *pOptions = pMainContext->pOptions;
	struct AppOptions *pAppOptions = &(pMainContext->AppOptions);

	/* Local command line */
	RMuint32 argc;
	RMascii **argv;

	/* Default to the command line from input */
	argc = argc_in;
	argv = argv_in;

	/* Default pointer */
	app_name = argv[0];

	/* Default value */
	*fileName = NULL;

	/*
	 * Allocate pAlreadySetOptions if not done already
	 */
	if (!pMainContext->pAlreadySetOptions)
	{
		pMainContext->pAlreadySetOptions = (struct CommandLineOptionSet*) RMMalloc(sizeof(struct CommandLineOptionSet));
		if (!pMainContext->pAlreadySetOptions)
		{
			fprintf(NORMALMSG, "Error allocating parameters set structure\n");
			return RM_ERROR;
		}
		RMMemset(pMainContext->pAlreadySetOptions, 0, sizeof(struct CommandLineOptionSet));
	}

	/* Get application name start */
	for (cnt = (RMasciiLength(argv[0])-1); cnt >=0 ; cnt--)
	{
		if (argv[0][cnt] == '/')
		{
			app_name = argv[0]+cnt+1;
			break;
		}
	}

	/* Force application type respect to executable name */
	if (RMCompareAscii(app_name,"play_audio"))
		pStreamType->application_type = RMFP_application_type_AUDIO;
	else if (RMCompareAscii(app_name,"play_video"))
		pStreamType->application_type = RMFP_application_type_VIDEO;
	else if (RMCompareAscii(app_name,"play_demux"))
		pStreamType->application_type = RMFP_application_type_SOFTDEMUX;
	else if (RMCompareAscii(app_name,"play_psfdemux"))
		pStreamType->application_type = RMFP_application_type_PSFDEMUX;
	else if (RMCompareAscii(app_name,"play_mp4"))
		pStreamType->application_type = RMFP_application_type_MP4;
	else if (RMCompareAscii(app_name,"play_avi_push"))
		pStreamType->application_type = RMFP_application_type_AVI;
	else if (RMCompareAscii(app_name,"play_asf"))
		pStreamType->application_type = RMFP_application_type_ASF;
	else if (RMCompareAscii(app_name,"play_mkv"))
		pStreamType->application_type = RMFP_application_type_MKV;
	else if (RMCompareAscii(app_name,"play_ogg"))
		pStreamType->application_type = RMFP_application_type_OGG;
	else if (RMCompareAscii(app_name,"play_picture"))
		pStreamType->application_type = RMFP_application_type_PICTURE;
	else if (RMCompareAscii(app_name,"test_rmfp"))
		pStreamType->application_type = RMFP_application_type_UNKNOWN;
	else if (RMCompareAscii(app_name,"example_rmfp"))
		pStreamType->application_type = RMFP_application_type_UNKNOWN;
	else {
		fprintf(NORMALMSG, "Cannot guess application type from name '%s', behaving like test_rmfp\n", app_name);
		pStreamType->application_type = RMFP_application_type_UNKNOWN;
	}

	/* Check that all parameters are OK ! */
	if ((check_and_show_all_options(NULL, FALSE, WithOutput) == RM_ERROR) && !((argc > 1) && RMCompareAscii(argv[1], "-help")))
	{
		fprintf(NORMALMSG,"%s: parameters implementation error (do '%s -help for more information')\n", argv[0], argv[0]);
		return RM_ERROR;
	}

	/* If the command line starts with "-cmdline filename_cmdline" we read the command line from file and
	 we append the original command line. Pass local memory for the final command line. */
	err = parse_command_line_from_file (argc_in, argv_in, &argc, &argv,
		pMainContext->local_argv_ptr, pMainContext->local_argv_line, sizeof(pMainContext->local_argv_line) );
	if (err == RM_ERROR) {
		fprintf(NORMALMSG,"%s: -cmdline option failed\n", argv[0]);
		return RM_ERROR;
	}

	i = 1;
	while (i<argc) {

		/* Try to get file name */
		if (argv[i][0] != '-') {
			if (*fileName == NULL) {
				*fileName = argv[i];
				i++;
			} else {
				fprintf(NORMALMSG,"%s: a file [%s] is already specified, [%s] cannot be opened\n", argv[0], *fileName, argv[i]);
				return RM_ERROR;
			}
		}
		else if (RMCompareAscii(argv[i], "-help")) {

			RMbool show_banner;

			show_banner = FALSE;

			if (argc>i+1)
			{
				if (RMCompareAscii(argv[i+1], "video")) {
					show_banner = (check_and_show_options(_options_description_type_video, TRUE) != RM_OK);
				}
				else if (RMCompareAscii(argv[i+1], "audio")) {
					show_banner = (check_and_show_options(_options_description_type_audio, TRUE) != RM_OK);
				}
				else if (RMCompareAscii(argv[i+1], "playback")) {
					show_banner = (check_and_show_options(_options_description_type_playback, TRUE) != RM_OK);
				}
				else if (RMCompareAscii(argv[i+1], "picture")) {
					show_banner = (check_and_show_options(_options_description_type_picture, TRUE) != RM_OK);
				}
				else if (RMCompareAscii(argv[i+1], "display")) {
					show_banner = (check_and_show_options(_options_description_type_display, TRUE) != RM_OK);
				}
				else if (RMCompareAscii(argv[i+1], "demux")) {
					show_banner = (check_and_show_options(_options_description_type_demux, TRUE) != RM_OK);
				}
				else if (RMCompareAscii(argv[i+1], "output") && WithOutput) {
					show_banner = (check_and_show_options(_options_description_type_output, TRUE) != RM_OK);
				}
				else
				{
					RMascii* option_description;
					RMascii* parameters_description;
					RMbool allow_multiple_instances;

					/*
					 * Try to find help for the option
					 */

					/* Find option in tables */
					if (_get_option_description(argv[i+1], &option_description, &parameters_description) != RM_OK)
					{
						fprintf(NORMALMSG,"%s: cannot find help for '%s%s'\n",
								argv[0], (argv[i+1][0] == '-')?"":"-", argv[i+1]);
						return RM_ERROR;
					}

					/* Print help for option */
					fprintf(NORMALMSG,"Option '%s%s': %s\n", (argv[i+1][0] == '-')?"":"-", argv[i+1], option_description);
					if (parameters_description[0] != 0)
						fprintf(NORMALMSG,"Usage: %s %s%s %s",app_name, (argv[i+1][0] == '-')?"":"-", argv[i+1], parameters_description);
					else
						fprintf(NORMALMSG,"Usage: %s %s%s",app_name, (argv[i+1][0] == '-')?"":"-", argv[i+1]);
					if ((option_allows_multiple_instances(((RMascii*) argv[i+1]), &allow_multiple_instances) == RM_OK) && allow_multiple_instances)
					{
						if (parameters_description[0] != 0)
							fprintf(NORMALMSG," [%s%s %s ...]",(argv[i+1][0] == '-')?"":"-", argv[i+1], parameters_description);
						else
							fprintf(NORMALMSG," [%s%s ...]",(argv[i+1][0] == '-')?"":"-", argv[i+1]);
					}
					fprintf(NORMALMSG,"\n");
				}
			}
			else
				show_banner = (check_and_show_all_options(app_name, TRUE, WithOutput) != RM_OK);

			if (show_banner)
			{
				fprintf(NORMALMSG,"\n#################################################################################################\n");
				fprintf(NORMALMSG,"######  WARNING : One or more options from the list are not yet or incorrectly supported. #######\n");
				fprintf(NORMALMSG,"######            - Missing options are pointer by a 'M'                                  #######\n");
				fprintf(NORMALMSG,"######            - Misplaced options are pointer by a '~'                                #######\n");
				fprintf(NORMALMSG,"######            - Duplicated options are pointer by a 'D'                               #######\n");
				fprintf(NORMALMSG,"######            - Not implemented options are pointer by a '!'                          #######\n");
				fprintf(NORMALMSG,"#################################################################################################\n");
			}

			return RM_PENDING;
		}
		else if (RMCompareAscii(argv[i], "-ghelp")) {

			if (argc > (i+1))
				_print_matching_options_description(argv[i+1], app_name);
			else
				fprintf(NORMALMSG,"%s: missing pattern for option [-ghelp]\n", app_name);

			return RM_PENDING;
		}
		/* Analyze option */
		else {
			enum _options_description_type current_option_type;
			RMbool allow_multiple_instances;
			RMuint32 current_option_index;

			/* Check that option has not been used yet or supports multiple instances */
			if ((option_allows_multiple_instances(((RMascii*) argv[i]), &allow_multiple_instances) == RM_OK) && !allow_multiple_instances)
			{
				RMbool is_set;

				if ((is_option_marked_as_set(pMainContext, (RMascii*) argv[i], &is_set) == RM_OK) && is_set)
				{
					fprintf(NORMALMSG,"%s: option [%s] can only be used once.\n", app_name, argv[i]);
					return RM_ERROR;
				}
			}

			/* Backup i value */
			current_option_index = i;

			/* Send to rmoutput parser */
			if (WithOutput) {
				err = rmoutput_parse_display_options(NULL, argc, argv, &i, pMainContext->display_opt);
				if (err != RM_PENDING) {
					if (err == RM_ERROR) {
						RMNOTIFY((NULL, RM_ERROR, "Error parse display options \n"));
						return err;
					}
					if (  // rewind for options that are used by both, rmoutput and rmfp
						RMCompareAscii(argv[current_option_index], "-route") ||
						RMCompareAscii(argv[current_option_index], "-ae") ||
						RMCompareAscii(argv[current_option_index], "-ad") ||
						RMCompareAscii(argv[current_option_index], "-audio_engine") ||
						RMCompareAscii(argv[current_option_index], "-audio_decoder")
					) {
						i = current_option_index;  // back it up, parse again
					} else {
						continue;
					}
				}
			}

			/* Send to all rmfp parsers */
			err = parse_all_cmdline(argc, argv, &i, pOptions, pStreamType, &current_option_type, pAppOptions);

			/* Analize result */
			switch (err)
			{
				/* Option found but, error in option parameters */
				case RM_ERROR:
				{
					RMascii* option_description = NULL;
					RMascii* parameters_description = NULL;

					/* Get informations for error reporting, if possible */
					if (_get_option_description(argv[i], &option_description, &parameters_description) != RM_OK)
					{
						option_description = "description not available";
						parameters_description = "";
					}

					/* Report error */
					fprintf(NORMALMSG,"%s: invalid parameter [%s] for option [%s]\n", app_name, argv[i+1], argv[i]);
					fprintf(NORMALMSG,"Valid parameters are : %s\n", parameters_description);

					/* Help hints */
					switch (current_option_type)
					{
						case _options_description_type_picture:
							TRY_HELP_SPECIFIC("picture");
							break;
						case _options_description_type_playback:
							TRY_HELP_SPECIFIC("playback");
							break;
						case _options_description_type_video:
							TRY_HELP_SPECIFIC("video");
							break;
						case _options_description_type_audio:
							TRY_HELP_SPECIFIC("audio");
							break;
						case _options_description_type_display:
							TRY_HELP_SPECIFIC("display");
							break;
						case _options_description_type_demux:
							TRY_HELP_SPECIFIC("demux");
							break;
						case _options_description_type_output:
							if (WithOutput) TRY_HELP_SPECIFIC("output");
							break;
					}
					break;
				}
				/* Option not found */
				case RM_PENDING:
					fprintf(NORMALMSG,"%s: unknown option [%s]\n", app_name, argv[i]);
					TRY_HELP();
					break;
				/* Option found and OK, continue parsing */
				default:
					/* Set option */
					if (mark_option_as_set(pMainContext, (RMascii*) argv[current_option_index]) != RM_OK)
					{
						fprintf(NORMALMSG,"%s: invalid option [%s]\n", app_name, argv[current_option_index]);
						break;
					}


					/* some post-commandline afterworks */
					/* if user didn't force -extrapict cmdline AND asks for MotionAdaptive deinterlacing */
					{
						RMstatus local_status;
						RMbool is_set_deinterlacing, is_set_extrapict;
						local_status = is_option_marked_as_set(pMainContext, "-extrapict", &is_set_extrapict);
						if (local_status != RM_OK) { /* should never happen, but oh, well */
							RMNOTIFY((NULL, local_status, "unexpected error on is_option_maked_as_set(-extrapict)\n"));
							return RM_ERROR;
						}
						
						local_status = is_option_marked_as_set(pMainContext, "-D", &is_set_deinterlacing);
						if (local_status != RM_OK) { /* should never happen, but oh, well */
							RMNOTIFY((NULL, local_status, "unexpected error on is_option_maked_as_set(-D)\n"));
							return RM_ERROR;
						}
						
						if (
							(is_set_extrapict == FALSE)
							&& 
							(is_set_deinterlacing == TRUE)
							&& 
							(
								(pAppOptions->Display.deinterlacingmode == EMhwlibDeinterlacingMode_MotionAdaptative)
#ifdef RMFEATURE_HAS_DEDICATED_DEINTERLACING
								||
								(pAppOptions->Display.deinterlacingmode == EMhwlibDeinterlacingMode_MotionAdaptative_4field)
#endif
							)
						) { 
							
							pOptions->video_options.vcodec_extra_pictures += 1; /* add one more picture to decode, this is most likely needed when we do adaptive deinterlacing (particularly on very agressive interlaced streams) */
						}
					}


					continue;

			}

			return RM_ERROR;
		}
	}

	pOptions->video_options.VideoScalerID = pAppOptions->Display.scaler_ID;
	pOptions->picture_options.alpha = pAppOptions->Display.OSD_alpha;
	pOptions->picture_options.force_rgb = FALSE;

	/* Missing name */
	if ((*fileName == NULL) && (!pOptions->demux_options.spi) && !pOptions->demux_options.multicast.count)
	{
		fprintf(NORMALMSG,"%s: missing file name\n",app_name);
		TRY_HELP();
		return RM_ERROR;
	}

	return RM_OK;
}

/**************************************************************************************************/

RMstatus is_option_marked_as_set(void *pContext, RMascii* option, RMbool* pIsSet)
{
	RMuint32 index_of_desc;
	RMuint32 cnt;
	struct rmfp_main_thread_context_type *pMainContext = (struct rmfp_main_thread_context_type *) pContext;

	/* Check pointer */
	if (!pMainContext->pAlreadySetOptions)
		return RM_ERROR;

	/* Get string pointer of the option in the options table */
	for (index_of_desc=0; index_of_desc<NB_COMMAND_LINE_OPTIONS; index_of_desc++)
	{
		if (RMCompareAscii(Options_description[index_of_desc].option_name, option))
			break;
	}

	/* Option not in table */
	if (index_of_desc == NB_COMMAND_LINE_OPTIONS)
		return RM_ERROR;

	/* By default, its not set */
	*pIsSet = FALSE;

	/*
	 * Try to find the option by its POINTER in the list.
	 * The pointer refers to the static at the top of the file.
	 */
	for (cnt=0; cnt<NB_COMMAND_LINE_OPTIONS; cnt++)
	{
		/* Already set ? */
		if (pMainContext->pAlreadySetOptions->option[cnt] == Options_description[index_of_desc].option_name)
		{
			*pIsSet = TRUE;
			break;
		}

		/* End of set options */
		if (!pMainContext->pAlreadySetOptions->option[cnt])
			break;
	}

	return RM_OK;
}

RMstatus PlaybackOptions_Init(struct PlaybackOptions * pPlaybackOpts)
{
	RMstatus eOutRMstatus = RM_OK;

	do
	{
		if(CC_UNLIKELY(NULL == pPlaybackOpts))
		{
			break;
		}
		pPlaybackOpts->loop = FALSE;
		pPlaybackOpts->LoopCount = 1;
	}while(FALSE);

	return eOutRMstatus;
}

#if 0

/**************************************************************************************************/

static RMbool fileName_is_directory(RMascii *fileName)
{
	RMbool is_directory = FALSE;
	RMdirectory directory = NULL;
	RMnonAscii *dirname = RMnonAsciiFromAscii( fileName );

	RMOpenDirectory( dirname, &directory );
	RMFreeNonAscii( dirname );

	if(directory != NULL) {
		RMDBGLOG((ENABLE, "%s is a directory\n", fileName));
		is_directory = TRUE;
	}
	RMCloseDirectory(directory);

	return is_directory;
}

#endif

/**************************************************************************************************/

/* look up profile name, store profile identifier */
static RMstatus get_video_profile(const RMascii* prof, enum MPEG_Profile* profile) {
	RMuint32 i;

	for (i = 0 ; profile_table[i].profile_id != 0L ; i++) {
		if ( RMCompareAscii(profile_table[i].profile_id, prof)) {
			*profile = profile_table[i].profile_profile;
			return RM_OK;
		}
	}

	return RM_ERROR;
}

/**************************************************************************************************/

/* look up audio codec name, store parameters identifier */
static RMstatus _get_audio_codec(const RMascii *codec, struct _audio_codec_entry **ptr)
{
	RMuint32 i;

	for (i=0; audio_codec_table[i].codecName != 0L; i++) {
		if ( RMCompareAscii( audio_codec_table[i].codecName, codec)) {
			*ptr = &audio_codec_table[i];
			return RM_OK;
		}
	}

	return RM_ERROR;
}

/**************************************************************************************************/

static RMstatus _get_option_description(	RMascii* option_name,
						RMascii** option_description,
						RMascii** parameters_description)
{
	RMuint32 cnt;
	RMascii* pStrippedOption = option_name;

	/* Check inputs */
	ASSERT_NULL_POINTER(option_name)
	ASSERT_NULL_POINTER(option_description)
	ASSERT_NULL_POINTER(parameters_description)

	/* Remove first - */
	if (pStrippedOption[0] == '-')
		pStrippedOption++;

	/* Find parameter in list */
	for (cnt=0;cnt<NB_COMMAND_LINE_OPTIONS;cnt++)
	{
		/* Is it the right one ? */
		if (RMasciiLength(Options_description[cnt].option_name) > 0)
		{
			if (RMCompareAscii(pStrippedOption, Options_description[cnt].option_name+1))
			{
				/* Return infos */
				*option_description = Options_description[cnt].option_description;
				*parameters_description = Options_description[cnt].parameters_description;
				return RM_OK;
			}
		}
	}

	/* Not found */
	if (cnt == NB_COMMAND_LINE_OPTIONS)
		return RM_ERROR;

	return RM_OK;
}

/**************************************************************************************************/

static RMstatus _print_matching_options_description(RMascii* option_partial_name, RMascii* pAppName)
{
	RMuint32 cnt;

	/* Check inputs */
	ASSERT_NULL_POINTER(option_partial_name)

	/* Print help for option */
	fprintf(NORMALMSG,"Options matching '%s' pattern:\n", option_partial_name);

	for (cnt=0;cnt<NB_COMMAND_LINE_OPTIONS;cnt++)
	{
		/* Is it the right one ? */
		if (RMasciiLength(Options_description[cnt].option_name) > 0)
		{
			RMascii* pPos;
			if (	(RMFindAsciiStringCaseInsensitively(Options_description[cnt].option_name, option_partial_name, &pPos) >= 0)
				||	(RMFindAsciiStringCaseInsensitively(Options_description[cnt].option_description, option_partial_name, &pPos) >= 0)
				)
			{
				RMbool allow_multiple_instances;

				fprintf(NORMALMSG,"   Option '%s': %s\n", Options_description[cnt].option_name, Options_description[cnt].option_description);
				if (Options_description[cnt].parameters_description[0] != 0)
					fprintf(NORMALMSG,"    Usage: %s %s %s", pAppName, Options_description[cnt].option_name, Options_description[cnt].parameters_description);
				else
					fprintf(NORMALMSG,"    Usage: %s %s", pAppName, Options_description[cnt].option_name);
				if ((option_allows_multiple_instances(Options_description[cnt].option_name, &allow_multiple_instances) == RM_OK) && allow_multiple_instances)
				{
					if (Options_description[cnt].parameters_description[0] != 0)
						fprintf(NORMALMSG," [%s %s ...]", Options_description[cnt].option_name, Options_description[cnt].parameters_description);
					else
						fprintf(NORMALMSG," [%s ...]", Options_description[cnt].option_name);
				}
				fprintf(NORMALMSG,"\n");
			}
		}
	}

	return RM_OK;
}

/**************************************************************************************************/

static RMstatus check_and_show_options(enum _options_description_type option_type, RMbool show)
{
	RMuint32 cnt;
	RMascii* banner = "";
	RMbool show_banner = FALSE;
	RMbool not_implemented = FALSE;
	RMstatus status;

	/* Get right table */
	switch (option_type)
	{
		case _options_description_type_video:	banner = "\nValid options for video are:\n"; break;
		case _options_description_type_audio:	banner = "\nValid options for audio are:\n"; break;
		case _options_description_type_playback:banner = "\nValid options for playback are:\n"; break;
		case _options_description_type_picture: banner = "\nValid options for picture are:\n"; break;
		case _options_description_type_display:	banner = "\nValid options for display are :\n"; break;
		case _options_description_type_demux:	banner = "\nValid options for demux are:\n"; break;
		case _options_description_type_output:	banner = "\nValid options for output are:\n"; break;
	}

	/* Print banner */
	if (show)
		fprintf(NORMALMSG,banner);

	if (option_type == _options_description_type_output) {
		struct rmoutput_options_description *pOptionsDescription;
		RMuint32 NumOptions;

		rmoutput_get_display_options_description(&pOptionsDescription, &NumOptions);
		if (show) print_rmoutput_options("output", pOptionsDescription, NumOptions);

		rmoutput_get_edid_target_description(&pOptionsDescription, &NumOptions);
		if (show) print_rmoutput_options("EDID target", pOptionsDescription, NumOptions);

		rmoutput_get_timing_options_description(&pOptionsDescription, &NumOptions);
		if (show) print_rmoutput_options("video timing", pOptionsDescription, NumOptions);

		rmoutput_get_hdsd_options_description(&pOptionsDescription, &NumOptions);
		if (show) print_rmoutput_options("HD-SD", pOptionsDescription, NumOptions);

		rmoutput_get_hdmi_selection_description(&pOptionsDescription, &NumOptions);
		if (show) print_rmoutput_options("HDMI chip selection", pOptionsDescription, NumOptions);

		rmoutput_get_hdmi_options_description(&pOptionsDescription, &NumOptions);
		if (show) print_rmoutput_options("HDMI", pOptionsDescription, NumOptions);

		rmoutput_get_video_options_description(&pOptionsDescription, &NumOptions);
		if (show) print_rmoutput_options("video", pOptionsDescription, NumOptions);

		rmoutput_get_audio_options_description(&pOptionsDescription, &NumOptions);
		if (show) print_rmoutput_options("audio", pOptionsDescription, NumOptions);
	} else {
		/* Print options */
		for (cnt = 0; cnt < NB_COMMAND_LINE_OPTIONS; cnt++)
		{
			enum _options_check_result check_result;
			RMascii * available_string = "E";

			/* Skip only options of the right type */
			if (Options_description[cnt].option_type != option_type)
				continue;

			/* Analyze it */
			status = check_option(Options_description[cnt].option_name, option_type, &check_result);
			if (status != RM_OK)
				return status;

			switch (check_result)
			{
				case _options_check_result_ok:
					available_string = " ";
					break;
				case _options_check_result_missing:
					show_banner = TRUE;
					available_string = "M";
					break;
				case _options_check_result_misplaced:
					show_banner = TRUE;
					available_string = "~";
					break;
				case _options_check_result_duplicated:
					show_banner = TRUE;
					available_string = "D";
					break;
				case _options_check_result_not_implemented:
					not_implemented = TRUE;
					available_string = "!";
					break;
			}

			if (show)
			{
				if (Options_description[cnt].parameters_description[0] == 0)
					fprintf(NORMALMSG,"%s %s : %s\n",
						available_string,
						Options_description[cnt].option_name,
						Options_description[cnt].option_description);
				else
					fprintf(NORMALMSG,"%s %s %s : %s\n",
						available_string,
						Options_description[cnt].option_name,
						Options_description[cnt].parameters_description,
						Options_description[cnt].option_description);
			}
		}
	}

	if (show)
		fprintf(NORMALMSG,"\n");

	/* Notify caller */
	if (show_banner)
		return RM_ERROR;
	else
	{
		if (not_implemented)
			return RM_NOTIMPLEMENTED;
		else
			return RM_OK;
	}
}

/**************************************************************************************************/

static RMstatus check_and_show_all_options(RMascii* app_name, RMbool show, RMbool WithOutput)
{
#define SHOW_ALL_OPTIONS_STATUS(x)\
	RMDBGLOG((DISABLE, "option %d status %d\n"));\
	switch (err)\
	{\
		case RM_OK:\
			break;\
		case RM_NOTIMPLEMENTED:\
			if (returned_err == RM_OK)\
				returned_err = RM_NOTIMPLEMENTED;\
			break;\
		default:\
			returned_err = RM_ERROR;\
			break;\
	}\

	RMstatus err, returned_err;

	if (show && app_name)
		fprintf(NORMALMSG,"Usage: %s filename options\n",app_name);

	returned_err = RM_OK;

	err = check_and_show_options(_options_description_type_playback, show);
	SHOW_ALL_OPTIONS_STATUS(_options_description_type_playback);
	err = check_and_show_options(_options_description_type_picture, show);
	SHOW_ALL_OPTIONS_STATUS(_options_description_type_picture);
	err = check_and_show_options(_options_description_type_video, show);
	SHOW_ALL_OPTIONS_STATUS(_options_description_type_video);
	err = check_and_show_options(_options_description_type_audio, show);
	SHOW_ALL_OPTIONS_STATUS(_options_description_type_audio);
	err = check_and_show_options(_options_description_type_display, show);
	SHOW_ALL_OPTIONS_STATUS(_options_description_type_display);
	err = check_and_show_options(_options_description_type_demux, show);
	SHOW_ALL_OPTIONS_STATUS(_options_description_type_demux);
	if (WithOutput) {
		err = check_and_show_options(_options_description_type_output, show);
		SHOW_ALL_OPTIONS_STATUS();
	}

	return returned_err;
}

/**************************************************************************************************/

static RMstatus check_option(RMascii *option, enum _options_description_type option_type, enum _options_check_result* pResult)
{
	RMstatus err;
	RMascii* argv[1];
	RMuint32 index;
	struct RMFPOptions tmp_options;
	struct AppOptions tmp_app_options;
	RMbool misplaced, not_implemented;
	RMuint32 found;

#define ANALYZE_OPTION_CHECK_STATUS(current_type)		\
	switch (err) {						\
	case RM_PENDING:					\
		break;						\
	case RM_NOTIMPLEMENTED:					\
		found++;					\
		not_implemented = TRUE;				\
		if (current_type != option_type)		\
			misplaced = TRUE;			\
		break;						\
	default:						\
		found++;					\
		if (current_type != option_type)		\
			misplaced = TRUE;			\
		break;						\
	}


	/* Prepare parameters */
	argv[0] = option;

	found = 0;
	misplaced = FALSE;
	not_implemented = FALSE;

	/*
	 * Send to all parsers
	 */

	index = 0;
	err = parse_playback_cmdline(1, argv, &index, &tmp_options.playback_options, NULL, &(tmp_app_options.Playback));
	ANALYZE_OPTION_CHECK_STATUS(_options_description_type_playback);

	index = 0;
	err = parse_picture_cmdline(1, argv, &index, &tmp_options.picture_options);
	ANALYZE_OPTION_CHECK_STATUS(_options_description_type_picture);

	index = 0;
	err = parse_video_cmdline(1, argv, &index, &tmp_options.video_options);
	ANALYZE_OPTION_CHECK_STATUS(_options_description_type_video);

	index = 0;
	err = parse_audio_cmdline(1, argv, &index, &tmp_options.audio_options,  &(tmp_app_options.Audio));
	ANALYZE_OPTION_CHECK_STATUS(_options_description_type_audio);

	index = 0;
	err = parse_display_cmdline(1, argv, &index, &(tmp_app_options.Display));
	ANALYZE_OPTION_CHECK_STATUS(_options_description_type_display);

	index = 0;
	err = parse_demux_cmdline(1, argv, &index, &tmp_options.demux_options);
	ANALYZE_OPTION_CHECK_STATUS(_options_description_type_demux);

	/* Return right result */
	if (found == 0)
		*pResult = _options_check_result_missing;
	else
	{
		if (found == 1)
		{
			if (not_implemented)
				*pResult = _options_check_result_not_implemented;
			else
			{
				if (misplaced)
					*pResult = _options_check_result_misplaced;
				else
					*pResult = _options_check_result_ok;
			}
		}
		else
			*pResult = _options_check_result_duplicated;
	}

	return RM_OK;
}

/**************************************************************************************************/

static RMstatus option_allows_multiple_instances(RMascii* option, RMbool* pAllowMultipleInstances)
{
	RMuint32 cnt;
	RMascii* pStrippedOption = option;

	/* Remove first - */
	if (pStrippedOption[0] == '-')
		pStrippedOption++;

	/* Find option in list */
	for (cnt=0; cnt<(sizeof(_multiple_instances_options)/sizeof(RMascii*)); cnt++)
	{
		if (RMCompareAscii(_multiple_instances_options[cnt]+1, pStrippedOption))
		{
			*pAllowMultipleInstances = TRUE;
			return RM_OK;
		}
	}

	*pAllowMultipleInstances =  FALSE;
	return RM_OK;
}

/**************************************************************************************************/

static RMstatus mark_option_as_set(struct rmfp_main_thread_context_type *pContext, RMascii* option)
{
	RMuint32 index_of_desc;
	RMuint32 cnt;

	/* Check pointer */
	if (!pContext->pAlreadySetOptions)
		return RM_ERROR;

	/* Get string pointer of the option in the options table */
	for (index_of_desc=0; index_of_desc<NB_COMMAND_LINE_OPTIONS; index_of_desc++)
	{
		if (RMCompareAscii(Options_description[index_of_desc].option_name, option))
			break;
	}

	/* Option not in table */
	if (index_of_desc == NB_COMMAND_LINE_OPTIONS)
		return RM_ERROR;

	/*
	 * Try to find the option by its POINTER in the list.
	 * The pointer refers to the static at the top of the file.
	 */
	for (cnt=0; cnt<NB_COMMAND_LINE_OPTIONS; cnt++)
	{
		/* Already set ? */
		if (pContext->pAlreadySetOptions->option[cnt] == Options_description[index_of_desc].option_name)
			return RM_OK;

		/* End of set options */
		if (!pContext->pAlreadySetOptions->option[cnt])
			break;
	}

	/* No more room in table (should not happend) */
	if (cnt == NB_COMMAND_LINE_OPTIONS)
		return RM_FATAL;

	/* Add option to table */
	pContext->pAlreadySetOptions->option[cnt] = Options_description[index_of_desc].option_name;

	return RM_OK;
}

/**************************************************************************************************/

// returns TRUE if 'ch' is not the first char of another option, or potential filename
static RMbool opt_arg(RMascii ch) {
	return (ch != '-') && (ch != '.') && (ch != '/') && (ch != '\\') && (ch != '_');
}

static RMstatus parse_all_cmdline(RMuint32 argc, RMascii **argv, RMuint32 *index, struct RMFPOptions *pOptions, struct RMFPStreamType *pStreamType,enum _options_description_type *current_option_type, struct AppOptions * pAppOptions)
{
	RMstatus err;

	/* Send the option to the parsers from all sections */

	*current_option_type = _options_description_type_playback;
	err = parse_playback_cmdline(argc, argv, index, &pOptions->playback_options, pStreamType, &(pAppOptions->Playback));
	if (err == RM_ERROR)
		return RM_ERROR;
	if (err != RM_PENDING)
		return RM_OK;

	*current_option_type = _options_description_type_picture;
	err = parse_picture_cmdline(argc, argv, index, &pOptions->picture_options);
	if (err == RM_ERROR)
		return RM_ERROR;
	if (err != RM_PENDING)
		return RM_OK;

	*current_option_type = _options_description_type_video;
	err = parse_video_cmdline(argc, argv, index, &pOptions->video_options);
	if (err == RM_ERROR)
		return RM_ERROR;
	if (err != RM_PENDING)
		return RM_OK;
	*current_option_type = _options_description_type_audio;
	err = parse_audio_cmdline(argc, argv, index, &pOptions->audio_options, &(pAppOptions->Audio));
	if (err == RM_ERROR)
		return RM_ERROR;
	if (err != RM_PENDING)
		return RM_OK;
	*current_option_type = _options_description_type_display;
	err = parse_display_cmdline(argc, argv, index, &(pAppOptions->Display));
	if (err == RM_ERROR)
		return RM_ERROR;
	if (err != RM_PENDING)
		return RM_OK;
	*current_option_type = _options_description_type_demux;
	err = parse_demux_cmdline(argc, argv, index, &pOptions->demux_options);
	if (err == RM_ERROR)
		return RM_ERROR;
	if (err != RM_PENDING)
		return RM_OK;

	return RM_PENDING;
}

/**************************************************************************************************/

static RMstatus parse_audio_cmdline(RMuint32 argc, RMascii **argv, RMuint32 *index, struct RMFPAudioOptions *audio_options, struct AudioOptions *pTestRMFPAudio_options)
{
	RMuint32 i = *index;
	RMbool bad_option_parameters= FALSE;

	if (RMCompareAscii(argv[i], "-audio_engine") || RMCompareAscii(argv[i], "-ae")) {
		if (argc > i+1) {
			RMuint32 audio_engine;

			RMasciiAutoToUint32(argv[i+1], &audio_engine);

			if (audio_engine >= MAX_AUDIO_ENGINE_INSTANCES) {
				fprintf(NORMALMSG,"Invalid audio engine %ld (should be in [%d, %d])\n", audio_engine, 0, MAX_AUDIO_ENGINE_INSTANCES-1);
				bad_option_parameters = TRUE;
			}
			else {
				audio_options->EngineIndex = audio_engine;
				i += 2;
			}
		}
		else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-audio_decoder") || RMCompareAscii(argv[i], "-ad")) {
		if (argc > i+1) {
			RMuint32 audio_decoder;

			RMasciiAutoToUint32(argv[i+1], &audio_decoder);

			if (audio_decoder >= MAX_AUDIO_DECODER_INSTANCES_PER_ENGINE) {
				fprintf(NORMALMSG,"Invalid audio decoder %ld (should be in [%d, %d])\n", audio_decoder, 0, MAX_AUDIO_DECODER_INSTANCES_PER_ENGINE-1);
				bad_option_parameters = TRUE;
			}
			else {
				audio_options->DecoderIndex = audio_decoder;
				i += 2;
			}
		}
		else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-audio_track")) {
		if (argc > i+1) {
			RMasciiAutoToUint32(argv[i+1], &(audio_options->audio_track));
			i += 2;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-lsbfirst")) {
		audio_options->MsbFirst = FALSE;
		i+=1;
	}
	else if (RMCompareAscii(argv[i], "-afifo")){
		if (argc > i+1) {
			audio_options->fifo_size = strtol(argv[i+1], NULL, 10);
			audio_options->fifo_size *= 1024;
			i+=2;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-axfer")){
		if (argc > i+1) {
			audio_options->xfer_count = strtol(argv[i+1], NULL, 10);
			i+=2;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-bits_per_sample")){
		if (argc > i+1) {
			audio_options->bit_per_sample = strtol(argv[i+1], NULL, 10);
			i+=2;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-askip_first_n_bytes")) {
		if (argc > i+1) {
			RMasciiAutoToUint32(argv[i+1], &(audio_options->skip_first_n_bytes));
			i += 2;
		}
		else
				bad_option_parameters = TRUE;
	}
	else if ( RMCompareAscii(argv[i], "-ac3compmode")) {
		if (argc > i+1) {
			audio_options->CompMode = (enum Ac3CompMode_type)atoi(argv[i+1]);
			i+=2;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if ( RMCompareAscii(argv[i], "-ac3dynhi")) {
		if (argc > i+1) {
			RMuint32 dynhi;
			sscanf((const RMascii*)argv[i+1], (const RMascii*)"0x%08lx", &dynhi);
			audio_options->DynScaleHi = dynhi;
			i += 2;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if ( RMCompareAscii(argv[i], "-ac3dynlo")) {
		if (argc > i+1) {
			RMuint32 dynlo;
			sscanf((const RMascii*)argv[i+1], (const RMascii*)"0x%08lx", &dynlo);
			audio_options->DynScaleLo = dynlo;
			i += 2;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if ( RMCompareAscii(argv[i], "-ac3pcmscale")) {
		if (argc > i+1) {
			RMuint32 PcmScale;
			sscanf((const RMascii
				*)argv[i+1], (const RMascii
					*)"0x%08lx", &PcmScale);
			audio_options->PcmScale = PcmScale;
			i += 2;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-c")) {
		if (argc > i+1) {
			struct _audio_codec_entry *pCodecTable = NULL;
			if ( _get_audio_codec(argv[i+1], &pCodecTable) == RM_OK ) {
				audio_options->Codec = pCodecTable->AudioCodec;
				audio_options->SubCodec = pCodecTable->SubCodec;
				audio_options->ChannelAssign = pCodecTable->channel_Assign;
				audio_options->bit_per_sample = pCodecTable->bits_per_sample;
				i+=2;
			}else
				bad_option_parameters = TRUE;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if ( RMCompareAscii(argv[i], "-unsigned")) {
		audio_options->SignedPCM = FALSE;
		i++;
	}
	else if ( RMCompareAscii(argv[i], "-pcm_frequency")) {
		if (argc > i+1) {
			RMasciiAutoToUint32(argv[i+1], &(audio_options->PCMSamplingFrequency));
			i+= 2;
		}
		else
			bad_option_parameters = TRUE;
	}else if ( RMCompareAscii(argv[i], "-pcm_channel")) {
		if (argc > i+1) {
			RMuint32 value;
			RMasciiAutoToUint32(argv[i+1], &value);
			switch (value) {
			case 1:
				audio_options->ChannelAssign = PcmCda1_C;
				break;
			case 2:
				audio_options->ChannelAssign = PcmCda2_LR;
				break;
			case 3:
				audio_options->ChannelAssign = PcmCda3_LfRfLfe;
				break;
			case 4:
				audio_options->ChannelAssign = PcmCda4_LfRfLsRs;
				break;
			case 5:
				audio_options->ChannelAssign = PcmCda5_LfRfLfeLsRs;
				break;
			case 6:
				audio_options->ChannelAssign = PcmCda6_LfRfCLfeLsRs;
				break;
			default :
				bad_option_parameters = TRUE;
				break;
			}
			i+= 2;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if ( RMCompareAscii(argv[i], "-downsample")) {
		audio_options->DownSample = TRUE;
		i++;
	}
	else if ( RMCompareAscii(argv[i], "-asend_n_bytes")) {
		if (argc > i+1) {
			RMasciiAutoToUint32(argv[i+1], &(audio_options->send_n_bytes));
			i += 2;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if ( RMCompareAscii(argv[i], "-aplay")) {
		if (argc > i+1) {
			audio_options->audio_play_time.PlayMode = strtol(argv[i+1], NULL, 10);
			i+=2;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if ( RMCompareAscii(argv[i], "-astart")) {
		if (argc > i+1) {
		  RMuint64 startPTS;
		  sscanf((const RMascii*)argv[i+1], (const RMascii*)"%llu", &startPTS);
		  audio_options->audio_play_time.PlayStartPTS = startPTS;
			i+=2;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if ( RMCompareAscii(argv[i], "-astop")) {
		if (argc > i+1) {
			RMuint64 stopPTS;
			sscanf((const RMascii*)argv[i+1], (const RMascii*)"%llu", &stopPTS);
			audio_options->audio_play_time.PlayEndPTS = stopPTS;
			i+=2;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if ( RMCompareAscii(argv[i], "-x")) {
		if (argc > i+1) {
			RMasciiAutoToUint32(argv[i+1], &(audio_options->chconfig));
			i += 2;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if ( RMCompareAscii(argv[i], "-drc")) {
		if (argc > i+1) {
			RMasciiAutoToUint32(argv[i+1], &(audio_options->drcenable));
			i += 2;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if ( RMCompareAscii(argv[i], "-boost")) {
		if (argc > i+1) {
			RMasciiAutoToUint32(argv[i+1], &(audio_options->drcboost));
			i += 2;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if ( RMCompareAscii(argv[i], "-cut")) {
		if (argc > i+1) {
			RMasciiAutoToUint32(argv[i+1], &(audio_options->drccut));
			i += 2;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if ( RMCompareAscii(argv[i], "-dialref")) {
		if (argc > i+1) {
			RMasciiToInt32(argv[i+1], &(audio_options->drcdialref));
			i += 2;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if ( RMCompareAscii(argv[i], "-lossless")) {
		audio_options->lossless = TRUE;
		i++;
	}
	else if ( RMCompareAscii(argv[i], "-acmod2dual")) {
		audio_options->Acmod2DualMode = TRUE;
		i++;
	}
	else if ( RMCompareAscii(argv[i], "-nosync")) {
		audio_options->sync_stc = FALSE;
		i++;
	}
	else if ( RMCompareAscii(argv[i], "-ttone_type")) {
		if(argc > i+1) {
			RMuint32 ttone_type;
			sscanf((const RMascii*)argv[i+1], (const RMascii*)"0x%lx", &ttone_type);
			audio_options->TToneType = ttone_type;
			i += 2;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if ( RMCompareAscii(argv[i], "-ttone_mask")) {
		if(argc > i+1) {
			RMuint32 ttone_chmask;
			sscanf((const RMascii*)argv[i+1], (const RMascii*)"0x%lx", &ttone_chmask);
			audio_options->TToneChannelMask = ttone_chmask;
			i += 2;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-extra_audio")) {
		if (argc > i+2) {
			if (audio_options->nb_audio_instances < 1) {
				fprintf(NORMALMSG,"Internal error: nb_audio_instances not initialized\n");
				bad_option_parameters = TRUE;
			}
			else if (audio_options->nb_audio_instances >= MAX_AUDIO_DECODER_INSTANCES) {
				fprintf(NORMALMSG,"Cannot add more extra audio (%d max)\n", MAX_AUDIO_DECODER_INSTANCES-1);
				bad_option_parameters = TRUE;
			}
			else {
				RMuint32 audio_engine, audio_decoder;
				RMasciiAutoToUint32(argv[i+1], &audio_engine);
				if (audio_engine >= MAX_AUDIO_ENGINE_INSTANCES) {
					fprintf(NORMALMSG,"Invalid audio engine %ld (should be in [%d, %d])\n", audio_engine, 0, MAX_AUDIO_ENGINE_INSTANCES-1);
					bad_option_parameters = TRUE;
				}
				else {
					RMasciiAutoToUint32(argv[i+2], &audio_decoder);
					if (audio_decoder >= MAX_AUDIO_DECODER_INSTANCES_PER_ENGINE) {
						fprintf(NORMALMSG,"Invalid audio decoder %ld (should be in [%d, %d])\n", audio_decoder, 0, MAX_AUDIO_DECODER_INSTANCES_PER_ENGINE-1);
						bad_option_parameters = TRUE;
					}
					else {
						pTestRMFPAudio_options->ExtraAudioEngine[audio_options->nb_audio_instances-1] = audio_engine;
						pTestRMFPAudio_options->ExtraAudioDecoder[audio_options->nb_audio_instances-1] = audio_decoder;

						audio_options->nb_audio_instances++;
						i += 3;
					}
				}

			}
		}
		else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-afs")){
		if (argc > i+1) {
			audio_options->afs = (strtol(argv[i+1], NULL, 10) > 0) ? TRUE : FALSE;
			i+=2;
		}
		else
			bad_option_parameters = TRUE;
	}
	else
		return RM_PENDING;


	/* Check if it failed */
	if (bad_option_parameters == TRUE)
	{
		return RM_ERROR;
	}
	else
	{
		*index = i;
		return RM_OK;
	}
}

/**************************************************************************************************/

static RMstatus _store_video_profile(enum MPEG_Profile profile, struct RMFPVideoOptions *video_options)
{

	switch (profile) {
	case Profile_MPEG2_SD:
	case Profile_MPEG2_DVD:
	case Profile_MPEG2_SD_DeInt:
	case Profile_MPEG2_DVD_DeInt:
		video_options->vcodec = EMhwlibVideoCodec_MPEG2;
		video_options->vcodec_max_width = 720;
		video_options->vcodec_max_height = 576;
		break;
	case Profile_MPEG2_HD:
	case Profile_MPEG2_HD_DeInt:
		video_options->vcodec = EMhwlibVideoCodec_MPEG2;
		video_options->vcodec_max_width = 1920;
		video_options->vcodec_max_height = 1080;
		break;
	case Profile_MPEG4_SD:
	case Profile_MPEG4_SD_DeInt:
		video_options->vcodec = EMhwlibVideoCodec_MPEG4;
		video_options->vcodec_max_width = 720;
		video_options->vcodec_max_height = 576;
		break;
	case Profile_MPEG4_SD_Padding:
	case Profile_MPEG4_SD_DeInt_Padding:
		video_options->vcodec = EMhwlibVideoCodec_MPEG4_Padding;
		video_options->vcodec_max_width = 720;
		video_options->vcodec_max_height = 576;
		break;
	case Profile_MPEG4_HD:
	case Profile_MPEG4_HD_DeInt:
		video_options->vcodec = EMhwlibVideoCodec_MPEG4;
		video_options->vcodec_max_width = 1920;
		video_options->vcodec_max_height = 1080;
		break;
	case Profile_MPEG4_HD_Padding:
	case Profile_MPEG4_HD_DeInt_Padding:
		video_options->vcodec = EMhwlibVideoCodec_MPEG4_Padding;
		video_options->vcodec_max_width = 1920;
		video_options->vcodec_max_height = 1080;
		break;
	case Profile_DIVX3_SD:
		video_options->vcodec = EMhwlibVideoCodec_DIVX3;
		video_options->vcodec_max_width = 720;
		video_options->vcodec_max_height = 576;
		break;
	case Profile_DIVX3_HD:
		video_options->vcodec = EMhwlibVideoCodec_DIVX3;
		video_options->vcodec_max_width = 1920;
		video_options->vcodec_max_height = 1080;
		break;
	case Profile_VC1_SD:
		video_options->vcodec = EMhwlibVideoCodec_VC1;
		video_options->vcodec_max_width = 720;
		video_options->vcodec_max_height = 576;
		break;
	case Profile_VC1_HD:
		video_options->vcodec = EMhwlibVideoCodec_VC1;
		video_options->vcodec_max_width = 1920;
		video_options->vcodec_max_height = 1080;
		break;
	case Profile_WMV_SD:
		video_options->vcodec = EMhwlibVideoCodec_WMV;
		video_options->vcodec_max_width = 720;
		video_options->vcodec_max_height = 576;
		break;
	case Profile_WMV_816P:
		video_options->vcodec = EMhwlibVideoCodec_WMV;
		video_options->vcodec_max_width = 1440;
		video_options->vcodec_max_height = 816;
		break;
	case Profile_WMV_HD:
		video_options->vcodec = EMhwlibVideoCodec_WMV;
		video_options->vcodec_max_width = 1920;
		video_options->vcodec_max_height = 1080;
		break;
	case Profile_H264_SD:
	case Profile_H264_SD_DeInt:
		video_options->vcodec = EMhwlibVideoCodec_H264;
		video_options->vcodec_profile = EMhwlib_H264_BaselineProfile;
		video_options->vcodec_level = EMhwlib_H264_Level_4;
		video_options->vcodec_max_width = 720;
		video_options->vcodec_max_height = 576;
		break;
	case Profile_H264_HD:
	case Profile_H264_HD_DeInt:
		video_options->vcodec = EMhwlibVideoCodec_H264;
		video_options->vcodec_profile = EMhwlib_H264_BaselineProfile;
		video_options->vcodec_level = EMhwlib_H264_Level_4;
		video_options->vcodec_max_width = 1920;
		video_options->vcodec_max_height = 1080;
		break;
	case Profile_AVS_SD:
		video_options->vcodec = EMhwlibVideoCodec_AVS;
		video_options->vcodec_max_width = 720;
		video_options->vcodec_max_height = 576;
		break;
	case Profile_AVS_HD:
		video_options->vcodec = EMhwlibVideoCodec_AVS;
		video_options->vcodec_max_width = 1920;
		video_options->vcodec_max_height = 1080;
		break;
	case Profile_H261_SD:
		video_options->vcodec = EMhwlibVideoCodec_H261;
		video_options->vcodec_max_width = 352;
		video_options->vcodec_max_height = 288;
		break;
	default:
		RMDBGLOG((ENABLE, "Unknown video decoder codec \n"));
		video_options->vcodec = 0xFF;
		break;
	}

	return RM_OK;
}

/**************************************************************************************************/

static RMstatus parse_picture_cmdline(RMuint32 argc, RMascii **argv, RMuint32 *index, struct RMFPPictureOptions *picture_options)
{
	RMuint32 i = *index;
	RMbool bad_option_parameters = FALSE;
	if (RMCompareAscii(argv[i], "-ignore_picture_alpha_channel")){
		picture_options->ignore_picture_alpha_channel = TRUE;
		i++;
	} else if (RMCompareAscii(argv[i], "-yuv_size")){
		if (argc > i+2) {
			RMasciiToUInt32(argv[i+1], &picture_options->yuv_width);
			RMasciiToUInt32(argv[i+2], &picture_options->yuv_height);
			if (picture_options->yuv_width == 0 || picture_options->yuv_height == 0) {
				RMNOTIFY((NULL, RM_INVALID_PARAMETER, "invalid width or height:  %dx%d \n", picture_options->yuv_width, picture_options->yuv_height));
				bad_option_parameters = TRUE;
			}
			i+=3;
		}
  	  	
	} else if (RMCompareAscii(argv[i], "-yuv_has_alpha")) {
		picture_options->yuv_has_alpha = TRUE;
		i+=1;
	} else if (RMCompareAscii(argv[i], "-yuv_sampling_mode")){
		if (argc > i+1) {
			if(RMCompareAscii(argv[i+1], "444")) { 
				picture_options->yuv_sampling_mode = EMhwlibSamplingMode_444;
			} else if (RMCompareAscii(argv[i+1], "422")) {
				picture_options->yuv_sampling_mode = EMhwlibSamplingMode_422;
			} else {
				RMNOTIFY((NULL, RM_INVALID_PARAMETER, "unsupported interleaved yuv_sampling_mode: %d\n", picture_options->yuv_sampling_mode));
				bad_option_parameters = TRUE;
			}
			i+=2;
		}
	} else {
		return RM_PENDING;
	}


	/* Check if it failed */
	if (bad_option_parameters == TRUE) {
		return RM_ERROR;
	}
	else {
		*index = i;
		return RM_OK;
	}
}

/**************************************************************************************************/




static RMstatus parse_video_cmdline(RMuint32 argc, RMascii **argv, RMuint32 *index, struct RMFPVideoOptions *video_options)
{
	RMuint32 i = *index;
	enum MPEG_Profile profile = 0;
	//enum VideoDecoder_Codec_type type;
	RMbool bad_option_parameters = FALSE;

	if (RMCompareAscii(argv[i], "-pv")) {
		if (argc > i+1) {
			if (get_video_profile(argv[i+1], &profile) != RM_OK) {
				bad_option_parameters = TRUE;
			}

			_store_video_profile(profile, video_options);

			i+=2;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-ve")) {
		if (argc > i+1) {
			RMasciiAutoToUint32(argv[i+1], &(video_options->EngineIndex));
			i += 2;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-vd")) {
		if (argc > i+1) {
			RMasciiAutoToUint32(argv[i+1], &(video_options->DecoderIndex));
			i += 2;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-video_track")) {
		if (argc > i+1) {
			RMasciiAutoToUint32(argv[i+1], (RMuint32 *)&(video_options->video_track));
			i += 2;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-fixvop")) {
		if (argc > i+2) {
			video_options->ForceTiming = TRUE;
			RMasciiAutoToUint32(argv[i+1], &(video_options->PTSTimeScale));
			RMasciiAutoToUint32(argv[i+2], &(video_options->PTSTimeIncrement));
			i += 3;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-vtimescale")) {
		if (argc > i+1) {
			video_options->ForcePTSTimeScale = TRUE;
			RMasciiAutoToUint32(argv[i+1], &(video_options->PTSTimeScale));
			i += 2;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-ics")) {
		if (argc > i+1) {
			RMstatus err = rmoutput_get_ColorSpace_from_name(argv[i + 1], &(video_options->input_color_space));
			if (err != RM_OK)
				bad_option_parameters = TRUE;

			if (bad_option_parameters == FALSE)
				video_options->force_input_color_space = TRUE;
			i += 2;
		} else
			bad_option_parameters = TRUE;
	}

	else if (RMCompareAscii(argv[i], "-cc")) {
		if (argc > i+1) {
			if(RMCompareAscii(argv[i+1], "tv")) {
				video_options->CloseCaptionMode = RMFPCloseCaptionMode_SendToTV;
			}
			else if(RMCompareAscii(argv[i+1], "soft") ||
				RMCompareAscii(argv[i+1], "608soft") ||
				RMCompareAscii(argv[i+1], "cc1")) {
				video_options->CloseCaptionMode    = RMFPCloseCaptionMode_ShowInOSD;
				video_options->CloseCaptionType    = RMFPCloseCaptionType_EIA608;

				video_options->CloseCaptionSelect  = EMhwlibCCSelect_CC1;

			}
			else if(RMCompareAscii(argv[i+1], "cc2") ) {
				video_options->CloseCaptionMode    = RMFPCloseCaptionMode_ShowInOSD;
				video_options->CloseCaptionType    = RMFPCloseCaptionType_EIA608;

				video_options->CloseCaptionSelect  = EMhwlibCCSelect_CC2;

			}
			else if(RMCompareAscii(argv[i+1], "cc3") ) {
				video_options->CloseCaptionMode    = RMFPCloseCaptionMode_ShowInOSD;
				video_options->CloseCaptionType    = RMFPCloseCaptionType_EIA608;

				video_options->CloseCaptionSelect  = EMhwlibCCSelect_CC3;

			}
			else if(RMCompareAscii(argv[i+1], "cc4") ) {
				video_options->CloseCaptionMode    = RMFPCloseCaptionMode_ShowInOSD;
				video_options->CloseCaptionType    = RMFPCloseCaptionType_EIA608;

				video_options->CloseCaptionSelect  = EMhwlibCCSelect_CC4;

			}
			else if(RMCompareAscii(argv[i+1], "708soft")) {
				video_options->CloseCaptionMode    = RMFPCloseCaptionMode_ShowInOSD;
				video_options->CloseCaptionType    = RMFPCloseCaptionType_EIA708;
			}
			else if(RMCompareAscii(argv[i+1], "off")) {
				video_options->CloseCaptionMode = RMFPCloseCaptionMode_Disabled;
			}
			else
				bad_option_parameters = TRUE;

			i += 2;
		}
		else
			bad_option_parameters = TRUE;
	}

	else if (RMCompareAscii(argv[i], "-vcodec")) {
		if (argc > i+3) {
			if(RMCompareAscii(argv[i+1], "mpeg2")) {
				video_options->vcodec = EMhwlibVideoCodec_MPEG2;
			}
			else if(RMCompareAscii(argv[i+1], "mpeg4")) {
				video_options->vcodec = EMhwlibVideoCodec_MPEG4;
			}
			else if(RMCompareAscii(argv[i+1], "divx3")) {
				video_options->vcodec = EMhwlibVideoCodec_DIVX3;
			}
			else if(RMCompareAscii(argv[i+1], "vc1")) {
				video_options->vcodec = EMhwlibVideoCodec_VC1;
			}
			else if(RMCompareAscii(argv[i+1], "wmv")) {
				video_options->vcodec = EMhwlibVideoCodec_WMV;
			}
			else if(RMCompareAscii(argv[i+1], "h264")) {
				video_options->vcodec = EMhwlibVideoCodec_H264;
			}
			else if(RMCompareAscii(argv[i+1], "avs")) {
				video_options->vcodec = EMhwlibVideoCodec_AVS;
			}
			else if(RMCompareAscii(argv[i+1], "h261")) {
				video_options->vcodec = EMhwlibVideoCodec_H261;
			}
			else if(RMCompareAscii(argv[i+1], "jpeg")) {
				video_options->vcodec = EMhwlibJPEGCodec;
				if (video_options->vcodec_profile == 0)
					video_options->vcodec_profile = EMhwlib_JPEG_422_Profile;
			}
			else
				bad_option_parameters = TRUE;
			if (bad_option_parameters == FALSE) {
				RMasciiAutoToUint32(argv[i+2], &(video_options->vcodec_max_width));
				RMasciiAutoToUint32(argv[i+3], &(video_options->vcodec_max_height));
			}

			i += 4;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-extrapict")) {
		if (argc > i+1) {
			RMasciiAutoToUint32(argv[i+1], (RMuint32*)&(video_options->vcodec_extra_pictures));
			i += 2;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-vprofile")) {
		if (argc > i+1) {
			RMasciiAutoToUint32(argv[i+1], &(video_options->vcodec_profile));
			i += 2;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-vlevel")) {
		if (argc > i+1) {
			RMasciiAutoToUint32(argv[i+1], &(video_options->vcodec_level));
			i += 2;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-vfifo")) {
		if (argc > i+1) {
			video_options->fifo_size = strtol(argv[i+1], NULL, 10);
			video_options->fifo_size *= 1024;
			i+=2;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-vxfer")){
		if (argc > i+1) {
			video_options->xfer_count = strtol(argv[i+1], NULL, 10);
			i+=2;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-ms")){
		video_options->MSflag = TRUE;
		i++;
	}
	else if (RMCompareAscii(argv[i], "-seq")){
		if (argc > i+1) {
			if (RMNCompareAscii(argv[i+1], "0x", 2) == TRUE) {
				sscanf(argv[i+1], "0x%lx", &video_options->wmv9_seq);
			} else {
				video_options->wmv9_seq = strtol(argv[i+1], NULL, 10);
			}
			i+=2;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-scan")){
		if (argc > i+1) {
			if(RMCompareAscii(argv[i+1], "frame")) {
				video_options->input_scan_mode = EMhwlibScanMode_Progressive;
				i += 2;
			}
			else if(RMCompareAscii(argv[i+1], "top")) {
				video_options->input_scan_mode = EMhwlibScanMode_Interlaced_TopFieldFirst;
				i += 2;
			}
			else if(RMCompareAscii(argv[i+1], "bot")) {
				video_options->input_scan_mode = EMhwlibScanMode_Interlaced_BotFieldFirst;
				i += 2;
			}
			else
				bad_option_parameters = TRUE;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-displayerror")){
		if (argc > i+1) {
			RMasciiAutoToUint32(argv[i+1], &(video_options->display_error_threshold));
			i += 2;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-err_prop_threshold")){
		if (argc > i+1) {
			RMasciiAutoToUint32(argv[i+1], &(video_options->anchor_error_propagation.AnchorErrPropagationThreshold));
			i += 2;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-err_prop_length")){
		if (argc > i+1) {
			RMasciiAutoToUint32(argv[i+1], &(video_options->anchor_error_propagation.AnchorErrPropagationLength));
			i += 2;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-intprog")){
		if (argc > i+1) {
			if(RMCompareAscii(argv[i+1], "std")) {
				video_options->interlaced_progressive_algorithm = INTERLACED_PROGRESSIVE_ALGORITHM_USING_DECODER_SPECIFICATION;
				i += 2;
			}
			else if(RMCompareAscii(argv[i+1], "mpeg2_prog_seq")) {
				video_options->interlaced_progressive_algorithm = INTERLACED_PROGRESSIVE_ALGORITHM_USING_MPEG2_PROGRESSIVE_SEQ;
				i += 2;
			}
			else if(RMCompareAscii(argv[i+1], "mpeg2_menu_prog")) {
				video_options->interlaced_progressive_algorithm = INTERLACED_PROGRESSIVE_ALGORITHM_USING_MPEG2_MENU_PROGRESSIVE;
				i += 2;
			}
			else
				bad_option_parameters = TRUE;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-use_afd")){
		// obsolete
		i++;
	}
	else if (RMCompareAscii(argv[i], "-src_afd") || RMCompareAscii(argv[i], "-act")) {
		if (argc > i+1) {
			video_options->ForceAFD = TRUE;
			video_options->afd.ActiveFormatValid = TRUE;
			if (RMFAILED(rmoutput_get_ActiveFormat_from_name(argv[i+1], &(video_options->afd.ActiveFormat)))) {
				bad_option_parameters = TRUE;
			} else if (video_options->afd.ActiveFormat == EMhwlibAF_same_as_picture) {
				video_options->afd.ActiveFormatValid = FALSE;
			}
			i += 2;
		} else {
			bad_option_parameters = TRUE;
		}
	}
	else if (RMCompareAscii(argv[i], "-src_aspix")) {
		if (argc > i+2) {
			video_options->ForceAsp = TRUE;
			RMasciiToUInt32(argv[i+1], &(video_options->afd.PixelAspectRatio.X));
			RMasciiToUInt32(argv[i+2], &(video_options->afd.PixelAspectRatio.Y));
			video_options->afd.FrameAspectRatio.X = 0;
			video_options->afd.FrameAspectRatio.Y = 0;
			i += 3;
		} else {
			bad_option_parameters = TRUE;
		}
	}
	else if (RMCompareAscii(argv[i], "-src_asp")) {
		if (argc > i+2) {
			video_options->ForceAsp = TRUE;
			RMasciiToUInt32(argv[i+1], &(video_options->afd.FrameAspectRatio.X));
			RMasciiToUInt32(argv[i+2], &(video_options->afd.FrameAspectRatio.Y));
			video_options->afd.PixelAspectRatio.X = 0;
			video_options->afd.PixelAspectRatio.Y = 0;
			i += 3;
		} else {
			bad_option_parameters = TRUE;
		}
	}
	else if (RMCompareAscii(argv[i], "-src_bar")) {
		if (argc > i+4) {
			video_options->ForceBarInfo = TRUE;
			video_options->BarInfo.VerticalBarDataValid = TRUE;
			video_options->BarInfo.HorizontalBarDataValid = TRUE;
			RMasciiToUInt16(argv[i+1], &(video_options->BarInfo.EndLeftBarPixelNum));
			RMasciiToUInt16(argv[i+2], &(video_options->BarInfo.StartRightBarPixelNum));
			RMasciiToUInt16(argv[i+3], &(video_options->BarInfo.EndTopBarLineNum));
			RMasciiToUInt16(argv[i+4], &(video_options->BarInfo.StartBottomBarLineNum));
			i += 5;
		} else {
			bad_option_parameters = TRUE;
		}
	}
	else if (RMCompareAscii(argv[i], "-src_scan")) {
		if (argc > i + 1) {
			i++;
			video_options->ForceScanInfo = TRUE;
			if ((argv[i][0] == 'o') || (argv[i][0] == 'O')) {
				video_options->ScanInfo = EMhwlibScanInfo_Overscanned;
			} else if ((argv[i][0] == 'u') || (argv[i][0] == 'U')) {
				video_options->ScanInfo = EMhwlibScanInfo_Underscanned;
			} else {
				video_options->ScanInfo = EMhwlibScanInfo_NoData;
			}
			i++;
		} else {
			bad_option_parameters = TRUE;
		}
	}
	else if (RMCompareAscii(argv[i], "-src_3d")) {
		if (argc > i + 1) {
			i++;
			video_options->Force3D = TRUE;
			RMMemset(&(video_options->Stereoscopic3D), 0, sizeof(video_options->Stereoscopic3D));
			video_options->Stereoscopic3D.Format = EMhwlibStereoscopicFormat_2D;
			video_options->Stereoscopic3D.SubSamplingMethod = EMhwlibStereoscopicSubSamplingMethod_Horizontal;
			video_options->Stereoscopic3D.SubSamplingPosition = EMhwlibStereoscopicSubSamplingPosition_OddEven;
			video_options->Stereoscopic3D.Parity = EMhwlibStereoscopicParity_LeftFirst;
			{
				RMstatus err;
				err = rmoutput_get_StereoscopicFormat_from_name(argv[i], &(video_options->Stereoscopic3D.Format));
				if (RMFAILED(err)) {
					bad_option_parameters = TRUE;
					video_options->Force3D = FALSE;
				}
				i++;
				if (RMSUCCEEDED(err) && (argc > i) && opt_arg(argv[i][0])) {
					err = rmoutput_get_StereoscopicSubSampling_from_name(argv[i], &(video_options->Stereoscopic3D.SubSamplingMethod), &(video_options->Stereoscopic3D.SubSamplingPosition));
					if (RMFAILED(err)) {
						bad_option_parameters = TRUE;
					}
					i++;
					if (RMSUCCEEDED(err) && (argc > i) && opt_arg(argv[i][0])) {
						err = rmoutput_get_StereoscopicParity_from_name(argv[i], &(video_options->Stereoscopic3D.Parity));
						if (RMFAILED(err)) {
							bad_option_parameters = TRUE;
						}
					}
				}
			}
		} else {
			bad_option_parameters = TRUE;
		}
	}
	else if (RMCompareAscii(argv[i], "-skipNCP")) {
		if (argc > i+1) {
			RMuint32 dummy = TRUE;

			RMasciiAutoToUint32(argv[i+1], &dummy);

			if (dummy)
				video_options->skipNCP = TRUE;
			else
				video_options->skipNCP = FALSE;
			i += 2;
		}
		else
			bad_option_parameters = TRUE;
	}
#if (EM86XX_CHIP >= EM86XX_CHIPID_TANGO3)
	else if (RMCompareAscii(argv[i], "-pp")) {
		if (argc > i+1) {
			RMuint32 enable;

			RMasciiAutoToUint32(argv[i+1], &enable);

			if (enable == 1)
			{
				video_options->pp_enabled = TRUE;
				video_options->common_flags |= COMMON_FLAGS_ENABLE_POST_PROCESSING;
			}
			else
				video_options->pp_enabled = FALSE;

			i += 2;
		}
		else
			bad_option_parameters = TRUE;
	}
#endif
	else if (RMCompareAscii(argv[i], "-ignore_h264bl")){
		video_options->h264_flags |= H264_IGNORE_BROKEN_LINK;
		i++;
	}
	else if (RMCompareAscii(argv[i], "-ignore_h264cpb")){
		video_options->h264_flags |= H264_IGNORE_CPB_REMOVAL_TIME;
		i++;
	}
	else if (RMCompareAscii(argv[i], "-pts_purge")){
		video_options->common_flags |= COMMON_FLAGS_PURGE_PTS_FIFO;
		i++;
	}
	else if (RMCompareAscii(argv[i], "-ignore_disp_size")){
		video_options->common_flags |= COMMON_FLAGS_IGNORE_PICTURE_DISPLAY_SIZE;
		i++;
	}
	else if (RMCompareAscii(argv[i], "-h264_svc")) {
		if (argc > i+1) {
			RMuint32 value;

			RMasciiAutoToUint32(argv[i+1], &value);

			if (value > 31)
				bad_option_parameters = TRUE;
			else
			{
				video_options->h264_flags |= value<<8;
				i += 2;
			}
		}
		else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-cs_algo")){
		if (argc > i+1) {
			if(RMCompareAscii(argv[i+1], "601")) {
				video_options->cs_algo = EMhwlibDefaultColorSpaceAlgoritm_601;
				i += 2;
			}
			else if(RMCompareAscii(argv[i+1], "709")) {
				video_options->cs_algo = EMhwlibDefaultColorSpaceAlgoritm_709;
				i += 2;
			}
			else if(RMCompareAscii(argv[i+1], "auto")) {
				video_options->cs_algo = EMhwlibDefaultColorSpaceAlgoritm_SD601_HD709;
				i += 2;
			}
			else
				bad_option_parameters = TRUE;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if ( RMCompareAscii(argv[i], "-rm_no_deblock"))
	{
		i++;
		video_options->rm_no_deblock = TRUE;
	}
	else if ( RMCompareAscii(argv[i], "-rm_no_B_deblock"))
	{
		i++;
		video_options->rm_no_B_deblock = TRUE;
	}
	else if ( RMCompareAscii(argv[i], "-vd_maxmem")) {
		i++;
		video_options->ForceMaxMem = TRUE;
	}
        else if ( RMCompareAscii(argv[i], "-vd_customem")) { 
		if (argc > i+1) {
			RMasciiAutoToUint32(argv[i+1], &(video_options->custom_memunp));
			i += 2;
		}
		else {
			bad_option_parameters = TRUE;
                }
	}
        else {
		return RM_PENDING;
	}

	/* Check if it failed */
	if (bad_option_parameters == TRUE) {
		return RM_ERROR;
	}
	else {
		*index = i;
		return RM_OK;
	}
}

/**************************************************************************************************/

static RMstatus parse_playback_cmdline(RMuint32 argc, RMascii **argv, RMuint32 *index, struct RMFPPlayOptions *playback_options, struct RMFPStreamType *pStreamType, struct PlaybackOptions *pTestRMFPPlayback_options)
{
	RMbool bad_option_parameters = FALSE;
	RMuint32 i;

	i= *index;

	if (RMCompareAscii(argv[i], "-app")) {
		if (argc > i+1) {
			/* Is it already set ?*/
			if (pStreamType != NULL) {
				if (pStreamType->application_type == RMFP_application_type_UNKNOWN) {
					if (RMCompareAscii(argv[i+1], "mp4")) {
						RMDBGLOG((ENABLE, "selecting MP4 playback\n"));
						pStreamType->application_type = RMFP_application_type_MP4;
					}
					else if (RMCompareAscii(argv[i+1], "audio")) {
						RMDBGLOG((ENABLE, "selecting AUDIO playback\n"));
						pStreamType->application_type = RMFP_application_type_AUDIO;
					}
					else if (RMCompareAscii(argv[i+1], "video")) {
						RMDBGLOG((ENABLE, "selecting VIDEO playback\n"));
						pStreamType->application_type = RMFP_application_type_VIDEO;
					}
					else if (RMCompareAscii(argv[i+1], "avi")) {
						RMDBGLOG((ENABLE, "selecting AVI playback\n"));
						pStreamType->application_type = RMFP_application_type_AVI;
					}
					else if (RMCompareAscii(argv[i+1], "swdemux")) {
						RMDBGLOG((ENABLE, "selecting SWDEMUX playback\n"));
						pStreamType->application_type = RMFP_application_type_SOFTDEMUX;
					}
					else if (RMCompareAscii(argv[i+1], "psfdemux")) {
						RMDBGLOG((ENABLE, "selecting PSFDEMUX playback\n"));
						pStreamType->application_type = RMFP_application_type_PSFDEMUX;
					}
					else if (RMCompareAscii(argv[i+1], "asf")) {
						RMDBGLOG((ENABLE, "selecting ASF playback\n"));
						pStreamType->application_type = RMFP_application_type_ASF;
					}
					else if (RMCompareAscii(argv[i+1], "picture")) {
						RMDBGLOG((ENABLE, "selecting PICTURE playback\n"));
						pStreamType->application_type = RMFP_application_type_PICTURE;
					}
					else if (RMCompareAscii(argv[i+1], "mkv")) {
						RMDBGLOG((ENABLE, "selecting MKV playback\n"));
						pStreamType->application_type = RMFP_application_type_MKV;
					}
					else if (RMCompareAscii(argv[i+1], "riff")) {
						RMDBGLOG((ENABLE, "selecting RIFF playback\n"));
						pStreamType->application_type = RMFP_application_type_RIFF;
					}
					else if (RMCompareAscii(argv[i+1], "flv")) {
						RMDBGLOG((ENABLE, "selecting FLV playback\n"));
						pStreamType->application_type = RMFP_application_type_FLV;
					}
					else if (RMCompareAscii(argv[i+1], "hls")) {
						RMDBGLOG((ENABLE, "selecting HLS playback\n"));
						pStreamType->application_type = RMFP_application_type_HLS;
					}
					else if (RMCompareAscii(argv[i+1], "rm")) {
						RMDBGLOG((ENABLE, "selecting realmedia playback\n"));
						pStreamType->application_type = RMFP_application_type_REALMEDIA;
					}
					else if (RMCompareAscii(argv[i+1], "ogg")) {
						RMDBGLOG((ENABLE, "selecting ogg/ogm playback\n"));
						pStreamType->application_type = RMFP_application_type_OGG;
					}
					else {
						bad_option_parameters = TRUE;
					}
				}
			}

			i += 2;
		} else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-plugin")) {
		if (argc > i+1) {
			RMNCopyAscii(playback_options->PlugInPath, (RMascii*) (argv[i+1]), RMFP_PLUGIN_PATH_SIZE);
			i += 2;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-m")) {
		if (argc > i+1) {
			pTestRMFPPlayback_options->BoardIndex = strtol(argv[i+1], NULL, 10);
			i += 2;
		}
		else
			bad_option_parameters = TRUE;

		i++;
	}
	else if (RMCompareAscii(argv[i], "-folder")) {
		pTestRMFPPlayback_options->is_directory = TRUE;
		i++;
	}
	else if (RMCompareAscii(argv[i], "-hdmi_nice")) {
		if (argc > i+1) {
			pTestRMFPPlayback_options->hdmi_nice = strtol(argv[i+1], NULL, 10);
			i += 2;
		} else {
			bad_option_parameters = TRUE;
		}
		i++;
	}
	else if (RMCompareAscii(argv[i], "-no_disp")) {
		pTestRMFPPlayback_options->no_disp = TRUE;
		i++;
	}
	else if (RMCompareAscii(argv[i], "-L")) {
		i++;
		return RM_NOTIMPLEMENTED;
	}
	else if (RMCompareAscii(argv[i], "-l")) {
		pTestRMFPPlayback_options->loop = TRUE;
		i++;
	}
	else if (RMCompareAscii(argv[i], "-disable_RMDBG")) {
		pTestRMFPPlayback_options->disable_debug_logging = TRUE;
		i++;
	}
	else if (RMCompareAscii(argv[i], "-detect_only")) {
		pTestRMFPPlayback_options->detect_only = TRUE;
		i++;
	}
	else if (RMCompareAscii(argv[i], "-detect_limit")) {
		if (argc > i+1) {
			RMasciiToInt32(argv[i+1], &(pTestRMFPPlayback_options->detect_limit));
			pTestRMFPPlayback_options->detect_limit *= 1024;
			i += 2;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if ( RMCompareAscii(argv[i], "-softdemux")) {
		pTestRMFPPlayback_options->UseSoftwareDemux = TRUE;
		i++;
	}
	else if ( RMCompareAscii(argv[i], "-softjpeg")) {
		pTestRMFPPlayback_options->UseSoftwareJPEGDecoder = TRUE;
		i++;
	}
	else if ( RMCompareAscii(argv[i], "-rmdrm_hw_decrypt")) {
		pTestRMFPPlayback_options->RMWMDRMUseHWDecryption = TRUE;
		i++;
	}
	else if (RMCompareAscii(argv[i], "-cipher")) {
		if (argc > i+1) {
			pTestRMFPPlayback_options->cipher_config_file_name = argv[i+1];
			i += 2;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-cmdline")) {
		// we support "-cmdline" only at the start of the command line
		bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-use_http_caching")) {
		if (argc > i+1) {
			pTestRMFPPlayback_options->use_http_caching = strtol(argv[i+1], NULL, 10);
			i += 2;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-extract_attachments")) {
		if (argc > i+1) {
			RMNCopyAscii( playback_options->attachments_extraction_dir, (RMascii*) (argv[i+1]), RMFP_MAX_ATTACHMENTS_DIRECTORY_SIZE);
			i += 2;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-subtitles_track")) {
		if (argc > i+1) {
			RMasciiAutoToUint32(argv[i+1], (RMuint32 *)&(playback_options->subtitles_track));
			i += 2;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if ( RMCompareAscii(argv[i], "-nosubs")) {
		playback_options->enable_spu = FALSE;
		i++;
	}
	else if (RMCompareAscii(argv[i], "-data")) {
		if (argc > i + 1) {
			RMuint32 n = 0;

			playback_options->send_audio = FALSE;
			playback_options->send_video = FALSE;
			playback_options->send_spu = FALSE;

			for (n=0; n<RMasciiLength(argv[i+1]); n++) {
				switch (argv[i+1][n]) {
				case 'a':
					playback_options->send_audio = TRUE;
					break;
				case 'v':
					playback_options->send_video = TRUE;
					break;
				case 's':
					playback_options->send_spu = TRUE;
					break;
				case 'n':
					break;
				default :
					bad_option_parameters = TRUE;
					break;
				}
			}
			i+=2;
		} else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-picture_format")) {
		if (argc > i+1) {
			if(RMCompareAscii(argv[i+1], "bmp")) {
				playback_options->PictureFormat = RMFPPictureFormat_BMP;
			}
			else if(RMCompareAscii(argv[i+1], "jpeg")) {
				playback_options->PictureFormat = RMFPPictureFormat_JPEG;
			}
			else if(RMCompareAscii(argv[i+1], "gif")) {
				playback_options->PictureFormat = RMFPPictureFormat_GIF;
			}
			else if(RMCompareAscii(argv[i+1], "png")) {
				playback_options->PictureFormat = RMFPPictureFormat_PNG;
			}
			else if(RMCompareAscii(argv[i+1], "yuv")) {
				playback_options->PictureFormat = RMFPPictureFormat_YUV;
			}
			else if(RMCompareAscii(argv[i+1], "test")) {
				playback_options->PictureFormat = RMFPPictureFormat_TEST;
			}
			else
				bad_option_parameters = TRUE;

			i += 2;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-ts")) {
		if (argc > i + 1) {
			RMuint32 n = 0;

			playback_options->send_audio_pts = FALSE;
			playback_options->send_video_pts = FALSE;
			playback_options->send_spu_pts = FALSE;

			for (n=0; n<RMasciiLength(argv[i+1]); n++) {
				switch (argv[i+1][n]) {
				case 'a':
					playback_options->send_audio_pts = TRUE;
					break;
				case 'v':
					playback_options->send_video_pts = TRUE;
					break;
				case 's':
					playback_options->send_spu_pts = TRUE;
					break;
				case 'n':
					break;
				default :
					bad_option_parameters = TRUE;
					break;
				}
			}
			i+=2;
		} else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-savev")) {
		if (argc > i + 1) {

			/* Try to open file */
			if (playback_options->save_video_file_handle == NULL)
				playback_options->save_video_file_handle = RMOpenFile((const RMnonAscii*)argv[i+1], RM_FILE_OPEN_WRITE);

			if (playback_options->save_video_file_handle == NULL)
			{
				printf ("Unable to open video file [%s] for writting\n",argv[i+1]);
				bad_option_parameters = TRUE;
			}
			else
				i+=2;
		} else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-savea")) {
		if (argc > i + 1) {

			/* Try to open file */
			if (playback_options->save_audio_file_handle == NULL)
				playback_options->save_audio_file_handle = RMOpenFile((const RMnonAscii*)argv[i+1], RM_FILE_OPEN_WRITE);

			if (playback_options->save_audio_file_handle == NULL)
			{
				printf ("Unable to open audio file [%s] for writting\n",argv[i+1]);
				bad_option_parameters = TRUE;
			}
			else
				i+=2;
		} else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-saves")) {
		if (argc > i + 1) {

			/* Try to open file */
			if (playback_options->save_spu_file_handle == NULL)
				playback_options->save_spu_file_handle = RMOpenFile((const RMnonAscii*)argv[i+1], RM_FILE_OPEN_WRITE);

			if (playback_options->save_spu_file_handle == NULL)
			{
				printf ("Unable to open subtitles file [%s] for writting\n",argv[i+1]);
				bad_option_parameters = TRUE;
			}
			else
				i+=2;
		} else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-saveformat")) {

		return RM_NOTIMPLEMENTED;

		if (argc > i+1) {
			if (RMCompareAscii(argv[i+1], "ms")) {
				playback_options->savems = TRUE;
				i+=2;
			}
			else
				bad_option_parameters = TRUE;
		}
		else
			bad_option_parameters = TRUE;

	}
	else if (RMCompareAscii(argv[i], "-speed")) {
		if (argc > i+2) {
			playback_options->speed_N = strtol(argv[i+1], NULL, 10);
			playback_options->speed_M = strtol(argv[i+2], NULL, 10);
			i += 3;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-dram")) {
		if (argc > i+1) {
			playback_options->DRAMIndex = strtol(argv[i+1], NULL, 10);
			i += 2;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-manutest")) {
		i++;
		return RM_NOTIMPLEMENTED;
	}
	else if (RMCompareAscii(argv[i], "-pause")) {
		pTestRMFPPlayback_options->start_in_pause = TRUE;
		i++;
	}
	else if (RMCompareAscii(argv[i], "-R")) {
		pTestRMFPPlayback_options->is_directory = TRUE;
		pTestRMFPPlayback_options->recursive = TRUE;
		i++;
	}
	else if (RMCompareAscii(argv[i], "-nostcdrift")) {
		playback_options->stc_compensation = FALSE;
		playback_options->vcxo_index = -1;
		i ++;
	}
	else if (RMCompareAscii(argv[i], "-vcxo")) {
		if (argc > i + 1) {

			if (RMCompareAscii(argv[i+1], "none")) {
				playback_options->stc_compensation = FALSE;
				playback_options->vcxo_index = -1;
				i+=2;
			}
			else if (RMCompareAscii(argv[i+1], "stconly")) {
				playback_options->stc_compensation = TRUE;
				playback_options->vcxo_index = -1;
				i+=2;
			}
			else if (RMasciiCharacterIsDigit(*argv[i+1])) {
				playback_options->stc_compensation = TRUE;
				RMasciiToInt32(argv[i+1],&playback_options->vcxo_index);
				i+=2;
			}
			else {
				printf ("Invalid vcxo option %s\n",argv[i+1]);
				bad_option_parameters = TRUE;
			}
		} else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-resetvcxo")) {
		playback_options->reset_vcxo = RMFPVcxoReset_SpeedAndRegulation;
		i ++;
	}
	else if (RMCompareAscii(argv[i], "-stcdbg")) {
		i++;
		return RM_NOTIMPLEMENTED;
	}
	else if (RMCompareAscii(argv[i], "-stc_offset_ms")) { // TODO: we should have -delay as obsolete but that translates to stc_offset_ms
		if (argc > i+1) {
			playback_options->stc_offset_ms = strtol(argv[i+1], NULL, 10);
			i += 2;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-dmapool")) {
		if (argc > i+2) {
			playback_options->dmapool_count = strtol(argv[i+1], NULL, 10);
			playback_options->dmapool_log2size = strtol(argv[i+2], NULL, 10);
			i += 3;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-disk_ctrl")) {
		if (argc > i+1) {
			/* TODO : Add disk_ctrl_state in options */
			//playback_options->disk_ctrl_state = DISK_CONTROL_STATE_SLEEPING;
			playback_options->disk_ctrl_low_level = strtol(argv[i+1], NULL, 10);
			playback_options->disk_ctrl_low_level *= 1024;

			playback_options->enable_disk_control = TRUE;
			i += 2;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-disk_ctrl_buf_size")) {
		if (argc > i+1) {
			playback_options->disk_ctrl_buffer_size = strtol(argv[i+1], NULL, 10);
			playback_options->disk_ctrl_buffer_size *= 1024;

			i += 2;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-prebuf")) {
		if (argc > i+1) {
			playback_options->prebuf_max = strtol(argv[i+1], NULL, 10);
			playback_options->prebuf_max *= 1024;
			i += 2;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-sat")) {
		playback_options->send_audio_trickmode = TRUE;
		i ++;
	}
	else if (RMCompareAscii(argv[i], "-past")) {
		playback_options->require_video_audio = FALSE;
		i ++;
	}
	else if (RMCompareAscii(argv[i], "-noucode")) {
		pTestRMFPPlayback_options->LoadUCODE = FALSE;
		i++;
	}
	else if (RMCompareAscii(argv[i], "-STCIndex")) {
		if (argc > i+1) {
			RMuint32 stc_index;

			RMasciiAutoToUint32(argv[i+1], &stc_index);

			if (stc_index >= MAX_TIMER_COUNT) {
				fprintf(NORMALMSG,"Invalid stc index %ld (should be in [%d, %d])\n", stc_index, 0, MAX_TIMER_COUNT-1);
				bad_option_parameters = TRUE;
			}
			else {
				playback_options->STCIndex = stc_index;
				i += 2;
			}
		}
		else
			bad_option_parameters = TRUE;

	}
	else if (RMCompareAscii(argv[i], "-STCEngine")) {
		if (argc > i+1) {
			RMuint32 stc_engine;

			RMasciiAutoToUint32(argv[i+1], &stc_engine);

			if (stc_engine >= MAX_DEMUX_ENGINES) {
				fprintf(NORMALMSG,"Invalid stc engine %ld (should be in [%d, %d])\n", stc_engine, 0, MAX_DEMUX_ENGINES-1);
				bad_option_parameters = TRUE;
			}
			else {
				playback_options->STCEngine = stc_engine;
				i += 2;
			}
		}
		else
			bad_option_parameters = TRUE;

	}
	else if (RMCompareAscii(argv[i], "-far")) {
		RMuint32 dummy;
		if (argc > i+1) {
			dummy = strtol(argv[i+1], NULL, 10);
			i += 2;

			if (!dummy)
				playback_options->fast_audio_recovery = FALSE;
			else
				playback_options->fast_audio_recovery = TRUE;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-duration")) {
		if (argc > i+1) {
			playback_options->duration = strtol(argv[i+1], NULL, 10);
			i+=2;
		} else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-accurate_seek")) {
		RMuint32 dummy;
		if (argc > i+1) {
			dummy = strtol(argv[i+1], NULL, 10);
			i+=2;

			if (!dummy)
				playback_options->accurate_seek = FALSE;
			else
				playback_options->accurate_seek = TRUE;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-linear_mode")) {
		RMuint32 dummy;
		if (argc > i+1) {
			dummy = strtol(argv[i+1], NULL, 10);
			i+=2;

			if (!dummy)
				playback_options->linear_mode = FALSE;
			else
				playback_options->linear_mode = TRUE;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-external_subs_delayms")) {
		RMuint32 dummy;
		if (argc > i+1) {
			dummy = strtol(argv[i+1], NULL, 10);
			i+=2;

			playback_options->external_subs_delayms = (RMint64) dummy;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-text_subs")) {

		/* Check count */
		if (playback_options->text_subs.count == RMFP_MAX_TEXT_SUBS)
		{
			fprintf(NORMALMSG,"Too much external text subtitles specified\n");
			bad_option_parameters = TRUE;
		}
		else
		{
			if (argc > i + 1)
			{
				RMascii* found_pos;
				RMascii* type = NULL;

				/* Get extension of file */
				if (	(RMFindAsciiStringCaseInsensitively((RMascii*) argv[i+1], ".srt", &found_pos) >= 0)
				&&	((argv[i+1] + RMasciiLength((RMascii*) argv[i+1])) ==  (found_pos + 4))
				   )
				{
					if (argc > i + 2)
					{
						if (RMCompareAscii(argv[i+2], "latin1"))
							playback_options->text_subs.entry[playback_options->text_subs.count].type = RMFPTextSubs_ASCII;
						else if (RMCompareAscii(argv[i+2], "utf8"))
							playback_options->text_subs.entry[playback_options->text_subs.count].type = RMFPTextSubs_UTF8;
						else
						{
							bad_option_parameters = TRUE;
							printf("Invalid encoding type [%s] for SRT sub\n", argv[i+2]);
						}
						type = "SRT";
					}
					else
					{
						bad_option_parameters = TRUE;
						printf("Missing encoding type for SRT sub\n");
					}
				}
				else if ((RMFindAsciiStringCaseInsensitively((RMascii*) argv[i+1], ".ssa", &found_pos) >= 0)
					 && ((argv[i+1] + RMasciiLength((RMascii*) argv[i+1])) ==  (found_pos + 4))) {
					playback_options->text_subs.entry[playback_options->text_subs.count].type = RMFPTextSubs_SSA;
					type = "SSA";
				}
				else if ((RMFindAsciiStringCaseInsensitively((RMascii*) argv[i+1], ".ass", &found_pos) >= 0)
					 && ((argv[i+1] + RMasciiLength((RMascii*) argv[i+1])) ==  (found_pos + 4))) {
					playback_options->text_subs.entry[playback_options->text_subs.count].type = RMFPTextSubs_ASS;
					type = "ASS";
				}
				else if ((RMFindAsciiStringCaseInsensitively((RMascii*) argv[i+1], ".sub", &found_pos) >= 0)
					 && ((argv[i+1] + RMasciiLength((RMascii*) argv[i+1])) ==  (found_pos + 4))) {
					playback_options->text_subs.entry[playback_options->text_subs.count].type = RMFPTextSubs_SUB;
					type = "SUB";

					/* We need the frame rate too */
					if (argc > i + 3)
					{
						playback_options->text_subs.entry[playback_options->text_subs.count].framerate_numerator = strtol(argv[i+2], NULL, 10);
						playback_options->text_subs.entry[playback_options->text_subs.count].framerate_denominator = strtol(argv[i+3], NULL, 10);
						if (	!playback_options->text_subs.entry[playback_options->text_subs.count].framerate_numerator
						||	!playback_options->text_subs.entry[playback_options->text_subs.count].framerate_denominator)
						{
							printf ("Invalid frame rate for SUB file\n");
							bad_option_parameters = TRUE;
						}
						else
						{
							printf ("SUB subtitles file framerate is %lu/%lu\n",
								playback_options->text_subs.entry[playback_options->text_subs.count].framerate_numerator,
								playback_options->text_subs.entry[playback_options->text_subs.count].framerate_denominator);
						}

					}
					else
					{
						printf ("Invalid frame rate for SUB file\n");
						bad_option_parameters = TRUE;
					}
				}
				else if ((RMFindAsciiStringCaseInsensitively((RMascii*) argv[i+1], ".smi", &found_pos) >= 0)
					 && ((argv[i+1] + RMasciiLength((RMascii*) argv[i+1])) ==  (found_pos + 4))) {
					playback_options->text_subs.entry[playback_options->text_subs.count].type = RMFPTextSubs_SMI;
					type = "SMI";
				}
				else
				{
					type = "???";
					printf ("Invalid text subtitles extension\n");
					bad_option_parameters = TRUE;
				}

				if (!bad_option_parameters)
				{

					printf ("Detected [%s] text subtitles\n", type);

					/* Try to open file */
					playback_options->text_subs.entry[playback_options->text_subs.count].file_handle = RMOpenFile((const RMnonAscii*)argv[i+1], RM_FILE_OPEN_READ);

					if (playback_options->text_subs.entry[playback_options->text_subs.count].file_handle == NULL)
					{
						printf ("Unable to open subtitles file [%s]\n",argv[i+1]);
						bad_option_parameters = TRUE;
					}
					else
					{
						RMint32 cnt;

						/* Store its name */
						for (cnt=RMasciiLength((RMascii*) argv[i+1]); cnt>=0; cnt--)
						{
							if (argv[i+1][cnt] == '/')
								break;
						}
						RMNCopyAscii( playback_options->text_subs.entry[playback_options->text_subs.count].description,
									(RMascii*) (argv[i+1] + cnt + 1), RMFP_MAX_DESCRIPTION_SIZE);

						i+=2;
						if (playback_options->text_subs.entry[playback_options->text_subs.count].type == RMFPTextSubs_SUB)
							i+=2;
						if ((playback_options->text_subs.entry[playback_options->text_subs.count].type == RMFPTextSubs_ASCII)
							|| (playback_options->text_subs.entry[playback_options->text_subs.count].type == RMFPTextSubs_UTF8))
							i+=1;

						playback_options->text_subs.count++;
					}
				}
			}
			else
				bad_option_parameters = TRUE;
		}
	}
	else if (RMCompareAscii(argv[i], "-truecolor_subs")) {
		playback_options->truecolor_subs = TRUE;
		i++;
	}
	else if (RMCompareAscii(argv[i], "-yuv_palette_subs")) {
		playback_options->yuv_palette_subs = TRUE;
		i++;
	}
	else if (RMCompareAscii(argv[i], "-no_prerendered_subs")) {
		playback_options->no_prerendered_subs = TRUE;
		i++;
	}
#if (EM86XX_CHIP >= EM86XX_CHIPID_TANGO3)
	else if (RMCompareAscii(argv[i], "-disable_ssa_anim")) {
		playback_options->disable_ssa_animations = TRUE;
		i++;
	}
#endif
	else if (RMCompareAscii(argv[i], "-subidx")) {
		if (argc > i+3) {
			/* Open SUB file */
			playback_options->subidx_sub_file_handle = RMOpenFile((const RMnonAscii*)argv[i+1], RM_FILE_OPEN_READ);
			if (playback_options->subidx_sub_file_handle == NULL)
			{
				printf ("Unable to open subid SUB file [%s]\n",argv[i+1]);
				bad_option_parameters = TRUE;
			}
			else
			{
				/* Open IDX file */
				playback_options->subidx_idx_file_handle = RMOpenFile((const RMnonAscii*)argv[i+2], RM_FILE_OPEN_READ);
				if (playback_options->subidx_idx_file_handle == NULL)
				{
					printf ("Unable to open subid IDX file [%s]\n",argv[i+2]);
					bad_option_parameters = TRUE;
				}
				else
				{
					/* Get index */
					playback_options->subidx_index = strtol(argv[i+3], NULL, 10);
					i+=4;
				}
			}
		}
		else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-waitexit")) {
		playback_options->WaitExit = TRUE;
		i++;
	}
	else if (RMCompareAscii(argv[i], "-extern_alloc")) {
		pTestRMFPPlayback_options->test_external_resources_allocation = TRUE;
		i++;
	}
	else if (RMCompareAscii(argv[i], "-dmapool_ruamem")) {
		pTestRMFPPlayback_options->dmapool_in_rua_mem = TRUE;
		i++;
	}
	else if (RMCompareAscii(argv[i], "-default_font"))
	{
		if (argc > i + 1)
		{
			/* Try to open file */
			if (pTestRMFPPlayback_options->fonts.default_font_file_handle != NULL)
			{
				printf ("Default font file already opened\n");
				bad_option_parameters = TRUE;
			}
			else
			{

				pTestRMFPPlayback_options->fonts.default_font_file_handle = RMOpenFile((const RMnonAscii*)argv[i+1], RM_FILE_OPEN_READ);

				if (pTestRMFPPlayback_options->fonts.default_font_file_handle == NULL)
				{
					printf ("Unable to open default font file [%s] for reading\n",argv[i+1]);
					bad_option_parameters = TRUE;
				}
				else
					i+=2;
			}
		} else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-cc_font"))
	{
		if (argc > i + 1)
		{
			/* Try to open file */
			if (pTestRMFPPlayback_options->fonts.cc_font_file_handle != NULL)
			{
				printf ("CloseCaption font file already opened\n");
				bad_option_parameters = TRUE;
			}
			else
			{

				pTestRMFPPlayback_options->fonts.cc_font_file_handle = RMOpenFile((const RMnonAscii*)argv[i+1], RM_FILE_OPEN_READ);

				if (pTestRMFPPlayback_options->fonts.cc_font_file_handle == NULL)
				{
					printf ("Unable to open CloseCaption font file [%s] for reading\n",argv[i+1]);
					bad_option_parameters = TRUE;
				}
				else
					i+=2;
			}
		} else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-forced_font"))
	{
		if (argc > i + 1)
		{
			/* Try to open file */
			if (pTestRMFPPlayback_options->fonts.forced_font_file_handle != NULL)
			{
				printf ("Forced font file already opened\n");
				bad_option_parameters = TRUE;
			}
			else
			{

				pTestRMFPPlayback_options->fonts.forced_font_file_handle = RMOpenFile((const RMnonAscii*)argv[i+1], RM_FILE_OPEN_READ);

				if (pTestRMFPPlayback_options->fonts.forced_font_file_handle == NULL)
				{
					printf ("Unable to open forced font file [%s] for reading\n",argv[i+1]);
					bad_option_parameters = TRUE;
				}
				else
					i+=2;
			}
		} else
			bad_option_parameters = TRUE;
	}
	else if ( RMCompareAscii(argv[i], "-font")) {
		if (argc > i+1) {
			if (pTestRMFPPlayback_options->fonts.nb_additional_fonts >= TEST_RMFP_MAX_ADDITIONAL_FONTS) {
				printf ("No more fonts allowed\n");
				bad_option_parameters = TRUE;
			}
			else {
				pTestRMFPPlayback_options->fonts.additional_font_file_handle[pTestRMFPPlayback_options->fonts.nb_additional_fonts] = RMOpenFile((const RMnonAscii*)argv[i+1], RM_FILE_OPEN_READ);

				if (pTestRMFPPlayback_options->fonts.additional_font_file_handle[pTestRMFPPlayback_options->fonts.nb_additional_fonts] == NULL) {
					printf ("Unable to open additional font file [%s] for reading\n",argv[i+1]);
					bad_option_parameters = TRUE;
				}
				else {
					i+=2;
					pTestRMFPPlayback_options->fonts.nb_additional_fonts++;
				}
			}
		}
		else
			bad_option_parameters = TRUE;
	}
	else if ( RMCompareAscii(argv[i], "-noterm")) {
		i++;
		pTestRMFPPlayback_options->UseTerminal = FALSE;
	}
	else if ( RMCompareAscii(argv[i], "-watermark")) {
		i++;
		playback_options->watermark = TRUE;
	}
	else if ( RMCompareAscii(argv[i], "-orientation")) {

		if (argc > i+1) {
			if(RMCompareAscii(argv[i+1], "0")){
				playback_options->PTOrientation = EMhwlibPictureOrientation_0;
			}
			else if(RMCompareAscii(argv[i+1], "90")){
				playback_options->PTOrientation = EMhwlibPictureOrientation_90;
			}
			else if(RMCompareAscii(argv[i+1], "180")){
				playback_options->PTOrientation = EMhwlibPictureOrientation_180;
			}
			else if(RMCompareAscii(argv[i+1], "270")){
				playback_options->PTOrientation = EMhwlibPictureOrientation_270;
			}
			else if(RMCompareAscii(argv[i+1], "hflip")){
				playback_options->PTOrientation = EMhwlibPictureOrientation_HFlip;
			}
			else if(RMCompareAscii(argv[i+1], "vflip")){
				playback_options->PTOrientation = EMhwlibPictureOrientation_VFlip;
			}
			else if(RMCompareAscii(argv[i+1], "bld")){
				playback_options->PTOrientation = EMhwlibPictureOrientation_BLDiagonalFlip;
			}
			else if(RMCompareAscii(argv[i+1], "tld")){
				playback_options->PTOrientation = EMhwlibPictureOrientation_TLDiagonalFlip;
			}
			else {
				bad_option_parameters = TRUE;
			}

			if (!bad_option_parameters) {
				playback_options->PTEnable = TRUE;

				i += 2;

				if (i < argc) {
					if ( RMCompareAscii(argv[i], "-inplace")) {
						i++;
						playback_options->PTInPlace = TRUE;
						RMDBGLOG((ENABLE, "doing in place rotation\n"));
					}
				}
			}
		}
		else
			bad_option_parameters = TRUE;
	}
	else if ( (RMCompareAscii(argv[i], "-font_from_file")) ) {
		RMuint32 dummy;
		if (argc > i+1) {
			dummy = strtol(argv[i+1], NULL, 10);
			i+=2;

			if (!dummy)
				pTestRMFPPlayback_options->open_font_from_file = FALSE;
			else
				pTestRMFPPlayback_options->open_font_from_file = TRUE;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if ( (RMCompareAscii(argv[i], "-rmfp_in_a_thread")) ) {
		RMuint32 dummy;
		if (argc > i+1) {
			dummy = strtol(argv[i+1], NULL, 10);
			i+=2;

			if (!dummy)
				pTestRMFPPlayback_options->rmfp_in_a_thread = FALSE;
			else
				pTestRMFPPlayback_options->rmfp_in_a_thread = TRUE;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if ( (RMCompareAscii(argv[i], "-special_keys")) ) {
		pTestRMFPPlayback_options->allow_special_keys = TRUE;
		i++;
	}
	else if ( (RMCompareAscii(argv[i], "-file_is_not_closed")) ) {
		//playback_options->IgnoreEOS = TRUE;
		pTestRMFPPlayback_options->file_is_not_closed = TRUE;
		i++;
	}
	else if ( RMCompareAscii(argv[i], "-reindex_mkv")) {
		RMuint32 dummy;
		if (argc > i+1) {
			dummy = strtol(argv[i+1], NULL, 10);
			i += 2;

			if (!dummy)
				playback_options->ReindexMKV = FALSE;
			else
				playback_options->ReindexMKV = TRUE;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if ( RMCompareAscii(argv[i], "-cache_mp4_index")) {
		RMuint32 dummy;
		if (argc > i+1) {
			dummy = strtol(argv[i+1], NULL, 10);
			i += 2;

			if (!dummy)
				playback_options->cacheMP4Indexes = FALSE;
			else
				playback_options->cacheMP4Indexes = TRUE;
		}
		else
			bad_option_parameters = TRUE;
	} else if (RMCompareAscii(argv[i], "-read_timeout")) {
		if (argc > i+1) {
			playback_options->read_timeout	= strtol(argv[i+1], NULL, 10);

			i += 2;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-force_linear_interleaving")) {
		RMuint32 dummy;
		if (argc > i+1) {
			dummy = strtol(argv[i+1], NULL, 10);
			i += 2;

			if (!dummy)
				playback_options->force_linear_interleaving = FALSE;
			else
				playback_options->force_linear_interleaving = TRUE;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-use_unseekable_file")) {
		RMuint32 dummy;
		if (argc > i+1) {
			dummy = strtol(argv[i+1], NULL, 10);
			i += 2;

			if (!dummy)
				playback_options->unseekable_file = FALSE;
			else
				playback_options->unseekable_file = TRUE;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-hls_key_url_options")) {
		if (argc > i+1) {
			playback_options->hls_key_url_options = argv[i+1];
			i += 2;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-hls_key_encoding")) {
		if (argc > i+3) {
			if (RMCompareAscii(argv[i+1], "none")) {
				playback_options->hls_key_encoding = RMFPHLSKeyEncoding_NONE;
			}
			else if (RMCompareAscii(argv[i+1], "aes-128-cbc")) {
				playback_options->hls_key_encoding = RMFPHLSKeyEncoding_AES_128_CBC;
			}
			else {
				bad_option_parameters = TRUE;
			}

			if (!bad_option_parameters) {
				playback_options->hls_key_key = argv[i+2];
				playback_options->hls_key_iv = argv[i+3];

				i += 4;

				if (i < argc) {
					if (RMCompareAscii(argv[i], "-base64")) {
						playback_options->hls_base64_key = TRUE;
						i++;
					}
				}
			}
		}
		else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-hls_type")) {
		if (argc > i+1) {
			if (RMCompareAscii(argv[i+1], "VOD")) {
				playback_options->hls_type = RMFPHLSType_VOD;
			}
			else if (RMCompareAscii(argv[i+1], "EVENT")) {
				playback_options->hls_type = RMFPHLSType_EVENT;
			}
			else if (RMCompareAscii(argv[i+1], "SLIDINGWINDOW")) {
				playback_options->hls_type = RMFPHLSType_SLIDINGWINDOW;
			}
			else {
				bad_option_parameters = TRUE;
			}

			if (!bad_option_parameters) {
				i+=2;
			}
		}
		else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-hls_thread_cache_memory")) {
		if (argc > i+1) {
			playback_options->hls_thread_cache_memory = strtol(argv[i+1], NULL, 10)*1024;

			i+=2;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-hls_autoswitch_window")) {
		if (argc > i+2) {
			playback_options->hls_up_window_percentage = strtol(argv[i+1], NULL, 10);
			playback_options->hls_down_window_percentage = strtol(argv[i+2], NULL, 10);
			playback_options->hls_autoswitch_set_window = TRUE;

			i+=3;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-rebuf")) {
		if (argc > i+1) {
			if (RMCompareAscii(argv[i+1], "fifo")) {
				playback_options->rebuffering_type = RMFPRebufferingMode_FIFO_FULLNESS;
			}
			else if (RMCompareAscii(argv[i+1], "time")) {
				playback_options->rebuffering_type = RMFPRebufferingMode_BUFFER_DURATION;
			}
			else if (RMCompareAscii(argv[i+1], "off")) {
				playback_options->rebuffering_type = RMFPRebufferingMode_DISABLED;
			} else {
				bad_option_parameters = TRUE;
			}

			if (!bad_option_parameters)
				i += 2;
		}
		else
			bad_option_parameters = TRUE;
	} else if (RMCompareAscii(argv[i], "-rebuf_fifo")) {
		if (argc > i+4) {
			playback_options->rebuf_vhigh	= strtol(argv[i+1], NULL, 10);
			playback_options->rebuf_vlow	= strtol(argv[i+2], NULL, 10);
			playback_options->rebuf_ahigh	= strtol(argv[i+3], NULL, 10);
			playback_options->rebuf_alow	= strtol(argv[i+4], NULL, 10);

			i += 5;
		}
		else
			bad_option_parameters = TRUE;
	} else if (RMCompareAscii(argv[i], "-rebuf_time")) {
		if (argc > i+5) {
			playback_options->rebuf_vhigh	= strtol(argv[i+1], NULL, 10);
			playback_options->rebuf_vlow	= strtol(argv[i+2], NULL, 10);
			playback_options->rebuf_ahigh	= strtol(argv[i+3], NULL, 10);
			playback_options->rebuf_alow	= strtol(argv[i+4], NULL, 10);
			playback_options->rebuf_fullness= strtol(argv[i+5], NULL, 10);

			i += 6;
		}
		else
			bad_option_parameters = TRUE;
	} else if (RMCompareAscii(argv[i], "-rebuf_timeout")) {
		if (argc > i+1) {
			playback_options->rebuf_timeout	= strtol(argv[i+1], NULL, 10);

			i += 2;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-lidx")) {
		RMuint32 dummy;
		if (argc > i+1) {
			dummy = strtol(argv[i+1], NULL, 10);
			i += 2;

			if (!dummy)
				playback_options->liteindex_enable = FALSE;
			else
				playback_options->liteindex_enable = TRUE;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-lidx_kickstart")) {
		if (argc > i+1) {
			playback_options->liteindex_kickstart	= strtol(argv[i+1], NULL, 10);

			i += 2;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-lidx_trickfactor")) {
		if (argc > i+1) {
			playback_options->liteindex_trickfactor	= strtol(argv[i+1], NULL, 10);

			i += 2;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-seek"))  {
		if (argc > i+3) {
			RMasciiAutoToUint32(argv[i+1], (RMuint32*) &playback_options->start_offset_type);
			RMasciiToUInt8(argv[i+2], &playback_options->start_offset_use_accurate_seek);


			switch (playback_options->start_offset_type) {
				case RMFPStartOffset_time_ms:
					RMasciiAutoToUint32(argv[i+3], &playback_options->start_offset.time);
					break;

				default:
					RMNOTIFY((NULL, RM_ERROR, "Unknown initial seek type\n"));
					return RM_ERROR;
			}

			i += 4;
		}
		else
			bad_option_parameters = TRUE;
	}
	else {
		/* Parameter not found ! */
		return RM_PENDING;
	}

	/* Check if it failed */
	if (bad_option_parameters == TRUE) {
		return RM_ERROR;
	}
	else {
		*index = i;
		return RM_OK;
	}
}

/**************************************************************************************************/

static RMstatus parse_demux_cmdline(RMuint32 argc, RMascii **argv, RMuint32 *index, struct RMFPDemuxOptions *demux_options)
{
	RMuint32 tmp_index;
	RMbool bad_option_parameters = FALSE;

	tmp_index = *index;

	/*
	 * Parse all options
	 */
	if ( RMCompareAscii(argv[tmp_index], "-y"))
	{
		if (argc > tmp_index+1)
		{
			if (RMCompareAscii(argv[tmp_index+1], "mpeg1"))
				demux_options->system_type = RM_SYSTEM_MPEG1;
			else if (RMCompareAscii(argv[tmp_index+1], "dvd"))
				demux_options->system_type = RM_SYSTEM_MPEG2_DVD;
			else if (RMCompareAscii(argv[tmp_index+1], "aob"))
				demux_options->system_type = RM_SYSTEM_MPEG2_DVD_AUDIO;
			else if (RMCompareAscii(argv[tmp_index+1], "m2t192"))
				demux_options->system_type = RM_SYSTEM_MPEG2_TRANSPORT_192;
			else if (RMCompareAscii(argv[tmp_index+1], "m2t"))
				demux_options->system_type = RM_SYSTEM_MPEG2_TRANSPORT;
			else if (RMCompareAscii(argv[tmp_index+1], "m2p"))
				demux_options->system_type = RM_SYSTEM_MPEG2_PROGRAM;
			else
				bad_option_parameters = TRUE;

			/* increment index */
			tmp_index += 2;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if ( RMCompareAscii(argv[tmp_index], "-z"))
	{
		if (argc > tmp_index+1)
		{
			RMuint32 enable;
			RMasciiAutoToUint32(argv[tmp_index+1], &(enable));
			if (enable == 0)
				demux_options->repack_sample = FALSE;
			else
				demux_options->repack_sample = TRUE;
			tmp_index+=2;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if ( RMCompareAscii(argv[tmp_index], "-vpid"))
	{
		if (argc > tmp_index+1)
		{
			RMasciiAutoToUint32(argv[tmp_index+1], &(demux_options->video_pid));
			tmp_index+=2;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if ( RMCompareAscii(argv[tmp_index], "-apid"))
	{
		if (argc > tmp_index+1)
		{
			RMasciiAutoToUint32(argv[tmp_index+1], &(demux_options->audio_pid));
			tmp_index+=2;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if ( RMCompareAscii(argv[tmp_index], "-spid"))
	{
		if (argc > tmp_index+1)
		{
			RMasciiAutoToUint32(argv[tmp_index+1], &(demux_options->spu_pid));
			tmp_index+=2;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if ( RMCompareAscii(argv[tmp_index], "-asubid"))
	{
		if (argc > tmp_index+1)
		{
			RMasciiAutoToUint32(argv[tmp_index+1], &(demux_options->audio_subid));
			tmp_index+=2;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if ( RMCompareAscii(argv[tmp_index], "-ssubid"))
	{
		if (argc > tmp_index+1)
		{
			RMasciiAutoToUint32(argv[tmp_index+1], &(demux_options->spu_subid));
			tmp_index+=2;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if ( RMCompareAscii(argv[tmp_index], "-ttxpid"))
	{
		if (argc > tmp_index+1)
		{
			RMasciiAutoToUint32(argv[tmp_index+1], &(demux_options->ttx_pid));
			tmp_index+=2;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if ( RMCompareAscii(argv[tmp_index], "-ttx"))
	{
		if (argc > tmp_index+1) {
			if(RMCompareAscii(argv[tmp_index+1], "tv")) {
				demux_options->TeletextMode = RMFPTeletextMode_SendToTV;
			}
			else if(RMCompareAscii(argv[tmp_index+1], "soft")) {

				demux_options->TeletextMode = RMFPTeletextMode_ShowInOSD;
			}
			else if(RMCompareAscii(argv[tmp_index+1], "off")) {
				demux_options->TeletextMode = RMFPTeletextMode_Disabled;
			}
			else
				bad_option_parameters = TRUE;

			tmp_index += 2;
		}
		else
			bad_option_parameters = TRUE;

	}
	else if ( RMCompareAscii(argv[tmp_index], "-de"))
	{
		if (argc > tmp_index+1)
		{
			RMuint32 engine_id;

			RMasciiAutoToUint32(argv[tmp_index+1], &engine_id);

			if (engine_id >= MAX_DEMUX_ENGINES) {
				fprintf(NORMALMSG,"Invalid demux engine %ld (should be in [%d, %d])\n", engine_id, 0, MAX_DEMUX_ENGINES-1);
				bad_option_parameters = TRUE;
			}
			else {
				demux_options->engine_id = engine_id;
				tmp_index+=2;
			}
		}
		else
			bad_option_parameters = TRUE;
	}
	else if ( RMCompareAscii(argv[tmp_index], "-task"))
	{
		if (argc > tmp_index+1)
		{
			RMuint32 task_id;

			RMasciiAutoToUint32(argv[tmp_index+1], &task_id);

			if (task_id >= MAX_DEMUX_TASK_COUNT) {
				fprintf(NORMALMSG,"Invalid demux task %ld (should be in [%d, %d])\n", task_id, 0, MAX_DEMUX_TASK_COUNT-1);
				bad_option_parameters = TRUE;
			}
			else {
				demux_options->task_id = task_id;
				tmp_index+=2;
			}
		}
		else
			bad_option_parameters = TRUE;
	}
	else if ( RMCompareAscii(argv[tmp_index], "-tsskip"))
	{
		if (argc > tmp_index+1)
		{
			RMasciiAutoToUint32(argv[tmp_index+1], &(demux_options->ts_skip));
			tmp_index+=2;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if ( RMCompareAscii(argv[tmp_index], "-rpid"))
	{
		if (argc > tmp_index+1)
		{
			RMasciiAutoToUint32(argv[tmp_index+1], &(demux_options->pcr_pid));
			tmp_index+=2;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if ( RMCompareAscii(argv[tmp_index], "-spi"))
	{
		demux_options->spi = TRUE;
		demux_options->serial_spi = FALSE;

		if (argc > tmp_index+1)
		{
			RMasciiAutoToUint32(argv[tmp_index+1], &(demux_options->input_port));

			if ( (demux_options->input_port == 0) || (demux_options->input_port == 1) )
			{
				/* for SPI the hardware input port are 0 and 2 */
				demux_options->input_port *= 2;
				tmp_index+=2;
			}
			else
				bad_option_parameters = TRUE;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if ( RMCompareAscii(argv[tmp_index], "-ssi"))
	{
		demux_options->spi = TRUE;
		demux_options->serial_spi = TRUE;

		if (argc > tmp_index+1)
		{
			RMasciiAutoToUint32(argv[tmp_index+1], &(demux_options->input_port));

			if (demux_options->input_port <= 2)
			{
				/* for SSI the hardware input port are 0, 1 and 2 */
				tmp_index+=2;
			}
			else
				bad_option_parameters = TRUE;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if ( RMCompareAscii(argv[tmp_index], "-idleport"))
	{
		if (argc > tmp_index+1)
		{
			RMasciiAutoToUint32(argv[tmp_index+1], &(demux_options->idle_port));
			tmp_index+=2;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if ( RMCompareAscii(argv[tmp_index], "-input_protocol"))
	{
		if (argc > tmp_index+1)
		{
			RMasciiAutoToUint32(argv[tmp_index+1], &(demux_options->idle_port));
			if (demux_options->idle_port > 2)
				bad_option_parameters = TRUE;
			else
				tmp_index+=2;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if ( RMCompareAscii(argv[tmp_index], "-ignore_pat"))
	{
		demux_options->ignore_pat = TRUE;
		tmp_index+=1;
	}
	else if ( RMCompareAscii(argv[tmp_index], "-pmt_index"))
	{
		if (argc > tmp_index+1)
		{
			RMasciiAutoToUint32(argv[tmp_index+1], &(demux_options->pmt_index));
			tmp_index+=2;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if ( RMCompareAscii(argv[tmp_index], "-pmt_pid"))
	{
		if (argc > tmp_index+1)
		{
			RMasciiAutoToUint32(argv[tmp_index+1], &(demux_options->pmt_pid));
			tmp_index+=2;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if ( RMCompareAscii(argv[tmp_index], "-synclock"))
	{
		if (argc > tmp_index+1)
		{
			RMasciiAutoToUint32(argv[tmp_index+1], &(demux_options->sync_lock));
			tmp_index+=2;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if ( RMCompareAscii(argv[tmp_index], "-pcrdisc"))
	{
		if (argc > tmp_index+1)
		{
			RMasciiAutoToUint32(argv[tmp_index+1], &(demux_options->pcr_disc));
			tmp_index+=2;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if ( RMCompareAscii(argv[tmp_index], "-audiotspriority"))
	{
		if (argc > tmp_index+1)
		{
			RMuint32 tmp;
			RMasciiAutoToUint32(argv[tmp_index+1], &tmp);
			demux_options->audio_ts_priority = (enum EMhwlibTransportPriority_type) tmp;
			tmp_index+=2;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if ( RMCompareAscii(argv[tmp_index], "-send_scrambled"))
	{
		if (demux_options->pes_pid_entry_input_type)
			bad_option_parameters = TRUE;
		else
		{
			demux_options->pes_pid_entry_input_type = 1;
			tmp_index++;
		}
	}
	else if ( RMCompareAscii(argv[tmp_index], "-ignore_subid"))
	{
		if (demux_options->pes_pid_entry_input_type)
			bad_option_parameters = TRUE;
		else
		{
			demux_options->pes_pid_entry_input_type = 2;
			tmp_index++;
		}
	}
	else if ( RMCompareAscii(argv[tmp_index], "-waitpcr"))
	{
		if (argc > tmp_index+2)
		{
			RMasciiAutoToUint32(argv[tmp_index+1], &(demux_options->wait_for_pcr_time_ms));
			RMasciiAutoToUint32(argv[tmp_index+2], &(demux_options->pts_taken_as_pcr_offset_ms));
			tmp_index+=3;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if ( RMCompareAscii(argv[tmp_index], "-mmc"))
	{
		demux_options->mpeg_multichannel = TRUE;
		tmp_index++;
	}
	else if ( RMCompareAscii(argv[tmp_index], "-dfifo"))
	{
		if (argc > tmp_index+1)
		{
			RMasciiAutoToUint32(argv[tmp_index+1], &(demux_options->fifo_size));
			demux_options->fifo_size *= 1024;
			tmp_index += 2;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[tmp_index], "-dxfer"))
	{
		if (argc > tmp_index+1)
		{
			RMasciiAutoToUint32(argv[tmp_index+1], &(demux_options->xfer_count));
			tmp_index += 2;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if ( RMCompareAscii(argv[tmp_index], "-allpat"))
	{
		demux_options->section_filter_based_on_new_version &= ~1;
		tmp_index++;
	}
	else if ( RMCompareAscii(argv[tmp_index], "-allpmt"))
	{
		demux_options->section_filter_based_on_new_version &= ~2;
		tmp_index++;
	}
	else if (RMCompareAscii(argv[tmp_index], "-savem"))
	{
		if (argc > tmp_index + 1)
		{

			/* Try to open file */
			if (demux_options->multicast_dump_file_handle != NULL)
			{
				printf ("Multicast dump file already opened\n");
				bad_option_parameters = TRUE;
			}
			else
			{

				demux_options->multicast_dump_file_handle = RMOpenFile((const RMnonAscii*)argv[tmp_index+1], RM_FILE_OPEN_WRITE);

				if (demux_options->multicast_dump_file_handle == NULL)
				{
					printf ("Unable to open multicast fump file [%s] for writting\n",argv[tmp_index+1]);
					bad_option_parameters = TRUE;
				}
				else
					tmp_index+=2;
			}
		} else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[tmp_index], "-saved") || RMCompareAscii(argv[tmp_index], "-saved192"))
	{
		if (argc > tmp_index + 1)
		{

			/* Try to open file */
			if (demux_options->tsdump_file_handle != NULL)
			{
				printf ("Demux dump file already opened\n");
				bad_option_parameters = TRUE;
			}
			else
			{
				demux_options->tsdump_file_handle = RMOpenFile((const RMnonAscii*)argv[tmp_index+1], RM_FILE_OPEN_WRITE);

				if (demux_options->tsdump_file_handle == NULL)
				{
					printf ("Unable to open demux file [%s] for writting\n",argv[tmp_index+1]);
					bad_option_parameters = TRUE;
				}
				else
				{
					if (RMCompareAscii(argv[tmp_index], "-saved192"))
						demux_options->tsdump_is_192 = TRUE;

					tmp_index+=2;
				}
			}
		} else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[tmp_index], "-savedi") || RMCompareAscii(argv[tmp_index], "-savedi192"))
	{
		if (argc > tmp_index + 2)
		{

			/* Try to open file */
			if ((demux_options->tsdump_file_handle != NULL) || (demux_options->tsdump_file_handle != NULL))
			{
				printf ("Demux dump or index file already opened\n");
				bad_option_parameters = TRUE;
			}
			else
			{

				demux_options->tsdump_file_handle = RMOpenFile((const RMnonAscii*)argv[tmp_index+1], RM_FILE_OPEN_WRITE);

				if (demux_options->tsdump_file_handle == NULL)
				{
					printf ("Unable to open demux file [%s] for writting\n",argv[tmp_index+1]);
					bad_option_parameters = TRUE;
				}
				else
				{

					demux_options->tsdump_index_file_handle = RMOpenFile((const RMnonAscii*)argv[tmp_index+2], RM_FILE_OPEN_WRITE);

					if (demux_options->tsdump_index_file_handle == NULL)
					{
						printf ("Unable to open index file [%s] for writting\n",argv[tmp_index+1]);
						bad_option_parameters = TRUE;
					}
					else
					{
						if (RMCompareAscii(argv[tmp_index], "-savedi192"))
							demux_options->tsdump_is_192 = TRUE;

						tmp_index+=3;
					}
				}
			}
		} else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[tmp_index], "-savepat"))
	{
		if (argc > tmp_index + 1)
		{

			/* Try to open file */
			if (demux_options->save_pat_file_handle != NULL)
			{
				printf ("PAT recording file already opened\n");
				bad_option_parameters = TRUE;
			}
			else
			{

				demux_options->save_pat_file_handle = RMOpenFile((const RMnonAscii*)argv[tmp_index+1], RM_FILE_OPEN_WRITE);

				if (demux_options->save_pat_file_handle == NULL)
				{
					printf ("Unable to open PAT file [%s] for writting\n",argv[tmp_index+1]);
					bad_option_parameters = TRUE;
				}
				else
					tmp_index+=2;
			}
		} else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[tmp_index], "-savepmt"))
	{
		if (argc > tmp_index + 1)
		{

			/* Try to open file */
			if (demux_options->save_pmt_file_handle != NULL)
			{
				printf ("PMT recording file already opened\n");
				bad_option_parameters = TRUE;
			}
			else
			{

				demux_options->save_pmt_file_handle = RMOpenFile((const RMnonAscii*)argv[tmp_index+1], RM_FILE_OPEN_WRITE);

				if (demux_options->save_pmt_file_handle == NULL)
				{
					printf ("Unable to open PMT file [%s] for writting\n",argv[tmp_index+1]);
					bad_option_parameters = TRUE;
				}
				else
					tmp_index+=2;
			}
		} else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[tmp_index], "-savep"))
	{
		if (argc > tmp_index + 2)
		{
			/* Try to open file */
			if (demux_options->save_custom_pid_file_handle != NULL)
			{
				printf ("Custom PID recording file already opened\n");
				bad_option_parameters = TRUE;
			}
			else
			{
				demux_options->save_custom_pid_file_handle = RMOpenFile((const RMnonAscii*)argv[tmp_index+1], RM_FILE_OPEN_WRITE);
				RMasciiAutoToUint32(argv[tmp_index+2], &(demux_options->custom_pid));

				if (demux_options->save_custom_pid_file_handle == NULL)
				{
					printf ("Unable to open custom file [%s] for writting\n",argv[tmp_index+1]);
					bad_option_parameters = TRUE;
				}
				else
					tmp_index+=3;
			}
		} else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[tmp_index], "-savei"))
	{
		if (argc > tmp_index + 1)
		{

			/* Try to open file */
			if (demux_options->save_input_file_handle != NULL)
			{
				printf ("Input record file already opened\n");
				bad_option_parameters = TRUE;
			}
			else
			{

				demux_options->save_input_file_handle = RMOpenFile((const RMnonAscii*)argv[tmp_index+1], RM_FILE_OPEN_WRITE);

				if (demux_options->save_input_file_handle == NULL)
				{
					printf ("Unable to open Input record file [%s] for writting\n",argv[tmp_index+1]);
					bad_option_parameters = TRUE;
				}
				else
					tmp_index+=2;
			}
		} else
			bad_option_parameters = TRUE;
	}
	else if ( RMCompareAscii(argv[tmp_index], "-index"))
	{
		if (argc > tmp_index+1)
		{
			if (demux_options->index_file_handle)
			{
				printf ("Index to use already selected\n");
				bad_option_parameters = TRUE;
			}
			else
			{
				demux_options->index_file_handle = RMOpenFile((const RMnonAscii*)argv[tmp_index+1],RM_FILE_OPEN_READ);

				if (demux_options->index_file_handle == NULL)
				{
					printf ("Unable to open index file [%s]\n",argv[tmp_index+1]);
					bad_option_parameters = TRUE;
				}
				else
					tmp_index+=2;
			}
		}
		else
			bad_option_parameters = TRUE;
	}
	else if ( RMCompareAscii(argv[tmp_index], "-createindex"))
	{
		if (argc > tmp_index+1)
		{
			if (demux_options->index2create_file_handle)
			{
				printf ("Index to create already selected\n");
				bad_option_parameters = TRUE;
			}
			else
			{
				demux_options->index2create_file_handle = RMOpenFile((const RMnonAscii*)argv[tmp_index+1],RM_FILE_OPEN_WRITE);

				if (demux_options->index2create_file_handle == NULL)
				{
					printf ("Unable to open index to create file [%s]\n",argv[tmp_index+1]);
					bad_option_parameters = TRUE;
				}
				else
					tmp_index +=2;
			}
		}
		else
			bad_option_parameters = TRUE;
	}
	else if ( RMCompareAscii(argv[tmp_index], "-indexotf"))
	{
		if (argc > tmp_index+1)
		{
			if (demux_options->index_file_handle || demux_options->index2create_file_handle)
			{
				printf ("Index 'On the Fly' mode cannot work with '-createindex' and/or '-index' options\n");
				bad_option_parameters = TRUE;
			}
			else
			{
				/* Create index */
				demux_options->index2create_file_handle = RMOpenFile((const RMnonAscii*)argv[tmp_index+1],RM_FILE_OPEN_WRITE);
				if (demux_options->index2create_file_handle == NULL)
				{
					printf ("Unable to open index to create file [%s]\n",argv[tmp_index+1]);
					bad_option_parameters = TRUE;
				}
				else
				{
					/* Open created index */
					demux_options->index_file_handle = RMOpenFile((const RMnonAscii*)argv[tmp_index+1],RM_FILE_OPEN_READ);
					if (demux_options->index_file_handle == NULL)
					{
						printf ("Unable to open index file [%s]\n",argv[tmp_index+1]);
						bad_option_parameters = TRUE;
					}
					else
						tmp_index+=2;
				}
			}
		}
		else
			bad_option_parameters = TRUE;
	}
	else if ( RMCompareAscii(argv[tmp_index], "-recoverindex"))
	{
		if (argc > tmp_index+1)
		{
			if (demux_options->index2create_file_name)
			{
				printf ("Index to create already selected\n");
				bad_option_parameters = TRUE;
			}
			else
			{
				demux_options->index2create_file_name = argv[tmp_index+1];
				demux_options->load_previous_index_entries = TRUE;
				tmp_index +=2;
			}
		}
		else
			bad_option_parameters = TRUE;
	}
	else if ( RMCompareAscii(argv[tmp_index], "-multicast") || RMCompareAscii(argv[tmp_index], "-unicast"))
	{
		RMbool MulticastRequested = RMCompareAscii(argv[tmp_index], "-multicast") ? TRUE : FALSE;

		if (argc > tmp_index+1)
		{
			if (demux_options->multicast.count >= RMFP_MAX_MULTICAST_STREAMS)
			{
				printf ("No more unicast/multicast entry allowed\n");
				bad_option_parameters = TRUE;
			}
			else
			{
				RMascii* port;

				port = RMSearchAscii(argv[tmp_index+1], (RMascii*) ":");

				if (port != NULL)\
				{
					RMuint32 address_size;

					address_size = (RMuint32) port - (RMuint32) argv[tmp_index+1];
					if (address_size >= 15)
					{
						printf ("Invalid IP\n");
						bad_option_parameters = TRUE;
					}
					else
					{
						RMuint32 length = RMasciiLength( argv[tmp_index+1] );
						RMascii* tokenized = RMMallocAscii( length );
						RMuint8 firstByte = 0;

						// Extract the first byte of the IP Address
						RMTokenizeAscii( argv[tmp_index+1], '.', tokenized, NULL );
						RMasciiToUInt8( tokenized, &firstByte );
						RMFreeAscii( tokenized );

						if (!MulticastRequested && ((firstByte >= 224) && (firstByte <= 239)) ) {
							printf ("Invalid Unicast Address\n");
							bad_option_parameters = TRUE;
						} else if (MulticastRequested && ((firstByte < 224) || (firstByte > 239)) ) {
							printf ("Invalid Multicast Address\n");
							bad_option_parameters = TRUE;
						}

						/* Copy IP address */
						RMMemcpy(	demux_options->multicast.address[demux_options->multicast.count],
								argv[tmp_index+1],
								address_size
							);

						/* Last char */
						demux_options->multicast.address[demux_options->multicast.count][address_size] = 0;

						/* Get port */
						RMasciiAutoToUint16(port+1, &demux_options->multicast.port[demux_options->multicast.count]);

						/* Increment count */
						demux_options->multicast.count++;

						tmp_index +=2;
					}
				}
				else
					bad_option_parameters = TRUE;
			}
		}
		else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[tmp_index], "-iterative_seek"))
	{
		RMuint32 dummy;
		if (argc > tmp_index+1) {
			RMasciiAutoToUint32(argv[tmp_index+1], &dummy);
			if (!dummy)
				demux_options->iterative_seek = FALSE;
			else
				demux_options->iterative_seek = TRUE;
			tmp_index+=2;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[tmp_index], "-searchvpes"))
	{
		demux_options->flags |= DEMUX_SEARCH_VIDEO_PES_HEADER_IN_VIDEO_PAYLOAD;
		tmp_index++;
	}
	else if (RMCompareAscii(argv[tmp_index], "-ignore_ts_cc"))
	{
		demux_options->flags |= DEMUX_IGNORE_TS_CONTINUITY_COUNTER;
		tmp_index++;
	}
	else if (RMCompareAscii(argv[tmp_index], "-start_offset"))
	{
		if (argc > tmp_index+1) {
			RMasciiAutoToUint64(argv[tmp_index+1], &demux_options->start_offset);
			tmp_index+=2;
		}
		else
			bad_option_parameters = TRUE;
	}
	else
		/* Parameter not found ! */
		return RM_PENDING;


	/* Check if it failed */
	if (bad_option_parameters == TRUE)
	{
		return RM_ERROR;
	}
	else
	{
		*index = tmp_index;
		return RM_OK;
	}
}

/**************************************************************************************************/

static RMstatus parse_display_cmdline(RMuint32 argc, RMascii **argv, RMuint32 *index, struct DisplayOptions *display_options)
{
	RMbool bad_option_parameters = FALSE;
	RMuint32 i;

	i= *index;

	if (RMCompareAscii(argv[i], "-zoom")) {
		if (argc > i+4) {
			RMuint32 x, y, w, h;
			RMasciiToInt32(argv[i+1], (RMint32*)&x);
			RMasciiToInt32(argv[i+2], (RMint32*)&y);
			RMasciiAutoToUint32(argv[i+3], &w);
			RMasciiAutoToUint32(argv[i+4], &h);
			display_options->source_window.X =      (x >= ZOOM_0) ? (x - ZOOM_0) : x;
			display_options->source_window.Y =      (y >= ZOOM_0) ? (y - ZOOM_0) : y;
			display_options->source_window.Width =  (w >= ZOOM_0) ? (w - ZOOM_0) : w;
			display_options->source_window.Height = (h >= ZOOM_0) ? (h - ZOOM_0) : h;
			display_options->source_window.XPositionMode = EMhwlibDisplayWindowPositionMode_FrontEdgeToBorder;
			display_options->source_window.YPositionMode = EMhwlibDisplayWindowPositionMode_FrontEdgeToBorder;
			display_options->source_window.XMode =      (x >= ZOOM_0) ? EMhwlibDisplayWindowValueMode_Relative : EMhwlibDisplayWindowValueMode_Fixed;
			display_options->source_window.YMode =      (y >= ZOOM_0) ? EMhwlibDisplayWindowValueMode_Relative : EMhwlibDisplayWindowValueMode_Fixed;
			display_options->source_window.WidthMode =  (w >= ZOOM_0) ? EMhwlibDisplayWindowValueMode_Relative : EMhwlibDisplayWindowValueMode_Fixed;
			display_options->source_window.HeightMode = (h >= ZOOM_0) ? EMhwlibDisplayWindowValueMode_Relative : EMhwlibDisplayWindowValueMode_Fixed;
			i += 5;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-window")) {
		if (argc > i+4) {
			RMasciiToInt32(argv[i+1], &(display_options->output_window.X));
			RMasciiToInt32(argv[i+2], &(display_options->output_window.Y));
			RMasciiAutoToUint32(argv[i+3], &(display_options->output_window.Width));
			RMasciiAutoToUint32(argv[i+4], &(display_options->output_window.Height));
			display_options->output_window.XPositionMode = EMhwlibDisplayWindowPositionMode_FrontEdgeToBorder;
			display_options->output_window.YPositionMode = EMhwlibDisplayWindowPositionMode_FrontEdgeToBorder;
			display_options->output_window.XMode = EMhwlibDisplayWindowValueMode_Fixed;
			display_options->output_window.YMode = EMhwlibDisplayWindowValueMode_Fixed;
			display_options->output_window.WidthMode = EMhwlibDisplayWindowValueMode_Fixed;
			display_options->output_window.HeightMode = EMhwlibDisplayWindowValueMode_Fixed;

			RMasciiToInt32(argv[i+1], &(display_options->output_osd_window.X));
			RMasciiToInt32(argv[i+2], &(display_options->output_osd_window.Y));
			RMasciiAutoToUint32(argv[i+3], &(display_options->output_osd_window.Width));
			RMasciiAutoToUint32(argv[i+4], &(display_options->output_osd_window.Height));
			display_options->output_osd_window.XPositionMode = EMhwlibDisplayWindowPositionMode_FrontEdgeToBorder;
			display_options->output_osd_window.YPositionMode = EMhwlibDisplayWindowPositionMode_FrontEdgeToBorder;
			display_options->output_osd_window.XMode = EMhwlibDisplayWindowValueMode_Fixed;
			display_options->output_osd_window.YMode = EMhwlibDisplayWindowValueMode_Fixed;
			display_options->output_osd_window.WidthMode = EMhwlibDisplayWindowValueMode_Fixed;
			display_options->output_osd_window.HeightMode = EMhwlibDisplayWindowValueMode_Fixed;

			i += 5;
		}
		else
			bad_option_parameters = TRUE;
	}

	else if (RMCompareAscii(argv[i], "-strips")) {
		if (argc > i+2) {
			RMasciiAutoToUint32(argv[i+1], &(display_options->blackstrip.Horizontal));
			RMasciiAutoToUint32(argv[i+2], &(display_options->blackstrip.Vertical));
			i+=3;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-cutstrips")) {
		if (argc > i+2) {
			RMasciiAutoToUint32(argv[i+1], &(display_options->cutstrip.Horizontal));
			RMasciiAutoToUint32(argv[i+2], &(display_options->cutstrip.Vertical));
			i+=3;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-nonlin")) {
		if (argc > i+2) {
			RMasciiAutoToUint32(argv[i+1], &(display_options->nonlinearmode.Width));
			RMasciiAutoToUint32(argv[i+2], &(display_options->nonlinearmode.Level));
			if ((display_options->nonlinearmode.Width > 3) || (display_options->nonlinearmode.Level > 3)) {
				bad_option_parameters = TRUE;
			} else {
				i += 3;
			}
		}
		else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-stripcolor")) {
		if (argc > i+1) {
			if (RMFAILED(rmoutput_get_ColorSpecification_from_name(argv[i], &(display_options->strip_color)))) {
				bad_option_parameters = TRUE;
			}
			i+=2;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-fs")) {
		if (argc > i+1) {
			if (RMCompareAscii(argv[i+1], "time")) {
				display_options->field_selection = EMhwlibScalerFieldSelection_BestFieldTime;
			}
			else if (RMCompareAscii(argv[i+1], "type")) {
				display_options->field_selection = EMhwlibScalerFieldSelection_BestFieldType;
			}
			else if (RMCompareAscii(argv[i+1], "one")) {
				display_options->field_selection = EMhwlibScalerFieldSelection_OneField;
			}
			else if (RMCompareAscii(argv[i+1], "pseudo_interlaced_out")) {
				display_options->field_selection = EMhwlibScalerFieldSelection_PseudoInterlacedOutput;
			}

			else
				bad_option_parameters = TRUE;

			i += 2;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-lock_scaler")) {
		if (argc > i+1) {
			if(RMCompareAscii(argv[i+1], "osd")) {
				display_options->lock_scaler = DispOSDScaler;
			}
			else if(RMCompareAscii(argv[i+1], "gfx")) {
				display_options->lock_scaler = DispGFXMultiScaler;
			}
#ifdef RMFEATURE_HAS_VCR_SCALER
			else if(RMCompareAscii(argv[i+1], "vcr")) {
				display_options->lock_scaler = DispVCRMultiScaler;
			}
#endif
#ifdef RMFEATURE_HAS_CRT_SCALER
			else if(RMCompareAscii(argv[i+1], "crt")) {
				display_options->lock_scaler = DispCRTMultiScaler;
			}
#endif
			else if(RMCompareAscii(argv[i+1], "spu")) {
				display_options->lock_scaler = DispSubPictureScaler;
			}
			else if(RMCompareAscii(argv[i+1], "mv")) {
				display_options->lock_scaler = DispMainVideoScaler;
			}
			else
				bad_option_parameters = TRUE;
			i += 2;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-sm")) {
		if (argc > i+1) {
			if (RMCompareAscii(argv[i+1], "letterBox")) {
				display_options->scalingmode = EMhwlibScalingMode_LetterBox;
			}
			else if (RMCompareAscii(argv[i+1], "panScan")) {
				display_options->scalingmode = EMhwlibScalingMode_PanScan;
			}
			else if (RMCompareAscii(argv[i+1], "ARIB")) {
				display_options->scalingmode = EMhwlibScalingMode_ARIB;
			}
			else
				bad_option_parameters = TRUE;

			i+=2;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-luma_lpf")) {
		if (argc > i+1) {
			if (RMCompareAscii(argv[i+1], "0")) {
				display_options->downscalingmode.Discard = FALSE;
				display_options->downscalingmode.FilterBoundary[0] = 0;
				display_options->downscalingmode.FilterBoundary[1] = 0;
				display_options->downscalingmode.FilterBoundary[2] = 0;

			} else if (RMCompareAscii(argv[i+1], "1")) {
				display_options->downscalingmode.Discard = FALSE;
				display_options->downscalingmode.FilterBoundary[0] = 512;
				display_options->downscalingmode.FilterBoundary[1] = 0;
				display_options->downscalingmode.FilterBoundary[2] = 0;


			} else if (RMCompareAscii(argv[i+1], "2")) {
				display_options->downscalingmode.Discard = FALSE;
				display_options->downscalingmode.FilterBoundary[0] = 512;
				display_options->downscalingmode.FilterBoundary[1] = 512;
				display_options->downscalingmode.FilterBoundary[2] = 0;


			} else if (RMCompareAscii(argv[i+1], "3")) {
				display_options->downscalingmode.Discard = FALSE;
				display_options->downscalingmode.FilterBoundary[0] = 512;
				display_options->downscalingmode.FilterBoundary[1] = 512;
				display_options->downscalingmode.FilterBoundary[2] = 512;

			} else if (RMCompareAscii(argv[i+1], "auto")) {
				display_options->downscalingmode.Discard = FALSE;
				display_options->downscalingmode.FilterBoundary[0] = 384;
				display_options->downscalingmode.FilterBoundary[1] = 256;
				display_options->downscalingmode.FilterBoundary[2] = 128;
			}
			else
				bad_option_parameters = TRUE;

			i += 2;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-va") ){
		if (argc> i+1) {
			RMasciiAutoToUint32(argv[i+1], &display_options->video_alpha);
			if (display_options->video_alpha > 0xFF)
				bad_option_parameters = TRUE;
			else
				i += 2;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-oa") ){
		if (argc> i+1) {
			RMasciiAutoToUint32(argv[i+1], &display_options->OSD_alpha);
			if (display_options->OSD_alpha > 0xFF)
				bad_option_parameters = TRUE;
			else
				i += 2;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-lumakey")) {
		if (argc > i+2) {
			if (RMNCompareAscii(argv[i+1], "0x", 2))
				RMasciiHexToUint32(argv[i+1]+2, &(display_options->luma_key.LumaMin));
			else
				RMasciiAutoToUint32(argv[i+1], &(display_options->luma_key.LumaMin));

			if (RMNCompareAscii(argv[i+2], "0x", 2))
				RMasciiHexToUint32(argv[i+2]+2, &(display_options->luma_key.LumaMax));
			else
				RMasciiAutoToUint32(argv[i+2], &(display_options->luma_key.LumaMax));

			i+=3;

		}
		else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-key_color")) {
		if (argc > i+2) {
			if (RMNCompareAscii(argv[i+1], "0x", 2))
				RMasciiHexToUint32(argv[i+1]+2, &(display_options->key_color.B_Cb));
			else
				RMasciiToUInt32(argv[i+1], &(display_options->key_color.B_Cb));

			if (RMNCompareAscii(argv[i+2], "0x", 2))
				RMasciiHexToUint32(argv[i+2]+2, &(display_options->key_color.G_Y));
			else
				RMasciiToUInt32(argv[i+2], &(display_options->key_color.G_Y));

			if (RMNCompareAscii(argv[i+3], "0x", 2))
				RMasciiHexToUint32(argv[i+3]+2, &(display_options->key_color.R_Cr));
			else
				RMasciiToUInt32(argv[i+3], &(display_options->key_color.R_Cr));

			if (RMNCompareAscii(argv[i+4], "0x", 2))
				RMasciiHexToUint32(argv[i+4]+2, &(display_options->key_color.Range));
			else
				RMasciiToUInt32(argv[i+4], &(display_options->key_color.Range));

			display_options->do_key_color = TRUE;
			i+=5;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-mv_wide_bw_filter_boundary")) {
		if (argc > i+1) {
			if (RMCompareAscii(argv[i+1], "none")) {
				display_options->wide_bw_filter_boundary = 0x0;

			} else if (RMCompareAscii(argv[i+1], "upscale_4x")) {
				display_options->wide_bw_filter_boundary = 0x400;
			} else if (RMCompareAscii(argv[i+1], "upscale_2x")) {
				display_options->wide_bw_filter_boundary = 0x800;
			} else if (RMCompareAscii(argv[i+1], "1x")) {
				display_options->wide_bw_filter_boundary = 0x1000;
			}
			else
				bad_option_parameters = TRUE;
			i += 2;
		}
		else
			bad_option_parameters = TRUE;
	}

	else if (RMCompareAscii(argv[i], "-mv_filter")) {
		if (argc > i+1) {
			if (RMCompareAscii(argv[i], "0")) {
				display_options->filtermode.Boundary_0_1 = 0x4000;
				display_options->filtermode.Boundary_1_2 = 0x4000;
				display_options->filtermode.Boundary_2_3 = 0x4000;

			} else if (RMCompareAscii(argv[i+1], "1")) {
				display_options->filtermode.Boundary_0_1 = 0x0000;
				display_options->filtermode.Boundary_1_2 = 0x4000;
				display_options->filtermode.Boundary_2_3 = 0x4000;

			} else if (RMCompareAscii(argv[i+1], "2")) {
				display_options->filtermode.Boundary_0_1 = 0x0000;
				display_options->filtermode.Boundary_1_2 = 0x0000;
				display_options->filtermode.Boundary_2_3 = 0x4000;

			} else if (RMCompareAscii(argv[i+1], "3")) {
				display_options->filtermode.Boundary_0_1 = 0x0000;
				display_options->filtermode.Boundary_1_2 = 0x0000;
				display_options->filtermode.Boundary_2_3 = 0x0000;

			} else if (RMCompareAscii(argv[i+1], "auto")) {
				display_options->filtermode.Boundary_0_1 = 0x1400;
				display_options->filtermode.Boundary_1_2 = 0x1c00;
				display_options->filtermode.Boundary_2_3 = 0x2c00;
			}
			else
				bad_option_parameters = TRUE;
			i += 2;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-time_interval")) {
		if (argc > i+1) {
			RMuint32 j;
			for (j=0 ; j<RMasciiLength(argv[i+1]) ; j++)
				if (argv[i+1][j] == '-')
					break;

			if (j==0)
				display_options->time_interval.Mode = EMhwlibDisplayIntervalMode_End;
			else if (j == RMasciiLength(argv[i+1]) - 1)
				display_options->time_interval.Mode = EMhwlibDisplayIntervalMode_Start;
			else if (j < RMasciiLength(argv[i+1])) {
				display_options->time_interval.Mode = EMhwlibDisplayIntervalMode_StartEnd;
			}

			if (j < RMasciiLength(argv[i+1])) {
				argv[i+1][j] = '\0';

				RMasciiAutoToUint32(argv[i+1], &(display_options->time_interval.StartPTSLo));
				display_options->time_interval.StartPTSHi = 0;
				RMasciiAutoToUint32(argv[i+1]+j+1, &(display_options->time_interval.EndPTSLo));
				display_options->time_interval.EndPTSHi = 0;
				i += 2;

			}
			else
				bad_option_parameters = TRUE;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-D")) {
		if (argc > i+1) {
			if (RMCompareAscii(argv[i+1], "0")) {
				display_options->deinterlacingmode = EMhwlibDeinterlacingMode_Discard_Bob;
			}
			else if (RMCompareAscii(argv[i+1], "1")) {
				display_options->deinterlacingmode = EMhwlibDeinterlacingMode_ConstantBlend;
			}
			else if (RMCompareAscii(argv[i+1], "2")) {
				display_options->deinterlacingmode = EMhwlibDeinterlacingMode_MotionAdaptative;
			}
			else if (RMCompareAscii(argv[i+1], "3")) {
				display_options->deinterlacingmode = EMhwlibDeinterlacingMode_Weave;
			}
#ifdef RMFEATURE_HAS_DEDICATED_DEINTERLACING
			else if (RMCompareAscii(argv[i+1], "4")) {
				display_options->deinterlacingmode = EMhwlibDeinterlacingMode_MotionAdaptative_4field;
			}
#endif
			else
				bad_option_parameters = TRUE;

			i+=2;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-32pd")) {
		display_options->do_pulldown = TRUE;
		i++;
	}else if (RMCompareAscii(argv[i], "-motion_config")) {
#ifdef RMFEATURE_HAS_DEDICATED_DEINTERLACING
		if (argc > i+2) {
			RMuint32 config;

			RMasciiHexToUint32(argv[i+1], &(config));
			display_options->deinterlacing_motion_config.Scale = config & 0x7;

			if (RMNCompareAscii(argv[i+2], "0x", 2))
				RMasciiHexToUint32(argv[i+2]+2, &(config));
			else
				RMasciiAutoToUint32(argv[i+2], &(config));
			display_options->deinterlacing_motion_config.Value0 = (config >> 0) & 0xff;
			display_options->deinterlacing_motion_config.Value8 = (config >> 8) & 0xff;
			display_options->deinterlacing_motion_config.Value16 = (config >> 16) & 0xff;
			display_options->deinterlacing_motion_config.Value32 = (config >> 24) & 0xff;
			i+=3;
		}
#else
		if (argc > i+1) {
			RMuint32 config;

			if (RMNCompareAscii(argv[i+1], "0x", 2))
				RMasciiHexToUint32(argv[i+1]+2, &(config));
			else
				RMasciiAutoToUint32(argv[i+1], &(config));
			display_options->deinterlacing_motion_config.Value0 = (config >> 0) & 0xff;
			display_options->deinterlacing_motion_config.Value8 = (config >> 8) & 0xff;
			display_options->deinterlacing_motion_config.Value16 = (config >> 16) & 0xff;
			display_options->deinterlacing_motion_config.Value32 = (config >> 24) & 0xff;
			i+=2;
		}
#endif // RMFEATURE_HAS_DEDICATED_DEINTERLACING
		else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-d2_proportion")) {
		if (argc > i+1) {
			RMuint32 config;

			if (RMNCompareAscii(argv[i+1], "0x", 2))
				RMasciiHexToUint32(argv[i+1]+2, &(config));
			else
				RMasciiAutoToUint32(argv[i+1], &(config));
			display_options->deinterlacing_proportion.ExistingLineProportion = (config >> 0) & 0xff;
			display_options->deinterlacing_proportion.NewLineProportion = (config >> 8) & 0xff;
			i+=2;
		}
		else
			bad_option_parameters = TRUE;
	}

	else if (RMCompareAscii(argv[i], "-bcss")) {
		if (argc > i+4) {
			RMint32 bh;
			RMasciiToInt32(argv[i+1], &bh);
			display_options->brightness = (bh > 127) ? 127 : (bh < -128) ? -128 : bh;
			RMasciiToUInt8(argv[i+2], &(display_options->contrast));
			RMasciiToUInt8(argv[i+3], &(display_options->saturation_blue));
			RMasciiToUInt8(argv[i+4], &(display_options->saturation_red));
			i += 5;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-cdb")) {
		if (argc > i+1) {
			RMasciiAutoToUint32(argv[i+1], &(display_options->color_degradation_boundary));
		}
		else
			bad_option_parameters = TRUE;
		i+=2;
	}

	else if (RMCompareAscii(argv[i], "-mcs")) {
		if (argc > i+1) {
			RMstatus err = rmoutput_get_ColorSpace_from_name(argv[i + 1], &(display_options->mixer_color_space));
			if (err != RM_OK)
				bad_option_parameters = TRUE;

			if (bad_option_parameters == FALSE)
				display_options->force_mixer_color_space = TRUE;
			i += 2;
		} else
			bad_option_parameters = TRUE;
	}

	else if (RMCompareAscii(argv[i], "-route")) {
		if (argc > i+1) {
			if(RMCompareAsciiCaseInsensitively(argv[i+1], "main")) {
				display_options->route = RMFPRoute_Main;
			}
			else if(RMCompareAsciiCaseInsensitively(argv[i+1], "vcr")) {
				display_options->route = RMFPRoute_Secondary;
			}
			else if(RMCompareAsciiCaseInsensitively(argv[i+1], "cb") || RMCompareAsciiCaseInsensitively(argv[i], "colorbars")) {
				RMNOTIFY((NULL, RM_PARAMETER_OUT_OF_RANGE, "Route to colorbars makes no sense\n"));
				display_options->route = RMFPRoute_ColorBars;
			}
			else
				bad_option_parameters = TRUE;
			i+=2;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-vscaler")) {
		if (argc > i+1) {
			if (RMCompareAscii(argv[i+1], "none") || RMCompareAscii(argv[i+1], "-1")) {
				display_options->scaler_ID = (RMuint32)-1;
			}
			else if (RMCompareAscii(argv[i+1], "mv") || RMCompareAscii(argv[i+1], "0")) {
				display_options->scaler_ID = DispMainVideoScaler;
			}
#ifdef RMFEATURE_HAS_VCR_SCALER
			else if(RMCompareAscii(argv[i+1], "vcr") || RMCompareAscii(argv[i+1], "1")) {
				display_options->scaler_ID = DispVCRMultiScaler;
			}
#endif
			else if(RMCompareAscii(argv[i+1], "gfx") || RMCompareAscii(argv[i+1], "2")) {
				display_options->scaler_ID = DispGFXMultiScaler;
			}
#ifdef RMFEATURE_HAS_CRT_SCALER
			else if(RMCompareAscii(argv[i+1], "crt") || RMCompareAscii(argv[i+1], "3")) {
				display_options->scaler_ID = DispCRTMultiScaler;
			}
#endif
			else
				bad_option_parameters = TRUE;
			i += 2;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-oscaler")) {
		if (argc > i+1) {
			if(RMCompareAscii(argv[i+1], "osd") || RMCompareAscii(argv[i+1], "0")) {
				display_options->osd_scaler_ID = DispOSDScaler;
			}
			else if(RMCompareAscii(argv[i+1], "gfx") || RMCompareAscii(argv[i+1], "1")) {
				display_options->osd_scaler_ID = DispGFXMultiScaler;
			}
			else if(RMCompareAscii(argv[i+1], "mv") || RMCompareAscii(argv[i+1], "2")) {
				display_options->osd_scaler_ID = DispMainVideoScaler;
			}
#ifdef RMFEATURE_HAS_VCR_SCALER
			else if(RMCompareAscii(argv[i+1], "vcr") || RMCompareAscii(argv[i+1], "3")) {
				display_options->osd_scaler_ID = DispVCRMultiScaler;
			}
#endif
#ifdef RMFEATURE_HAS_CRT_SCALER
			else if(RMCompareAscii(argv[i+1], "crt") || RMCompareAscii(argv[i+1], "4")) {
				display_options->osd_scaler_ID = DispCRTMultiScaler;
			}
#endif
			else if(RMCompareAscii(argv[i+1], "spu") || RMCompareAscii(argv[i+1], "5")) {
				display_options->osd_scaler_ID = DispSubPictureScaler;
			}
#ifdef RMFEATURE_HAS_VIDEO_PLANE
			else if(RMCompareAscii(argv[i+1], "vp") || RMCompareAscii(argv[i+1], "6")) {
				display_options->osd_scaler_ID = DispVideoPlane;
			}
#endif
			else
				bad_option_parameters = TRUE;
			i += 2;
		}
		else
			bad_option_parameters = TRUE;

	}
#ifdef RMFEATURE_HAS_DEDICATED_DEINTERLACING
	else if (RMCompareAscii(argv[i], "-D_window0")) {
		if (argc > i+4) {
			RMint32 X, Y;
			RMuint32 Width, Height;

			RMasciiToInt32(argv[i+1], &X);
			RMasciiToInt32(argv[i+2], &Y);
			RMasciiAutoToUint32(argv[i+3], &Width);
			RMasciiAutoToUint32(argv[i+4], &Height);

			display_options->deinterlacing_window0.Xmin = X;
			display_options->deinterlacing_window0.Ymin = Y;
			display_options->deinterlacing_window0.Xmax = X + Width;
			display_options->deinterlacing_window0.Ymax = Y + Height;

			i += 5;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-D_window1")) {
		if (argc > i+4) {
			RMint32 X, Y;
			RMuint32 Width, Height;

			RMasciiToInt32(argv[i+1], &X);
			RMasciiToInt32(argv[i+2], &Y);
			RMasciiAutoToUint32(argv[i+3], &Width);
			RMasciiAutoToUint32(argv[i+4], &Height);

			display_options->deinterlacing_window1.Xmin = X;
			display_options->deinterlacing_window1.Ymin = Y;
			display_options->deinterlacing_window1.Xmax = X + Width;
			display_options->deinterlacing_window1.Ymax = Y + Height;

			i += 5;
		}
		else
			bad_option_parameters = TRUE;
	}
#endif
	else if (RMCompareAscii(argv[i], "-subs_res")) {
		if (argc > i+1) {
			RMint32 Y;

			RMasciiToInt32(argv[i+1], &Y);

			display_options->subtitles_osd_height = Y;

			i += 2;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-surface_event_index")) {
		if (argc > i+1) {
			RMint32 Y;

			RMasciiToInt32(argv[i+1], &Y);

			display_options->SurfaceSoftEventIndex = Y;

			i += 2;
		}
		else
			bad_option_parameters = TRUE;
	}
	else if (RMCompareAscii(argv[i], "-user_surface")) {
		if (argc > i+1) {
			if (RMCompareAscii(argv[i+1], "dummy")) {
				display_options->UserSurfaceMode = TESTRMFP_UserSurfaceMode_Dummy;
			}
			else if (RMCompareAscii(argv[i+1], "print")) {
				display_options->UserSurfaceMode = TESTRMFP_UserSurfaceMode_Print;
			}
			else if (RMCompareAscii(argv[i+1], "checksum")) {
				display_options->UserSurfaceMode = TESTRMFP_UserSurfaceMode_CRC32;
			}
			else
				bad_option_parameters = TRUE;
			i += 2;
		}
		else
			bad_option_parameters = TRUE;
	}
	else {
		/* Parameter not found ! */
		return RM_PENDING;
	}

	/* Check if it failed */
	if (bad_option_parameters == TRUE) {
		return RM_ERROR;
	}
	else {
		*index = i;
		return RM_OK;
	}
}

