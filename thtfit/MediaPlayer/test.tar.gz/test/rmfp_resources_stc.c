/*****************************************
 Copyright 2001-2007
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   rmfp_resources_stc.c
  @brief


  @author Sebastian Frias Feltrer
  @date   2007-11-05
*/

#include "rmfp_internal.h"

#if 0
#define LOCALDBG ENABLE
#else
#define LOCALDBG DISABLE
#endif



static RMstatus rmfp_print_dcc_stc_profile(struct DCCStcProfile *pSTCProfile);

RMstatus rmfp_internal_get_stc_handler(void *pContext, struct RMLibPlaySTC *pSTC, struct RMLibPlaySTCProfile *pSTCProfile)
{
	struct RMFPHandle *pHandle = NULL;
	struct DCCStcProfile DCCSTCProfile = { 0, };
	struct DCC *pDCC = NULL;
	struct DCCSTCSource *pDCCSTCSource = NULL;
	struct RMFPPlayOptions *pPlayOptions = NULL;
	RMuint32 STCModuleID = 0;
	RMstatus status;

	RMDBGLOG((LOCALDBG, "rmfp_get_stc()\n"));

	ASSERT_NULL_POINTER(pContext);
	ASSERT_NULL_POINTER(pSTCProfile);
	ASSERT_NULL_POINTER(pSTC);

	pHandle = (struct RMFPHandle *)pContext;

	pDCC = pHandle->profile.pDCC;

	pPlayOptions = &(pHandle->playback_options);


	DCCSTCProfile.STCID                 = pPlayOptions->STCIndex + pPlayOptions->STCEngine*3;
	
	DCCSTCProfile.master                = RMFP_DEFAULT_STC_MODE;

	DCCSTCProfile.stc_timer_id          = 3 * pPlayOptions->STCIndex + 0;
	DCCSTCProfile.stc_time_resolution   = pSTCProfile->stc_time_resolution;

	DCCSTCProfile.video_timer_id        = 3 * pPlayOptions->STCIndex + 1;
	DCCSTCProfile.video_time_resolution = pSTCProfile->video_time_resolution;
	DCCSTCProfile.video_offset          = pSTCProfile->video_offset;

	DCCSTCProfile.audio_timer_id        = 3 * pPlayOptions->STCIndex + 2;
	DCCSTCProfile.audio_time_resolution = pSTCProfile->audio_time_resolution;
	DCCSTCProfile.audio_offset          = pSTCProfile->audio_offset;

	/* Use the requested stc engine */
	DCCSTCProfile.stc_timer_id         |= pPlayOptions->STCEngine << 16;
	DCCSTCProfile.video_timer_id       |= pPlayOptions->STCEngine << 16;
	DCCSTCProfile.audio_timer_id       |= pPlayOptions->STCEngine << 16;

	rmfp_print_dcc_stc_profile(&DCCSTCProfile);

	status = DCCSTCOpen(pDCC, &DCCSTCProfile, &pDCCSTCSource);
	if (status != RM_OK) {
		RMNOTIFY((NULL, status, "Cannot open STC\n"));
		return status;
	}

	status = DCCSTCGetModuleId(pDCCSTCSource, &STCModuleID);
	RMDBGLOG((LOCALDBG, "STC ModuleID 0x%lx\n", STCModuleID));


	pSTC->source = (void *)pDCCSTCSource;

	/* if needed connect clock to VCXO */
	if (pPlayOptions->stc_compensation)
	{
#if (EM86XX_CHIP >= EM86XX_CHIPID_TANGO2)
		RMuint32 N,M;
		struct DCCVCXOProfile vcxo_open_profile = {0, };

		RMDBGLOG((ENABLE, "Enable VCXO\n"));

		/* Set the VCXO index (-1 if none) */
		vcxo_open_profile.VCXOIndex = pPlayOptions->vcxo_index;

		
		/* Open a new VCXO handle */
		status = DCCVCXOOpen(pDCC, &vcxo_open_profile, (struct DCCVCXOSource**) &(pSTC->VCXOSource));
		if (status != RM_OK)
		{
			RMNOTIFY((NULL, status, "Cannot open a new VCXO handle\n"));
			return status;
		}
		
		/* Set STC to the current VCXO speed if there is a vcxo */
		if (vcxo_open_profile.VCXOIndex >= 0)
		{
			status = DCCVCXOGetSpeed(pSTC->VCXOSource, &N, &M);
			if (status != RM_OK)
			{
				RMNOTIFY((NULL, status, "Cannot get VCXO speed\n"));
				return status;
			}
			DCCSTCSetSpeed(pSTC->source, N, M);
			if (status != RM_OK)
			{
				RMNOTIFY((NULL, status, "Cannot reset VCXO speed\n"));
				return status;
			}
		}
		
		/* Connect the STC to the VCXO */
		status = DCCVCXOConnectSTC(pSTC->VCXOSource, pSTC->source);
		if (status != RM_OK)
		{
			RMNOTIFY((NULL, status, "Cannot connect the STC to the VCXO\n"));
			return status;
		}
		
		/* Reset regulation and VCXO speed if requested */
		if (pPlayOptions->reset_vcxo == RMFPVcxoReset_SpeedAndRegulation) {
			status = DCCVCXOSetSpeed(pSTC->VCXOSource, 1000000000, 1000000000);
			if (status != RM_OK)
			{
				RMNOTIFY((NULL, status, "Cannot set VCXO speed\n"));
				return status;
			}
			
			status = DCCVCXOResetRegulation(pSTC->VCXOSource);
			if (status != RM_OK)
			{
				RMNOTIFY((NULL, status, "Cannot reset VCXO regulation\n"));
				return status;
			}
		}
		else if (pPlayOptions->reset_vcxo == RMFPVcxoReset_Regulation) {
			status = DCCVCXOResetRegulation(pSTC->VCXOSource);
			if (status != RM_OK)
			{
				RMNOTIFY((NULL, status, "Cannot reset VCXO regulation\n"));
				return status;
			}
		}
		
#else
		RMNOTIFY((NULL, RM_ERROR, "VCXO is not available on this chip\n"));
		return RM_ERROR;
#endif
	}

	return RM_OK;
}


RMstatus rmfp_internal_release_stc_handler(void *pContext, struct RMLibPlaySTC *pSTC)
{
	struct RMFPHandle *pHandle = NULL;
	struct DCCSTCSource *pSTCSource = NULL;
	struct RMFPPlayOptions *pPlayOptions = NULL;
	RMstatus status;

	RMDBGLOG((LOCALDBG, "rmfp_release_stc()\n"));

	ASSERT_NULL_POINTER(pContext);
	ASSERT_NULL_POINTER(pSTC);

	pHandle = (struct RMFPHandle *)pContext;
	pSTCSource = (struct DCCSTCSource *)pSTC->source;
	pPlayOptions = &(pHandle->playback_options);

	/* if needed close the DCC VCXO */
	if (pPlayOptions->stc_compensation)
	{
#if (EM86XX_CHIP >= EM86XX_CHIPID_TANGO2)
		/* Disconnect the STC from the VCXO */
		status = DCCVCXODisconnectSTC(pSTC->VCXOSource);
		if (status != RM_OK)
		{
			RMNOTIFY((NULL, status, "Cannot disconnect the STC from the VCXO\n"));
			return status;
		}
		
		status = DCCVCXOClose(pSTC->VCXOSource);
		if (status != RM_OK)
		{
			RMNOTIFY((NULL, status, "Cannot close VCXO handle\n"));
			return status;
		}
		pSTC->VCXOSource = NULL;
#else
		RMNOTIFY((NULL, RM_ERROR, "VCXO is not available on this chip\n"));
		return RM_ERROR;
#endif
	}
	status = DCCSTCClose(pSTCSource);

	return status;
}


static RMstatus rmfp_print_dcc_stc_profile(struct DCCStcProfile *pSTCProfile)
{

	ASSERT_NULL_POINTER(pSTCProfile);


	RMDBGPRINT((LOCALDBG, "DCCSTCProfile:\n"));
	RMDBGPRINT((LOCALDBG, "\tSTCIndex                %lu\n", pSTCProfile->STCID));
	RMDBGPRINT((LOCALDBG, "\tMode                    0x%lx\n", pSTCProfile->master));

	RMDBGPRINT((LOCALDBG, "\tSTC Timer ID            %lu (0x%lx)\n", pSTCProfile->stc_timer_id, pSTCProfile->stc_timer_id));
	RMDBGPRINT((LOCALDBG, "\tSTC TimeScale           %lu\n", pSTCProfile->stc_time_resolution));

	RMDBGPRINT((LOCALDBG, "\tVideo Timer ID          %lu (0x%lx)\n", pSTCProfile->video_timer_id, pSTCProfile->video_timer_id));
	RMDBGPRINT((LOCALDBG, "\tVideo TimeScale         %lu\n", pSTCProfile->video_time_resolution));
	RMDBGPRINT((LOCALDBG, "\tVideo Offset            %ld\n", pSTCProfile->video_offset));

	RMDBGPRINT((LOCALDBG, "\tAudio Timer ID          %lu (0x%lx)\n", pSTCProfile->audio_timer_id, pSTCProfile->audio_timer_id));
	RMDBGPRINT((LOCALDBG, "\tAudio TimeScale         %lu\n", pSTCProfile->audio_time_resolution));
	RMDBGPRINT((LOCALDBG, "\tAudio Offset            %ld\n", pSTCProfile->audio_offset));

	return RM_OK;
}
