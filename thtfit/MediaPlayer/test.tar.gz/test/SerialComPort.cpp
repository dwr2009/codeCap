#include "SerialComPort.h"
#include <BaseErrDef.h>
#include <ErrPrintHelper.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <FdEvtNotifier.h>

CSerialComPort::CSerialComPort()
{
	m_iDevFd = INVALID_FILE_DESCRIPTOR;
}
CSerialComPort::~CSerialComPort()
{
	Close();
}

INT_t CSerialComPort::Open(LPCSTR pszSerialComDev)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	struct termios newComSettings;

	do
	{
		if(NULL == pszSerialComDev || '\0' == pszSerialComDev)
		{
			iOutRet = ERROR_INVALID_PARAMETER;
			break;
		}
		
		if(INVALID_FILE_DESCRIPTOR != m_iDevFd)
		{
			iOutRet = ERR_ALREADY_OPENED;
			break;
		}

		m_iDevFd = open(pszSerialComDev, O_RDWR | O_NOCTTY | O_NDELAY | O_NONBLOCK);
		if(0 > m_iDevFd)
		{
			iOutRet = ERROR_FILE_OPEN_FAIL;
			break;
		}

		iRet = tcgetattr(m_iDevFd, &newComSettings);
		if(0 != iRet)
		{
			iOutRet = ERR_TC_GET_ATTR_FAIL;
			break;
		}
		//local use
		newComSettings.c_cflag &= ~(CRTSCTS);
		newComSettings.c_cflag |= (CLOCAL | CREAD);
		//disable data flow control
		newComSettings.c_iflag &= ~(ICANON | ECHO | ECHOE | ISIG | BRKINT | INPCK | ISTRIP | ICRNL | IXON | IXOFF | IXANY);
		newComSettings.c_oflag &= ~(ICANON | ECHO | ECHOE | ISIG | BRKINT | INPCK | ISTRIP | ICRNL | IXON | IXOFF | IXANY);
		newComSettings.c_lflag &= ~(ICANON | ECHO | ECHOE | ISIG | BRKINT | INPCK | ISTRIP | ICRNL | IXON | IXOFF | IXANY);
		newComSettings.c_cc[VTIME] = 0;
		newComSettings.c_cc[VMIN] = 1;
		//set
		iRet = tcsetattr(m_iDevFd, TCSANOW, &newComSettings);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = ERR_SET_ATTR_FAIL;
			break;
		}
		//register a read listener
		iRet = CFdEvtNotifier::RegisterFdNotify(m_iDevFd, IFileDescriptorEventIf::FD_EVT_READABLE, m_this_wp);
		if(ERROR_SUCCESS != iRet)
		{
			PRINT_BFILE_LINENO_IRET_STR;
		}
	}while(FALSE);

	return iOutRet;
}

INT_t CSerialComPort::getTermIosSpeed(INT_t iBaudrate, OUT speed_t & termBaudrate)
{
	INT_t iOutRet = ERROR_SUCCESS;

	do
	{	
		if(110 == iBaudrate)
		{
			termBaudrate = B110;
		}
		else if(300 == iBaudrate)
		{
			termBaudrate = B300;
		}
		else if(600 == iBaudrate)
		{
			termBaudrate = B600;
		}
		else if(1200 == iBaudrate)
		{
			termBaudrate = B1200;
		}
		else if(2400 == iBaudrate)
		{
			termBaudrate = B2400;
		}
		else if(4800 == iBaudrate)
		{
			termBaudrate = B4800;
		}
		else if(9600 == iBaudrate)
		{
			termBaudrate = B9600;
		}
		else if(19200 == iBaudrate)
		{
			termBaudrate = B19200;
		}
		else if(38400 == iBaudrate)
		{
			termBaudrate = B38400;
		}
		else if(57600 == iBaudrate)
		{
			termBaudrate = B57600;
		}
		else if(115200 == iBaudrate)
		{
			termBaudrate = B115200;
		}
		else
		{
			iOutRet = ERROR_INVALID_PARAMETER;
			break;
		}
	}while(FALSE);

	return iOutRet;
}

INT_t CSerialComPort::setComParameters(INT_t iBaudrate, CSerialComPort::SERIAL_PARITY eSerialParity, INT_t iDataBits, INT_t iStopBits)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	struct termios newComSettings;
	speed_t termBaudrate;

	do
	{
		if(INVALID_FILE_DESCRIPTOR == m_iDevFd)
		{
			iOutRet = ERR_FILE_NOT_OPENED;
			break;
		}
		iRet = tcgetattr(m_iDevFd, &newComSettings);
		if(0 != iRet)
		{
			iOutRet = ERR_TC_GET_ATTR_FAIL;
			break;
		}
		//baudrate
		iRet = getTermIosSpeed(iBaudrate, OUT termBaudrate);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}
		iRet = cfsetispeed(&newComSettings, termBaudrate);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = ERR_SET_ATTR_FAIL;
			break;
		}
		iRet = cfsetospeed(&newComSettings, termBaudrate);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = ERR_SET_ATTR_FAIL;
			break;
		}
		//parity
		if(PARITY_NO == eSerialParity)
		{
			newComSettings.c_cflag &= ~(PARENB | PARODD);
			newComSettings.c_iflag &= ~INPCK;	//disable parity checking for incoming packat
		}
		else if(PARITY_ODD == eSerialParity)
		{
			newComSettings.c_cflag |= PARENB;
			newComSettings.c_cflag |= PARODD; 
			newComSettings.c_iflag |= INPCK;	//enable parity checking for incoming packat
		}
		else if(PARITY_EVEN == eSerialParity)
		{
			newComSettings.c_cflag |= PARENB; 
			newComSettings.c_cflag &= ~PARODD; 
			newComSettings.c_iflag |= INPCK;	//enable parity checking for incoming packat
		}
		else
		{
			iOutRet = ERROR_INVALID_PARAMETER;
			break;
		}
		//data bits
		newComSettings.c_cflag &= ~CSIZE;
		if(7 ==  iDataBits)
		{
			newComSettings.c_cflag |= CS7;
		}
		else if(8 ==  iDataBits)
		{
			newComSettings.c_cflag |= CS8;
		}
		else
		{
			iOutRet = ERROR_INVALID_PARAMETER;
			break;
		}
		//stop bits
		if(1 == iStopBits)
		{
			newComSettings.c_cflag &= ~CSTOPB;
		}
		else if(2 == iStopBits)
		{
			newComSettings.c_cflag |= CSTOPB;
		}
		else
		{
			iOutRet = ERROR_INVALID_PARAMETER;
			break;
		}
		//set
		iRet = tcsetattr(m_iDevFd, TCSANOW, &newComSettings);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = ERR_SET_ATTR_FAIL;
			break;
		}
	}while(FALSE);

	return iOutRet;
}

VOID CSerialComPort::Close()
{
	int iRet;
	
	if(INVALID_FILE_DESCRIPTOR != m_iDevFd)
	{
		//unregister the listener
		iRet = CFdEvtNotifier::UnregisterFdNotify(m_iDevFd);
		if(ERROR_SUCCESS != iRet)
		{
			PRINT_BFILE_LINENO_IRET_STR;
		}
		//close the fd
		iRet = close(m_iDevFd);
		if(ERROR_SUCCESS != iRet)
		{
			PRINT_BFILE_LINENO_CRT_ERRINFO;
		}
		m_iDevFd = INVALID_FILE_DESCRIPTOR;
	}
}

INT_t CSerialComPort::OnFdEvent(int iFd, CONST IFileDescriptorEventIf::FD_EVENT_FLAGS FdEvtFlags)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;

	//LOG_BLINE("OnFdEvent(%d,0x%08x)\n", iFd, FdEvtFlags);

	do
	{
		if(iFd == m_iDevFd)
		{
			if(IFileDescriptorEventIf::FD_EVT_READABLE & FdEvtFlags)
			{
				BYTE szReceiveBuf[MP7XX_MAX_RECEIVE_BUF_SIZE];	
				iRet = read(m_iDevFd, szReceiveBuf, sizeof(szReceiveBuf));
				if(0 < iRet)
				{
					size_t BytesRead = iRet;
					//LOG_BLINE("BytesRead=%d\n", BytesRead);
					iRet = m_ReceivedData.Append(szReceiveBuf, BytesRead);
					if(ERROR_SUCCESS == iRet)
					{
						if(MP7XX_MAX_RECEIVE_BUF_SIZE < m_ReceivedData.GetSize())
						{
							iRet = m_ReceivedData.RemoveAt(0, m_ReceivedData.GetSize()-MP7XX_MAX_RECEIVE_BUF_SIZE);
							if(ERROR_SUCCESS == iRet)
							{
								PRINT_BFILE_LINENO_IRET_STR;
							}
						}
					}
					else
					{
						PRINT_BFILE_LINENO_IRET_STR;
					}
				}
			}
			else
			{
				PRINT_BFILE_LINENO_BUG_STR;
			}
		}
		else
		{
			PRINT_BFILE_LINENO_BUG_STR;
		}
	}while(FALSE);

	return iOutRet;
}

INT_t CSerialComPort::SendCommand(LPCSTR pszCmd)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	size_t bytesToSend = strlen(pszCmd), bytesSent = 0;
	long int iOldFdFlags, iNewFdFlags;
	BOOL_t bNeedRestoreFdFlags = FALSE;

	do
	{
		iOldFdFlags = fcntl(m_iDevFd, F_GETFL);
		if(0 > iOldFdFlags)
		{
			iOutRet = ERROR_IOCTL_FAILED;
			break;
		}
		
		iNewFdFlags = iOldFdFlags & (~(O_NONBLOCK));
		iRet = fcntl(m_iDevFd, F_SETFL, iNewFdFlags);
		if(0 > iRet)
		{
			iOutRet = ERROR_IOCTL_FAILED;
			break;
		}
		bNeedRestoreFdFlags = TRUE;
		
		iRet = write(m_iDevFd, pszCmd, bytesToSend);
		if(0 > iRet)
		{
			iOutRet = ERROR_FILE_WRITE_FAIL;
			break;
		}
		else if(bytesToSend != iRet)
		{
			PRINT_BFILE_LINENO_CRT_ERRINFO;
			break;
		}
		m_ReceivedData.RemoveAll();
	}while(FALSE);

	if(bNeedRestoreFdFlags)
	{
		bNeedRestoreFdFlags = FALSE;
		iRet = fcntl(m_iDevFd, F_SETFL, iOldFdFlags);
		if(0 > iRet)
		{
			iOutRet = ERROR_IOCTL_FAILED;
		}
	}
	
	return iOutRet;
}

INT_t CSerialComPort::ReadResult(OUT CByteArray2 & resultData)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;

	do
	{
		iRet = (resultData = m_ReceivedData);
		if(ERROR_SUCCESS != iRet)
		{
			iOutRet = iRet;
			break;
		}
	}while(FALSE);

	return iOutRet;
}

