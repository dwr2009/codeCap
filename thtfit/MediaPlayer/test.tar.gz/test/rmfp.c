/*****************************************
 Copyright 2001-2007
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   rmfp.c
  @brief


  @author Sebastian Frias Feltrer
  @date   2007-08-07
*/


/*
   If set to 0 then all ASSERT_NULL_POINTER() calls will be disabled.
   By default (set to 1) we only check for NULL pointers at the
   interface, but not inside the library, see rmfp_internal.h to enable
   checking inside the library
*/
#define CHECK_NULL_POINTERS 1

#include <stdio.h> // for sscanf

#include <rmlibhttp/include/rmlibhttp.h>
#include <rmlibcurl/include/rmlibcurl.h>
#include <rmlibcw/include/rmlibcw.h>
#include <rmcore/include/rmcore.h>
#include <rmtextsubs/include/rmtextsubs.h>
#include <rmfontrender/include/rmfontrender.h>
#include "rmfp_internal.h"
#include "rmfp_fonts.h"
#include <ErrPrintHelper.h>
#include <rmlibplay/include/rmlibplay.h>
#include <Compiler.h>
#include <sys/time.h>
#include <ErrPrintHelper.h>
#define LOCALDBG DISABLE


/*
  INTERNAL FUNCTIONS PROTOTYPES
*/


// initialisation functions
static RMstatus rmfp_init_playback_options(struct RMFPPlayOptions *pOptions);
static RMstatus rmfp_init_video_options(struct RMFPVideoOptions *pOptions);
static RMstatus rmfp_init_audio_options(struct RMFPAudioOptions *pOptions);
static RMstatus rmfp_init_demux_options(struct RMFPDemuxOptions *pOptions);
static RMstatus rmfp_init_picture_options(struct RMFPPictureOptions *pOptions);

// translation from RMFP to RMLIBPLAY
static RMstatus rmfp_rmfp2rmlibplay_translate_options(struct RMFPOptions *pInRMFPOptions, struct RMLibPlayOptions *pOutRMLibPlayOptions);
static RMstatus rmfp_rmfp2rmlibplay_translate_audio_options(struct RMFPAudioOptions *pInOptions, struct RMLibPlayAudioOptions *pOutOptions);
static RMstatus rmfp_rmfp2rmlibplay_translate_video_options(struct RMFPVideoOptions *pInVideoOptions, struct RMLibPlayVideoOptions *pOutVideoOptions);
static RMstatus rmfp_rmfp2rmlibplay_translate_playback_options(struct RMFPPlayOptions *pInPlaybackOptions, struct RMLibPlayPlaybackOptions *pOutPlaybackOptions);
static RMstatus rmfp_rmfp2rmlibplay_translate_demux_options(struct RMFPDemuxOptions *pInDemuxOptions, struct RMLibPlayDemuxOptions *pOutDemuxOptions);
static RMstatus rmfp_rmfp2rmlibplay_translate_picture_options(struct RMFPPictureOptions *pInPictureOptions, struct RMLibPlayPictureOptions *pOutPictureOptions);

// Parameters coherency check
static RMstatus rmfp_check_parameters_coherency(struct RMFPHandle *pHandle, struct RMFPOptions *pOptions, struct RMFPStreamType *pStreamType);

// Misc checks
static void rmfp_check_callback(struct RMFPProfile* pProfile);

#define PRINT_STRUCT_SIZES DISABLE
static void rmfp_print_struct_sizes(void);

RMstatus RMFPInitProfile(struct RMFPProfile *pProfile)
{
	/*
	init the profile with default values and fill the magicNumber
	*/

	ASSERT_NULL_POINTER(pProfile);

	RMDBGLOG((LOCALDBG, "RMFPInitProfile(@%p)\n", pProfile));

	if (pProfile->magicNumber == RMFP_MAGIC_NUMBER) {
		// the application knows the current version of the profile
		RMMemset((void *)pProfile, 0, sizeof(struct RMFPProfile));

		// set the magic again
		pProfile->magicNumber = RMFP_MAGIC_NUMBER;

	}
	else {
		// else, the application knows an old version of the profile, needs special handling
		RMNOTIFY((NULL, RM_ERROR, "We don't know how to handle this profile\n"));
		return RM_ERROR;
	}

	// Default options
	pProfile->options.use_http_caching = FALSE;

	return RM_OK;
}

RMstatus RMFPInitOptions(struct RMFPOptions *pOptions)
{
	ASSERT_NULL_POINTER(pOptions);

	RMDBGLOG((LOCALDBG, "RMFPInitOptions(@%p)\n", pOptions));

	RMMemset((void *)pOptions, 0, sizeof(struct RMFPOptions));

	// initialise the options
	rmfp_init_playback_options(&(pOptions->playback_options));

	rmfp_init_video_options(&(pOptions->video_options));

	rmfp_init_audio_options(&(pOptions->audio_options));

	rmfp_init_demux_options(&(pOptions->demux_options));

	rmfp_init_picture_options(&(pOptions->picture_options));

	return RM_OK;
}

RMstatus RMFPInitStreamType(struct RMFPStreamType *pStreamType)
{
	ASSERT_NULL_POINTER(pStreamType);

	RMDBGLOG((LOCALDBG, "RMFPInitStreamType(@%p)\n", pStreamType));

	pStreamType->application_type = RMFP_application_type_UNKNOWN;

	return RM_OK;

}

RMstatus RMFPOpenHandle(struct RMFPProfile *pProfile, struct RMFPHandle **ppHandle)
{
/*
	Perform any initialisation required for the underlying libraries.
	The libplay handle will be created here for example and it'll also
	be filled up, with for example what streams to play, etc.
*/
	RMstatus status;
	struct RMFPHandle *playbackHandle = NULL;
	struct RMLibPlayProfile rmlibplayProfile = { 0, };
	struct RMLibPlayHandle *pRMLibPlayHandle = NULL;

	ASSERT_NULL_POINTER(pProfile);
	ASSERT_NULL_POINTER(ppHandle);

	RMDBGLOG((LOCALDBG, "RMFPOpenHandle(@%p, @%p)\n", pProfile, ppHandle));

#ifdef WITH_THREADS
	RMDBGLOG((ENABLE, "RMFP is thread-safe\n"));
#else
	RMDBGLOG((ENABLE, "RMFP is NOT thread-safe!\n"));
#endif

	playbackHandle = (struct RMFPHandle *)RMMalloc(sizeof(struct RMFPHandle));
	if (!playbackHandle)
		return RM_FATALOUTOFMEMORY;


	RMMemset((void *)playbackHandle,  0, sizeof(struct RMFPHandle));

	// Default command execution status
	playbackHandle->command_execution_status = RMFPCommand_execution_status_completed;

	// assign callbacks: we want a local copy of the profile
	RMMemcpy((void *)&(playbackHandle->profile), (void *)pProfile, sizeof(struct RMFPProfile));

	/*
	  NOTE: after copying the profile, we make pProfile point to the copy so that we work
	  with the copy
	*/

	pProfile = &(playbackHandle->profile);

	rmlibplayProfile.magicNumber = RMLIBPLAY_MAGIC_NUMBER;

	// init rmlibplay profile
	status = RMLibPlayInitProfile(&rmlibplayProfile);
	if (status != RM_OK) {
		RMNOTIFY((NULL, status, "Failed to initialise libplay profile\n"));
		RMFPCloseHandle(playbackHandle);
		return status;
	}

	// Print callbacks availability
	rmfp_check_callback(pProfile);

	rmlibplayProfile.pRUA = pProfile->pRUA;
	rmlibplayProfile.pDCC = pProfile->pDCC;

	rmlibplayProfile.callback_context = (void *)playbackHandle;


	// control
	rmlibplayProfile.get_command			= rmfp_internal_get_command_handler;
	rmlibplayProfile.notify_command_status	= rmfp_internal_notify_command_status_handler;
	rmlibplayProfile.disk_control			= rmfp_internal_disk_control_handler;

	// signaling
	rmlibplayProfile.notify_available_commands		= rmfp_internal_notify_available_commands_handler;
	rmlibplayProfile.notify_playback_status			= rmfp_internal_notify_playback_status_handler;
	rmlibplayProfile.notify_playback_start			= rmfp_internal_notify_playback_start_handler;
	rmlibplayProfile.notify_playback_eos			= rmfp_internal_notify_playback_eos_handler;
	rmlibplayProfile.notify_current_streams_properties	= rmfp_internal_notify_current_streams_properties_handler;
	rmlibplayProfile.notify_stream_metadata			= rmfp_internal_notify_stream_metadata;
	rmlibplayProfile.notify_pat						= rmfp_internal_notify_pat_handler;
	rmlibplayProfile.notify_pmt				= rmfp_internal_notify_pmt_handler;
	
	rmlibplayProfile.notify_pid_creation			= rmfp_internal_notify_pid_creation_handler;
	rmlibplayProfile.notify_send_data				= rmfp_internal_notify_send_data_handler;
	rmlibplayProfile.notify_event					= rmfp_internal_notify_event_handler;
	rmlibplayProfile.notify_progress_callback		= rmfp_internal_notify_progress_handler;

	// New osd allocation
	rmlibplayProfile.rmlibplay_open_osd				= rmfp_internal_open_osd_handler;
	rmlibplayProfile.rmlibplay_close_osd			= rmfp_internal_close_osd_handler;
	rmlibplayProfile.rmlibplay_get_osd_picture		= rmfp_internal_get_osd_picture_handler;
	rmlibplayProfile.rmlibplay_set_osd_picture		= rmfp_internal_set_osd_picture_handler;

	// resource allocation
	rmlibplayProfile.rmlibplay_get_video_decoder	= rmfp_internal_get_video_decoder_handler;
	rmlibplayProfile.rmlibplay_get_audio_decoder	= rmfp_internal_get_audio_decoder_handler;
	rmlibplayProfile.rmlibplay_get_spu_decoder		= rmfp_internal_get_spu_decoder_handler;
	rmlibplayProfile.rmlibplay_get_dmapool			= rmfp_internal_get_dmapool_handler;
	rmlibplayProfile.rmlibplay_get_stc				= rmfp_internal_get_stc_handler;
	rmlibplayProfile.rmlibplay_get_ccfifo			= rmfp_internal_get_ccfifo_handler;
	rmlibplayProfile.rmlibplay_get_teletext			= rmfp_internal_get_teletext_handler;
	rmlibplayProfile.rmlibplay_get_demux_task		= rmfp_internal_get_demux_handler;
	rmlibplayProfile.rmlibplay_get_demux_output		= rmfp_internal_get_demux_output_handler;

	// resource surface
	rmlibplayProfile.rmlibplay_connect_surface		= rmfp_internal_connect_surface;
	rmlibplayProfile.rmlibplay_disconnect_surface	= rmfp_internal_disconnect_surface;

	// resource release
	rmlibplayProfile.rmlibplay_release_video_decoder	= rmfp_internal_release_video_decoder_handler;
	rmlibplayProfile.rmlibplay_release_audio_decoder	= rmfp_internal_release_audio_decoder_handler;
	rmlibplayProfile.rmlibplay_release_spu_decoder		= rmfp_internal_release_spu_decoder_handler;
	rmlibplayProfile.rmlibplay_release_dmapool		= rmfp_internal_release_dmapool_handler;
	rmlibplayProfile.rmlibplay_release_stc			= rmfp_internal_release_stc_handler;
	rmlibplayProfile.rmlibplay_release_ccfifo		= rmfp_internal_release_ccfifo_handler;
	rmlibplayProfile.rmlibplay_release_teletext		= rmfp_internal_release_teletext_handler;
	rmlibplayProfile.rmlibplay_release_demux_task		= rmfp_internal_release_demux_handler;
	rmlibplayProfile.rmlibplay_release_demux_output		= rmfp_internal_release_demux_output_handler;

	rmlibplayProfile.rmlibplay_refresh_ccfifo		= rmfp_internal_refresh_ccfifo_handler;
	rmlibplayProfile.rmlibplay_clear_ccfifo			= rmfp_internal_clear_ccfifo_handler;

	rmlibplayProfile.rmlibplay_teletext_decode		= rmfp_internal_teletext_decode;
	rmlibplayProfile.rmlibplay_teletext_flush		= rmfp_internal_teletext_flush;
	rmlibplayProfile.rmlibplay_teletext_refresh     	= rmfp_internal_teletext_refresh;

	rmlibplayProfile.rmlibplay_update_audio_decoder_outport = rmfp_internal_update_audio_decoder_outport;

	// NeroSPU
	rmlibplayProfile.rmlibplay_open_nero_spu		= rmfp_internal_open_nero_spu_handler;
	rmlibplayProfile.rmlibplay_blend_nero_spu		= rmfp_internal_blend_nero_spu_handler;
	rmlibplayProfile.rmlibplay_clear_nero_spu		= rmfp_internal_clear_nero_spu_handler;
	rmlibplayProfile.rmlibplay_close_nero_spu		= rmfp_internal_close_nero_spu_handler;

	rmlibplayProfile.rmlibplay_get_rmwmdrm_handle           = rmfp_internal_get_rmwmdrm_handle_handler;
	rmlibplayProfile.rmlibplay_release_rmwmdrm_handle       = rmfp_internal_release_rmwmdrm_handle_handler;

	rmlibplayProfile.rmlibplay_rmwmdrm_url_acquire_license  = rmfp_internal_rmwmdrm_acquire_url_license;

	// bdspu decoder
	rmlibplayProfile.rmlibplay_open_bdspu_decoder		= rmfp_internal_open_bdspu_decoder;
	rmlibplayProfile.rmlibplay_close_bdspu_decoder		= rmfp_internal_close_bdspu_decoder;
	rmlibplayProfile.rmlibplay_send_bdspu_decoder		= rmfp_internal_send_bdspu_decoder;
	rmlibplayProfile.rmlibplay_flush_bdspu_decoder		= rmfp_internal_flush_bdspu_decoder;

	// HLS
	if (pProfile->rmfp_hls_get_key_callback)
		rmlibplayProfile.rmlibplay_hls_get_key		= rmfp_internal_hls_get_key;

	rmlibplayProfile.get_video_scaler_callback = rmfp_internal_getVideoScalerModuleId;
	rmlibplayProfile.pfnRmoutputAudioEngine_setSampleFreq = RmfpInternal_AudioEngine_setSampleFreq;

	// init CURL handle, http cache
	playbackHandle->pCURLHandle = NULL;
	playbackHandle->pHttpCache = NULL;
	
	// Font rendering
	playbackHandle->pFontRenderHandle   = pProfile->pFontRenderHandle;
	playbackHandle->default_font_slotID = -1;
	playbackHandle->cc_font_slotID      = -1;

	rmlibplayProfile.pFontRenderHandle = playbackHandle->pFontRenderHandle;

	if (rmlibplayProfile.pFontRenderHandle) {

		// Add a default font if none
		if (!pProfile->pDefaultFontName) {

			status = RMFontRenderOpenFontSlot(rmlibplayProfile.pFontRenderHandle, rmfp_font_Vera, sizeof(rmfp_font_Vera), &playbackHandle->default_font_slotID);
			if (status != RM_OK) {
				RMNOTIFY((NULL, status, "Unable to add default font\n"));
				return status;
			}

			// set default font name in RMFP's profile
			pProfile->pDefaultFontName = rmfp_font_name_Vera;
		}

		// Add a CC font if none
		if (!pProfile->pCCFontName) {
			/* Add font */
			status = RMFontRenderOpenFontSlot(rmlibplayProfile.pFontRenderHandle, rmfp_font_Vera608, sizeof(rmfp_font_Vera608), &playbackHandle->cc_font_slotID);
			if (status != RM_OK) {
				RMNOTIFY((NULL, status, "Unable to add CC font\n"));
				return status;
			}

			// set default font name in RMFP's profile
			pProfile->pCCFontName = rmfp_font_name_Vera608;
		}

	}

	rmlibplayProfile.pDefaultFontName = pProfile->pDefaultFontName;
	rmlibplayProfile.pCCFontName	  = pProfile->pCCFontName;
	rmlibplayProfile.pForcedFontName  = pProfile->pForcedFontName;

	// open
	status = RMLibPlayOpenHandle(&rmlibplayProfile, &pRMLibPlayHandle);
	if (status != RM_OK) {
		RMNOTIFY((NULL, status, "Cannot open libplay handle\n"));
		RMFPCloseHandle(playbackHandle);
		return status;
	}

	RMDBGLOG((LOCALDBG, "rmfp @ %p rmlibplay @ %p\n", playbackHandle, pRMLibPlayHandle));

	playbackHandle->PrintPlaybackDebug = FALSE;
  // attach RMLibPlay handle to this RMFP handle

	playbackHandle->pRMLibPlayHandle = (void *)pRMLibPlayHandle;
	*ppHandle = playbackHandle;

	rmfp_print_struct_sizes();

	return RM_OK;
}

static void rmfp_print_struct_sizes(void)
{
#define PRINTSIZEOF(x) RMDBGLOG((PRINT_STRUCT_SIZES, "'%s' has size %lu\n", #x, sizeof(x)))

	PRINTSIZEOF(struct RMFPVideoResourcesProfile);
	PRINTSIZEOF(struct RMFPMultipleAudioResourcesProfile);
	PRINTSIZEOF(struct RMFPDemuxResourcesProfile);
	PRINTSIZEOF(struct RMFPDemuxOutputResourcesProfile);
	PRINTSIZEOF(struct RMFPSPUResourcesProfile);
	PRINTSIZEOF(struct RMFPCCFIFOResourcesProfile);
	PRINTSIZEOF(struct RMFPTTXResourcesProfile);
	PRINTSIZEOF(struct RMFPOSDSource);
	PRINTSIZEOF(struct RMFPSurfaceProfile);
	PRINTSIZEOF(struct RMFPPAT);
	PRINTSIZEOF(struct RMFPPMT);

	PRINTSIZEOF(struct RMFPStreamProperties);
	PRINTSIZEOF(struct RMFPStreamMetadata);

	PRINTSIZEOF(struct RMFPStreamInfo_Video);
	PRINTSIZEOF(struct RMFPStreamInfo_Audio);
	PRINTSIZEOF(struct RMFPStreamInfo_System);
	PRINTSIZEOF(struct RMFPStreamInfo_Data);
	PRINTSIZEOF(struct RMFPStreamInfo);
}

RMfile RMFPOpenURL(struct RMFPHandle *pHandle, const RMascii *pURL)
{
	RMfile fileHandle = NULL;

	if (!pURL) {
		RMNOTIFY((NULL, RM_FATALINVALIDPOINTER, "got NULL ptr for pURL!\n"));
		return NULL;
	}

	RMDBGLOG((LOCALDBG, "RMFPOpenURL(@%p, '%s')\n", pHandle, pURL));

	/* take care of CARDEA, DTCP, HTTP, etc... (rminputstream.c ...) */
	if (RMNCompareAsciiCaseInsensitively((const RMascii *) pURL, "http://", 7)  ||
		RMNCompareAsciiCaseInsensitively((const RMascii *) pURL, "https://", 8 )) {	
#ifdef	USE_RMLIBCURL
		RMfile uncached = NULL;
		RMstatus status = RM_ERROR;
	
		/*
		** Two cases:
		** 1. rmlibcurl loads, use rmlibcurl.
		** 2. rmlibcurl fails to load and url is HTTP://, use
		**      rmlibhttp for backwards compatibility.
		*/
		
		struct RMLibCURLHandle *pCURLHandle = NULL;
		
		/* Attempt to use RMLibCURL */
		status = RMLibCURLOpen(&pCURLHandle);
		
		if(RMFAILED(status)) {
			RMNOTIFY((NULL, status, "RMLibCURLOpen failed\n"));
			pCURLHandle = NULL;
		}
			
		if(pCURLHandle) {
			RMascii *pmodURL = NULL;
			RMascii user[CURL_MAX_AUTH_LEN];
			RMascii passw[CURL_MAX_AUTH_LEN];
			RMbool hasAuth = FALSE;
			struct RMLibCURLInfo urlInfo;

			/* Set SSL Certificate path */
			/* Passing NULL turns off HOST certificate verification. */
			status = RMLibCURLSetSSLCertificatePath( pCURLHandle,  LIBCURL_SSL_CERT_PATH);
			if(RMFAILED(status)) {
				RMNOTIFY((NULL, status, "RMLibCURLSetSSLCertificatePath() failed\n"));
				goto no_curl;
			}
		
			/* Check if url contains authentication info and pass it to libcurl */
			if (RMFindAsciiString (pURL,  "//" , &pmodURL)) {
				pmodURL+=2;
				hasAuth = (sscanf(pmodURL, "%" CURL_MAX_AUTH_LEN_TXT "[^:@]:" "%" CURL_MAX_AUTH_LEN_TXT "[^@]",  user, passw) == 2);
				if(hasAuth) {
					if( RMFAILED(RMLibCURLAuth( pCURLHandle, user, passw)) ) {
						RMNOTIFY((NULL, RM_ERROR, "RMLibCURLAuth() failed\n" ));
					}
				}
			}			
		
			/** TODO: Not sure how not including httpFileOps will affect
			** functionality. **/
			status = RMLibCURLOpenURL(pCURLHandle, (RMascii *)pURL, &uncached);
			if (RMFAILED(status)) {
				RMNOTIFY((NULL, status, "RMLibCURLOpenURL() failed\n"));
				goto no_curl;
			}
			
			fileHandle = uncached;

			/* Check if we are able to seek in the file before caching
			   if we want to change the cache for unseekable file.*/
			status = RMLibCURLGetInfo(fileHandle, RMLibCURLInfoType_IsSeekable, &urlInfo);
			if(status == RM_OK) {
				if(!urlInfo.parameter.isSeekable){
					RMDBGLOG((ENABLE, "Seek is disabled, force linear mode\n"));
					pHandle->playback_options.linear_mode = TRUE;
				}
			}

			/* use caching file handle if requested.  */
			if (pHandle->profile.options.use_http_caching) {
				const RMuint32 cache_buffer_num = 8;
				const RMuint32 cache_buffer_size = ( 1 << 17 );
				RMstatus cache_status = RM_ERROR;
				RMuint8 *pBuffer = NULL;
					
				pBuffer = RMMalloc( cache_buffer_size*cache_buffer_num );
				if( pBuffer == NULL) {
					RMDBGLOG((LOCALDBG,  "Failed to allocate cache buffer\n" ));
				}
				else {
					cache_status = RMFileCacheOpen( uncached,
							&fileHandle,
							pBuffer,
							cache_buffer_num,
							cache_buffer_size);
							
					if(RMFAILED(cache_status)) {
						RMDBGLOG((LOCALDBG, "RMFileCacheOpen() failed\n" ));
						RMFree(pBuffer);
						pBuffer = NULL;
					}
					
					pHandle->pHttpCache = pBuffer;
				}
				
				if( pHandle->pHttpCache == NULL) {
					RMNOTIFY((NULL, RM_ERROR, "Failed to setup http cache, continuing without\n"));
				}
			}
no_curl:
			if(RMFAILED(status)){
				RMLibCURLClose(pCURLHandle);
				pCURLHandle = NULL;
			}
			else {
				RMNOTIFY((NULL, status, "rmlibcurl successfully opened\n"));
			}
		}
		
		pHandle->pCURLHandle = pCURLHandle;
		
		if( pHandle->pCURLHandle == NULL) 
#endif	//USE_RMLIBCURL
		{
			/* Using librmhttp */
			HTTPFile *httpFile = NULL;
			RMuint32  options;
	
			/* Set options */
			options = 0;
			if (pHandle) {
				if (pHandle->profile.options.use_http_caching)
					options |= RM_HTTP_OPEN_CACHED;
			}
	
			/* Opening a HTTP stream */
			httpFile = fetchOpen((const RMascii *) pURL, options);
			if (httpFile == NULL)
				return NULL;
	
			fileHandle = RMOpenFileCookie(httpFile, RM_FILE_OPEN_READ, (RMFileOps *) httpFileOps);
			if (fileHandle == NULL) {
				fetchClose(httpFile);
				return NULL;
			}
		}
		return fileHandle;
	}
	else
		return RMOpenFile((const RMnonAscii *)pURL, RM_FILE_OPEN_READ);
}

RMstatus RMFPCloseURL(struct RMFPHandle *pHandle, RMfile fileHandle)
{
	RMstatus Status;

	ASSERT_NULL_POINTER(pHandle);
	ASSERT_NULL_POINTER(fileHandle);

	RMDBGLOG((LOCALDBG, "RMFPCloseURL(@%p, %p)\n", pHandle, fileHandle));

	// take care of CARDEA, DTCP, HTTP, etc... (rminputstream.c ...)

	Status = RMCloseFile(fileHandle);
	if (Status != RM_OK)
		RMNOTIFY((NULL, Status, "Failed to close filehandle %p\n", fileHandle));
		
	if( pHandle->pHttpCache != NULL) {
		RMFree(pHandle->pHttpCache);
		pHandle->pHttpCache = NULL;
	}
		
#ifdef	USE_RMLIBCURL
	if ( pHandle->pCURLHandle != NULL && (Status = RMLibCURLClose(pHandle->pCURLHandle)) != RM_OK) {
		RMDBGLOG((LOCALDBG, "RMLibCURLClose() failed\n" ));
	}
	else
	{
		pHandle->pCURLHandle = NULL;
	}
#endif	//USE_RMLIBCURL

	return Status;
}

RMstatus RMFPMain(struct RMFPHandle *pHandle,
				  RMfile fileHandle,
				  struct RMFPStreamType *pStreamType,
				  struct RMFPOptions *pOptions)
{
	RMstatus status;
	struct RMLibPlayOptions rmlibplay_options = { 0, };
/*
	The selected application's main loop will be started here.
	This would probably translate to only calling RMLibPlay_start or something.
*/

	ASSERT_NULL_POINTER(pHandle);
	ASSERT_NULL_POINTER(pOptions);

	RMDBGLOG((LOCALDBG, "RMFPMain(@%p)\n", pHandle));

	/* Check input parameters */
	status = rmfp_check_parameters_coherency(pHandle, pOptions, pStreamType);
	if (status != RM_OK){
		RMNOTIFY((NULL, status, "Paramters coherency check failed.\n"));
		return status;
	}

	// copy options to handle
	pHandle->playback_options = pOptions->playback_options;
	pHandle->video_options = pOptions->video_options;
	pHandle->audio_options = pOptions->audio_options;
	pHandle->demux_options = pOptions->demux_options;
	/* no need to copy pOptions->picture_options as it won't be further used by rmfp (only rmlibplay) */ 

	status = RMLibPlayInitOptions(&rmlibplay_options);
	if (status != RM_OK){
		RMNOTIFY((NULL, status, "Init options failed.\n"));
		return status;
	}

	status = rmfp_rmfp2rmlibplay_translate_options(pOptions, &rmlibplay_options);
	if (status != RM_OK){
		RMNOTIFY((NULL, status, "Cannot translate options.\n"));
		return status;
	}

	// open soft CC decoder
	if (pHandle->video_options.CloseCaptionMode == RMFPCloseCaptionMode_ShowInOSD) {
		RMDBGLOG((LOCALDBG, "open software close caption render\n"));
		status = rmfp_internal_open_softcc_render(pHandle);
		if (status != RM_OK) {
			RMNOTIFY((NULL, status, "Couldn't open soft CC render\n"));
			pHandle->video_options.CloseCaptionMode = RMFPCloseCaptionMode_Disabled;
		}
	}

	status = RMLibPlayMain(pHandle->pRMLibPlayHandle, fileHandle, pStreamType, &rmlibplay_options, pHandle->pStreamInfo);

	// close soft CC decoder
	if (pHandle->video_options.CloseCaptionMode == RMFPCloseCaptionMode_ShowInOSD) {
		RMstatus LocalStatus;
		RMDBGLOG((LOCALDBG, "close software close caption render\n"));
		LocalStatus = rmfp_internal_close_softcc_render(pHandle);
		if (LocalStatus != RM_OK)
			RMNOTIFY((NULL, LocalStatus, "Couldn't close softCC render\n"));
	}

 	return status;
}

RMstatus RMFPReleaseSource(struct RMFPHandle *pHandle)
{
	RMstatus err = RM_OK, iRetState;
	
	do{
		if(NULL == pHandle)
		{
			err = RM_INVALID_PARAMETER;
			break;
		}

		if (pHandle->video_options.CloseCaptionMode == RMFPCloseCaptionMode_ShowInOSD)
		{
			RMDBGLOG((LOCALDBG, "close software close caption render\n"));
			iRetState = rmfp_internal_close_softcc_render(pHandle);
			if (RM_OK != iRetState)
			{
				RMNOTIFY((NULL, iRetState, "Couldn't close softCC render\n"));
				err = iRetState;
				break;
			}
		}

		if(CC_LIKELY(pHandle->pRMLibPlayHandle))
		{
			iRetState = rmlibplay_uninit(pHandle->pRMLibPlayHandle);
			if(RM_OK != iRetState)
			{
				err = iRetState;
				break;
			}
		}
	}while(FALSE);

	return err;
}

RMstatus RMFPCloseHandle(struct RMFPHandle *pHandle)
{
	RMstatus status, eRMstatus;

	ASSERT_NULL_POINTER(pHandle);

	RMDBGLOG((LOCALDBG, "RMFPCloseHandle(@%p)\n", pHandle));

	if (pHandle->pFontRenderHandle) {
		// Close the added fonts
		if (pHandle->default_font_slotID != -1) {
			status = RMFontRenderCloseFontSlot(pHandle->pFontRenderHandle, pHandle->default_font_slotID);
			if (status != RM_OK)
				RMNOTIFY((NULL, status, "Unable to release font (%d)\n", pHandle->default_font_slotID));
		}
		if (pHandle->cc_font_slotID != -1) {
			status = RMFontRenderCloseFontSlot(pHandle->pFontRenderHandle, pHandle->cc_font_slotID);
			if (status != RM_OK)
				RMNOTIFY((NULL, status, "Unable to release font (%d)\n", pHandle->cc_font_slotID));
		}
	}

	if(pHandle->pStreamInfo)
	{
		eRMstatus = RMFPReleaseStreamInfo(pHandle, pHandle->pStreamInfo);
		if(RMFAILED(eRMstatus))
		{
			PRINT_BFILE_LINENO_RMSTATUS;
		}
		pHandle->pStreamInfo = NULL;
	}

	status = RMLibPlayCloseHandle(pHandle->pRMLibPlayHandle);
	pHandle->pRMLibPlayHandle = NULL;

	RMFree(pHandle);

	return status;
}

RMstatus RMFPSendCommand(struct RMFPHandle *pHandle, struct RMFPPlaybackCommand *pCommand)
{
	struct RMFPCommandStatus null_command_status = {0, };

	ASSERT_NULL_POINTER(pHandle);
	ASSERT_NULL_POINTER(pCommand);

	RMDBGLOG((LOCALDBG, "RMFPSendCommand(@%p, @%p)\n", pHandle, pCommand));

	/* Check if we are in polling mode */
	if (pHandle->profile.rmfp_get_command_callback)
	{
		RMNOTIFY((NULL, ENABLE, "Unable to send a command, we are in polling mode\n"));
		return RM_ERROR;
	}

	/* Is there a command already in progress */
	if (pHandle->command_execution_status != RMFPCommand_execution_status_completed)
		return RM_PENDING;

	/* Send the command */
	pHandle->command = *pCommand;
	pHandle->command_status = null_command_status;
	pHandle->command_execution_status = RMFPCommand_execution_status_to_be_processed;

	return RM_OK;
}

RMstatus RMFPWaitForCommandCompletion(struct RMFPHandle *pHandle,
									  struct RMFPCommandStatus *pCommandStatus,
									  RMuint32 timeout_ms)
{
	RMuint64 ref_time_us;

	ASSERT_NULL_POINTER(pHandle);
	ASSERT_NULL_POINTER(pCommandStatus);

	RMDBGLOG((LOCALDBG, "RMFPWaitForCommandAnwser(@%p, @%p)\n", pHandle, pCommandStatus));

	/* Check if we are in polling mode */
	if (pHandle->profile.rmfp_get_command_callback)
	{
		RMNOTIFY((NULL, ENABLE, "Unable to send a command, we are in polling mode\n"));
		return RM_ERROR;
	}

	/* Get reference time */
	ref_time_us = RMGetTimeInMicroSeconds();

	/* Wait for command completion */
	do
	{
		/* Command completed */
		if (pHandle->command_execution_status == RMFPCommand_execution_status_completed)
		{
			*pCommandStatus = pHandle->command_status;
			return RM_OK;
		}

		RMMicroSecondSleep(1000);

	} while ((RMGetTimeInMicroSeconds() - ref_time_us) < (timeout_ms*1000));

	return RM_TIMEOUT;

}

RMstatus RMFPAddEvents(struct RMFPHandle *pHandle, struct RUAEvent *pEvents, RMuint32 eventCount)
{
	ASSERT_NULL_POINTER(pHandle);

	return RMLibPlayAddEvents(pHandle->pRMLibPlayHandle, pEvents, eventCount);
}

RMstatus RMFPRemoveEvents(struct RMFPHandle *pHandle, struct RUAEvent *pEvents, RMuint32 eventCount)
{
	ASSERT_NULL_POINTER(pHandle);

	return RMLibPlayAddEvents(pHandle->pRMLibPlayHandle, pEvents, eventCount);
}


RMstatus RMFPGetPlaybackTime(struct RMFPHandle *pHandle, RMuint32 *pTime)
{
	ASSERT_NULL_POINTER(pHandle);
	ASSERT_NULL_POINTER(pTime);

	return RMLibPlayGetPlaybackTime(pHandle->pRMLibPlayHandle, pTime);
}

RMstatus RMFPCreateCustomPIDFilter(struct RMFPHandle *pHandle, struct RMFPCustomPIDParameters* pParams, RMuint32 *pPidHandle)
{
	ASSERT_NULL_POINTER(pHandle);
	
	return RMLibPlayCreateCustomPIDFilter(pHandle->pRMLibPlayHandle, pParams, pPidHandle);
}

RMstatus RMFPDeleteCustomPIDFilter(struct RMFPHandle *pHandle, RMuint32 PidHandle)
{
	ASSERT_NULL_POINTER(pHandle);
	
	return RMLibPlayDeleteCustomPIDFilter(pHandle->pRMLibPlayHandle, PidHandle);
}

RMstatus RMFPAddCustomPIDFilterSection(struct RMFPHandle *pHandle, RMuint32 PidHandle, struct PSFMatchSection_type* pSection)
{
	ASSERT_NULL_POINTER(pHandle);
	
	return RMLibPlayAddCustomPIDFilterSection(pHandle->pRMLibPlayHandle, PidHandle, pSection);
}

RMstatus RMFPDeleteCustomPIDFilterSection(struct RMFPHandle *pHandle, RMuint32 PidHandle, struct PSFMatchSection_type* pSection)
{
	ASSERT_NULL_POINTER(pHandle);
	
	return RMLibPlayDeleteCustomPIDFilterSection(pHandle->pRMLibPlayHandle, PidHandle, pSection);
}

RMstatus RMFPGetPlaybackStatistic(struct RMFPHandle *pHandle, struct RMFPPlaybackStatistic* pStat)
{
	RMstatus err;

	ASSERT_NULL_POINTER(pHandle);
	ASSERT_NULL_POINTER(pStat);

	err = RMLibPlayGetPlaybackStatistic(pHandle->pRMLibPlayHandle, pStat);

	if (RMFAILED(err))
		return err;

	return RM_OK;
}


/***********************************************************************************************************
  DETECTION API
************************************************************************************************************/

// in order to avoid cluttering rmfp.c with detection specific routines we put them in rmfp_detection.c



RMstatus RMFPGetStreamInfo(struct RMFPHandle *pHandle,
			   RMfile fileHandle,
			   const RMascii *pFilename,
			   RMint32 ParsingLength,
			   RMbool AvoidSeeking,
			   struct RMFPStreamType *pStreamType,
			   struct RMFPStreamInfo **ppStreamInfo)
{

	return rmfp_internal_get_stream_info(pHandle,
					     fileHandle,
					     pFilename,
					     ParsingLength,
					     AvoidSeeking,
					     pStreamType,
					     ppStreamInfo);
}


RMstatus RMFPApplyStreamInfoToOptions(struct RMFPHandle *pHandle,
				      RMfile fileHandle,
				      struct RMFPStreamType *pStreamType,
				      struct RMFPStreamInfo *pStreamInfo,
				      struct RMFPOptions *pOptions)
{

	return rmfp_internal_apply_stream_info_to_options( pHandle,
							   fileHandle,
							   pStreamType,
							   pStreamInfo,
							   pOptions);
}


RMstatus RMFPReleaseStreamInfo(struct RMFPHandle *pHandle, struct RMFPStreamInfo *pStreamInfo)
{
	return rmfp_internal_release_stream_info(pHandle, pStreamInfo);
}

RMstatus RMFPReleaseStreamInfo2(struct RMFPStreamInfo *pStreamInfo)
{
	return rmfp_internal_release_stream_info2(pStreamInfo);
}


/***********************************************************************************************************
  PREFETCH API
************************************************************************************************************/

// in order to avoid cluttering rmfp.c with prefetch specific routines we put them in rmfp_prefetch.c


RMstatus RMFPPrefetchInit(struct RMFPHandle *pHandle, struct RMFPPrefetchProfile *pProfile)
{

	return rmfp_internal_prefetch_init(pHandle, pProfile);
}

RMstatus RMFPPrefetchGetResources(struct RMFPHandle *pHandle, struct RMFPPrefetchResources *pResources)
{

	return rmfp_internal_prefetch_get_resources(pHandle, pResources);
}

RMstatus RMFPPrefetchUninit(struct RMFPHandle *pHandle)
{

	return rmfp_internal_prefetch_uninit(pHandle);
}

RMstatus RMFPPrefetchOpenFile(struct RMFPHandle *pHandle, RMfile InputFileHandle, RMfile *pPrefetchedFileHandle)
{

	return rmfp_internal_prefetch_open_file(pHandle, InputFileHandle, pPrefetchedFileHandle);
}

RMstatus RMFPPrefetchStart(struct RMFPHandle *pHandle, RMfile PrefetchedFileHandle)
{
	return rmfp_internal_prefetch_start(pHandle, PrefetchedFileHandle, 0);
}

RMstatus RMFPPrefetchStart_WithTimeout(struct RMFPHandle *pHandle, RMfile PrefetchedFileHandle, RMuint32 timeout)
{
	return rmfp_internal_prefetch_start(pHandle, PrefetchedFileHandle, timeout);
}

RMstatus RMFPPrefetchStop(struct RMFPHandle *pHandle, RMfile PrefetchedFileHandle)
{
	return rmfp_internal_prefetch_stop(pHandle, PrefetchedFileHandle);
}


/***********************************************************************************************************
  INTERNAL FUNCTIONS


  Some of them will be called from within RMLibPlay and here we will either redirect them (after parameter and
  context translation) to the application using RMFP or handle them internally.

  Some other are for internal use (such as the translation functions)


************************************************************************************************************/

static RMstatus rmfp_init_playback_options(struct RMFPPlayOptions *pOptions)
{
	ASSERT_NULL_POINTER(pOptions);

	RMMemset((void*)pOptions, 0, sizeof(struct RMFPPlayOptions));

	pOptions->STCIndex   = RMFP_DEFAULT_STC_INDEX;
	pOptions->STCEngine  = RMFP_DEFAULT_STC_ENGINE;
	pOptions->DRAMIndex  = RMFP_DEFAULT_DRAM_CONTROLLER_INDEX;

	pOptions->duration = 0;

	pOptions->send_audio = TRUE;
	pOptions->send_video = TRUE;
	pOptions->send_spu = TRUE;

	pOptions->send_audio_pts = TRUE;
	pOptions->send_video_pts = TRUE;
	pOptions->send_spu_pts = TRUE;

	pOptions->save_video_file_handle = NULL;
	pOptions->save_audio_file_handle = NULL;
	pOptions->save_spu_file_handle = NULL;

	pOptions->savems = FALSE;

	pOptions->speed_N = 1;
	pOptions->speed_M = 1;

	pOptions->stc_offset_ms = -100;

	pOptions->require_video_audio = TRUE;

	pOptions->dmapool_count = 0;
	pOptions->dmapool_log2size = 0;

	pOptions->prebuf_max = (16*1024);

	pOptions->enable_disk_control = FALSE;
	pOptions->disk_ctrl_low_level = 0;
	pOptions->disk_ctrl_buffer_size = 0;

	pOptions->send_audio_trickmode = FALSE;
	pOptions->fast_audio_recovery = TRUE;
	pOptions->accurate_seek = TRUE;

	pOptions->linear_mode = FALSE;

	pOptions->stc_compensation = FALSE;
	pOptions->vcxo_index = -1;
	pOptions->reset_vcxo = RMFPVcxoReset_None;

	pOptions->pCARDEAHandle    = NULL;
	pOptions->pCARDEAURLHandle = NULL;

	pOptions->PictureFormat = 0;

	pOptions->subidx_sub_file_handle = NULL;
	pOptions->subidx_idx_file_handle = NULL;
	pOptions->subidx_index = 0;

	pOptions->external_subs_delayms = 0;

	pOptions->subtitles_track = -1;
	pOptions->enable_spu = TRUE;

	pOptions->WaitExit = FALSE;

#if (EM86XX_CHIP < EM86XX_CHIPID_TANGO3)
	/* On chips < tango3, disable by default SSS animations */
	pOptions->disable_ssa_animations = TRUE;
#endif

	pOptions->watermark = FALSE;

	pOptions->IgnoreEOS = FALSE;
	pOptions->ReindexMKV = FALSE;

	pOptions->cacheMP4Indexes = FALSE;
	pOptions->force_linear_interleaving = FALSE;

	pOptions->unseekable_file = FALSE;

	pOptions->hls_key_url_options = NULL;
	pOptions->hls_key_encoding = RMFPHLSKeyEncoding_NONE;
	pOptions->hls_key_key = NULL;
	pOptions->hls_key_iv = NULL;
	pOptions->hls_base64_key = FALSE;
	pOptions->hls_type = RMFPHLSType_UNKNOWN;
	pOptions->hls_thread_cache_memory = 0;
	pOptions->hls_autoswitch_set_window = FALSE;
	pOptions->hls_up_window_percentage = 0;
	pOptions->hls_down_window_percentage = 0;

	pOptions->rebuffering_type = RMFPRebufferingMode_DISABLED;
	pOptions->rebuf_alow	= -1L;
	pOptions->rebuf_vlow	= -1L;
	pOptions->rebuf_ahigh	= -1L;
	pOptions->rebuf_vhigh	= -1L;
	pOptions->rebuf_fullness= -1L;
	pOptions->rebuf_timeout = -1L;

	pOptions->read_timeout = 400;

	pOptions->liteindex_enable = FALSE;
	pOptions->liteindex_kickstart = 0;
	pOptions->liteindex_trickfactor = 0;

	pOptions->start_offset_type = RMFPStartOffset_none;
	pOptions->start_offset_use_accurate_seek = FALSE;

	return RM_OK;
}

/*************************************************************************************************/
/* Initialisation of video options
 * Some are initialized with bad value if compulsory*/
static RMstatus rmfp_init_video_options(struct RMFPVideoOptions *pOptions)
{
	ASSERT_NULL_POINTER(pOptions);

	RMMemset((void*)pOptions, 0, sizeof(struct RMFPVideoOptions));

	pOptions->CCFIFOEntryCount = 256;

	pOptions->EngineIndex       = RMFP_DEFAULT_VIDEO_ENGINE_INDEX;
	pOptions->DecoderIndex      = RMFP_DEFAULT_VIDEO_DECODER_INDEX;
	pOptions->VideoScalerID     = 0;

	pOptions->fifo_size = 0;
	pOptions->xfer_count = 0;

	pOptions->vcodec                = 0;
	pOptions->vcodec_max_width      = 0;
	pOptions->vcodec_max_height     = 0;
	pOptions->vcodec_profile        = 0;
	pOptions->vcodec_level          = 0;
	pOptions->vcodec_extra_pictures = 0;

	pOptions->video_track = -1;

	pOptions->skipNCP = FALSE;

	/* default CC is TV */
	pOptions->CloseCaptionMode    = RMFPCloseCaptionMode_Disabled;
	pOptions->CloseCaptionType    = RMFPCloseCaptionType_EIA608;
	pOptions->CloseCaptionSelect  = EMhwlibCCSelect_CC1;

	pOptions->PTSTimeScale      = 0;
	pOptions->ForcePTSTimeScale = FALSE;

	pOptions->PTSTimeIncrement  = 0;
	pOptions->ForceTiming       = FALSE;

	pOptions->force_input_color_space = FALSE;
	pOptions->input_color_space = 0; //EMhwlibColorSpace_YUV_601;

	pOptions->MSflag = FALSE;
	pOptions->wmv9_seq = 0;

	pOptions->input_scan_mode = EMhwlibScanMode_Source;

	pOptions->display_error_threshold = 0;
	pOptions->anchor_error_propagation.AnchorErrPropagationThreshold = 500;
	pOptions->anchor_error_propagation.AnchorErrPropagationLength = 13;

	pOptions->interlaced_progressive_algorithm = INTERLACED_PROGRESSIVE_ALGORITHM_USING_DECODER_SPECIFICATION;

	pOptions->ForceAFD = FALSE;  // force Active Format Descriptor for content
	pOptions->afd.ActiveFormatValid = FALSE;
	pOptions->afd.ActiveFormat = EMhwlibAF_same_as_picture;
	pOptions->ForceAsp = FALSE;
	pOptions->ForceBarInfo = FALSE;
	pOptions->ForceScanInfo = FALSE;
	pOptions->Force3D = FALSE;

	pOptions->pp_enabled = FALSE;
	
	pOptions->cs_algo = EMhwlibDefaultColorSpaceAlgoritm_SD601_HD709;

	pOptions->rm_no_deblock = FALSE;
	pOptions->rm_no_B_deblock = FALSE;

	pOptions->ForceMaxMem = FALSE;

        pOptions->custom_memunp         = 0;

	return RM_OK;
}

/*************************************************************************************************/
/* Initialisation of audio options
 * Some are initialized with bad value if compulsory*/
static RMstatus rmfp_init_audio_options(struct RMFPAudioOptions *pOptions)
{
	ASSERT_NULL_POINTER(pOptions);

	RMMemset((void*)pOptions, 0, sizeof(struct RMFPAudioOptions));

	pOptions->EngineIndex  = RMFP_DEFAULT_AUDIO_ENGINE_INDEX;
	pOptions->DecoderIndex = RMFP_DEFAULT_AUDIO_DECODER_INDEX;
	pOptions->ChannelServiceIndex = RMFP_DEFAULT_CHANNEL_SERVICE_INDEX;

	/* This tree options need to be set */
	pOptions->Codec = 0;
	pOptions->SubCodec = 0xFF;
	pOptions->PCMSamplingFrequency = 0;
	pOptions->ChannelAssign = 0;

	pOptions->audio_track = -1;

	pOptions->SignedPCM = TRUE;

	pOptions->DownSample = FALSE;


	pOptions->Acmod2DualMode = FALSE;
	pOptions->CompMode = CompMode_line_out;
	pOptions->DynScaleHi = 0x10000000;
	pOptions->DynScaleLo = 0x10000000;
	pOptions->PcmScale = 0x10000000;

	pOptions->DTS_CD = FALSE;

	pOptions->bit_per_sample = 0;
	pOptions->MsbFirst = TRUE;


	pOptions->TToneType = Ttone_WhiteNoise;
	pOptions->TToneChannelMask = 0xff;

	pOptions->fifo_size = 0;
	pOptions->xfer_count = 0;

	pOptions->skip_first_n_bytes = 0;
	pOptions->send_n_bytes = 0;


	pOptions->chconfig = 2;
	pOptions->drcenable = 1;
	pOptions->drcboost = 100;
	pOptions->drccut = 100;
	pOptions->drcdialref = -31;
	pOptions->lossless = FALSE;

	pOptions->audio_play_time.PlayMode = 0;
	pOptions->audio_play_time.PlayStartPTS = 0;
	pOptions->audio_play_time.PlayEndPTS = 0;


	pOptions->sync_stc = TRUE;

	/* Always 1 by default */
	pOptions->nb_audio_instances = 1;
	
	pOptions->afs = TRUE;
	
	return RM_OK;
}

/*************************************************************************************************/

static RMstatus rmfp_init_demux_options(struct RMFPDemuxOptions *pOptions)
{
	ASSERT_NULL_POINTER(pOptions);

	RMMemset((void*)pOptions, 0, sizeof(struct RMFPDemuxOptions));

	pOptions->section_filter_based_on_new_version = RMFP_DEFAULT_SECTION_FILTER_MASK;
	pOptions->repack_sample = TRUE;
	pOptions->idle_port = 0xff;
	pOptions->iterative_seek = FALSE;

	pOptions->TeletextMode = RMFPTeletextMode_Disabled;

	pOptions->pcr_disc = 0xffffffff;
	pOptions->wait_for_pcr_time_ms = 0xffffffff;
	pOptions->pts_taken_as_pcr_offset_ms = 0xffffffff;

	return RM_OK;
}

static RMstatus rmfp_init_picture_options(struct RMFPPictureOptions *pOptions)
{
	ASSERT_NULL_POINTER(pOptions);

	RMMemset((void*)pOptions, 0, sizeof(struct RMFPPictureOptions));

	pOptions->alpha = 0xff;
	pOptions->force_rgb = FALSE;
	pOptions->ignore_picture_alpha_channel = FALSE;
	pOptions->yuv_width = 0;
  	pOptions->yuv_height = 0;
  	pOptions->yuv_sampling_mode = EMhwlibSamplingMode_None;
  	pOptions->yuv_has_alpha = FALSE;

	return RM_OK;
}

/*************************************************************************************************/

static RMstatus rmfp_rmfp2rmlibplay_translate_audio_options(struct RMFPAudioOptions *pInAudioOptions, 
															struct RMLibPlayAudioOptions *pOutAudioOptions)
{
	//RMmustBeEqual(sizeof(struct RMFPAudioOptions), 592, RMFPAudioOptions);
	//RMmustBeEqual(sizeof(struct RMLibPlayAudioOptions), 584, RMLibPlayAudioOptions);

	RMDBGLOG((LOCALDBG, "size of RMFPAudioOptions %lu\n", sizeof(struct RMFPAudioOptions)));
	RMDBGLOG((LOCALDBG, "size of RMLibPlayAudioOptions %lu\n", sizeof(struct RMLibPlayAudioOptions)));

	ASSERT_NULL_POINTER(pInAudioOptions);
	ASSERT_NULL_POINTER(pOutAudioOptions);


	pOutAudioOptions->Codec = pInAudioOptions->Codec;
	pOutAudioOptions->SubCodec = pInAudioOptions->SubCodec;

	pOutAudioOptions->PCMSamplingFrequency = pInAudioOptions->PCMSamplingFrequency;

	pOutAudioOptions->ChannelAssign = pInAudioOptions->ChannelAssign;

	pOutAudioOptions->audio_track = pInAudioOptions->audio_track;


	pOutAudioOptions->fifo_size = pInAudioOptions->fifo_size;
	pOutAudioOptions->xfer_count = pInAudioOptions->xfer_count;

	pOutAudioOptions->MsbFirst = pInAudioOptions->MsbFirst;
	pOutAudioOptions->bit_per_sample = pInAudioOptions->bit_per_sample;

	pOutAudioOptions->send_n_bytes = pInAudioOptions->send_n_bytes;
	pOutAudioOptions->skip_first_n_bytes = pInAudioOptions->skip_first_n_bytes;

	pOutAudioOptions->Acmod2DualMode = pInAudioOptions->Acmod2DualMode;
	pOutAudioOptions->DynScaleHi = pInAudioOptions->DynScaleHi;
	pOutAudioOptions->DynScaleLo = pInAudioOptions->DynScaleLo;
	pOutAudioOptions->CompMode = pInAudioOptions->CompMode;
	pOutAudioOptions->PcmScale = pInAudioOptions->PcmScale;

	pOutAudioOptions->SignedPCM = pInAudioOptions->SignedPCM;
	pOutAudioOptions->DownSample = pInAudioOptions->DownSample;


	RMMemcpy(&pOutAudioOptions->audio_play_time, &pInAudioOptions->audio_play_time, sizeof(struct AudioDecoder_AudioPlayTime_type));

	pOutAudioOptions->chconfig = pInAudioOptions->chconfig;
	pOutAudioOptions->drcenable = pInAudioOptions->drcenable;
	pOutAudioOptions->drcboost = pInAudioOptions->drcboost;
	pOutAudioOptions->drccut = pInAudioOptions->drccut;
	pOutAudioOptions->drcdialref = pInAudioOptions->drcdialref;
	pOutAudioOptions->lossless = pInAudioOptions->lossless;


	pOutAudioOptions->sync_stc = pInAudioOptions->sync_stc;
	pOutAudioOptions->TToneChannelMask = pInAudioOptions->TToneChannelMask;
	pOutAudioOptions->TToneType = pInAudioOptions->TToneType;

	pOutAudioOptions->ChannelServiceIndex    = pInAudioOptions->ChannelServiceIndex;

	return RM_OK;
}

static RMstatus rmfp_rmfp2rmlibplay_translate_video_options(struct RMFPVideoOptions *pInVideoOptions,
															struct RMLibPlayVideoOptions *pOutVideoOptions)
{
	//RMmustBeEqual(sizeof(struct RMFPVideoOptions), 592, RMFPVideoOptions);
	//RMmustBeEqual(sizeof(struct RMLibPlayVideoOptions), 584, RMLibPlayVideoOptions);

	RMDBGLOG((LOCALDBG, "size of RMFPVideoOptions %lu\n", sizeof(struct RMFPVideoOptions)));
	RMDBGLOG((LOCALDBG, "size of RMLibPlayVideoOptions %lu\n", sizeof(struct RMLibPlayVideoOptions)));

	ASSERT_NULL_POINTER(pInVideoOptions);
	ASSERT_NULL_POINTER(pOutVideoOptions);

	pOutVideoOptions->fifo_size  = pInVideoOptions->fifo_size;
	pOutVideoOptions->xfer_count = pInVideoOptions->xfer_count;

	pOutVideoOptions->vcodec                = pInVideoOptions->vcodec;
	pOutVideoOptions->vcodec_max_width      = pInVideoOptions->vcodec_max_width;
	pOutVideoOptions->vcodec_max_height     = pInVideoOptions->vcodec_max_height;
	pOutVideoOptions->vcodec_profile        = pInVideoOptions->vcodec_profile;
	pOutVideoOptions->vcodec_level          = pInVideoOptions->vcodec_level;
	pOutVideoOptions->vcodec_extra_pictures = pInVideoOptions->vcodec_extra_pictures;


	pOutVideoOptions->skipNCP                        = pInVideoOptions->skipNCP;

	pOutVideoOptions->video_track                     = pInVideoOptions->video_track;

	//pOutVideoOptions->vtimescale.enable              = pInVideoOptions->vtimescale.enable;
	//pOutVideoOptions->vtimescale.time_resolution     = pInVideoOptions->vtimescale.time_resolution;
	//pOutVideoOptions->VopInfo.FixedVopTimeIncrement  = pInVideoOptions->VopInfo.FixedVopTimeIncrement;
	//pOutVideoOptions->VopInfo.VopTimeIncrementResolution  = pInVideoOptions->VopInfo.VopTimeIncrementResolution;
	//pOutVideoOptions->VopInfo.FixedVopRate           = pInVideoOptions->VopInfo.FixedVopRate;

	pOutVideoOptions->PTSTimeScale      = pInVideoOptions->PTSTimeScale;
	pOutVideoOptions->ForcePTSTimeScale = pInVideoOptions->ForcePTSTimeScale;

	pOutVideoOptions->PTSTimeIncrement  = pInVideoOptions->PTSTimeIncrement;
	pOutVideoOptions->ForceTiming       = pInVideoOptions->ForceTiming;


	pOutVideoOptions->CCFIFOEntryCount   = pInVideoOptions->CCFIFOEntryCount;
	pOutVideoOptions->CloseCaptionSelect = pInVideoOptions->CloseCaptionSelect;
	pOutVideoOptions->CloseCaptionType   = pInVideoOptions->CloseCaptionType;
	pOutVideoOptions->CloseCaptionMode   = pInVideoOptions->CloseCaptionMode;

	pOutVideoOptions->pp_enabled                     = pInVideoOptions->pp_enabled;

	pOutVideoOptions->rm_no_deblock      = pInVideoOptions->rm_no_deblock;
	pOutVideoOptions->rm_no_B_deblock    = pInVideoOptions->rm_no_B_deblock;

	pOutVideoOptions->EngineIndex      = pInVideoOptions->EngineIndex;
	pOutVideoOptions->DecoderIndex    = pInVideoOptions->DecoderIndex;

	return RM_OK;
}


static RMstatus rmfp_rmfp2rmlibplay_translate_playback_options(struct RMFPPlayOptions *pInPlaybackOptions,
															   struct RMLibPlayPlaybackOptions *pOutPlaybackOptions)
{
	RMuint32 cnt;

	//RMmustBeEqual(sizeof(struct RMFPPlayOptions), 592, RMFPPlayOptions);
	//RMmustBeEqual(sizeof(struct RMLibPlayPlaybackOptions), 584, RMLibPlayPlaybackOptions);

	RMDBGLOG((LOCALDBG, "size of RMFPPlayOptions %lu\n", sizeof(struct RMFPPlayOptions)));
	RMDBGLOG((LOCALDBG, "size of RMLibPlayPlaybackOptions %lu\n", sizeof(struct RMLibPlayPlaybackOptions)));

	ASSERT_NULL_POINTER(pInPlaybackOptions);
	ASSERT_NULL_POINTER(pOutPlaybackOptions);

	pOutPlaybackOptions->dmapool_count             = pInPlaybackOptions->dmapool_count;
	pOutPlaybackOptions->dmapool_log2size          = pInPlaybackOptions->dmapool_log2size;
	pOutPlaybackOptions->duration                  = pInPlaybackOptions->duration;
	pOutPlaybackOptions->enable_disk_control       = pInPlaybackOptions->enable_disk_control;
	pOutPlaybackOptions->disk_ctrl_low_level       = pInPlaybackOptions->disk_ctrl_low_level;
	pOutPlaybackOptions->disk_ctrl_buffer_size     = pInPlaybackOptions->disk_ctrl_buffer_size;
	pOutPlaybackOptions->fast_audio_recovery       = pInPlaybackOptions->fast_audio_recovery;
	pOutPlaybackOptions->accurate_seek             = pInPlaybackOptions->accurate_seek;
	pOutPlaybackOptions->linear_mode               = pInPlaybackOptions->linear_mode;
	pOutPlaybackOptions->prebuf_max                = pInPlaybackOptions->prebuf_max;
	pOutPlaybackOptions->require_video_audio       = pInPlaybackOptions->require_video_audio;
	pOutPlaybackOptions->save_audio_file_handle    = pInPlaybackOptions->save_audio_file_handle;
	pOutPlaybackOptions->save_spu_file_handle      = pInPlaybackOptions->save_spu_file_handle;
	pOutPlaybackOptions->save_video_file_handle    = pInPlaybackOptions->save_video_file_handle;
	pOutPlaybackOptions->savems                    = pInPlaybackOptions->savems;
	pOutPlaybackOptions->send_audio                = pInPlaybackOptions->send_audio;
	pOutPlaybackOptions->send_audio_pts            = pInPlaybackOptions->send_audio_pts;
	pOutPlaybackOptions->send_audio_trickmode      = pInPlaybackOptions->send_audio_trickmode;
	pOutPlaybackOptions->send_spu                  = pInPlaybackOptions->send_spu;
	pOutPlaybackOptions->send_spu_pts              = pInPlaybackOptions->send_spu_pts;
	pOutPlaybackOptions->send_video                = pInPlaybackOptions->send_video;
	pOutPlaybackOptions->send_video_pts            = pInPlaybackOptions->send_video_pts;
	pOutPlaybackOptions->speed_N                   = pInPlaybackOptions->speed_N;
	pOutPlaybackOptions->speed_M                   = pInPlaybackOptions->speed_M;
	pOutPlaybackOptions->stc_offset_ms             = pInPlaybackOptions->stc_offset_ms;
	pOutPlaybackOptions->stc_compensation          = pInPlaybackOptions->stc_compensation;

	pOutPlaybackOptions->pCARDEAHandle             = pInPlaybackOptions->pCARDEAHandle;
	pOutPlaybackOptions->pCARDEAURLHandle          = pInPlaybackOptions->pCARDEAURLHandle;
	pOutPlaybackOptions->pDTCPURLHandle            = pInPlaybackOptions->pDTCPURLHandle;
	pOutPlaybackOptions->DTCPUseDemuxForDecryption = pInPlaybackOptions->DTCPUseDemuxForDecryption;

	switch (pInPlaybackOptions->PictureFormat) {
	case RMFPPictureFormat_BMP:
		pOutPlaybackOptions->PictureFormat = RMLibPlayPictureFormat_BMP; break;
	case RMFPPictureFormat_JPEG:
		pOutPlaybackOptions->PictureFormat = RMLibPlayPictureFormat_JPEG; break;
	case RMFPPictureFormat_GIF:
		pOutPlaybackOptions->PictureFormat = RMLibPlayPictureFormat_GIF; break;
	case RMFPPictureFormat_PNG:
		pOutPlaybackOptions->PictureFormat = RMLibPlayPictureFormat_PNG; break;
	case RMFPPictureFormat_YUV:
		pOutPlaybackOptions->PictureFormat = RMLibPlayPictureFormat_YUV; break;
	case RMFPPictureFormat_TEST:
		pOutPlaybackOptions->PictureFormat = RMLibPlayPictureFormat_TEST; break;
	}

        if (pInPlaybackOptions->text_subs.count > RMLIBPLAY_MAX_TEXT_SUBS)
        {
                RMDBGLOG((ENABLE, "Warning : using only %d text subs\n", RMLIBPLAY_MAX_TEXT_SUBS, pInPlaybackOptions->text_subs.count));
                pOutPlaybackOptions->text_subs.count = RMLIBPLAY_MAX_TEXT_SUBS;
        }
	else
		pOutPlaybackOptions->text_subs.count = pInPlaybackOptions->text_subs.count;

        for (cnt=0; cnt<pOutPlaybackOptions->text_subs.count; cnt++)
        {
		pOutPlaybackOptions->text_subs.entry[cnt].file_handle  = pInPlaybackOptions->text_subs.entry[cnt].file_handle;
		pOutPlaybackOptions->text_subs.entry[cnt].description = pInPlaybackOptions->text_subs.entry[cnt].description;
		switch (pInPlaybackOptions->text_subs.entry[cnt].type)
		{
			case RMLibPlayTextSubs_ASCII: pOutPlaybackOptions->text_subs.entry[cnt].type = RMFPTextSubs_ASCII; break;
			case RMLibPlayTextSubs_UTF8: pOutPlaybackOptions->text_subs.entry[cnt].type = RMFPTextSubs_UTF8; break;
			case RMLibPlayTextSubs_SSA: pOutPlaybackOptions->text_subs.entry[cnt].type = RMFPTextSubs_SSA; break;
			case RMLibPlayTextSubs_ASS: pOutPlaybackOptions->text_subs.entry[cnt].type = RMFPTextSubs_ASS; break;
			case RMLibPlayTextSubs_SUB: pOutPlaybackOptions->text_subs.entry[cnt].type = RMFPTextSubs_SUB; break;
			case RMLibPlayTextSubs_SMI: pOutPlaybackOptions->text_subs.entry[cnt].type = RMFPTextSubs_SMI; break;
		}
		pOutPlaybackOptions->text_subs.entry[cnt].framerate_numerator = pInPlaybackOptions->text_subs.entry[cnt].framerate_numerator;
		pOutPlaybackOptions->text_subs.entry[cnt].framerate_denominator = pInPlaybackOptions->text_subs.entry[cnt].framerate_denominator;
        }
	
	pOutPlaybackOptions->truecolor_subs = pInPlaybackOptions->truecolor_subs;
	pOutPlaybackOptions->yuv_palette_subs = pInPlaybackOptions->yuv_palette_subs;
	pOutPlaybackOptions->no_prerendered_subs = pInPlaybackOptions->no_prerendered_subs;
	pOutPlaybackOptions->disable_ssa_animations = pInPlaybackOptions->disable_ssa_animations;
	
	pOutPlaybackOptions->subidx_sub_file_handle = pInPlaybackOptions->subidx_sub_file_handle;
        pOutPlaybackOptions->subidx_idx_file_handle = pInPlaybackOptions->subidx_idx_file_handle;
        pOutPlaybackOptions->subidx_index = pInPlaybackOptions->subidx_index;

	pOutPlaybackOptions->external_subs_delayms = pInPlaybackOptions->external_subs_delayms;

	pOutPlaybackOptions->subtitles_track = pInPlaybackOptions->subtitles_track;
	pOutPlaybackOptions->enable_spu      = pInPlaybackOptions->enable_spu;

	pOutPlaybackOptions->attachments_extraction_dir = pInPlaybackOptions->attachments_extraction_dir;

	pOutPlaybackOptions->WaitExit = pInPlaybackOptions->WaitExit;

	pOutPlaybackOptions->rtsp_url = pInPlaybackOptions->rtsp_url;

	pOutPlaybackOptions->watermark = pInPlaybackOptions->watermark;

	pOutPlaybackOptions->pPlugInPath = &(pInPlaybackOptions->PlugInPath[0]);

	pOutPlaybackOptions->IgnoreEOS = pInPlaybackOptions->IgnoreEOS;
	pOutPlaybackOptions->ReindexMKV = pInPlaybackOptions->ReindexMKV;
	pOutPlaybackOptions->url = pInPlaybackOptions->url;

	pOutPlaybackOptions->cacheMP4Indexes = pInPlaybackOptions->cacheMP4Indexes;
	pOutPlaybackOptions->force_linear_interleaving = pInPlaybackOptions->force_linear_interleaving;

	pOutPlaybackOptions->hls_key_url_options = pInPlaybackOptions->hls_key_url_options;
	switch (pInPlaybackOptions->hls_key_encoding) {
	case RMFPHLSKeyEncoding_NONE:
		pOutPlaybackOptions->hls_key_encoding = RMLibPlayHLSKeyEncoding_NONE;
		break;
	case RMFPHLSKeyEncoding_AES_128_CBC:
		pOutPlaybackOptions->hls_key_encoding = RMLibPlayHLSKeyEncoding_AES_128_CBC;
		break;
	}
	pOutPlaybackOptions->hls_key_key = pInPlaybackOptions->hls_key_key;
	pOutPlaybackOptions->hls_key_iv = pInPlaybackOptions->hls_key_iv;
	pOutPlaybackOptions->hls_base64_key = pInPlaybackOptions->hls_base64_key;
	switch (pInPlaybackOptions->hls_type) {
	case RMFPHLSType_UNKNOWN:
		pOutPlaybackOptions->hls_type = RMLibPlayHLSType_UNKNOWN;
		break;
	case RMFPHLSType_VOD:
		pOutPlaybackOptions->hls_type = RMLibPlayHLSType_VOD;
		break;
	case RMFPHLSType_SLIDINGWINDOW:
		pOutPlaybackOptions->hls_type = RMLibPlayHLSType_SLIDINGWINDOW;
		break;
	case RMFPHLSType_EVENT:
		pOutPlaybackOptions->hls_type = RMLibPlayHLSType_EVENT;
		break;
	}
	pOutPlaybackOptions->hls_thread_cache_memory = pInPlaybackOptions->hls_thread_cache_memory;
	pOutPlaybackOptions->hls_autoswitch_set_window = pInPlaybackOptions->hls_autoswitch_set_window;
	pOutPlaybackOptions->hls_up_window_percentage = pInPlaybackOptions->hls_up_window_percentage;
	pOutPlaybackOptions->hls_down_window_percentage = pInPlaybackOptions->hls_down_window_percentage;

	switch (pInPlaybackOptions->rebuffering_type) {
		case RMFPRebufferingMode_FIFO_FULLNESS:
			pOutPlaybackOptions->rebuffering.type = RMLibPlayRebuffering_auto_fullness;

			pOutPlaybackOptions->rebuffering.params.fifo.alow = ( pInPlaybackOptions->rebuf_alow == (RMuint32) -1L ) ? 10
										: pInPlaybackOptions->rebuf_alow;

			pOutPlaybackOptions->rebuffering.params.fifo.ahigh= ( pInPlaybackOptions->rebuf_ahigh == (RMuint32) -1L ) ? 90
										: pInPlaybackOptions->rebuf_ahigh;

			pOutPlaybackOptions->rebuffering.params.fifo.vlow = ( pInPlaybackOptions->rebuf_vlow == (RMuint32) -1L ) ? 10
										: pInPlaybackOptions->rebuf_vlow;

			pOutPlaybackOptions->rebuffering.params.fifo.vhigh= ( pInPlaybackOptions->rebuf_vhigh == (RMuint32) -1L ) ? 90
										: pInPlaybackOptions->rebuf_vhigh;
			break;

		case RMFPRebufferingMode_BUFFER_DURATION:
			pOutPlaybackOptions->rebuffering.type = RMLibPlayRebuffering_auto_time;

			pOutPlaybackOptions->rebuffering.params.time.alow = ( pInPlaybackOptions->rebuf_alow == (RMuint32) -1L ) ? 500
										: pInPlaybackOptions->rebuf_alow;

			pOutPlaybackOptions->rebuffering.params.time.ahigh= ( pInPlaybackOptions->rebuf_ahigh == (RMuint32) -1L ) ? 10000
										: pInPlaybackOptions->rebuf_ahigh;

			pOutPlaybackOptions->rebuffering.params.time.vlow = ( pInPlaybackOptions->rebuf_vlow == (RMuint32) -1L ) ? 500
										: pInPlaybackOptions->rebuf_vlow;

			pOutPlaybackOptions->rebuffering.params.time.vhigh= ( pInPlaybackOptions->rebuf_vhigh == (RMuint32) -1L ) ? 10000
										: pInPlaybackOptions->rebuf_vhigh;

			pOutPlaybackOptions->rebuffering.params.time.fullness = ( pInPlaybackOptions->rebuf_fullness == (RMuint32) -1L ) ? 90
										: pInPlaybackOptions->rebuf_fullness;

			break;

		case RMFPRebufferingMode_DISABLED:
		default:
			pOutPlaybackOptions->rebuffering.type = RMLibPlayRebuffering_disabled;
			break;
	}

	pOutPlaybackOptions->rebuffering.timeout = ( pInPlaybackOptions->rebuf_timeout == (RMuint32) -1L ) ? 90
							: pInPlaybackOptions->rebuf_timeout;

	pOutPlaybackOptions->read_timeout = (pInPlaybackOptions->read_timeout > 1000) ? 1000 : pInPlaybackOptions->read_timeout;

	pOutPlaybackOptions->liteindex_enable = pInPlaybackOptions->liteindex_enable;
	pOutPlaybackOptions->liteindex_kickstart = pInPlaybackOptions->liteindex_kickstart ? pInPlaybackOptions->liteindex_kickstart : 40;
	pOutPlaybackOptions->liteindex_trickfactor = (pInPlaybackOptions->liteindex_trickfactor >= 200)
							? pInPlaybackOptions->liteindex_trickfactor : 500;

	pOutPlaybackOptions->start_offset_type = pInPlaybackOptions->start_offset_type;
	pOutPlaybackOptions->start_offset_use_accurate_seek = pInPlaybackOptions->start_offset_use_accurate_seek;
	pOutPlaybackOptions->start_offset = pInPlaybackOptions->start_offset;

	return RM_OK;
}

static RMstatus rmfp_rmfp2rmlibplay_translate_demux_options(struct RMFPDemuxOptions *pInDemuxOptions,
															struct RMLibPlayDemuxOptions *pOutDemuxOptions)
{
	RMuint32 cnt;

	//RMmustBeEqual(sizeof(struct RMFPDemuxOptions), 592, RMFPDemuxOptions);
	//RMmustBeEqual(sizeof(struct RMLibDemuxVideoOptions), 584, RMLibPlayDemuxOptions);

	RMDBGLOG((LOCALDBG, "size of RMFPDemuxOptions %lu\n", sizeof(struct RMFPDemuxOptions)));
	RMDBGLOG((LOCALDBG, "size of RMLibPlayDemuxOptions %lu\n", sizeof(struct RMLibPlayDemuxOptions)));

	ASSERT_NULL_POINTER(pInDemuxOptions);
	ASSERT_NULL_POINTER(pOutDemuxOptions);


	pOutDemuxOptions->engine_id = pInDemuxOptions->engine_id;
	pOutDemuxOptions->task_id = pInDemuxOptions->task_id;

	pOutDemuxOptions->system_type = pInDemuxOptions->system_type;
	pOutDemuxOptions->repack_sample = pInDemuxOptions->repack_sample;
	pOutDemuxOptions->video_pid = pInDemuxOptions->video_pid;
	pOutDemuxOptions->audio_pid = pInDemuxOptions->audio_pid;
	pOutDemuxOptions->spu_pid = pInDemuxOptions->spu_pid;
	pOutDemuxOptions->audio_subid = pInDemuxOptions->audio_subid;
	pOutDemuxOptions->spu_subid = pInDemuxOptions->spu_subid;
	pOutDemuxOptions->ttx_pid = pInDemuxOptions->ttx_pid;
	pOutDemuxOptions->TeletextMode = pInDemuxOptions->TeletextMode;
	pOutDemuxOptions->custom_pid = pInDemuxOptions->custom_pid;

	pOutDemuxOptions->wait_for_pcr_time_ms = pInDemuxOptions->wait_for_pcr_time_ms;
	pOutDemuxOptions->pts_taken_as_pcr_offset_ms = pInDemuxOptions->pts_taken_as_pcr_offset_ms;
	pOutDemuxOptions->ts_skip = pInDemuxOptions->ts_skip;
	pOutDemuxOptions->pcr_pid = pInDemuxOptions->pcr_pid;
	pOutDemuxOptions->spi = pInDemuxOptions->spi;
	pOutDemuxOptions->serial_spi = pInDemuxOptions->serial_spi;
	pOutDemuxOptions->input_port = pInDemuxOptions->input_port;
	pOutDemuxOptions->input_protocol = pInDemuxOptions->input_protocol;
	pOutDemuxOptions->idle_port = pInDemuxOptions->idle_port;
	pOutDemuxOptions->flags = pInDemuxOptions->flags;
	pOutDemuxOptions->ignore_pat = pInDemuxOptions->ignore_pat;
	pOutDemuxOptions->pmt_index = pInDemuxOptions->pmt_index;
	pOutDemuxOptions->pmt_pid = pInDemuxOptions->pmt_pid;
	pOutDemuxOptions->default_pmt_pid = pInDemuxOptions->default_pmt_pid;
	pOutDemuxOptions->sync_lock = pInDemuxOptions->sync_lock;
	pOutDemuxOptions->pcr_disc = pInDemuxOptions->pcr_disc;
	pOutDemuxOptions->audio_ts_priority = pInDemuxOptions->audio_ts_priority;
	pOutDemuxOptions->pes_pid_entry_input_type = pInDemuxOptions->pes_pid_entry_input_type;
	pOutDemuxOptions->mpeg_multichannel = pInDemuxOptions->mpeg_multichannel;
	pOutDemuxOptions->monitor = pInDemuxOptions->monitor;
	pOutDemuxOptions->fifo_size = pInDemuxOptions->fifo_size;
	pOutDemuxOptions->xfer_count = pInDemuxOptions->xfer_count;
	pOutDemuxOptions->section_filter_based_on_new_version = pInDemuxOptions->section_filter_based_on_new_version;
	pOutDemuxOptions->iterative_seek = pInDemuxOptions->iterative_seek;

	pOutDemuxOptions->index_file_handle = pInDemuxOptions->index_file_handle;
	pOutDemuxOptions->multicast_dump_file_handle = pInDemuxOptions->multicast_dump_file_handle;
	pOutDemuxOptions->tsdump_file_handle = pInDemuxOptions->tsdump_file_handle;
	pOutDemuxOptions->tsdump_index_file_handle = pInDemuxOptions->tsdump_index_file_handle;
	pOutDemuxOptions->tsdump_is_192 = pInDemuxOptions->tsdump_is_192;
	pOutDemuxOptions->index2create_file_handle = pInDemuxOptions->index2create_file_handle;
	pOutDemuxOptions->second_file_handle = pInDemuxOptions->second_file_handle;
	pOutDemuxOptions->index2create_file_name = pInDemuxOptions->index2create_file_name;
	pOutDemuxOptions->load_previous_index_entries = pInDemuxOptions->load_previous_index_entries;
	

	pOutDemuxOptions->save_input_file_handle = pInDemuxOptions->save_input_file_handle;
	

	pOutDemuxOptions->save_pat_file_handle = pInDemuxOptions->save_pat_file_handle;
	pOutDemuxOptions->save_pmt_file_handle = pInDemuxOptions->save_pmt_file_handle;
	pOutDemuxOptions->save_custom_pid_file_handle = pInDemuxOptions->save_custom_pid_file_handle;

	if (pInDemuxOptions->multicast.count > RMLIBPLAY_MAX_MULTICAST_STREAMS)
	{
		RMDBGLOG((ENABLE, "Warning : using only %d multicast addresses\n",RMLIBPLAY_MAX_MULTICAST_STREAMS));
		pOutDemuxOptions->multicast.count = RMLIBPLAY_MAX_MULTICAST_STREAMS;
	}
	else
		pOutDemuxOptions->multicast.count = pInDemuxOptions->multicast.count;

	for (cnt=0; cnt<pOutDemuxOptions->multicast.count; cnt++)
	{
		RMMemcpy(pOutDemuxOptions->multicast.address[cnt], pInDemuxOptions->multicast.address[cnt], 16);
		pOutDemuxOptions->multicast.port[cnt] = pInDemuxOptions->multicast.port[cnt];
	}
	
	pOutDemuxOptions->start_offset = pInDemuxOptions->start_offset;

	return RM_OK;
}

static RMstatus rmfp_rmfp2rmlibplay_translate_picture_options(struct RMFPPictureOptions *pInPictureOptions,
															  struct RMLibPlayPictureOptions *pOutPictureOptions)
{
	RMDBGLOG((LOCALDBG, "size of RMFPPictureOptions %lu\n", sizeof(struct RMFPPictureOptions)));
	RMDBGLOG((LOCALDBG, "size of RMLibPlayPictureOptions %lu\n", sizeof(struct RMLibPlayPictureOptions)));

	ASSERT_NULL_POINTER(pInPictureOptions);
	ASSERT_NULL_POINTER(pOutPictureOptions);

	pOutPictureOptions->alpha        = pInPictureOptions->alpha;
	pOutPictureOptions->force_rgb    = pInPictureOptions->force_rgb;
	pOutPictureOptions->ignore_picture_alpha_channel = pInPictureOptions->ignore_picture_alpha_channel;
	pOutPictureOptions->yuv_width = pInPictureOptions->yuv_width;
  	pOutPictureOptions->yuv_height = pInPictureOptions->yuv_height;
  	pOutPictureOptions->yuv_has_alpha = pInPictureOptions->yuv_has_alpha;
  	pOutPictureOptions->yuv_sampling_mode = pInPictureOptions->yuv_sampling_mode;

	return RM_OK;
}

static RMstatus rmfp_rmfp2rmlibplay_translate_options(struct RMFPOptions *pRMFPOptions,
													  struct RMLibPlayOptions *pRMLibPlayOptions)
{
	RMstatus status;

	/* IMPORTANT : if change in struct RMFPOptions of RMLibPLayOptions you need to modified this fonction */
	/* Verification */
// TEMPORARLY DISABLED SINCE IT GIVES DIFFERENT RESULTS FOR STANDALONE AND WITHHOST
	//RMmustBeEqual(sizeof(struct RMFPOptions), 592, RMFPOptions);
	//RMmustBeEqual(sizeof(struct RMLibPlayOptions), 584, RMLibPlayOptions);

	RMDBGLOG((LOCALDBG, "size of RMFPOptions %lu\n", sizeof(struct RMFPOptions)));
	RMDBGLOG((LOCALDBG, "size of RMLibPlayOptions %lu\n", sizeof(struct RMLibPlayOptions)));


	status = rmfp_rmfp2rmlibplay_translate_audio_options(&pRMFPOptions->audio_options, &pRMLibPlayOptions->audio_options);
	if (status != RM_OK) {
		RMNOTIFY((NULL, status, "Cannot translate audio options\n"));
		return status;
	}

	status = rmfp_rmfp2rmlibplay_translate_video_options(&pRMFPOptions->video_options, &pRMLibPlayOptions->video_options);
	if (status != RM_OK) {
		RMNOTIFY((NULL, status, "Cannot translate video options\n"));
		return status;
	}

	status = rmfp_rmfp2rmlibplay_translate_playback_options(&pRMFPOptions->playback_options, &pRMLibPlayOptions->playback_options);
	if (status != RM_OK) {
		RMNOTIFY((NULL, status, "Cannot translate playback options\n"));
		return status;
	}

	status = rmfp_rmfp2rmlibplay_translate_demux_options(&pRMFPOptions->demux_options, &pRMLibPlayOptions->demux_options);
	if (status != RM_OK) {
		RMNOTIFY((NULL, status, "Cannot translate demux options\n"));
		return status;
	}

	status = rmfp_rmfp2rmlibplay_translate_picture_options(&pRMFPOptions->picture_options, &pRMLibPlayOptions->picture_options);
	if (status != RM_OK) {
		RMNOTIFY((NULL, status, "Cannot translate picture options\n"));
		return status;
	}

	return status;
}

static RMstatus rmfp_check_parameters_coherency(struct RMFPHandle *pHandle,
												struct RMFPOptions *pOptions,
												struct RMFPStreamType *pStreamType)
{
	ASSERT_NULL_POINTER(pHandle);
	ASSERT_NULL_POINTER(pOptions);

	RMDBGLOG((LOCALDBG, "RMFPMain(@%p)\n", pHandle));

	/*
	 * Demux parameters
	 */

	if (((pOptions->demux_options.spi) || (pOptions->demux_options.multicast.count))
	    && ((pOptions->demux_options.index_file_handle) || (pOptions->demux_options.index2create_file_handle)))
	{
		return RM_INVALID_PARAMETER;
	}
		

	if ((pOptions->demux_options.spi) && (pOptions->demux_options.multicast.count))
	{
		return RM_INVALID_PARAMETER;
	}
		

	if (	((pOptions->playback_options.subidx_sub_file_handle) || (pOptions->playback_options.subidx_idx_file_handle))
	&&	(pStreamType->application_type != RMFP_application_type_RIFF)
	&&	(pStreamType->application_type != RMFP_application_type_AVI)
	&&	(pStreamType->application_type != RMFP_application_type_ASF)
	&&	(pStreamType->application_type != RMFP_application_type_MKV)
	   )
		return RM_INVALID_PARAMETER;
	
	if (	pOptions->playback_options.stc_compensation
		&&	(	(pStreamType->application_type != RMFP_application_type_PSFDEMUX
		&& pStreamType->application_type != RMFP_application_type_DTV)
		||	(!pOptions->demux_options.spi && !pOptions->demux_options.multicast.count)
		)
		)
		return RM_INVALID_PARAMETER;
		
	if ((!pOptions->demux_options.spi) && (pOptions->demux_options.save_input_file_handle))
		return RM_INVALID_PARAMETER;

	return RM_OK;
}


static void rmfp_check_callback(struct RMFPProfile* pProfile)
{
#define CHECK_CALLBACK(my_callback)					\
	if (pProfile->my_callback)					\
		RMDBGLOG((LOCALDBG, "OK: " #my_callback "\n"));		\
	else								\
		RMDBGLOG((ENABLE, "MISSING: " #my_callback "\n"))

	RMDBGPRINT((LOCALDBG, "\nCallbacks availability check:\n"));

	CHECK_CALLBACK(rmfp_video_resources_callback);
	CHECK_CALLBACK(rmfp_picture_transform_resources_callback);
	CHECK_CALLBACK(rmfp_audio_resources_callback);
	CHECK_CALLBACK(rmfp_demux_resources_callback);
	CHECK_CALLBACK(rmfp_demux_output_resources_callback);
	CHECK_CALLBACK(rmfp_spu_resources_callback);
	CHECK_CALLBACK(rmfp_ccfifo_resources_callback);
	CHECK_CALLBACK(rmfp_teletext_resources_callback);
	CHECK_CALLBACK(rmfp_release_video_resources_callback);
	CHECK_CALLBACK(rmfp_release_audio_resources_callback);
	CHECK_CALLBACK(rmfp_release_demux_resources_callback);
	CHECK_CALLBACK(rmfp_release_demux_output_resources_callback);
	CHECK_CALLBACK(rmfp_release_spu_resources_callback);
	CHECK_CALLBACK(rmfp_release_ccfifo_resources_callback);
	CHECK_CALLBACK(rmfp_release_teletext_resources_callback);
	CHECK_CALLBACK(rmfp_open_osd_callback);
	CHECK_CALLBACK(rmfp_close_osd_callback);
	CHECK_CALLBACK(rmfp_get_surface_events_callback);
	CHECK_CALLBACK(rmfp_disconnect_surface_callback);
	CHECK_CALLBACK(rmfp_notify_event_callback);
	CHECK_CALLBACK(rmfp_disk_control_callback);
	CHECK_CALLBACK(rmfp_get_command_callback);
	CHECK_CALLBACK(rmfp_notify_command_status_callback);
	CHECK_CALLBACK(rmfp_notify_playback_status_callback);
	CHECK_CALLBACK(rmfp_notify_progress_callback);
	CHECK_CALLBACK(rmfp_notify_available_commands_callback);
	CHECK_CALLBACK(rmfp_notify_playback_start_callback);
	CHECK_CALLBACK(rmfp_notify_playback_eos_callback);
	CHECK_CALLBACK(rmfp_notify_current_streams_properties_callback);
	CHECK_CALLBACK(rmfp_notify_stream_metadata_callback);
	CHECK_CALLBACK(rmfp_notify_pat_callback);
	CHECK_CALLBACK(rmfp_notify_pmt_callback);
	CHECK_CALLBACK(rmfp_notify_pid_creation_callback);
	CHECK_CALLBACK(rmfp_notify_send_data_callback);
	CHECK_CALLBACK(rmfp_teletext_entry_callback);
	CHECK_CALLBACK(rmfp_ccfifo_entry_callback);

	RMDBGPRINT((LOCALDBG, "\n"));

}


/*
  HACK: since for 8634 we need to support both libsamples1 and libsamples2 (RMFP)
  we need to add this since they are required by the old DTCP API.

  chips newer than 8634 only support RMFP so they do not require this hack
*/

#ifndef ANDROID
#if (1) //(EM86XX_CHIP < EM86XX_CHIPID_TANGO3)

struct stream_options_s;

RMstatus set_http_hook_options(struct stream_options_s *options, RMHTTPFlags http_flags, void *custom_cookie, void *custom_hooks);
RMstatus set_http_hook_options(struct stream_options_s *options, RMHTTPFlags http_flags, void *custom_cookie, void *custom_hooks)
{
	RMDBGLOG((ENABLE, "laJSdlkajsd\n"));
	return RM_ERROR;
}

RMstatus AESKeyPrecipherInband(struct RUA *Context_RUA,RMuint32 Context_demux_task,enum EMhwlibScramblingBits scrambling, RMuint8 *pkey, RMuint8 *piv, RMuint32 key_size,RMuint32 inband_state);
RMstatus AESKeyPrecipherInband(struct RUA *Context_RUA,RMuint32 Context_demux_task,enum EMhwlibScramblingBits scrambling, RMuint8 *pkey, RMuint8 *piv, RMuint32 key_size,RMuint32 inband_state)
{
	RMDBGLOG((ENABLE, "LAKJSDLKASJDLKA\n"));
	return RM_ERROR;
}

#endif
#endif

RMstatus Rmfp_getAllowedCmdMask(const struct RMFPHandle *pRmfpHandle, RMuint32 * const pAllowedCmdMask)
{
	RMstatus eOutRMstatus;

	eOutRMstatus = RM_OK;

	do
	{
		if(NULL == pRmfpHandle)
		{
			eOutRMstatus = RM_INVALID_PARAMETER;
			break;
		}

		if(NULL == pRmfpHandle->pRMLibPlayHandle)
		{
			eOutRMstatus = RM_ERROR_STATE;
			break;
		}

		if(pAllowedCmdMask)
		{
			eOutRMstatus = Rmlibplay_getAllowedCmdMask(pRmfpHandle->pRMLibPlayHandle, pAllowedCmdMask);
		}
	}while(FALSE);
	
	return eOutRMstatus;
}

RMstatus Rmfp_getPlaybackStatus(const struct RMFPHandle *pRmfpHandle, 
	struct RMFPPlaybackStatus * pRmfpPlaybackStatus)
{
	RMstatus eOutRMstatus;

	eOutRMstatus = RM_OK;

	do
	{
		if(NULL == pRmfpHandle)
		{
			eOutRMstatus = RM_INVALID_PARAMETER;
			break;
		}

		if(NULL == pRmfpHandle->pRMLibPlayHandle)
		{
			eOutRMstatus = RM_ERROR_STATE;
			break;
		}

		if(pRmfpPlaybackStatus)
		{
			eOutRMstatus = Rmlibplay_getPlaybackStatus(pRmfpHandle->pRMLibPlayHandle, pRmfpPlaybackStatus);
		}
	}while(FALSE);
	
	return eOutRMstatus;
}

RMstatus Rmfp_setRmlibplayPlaybackOpt_PrebufMax(struct RMFPHandle *pRmfpHandle, RMuint32 PrebufMaxSize)
{
	RMstatus eOutRMstatus;

	eOutRMstatus = RM_OK;

	do
	{
		if(NULL == pRmfpHandle)
		{
			eOutRMstatus = RM_INVALID_PARAMETER;
			break;
		}

		if(NULL == pRmfpHandle->pRMLibPlayHandle)
		{
			eOutRMstatus = RM_ERROR_STATE;
			break;
		}

		eOutRMstatus = Rmlibplay_setPrebufMax(pRmfpHandle->pRMLibPlayHandle, PrebufMaxSize);
	}while(FALSE);
	
	return eOutRMstatus;
}

RMstatus Rmfp_setRequestQuitPlay(struct RMFPHandle *pRmfpHandle, const RMbool bRequestQuitPlay)
{
	RMstatus eOutRMstatus;

	eOutRMstatus = RM_OK;

	do
	{
		if(NULL == pRmfpHandle)
		{
			eOutRMstatus = RM_INVALID_PARAMETER;
			break;
		}

		if(NULL == pRmfpHandle->pRMLibPlayHandle)
		{
			eOutRMstatus = RM_ERROR_STATE;
			break;
		}

		eOutRMstatus = Rmlibplay_setRequestQuitPlay(pRmfpHandle->pRMLibPlayHandle, bRequestQuitPlay);
	}while(FALSE);
	
	return eOutRMstatus;
}

#if 1/*added by lxj 2013-1-8*/
RMstatus Rmfp_setPauseAfterBuffering(struct RMFPHandle *pRmfpHandle, const RMbool bPauseAfterBuffering)
{
	RMstatus eOutRMstatus;

	eOutRMstatus = RM_OK;

	do
	{
		if(NULL == pRmfpHandle)
		{
			eOutRMstatus = RM_INVALID_PARAMETER;
			break;
		}

		if(NULL == pRmfpHandle->pRMLibPlayHandle)
		{
			eOutRMstatus = RM_ERROR_STATE;
			break;
		}

		eOutRMstatus = Rmlibplay_setPauseAfterBuffering(pRmfpHandle->pRMLibPlayHandle, bPauseAfterBuffering);
	}while(FALSE);
	
	return eOutRMstatus;
}

#endif
