/*****************************************
 Copyright 2001-2007
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   crc32.h
  @brief  This file provides with sample code for implementing RMFP's callbacks

	  This file is part of the test_rmfp suite

  @author Sebastian Frias Feltrer
  @date   2007-10-29
*/

/*
  **********************************************
  DISCLAIMER:

  - THIS IS TEST CODE, provided as sample code
  to help you understand what you should do to
  develop your own application based in RMFP.

  - This is NOT production grade code; It is not
  even a library, so any API defined here, CAN
  and WILL CHANGE without notice.

  **********************************************
*/

#ifndef __TESTRMFP_CRC32_H__
#define __TESTRMFP_CRC32_H__


#include <rmdef/rmdef.h>
#include "rmfp.h"
#include "test_rmfp.h"



RMstatus init_crc32(struct rmfp_main_thread_context_type *pHandle);


RMstatus compute_crc32(struct rmfp_main_thread_context_type *pHandle,
		       RMuint32 buffer_start, RMuint32 buffer_tile_width,
		       RMuint32 xmin, RMuint32 xmax,
		       RMuint32 ymin, RMuint32 ymax, RMuint8 Tiled,
		       RMuint32 *pCheckSum);

RMstatus deinit_crc32(struct rmfp_main_thread_context_type *pHandle);


#endif // __TESTRMFP_CRC32_H__
