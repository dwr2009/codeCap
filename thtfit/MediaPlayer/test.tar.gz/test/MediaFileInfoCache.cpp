#ifndef	ALLOW_OS_CODE
#define	ALLOW_OS_CODE
#endif	//ALLOW_OS_CODE

#ifndef __USE_FILE_OFFSET64
#define __USE_FILE_OFFSET64
#endif
#ifndef __USE_LARGEFILE64
#define __USE_LARGEFILE64
#endif
#ifndef _LARGEFILE64_SOURCE
#define _LARGEFILE64_SOURCE
#endif

#include "MediaFileInfoCache.h"
#include <memory.h>
#include <DateTime.h>
#include <fcntl.h>
#include <DbgLogSwitchDef.h>

#ifndef debugMediaInfo
#define debugMediaInfo(format,...)\
	if(Sw_LogMediaFileInfo){ \
		LOG_BLINE(format,##__VA_ARGS__); \
	}
#define debugMediaError(format,...)\
		LOG_BLINE(format,##__VA_ARGS__);
#endif

#if 1/*added by lxj 2012-11-6*/
static RMuint32 CalculateCRC(RMuint8 *buffer, RMuint32 size)
{
	UINT32_t crc_table[256];
	UINT32_t c;
	UINT16_t n, k;

	for (n = 0; n < 256; n++) {
		c = (UINT32_t) n;
		for (k = 0; k < 8; k++) {
			if (c & 1)
				c = 0xedb88320L ^ (c >> 1);
			else
				c = c >> 1;
		}
		crc_table[n] = c;
	}

	// get crc
	c = 0xffffffffL;
	for (n = 0; n < size; n++) {
		c = crc_table[(c ^ buffer[n]) & 0xff] ^ (c >> 8);
	}

	return c ^ 0xffffffffL;
}
#endif

CMediaFileInfo::CMediaFileInfo()
{
#if 1/*modify by lxj 2012-11-6*/
	ZeroMemory(&m_CacheRecord,sizeof(m_CacheRecord));
	m_CacheRecord.RmfpStreamType.application_type = RMFP_application_type_UNKNOWN;
#endif
}

CMediaFileInfo::~CMediaFileInfo()
{
#if 1/*modify by lxj 2012-11-6*/
#endif
}

const int CMediaFileInfoCache::MAX_CACHE_ITEMS;

CMediaFileInfoCache::CMediaFileInfoCache()
{
#if 1/*added by lxj 2012-11-6*/
	m_MediaFileInfoCacheHandle = -1;
	LoadMediaInfoCacheFromFile();
#endif
}

CMediaFileInfoCache::~CMediaFileInfoCache()
{
#if 1/*added by lxj 2012-11-6*/
	UnloadMediaInfoCacheFile();
#endif
}

/*
Caller has the responsibility of freeing the returned pointer of pFindOutParam
*/
INT_t CMediaFileInfoCache::FindStreamInfoInCache(CONST IMediaFileInfoCache::P_FIND_STREAM_INFO_IN_PARAM pFindInParam,
	IMediaFileInfoCache::P_FIND_STREAM_INFO_OUT_PARAM pFindOutParam)
{
	INT_t iOutRet = ERROR_NOT_FOUND, iRet;
	SharedPtr <CMediaFileInfo> MediaFileInfo_sp;
	MediaFileInfo_map::iterator itMediaFileInfo;
	struct stat64 FileStat;

	do
	{
		if(pFindOutParam)
		{
			pFindOutParam->RmfpStreamType.application_type = RMFP_application_type_UNKNOWN;
			pFindOutParam->pRmfpStreamInfo = NULL;
		}

		if(NULL == pFindInParam)
		{
			break;
		}

		itMediaFileInfo = m_MediaFileInfoMap.find((LPCSTR)(pFindInParam->pszFileName));
		if(m_MediaFileInfoMap.end() == itMediaFileInfo)
		{
			//debugMediaInfo("NotFound:%s\n", (LPCSTR)(pFindInParam->pszFileName));
			break;
		}
		//debugMediaInfo("Found:%s\n", (LPCSTR)(itMediaFileInfo->first));
		MediaFileInfo_sp = itMediaFileInfo->second;
		if(MediaFileInfo_sp.isNull())
		{
			m_MediaFileInfoMap.erase(itMediaFileInfo);
			break;
		}
		iRet = stat64((LPCSTR)(pFindInParam->pszFileName), &FileStat);
		if(0 == iRet)
		{
#if 1/*modify by lxj 2012-11-6, check file*/
			if( (MediaFileInfo_sp->m_CacheRecord.FileModifiedTime != FileStat.st_mtime) ||
				(MediaFileInfo_sp->m_CacheRecord.FileSize != FileStat.st_size) ){
				debugMediaInfo("find cache record \"%s\", but the file modify time or size not matched to cache record.\n",pFindInParam->pszFileName);
				break;
			}
#endif
		}
		else	//crt err
		{
			//PRINT_BFILE_LINENO_CRT_ERRINFO;
			break;
		}
		MediaFileInfo_sp->m_CacheRecord.LastUseTimeMs = GetSysUpTimeMs();
		MediaFileInfo_sp->m_CacheRecord.check_crc = CalculateCRC((RMuint8*)(&MediaFileInfo_sp->m_CacheRecord),sizeof(MediaFileInfo_sp->m_CacheRecord)-sizeof(MediaFileInfo_sp->m_CacheRecord.check_crc));//added by lxj 2013-3-13 avoid crc error

#if 1/*modify by lxj 2012-11-6*/
		pFindOutParam->RmfpStreamType = MediaFileInfo_sp->m_CacheRecord.RmfpStreamType;
		pFindOutParam->pRmfpStreamInfo = CloneRmfpStreamInfo(&MediaFileInfo_sp->m_CacheRecord.RmfpStreamInfo);
#endif

		iOutRet = ERROR_SUCCESS;
	}while(FALSE);

	return iOutRet;
}

INT_t CMediaFileInfoCache::AddMediaInfoCache(const RMascii * pszFileName, CONST struct RMFPStreamType * pRmfpStreamType,
	CONST struct RMFPStreamInfo * pRmfpStreamInfo)
{
	INT_t iOutRet = ERROR_SUCCESS, iRet;
	SharedPtr <CMediaFileInfo> MediaFileInfo_sp;
	pMediaFileInfoCacheRecord_t pCacheRecord=NULL;
	MediaFileInfo_map::iterator itMediaFileInfo;
	struct stat64 FileStat;

	do
	{
		if(NULL == pszFileName || NULL == pRmfpStreamType || NULL == pRmfpStreamInfo)
		{
			iOutRet = ERROR_INVALID_PARAMETER;
			break;
		}

#if 1/*added by lxj 2012-11-6*/
		itMediaFileInfo = m_MediaFileInfoMap.find((LPCSTR)(pszFileName));
		if(itMediaFileInfo != m_MediaFileInfoMap.end() ){
			MediaFileInfo_sp = itMediaFileInfo->second;
			if(MediaFileInfo_sp.isValid()){
				debugMediaInfo("remove old cache record \"%s\"\n",pszFileName);
				m_MediaFileInfoMap.erase(itMediaFileInfo);
				iRet = RemoveOldCacheItemsFromFile();
				if(ERROR_SUCCESS != iRet){
					PRINT_BFILE_LINENO_IRET_STR;
				}
			}
		}
#endif

		MediaFileInfo_sp = SharedPtr <CMediaFileInfo> (new CMediaFileInfo);
		if(MediaFileInfo_sp.isNull())
		{
			iOutRet = ERROR_OUT_OF_MEMORY;
			break;
		}

#if 1/*modify by lxj 2012-11-6*/
		pCacheRecord = &MediaFileInfo_sp->m_CacheRecord;

		pCacheRecord->RecordSize = sizeof(*pCacheRecord);
		strncpy( pCacheRecord->FilePathName, pszFileName, sizeof(pCacheRecord->FilePathName)-1);

		pCacheRecord->RmfpStreamType = *pRmfpStreamType;
		pCacheRecord->RmfpStreamInfo.Version = pRmfpStreamInfo->Version;

		pCacheRecord->RmfpStreamInfo.VideoStreamCount =
			(pRmfpStreamInfo->VideoStreamCount > STRAMINFO_VIDEO_MAX ?
			 STRAMINFO_VIDEO_MAX :
			 pRmfpStreamInfo->VideoStreamCount);
		pCacheRecord->RmfpStreamInfo.AudioStreamCount =
			(pRmfpStreamInfo->AudioStreamCount > STRAMINFO_AUDIO_MAX ?
			 STRAMINFO_AUDIO_MAX :
			 pRmfpStreamInfo->AudioStreamCount);
		pCacheRecord->RmfpStreamInfo.DataStreamCount =
			(pRmfpStreamInfo->DataStreamCount > STRAMINFO_DATA_MAX ?
			 STRAMINFO_DATA_MAX :
			 pRmfpStreamInfo->DataStreamCount);
		pCacheRecord->RmfpStreamInfo.SystemStreamCount =
			(pRmfpStreamInfo->SystemStreamCount > STRAMINFO_SYSTEM_MAX ?
			 STRAMINFO_SYSTEM_MAX :
			 pRmfpStreamInfo->SystemStreamCount);

		if(pRmfpStreamInfo->pVideo){
			RMMemcpy( &pCacheRecord->RmfpStreamInfo.Video, pRmfpStreamInfo->pVideo,
			          sizeof((*(&pCacheRecord->RmfpStreamInfo.Video[0]))) * pCacheRecord->RmfpStreamInfo.VideoStreamCount );
		}
		if(pRmfpStreamInfo->pAudio){
			RMMemcpy( &pCacheRecord->RmfpStreamInfo.Audio, pRmfpStreamInfo->pAudio,
			          sizeof((*(&pCacheRecord->RmfpStreamInfo.Audio[0]))) * pCacheRecord->RmfpStreamInfo.AudioStreamCount );
		}
		if(pRmfpStreamInfo->pData){
			RMMemcpy( &pCacheRecord->RmfpStreamInfo.Data, pRmfpStreamInfo->pData,
			          sizeof((*(&pCacheRecord->RmfpStreamInfo.Data[0]))) * pCacheRecord->RmfpStreamInfo.DataStreamCount );
		}
		if(pRmfpStreamInfo->pSystem){
			RMMemcpy( &pCacheRecord->RmfpStreamInfo.System, pRmfpStreamInfo->pSystem,
			          sizeof((*(&pCacheRecord->RmfpStreamInfo.System[0]))) * pCacheRecord->RmfpStreamInfo.SystemStreamCount );
		}

		iRet = stat64(pszFileName, &FileStat);
		if(0 == iRet){
			pCacheRecord->FileModifiedTime = FileStat.st_mtime;
			pCacheRecord->FileSize = FileStat.st_size;
		}else{
			PRINT_BFILE_LINENO_CRT_ERRINFO;
			break;
		}

		pCacheRecord->LastUseTimeMs = GetSysUpTimeMs();

		pCacheRecord->check_crc = CalculateCRC((RMuint8*)(pCacheRecord),sizeof(*pCacheRecord)-sizeof(pCacheRecord->check_crc));
		m_MediaFileInfoMap[(LPCSTR)pszFileName] = MediaFileInfo_sp;

		//debugMediaInfo("Add MediaInfoCache(%s)\n",pCacheRecord->FilePathName);

		iRet = AddMediaInfoCacheToFile(pCacheRecord);
		if(ERROR_SUCCESS != iRet){
			PRINT_BFILE_LINENO_IRET_STR;
		}

		/*
		debugMediaInfo("MediaFileInfoCacheCnt:%d\n", m_MediaFileInfoMap.size());
		MediaFileInfo_map::iterator itMediaFileInfo;
		for(itMediaFileInfo = m_MediaFileInfoMap.begin(); itMediaFileInfo != m_MediaFileInfoMap.end(); itMediaFileInfo++)
		{
			debugMediaInfo("KEY:%s\n", (LPCSTR)(itMediaFileInfo->first));
		}
		*/
		//Check whether the size of the map exceeds MAX_CACHE_ITEMS
		if(MAX_CACHE_ITEMS < m_MediaFileInfoMap.size()){
			int ItemCntToRemove = (MAX_CACHE_ITEMS > 10) ? (MAX_CACHE_ITEMS/10) : 5;
			iRet = RemoveOldCacheItems(ItemCntToRemove);
			if(ERROR_SUCCESS != iRet){
				PRINT_BFILE_LINENO_IRET_STR;
			}
			iRet = RemoveOldCacheItemsFromFile();
			if(ERROR_SUCCESS != iRet){
				PRINT_BFILE_LINENO_IRET_STR;
			}
		}
#endif
	}while(FALSE);

	return iOutRet;
}

#if 1/*added by lxj 2012-11-6*/
INT_t CMediaFileInfoCache::LoadMediaInfoCacheFromFile(void)
{
	INT_t iOutRet=-1;
	INT_t i,recordLen,readSize;
	INT_t nErrorRecord=0;

	struct stat64 FileStat;
	char *fileBuffer=NULL,*p=NULL;
	SharedPtr <CMediaFileInfo> MediaFileInfo_sp;

#if 0/*debug*/
	debugMediaInfo("CacheRecord size=%d Bytes,MAX_CACHE size=%d Bytes\n",
	           sizeof(MediaFileInfoCacheRecord_t),
	           MAX_MEDIA_INFO_CACHE_FILE_BUFFER_SIZE);
#endif

	if(m_MediaFileInfoCacheHandle!=-1){
		debugMediaError("file \"%s\" was already opened.\n",MEDIA_INFO_CACHE_FILE_NAME);
		iOutRet = ERROR_INVALID_PARAMETER;
		goto error;
	}

	m_MediaFileInfoCacheHandle = open( MEDIA_INFO_CACHE_FILE_NAME,
	                                 O_CREAT | O_RDWR | O_SYNC | O_LARGEFILE,
	                                 S_IRUSR |S_IWUSR  |
	                                 S_IRGRP | S_IWGRP |
	                                 S_IROTH | S_IWOTH );

	if( m_MediaFileInfoCacheHandle == -1 ){
		debugMediaError("open file \"%s\" fails, errno=%d.\n",MEDIA_INFO_CACHE_FILE_NAME,errno);
		iOutRet = ERROR_FILE_OPEN_FAIL;
		goto error;
	}

	iOutRet = stat64(MEDIA_INFO_CACHE_FILE_NAME,&FileStat);
	if( iOutRet != ERROR_SUCCESS ){
		debugMediaError("stat64 file \"%s\" fails, errno=%d.\n",MEDIA_INFO_CACHE_FILE_NAME,errno);
		iOutRet = ERROR_FILE_READ_FAIL;
		goto error;
	}

	readSize = FileStat.st_size;
	if( readSize > MAX_MEDIA_INFO_CACHE_FILE_BUFFER_SIZE ){
		readSize = MAX_MEDIA_INFO_CACHE_FILE_BUFFER_SIZE;
	}else if(readSize<=0){
		//debugMediaInfo("file \"%s\" size is %d or so big\n",MEDIA_INFO_CACHE_FILE_NAME,readSize);
		goto ret;
	}

	fileBuffer = new char[readSize];
	if( fileBuffer == NULL ){
		debugMediaError("new memory fails.\n");
		iOutRet = ERROR_OUT_OF_MEMORY;
		goto error;
	}

	readSize = read( m_MediaFileInfoCacheHandle, (void*)fileBuffer, readSize );
	if( readSize == -1 || readSize < 0 ){
		debugMediaError("read file \"%s\" fails, errno=%d.\n",MEDIA_INFO_CACHE_FILE_NAME,errno);
		iOutRet = ERROR_FILE_READ_FAIL;
		goto error;
	}

#if 0/*debug*/
	debugMediaInfo("FileStat.st_size=%lld Bytes,CacheRecord size=%d Bytes,MAX_CACHE size=%d Bytes,readSize=%d Bytes\n",
	           FileStat.st_size,
	           sizeof(MediaFileInfoCacheRecord_t),
	           MAX_MEDIA_INFO_CACHE_FILE_BUFFER_SIZE,
	           readSize);
#endif

	if(readSize==0){
		debugMediaInfo("file \"%s\" size is %d\n",MEDIA_INFO_CACHE_FILE_NAME,readSize);
		goto ret;
	}

	p = fileBuffer;
	for(i=0;i<readSize;){
		recordLen = (*((INT_t*)p));
		switch( recordLen ){
			case sizeof(MediaFileInfoCacheRecord_t):{
				if((readSize-i) < sizeof(MediaFileInfoCacheRecord_t)){
					debugMediaError("Bad Media info cache records, size %d.\n",readSize-i);
					goto ret;
				}
				pMediaFileInfoCacheRecord_t pCacheRecord=(pMediaFileInfoCacheRecord_t)p;
				RMuint32 check_crc = CalculateCRC((RMuint8*)(pCacheRecord),recordLen-sizeof(pCacheRecord->check_crc));
				if( pCacheRecord->check_crc == check_crc ){
					//debugMediaInfo("Load MediaInfoCache(%s)\n",pCacheRecord->FilePathName);
					MediaFileInfo_sp = SharedPtr <CMediaFileInfo> (new CMediaFileInfo);
					if(MediaFileInfo_sp.isNull()){
						debugMediaError("new memory fails.\n");
						iOutRet = ERROR_OUT_OF_MEMORY;
						goto error;
					}
					RMMemcpy( &MediaFileInfo_sp->m_CacheRecord, pCacheRecord, sizeof(MediaFileInfo_sp->m_CacheRecord) );
					m_MediaFileInfoMap[(LPCSTR)pCacheRecord->FilePathName] = MediaFileInfo_sp;
                }else{
					nErrorRecord++;
                	debugMediaError("Check CRC error, \"%s\" source pCacheRecord->check_crc (0x%08x) != check_crc (0x%08x) \n",
                	               pCacheRecord->FilePathName,
                	               pCacheRecord->check_crc,
                	               check_crc );
				}
				break;
			}
			default:
				recordLen = sizeof(MediaFileInfoCacheRecord_t);
				debugMediaError("Unknown Media info cache records format, try to record size %d.\n",recordLen);
				break;
		}
		/*For next record*/
		i += recordLen;
		p += recordLen;
	}

ret:/*It's OK*/
	if(nErrorRecord){//added by lxj 2013-3-13
		debugMediaInfo("Remove %d error reocrds\n",nErrorRecord);
		RemoveOldCacheItemsFromFile();
	}
	iOutRet = ERROR_SUCCESS;

error:
	if(fileBuffer){
		delete[] fileBuffer;
		fileBuffer = NULL;
	}

	return iOutRet;
}

INT_t CMediaFileInfoCache::UnloadMediaInfoCacheFile(void)
{
	INT_t iOutRet=-1;
	if(m_MediaFileInfoCacheHandle != -1 ){
		if(close(m_MediaFileInfoCacheHandle)==ERROR_SUCCESS){
			m_MediaFileInfoCacheHandle = -1;
			iOutRet = ERROR_SUCCESS;
		}else{
			debugMediaError("close file handle fails, errno=%d\n",errno);
			iOutRet = ERROR_FAILED;
		}
	}
	return iOutRet;
}

INT_t CMediaFileInfoCache::RemoveOldCacheItemsFromFile(void)
{
	INT_t iOutRet=-1,recordCount,writeSize;
	SharedPtr <CMediaFileInfo> MediaFileInfo_sp;
	MediaFileInfo_map::iterator itMediaFileInfo;
	pMediaFileInfoCacheRecord_t pRecordCache=NULL;
	char *fileBuffer=NULL;

	recordCount = m_MediaFileInfoMap.size();
	if( recordCount > MAX_CACHE_ITEMS ){
		recordCount = MAX_CACHE_ITEMS;
	}

	writeSize = sizeof(*pRecordCache) * recordCount;

	fileBuffer = new char[writeSize];
	if( fileBuffer == NULL ){
		debugMediaError("new memory fails.\n");
		iOutRet = ERROR_OUT_OF_MEMORY;
		goto error;
	}

	pRecordCache = (pMediaFileInfoCacheRecord_t)fileBuffer;
	for(itMediaFileInfo = m_MediaFileInfoMap.begin(); itMediaFileInfo != m_MediaFileInfoMap.end(); itMediaFileInfo++){
		MediaFileInfo_sp = itMediaFileInfo->second;
		if(MediaFileInfo_sp.isValid()){
			RMMemcpy( pRecordCache, &MediaFileInfo_sp->m_CacheRecord, sizeof(*pRecordCache) );
			//debugMediaInfo("move \"%s\"\n",pRecordCache->FilePathName);
			pRecordCache++;
		}
	}

	iOutRet = lseek64( m_MediaFileInfoCacheHandle, 0, SEEK_SET );
	if(iOutRet == -1){
		debugMediaError("seek file \"%s\" fails, errno=%d\n",MEDIA_INFO_CACHE_FILE_NAME,errno);
		iOutRet = ERROR_FILE_READ_FAIL;
		goto error;
	}

	iOutRet = write( m_MediaFileInfoCacheHandle, fileBuffer, writeSize );
	if(iOutRet != writeSize){
		debugMediaError("write file \"%s\" fails, expected writeSize (%d) != really iOutRet (%d), errno=%d\n",MEDIA_INFO_CACHE_FILE_NAME,writeSize,iOutRet,errno);
		iOutRet = ERROR_FILE_WRITE_FAIL;
		goto error;
	}

	iOutRet = ftruncate( m_MediaFileInfoCacheHandle, writeSize );
	if(iOutRet != ERROR_SUCCESS){
		debugMediaError("truncate file \"%s\" fails, errno=%d\n",MEDIA_INFO_CACHE_FILE_NAME,errno);
		iOutRet = ERROR_FILE_WRITE_FAIL;
		goto error;
	}

	/*It's OK*/
	iOutRet = ERROR_SUCCESS;

error:
	if(fileBuffer){
		delete[] fileBuffer;
		fileBuffer = NULL;
	}

	return iOutRet;
}

INT_t CMediaFileInfoCache::AddMediaInfoCacheToFile(const pMediaFileInfoCacheRecord_t pCacheRecord)
{
	INT_t iOutRet=-1;

	if(pCacheRecord==NULL){
		debugMediaError("parameter error\n");
		iOutRet = ERROR_INVALID_PARAMETER;
		goto error;
	}

	iOutRet = lseek64( m_MediaFileInfoCacheHandle, 0, SEEK_END );
	if(iOutRet == -1){
		debugMediaError("seek file \"%s\" fails, errno=%d\n",MEDIA_INFO_CACHE_FILE_NAME,errno);
		iOutRet = ERROR_FILE_READ_FAIL;
		goto error;
	}

	iOutRet = write( m_MediaFileInfoCacheHandle, pCacheRecord, sizeof(*pCacheRecord) );
	if(iOutRet != sizeof(*pCacheRecord)){
		debugMediaError("write file \"%s\" fails, expected writeSize (%d) != really iOutRet (%d), errno=%d\n",MEDIA_INFO_CACHE_FILE_NAME,sizeof(*pCacheRecord),iOutRet,errno);
		iOutRet = ERROR_FILE_WRITE_FAIL;
		goto error;
	}

	/*It's OK*/
	iOutRet = ERROR_SUCCESS;

error:
	return iOutRet;
}
#endif

struct RMFPStreamInfo * CMediaFileInfoCache::CloneRmfpStreamInfo(CONST struct RMFPStreamInfo2 * pOrigRmfpStreamInfo)
{
	struct RMFPStreamInfo * pRmfpStreamInfo = NULL;
	RMstatus eRMstatus = RM_OK;
	BOOL_t bErr = FALSE;

#if 1/*modify by lxj 2012-11-6*/
	do
	{
		if(NULL == pOrigRmfpStreamInfo)
		{
			break;
		}
		pRmfpStreamInfo = (typeof(pRmfpStreamInfo))RMMalloc(sizeof(*pRmfpStreamInfo));
		if(NULL == pRmfpStreamInfo)
		{
			bErr = TRUE;
			break;
		}
		ZeroMemory(pRmfpStreamInfo, sizeof(*pRmfpStreamInfo));
		pRmfpStreamInfo->Version = pOrigRmfpStreamInfo->Version;
		if(&pOrigRmfpStreamInfo->Video)
		{
			pRmfpStreamInfo->pVideo = (typeof(pRmfpStreamInfo->pVideo))RMMalloc(sizeof(*pRmfpStreamInfo->pVideo) * pOrigRmfpStreamInfo->VideoStreamCount);
			RMMemcpy(pRmfpStreamInfo->pVideo, &pOrigRmfpStreamInfo->Video,
				sizeof(*pRmfpStreamInfo->pVideo) * pOrigRmfpStreamInfo->VideoStreamCount);
			pRmfpStreamInfo->VideoStreamCount = pOrigRmfpStreamInfo->VideoStreamCount;
		}
		if(&pOrigRmfpStreamInfo->Audio)
		{
			pRmfpStreamInfo->pAudio = (typeof(pRmfpStreamInfo->pAudio))RMMalloc(sizeof(*pRmfpStreamInfo->pAudio) * pOrigRmfpStreamInfo->AudioStreamCount);
			RMMemcpy(pRmfpStreamInfo->pAudio, &pOrigRmfpStreamInfo->Audio,
				sizeof(*pRmfpStreamInfo->pAudio) * pOrigRmfpStreamInfo->AudioStreamCount);
			pRmfpStreamInfo->AudioStreamCount = pOrigRmfpStreamInfo->AudioStreamCount;
		}
		if(&pOrigRmfpStreamInfo->Data)
		{
			pRmfpStreamInfo->pData = (typeof(pRmfpStreamInfo->pData))RMMalloc(sizeof(*pRmfpStreamInfo->pData) * pOrigRmfpStreamInfo->DataStreamCount);
			RMMemcpy(pRmfpStreamInfo->pData, &pOrigRmfpStreamInfo->Data,
				sizeof(*pRmfpStreamInfo->pData) * pOrigRmfpStreamInfo->DataStreamCount);
			pRmfpStreamInfo->DataStreamCount = pOrigRmfpStreamInfo->DataStreamCount;
		}
		if(&pOrigRmfpStreamInfo->System)
		{
			pRmfpStreamInfo->pSystem = (typeof(pRmfpStreamInfo->pSystem))RMMalloc(sizeof(*pRmfpStreamInfo->pSystem) * pOrigRmfpStreamInfo->SystemStreamCount);
			RMMemcpy(pRmfpStreamInfo->pSystem, &pOrigRmfpStreamInfo->System,
				sizeof(*pRmfpStreamInfo->pSystem) * pOrigRmfpStreamInfo->SystemStreamCount);
			pRmfpStreamInfo->SystemStreamCount = pOrigRmfpStreamInfo->SystemStreamCount;
		}
	}while(FALSE);
#endif

	if(bErr)
	{
		if(pRmfpStreamInfo)
		{
			eRMstatus = RMFPReleaseStreamInfo2(pRmfpStreamInfo);
			if(RMFAILED(eRMstatus))
			{
				PRINT_BFILE_LINENO_RMSTATUS;
			}
			pRmfpStreamInfo = NULL;
		}
	}

	return pRmfpStreamInfo;
}

INT_t CMediaFileInfoCache::RemoveOldCacheItems(CONST int ItemCntToRemove/* = 1*/)
{
	INT_t iOutRet = ERROR_SUCCESS;
	int LeftItemCntToRemove = ItemCntToRemove;
	UINT64_t EarliestTimeMs = 0x7FFFFFFFFFFFFFFFULL;
	SharedPtr <CMediaFileInfo> MediaFileInfo_sp;

	do
	{
#if 1/*modify by lxj 2012-11-6*/
		while(0 < LeftItemCntToRemove )
		{
			/*search eariles item*/
			MediaFileInfo_map::iterator itMediaFileInfo;
			MediaFileInfo_map::iterator itEarliestMediaFileInfo = m_MediaFileInfoMap.end();
			for(itMediaFileInfo = m_MediaFileInfoMap.begin(); itMediaFileInfo != m_MediaFileInfoMap.end(); itMediaFileInfo++)
			{
				MediaFileInfo_sp = itMediaFileInfo->second;
				if(MediaFileInfo_sp.isValid())
				{
					if(itMediaFileInfo == m_MediaFileInfoMap.begin()){/*first*/
						EarliestTimeMs = MediaFileInfo_sp->m_CacheRecord.LastUseTimeMs;
						itEarliestMediaFileInfo = itMediaFileInfo;
					}
					//debugMediaInfo("%s,0x%08llX,EarliestTimeMs=0x%llX\n",MediaFileInfo_sp->m_CacheRecord.FilePathName,MediaFileInfo_sp->m_CacheRecord.LastUseTimeMs,EarliestTimeMs);
					if(MediaFileInfo_sp->m_CacheRecord.LastUseTimeMs < EarliestTimeMs)
					{
						EarliestTimeMs = MediaFileInfo_sp->m_CacheRecord.LastUseTimeMs;
						itEarliestMediaFileInfo = itMediaFileInfo;
					}
				}
			}
			if(itEarliestMediaFileInfo != m_MediaFileInfoMap.end())
			{
				//debugMediaInfo("Remove %s\n", (LPCSTR)(itEarliestMediaFileInfo->first));
				m_MediaFileInfoMap.erase(itEarliestMediaFileInfo);
			}
			LeftItemCntToRemove--;
		}
#endif
	}while(FALSE);

	return iOutRet;
}
