/*****************************************
 Copyright 2001-2007
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   soft_crc32.c
  @brief  This file provides with sample code for implementing RMFP's callbacks

	  This file is part of the test_rmfp suite

  @author Sebastian Frias Feltrer
  @date   2007-10-29
*/

/*
  **********************************************
  DISCLAIMER:

  - THIS IS TEST CODE, provided as sample code
  to help you understand what you should do to
  develop your own application based in RMFP.

  - This is NOT production grade code; It is not
  even a library, so any API defined here, CAN
  and WILL CHANGE without notice.

  **********************************************
*/

#define ALLOW_OS_CODE 1

#include "crc32.h"
#include <dcc/include/dcc_macros.h>

#include <stdio.h>
#include <stdlib.h>


// to remove
#include <llad/include/llad.h>
#include <llad/include/gbus.h>

struct CRC32Context {
	struct llad *pLLAD;
	struct gbus *pGBus;
};

static struct CRC32Context LocalContext = { 0, };

// to remove


#define LOCALDBG ENABLE

#define CRCPOLY_BE 0x04c11db7
#define CRCPOLY_LE 0xedb88320

static RMuint32 crc_table[256];

#define ADD_CRC32_BYTE(crc, c) (((crc) << 8) ^ crc_table[(((crc) >> 24) ^ (c)) & 0xFF])




static RMuint32 offset_address(RMuint32 tile_width_l2, RMuint32 tile_height_l2,
			       RMuint32 x, RMuint32 y, RMuint32 width, RMuint32 nb_comp);




RMstatus init_crc32(struct rmfp_main_thread_context_type *pHandle)
{
	RMuint32 crc, poly;
	RMuint32 i, j;

	RMDBGLOG((LOCALDBG, "%s\n", __FUNCTION__));

	// init big-endian CRC32 table
	poly = CRCPOLY_BE;
	for (i = 0; i < 256; i++) {
		crc = (i << 24);
		for (j = 8; j > 0; j--)
			crc = (crc & 0x80000000) ? (crc << 1) ^ poly : crc << 1;
		crc_table[i] = crc;
	}


	// to remove
	{
		RMascii LLADDevice[10];

		// open hardware for CRC32
		RMPrintAscii(LLADDevice, "%lu", pHandle->AppOptions.Playback.BoardIndex);

		LocalContext.pLLAD = llad_open(LLADDevice);
		if (!LocalContext.pLLAD) {
			RMNOTIFY((NULL, RM_ERROR, "Cannot open llad %s\n", LLADDevice));
			return RM_ERROR;
		}

		LocalContext.pGBus = gbus_open(LocalContext.pLLAD);
		if (!LocalContext.pGBus) {
			RMNOTIFY((NULL, RM_ERROR, "Cannot open gbus\n"));
			llad_close(LocalContext.pLLAD);
			return RM_ERROR;
		}
	}
	// to remove


	return RM_OK;
}


RMstatus deinit_crc32(struct rmfp_main_thread_context_type *pHandle)
{
	RMDBGLOG((LOCALDBG, "%s\n", __FUNCTION__));

	// to remove
	if (LocalContext.pGBus)
		gbus_close(LocalContext.pGBus);

	if (LocalContext.pLLAD)
		llad_close(LocalContext.pLLAD);
	// to remove


	return RM_OK;
}


RMstatus compute_crc32(struct rmfp_main_thread_context_type *pHandle,
		       RMuint32 buffer_start, RMuint32 buffer_tile_width,
		       RMuint32 xmin, RMuint32 xmax,
		       RMuint32 ymin, RMuint32 ymax, RMuint8 Tiled,
		       RMuint32 *pCheckSum)
{
	RMuint32 width, height;
	RMuint32 x, y;
	RMuint32 address;
	RMuint32 c;

	RMuint32 size;

	RMuint32 crc;

	RMuint32 tile_width_log2  = RMTILE_WIDTH_SHIFT;
	RMuint32 tile_height_log2 = RMTILE_HEIGHT_SHIFT;



	crc = 0xFFFFFFFF;

	// Some sanity checks
	if (!pHandle ||
	    xmin > 0x10000 ||
	    xmax > 0x10000 ||
	    ymin > 0x10000 ||
	    ymax > 0x10000 ||
	    buffer_tile_width > 0x10000000 ||
	    xmin == xmax ||
	    ymin == ymax ||
	    buffer_start == 0 ||
	    buffer_tile_width == 0) {
		RMDBGLOG((ENABLE, "invalid parameters!\n"));

		// invalid parameters!
		return RM_INVALID_PARAMETER;
	}


	width = xmax-xmin;
	height = ymax-ymin;
	size = width*height;


	if (Tiled) {

		// tiled buffer
		for (y = ymin; y < ymax; y++) {
			// Instead of using gbus_read_uint8 all the time, I use gbus_read_uint32 when possible.
			// As buffer_start is always aligned, it is enough that x%4==0 to know that the resulting
			// address will be 32bits aligned.
			x = xmin;
			// read the first bytes one by one up to an aligned x position
			for (; (x < xmax) && ((x & 0x3) != 0); x++) {
				address = buffer_start + offset_address(tile_width_log2, tile_height_log2, x, y, buffer_tile_width, 1);
				c = gbus_read_uint8(LocalContext.pGBus, address);
				crc = ADD_CRC32_BYTE(crc, c);
			}
			// read the bytes 4 by 4 up to the last aligned 32bits block in x position
			for (; x < (xmax & ~0x3); x+=4) {
				address = buffer_start + offset_address(tile_width_log2, tile_height_log2, x, y, buffer_tile_width, 1);
				c = gbus_read_uint32(LocalContext.pGBus, address);
				crc = ADD_CRC32_BYTE(crc, (c>>0));
				crc = ADD_CRC32_BYTE(crc, (c>>8));
				crc = ADD_CRC32_BYTE(crc, (c>>16));
				crc = ADD_CRC32_BYTE(crc, (c>>24));
			}
			// read the remaining bytes one by one up to xmax
			for (; x < xmax; x++) {
				address = buffer_start + offset_address(tile_width_log2, tile_height_log2, x, y, buffer_tile_width, 1);
				c = gbus_read_uint8(LocalContext.pGBus, address);
				crc = ADD_CRC32_BYTE(crc, c);
			}

		}

	}
	else {
		// standard buffer
		for (y = ymin; y < ymax; y++) {
			for (x = xmin; x < xmax; x++) {
				address = buffer_start + x + y * buffer_tile_width * (1 << tile_width_log2);
				c = gbus_read_uint8(LocalContext.pGBus, address);
				crc = (crc << 8) ^ crc_table[((crc >> 24) ^ c) & 0xFF];
			}
		}
	}


	if (pCheckSum)
		*pCheckSum = crc;

	return RM_OK;
}


/*
  Internal functions
*/


static RMuint32 offset_address(RMuint32 tile_width_log2, RMuint32 tile_height_log2,
			       RMuint32 x, RMuint32 y, RMuint32 width, RMuint32 nb_comp)
{
	return
	(y >> tile_height_log2) * (width << (tile_width_log2 + tile_height_log2))
	+ ((y & ((1 << tile_height_log2) - 1)) << tile_width_log2)
	+ (((x * nb_comp) >> tile_width_log2) << (tile_width_log2 + tile_height_log2))
	+ ((x * nb_comp) & ((1 << tile_width_log2) - 1));
}

