#ifndef	ALLOW_OS_CODE
#define	ALLOW_OS_CODE
#endif

#include "Smp86xxGpioCtrl.h"
#include <ErrPrintHelper.h>
#include <BaseErrDef.h>
#if (EM86XX_CHIP >= EM86XX_CHIPID_TANGO3)
#include <emhwlib_hal/include/tango3/emhwlib_registers_tango3.h>
#endif

namespace Smp86xx
{

#define	TICKS_HZ		XTAL_HZ

CSmp86xxGpioCtrl::CSmp86xxGpioCtrl()
{
	INT_t iRet;

	do
	{
		iRet = CommonConstruct();
		if(ERROR_SUCCESS != iRet)
		{
			break;
		}
		{
			m_pLlad = llad_open((RMascii *)"0");
			if(NULL == m_pLlad)
			{
				LOG("Failed to open llad dev\n");
				break;
			}
		}
		{
			m_pGbus = gbus_open(m_pLlad);
			if(NULL == m_pGbus)
			{
				LOG("Failed to open gbus\n");
				break;
			}
		}

		m_bInited = TRUE;
	}while(FALSE);
}

INT_t CSmp86xxGpioCtrl::CommonConstruct()
{
	INT_t iOutRet = ERROR_SUCCESS;

	do
	{
		m_bInited = FALSE;
		m_pLlad = NULL;
		m_pGbus = NULL;
	}while(FALSE);

	return iOutRet;
}

CSmp86xxGpioCtrl::~CSmp86xxGpioCtrl()
{
	if(m_pGbus)
	{
		gbus_close(m_pGbus);
		m_pGbus = NULL;
	}
	if(m_pLlad)
	{
		llad_close(m_pLlad);
		m_pLlad = NULL;
	}
}

BOOL_t CSmp86xxGpioCtrl::ChkInit()
{
	return m_bInited;
}

INT_t CSmp86xxGpioCtrl::setGpioDirection(enum GPIOId_type GpioId, INT_t Direction)
{
	INT_t iOutRet = ERROR_SUCCESS;
	RMuint32 BitId = 0;
	RMuint32 DirectionBitVal = 0;

	do
	{
		if(FALSE == m_bInited)
		{
			iOutRet = ERR_NOT_INITIALIZED;
			break;
		}

		if(GPIO_OUTPUT == Direction)
		{
			DirectionBitVal = 0x00000001;
		}
		
		switch(GpioId)
		{
			case GPIOId_Sys_0:
			case GPIOId_Sys_1:
			case GPIOId_Sys_2:
			case GPIOId_Sys_3:
			case GPIOId_Sys_4:
			case GPIOId_Sys_5:
			case GPIOId_Sys_6:
			case GPIOId_Sys_7:
			case GPIOId_Sys_8:
			case GPIOId_Sys_9:
			case GPIOId_Sys_10:
			case GPIOId_Sys_11:
			case GPIOId_Sys_12:
			case GPIOId_Sys_13:
			case GPIOId_Sys_14:
			case GPIOId_Sys_15:
				BitId = GpioId;
				gbus_write_uint32(m_pGbus, REG_BASE_system_block + SYS_gpio_dir, 
					(0x00010000 | DirectionBitVal) << BitId);
				break;
			default:
				iOutRet = ERROR_INVALID_PARAMETER;
		}
	}while(FALSE);

	return iOutRet;
}

INT_t CSmp86xxGpioCtrl::setGpioData(enum GPIOId_type GpioId, BOOL_t bValue)
{
	INT_t iOutRet = ERROR_SUCCESS;
	RMuint32 BitId = 0;
	RMuint32 DataBitVal = 0;

	do
	{
		if(FALSE == m_bInited)
		{
			iOutRet = ERR_NOT_INITIALIZED;
			break;
		}

		if(bValue)
		{
			DataBitVal = 0x00000001;
		}
		
		switch(GpioId)
		{
			case GPIOId_Sys_0:
			case GPIOId_Sys_1:
			case GPIOId_Sys_2:
			case GPIOId_Sys_3:
			case GPIOId_Sys_4:
			case GPIOId_Sys_5:
			case GPIOId_Sys_6:
			case GPIOId_Sys_7:
			case GPIOId_Sys_8:
			case GPIOId_Sys_9:
			case GPIOId_Sys_10:
			case GPIOId_Sys_11:
			case GPIOId_Sys_12:
			case GPIOId_Sys_13:
			case GPIOId_Sys_14:
			case GPIOId_Sys_15:
				BitId = GpioId;
				gbus_write_uint32(m_pGbus, REG_BASE_system_block + SYS_gpio_data, 
					(0x00010000 | DataBitVal) << BitId);
				break;
			default:
				iOutRet = ERROR_INVALID_PARAMETER;
		}
	}while(FALSE);

	return iOutRet;
}

VOID CSmp86xxGpioCtrl::DelayUs(INT_t DelayTimeUs)
{
	INT_t iCountTimeHz = 0;
	RMuint32 PrevXtalCnt = 0, CurXtalCnt;

	PrevXtalCnt = gbus_read_uint32(m_pGbus, REG_BASE_system_block + SYS_xtal_in_cnt);
	//LOG_BLINE("PrevXtalCnt=%lu\n", PrevXtalCnt);
	while((iCountTimeHz / (TICKS_HZ / (1*1000*1000))) < DelayTimeUs)
	{
		CurXtalCnt = gbus_read_uint32(m_pGbus, REG_BASE_system_block + SYS_xtal_in_cnt);
		//LOG_BLINE("CurXtalCnt=%lu\n", CurXtalCnt);
		if(CurXtalCnt != PrevXtalCnt)
		{
			if(CurXtalCnt > PrevXtalCnt)
			{
				iCountTimeHz += (CurXtalCnt - PrevXtalCnt);
			}
			else	//CurXtalCnt < PrevXtalCnt
			{
				iCountTimeHz += (0xFFFFFFFF - (PrevXtalCnt - CurXtalCnt) + 1);
			}
			PrevXtalCnt = CurXtalCnt;
		}
	}
}

}	//namespace Smp86xx

