#ifndef	_MEDIA_SRV_INTERFACE_H_
#define	_MEDIA_SRV_INTERFACE_H_

#include <SharedPtr.h>

using namespace CppBase;

class IMediaFileInfoCache
{
public:
	typedef struct
	{
		const RMascii * pszFileName;
	}FIND_STREAM_INFO_IN_PARAM, *P_FIND_STREAM_INFO_IN_PARAM;
	typedef struct
	{
		struct RMFPStreamType RmfpStreamType;
		struct RMFPStreamInfo * pRmfpStreamInfo;		
	}FIND_STREAM_INFO_OUT_PARAM, *P_FIND_STREAM_INFO_OUT_PARAM;
public:
	virtual INT_t FindStreamInfoInCache(CONST IMediaFileInfoCache::P_FIND_STREAM_INFO_IN_PARAM pFindInParam, 
		IMediaFileInfoCache::P_FIND_STREAM_INFO_OUT_PARAM pFindOutParam) = 0;
	virtual INT_t AddMediaInfoCache(const RMascii * pszFileName, CONST struct RMFPStreamType * pRmfpStreamType, 
		CONST struct RMFPStreamInfo * pRmfpStreamInfo) = 0;
};

SharedPtr <IMediaFileInfoCache> getMediaFileInfoCacheSrvSp();

#endif	//_MEDIA_SRV_INTERFACE_H_

