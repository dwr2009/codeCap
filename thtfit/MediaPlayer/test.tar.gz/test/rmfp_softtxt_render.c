/*****************************************
 Copyright 2001-2007
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
*****************************************/
/**
   @file   rmfp_softtxt_render.c
   @brief  This file provides software teletext rendering for rmsofttxt


   @author Faizal Fikhri ZAKARIA
   @date   2009-2-27

   @TODO :
   - real time clock is not optimized
   - Lazy cache bugs for real time clock string
*/


#include "rmfp_internal.h"
#include "rmsofttxt/include/rmsofttxt.h"


/*********************************************************************/
/************************ RMDBGLOG debug *****************************/
/*********************************************************************/

#if 0
#define LOCALDBG ENABLE
#else
#define LOCALDBG DISABLE
#endif
#define PTD_DBG  DISABLE
#define DF_DBG   DISABLE

/*********************************************************************/
/************************ Configuration ******************************/
/*********************************************************************/

#define TRUE_COLOR                    0
#define USE_OTHER_FONT                1

/*********************************************************************/
/****************************** Size *********************************/
/*********************************************************************/

/* hack for bugID 10859 */
#define WAIT_FOR_OSD_FIX

#ifdef WAIT_FOR_OSD_FIX
#define OSD_NUMBER                    3
#else
#define OSD_NUMBER                    2
#endif

#define MAX_LAZY_CACHE              150

/*********************************************************************/
/************************** Misc Functions ***************************/
/*********************************************************************/

#define PRINT_ELAPSED(t_i, t_f, msg)					\
	do {								\
		RMuint64 Ti = (RMuint64)t_i;				\
		RMuint64 Tf = (RMuint64)t_f;				\
									\
		RMDBGLOG((ENABLE, "%s took %lld us (Ti = %llu, Tf = %llu)\n", msg, Tf - Ti, Ti, Tf)); \
									\
	} while(0)


/*********************************************************************/
/************************ Structure Declaration **********************/
/*********************************************************************/

struct RMFPSoftTXTRenderHandle {
	
	// RMSoftTXTHandle , teletext handler
	struct RMSoftTXTHandle * pSoftTXTHandle;

	// OSD 
	struct RMLibPlayOSDSource OSDSource;
		
	struct RMLibPlayOSDPicture currentOSD;
	struct RMLibPlayOSDPicture onScreenOSD;
	RMbool onScreenOSD_set;
	/* for current OSD */
	RMuint8 *pLumaBuffer;  // locked and mapped
	RMuint32 LumaSize;
	/* for on Screen OSD (for real time clock refresh) */
	RMuint8 *pLumaBuffer_RTClk;  // locked and mapped
	RMuint32 LumaSize_RTClk;

	struct RMFontRenderSurface *pSurface;

	RMpalette_8BPP TXTPaletteMix;
	RMpalette_8BPP TXTPaletteNotMix;

	RMuint8 *pFontName_normal;
	RMuint8 *pFontName_mosaic;

	/* mode mix or non mix */
	RMbool isMix;

	/* lazy cache */
	struct RMFPSoftTXTRender_LazyCache{
		/* glyph */
		struct RMFontRenderGlyphChain *glyphChain;
		/* parameters */
		RMuint32 width;
		RMuint32 height;
		RMuint32 length;
		RMuint8  pString[10];
		/* test */
		RMbool used;
		/* mosaic or normal */
		RMbool isMosaic;
				
	}lazyCache[MAX_LAZY_CACHE];
	/* lazy cache pointer */
	RMint32 LC_pointer;
	RMbool txtON;

	/* for debug purpose */
	RMuint32 fontNotFoundCount;
};

/*********************************************************************/
/**************************** Prototype ******************************/
/*********************************************************************/

static RMstatus softtxt_get_string_size(void *pContext,
					RMuint8 *pChars,
					RMuint32 CharSize,
					RMuint32 *pWidth,
					RMuint32 *pHeight,
					RMbool isMosaic);
static RMstatus softtxt_draw_string(void *pContext,
				    RMuint32 PosX,
				    RMuint32 PosY,
				    RMuint8 *pChars,
				    RMuint32 FGColor,
				    RMuint32 CharHeight,
				    RMuint32 CharWidth,
				    RMbool isMosaic);
static RMstatus softtxt_draw_rect(void *pContext,
				  RMuint32 PosX,
				  RMuint32 PosY,
				  RMuint32 Width,
				  RMuint32 Height,
				  RMuint32 Color);
static RMstatus softtxt_prepare_to_draw(void *pContext, 
					RMbool isTXTSub,
					RMbool isRTClk);

static RMstatus softtxt_set_osd(void * pContext, 
				RMbool isRTClk);
static RMstatus softtxt_exit_teletext(void *pContext);

static RMstatus softtxt_get_blending_color_index(void * pContext, 
						 RMuint8 FG,
						 RMuint8 BG, 
						 RMuint8 Alpha, 
						 RMuint8 * NewIndex);

/************************************************************************************************/

/*
 * OPEN softtxt render
 */ 
RMstatus rmfp_internal_open_softtxt_render(struct RMFPSoftTXTRenderHandle **ppHandle, 
					   struct RMFPSoftTXTRenderProfile *pProfile)
{
		
	struct RMFontRenderFontInfo FontInfo;
	RMascii * mosaicFont = "Arial Alternative Symbol";
#if USE_OTHER_FONT
	RMascii * normalFont = "Arial Alternative";
//	RMascii * normalFont = "Courier";
#endif
	struct RMSoftTXTHandle * pSoftTXTHandle;
	struct RMSoftTXTProfile STXTProfile;
	RMstatus status;
	struct RMLibPlayOSDProfile OSDProfile;
	struct RMFPHandle * pHandle = (struct RMFPHandle *) pProfile->pHandle;

	RMDBGLOG((LOCALDBG, "rmfp_internal_open_softtxt_render()\n"));

	if ( !pProfile->pHandle->profile.pFontRenderHandle ) {
		RMNOTIFY((NULL, RM_FATALINVALIDPOINTER, "Invalid RMFontRender handle\n"));
		return RM_FATALINVALIDPOINTER;
	}


	pHandle->pSoftTXTRenderHandle = ( struct RMFPSoftTXTRenderHandle * ) RMMalloc( sizeof( struct RMFPSoftTXTRenderHandle ) );
	if (!pHandle->pSoftTXTRenderHandle) {
		RMNOTIFY((NULL, RM_FATALOUTOFMEMORY, "Not enough memory\n"));
		return RM_FATALOUTOFMEMORY;
	}
	RMMemset((void*)pHandle->pSoftTXTRenderHandle, 0, sizeof(struct RMFPSoftTXTRenderHandle));


	/********************************************************************/
	/******************************* FONT *******************************/
	/********************************************************************/
	
	/* search a monospaced font */
	{
		RMuint32 i = 0;
		RMbool Found = FALSE;
		while (1) {
			
			status = RMFontRenderGetFontInfo(pHandle->profile.pFontRenderHandle, i, &FontInfo);
			if (status != RM_OK)
				break;
			
			if (FontInfo.FixedWidth) {
				RMDBGLOG((LOCALDBG, "Fixed!\n"));
				Found = TRUE;
				break;
			}
			else
				RMDBGLOG((LOCALDBG, "Variable\n"));
			
			i++;
		}
		
		if (!Found) {
			
			RMDBGLOG((LOCALDBG, "Couldn't find fixed width font\n"));
			
			if (pHandle->profile.pCCFontName) {
				
				RMDBGLOG((LOCALDBG, "using default CC font\n"));
				
				FontInfo.pFontName = pHandle->profile.pCCFontName;
			}
			else {
				RMDBGLOG((LOCALDBG, "using first font\n"));
				
				status = RMFontRenderGetFontInfo(pHandle->profile.pFontRenderHandle, 0, &FontInfo);
				if (status != RM_OK) {
					RMDBGLOG((ENABLE, "no suitable fonts found\n"));
					return status;
				}
			}
		}
	}
#if USE_OTHER_FONT
	pHandle->pSoftTXTRenderHandle->pFontName_normal = (RMuint8 *) normalFont;
#else
	pHandle->pSoftTXTRenderHandle->pFontName_normal = FontInfo.pFontName;
#endif
	pHandle->pSoftTXTRenderHandle->pFontName_mosaic = (RMuint8 *) mosaicFont;

	RMDBGLOG((LOCALDBG, "mosaic font : %s, normal font : %s \n",
		  pHandle->pSoftTXTRenderHandle->pFontName_mosaic,
		  pHandle->pSoftTXTRenderHandle->pFontName_normal));


	/********************************************************************/
	/*********************** Teletext decoder ***************************/
	/********************************************************************/

	STXTProfile.PresentationLevel = RMSoftTXT_Level_1;
	STXTProfile.SurfaceWidth  = 720;
	STXTProfile.SurfaceHeight = 576;

	STXTProfile.MaxUsableOSD = 2;

	STXTProfile.pCallbackContext      = pHandle;
	STXTProfile.GetStringSizeCallback = softtxt_get_string_size;
	STXTProfile.DrawStringCallback    = softtxt_draw_string;
	STXTProfile.DrawRectangleCallback = softtxt_draw_rect;
	STXTProfile.PrepareToDrawCallback = softtxt_prepare_to_draw;
	STXTProfile.SetOSDCallback        = softtxt_set_osd;

	status = RMSoftTXTOpen( &STXTProfile, &pSoftTXTHandle );// &(pSoftTXTRenderHandle->pSoftTXTHandle)  );
	if (( status != RM_OK ) || ( pSoftTXTHandle == NULL ))
	{
		if (status == RM_OK)
			status = RM_ERROR;
				
		RMNOTIFY((NULL, ENABLE, "Cannot open RMSoftTXT\n"));
		return status;
	}

	RMDBGLOG((LOCALDBG, "get Software teletext palette\n"));

	status = RMSoftTXTGetPalette(&(pHandle->pSoftTXTRenderHandle->TXTPaletteMix), TRUE);
	if (status != RM_OK){
		RMNOTIFY((NULL, status, "Cannot get Mix palette\n"));

		goto exit_with_error;
	}

	status = RMSoftTXTGetPalette(&(pHandle->pSoftTXTRenderHandle->TXTPaletteNotMix), FALSE);
	if (status != RM_OK){
		RMNOTIFY((NULL, status, "Cannot get Not Mix palette\n"));

		goto exit_with_error;
	}
		
	/********************************************************************/
	/********************************* OSD ******************************/
	/********************************************************************/

	RMDBGLOG((LOCALDBG, "open soft TXT OSD\n"));

	OSDProfile.NumberOfPictures = OSD_NUMBER;

/* color mode */
#if TRUE_COLOR
	OSDProfile.Profile.ColorMode = EMhwlibColorMode_TrueColor;
#else
	OSDProfile.Profile.ColorMode = EMhwlibColorMode_LUT_8BPP;
#endif
	OSDProfile.Profile.ColorFormat  = EMhwlibColorFormat_32BPP;

	OSDProfile.Profile.Width  = STXTProfile.SurfaceWidth;
	OSDProfile.Profile.Height = STXTProfile.SurfaceHeight;
		
	OSDProfile.Profile.ColorSpace   = EMhwlibColorSpace_RGB_0_255;
	OSDProfile.Profile.SamplingMode = EMhwlibSamplingMode_444;

	OSDProfile.ForcedOSDSize  = TRUE;

	OSDProfile.Profile.PixelAspectRatio.X = 1;
	OSDProfile.Profile.PixelAspectRatio.Y = 1;
		
	/* open osd */
	status = rmfp_internal_open_osd_handler((void*)pHandle, &OSDProfile, &(pHandle->pSoftTXTRenderHandle->OSDSource));
	if (status != RM_OK) {
		RMNOTIFY((NULL, status, "Couldn't open OSD for soft teletext rendering\n"));

		goto exit_with_error;
	}

	/* get osd picture handler */
	status = rmfp_internal_get_osd_picture_handler((void*)pHandle,
						       &(pHandle->pSoftTXTRenderHandle->OSDSource),
						       &(pHandle->pSoftTXTRenderHandle->currentOSD));
	if (status != RM_OK) {
		RMNOTIFY((NULL, status, "Couldn't get picture\n"));
		
		goto exit_with_error;
	}
	pHandle->pSoftTXTRenderHandle->currentOSD.pPalette = (RMuint32*)&(pHandle->pSoftTXTRenderHandle->TXTPaletteNotMix);


	/********************************************************************/
	/************************* SETTING LUMA *****************************/
	/********************************************************************/
				
	{
		RMuint32 LumaAddr, LumaSize;
		RMuint8 *luma_buf;
		
		LumaAddr = pHandle->pSoftTXTRenderHandle->currentOSD.LumaBufferAddress;
		LumaSize = pHandle->pSoftTXTRenderHandle->currentOSD.LumaBufferSize;

		RMDBGLOG((LOCALDBG, "Locking OSD buffer at 0x%08lx (0x%08lx bytes)\n", LumaAddr, LumaSize));
	
		//palette
		pHandle->pSoftTXTRenderHandle->currentOSD.pPalette = (RMuint32*)&(pHandle->pSoftTXTRenderHandle->TXTPaletteNotMix);
		

		status = RUALock(pHandle->profile.pRUA, LumaAddr, LumaSize);
		if (status != RM_OK) {
			RMNOTIFY((NULL, status, "Locking OSD buffer at 0x%08lx (0x%08lx bytes)\n", LumaAddr, LumaSize));
			
			goto exit_with_error;
		}
		
		luma_buf = RUAMap(pHandle->profile.pRUA, LumaAddr, LumaSize);
		if (!luma_buf) {
			RMNOTIFY((NULL, RM_ERROR, "Error mapping OSD buffer at 0x%08lX (0x%08lX bytes)\n", LumaAddr, LumaSize));
			status = RM_ERROR;
				
			goto exit_with_error;
		}
		
		RMMemset(luma_buf, 0, LumaSize);
		
		pHandle->pSoftTXTRenderHandle->LumaSize    = LumaSize;
		pHandle->pSoftTXTRenderHandle->pLumaBuffer = luma_buf;
		
		status = rmfp_internal_set_osd_picture_handler((void*)pHandle,
												   &(pHandle->pSoftTXTRenderHandle->OSDSource),
												   &(pHandle->pSoftTXTRenderHandle->currentOSD));
		if (status != RM_OK) {
			RMNOTIFY((NULL, status, "Cannot set picture\n"));
			goto exit_with_error;
		}
	}
	
	pHandle->pSoftTXTRenderHandle->pSoftTXTHandle = pSoftTXTHandle;

	/********************************************************************/
	/******************************* Surface ****************************/
	/********************************************************************/
		
	pHandle->pSoftTXTRenderHandle->pSurface = (struct RMFontRenderSurface *)RMMalloc(sizeof(struct RMFontRenderSurface));
	if (!pHandle->pSoftTXTRenderHandle->pSurface) {
		status = RM_FATALOUTOFMEMORY;
		RMNOTIFY((NULL, status, "Not enough memory\n"));
		goto exit_with_error;
	}

	pHandle->pSoftTXTRenderHandle->pSurface->Width      = OSDProfile.Profile.Width;
	pHandle->pSoftTXTRenderHandle->pSurface->Height     = OSDProfile.Profile.Height;
		
	pHandle->pSoftTXTRenderHandle->pSurface->TotalWidth = OSDProfile.Profile.Width;

#if TRUE_COLOR
	pHandle->pSoftTXTRenderHandle->pSurface->ColorDepth = 32;
	pHandle->pSoftTXTRenderHandle->pSurface->pPalette = NULL;

#else
	pHandle->pSoftTXTRenderHandle->pSurface->ColorDepth = 8;
	pHandle->pSoftTXTRenderHandle->pSurface->pPalette = (RMuint32 *)&(pHandle->pSoftTXTRenderHandle->TXTPaletteNotMix);
#endif

	pHandle->pSoftTXTRenderHandle->pSurface->pPixelBuffer = pHandle->pSoftTXTRenderHandle->pLumaBuffer;

	pHandle->pSoftTXTRenderHandle->pSurface->GetBlendingColorIndex = softtxt_get_blending_color_index;

	/********************************************************************/
	/************************** Initialization **************************/
	/********************************************************************/
	
	/* Init mix mode, by default it is non mix mode */
	pHandle->pSoftTXTRenderHandle->isMix = FALSE;
	pHandle->pSoftTXTRenderHandle->LC_pointer = 0;
	pHandle->pSoftTXTRenderHandle->onScreenOSD_set = FALSE;
	pHandle->pSoftTXTRenderHandle->txtON = FALSE;

	pHandle->pSoftTXTRenderHandle->fontNotFoundCount = 0;

	*ppHandle = pHandle->pSoftTXTRenderHandle;

	return RM_OK;

exit_with_error:
			rmfp_internal_close_softtxt_render(pHandle);
			return status;

}

/************************************************************************************************/

/*
 * Close teletext renderer
 */
RMstatus rmfp_internal_close_softtxt_render(struct RMFPHandle *pHandle)
{
	RMstatus status;
	RMint32 cnt;
	
	RMDBGLOG((LOCALDBG, "rmfp_internal_close_softtxt_render()\n"));
	ASSERT_NULL_POINTER(pHandle);

	if ( !pHandle->profile.pFontRenderHandle )
		RMNOTIFY((NULL, RM_FATALINVALIDPOINTER, "Invalid RMFontRender handle\n"));

	if (pHandle->pSoftTXTRenderHandle) {

		/********************************************************************/
		/*********************** Empty Lazy Cache ***************************/
		/********************************************************************/
		for (cnt=0; cnt < MAX_LAZY_CACHE; cnt++) {
			if (pHandle->pSoftTXTRenderHandle->lazyCache[cnt].glyphChain) {
				RMFontRenderDestroyGlyphChain(pHandle->profile.pFontRenderHandle, pHandle->pSoftTXTRenderHandle->lazyCache[cnt].glyphChain);
				pHandle->pSoftTXTRenderHandle->lazyCache[cnt].glyphChain = NULL;
			}
		}
		

		/********************************************************************/
		/*********************** Close Teletext Decoder *********************/
		/********************************************************************/
		
		if ( pHandle->pSoftTXTRenderHandle->pSoftTXTHandle ) {

			RMDBGLOG((LOCALDBG, "close SoftTXTHandle\n"));
			status = RMSoftTXTClose( pHandle->pSoftTXTRenderHandle->pSoftTXTHandle );
			if (status != RM_OK)
				RMNOTIFY((NULL, status, "Cannot close RMSoftTXTHandle\n"));

			pHandle->pSoftTXTRenderHandle->pSoftTXTHandle = NULL;
		}

		if (pHandle->pSoftTXTRenderHandle->OSDSource.pHandler) {

			RMDBGLOG((LOCALDBG, "close soft TXT OSD\n"));

			/********************************************************************/
			/******************************* Close OSD **************************/
			/********************************************************************/
			if (pHandle->pSoftTXTRenderHandle->pLumaBuffer)
			RUAUnMap(pHandle->profile.pRUA,
				 pHandle->pSoftTXTRenderHandle->pLumaBuffer,
				 pHandle->pSoftTXTRenderHandle->LumaSize);

			if (pHandle->pSoftTXTRenderHandle->currentOSD.LumaBufferAddress) {
				status = RUAUnLock(pHandle->profile.pRUA,
						   pHandle->pSoftTXTRenderHandle->currentOSD.LumaBufferAddress,
						   pHandle->pSoftTXTRenderHandle->currentOSD.LumaBufferSize);
				
				if (status != RM_OK)
					RMNOTIFY((NULL, status, "Cannot unlock %p size %lu\n",
						    pHandle->pSoftTXTRenderHandle->currentOSD.LumaBufferAddress,
						    pHandle->pSoftTXTRenderHandle->currentOSD.LumaBufferSize));
			}
			

			rmfp_internal_close_osd_handler((void*)pHandle, &(pHandle->pSoftTXTRenderHandle->OSDSource));
			
		}

		/********************************************************************/
		/*************************** Close Surface **************************/
		/********************************************************************/

		if (pHandle->pSoftTXTRenderHandle->pSurface)
			RMFree(pHandle->pSoftTXTRenderHandle->pSurface);
				
		/* free teletext render */
		RMFree(pHandle->pSoftTXTRenderHandle);
		
	}	
	return RM_OK;
}

/************************************************************************************************/

/*
 * Parser teletext stream
 */ 
RMstatus rmfp_internal_softtxt_render_decode(struct RMFPSoftTXTRenderHandle * pSoftTXTRenderHandle, 
					     RMuint8 * buffer, 
					     RMuint32 buffer_size)
{
	
	ASSERT_NULL_POINTER(pSoftTXTRenderHandle);
	ASSERT_NULL_POINTER(buffer);

	return RMSoftTXTParseTeletext(pSoftTXTRenderHandle->pSoftTXTHandle , buffer, buffer_size );
}

/************************************************************************************************/

/*
 * Get string size
 */
static RMstatus softtxt_get_string_size(void *pContext,
					RMuint8 *pChars,
					RMuint32 CharSize,
					RMuint32 *pWidth,
					RMuint32 *pHeight,
					RMbool isMosaic)
{

	struct RMFPHandle *pHandle = NULL;
	struct RMFontRenderHandle *pFontRenderHandle = NULL;
	struct RMFPSoftTXTRenderHandle *pSoftTXTRenderHandle = NULL;
	struct RMFontRenderStringStyle Style = { 0, };
	RMuint32 CharsCount;
	RMuint32 Width, Height;

	RMstatus status;

	RMDBGLOG((LOCALDBG, "softtxt_get_string_size()\n"));
	RMDBGLOG((LOCALDBG, "string '%s' size %lu\n", pChars, CharSize));

	ASSERT_NULL_POINTER(pContext);
	ASSERT_NULL_POINTER(pChars);

	pHandle             = (struct RMFPHandle *)pContext;
	pSoftTXTRenderHandle = pHandle->pSoftTXTRenderHandle;
	pFontRenderHandle   = pHandle->profile.pFontRenderHandle;

	ASSERT_NULL_POINTER(pSoftTXTRenderHandle);
	ASSERT_NULL_POINTER(pFontRenderHandle);

	CharsCount = RMasciiLength((RMascii*)pChars);

	/********************************************************************/
	/*************************** Set Style ******************************/
	/********************************************************************/

	Style.Encoding = RMFontRenderCharEnconding_Latin;

	if ( isMosaic ) {
		Style.pFontName = pSoftTXTRenderHandle->pFontName_mosaic;
	}
	else {
		Style.pFontName = pSoftTXTRenderHandle->pFontName_normal;
	}

	Style.EnableKerning = FALSE;
	Style.Style = RMFontRenderFontStyle_Normal;

	Style.FontHeight = CharSize;

	Style.FillColor = 0xFFFFFFFF;

	Style.DrawBorder = FALSE;
	Style.BorderSize = 2;
	Style.BorderColor = 0xFF000000;

	Style.DrawShadow = FALSE;
	Style.ShadowSize = 4;
	Style.ShadowColor = 0x80101010;

	RMDBGLOG((LOCALDBG, "Font '%s'\n", Style.pFontName));

	status = RMFontRenderComputeCharsSize(pFontRenderHandle,
					      pChars,
					      CharsCount,
					      &Style,
					      &Width,
					      &Height);

	*pWidth = Width;
	*pHeight = Height;

	if (status != RM_OK)
		RMNOTIFY((NULL, status, "couldn't get chars size!\n"));

      	return status;
}

/************************************************************************************************/

/*
 * Draw String 
 */
static RMstatus softtxt_draw_string(void *pContext,
				    RMuint32 PosX,
				    RMuint32 PosY,
				    RMuint8 *pChars,
				    RMuint32 FGColor,
				    RMuint32 CharHeight,
				    RMuint32 CharWidth,
				    RMbool isMosaic)
{
	struct RMFPHandle *pHandle = NULL;
	struct RMFontRenderHandle *pFontRenderHandle = NULL;
	struct RMFPSoftTXTRenderHandle *pSoftTXTRenderHandle = NULL;

	struct RMFontRenderStringStyle Style = { 0, };
	struct RMFontRenderPoint StartPoint = { 0, };
	struct RMFontRenderBox OutBox = { 0, };
	struct RMFontRenderDrawParameter parameter = {0, };
	struct RMFontRenderGlyphChain *pGlyphChain = NULL;
		
	RMuint32 CharsCount;
	RMuint32 Width;
	RMuint32 Height;
	RMstatus status = RM_OK;
	RMint32 cnt;

	RMint32 slot = -1;
	RMbool glyphCreated = FALSE;

	RMDBGLOG((DISABLE, "softtxt_draw_string() [%lu, %lu] [0x%lx, %lu, %lu] '%s'\n",
		  PosX,
		  PosY,
		  FGColor,
		  CharHeight,
		  CharWidth,
		  pChars));


	ASSERT_NULL_POINTER(pContext);
	ASSERT_NULL_POINTER(pChars);

	pHandle = (struct RMFPHandle *)pContext;
	pSoftTXTRenderHandle = pHandle->pSoftTXTRenderHandle;
	pFontRenderHandle = pHandle->profile.pFontRenderHandle;

	ASSERT_NULL_POINTER(pSoftTXTRenderHandle);
	ASSERT_NULL_POINTER(pFontRenderHandle);

	CharsCount = RMasciiLength((RMascii*)pChars);
	if (CharsCount == 0) {
		return RM_OK;
	}

	/********************************************************************/
	/*************************** Set Style ******************************/
	/********************************************************************/

	if (isMosaic) {
		RMDBGLOG((DISABLE,"MOSAIC CHAR\n"));
		Style.Encoding = RMFontRenderCharEnconding_Latin;
		Style.pFontName     = pSoftTXTRenderHandle->pFontName_mosaic;
		//start
		StartPoint.X = PosX;
		StartPoint.Y = PosY;
	}
	else {
		RMDBGLOG((DISABLE,"NORMAL CHAR\n"));
		Style.Encoding = RMFontRenderCharEnconding_UTF8;
		Style.pFontName = pSoftTXTRenderHandle->pFontName_normal;
		//start
		StartPoint.X = PosX;
		StartPoint.Y = PosY;
	}

	Style.FontHeight = CharHeight;
	Style.FontWidth  = CharWidth;

	Style.EnableKerning = FALSE;
	Style.Style         = RMFontRenderFontStyle_Normal;

	Style.FillColor = FGColor;
	parameter.FillColor = FGColor;
	parameter.DrawBorder = FALSE;
	parameter.DrawShadow = FALSE;
	/********************************************************************/
	/************************** Create glyph chain **********************/
	/********************************************************************/
	
	/* check if the glyph is existed already in the cache */
	for (cnt=0; cnt< MAX_LAZY_CACHE; cnt++) {
		if (pSoftTXTRenderHandle->lazyCache[cnt].used) {
			if (RMCompareAscii((RMascii*)pChars, (RMascii*)pSoftTXTRenderHandle->lazyCache[cnt].pString) &&
			    pSoftTXTRenderHandle->lazyCache[cnt].width == CharWidth &&
			    pSoftTXTRenderHandle->lazyCache[cnt].height == CharHeight ) {
				if ((pSoftTXTRenderHandle->lazyCache[cnt].isMosaic & isMosaic) 
				    || (!pSoftTXTRenderHandle->lazyCache[cnt].isMosaic & !isMosaic) ) {
					glyphCreated = TRUE;	
					pGlyphChain = pSoftTXTRenderHandle->lazyCache[cnt].glyphChain;
					break;
				}
			}
		}
		
	}

	if (!glyphCreated) {
		/*get free slot in cache*/
		slot = pSoftTXTRenderHandle->LC_pointer;
		pSoftTXTRenderHandle->LC_pointer++;
		if (pSoftTXTRenderHandle->LC_pointer== MAX_LAZY_CACHE) {
			pSoftTXTRenderHandle->LC_pointer = 0;
		}

		status = RMFontRenderCreateGlyphChain(pFontRenderHandle,
						      pChars,
						      CharsCount,
						      &Style,
						      &Width,
						      &Height,
						      &pGlyphChain,
						      NULL);
	
		if (status == RM_NOT_FOUND) {
			
			RMNOTIFY((NULL, RM_NOT_FOUND, "%lu -- Char [%s] cannot be rendered with the selected font %s\n", 
				  pSoftTXTRenderHandle->fontNotFoundCount++,
				  pChars,
				  Style.pFontName));
			goto exit;
		}
		else if (status != RM_OK) {
			RMDBGLOG((ENABLE, "Couldn't create glyph chain\n"));
			goto exit;
		}
		/* save glyph */
		if (slot > -1 ) {

			/* destroy the last glyph first if there is any */
			if (pSoftTXTRenderHandle->lazyCache[slot].glyphChain) {
				RMFontRenderDestroyGlyphChain(pHandle->profile.pFontRenderHandle, pHandle->pSoftTXTRenderHandle->lazyCache[slot].glyphChain);
				pSoftTXTRenderHandle->lazyCache[slot].glyphChain = NULL;
			}

			if (pSoftTXTRenderHandle->lazyCache[slot].glyphChain) {
				RMNOTIFY((NULL, RM_ERROR, "the cache is occupied ?? \n"));
				goto Draw_glyph;
			}

			pSoftTXTRenderHandle->lazyCache[slot].glyphChain = pGlyphChain;
			pSoftTXTRenderHandle->lazyCache[slot].length = CharsCount;
			pSoftTXTRenderHandle->lazyCache[slot].width = CharWidth;
			pSoftTXTRenderHandle->lazyCache[slot].height = CharHeight;
			pSoftTXTRenderHandle->lazyCache[slot].isMosaic = isMosaic;
			RMCopyAscii((RMascii*)pSoftTXTRenderHandle->lazyCache[slot].pString, (RMascii*)pChars);
			pSoftTXTRenderHandle->lazyCache[slot].used = TRUE;
			RMDBGLOG((DISABLE, "save GLyph %s, %s %x slot %d\n",
				  pChars, pSoftTXTRenderHandle->lazyCache[slot].pString,
				  pSoftTXTRenderHandle->lazyCache[slot].glyphChain, 
				  slot ));
		}
		else {
			RMDBGLOG((ENABLE, "~~~~~~~~~~~~~~no free slot \n"));
		}

	}

Draw_glyph:

	/********************************************************************/
	/*************************** Draw glyph chain ***********************/
	/********************************************************************/
	
	if (pGlyphChain) {
		status = RMFontRenderDrawGlyphChainWithParameter(pFontRenderHandle,
								 pSoftTXTRenderHandle->pSurface,
								 &StartPoint,
								 pGlyphChain,
								 &OutBox,
								 &parameter);
	}
	else {
		RMNOTIFY((NULL, status, "There is no glyph chain!\n"));	
	}

	if (status != RM_OK)
		RMNOTIFY((NULL, status, "Couldn't draw chars!\n"));

	return status;
exit:
	if (pGlyphChain)
		RMFontRenderDestroyGlyphChain(pFontRenderHandle, pGlyphChain);

	return status;

}

/************************************************************************************************/

/*
 * prepare to draw, prepare OSD, surface etc
 */
static RMstatus softtxt_prepare_to_draw(void *pContext, RMbool isTXTSub, RMbool isRTClk)
{
	
	struct RMFPHandle *pHandle = NULL;
	RMstatus status = RM_OK;
	ASSERT_NULL_POINTER(pContext);
	RMDBGLOG((DISABLE, "prepare_to_draw\n"));
	pHandle = (struct RMFPHandle *)pContext;
	
	if (pHandle->pSoftTXTRenderHandle->OSDSource.pHandler) {

		RMuint32 LumaAddr, LumaSize;
		RMuint8 *luma_buf;

		/* prepare to draw for a page , not real time clock refresh */
		if (!isRTClk) {

			RMDBGLOG((DISABLE, "unmap/unlock current picture\n"));
			if (pHandle->pSoftTXTRenderHandle->pLumaBuffer)
				RUAUnMap(pHandle->profile.pRUA,
					 pHandle->pSoftTXTRenderHandle->pLumaBuffer,
					 pHandle->pSoftTXTRenderHandle->LumaSize);

			if (pHandle->pSoftTXTRenderHandle->currentOSD.LumaBufferAddress) {
				status = RUAUnLock(pHandle->profile.pRUA,
						   pHandle->pSoftTXTRenderHandle->currentOSD.LumaBufferAddress,
						   pHandle->pSoftTXTRenderHandle->currentOSD.LumaBufferSize);

				if (status != RM_OK)
					RMNOTIFY((NULL, status, "Cannot unlock %p size %lu\n",
						    pHandle->pSoftTXTRenderHandle->currentOSD.LumaBufferAddress,
						    pHandle->pSoftTXTRenderHandle->currentOSD.LumaBufferSize));
			}
		
			status = rmfp_internal_get_osd_picture_handler((void*)pHandle,
								       &(pHandle->pSoftTXTRenderHandle->OSDSource),
								       &(pHandle->pSoftTXTRenderHandle->currentOSD));
			if (status != RM_OK) {
				RMNOTIFY((NULL, status, "Couldn't get picture\n"));
				
				goto exit_with_error;
			}

			LumaAddr = pHandle->pSoftTXTRenderHandle->currentOSD.LumaBufferAddress;
			LumaSize = pHandle->pSoftTXTRenderHandle->currentOSD.LumaBufferSize;

			/* check palette mode */
			if (pHandle->pSoftTXTRenderHandle->isMix) {
				pHandle->pSoftTXTRenderHandle->currentOSD.pPalette = (RMuint32*) &(pHandle->pSoftTXTRenderHandle->TXTPaletteMix);
			}
			else {
				pHandle->pSoftTXTRenderHandle->currentOSD.pPalette = (RMuint32*) &(pHandle->pSoftTXTRenderHandle->TXTPaletteNotMix);
			}

			status = RUALock(pHandle->profile.pRUA, LumaAddr, LumaSize);
			if (status != RM_OK) {
				RMNOTIFY((NULL, status, "Locking OSD buffer at 0x%08lX (0x%08lX bytes)\n", LumaAddr, LumaSize));

				goto exit_with_error;
			}

			luma_buf = RUAMap(pHandle->profile.pRUA, LumaAddr, LumaSize);
			if (!luma_buf) {
				RMNOTIFY((NULL, RM_ERROR, "Error mapping OSD buffer at 0x%08lX (0x%08lX bytes)\n", LumaAddr, LumaSize));
				status = RM_ERROR;

				goto exit_with_error;
			}
		
#if TRUE_COLOR
			if (isTXTSub) {
				RMMemset(luma_buf,0x00, LumaSize);
			}
			else {
				RMMemset(luma_buf,0x00, LumaSize);
			}
#else
			if (isTXTSub) {
				RMMemset(luma_buf,0x00, LumaSize);

			}
			else {
				if (pHandle->pSoftTXTRenderHandle->isMix) {
					RMMemset(luma_buf,0x00, LumaSize);
				} 
				else {
					RMMemset(luma_buf,0xc0, LumaSize);
				}
			}
#endif
			pHandle->pSoftTXTRenderHandle->LumaSize    = LumaSize;
			pHandle->pSoftTXTRenderHandle->pLumaBuffer = luma_buf;
		
			pHandle->pSoftTXTRenderHandle->pSurface->pPixelBuffer = pHandle->pSoftTXTRenderHandle->pLumaBuffer;
		
			RMDBGLOG((PTD_DBG, "OSD %ld is occupied\n", pHandle->pSoftTXTRenderHandle->currentOSD.PictureID));
		}
		
		/* if its for Real time clock */
		else{

			if (pHandle->pSoftTXTRenderHandle->onScreenOSD_set) {
				if ( pHandle->pSoftTXTRenderHandle->onScreenOSD.PictureID == pHandle->pSoftTXTRenderHandle->currentOSD.PictureID ) {
					return RM_OK;
				}

				LumaAddr = pHandle->pSoftTXTRenderHandle->onScreenOSD.LumaBufferAddress;
				LumaSize = pHandle->pSoftTXTRenderHandle->onScreenOSD.LumaBufferSize;

				/* lock & map */
				status = RUALock(pHandle->profile.pRUA, LumaAddr, LumaSize);
				if (status != RM_OK) {
					RMNOTIFY((NULL, status, "Locking OSD buffer at 0x%08lX (0x%08lX bytes)\n", LumaAddr, LumaSize));

					goto exit_with_error;
				}

				luma_buf = RUAMap(pHandle->profile.pRUA, LumaAddr, LumaSize);
				if (!luma_buf) {
					RMNOTIFY((NULL, RM_ERROR, "Error mapping OSD buffer at 0x%08lX (0x%08lX bytes)\n", LumaAddr, LumaSize));
					status = RM_ERROR;

					goto exit_with_error;
				}

				pHandle->pSoftTXTRenderHandle->LumaSize_RTClk    = LumaSize;
				pHandle->pSoftTXTRenderHandle->pLumaBuffer_RTClk = luma_buf;
				pHandle->pSoftTXTRenderHandle->pSurface->pPixelBuffer = luma_buf;
			}
		}
	}
	else {
		RMDBGLOG((ENABLE, "OSD not opened yet\n"));
		return RM_ERROR;
	}

	return RM_OK;

exit_with_error:
	
	rmfp_internal_close_softtxt_render(pHandle);

	return status;
}

/************************************************************************************************/

/*
 * draw rectangle
 */
static RMstatus softtxt_draw_rect(void *pContext,
				  RMuint32 PosX,
				  RMuint32 PosY,
				  RMuint32 Width,
				  RMuint32 Height,
				  RMuint32 Color)
{
	struct RMFPHandle *pHandle = NULL;
	struct RMFontRenderHandle *pFontRenderHandle = NULL;
	struct RMFPSoftTXTRenderHandle *pSoftTXTRenderHandle = NULL;
	struct RMFontRenderBox Box = { 0, };
	RMstatus status = RM_OK;

	RMDBGLOG((DISABLE, "softtxt_draw_rect() [%lu, %lu] [%lu, %lu] Color 0x%lx\n",
		  PosX,
		  PosY,
		  Width,
		  Height,
		  Color));


	ASSERT_NULL_POINTER(pContext);

	pHandle = (struct RMFPHandle *)pContext;

	pSoftTXTRenderHandle = pHandle->pSoftTXTRenderHandle;
	pFontRenderHandle = pHandle->profile.pFontRenderHandle;
	
	ASSERT_NULL_POINTER(pSoftTXTRenderHandle);
	ASSERT_NULL_POINTER(pFontRenderHandle);

	if (pSoftTXTRenderHandle->isMix) {
		Color = 0;

	}

	if (pSoftTXTRenderHandle->pSurface)
		RMDBGLOG((LOCALDBG, "using luma buffer %p\n", pSoftTXTRenderHandle->pSurface->pPixelBuffer));


	Box.X      = PosX;
	Box.Y      = PosY;
	Box.Width  = Width;
	Box.Height = Height;

	status = RMFontRenderDrawBox(pFontRenderHandle,
				     pSoftTXTRenderHandle->pSurface,
				     &Box,
				     Color);

	return status;
}

/************************************************************************************************/

/*
 * set OSD on the screen
 */
static RMstatus softtxt_set_osd(void *pContext, RMbool isRTClk)
{
	struct RMFPHandle *pHandle = NULL;
	RMstatus status = RM_OK;

	RMDBGLOG((DISABLE, "softtxt_set_osd(%p)\n", pContext));

	ASSERT_NULL_POINTER(pContext);

	pHandle = (struct RMFPHandle *)pContext;

	RMDBGLOG((DISABLE, "OSD %ld is set ON screen\n", pHandle->pSoftTXTRenderHandle->currentOSD.PictureID));

	if ( !isRTClk ) {

		/* set the new picture */
		status = rmfp_internal_set_osd_picture_handler((void*)pHandle,
							       &(pHandle->pSoftTXTRenderHandle->OSDSource),
							       &(pHandle->pSoftTXTRenderHandle->currentOSD));
		if (status != RM_OK) {
			RMNOTIFY((NULL, status, "Cannot set picture\n"));
			goto exit_with_error;
		}

		/* save OSD's address */ 
		RMMemcpy(&pHandle->pSoftTXTRenderHandle->onScreenOSD, 
			 &pHandle->pSoftTXTRenderHandle->currentOSD, 
			 sizeof (struct RMLibPlayOSDPicture));

		pHandle->pSoftTXTRenderHandle->onScreenOSD_set = TRUE;
	}
	else {

		if ( pHandle->pSoftTXTRenderHandle->onScreenOSD.PictureID == pHandle->pSoftTXTRenderHandle->currentOSD.PictureID ) {
			return RM_OK;
		}

		if (pHandle->pSoftTXTRenderHandle->pLumaBuffer_RTClk) {
			RUAUnMap(pHandle->profile.pRUA,
				 pHandle->pSoftTXTRenderHandle->pLumaBuffer_RTClk,
				 pHandle->pSoftTXTRenderHandle->LumaSize_RTClk);
		}

		if (pHandle->pSoftTXTRenderHandle->onScreenOSD.LumaBufferAddress) {
			status = RUAUnLock(pHandle->profile.pRUA,
					   pHandle->pSoftTXTRenderHandle->onScreenOSD.LumaBufferAddress,
					   pHandle->pSoftTXTRenderHandle->onScreenOSD.LumaBufferSize);
		
			if (status != RM_OK) {
				RMNOTIFY((NULL, status, "Cannot unlock %p size %lu\n",
					    pHandle->pSoftTXTRenderHandle->onScreenOSD.LumaBufferAddress,
					    pHandle->pSoftTXTRenderHandle->onScreenOSD.LumaBufferSize));
			}
		}
		pHandle->pSoftTXTRenderHandle->pSurface->pPixelBuffer = pHandle->pSoftTXTRenderHandle->pLumaBuffer;
	}
	return status;

exit_with_error:

	rmfp_internal_close_softtxt_render(pHandle);

	return status;
}


/************************************************************************************************/

/*
 * Refresh txt
 */
RMstatus rmfp_internal_softtxt_refreshTXT(struct RMFPHandle * pHandle, 
					  RMuint32 magazineNumber, 
					  RMuint32 pageNumber,
					  RMuint64 STC)
{
	RMint32 currentOSD;

#ifdef TIMING_DBG
	RMuint64 t0, t1;
#endif

	ASSERT_NULL_POINTER(pHandle);
	if (!pHandle->pSoftTXTRenderHandle->txtON) {
		goto NEW_PAGE;
	}

	currentOSD = pHandle->pSoftTXTRenderHandle->currentOSD.PictureID;

	RMDBGLOG((DISABLE,"refresh txt\n"));

	if (currentOSD >= 0){
		if ( magazineNumber == 10 && pageNumber == 0 ) {
			RMDBGLOG((ENABLE, "close teletext\n"));
			softtxt_exit_teletext((void*)pHandle);
			RMSoftTXTExitTXT(pHandle->pSoftTXTRenderHandle->pSoftTXTHandle);
		}

		if ( magazineNumber == 20 && pageNumber == 0 ) {

			pHandle->pSoftTXTRenderHandle->isMix = !pHandle->pSoftTXTRenderHandle->isMix;
			RMSoftTXTRedrawTXTPage(pHandle->pSoftTXTRenderHandle->pSoftTXTHandle);
		}
	}

NEW_PAGE:
	if ( magazineNumber <= 8 && pageNumber <= 99 ) {
#ifdef TIMING_DBG
		t0 = RMGetTimeInMicroSeconds();
#endif
		RMSoftTXTRefreshTXT(pHandle->pSoftTXTRenderHandle->pSoftTXTHandle, 
				    magazineNumber, 
				    pageNumber, 
				    STC);
#ifdef TIMING_DBG
		t1 = RMGetTimeInMicroSeconds();
		PRINT_ELAPSED(t0, t1, "process display teletext");
#endif
		pHandle->pSoftTXTRenderHandle->txtON = TRUE;
	}
	return RM_OK;
}

/************************************************************************************************/

/*
 * Exit teletext, reset luma to transparent
 */
static RMstatus softtxt_exit_teletext(void *pContext)
{
	struct RMFPHandle *pHandle = NULL;

	ASSERT_NULL_POINTER(pContext);
	
	pHandle = (struct RMFPHandle *)pContext;
	softtxt_prepare_to_draw(pContext, TRUE, FALSE);
	softtxt_set_osd(pContext, FALSE);
	pHandle->pSoftTXTRenderHandle->txtON = FALSE;
	return RM_OK;

}

/************************************************************************************************/

/* 
 * Get the blending color index (palette mode).
 * Using pattern to organaize Teletext palette 
 * Pattern equation : (Foreground_Color*8 + blender_index_start_at) + Background_color
 * Foreground_color, background_color are between 0 to 7 (there are only 8 basic colors)
 * blender_index_start_at is where the 1st index of the palette that has blender color (in my case is 1)
 * There are only 4 different alpha that being used, 0x00, 0x40, 0x80, 0xc0.
 * Alpha is come from the foreground color that has been calculated by Freetype which take only first 2 significatif bits
 * Example : Foreground color = 0xC7 => Alpha = 0xC0
 */
static RMstatus softtxt_get_blending_color_index(void * pContext, RMuint8 FG, RMuint8 BG, RMuint8 Alpha, RMuint8 * NewIndex)
{
	RMstatus status = RM_OK;
	RMuint8 index, indexTab=0;
	/* color combination */
	RMuint8 NumberCombination = 64;
	RMuint8 FGtemp = FG &0x0F;
	RMuint8 BGtemp = (BG - 8 ) & 0x07;
	switch (Alpha&0xC0) {
	case 0x00:/* Transparent */
		*NewIndex = 0xC0 | BGtemp;
		return status;
	case 0x40:
		indexTab = 0;
		break;
	case 0x80:
		indexTab = 1;
		break;
	case 0xc0:/* Opaque */
		*NewIndex = 0xC0 | FGtemp;
		return status;
	default:
		status = RM_ERROR;
		return status;
	}

	index = (FGtemp*8 + 1) + BGtemp;
	*NewIndex = index + indexTab*NumberCombination;
	RMDBGLOG((DISABLE, "FG :%02x BG : %02x\n",FGtemp, BGtemp));

	return status;
}

/************************************************************************************************/
