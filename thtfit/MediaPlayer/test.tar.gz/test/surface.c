/*****************************************
 Copyright 2001-2007
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   surface.c
  @brief  This file provides with sample code for implementing RMFP's callbacks

	  This file is part of the test_rmfp suite

  @author Sebastian Frias Feltrer
  @date   2007-10-29
*/

/*
  **********************************************
  DISCLAIMER:

  - THIS IS TEST CODE, provided as sample code
  to help you understand what you should do to
  develop your own application based in RMFP.

  - This is NOT production grade code; It is not
  even a library, so any API defined here, CAN
  and WILL CHANGE without notice.

  **********************************************
*/

#define ALLOW_OS_CODE 1

#include "surface.h"
#include "crc32.h"

#include <dcc/include/dcc_macros.h>




#define LOCALDBG DISABLE


#define RMFP_SURFACE_PROFILE_VERSION	(1)

#define MAX_EMPTY_FIFO_RETRIES (10)


#define LOG_FILENAME "crc32.log"
static RMfile LogFileHandle = NULL;


static RMstatus connect_usermode_surface_handler(void *pContext, struct RMFPSurfaceProfile *pSurfaceProfile, struct RMFPSurfaceEventsSource *pSurfaceEventsSource);
static RMstatus disconnect_usermode_surface_handler(void *pContext, RMuint32 surface);
static void *usermode_surface_handler_thread(void *pContext);

static RMstatus dummy_picture_handler(struct rmfp_main_thread_context_type *pHandle, struct EMhwlibPictureInfo *pPictureInfo);
static RMstatus printf_picture_handler(struct rmfp_main_thread_context_type *pHandle, struct EMhwlibPictureInfo *pPictureInfo);
static RMstatus crc32_picture_handler(struct rmfp_main_thread_context_type *pHandle, struct EMhwlibPictureInfo *pPictureInfo);



/**************************************************************************************************/

RMstatus get_surface_events_handler(void *pContext, struct RMFPSurfaceProfile *pSurfaceProfile, struct RMFPSurfaceEventsSource *pSurfaceEventsSource)
{
	struct rmfp_main_thread_context_type *pHandle = NULL;
	RMstatus status = RM_OK;
	RMuint32 scaler_ID;
	RMbool enable;

	ASSERT_NULL_POINTER(pContext);
	ASSERT_NULL_POINTER(pSurfaceProfile);
	ASSERT_NULL_POINTER(pSurfaceEventsSource);

	pHandle = (struct rmfp_main_thread_context_type *)pContext;

	scaler_ID = pHandle->AppOptions.Display.scaler_ID;

	if (pSurfaceProfile->Version != RMFP_SURFACE_PROFILE_VERSION) {
		RMNOTIFY((NULL, RM_ERROR, "Got version 0x%lx, expected 0x%lx\n", pSurfaceProfile->Version, RMFP_SURFACE_PROFILE_VERSION));
		return RM_ERROR;
	}

	if (scaler_ID == (RMuint32)-1) {
		RMuint32 SoftEventIndex = pHandle->AppOptions.Display.SurfaceSoftEventIndex;

		RMDBGLOG((ENABLE, "No scaler, do not link surface! (using SoftEventIndex = %lu)\n", SoftEventIndex));

		/*
		   note that in order for RMFP to work properly you also need to set
		   those events with RUASetSoftEvent()
		 */

		pSurfaceEventsSource->event[RMFP_EVENT_INDEX_DISPLAY_EVENT].ModuleID = EMHWLIB_MODULE(0, SoftEventIndex);
		pSurfaceEventsSource->event[RMFP_EVENT_INDEX_DISPLAY_EVENT].Mask     = (1 << 0);

		pSurfaceEventsSource->event[RMFP_EVENT_INDEX_NEW_PICTURE].ModuleID   = EMHWLIB_MODULE(0, SoftEventIndex);
		pSurfaceEventsSource->event[RMFP_EVENT_INDEX_NEW_PICTURE].Mask       = (1 << 1);

		pSurfaceEventsSource->event[RMFP_EVENT_INDEX_EOS].ModuleID           = EMHWLIB_MODULE(0, SoftEventIndex);
		pSurfaceEventsSource->event[RMFP_EVENT_INDEX_EOS].Mask               = (1 << 2);

	}
	else {
		RMDBGLOG((ENABLE, "Linking surface %p to ScalerID %lu\n", pSurfaceProfile->surface, scaler_ID));

		DCCSP(pHandle->pRUA, scaler_ID, RMGenericPropertyID_Surface, &(pSurfaceProfile->surface), sizeof(pSurfaceProfile->surface));

		enable = FALSE;
		DCCSP(pHandle->pRUA, scaler_ID, RMGenericPropertyID_PersistentSurface, &enable, sizeof(enable));

		DCCSP(pHandle->pRUA, scaler_ID, RMGenericPropertyID_Validate, NULL, 0);

		pSurfaceEventsSource->event[RMFP_EVENT_INDEX_DISPLAY_EVENT].ModuleID = EMHWLIB_MODULE(DisplayBlock, 0);
		pSurfaceEventsSource->event[RMFP_EVENT_INDEX_DISPLAY_EVENT].Mask     = EMHWLIB_DISPLAY_EVENT_ID(scaler_ID);

		pSurfaceEventsSource->event[RMFP_EVENT_INDEX_NEW_PICTURE].ModuleID   = EMHWLIB_MODULE(DisplayBlock, 0);
		pSurfaceEventsSource->event[RMFP_EVENT_INDEX_NEW_PICTURE].Mask       = EMHWLIB_DISPLAY_NEW_PICTURE_EVENT_ID(scaler_ID);

		pSurfaceEventsSource->event[RMFP_EVENT_INDEX_EOS].ModuleID           = EMHWLIB_MODULE(DisplayBlock, 0);
		pSurfaceEventsSource->event[RMFP_EVENT_INDEX_EOS].Mask               = EMHWLIB_DISPLAY_INBAND_COMMAND_EVENT_ID(scaler_ID);


		pHandle->ActiveScalers |= VIDEO_SCALER_ACTIVE;
		pHandle->ScalersOperationsMask |= VIDEO_SCALER_ACTIVE;
	}

	/*
	  EXPERIMENTAL
	*/
	if (pHandle->AppOptions.Display.UserSurfaceMode != TESTRMFP_UserSurfaceMode_None)
		return connect_usermode_surface_handler(pContext, pSurfaceProfile, pSurfaceEventsSource);

	return status;
}


/**************************************************************************************************/

RMstatus disconnect_surface_handler(void *pContext, RMuint32 surface)
{
	struct rmfp_main_thread_context_type *pHandle = NULL;
	RMstatus status = RM_OK;
	RMuint32 scaler_ID;
	RMuint32 null_surface = 0;

	ASSERT_NULL_POINTER(pContext);

	pHandle = (struct rmfp_main_thread_context_type *)pContext;

	scaler_ID = pHandle->AppOptions.Display.scaler_ID;

	if (scaler_ID == (RMuint32)-1) {
		RMDBGLOG((ENABLE, "Nothing to disconnect from\n"));
	}
	else {
		RMDBGLOG((LOCALDBG, "Disconnecting surface from scaler %lu\n", scaler_ID));

		/* Disconnect scaler */
		DCCSP(pHandle->pRUA, scaler_ID, RMGenericPropertyID_Surface, &null_surface, sizeof(null_surface));
	}


	if (pHandle->AppOptions.Display.UserSurfaceMode != TESTRMFP_UserSurfaceMode_None)
		return disconnect_usermode_surface_handler(pContext, surface);


	return status;
}



/*
********************
  EXPERIMENTAL CODE!
  ********************
*/


/**************************************************************************************************/

static RMstatus connect_usermode_surface_handler(void *pContext, struct RMFPSurfaceProfile *pSurfaceProfile, struct RMFPSurfaceEventsSource *pSurfaceEventsSource)
{
	RMstatus Status;
	struct rmfp_main_thread_context_type *pHandle = NULL;


	ASSERT_NULL_POINTER(pContext);

	pHandle = (struct rmfp_main_thread_context_type *)pContext;

	if (pHandle->AppOptions.Display.UserSurfaceMode == TESTRMFP_UserSurfaceMode_CRC32) {

		Status = init_crc32(pHandle);
		if (Status != RM_OK) {
			RMNOTIFY((NULL, Status, "Cannot initialise CRC32\n"));
			return Status;
		}

		LogFileHandle = RMOpenFile((RMnonAscii*)LOG_FILENAME, RM_FILE_OPEN_WRITE);
		if (!LogFileHandle) {
			RMNOTIFY((NULL, RM_ERROR, "Cannot open log file\n"));
			return RM_ERROR;
		}

	}


	fprintf(NORMALMSG, "Launching surface handler thread\n");
	fprintf(NORMALMSG, "Using surface 0x%08lx, softEventIndex %lu\n", (RMuint32)pSurfaceProfile->surface, (RMuint32)pHandle->AppOptions.Display.SurfaceSoftEventIndex);

	pHandle->ExitSurfaceHandler = FALSE;
	pHandle->UsermodeSurface = (RMuint32)pSurfaceProfile->surface;
	pHandle->UsermodeSurfaceHandlerThreadID = RMCreateThread("SurfaceHandler", usermode_surface_handler_thread, (void*)pContext);


	return RM_OK;
}

/**************************************************************************************************/

static RMstatus disconnect_usermode_surface_handler(void *pContext, RMuint32 surface)
{
	RMstatus Status;
	struct rmfp_main_thread_context_type *pHandle = NULL;

	ASSERT_NULL_POINTER(pContext);

	pHandle = (struct rmfp_main_thread_context_type *)pContext;


	// wait for thread to finish
	fprintf(NORMALMSG, "\n\nWaiting for surface handler thread to finish\n\n");;

	pHandle->ExitSurfaceHandler = TRUE;
	RMWaitForThreadToFinish(pHandle->UsermodeSurfaceHandlerThreadID);


	if (pHandle->AppOptions.Display.UserSurfaceMode == TESTRMFP_UserSurfaceMode_CRC32) {
		Status = deinit_crc32(pHandle);
		if (Status != RM_OK) {
			RMNOTIFY((NULL, Status, "Cannot deinitialise CRC32\n"));
			return Status;
		}

		if (LogFileHandle)
			RMCloseFile(LogFileHandle);

	}


	return RM_OK;
}

/**************************************************************************************************/

void *usermode_surface_handler_thread(void *pContext)
{
	struct rmfp_main_thread_context_type *pHandle = NULL;
	RMstatus status;
	RMuint32 EmptyFIFOCounter;


	if (!pContext)
		return NULL;

	pHandle = (struct rmfp_main_thread_context_type *)pContext;

	EmptyFIFOCounter = 0;

	fprintf(NORMALMSG, "usermode_surface_handler: start\n");

	while (!pHandle->ExitSurfaceHandler) {
		struct EMhwlibSurfaceReader SurfaceReader = {0, };
		struct EMhwlibPictureInfo PictureInfo = {0, };
		//struct InbandCommandX_type InbandCommand = { 0, };
		RMuint32 EventMask;


#if 1
		if (pHandle->AppOptions.Display.scaler_ID != (RMuint32)-1) {
			/*
			  Normally, the surface shouldn't be connected to a scaler, otherwise this thread and
			  the scaler would compete for the pictures.
			*/
			RMNOTIFY((NULL, RM_ERROR, "UserSurfaceHandler: scaler %lu is also connected to the surface!\n", pHandle->AppOptions.Display.scaler_ID));
			RMMicroSecondSleep(1000000);
			continue;
		}
#endif

		if (!pHandle->playback_started) {
			fprintf(NORMALMSG, "Waiting for playback to start\n");
			RMMicroSecondSleep(200000);
			continue;
		}

		/*

		  KNOWN PROBLEMS:

		  - currently we don't have a way to retrieve outband commands (stop/flush/next) from the surface
		  - currently "NextInbandCommand" will also remove the command from the FIFO, however, what we need
		  here is to see if there's one (EOS for example) so that we can send an event to RMFP which will
		  remove it

		  (we could get rid of this by using two surfaces and forward data between them)

		  - right now we're polling for new pictures/commands, we should wait for events on the producer of the
		  pictures/commands

		*/


		// HACK
		EventMask = (1 << 0); // display event

		SurfaceReader.SurfaceAddress = (RMuint32)pHandle->UsermodeSurface;

#if 0
		status = RUAExchangeProperty(pHandle->pRUA,
					     EMHWLIB_MODULE(DisplayBlock, 0),
					     RMDisplayBlockPropertyID_NextInbandCommand,
					     &(SurfaceReader.SurfaceAddress),
					     sizeof(SurfaceReader.SurfaceAddress),
					     &InbandCommand,
					     sizeof(InbandCommand));

		if (status == RM_OK) {
			fprintf(NORMALMSG, "InbandCommand 0x%02lx\n", INBAND_COMMAND_GET_TAG(InbandCommand.flags_tag));

			EventMask |= (1 << 2);
		}

		status = RUAExchangeProperty(pHandle->pRUA,
					     EMHWLIB_MODULE(DisplayBlock, 0),
					     RMDisplayBlockPropertyID_NextUserInbandCommand,
					     &(SurfaceReader.SurfaceAddress),
					     sizeof(SurfaceReader.SurfaceAddress),
					     &InbandCommand,
					     sizeof(InbandCommand));

		if (status == RM_OK) {
			fprintf(NORMALMSG, "UserInbandCommand 0x%02lx\n", INBAND_COMMAND_GET_TAG(InbandCommand.flags_tag));
		}
#endif

		status = RUAExchangeProperty(pHandle->pRUA,
					     EMHWLIB_MODULE(DisplayBlock, 0),
					     RMDisplayBlockPropertyID_PeekNextPicture,
					     &(SurfaceReader),
					     sizeof(SurfaceReader),
					     &PictureInfo,
					     sizeof(struct EMhwlibPictureInfo));

		if ((status == RM_OK) && (PictureInfo.PictureAddress)) {

			SurfaceReader.emhwlibReserved = PictureInfo.PictureAddress;

			// acquire (equiv. to "get")
			status = RUASetProperty(pHandle->pRUA,
						EMHWLIB_MODULE(DisplayBlock, 0),
						RMDisplayBlockPropertyID_AcquirePicture,
						&(SurfaceReader),
						sizeof(SurfaceReader),
						0);

			if (status != RM_OK)
				fprintf(ERRORMSG, "cannot acquire picture!\n");



			// call selected handler

			switch (pHandle->AppOptions.Display.UserSurfaceMode) {
			case TESTRMFP_UserSurfaceMode_None:
				// not possible!

				RMNOTIFY((NULL, RM_ERROR, "UserSurfaceHandler: invalid mode\n"));

				break;
			case TESTRMFP_UserSurfaceMode_Dummy:
				status = dummy_picture_handler(pHandle, &PictureInfo);
				break;
			case TESTRMFP_UserSurfaceMode_Print:
				status = printf_picture_handler(pHandle, &PictureInfo);
				break;
			case TESTRMFP_UserSurfaceMode_CRC32:
				status = crc32_picture_handler(pHandle, &PictureInfo);
				break;
			};



			//release
			status = RUASetProperty(pHandle->pRUA,
						EMHWLIB_MODULE(DisplayBlock, 0),
						RMDisplayBlockPropertyID_ReleasePicture,
						&(SurfaceReader),
						sizeof(SurfaceReader),
						0);

			if (status != RM_OK)
				fprintf(ERRORMSG, "cannot release picture\n");


			EventMask |= (1 << 1); //new picture event
			EmptyFIFOCounter = 0;
		}
		else {
			RMMicroSecondSleep(200000);

			EmptyFIFOCounter++;

			// HACK: consider EOS after a number of times
			if (EmptyFIFOCounter > MAX_EMPTY_FIFO_RETRIES) {
				if (!pHandle->EOS) {
					RMDBGLOG((ENABLE, "FIFO has been empty %lu times, considering EOS\n", EmptyFIFOCounter));
					EventMask |= (1 << 2); // eos event
				}
				else
					RMDBGLOG((ENABLE, "RMFP signalled EOS\n"));
			}

		}

		if (EventMask) {
			struct RUAEvent Event = { 0, };
			RMuint32 SoftEventIndex = pHandle->AppOptions.Display.SurfaceSoftEventIndex;

			Event.ModuleID = EMHWLIB_MODULE(0, SoftEventIndex);
			Event.Mask = EventMask;

			//fprintf(NORMALMSG, "SetSoftEvent: ModuleID=0x%lx, Mask 0x%08lx\n", Event.ModuleID, Event.Mask);

			RUASetSoftEvent(pHandle->pRUA, &Event);
		}
	}

	fprintf(NORMALMSG, "usermode_surface_handler: end\n");

	return NULL;
}



static RMstatus dummy_picture_handler(struct rmfp_main_thread_context_type *pHandle, struct EMhwlibPictureInfo *pPictureInfo)
{
	RMuint64 VideoPTS = 0;

	if (!pHandle || !pPictureInfo)
		return RM_FATALINVALIDPOINTER;

	VideoPTS = pPictureInfo->Picture.first_pts_lo + ((RMuint64)pPictureInfo->Picture.first_pts_hi<<32);

	fprintf(NORMALMSG, "VideoPTS = 0x%lld\n", VideoPTS);

	return RM_OK;
}

enum FrameInfo_type {
	FrameInfo_Progressive = 0,
	FrameInfo_TopFieldOnly,
	FrameInfo_BottonFieldOnly,
	FrameInfo_Interlaced,
};

enum PixelFormat_type {
	PixelFormat_Y_UV = 0,
	PixelFormat_Y,
	PixelFormat_YUYV,
	PixelFormat_RGBA,
};

enum BitsPerPixel_type {
	BitsPerPixel_1 = 0,
	BitsPerPixel_2,
	BitsPerPixel_4,
	BitsPerPixel_8,
	BitsPerPixel_16,
	BitsPerPixel_24,
	BitsPerPixel_32,
	BitsPerPixel_Reserved,
};

union DisplayData_type {
	struct {
		enum FrameInfo_type FrameInfo : 2;
		RMuint32 TFF : 1;
		RMuint32 RFF : 1;
		RMuint32 NRF : 2;
		enum PixelFormat_type PixelFormat : 2;
		enum BitsPerPixel_type BitsPerPixel : 3;
		RMuint32 BitMapping : 3;
		RMuint32 ProgressiveSeq : 1;
		RMuint32 BufferType : 1;
		RMuint32 ChromaLumaTopFldVtPhOff : 4;
		RMuint32 ChromaLumaTopFldHzPhOff : 4;
		RMuint32 ChromaLumaBotFldVtPhOff : 4;
		RMuint32 ChromaLumaBotFldHzPhOff : 4;
	} Field;
	RMuint32 data;
};


union ColorDescription_type {
	struct {
		RMuint32 Matrix : 8;
		RMuint32 Transfer : 8;
		RMuint32 Primaries : 8;
		RMuint32 Range : 1;
		RMuint32 Reserved : 7;
	} Field;
	RMuint32 data;
};


static RMstatus printf_picture_handler(struct rmfp_main_thread_context_type *pHandle, struct EMhwlibPictureInfo *pPictureInfo)
{
	RMuint32 LumaAddr;
	RMuint32 LumaWidth;
	RMuint32 ChromaAddr;
	RMuint32 ChromaWidth;
	RMuint32 LumaScale;
	RMuint32 ChromaScale;
	RMuint32 PaletteAddr;
	RMuint32 PaletteSize;
	RMuint32 PaletteBufferSize;
	union DisplayData_type DisplayData;
	RMuint32 ScaledWidth;
	RMuint32 ScaledHeight;
	RMuint32 ARx;
	RMuint32 ARy;
	union ColorDescription_type ColorDescription;
	RMuint32 PTSHi;
	RMuint32 PTSLo;
	RMuint32 DeltaPTS;
	RMuint32 SystemPTS;
	RMuint32 TIR;
	RMuint32 FrameCount;
	RMuint32 DisplayStatus;
	RMuint32 Error;
	RMuint32 ActiveFormat;
	RMuint32 HorizBar;
	RMuint32 VertBar;
	RMuint64 PTS64bit;


	if (!pHandle || !pPictureInfo)
		return RM_FATALINVALIDPOINTER;



#define GET_FIELD(x) pPictureInfo->Picture.x

	LumaAddr = GET_FIELD(luma_address);
	LumaWidth = GET_FIELD(luma_total_width);
	ChromaAddr = GET_FIELD(chroma_address);
	ChromaWidth = GET_FIELD(chroma_total_width);
	LumaScale = GET_FIELD(luma_scale);
	ChromaScale = GET_FIELD(chroma_scale);
	PaletteAddr = GET_FIELD(palette_address);
	PaletteSize = GET_FIELD(palette_size);
	PaletteBufferSize = GET_FIELD(palette_buffer_size);
	DisplayData.data = GET_FIELD(picture_display_data);
	ScaledWidth = GET_FIELD(scaled_width);
	ScaledHeight = GET_FIELD(scaled_height);
	ARx = GET_FIELD(ar_x);
	ARy = GET_FIELD(ar_y);
	ColorDescription.data = GET_FIELD(color_description);
	PTSHi = GET_FIELD(first_pts_hi);
	PTSLo = GET_FIELD(first_pts_lo);
	DeltaPTS = GET_FIELD(delta_pts);
	SystemPTS = GET_FIELD(system_pts);
	TIR = GET_FIELD(time_increment_resolution);
	FrameCount = GET_FIELD(frame_count);
	DisplayStatus = GET_FIELD(picture_display_status);
	Error = GET_FIELD(error_status);
	ActiveFormat = GET_FIELD(active_format);
	HorizBar = GET_FIELD(horizontal_bar);
	VertBar = GET_FIELD(vertical_bar);

	PTS64bit = PTSLo + ((RMuint64)PTSHi << 32);

	fprintf(NORMALMSG, "\nSurface @ 0x%08lx\n", (RMuint32)pHandle->UsermodeSurface);
	fprintf(NORMALMSG, "Picture[%lu]: Luma @ 0x%08lx, width %lu, Chroma @ 0x%08lx, width %lu\n", FrameCount, LumaAddr, LumaWidth, ChromaAddr, ChromaWidth);
	fprintf(NORMALMSG, "\tLumaScale %lu, ChromaScale %lu, Palette @ 0x%08lx, PaletteSize %lu PaletteBufferSize %lu\n", LumaScale, ChromaScale, PaletteAddr, PaletteSize, PaletteBufferSize);
	fprintf(NORMALMSG, "\tDisplayData 0x%08lx\n", DisplayData.data);
	fprintf(NORMALMSG, "\t\tFI %lu, TFF %lu, RFF %lu, NRF %lu, PF %lu, BPP %lu, BM %lu, PS %lu, BT %lu\n",
		(RMint32)DisplayData.Field.FrameInfo,
		(RMint32)DisplayData.Field.TFF,
		(RMint32)DisplayData.Field.RFF,
		(RMint32)DisplayData.Field.NRF,
		(RMint32)DisplayData.Field.PixelFormat,
		(RMint32)DisplayData.Field.BitsPerPixel,
		(RMint32)DisplayData.Field.BitMapping,
		(RMint32)DisplayData.Field.ProgressiveSeq,
		(RMint32)DisplayData.Field.BufferType);
	fprintf(NORMALMSG, "\t\tChromaLumaTopFldVtPhOff %lu, -TopFldHzPhOff %lu, -BotFldVtPhOff %lu, -BotFldHzPhOff %lu\n",
		(RMint32)DisplayData.Field.ChromaLumaTopFldVtPhOff,
		(RMint32)DisplayData.Field.ChromaLumaTopFldHzPhOff,
		(RMint32)DisplayData.Field.ChromaLumaBotFldVtPhOff,
		(RMint32)DisplayData.Field.ChromaLumaBotFldHzPhOff);
	fprintf(NORMALMSG, "\tScaled size %lu x %lu, AspectRatio %lu x %lu\n", ScaledWidth, ScaledHeight, ARx, ARy);
	fprintf(NORMALMSG, "\tColorDescription 0x%08lx\n", ColorDescription.data);
	fprintf(NORMALMSG, "\t\tM %lu, T %lu, P %lu, R %lu\n",
		(RMint32)ColorDescription.Field.Matrix,
		(RMint32)ColorDescription.Field.Transfer,
		(RMint32)ColorDescription.Field.Primaries,
		(RMint32)ColorDescription.Field.Range);
	fprintf(NORMALMSG, "\tPTS 0x%08lx %08lx (%llu) delta 0x%08lx (%lu) system 0x%08lx\n", PTSHi, PTSLo, PTS64bit, DeltaPTS, DeltaPTS, SystemPTS);
	fprintf(NORMALMSG, "\tTIR 0x%08lx (%lu), FrameCount %lu\n", TIR, TIR, FrameCount);
	fprintf(NORMALMSG, "\tDisplayStatus %lu, Error 0x%08lx\n", DisplayStatus, Error);
	fprintf(NORMALMSG, "\tActiveFormat 0x%08lx, HorizBar 0x%08lx, VertBar 0x%08lx\n", ActiveFormat, HorizBar, VertBar);

	return RM_OK;
}




static RMstatus crc32_picture_handler(struct rmfp_main_thread_context_type *pHandle, struct EMhwlibPictureInfo *pPictureInfo)
{
	RMstatus Status;

	RMuint32 LumaAddr, LumaWidth;
	RMuint32 ChromaAddr, ChromaWidth;
	RMuint32 LumaScale, ChromaScale;
	RMuint32 PaletteAddr, PaletteSize, PaletteBufferSize;
	union DisplayData_type DisplayData;
	RMuint32 ScaledWidth, ScaledHeight;
	RMuint32 ARx, ARy;
	union ColorDescription_type ColorDescription;
	RMuint32 PTSHi, PTSLo, DeltaPTS, SystemPTS;
	RMuint32 TIR;
	RMuint32 FrameCount;
	RMuint32 DisplayStatus;
	RMuint32 Error;
	RMuint32 ActiveFormat, HorizBar, VertBar;

	RMuint64 PTS64bit;

	RMuint32 CheckSum;
	RMuint32 LumaX, LumaY, LumaW, LumaH;
	RMuint32 ChromaX, ChromaY, ChromaW, ChromaH;


	if (!pHandle || !pPictureInfo)
		return RM_FATALINVALIDPOINTER;



#define GET_FIELD(x) pPictureInfo->Picture.x

	LumaAddr = GET_FIELD(luma_address);
	LumaWidth = GET_FIELD(luma_total_width);
	ChromaAddr = GET_FIELD(chroma_address);
	ChromaWidth = GET_FIELD(chroma_total_width);
	LumaScale = GET_FIELD(luma_scale);
	ChromaScale = GET_FIELD(chroma_scale);
	PaletteAddr = GET_FIELD(palette_address);
	PaletteSize = GET_FIELD(palette_size);
	PaletteBufferSize = GET_FIELD(palette_buffer_size);
	DisplayData.data = GET_FIELD(picture_display_data);
	ScaledWidth = GET_FIELD(scaled_width);
	ScaledHeight = GET_FIELD(scaled_height);
	ARx = GET_FIELD(ar_x);
	ARy = GET_FIELD(ar_y);
	ColorDescription.data = GET_FIELD(color_description);
	PTSHi = GET_FIELD(first_pts_hi);
	PTSLo = GET_FIELD(first_pts_lo);
	DeltaPTS = GET_FIELD(delta_pts);
	SystemPTS = GET_FIELD(system_pts);
	TIR = GET_FIELD(time_increment_resolution);
	FrameCount = GET_FIELD(frame_count);
	DisplayStatus = GET_FIELD(picture_display_status);
	Error = GET_FIELD(error_status);
	ActiveFormat = GET_FIELD(active_format);
	HorizBar = GET_FIELD(horizontal_bar);
	VertBar = GET_FIELD(vertical_bar);

	PTS64bit = PTSLo + ((RMuint64)PTSHi << 32);
	FrameCount -= 1;
	CheckSum = (RMuint32)-1;


	fprintf(NORMALMSG, "\nSurface @ 0x%08lx\n", (RMuint32)pHandle->UsermodeSurface);
	fprintf(NORMALMSG, "Picture[%lu]: Luma @ 0x%08lx, width %lu, Chroma @ 0x%08lx, width %lu\n", FrameCount, LumaAddr, LumaWidth, ChromaAddr, ChromaWidth);
	fprintf(NORMALMSG, "\tLumaScale %lu, ChromaScale %lu, Palette @ 0x%08lx, PaletteSize %lu PaletteBufferSize %lu\n", LumaScale, ChromaScale, PaletteAddr, PaletteSize, PaletteBufferSize);

#if 0
	fprintf(NORMALMSG, "\tDisplayData 0x%08lx\n", DisplayData.data);
	fprintf(NORMALMSG, "\t\tFI %lu, TFF %lu, RFF %lu, NRF %lu, PF %lu, BPP %lu, BM %lu, PS %lu, BT %lu\n",
		(RMuint32)DisplayData.Field.FrameInfo,
		(RMuint32)DisplayData.Field.TFF,
		(RMuint32)DisplayData.Field.RFF,
		(RMuint32)DisplayData.Field.NRF,
		(RMuint32)DisplayData.Field.PixelFormat,
		(RMuint32)DisplayData.Field.BitsPerPixel,
		(RMuint32)DisplayData.Field.BitMapping,
		(RMuint32)DisplayData.Field.ProgressiveSeq,
		(RMuint32)DisplayData.Field.BufferType);
	fprintf(NORMALMSG, "\t\tChromaLumaTopFldVtPhOff %lu, -TopFldHzPhOff %lu, -BotFldVtPhOff %lu, -BotFldHzPhOff %lu\n",
		(RMuint32)DisplayData.Field.ChromaLumaTopFldVtPhOff,
		(RMuint32)DisplayData.Field.ChromaLumaTopFldHzPhOff,
		(RMuint32)DisplayData.Field.ChromaLumaBotFldVtPhOff,
		(RMuint32)DisplayData.Field.ChromaLumaBotFldHzPhOff);
	fprintf(NORMALMSG, "\tScaled size %lu x %lu, AspectRatio %lu x %lu\n", ScaledWidth, ScaledHeight, ARx, ARy);
	fprintf(NORMALMSG, "\tColorDescription 0x%08lx\n", ColorDescription.data);
	fprintf(NORMALMSG, "\t\tM %lu, T %lu, P %lu, R %lu\n",
		(RMuint32)ColorDescription.Field.Matrix,
		(RMuint32)ColorDescription.Field.Transfer,
		(RMuint32)ColorDescription.Field.Primaries,
		(RMuint32)ColorDescription.Field.Range);
	fprintf(NORMALMSG, "\tPTS 0x%08lx %08lx (%llu) delta 0x%08lx (%lu) system 0x%08lx\n", PTSHi, PTSLo, PTS64bit, DeltaPTS, DeltaPTS, SystemPTS);
	fprintf(NORMALMSG, "\tTIR 0x%08lx (%lu), FrameCount %lu\n", TIR, TIR, FrameCount);
	fprintf(NORMALMSG, "\tDisplayStatus %lu, Error 0x%08lx\n", DisplayStatus, Error);
	fprintf(NORMALMSG, "\tActiveFormat 0x%08lx, HorizBar 0x%08lx, VertBar 0x%08lx\n", ActiveFormat, HorizBar, VertBar);
#endif



	LumaX   = GET_FIELD(luma_position_in_buffer.x);
	LumaY   = GET_FIELD(luma_position_in_buffer.y);
	LumaW   = GET_FIELD(luma_position_in_buffer.width);
	LumaH   = GET_FIELD(luma_position_in_buffer.height);

	ChromaX = GET_FIELD(chroma_position_in_buffer.x);
	ChromaY = GET_FIELD(chroma_position_in_buffer.y);
	ChromaW = GET_FIELD(chroma_position_in_buffer.width);
	ChromaH = GET_FIELD(chroma_position_in_buffer.height);


	fprintf(NORMALMSG, "\n\tLumaX %lu LumaY %lu LumaW %lu LumaH %lu\n", LumaX, LumaY, LumaW, LumaH);
	fprintf(NORMALMSG, "\tChromaX %lu ChromaY %lu ChromaW %lu ChromaH %lu\n", ChromaX, ChromaY, ChromaW, ChromaH);


	Status = compute_crc32(pHandle,
			       LumaAddr, (LumaWidth >> RMTILE_WIDTH_SHIFT),
			       LumaX, LumaW,
			       LumaY, LumaH,
			       TRUE,
			       &CheckSum);
	if (Status != RM_OK) {
		RMNOTIFY((NULL, Status, "Cannot compute Luma CRC32\n"));
		return Status;
	}

	if (LogFileHandle)
		RMPrintFile(LogFileHandle, "#%10lu luma %10lx", FrameCount, CheckSum);

	Status = compute_crc32(pHandle,
			       ChromaAddr, (ChromaWidth >> RMTILE_WIDTH_SHIFT),
			       ChromaX, (ChromaW * 2), // there are two bytes per sample
			       ChromaY, ChromaH,
			       TRUE,
			       &CheckSum);

	if (Status != RM_OK) {
		RMNOTIFY((NULL, Status, "Cannot compute Chroma CRC32\n"));
		return Status;
	}

	if (LogFileHandle)
		RMPrintFile(LogFileHandle, " chroma %10lx\n", CheckSum);



	return RM_OK;
}


