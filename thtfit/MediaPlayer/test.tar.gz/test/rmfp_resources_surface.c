/*****************************************
 Copyright 2010
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   rmfp_resources_surface.c
  @brief


  @author Faizal Fikhri ZAKARIA
  @date   2010-01-28
*/

#include "rmfp_internal.h"

#define LOCALDBG DISABLE

RMstatus rmfp_internal_connect_surface(void *pContext, RMuint32 output_surface, struct RMFPSurfaceEventsSource *pSurfaceEventsSource)
{
	struct RMFPHandle *pHandle = NULL;
	RMstatus status = RM_OK;
	pHandle = (struct RMFPHandle *)pContext;

	RMDBGLOG((LOCALDBG, "pHandle->profile.rmfp_get_surface_events_callback : %p output_surface : %p \n",*
			  pHandle->profile.rmfp_get_surface_events_callback,
			  output_surface));

	if (pHandle->profile.rmfp_get_surface_events_callback && (output_surface != 0)) {

		struct RMFPSurfaceProfile SurfaceProfile;

		SurfaceProfile.Version = GET_VERSION_FROM_MAGIC(RMFP_SURFACE_PROFILE_VERSION);


		SurfaceProfile.surface = (struct EMhwlibSurface *)output_surface;
	
		status = pHandle->profile.rmfp_get_surface_events_callback(pHandle->profile.callback_context , &SurfaceProfile, pSurfaceEventsSource);
		if (status != RM_OK) {
			RMNOTIFY((NULL, status, "Cannot get surface from application\n"));
			return status;
		}
	}
	else {
		return RM_ERROR;
	}

	return status;
}


RMstatus rmfp_internal_disconnect_surface(void *pContext, RMuint32 surface)
{
	struct RMFPHandle *pHandle = NULL;
	RMstatus status = RM_OK;
	pHandle = (struct RMFPHandle *)pContext;

	/* Disconnect surface */
	if (pHandle->profile.rmfp_disconnect_surface_callback) {
		status = pHandle->profile.rmfp_disconnect_surface_callback(pHandle->profile.callback_context , (RMuint32) surface);
		if (status != RM_OK) {
			RMNOTIFY((NULL, status, "rmfp_get_surface_events_callback\n"));
			return status;
		}
	}
	
	return status;
}
