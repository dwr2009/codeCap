#ifndef __TESTRMFP_H__
#define __TESTRMFP_H__

#include <rmdef/rmdef.h>
#include "parse_command_line.h"
#include "ciphers.h"
#include <CCplusplusBridge.h>
#include <BaseTypeDef.h>

#ifdef WITH_THREADS
#include <rmlibcw/include/rmsemaphores.h>


#define DEBUG_BLOCKING_SEMAPHORES        (0)
#define DEBUG_BLOCKING_CRITICAL_SECTIONS (0)

#if DEBUG_BLOCKING_CRITICAL_SECTIONS
#define ENTER_CS(x) do {						\
		if (x) {						\
			RMDBGLOG((ENABLE, "Entering CS %p('%s') from %s\n", (void*)x, STR(x), __FUNCTION__)); \
			RMEnterCriticalSection(x);			\
			RMDBGLOG((ENABLE, "Got CS %p('%s')\n", (void*)x, STR(x)));	\
		}							\
		else							\
			RMDBGLOG((ENABLE, "Critical Section '%s' NULL in %s!\n", STR(x),__FUNCTION__)); \
	} while (0)

#define LEAVE_CS(x) do {						\
		if (x) {						\
			RMDBGLOG((ENABLE, "Leaving CS %p('%s') from %s\n", (void*)x, STR(x), __FUNCTION__)); \
			RMLeaveCriticalSection(x);			\
			RMDBGLOG((ENABLE, "Left CS %p('%s')\n", (void*)x, STR(x)));	\
		}							\
		else							\
			RMDBGLOG((ENABLE, "Critical Section '%s' NULL in %s!\n", STR(x),__FUNCTION__)); \
	} while (0)

#else //DEBUG_BLOCKING_CRITICAL_SECTIONS
#define ENTER_CS(x) do {						\
		if (x)							\
			RMEnterCriticalSection(x);			\
		else							\
			RMDBGLOG((ENABLE, "Critical Section NULL!\n"));	\
	} while (0)

#define LEAVE_CS(x) do {						\
		if (x)							\
			RMLeaveCriticalSection(x);			\
		else							\
			RMDBGLOG((ENABLE, "Critical Section NULL!\n"));	\
	} while (0)
#endif //DEBUG_BLOCKING_CRITICAL_SECTIONS



#if DEBUG_BLOCKING_SEMAPHORES
#define SEMAPHORE_P(x) do {						\
		if (x) {						\
			RMDBGLOG((ENABLE, "SEM_P(%p)\n", x));		\
			RMReleaseSemaphore(x, 1);			\
		}							\
		else							\
			RMDBGLOG((ENABLE, "Semaphore NULL!\n"));	\
	} while (0)


#define SEMAPHORE_V(x) do {						\
		if (x) {						\
			while (RMTryWaitForSemaphore(x) == RM_SEMAPHORELOCKED) { \
				RMDBGLOG((ENABLE, "wait on %p\n", x));	\
				RMMicroSecondSleep(10 * 1000);		\
			}						\
		}							\
		else							\
			RMDBGLOG((ENABLE, "Semaphore NULL!\n"));	\
	} while (0)

#else
#define SEMAPHORE_P(x) do {						\
		if (x)							\
			RMReleaseSemaphore(x, 1);			\
		else							\
			RMDBGLOG((ENABLE, "Semaphore NULL!\n"));	\
	} while (0)

#define SEMAPHORE_V(x) do {						\
		if (x)							\
			RMWaitForSemaphore(x);				\
		else							\
			RMDBGLOG((ENABLE, "Semaphore NULL!\n"));	\
	} while (0)
#endif //DEBUG_BLOCKING_SEMAPHORES


#else
#define ENTER_CS(x) do { } while(0)
#define LEAVE_CS(x) do { } while(0)
#define SEMAPHORE_P(x) do { } while(0)
#define SEMAPHORE_V(x) do { } while(0)
#endif


// set it to zero if you want to let RMFP to completely handle the resources
// set it to one if you want to use the resource handling callbacks from resources.c
#define USE_RESOURCE_CALLBACKS (1)

// this is mostly for testing purposes: set it to zero to disable almost all callbacks

#define USE_NOTIFICATION_CALLBACKS (1)
#define MAX_DIR_RECURSION (8)
#define VIDEO_SCALER_ACTIVE (1<<0)
#define OSD_SCALER_ACTIVE   (1<<1)

#define NORMALMSG stdout
#define ERRORMSG  stderr


#define ASSERTDBG DISABLE

#define ASSERT_NULL_POINTER(ptr)					\
	do {								\
		RMDBGLOG((ASSERTDBG, "%s = %p\n", #ptr, ptr));		\
		if (!ptr) {						\
			fprintf(ERRORMSG, "got NULL pointer for %s\n", #ptr); \
			return RM_FATALINVALIDPOINTER;			\
		}							\
	} while(0);



struct rmfp_main_thread_context_type {
	struct RUA *pRUA;
	struct DCC *pDCC;

	struct RMFPHandle *pHandle;

	RMfile fileHandle;

	struct RMFPOptions *pOptions;
	struct AppOptions AppOptions;
	struct CommandLineOptionSet* pAlreadySetOptions;

	RMbool video_scaler_options_applied;
	RMstatus status;
	RMuint32 availableCommandsMask;
	struct RMFPStreamType stream_type;
	RMbool playback_started;
	RMbool EOS;

	// Display setup options
	struct dh_context *dh_info;  // HDMI context
	struct rmoutput_hwlib_callbacks *pHWLib;  // EMhwlib/RUA context for rmoutput
	struct rmoutput_display_options *display_opt;  // display options
	struct rmoutput_display_config *display_conf;  // display configuration
	struct rmoutput_debug_context *pDebug;  // debug menu key handling
	
	// Current status
	struct RMFPPlaybackStatus current_status;

	// for picture rendering
	struct DCCVideoSource *pPictureOSDSource;
	RMuint32 PictureScaler;
	RMuint32 Picture;

	// for PlaybackTimer
	RMuint32 LastPlaybackTime;

	// for HDD control
	RMuint64 DiskControlLastTimerValue;
	RMuint64 HDsleepTime;
	RMuint64 HDrunTime;

	//Active scalers mask

	RMuint32 ActiveScalers;
	RMuint32 ScalersOperationsMask;
	RMbool osd_opened;

	// Exit get key thread
	RMcriticalsection GetKeyCS;
	RMbool exit_key_management_thread;

	// Recursive mode
	RMdirectory directory[MAX_DIR_RECURSION];
	RMascii path[256];
	RMuint32 path_index[MAX_DIR_RECURSION];
	RMuint32 dir_index;
	RMbool quit;

	// Metadata
	struct RMFPStreamMetadata metadata;
	struct RMFPStreamMetadata defaults_metadata;

	// Streams properties
	struct RMFPStreamProperties stream_properties;

	// PAT and PMT
	struct DCCPATInfoType current_pat;
        struct DCCPMTInfoType current_pmt;

	RMint32 LastProgress;
	RMuint64 LastUnknownProgressTime;
	RMuint64 StartOfProgressTime;

	// Font rendering
	struct RMFontRenderHandle *pFontRenderHandle;
	RMint32 default_font_slotID;	// -1 if none
	RMint32 forced_font_slotID;	// -1 if none
	RMint32 cc_font_slotID;		// -1 if none
	RMuint32 nb_additional_fonts;
	RMint32 additional_font_slotID[TEST_RMFP_MAX_ADDITIONAL_FONTS];

	// Store OSD information
	RMbool OSDAvailable;
	struct RMFPOSDProfile OSDProfile;
	struct EMhwlibDisplayWindow applied_output_osd_window;
	RMbool iframing;
	
	// Ciphers context
	struct rmfp_cipher_context cipher_context;

	// For DTCP
	struct RMDTCPAPIHandle *pDTCPHandle;

	RMascii *local_argv_ptr[32];
	RMascii local_argv_line[256];

	// usermode surface handler
	RMuint32 UsermodeSurface;
	RMthread UsermodeSurfaceHandlerThreadID;
	RMbool ExitSurfaceHandler;

	RMbool ReceivedCECStandby;

	PVOID pMediaSrv;
};

DECLARE_EXTERN_C_BLOCK_START

RMstatus player_rmfp_run(struct rmfp_main_thread_context_type *pMainContext);
RMstatus player_rmfp_exit(struct rmfp_main_thread_context_type *pMainContext);

RMstatus player_rmfp_openurl(struct rmfp_main_thread_context_type *pMainContext,
                             const RMascii *fileName);
RMstatus player_rmfp_closeurl(struct rmfp_main_thread_context_type *pMainContext);
RMstatus init_font_rendering(	struct rmfp_main_thread_context_type *pMainContext,
	RMascii* pAppName,  RMuint8** ppDefaultFontName, RMuint8** ppCCFontName, RMuint8** ppForcedFontName);

DECLARE_EXTERN_C_BLOCK_END

#endif //__TESTRMFP_H__

