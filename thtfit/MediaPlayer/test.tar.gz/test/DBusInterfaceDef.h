#ifndef	_DBUS_INTERFACE_DEF_H_
#define	_DBUS_INTERFACE_DEF_H_

#define	DBUS_SystemService_NetMgrSrv_If	"org.thtfit.SystemService.NetworkManagerSrv"
#define	DBUS_SysSrv_SysEvt_If	"org.thtfit.SystemService.SystemEvent"

#define	NetMgrIf_SigName_SntpUpdatedSysTime		"SntpUpdatedSysTime"
#define	SysEvtIf_SigName_Evt_SyncCacheToStorage		"Evt_SyncCacheToStorage"

#endif	//_DBUS_INTERFACE_DEF_H_

