/*****************************************
 Copyright 2001-2007
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   rmfp_internal.c
  @brief


  @author Sebastian Frias Feltrer
  @date   2007-08-07
*/


/*
   If set to 0 then all ASSERT_NULL_POINTER() calls will be disabled.
   By default (set to 1) we only check for NULL pointers at the
   interface, but not inside the library, see rmfp_internal.h to enable
   checking inside the library
*/

#ifndef	ALLOW_OS_CODE
#define	ALLOW_OS_CODE
#endif	//ALLOW_OS_CODE

#define CHECK_NULL_POINTERS 1


#include <rmlibcw/include/rmlibcw.h>
#include <rmcore/include/rmcore.h>
#include <rmtextsubs/include/rmtextsubs.h>
#include "rmfp_internal.h"
#include <ErrPrintHelper.h>

#if 0
#define LOCALDBG ENABLE
#else
#define LOCALDBG DISABLE
#endif

/*
  INTERNAL RMLIBPLAY CALLBACK HANDLERS
*/

RMstatus rmfp_internal_get_command_handler(void *pContext, struct RMFPPlaybackCommand *pCommand, RMuint32 TimeOutInMicroSeconds)
{
	RMstatus status = RM_OK;
	struct RMFPHandle *pHandle = (struct RMFPHandle *)pContext;

	RMDBGLOG((LOCALDBG, "rmfp_internal_get_command_handler\n"));

	ASSERT_NULL_POINTER(pHandle);
	ASSERT_NULL_POINTER(pCommand);

	/* There is no polling function, see if a new command is avaible in our structure */
	if (!pHandle->profile.rmfp_get_command_callback)
	{
		/* Is there a command in the fifo ? */
		if (pHandle->command_execution_status != RMFPCommand_execution_status_to_be_processed)
			return RM_PENDING;

		/* Get a new command from fifo */
		*pCommand = pHandle->command;

		/* Update status */
		pHandle->command_execution_status = RMFPCommand_execution_status_in_progress;

		status = RM_OK;
	}
	else
		status = pHandle->profile.rmfp_get_command_callback(pHandle->profile.callback_context,pCommand, TimeOutInMicroSeconds);


	if (status == RM_OK)
		RMDBGLOG((ENABLE, "Got command %lu\n", (RMuint32)pCommand->command));

	return status;
}

/**************************************************************************************************/

RMstatus rmfp_internal_notify_command_status_handler(void *pContext, struct RMFPCommandStatus *pCommandStatus)
{
	struct RMFPHandle *pHandle = (struct RMFPHandle *)pContext;

	RMDBGLOG((LOCALDBG, "rmfp_internal_notify_command_status_handler\n"));

	ASSERT_NULL_POINTER(pHandle);
	ASSERT_NULL_POINTER(pCommandStatus);

	/* Dont send rmlibplay commands status */
	if (pCommandStatus->lastCommand.command >= RMFP_Playback_command_Play+10000)
		return RM_OK;

	/* There is no polling function, update the command status in the main structure */
	if (!pHandle->profile.rmfp_get_command_callback)
	{
		/* Is there a command in progress */
		if (pHandle->command_execution_status != RMFPCommand_execution_status_in_progress)
			return RM_PENDING;

		/* Store status */
		pHandle->command_status = *pCommandStatus;

		/* Update status */
		pHandle->command_execution_status = RMFPCommand_execution_status_completed;

		return RM_OK;
	}
	else
	{
		if (!pHandle->profile.rmfp_notify_command_status_callback)
			return RM_NOTIMPLEMENTED;

		return pHandle->profile.rmfp_notify_command_status_callback(pHandle->profile.callback_context, pCommandStatus);
	}
}

/**************************************************************************************************/

RMstatus rmfp_internal_notify_playback_status_handler(void *pContext, struct RMFPPlaybackStatus *pStatus)
{
	struct RMFPHandle *pHandle = (struct RMFPHandle *)pContext;

	RMDBGLOG((LOCALDBG, "rmfp_internal_notify_playback_status_handler\n"));

	ASSERT_NULL_POINTER(pHandle);
	ASSERT_NULL_POINTER(pStatus);

	if (!pHandle->profile.rmfp_notify_playback_status_callback)
		return RM_OK;

	return pHandle->profile.rmfp_notify_playback_status_callback(pHandle->profile.callback_context, pStatus);
}

/**************************************************************************************************/

RMstatus rmfp_internal_notify_playback_start_handler(void *pContext)
{
	struct RMFPHandle *pHandle = (struct RMFPHandle *)pContext;

	RMDBGLOG((LOCALDBG, "rmfp_internal_notify_playback_start_handler\n"));

	ASSERT_NULL_POINTER(pHandle);

	if (!pHandle->profile.rmfp_notify_playback_start_callback)
		return RM_OK;

	return pHandle->profile.rmfp_notify_playback_start_callback(pHandle->profile.callback_context);
}

/**************************************************************************************************/

RMstatus rmfp_internal_notify_playback_eos_handler(void *pContext)
{
	struct RMFPHandle *pHandle = (struct RMFPHandle *)pContext;

	RMDBGLOG((LOCALDBG, "rmfp_internal_notify_playback_eos_handler\n"));

	ASSERT_NULL_POINTER(pHandle);

	if (!pHandle->profile.rmfp_notify_playback_eos_callback)
		return RM_OK;

	return pHandle->profile.rmfp_notify_playback_eos_callback(pHandle->profile.callback_context);
}

/**************************************************************************************************/

RMstatus rmfp_internal_notify_available_commands_handler(void *pContext, RMuint32 mask)
{
	struct RMFPHandle *pHandle = (struct RMFPHandle *)pContext;

	RMDBGLOG((LOCALDBG, "rmfp_internal_notify_available_commands_handler\n"));

	ASSERT_NULL_POINTER(pHandle);

	if (!pHandle->profile.rmfp_notify_available_commands_callback)
		return RM_OK;

	return pHandle->profile.rmfp_notify_available_commands_callback(pHandle->profile.callback_context, mask);
}

/**************************************************************************************************/

RMstatus rmfp_internal_notify_current_streams_properties_handler(void *pContext, struct RMFPStreamProperties *pStreamProperties)
{
	struct RMFPHandle *pHandle = (struct RMFPHandle *)pContext;

	RMDBGLOG((LOCALDBG, "rmfp_internal_notify_current_streams_properties_handler\n"));

	ASSERT_NULL_POINTER(pHandle);
	ASSERT_NULL_POINTER(pStreamProperties);

	if (!pHandle->profile.rmfp_notify_current_streams_properties_callback)
		return RM_OK;

	/* Add versions */
	pStreamProperties->Version = GET_VERSION_FROM_MAGIC(RMFP_CURRENT_STREAMS_PROPERTIES_VERSION);

	return pHandle->profile.rmfp_notify_current_streams_properties_callback(pHandle->profile.callback_context, pStreamProperties);
}

/**************************************************************************************************/

RMstatus rmfp_internal_notify_stream_metadata(void *pContext, struct RMFPStreamMetadata *pStreamMetadata)
{
	struct RMFPHandle *pHandle = (struct RMFPHandle *)pContext;

	RMDBGLOG((LOCALDBG, "rmfp_internal_notify_stream_metadata\n"));

	ASSERT_NULL_POINTER(pHandle);
	ASSERT_NULL_POINTER(pStreamMetadata);

	if (!pHandle->profile.rmfp_notify_stream_metadata_callback)
		return RM_OK;

	/* Add version */
	pStreamMetadata->Version = GET_VERSION_FROM_MAGIC(RMFP_STREAM_METADATA_VERSION);

	return pHandle->profile.rmfp_notify_stream_metadata_callback(pHandle->profile.callback_context, pStreamMetadata);
}

/**************************************************************************************************/

RMstatus rmfp_internal_notify_pat_handler(void *pContext, struct RMFPPAT *pPAT)
{
	struct RMFPHandle *pHandle = (struct RMFPHandle *)pContext;

	RMDBGLOG((LOCALDBG, "rmfp_internal_notify_pat_handler\n"));

	ASSERT_NULL_POINTER(pHandle);
	ASSERT_NULL_POINTER(pPAT);

	if (!pHandle->profile.rmfp_notify_pat_callback)
		return RM_OK;

	/* Add version */
	pPAT->Version = GET_VERSION_FROM_MAGIC(RMFP_PAT_VERSION);

	return pHandle->profile.rmfp_notify_pat_callback(pHandle->profile.callback_context, pPAT);
}

/**************************************************************************************************/

RMstatus rmfp_internal_notify_pmt_handler(void *pContext, struct RMFPPMT *pPMT)
{
	struct RMFPHandle *pHandle = (struct RMFPHandle *)pContext;

	RMDBGLOG((LOCALDBG, "rmfp_internal_notify_pmt_handler\n"));

	ASSERT_NULL_POINTER(pHandle);
	ASSERT_NULL_POINTER(pPMT);

	if (!pHandle->profile.rmfp_notify_pmt_callback)
		return RM_OK;

	/* Add version */
	pPMT->Version = GET_VERSION_FROM_MAGIC(RMFP_PMT_VERSION);

	return pHandle->profile.rmfp_notify_pmt_callback(pHandle->profile.callback_context, pPMT);
}

/**************************************************************************************************/

RMstatus rmfp_internal_notify_pid_creation_handler(void *pContext, struct RMFPPID *pPID)
{
	struct RMFPHandle *pHandle = (struct RMFPHandle *)pContext;

	RMDBGLOG((LOCALDBG, "rmfp_internal_notify_pid_creation_handler\n"));

	ASSERT_NULL_POINTER(pHandle);
	ASSERT_NULL_POINTER(pPID);

	if (!pHandle->profile.rmfp_notify_pid_creation_callback)
		return RM_OK;

	/* Add version */
	pPID->Version = GET_VERSION_FROM_MAGIC(RMFP_PID_VERSION);

	return pHandle->profile.rmfp_notify_pid_creation_callback(pHandle->profile.callback_context, pPID);
}

/**************************************************************************************************/

RMstatus rmfp_internal_notify_send_data_handler(void *pContext, struct RMFPSendData *pSendData)
{
	struct RMFPHandle *pHandle = (struct RMFPHandle *)pContext;

	RMDBGLOG((LOCALDBG, "rmfp_internal_notify_send_data_handler\n"));

	ASSERT_NULL_POINTER(pHandle);
	ASSERT_NULL_POINTER(pSendData);

	if (!pHandle->profile.rmfp_notify_send_data_callback)
		return RM_OK;

	/* Add version */
	pSendData->Version = GET_VERSION_FROM_MAGIC(RMFP_SEND_DATA_VERSION);

	return pHandle->profile.rmfp_notify_send_data_callback(pHandle->profile.callback_context, pSendData);
}

/**************************************************************************************************/

RMstatus rmfp_internal_disk_control_handler(void *pContext, enum RMFPDiskControl_action action)
{
	struct RMFPHandle *pHandle = (struct RMFPHandle *)pContext;

	RMDBGLOG((LOCALDBG, "rmfp_internal_disk_control_handler\n"));

	ASSERT_NULL_POINTER(pHandle);

	if (!pHandle->profile.rmfp_disk_control_callback)
		return RM_OK;

	return pHandle->profile.rmfp_disk_control_callback(pHandle->profile.callback_context, action);

}

/**************************************************************************************************/

RMstatus rmfp_internal_notify_event_handler(void *pContext, struct RUAEvent *pEvent)
{
	struct RMFPHandle *pHandle = (struct RMFPHandle *)pContext;

	RMDBGLOG((LOCALDBG, "rmfp_internal_notify_event_handler\n"));

	ASSERT_NULL_POINTER(pHandle);

	if (!pHandle->profile.rmfp_notify_event_callback)
		return RM_OK;

	return pHandle->profile.rmfp_notify_event_callback(pHandle->profile.callback_context, pEvent);
}

/**************************************************************************************************/

RMstatus rmfp_internal_notify_progress_handler(void *pContext, struct RMFPProgress* pProgress, RMbool *pAbort)
{
	struct RMFPHandle *pHandle = (struct RMFPHandle *)pContext;

	RMDBGLOG((LOCALDBG, "rmfp_internal_notify_progress_handler\n"));

	ASSERT_NULL_POINTER(pHandle);

	if (!pHandle->profile.rmfp_notify_progress_callback)
		return RM_OK;

	/* Add version */
	pProgress->Version = GET_VERSION_FROM_MAGIC(RMFP_PROGRESS_VERSION);

	return pHandle->profile.rmfp_notify_progress_callback(pHandle->profile.callback_context, pProgress, pAbort);
}

/**************************************************************************************************/

RMstatus rmfp_internal_open_bdspu_decoder(void *pContext)
{
	struct RMFPHandle *pHandle = (struct RMFPHandle *)pContext;

	RMDBGLOG((LOCALDBG, "rmfp_internal_open_bdspu_decoder\n"));

	ASSERT_NULL_POINTER(pHandle);

	if (!pHandle->profile.rmfp_open_bdspu_decoder_callback)
		return RM_OK;

	return pHandle->profile.rmfp_open_bdspu_decoder_callback(pHandle->profile.callback_context);
}

/**************************************************************************************************/

RMstatus rmfp_internal_close_bdspu_decoder(void *pContext)
{
	struct RMFPHandle *pHandle = (struct RMFPHandle *)pContext;

	RMDBGLOG((LOCALDBG, "rmfp_internal_close_bdspu_decoder\n"));

	ASSERT_NULL_POINTER(pHandle);

	if (!pHandle->profile.rmfp_close_bdspu_decoder_callback)
		return RM_OK;

	return pHandle->profile.rmfp_close_bdspu_decoder_callback(pHandle->profile.callback_context);
}

/**************************************************************************************************/

RMstatus rmfp_internal_send_bdspu_decoder(void *pContext, RMuint8* pBuffer, RMuint32 Size)
{
	struct RMFPHandle *pHandle = (struct RMFPHandle *)pContext;

	RMDBGLOG((LOCALDBG, "rmfp_internal_send_bdspu_decoder\n"));

	ASSERT_NULL_POINTER(pHandle);

	if (!pHandle->profile.rmfp_send_bdspu_decoder_callback)
		return RM_OK;

	return pHandle->profile.rmfp_send_bdspu_decoder_callback(pHandle->profile.callback_context, pBuffer, Size);
}

/**************************************************************************************************/

RMstatus rmfp_internal_flush_bdspu_decoder(void *pContext)
{
	struct RMFPHandle *pHandle = (struct RMFPHandle *)pContext;

	RMDBGLOG((LOCALDBG, "rmfp_internal_flush_bdspu_decoder\n"));

	ASSERT_NULL_POINTER(pHandle);

	if (!pHandle->profile.rmfp_flush_bdspu_decoder_callback)
		return RM_OK;

	return pHandle->profile.rmfp_flush_bdspu_decoder_callback(pHandle->profile.callback_context);
}


/*
  Other routines for RMFP
*/

RMstatus rmfp_internal_get_route(struct RMFPHandle *pHandle, enum DCCRoute *pDCCRoute)
{
	RMstatus status;
	
	if (!pHandle || !pDCCRoute)
		return RM_ERROR;

	/* Get route from application */
	if (pHandle->profile.rmfp_get_route_callback)
	{
		struct RMFPRoute rmfp_route = {0, };
		
		status = pHandle->profile.rmfp_get_route_callback(pHandle->profile.callback_context, &rmfp_route);
		if (status != RM_OK)
		{
			RMNOTIFY((NULL, status, "Cannot get route from application\n"));
			return status;
		}
		
		switch (rmfp_route.route) {
			case RMFPRoute_Main: *pDCCRoute = DCCRoute_Main; break;
			case RMFPRoute_Secondary: *pDCCRoute = DCCRoute_Secondary; break;
			case RMFPRoute_ColorBars: *pDCCRoute = DCCRoute_ColorBars; break;
			default:
				RMNOTIFY((NULL, status, "Invalid route %d\n", rmfp_route.route));
				return RM_ERROR;
		}
	}
	else
		*pDCCRoute = RMFP_DEFAULT_DCC_DISPLAY_ROUTE;
	
	return RM_OK;
}	 	

RMstatus rmfp_internal_hls_get_key( void* pContext, RMascii *url, RMuint8 *key, RMuint32 keylength)
{
	struct RMFPHandle* pHandle;

	RMDBGLOG((LOCALDBG, "rmfp_internal_hls_get_key\n"));

	ASSERT_NULL_POINTER(pContext);

	pHandle = (struct RMFPHandle *)pContext;

	if (!pHandle->profile.rmfp_hls_get_key_callback)
		return RM_OK;

	return pHandle->profile.rmfp_hls_get_key_callback(pHandle->profile.callback_context, url, key, keylength);
}


RMstatus rmfp_internal_getVideoScalerModuleId(struct RMFPHandle *pHandle, RMuint32 * pVidScalerModuleId, enum DCCRoute * pDccRoute)
{
	RMstatus eOutRMstatus = RM_OK;

	do
	{
		if(NULL == pHandle->profile.rmfp_get_video_scaler_callback)
		{
			break;
		}
		eOutRMstatus = pHandle->profile.rmfp_get_video_scaler_callback(pHandle->profile.callback_context, pVidScalerModuleId, pDccRoute);
	}while(FALSE);

	return eOutRMstatus;
}

RMstatus RmfpInternal_AudioEngine_setSampleFreq(struct RMFPHandle *pHandle, RMbool bUseCurCfg, 
	RMbool bAutoSetFromStream, RMuint32 audioSampleFreq)
{
	RMstatus eOutRMstatus = RM_OK;

	do
	{
		if(NULL == pHandle->profile.pfnRmoutputAudioEngine_setSampleFreq)
		{
			break;
		}
		eOutRMstatus = pHandle->profile.pfnRmoutputAudioEngine_setSampleFreq(
			pHandle->profile.callback_context, bUseCurCfg, bAutoSetFromStream, audioSampleFreq);
	}while(FALSE);

	return eOutRMstatus;
}

