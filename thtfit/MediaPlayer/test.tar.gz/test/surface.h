/*****************************************
 Copyright 2001-2007
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   surface.h
  @brief  This file provides with sample code for implementing RMFP's callbacks

	  This file is part of the test_rmfp suite

  @author Sebastian Frias Feltrer
  @date   2007-10-29
*/

/*
  **********************************************
  DISCLAIMER:

  - THIS IS TEST CODE, provided as sample code
  to help you understand what you should do to
  develop your own application based in RMFP.

  - This is NOT production grade code; It is not
  even a library, so any API defined here, CAN
  and WILL CHANGE without notice.

  **********************************************
*/

#ifndef __TESTRMFP_SURFACE_H__
#define __TESTRMFP_SURFACE_H__


#include <rmdef/rmdef.h>
#include "rmfp.h"
#include "test_rmfp.h"

RMstatus get_surface_events_handler(void *pContext,struct RMFPSurfaceProfile *pSurfaceProfile, struct RMFPSurfaceEventsSource *pSurfaceEventsSource);
RMstatus disconnect_surface_handler(void *pContext, RMuint32 surface);

#endif // __TESTRMFP_SURFACE_H__
