/*****************************************
 Copyright 2001-2007
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   resources.h
  @brief  This file provides an example of implementation of the resources callbacks
	  from the RMFP profile

	  This file is part of the test_rmfp suite

  @author Sebastian Frias Feltrer
  @date   2007-10-29
*/

/*
  **********************************************
  DISCLAIMER:

  - THIS IS TEST CODE, provided as sample code
  to help you understand what you should do to
  develop your own application based in RMFP.

  - This is NOT production grade code; It is not
  even a library, so any API defined here, CAN
  and WILL CHANGE without notice.

  **********************************************
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>

#define ALLOW_OS_CODE 1

#include "resources.h"
#include <dcc/include/dcc_macros.h>
#include "test_rmfp.h"

#if 0
#define LOCALDBG ENABLE
#else
#define LOCALDBG DISABLE
#endif

/*
 * Define all the profiles version for which this file has been written
 */

#define RMFP_VIDEO_RESOURCES_PROFILE_VERSION		1
#define RMFP_PICTURE_TRANSFORM_RESOURCES_PROFILE_VERSION 1
#define RMFP_PPF_RESOURCES_PROFILE_VERSION			1
#define RMFP_AUDIO_INSTANCES_PROFILE_VERSION		1
#define RMFP_AUDIO_RESOURCES_PROFILE_VERSION		2
#define RMFP_DEMUX_RESOURCES_PROFILE_VERSION		1
#define RMFP_DEMUX_OUTPUT_RESOURCES_PROFILE_VERSION	1
#define RMFP_SPU_RESOURCES_PROFILE_VERSION		1
#define RMFP_DMAPOOL_RESOURCES_PROFILE_VERSION          1
#define RMFP_CCFIFO_RESOURCES_PROFILE_VERSION		1
#define RMFP_TELETEXT_PROFILE_VERSION			1

#define RMFP_RMWMDRM_PROFILE_VERSION                    1
#define RMFP_RMWMDRM_RESOURCES_PROFILE_VERSION          1


#define AUDIO_DRAM_CONTROLLER				0
struct { RMuint32 engine_index; RMuint32 decoder_index; } Audio_Instances[] = { {0, 1}, {0, 0}, {1, 0}, {0, 1} };

#if (EM86XX_CHIP==EM86XX_CHIPID_TANGO3)
	#define VIDEO_DRAM_CONTROLLER			0
	#define VIDEO_ENGINE_INDEX			0
#else
	#define VIDEO_DRAM_CONTROLLER			1
	#define VIDEO_ENGINE_INDEX			1
#endif

#define OTHERS_DRAM_CONTROLLER				0

/*
 * Local routines
 */
static RMstatus print_video_resources_profile(struct RMFPVideoResourcesProfile *pProfile);
static RMstatus print_picture_transform_resources_profile(struct RMFPPictureTransformResourcesProfile *pProfile);
static RMstatus print_ppf_resources_profile(struct RMFPPPFResourcesProfile *pProfile);
static RMstatus print_audio_instances_profile(struct RMFPMultipleAudioInstancesProfile *pProfile);
static RMstatus print_audio_resources_profile(struct RMFPMultipleAudioResourcesProfile *pProfile);
static RMstatus print_demux_resources_profile(struct RMFPDemuxResourcesProfile *pProfile);
static RMstatus print_demux_output_resources_profile(struct RMFPDemuxOutputResourcesProfile *pProfile);
static RMstatus print_spu_resources_profile(struct RMFPSPUResourcesProfile *pProfile);
static RMstatus print_ccfifo_resources_profile(struct RMFPCCFIFOResourcesProfile *pProfile);
static RMstatus print_teletext_resources_profile(struct RMFPTTXResourcesProfile *pProfile);
static RMstatus print_rmwmdrm_resources_profile(struct RMFPRMWMDRMResourcesProfile *pProfile);

/*
 * Macros
 */
#define ALLOCATE_RESOURCES(destination, controller, type, size)		\
	{								\
		destination = DCCMalloc(pHandle->pDCC,			\
					controller,			\
					type,				\
					size);				\
		if (!destination && size) {				\
			RMNOTIFY((NULL, RM_FATALOUTOFMEMORY, "Unable to allocate %d bytes\n", size)); \
			return RM_FATALOUTOFMEMORY;			\
		}							\
		else							\
			RMDBGLOG((LOCALDBG, "Allocated %lu bytes at %p\n", size, destination));	\
	}


#define FREE_RESOURCES(source)			\
	{					\
		if (source) {						\
			DCCFree(pHandle->pDCC, source);			\
			RMDBGLOG((LOCALDBG, "Freed %p\n", source));	\
			source = 0;					\
		}							\
	}								\


#define CHECK_VERSION(version)						\
	{								\
		if (pProfile->Version != version) {			\
			RMNOTIFY((NULL, RM_ERROR, "Got version 0x%lx, expected 0x%lx\n", pProfile->Version, version)); \
			return RM_ERROR;				\
		}							\
	}

/**************************************************************************************************/

RMstatus video_resources_handler(void *pContext, struct RMFPVideoResourcesProfile *pProfile)
{
	struct rmfp_main_thread_context_type *pHandle = NULL;

	RMDBGLOG((LOCALDBG, "video_resources_handler()\n"));

	ASSERT_NULL_POINTER(pContext);
	ASSERT_NULL_POINTER(pProfile);

	pHandle = (struct rmfp_main_thread_context_type *)pContext;

	/* Check version of profile, so that we are sure we do not use a mismatched structure */
	CHECK_VERSION(RMFP_VIDEO_RESOURCES_PROFILE_VERSION);

	RMDBGLOG((LOCALDBG, "input profile\n"));
	print_video_resources_profile(pProfile);


	if (pHandle->AppOptions.Playback.test_external_resources_allocation)
	{

		pProfile->dram = VIDEO_DRAM_CONTROLLER;
		pProfile->engine_index = VIDEO_ENGINE_INDEX;

		ALLOCATE_RESOURCES(pProfile->scheduler_memory_address, pProfile->dram, RUA_DRAM_UNCACHED, pProfile->scheduler_memory_size);
		ALLOCATE_RESOURCES(pProfile->shared_memory_address, pProfile->dram, RUA_DRAM_UNCACHED, pProfile->shared_memory_size);
		ALLOCATE_RESOURCES(pProfile->picture_memory_address, pProfile->dram, RUA_DRAM_UNCACHED, pProfile->picture_memory_size);
		ALLOCATE_RESOURCES(pProfile->bitstream_memory_address, pProfile->dram, RUA_DRAM_UNCACHED, pProfile->bitstream_memory_size);
		ALLOCATE_RESOURCES(pProfile->unprotected_memory_address, pProfile->dram, RUA_DRAM_UNCACHED, pProfile->unprotected_memory_size);
		ALLOCATE_RESOURCES(pProfile->postprocessing_memory_address, pProfile->dram, RUA_DRAM_UNCACHED, pProfile->postprocessing_memory_size);

		RMDBGLOG((LOCALDBG, "returned profile\n"));
		print_video_resources_profile(pProfile);
	}

	return RM_OK;
}

/**************************************************************************************************/

RMstatus release_video_resources_handler(void *pContext, struct RMFPVideoResourcesProfile *pProfile)
{
	struct rmfp_main_thread_context_type *pHandle = NULL;

	RMDBGLOG((LOCALDBG, "release_video_resources_handler()\n"));

	ASSERT_NULL_POINTER(pContext);
	ASSERT_NULL_POINTER(pProfile);

	pHandle = (struct rmfp_main_thread_context_type *)pContext;

	/* Check version of profile, so that we are sure we do not use a mismatched structure */
	CHECK_VERSION(RMFP_VIDEO_RESOURCES_PROFILE_VERSION);

	RMDBGLOG((LOCALDBG, "input profile\n"));
	print_video_resources_profile(pProfile);


	if (pHandle->AppOptions.Playback.test_external_resources_allocation)
	{

		FREE_RESOURCES(pProfile->scheduler_memory_address);;
		FREE_RESOURCES(pProfile->shared_memory_address);
		FREE_RESOURCES(pProfile->scheduler_memory_address);
		FREE_RESOURCES(pProfile->picture_memory_address);
		FREE_RESOURCES(pProfile->bitstream_memory_address);
		FREE_RESOURCES(pProfile->unprotected_memory_address);
		FREE_RESOURCES(pProfile->postprocessing_memory_address);

		RMDBGLOG((LOCALDBG, "returned profile\n"));
		print_video_resources_profile(pProfile);
	}

	return RM_OK;
}

/**************************************************************************************************/

RMstatus picture_transform_resources_handler(void *pContext, struct RMFPPictureTransformResourcesProfile *pProfile)
{
	struct rmfp_main_thread_context_type *pHandle = NULL;

	RMDBGLOG((LOCALDBG, "picture_transform_resources_handler()\n"));

	ASSERT_NULL_POINTER(pContext);
	ASSERT_NULL_POINTER(pProfile);

	pHandle = (struct rmfp_main_thread_context_type *)pContext;

	RMDBGLOG((LOCALDBG, "input profile\n"));
	print_picture_transform_resources_profile(pProfile);


	if (pHandle->AppOptions.Playback.test_external_resources_allocation) {
		/* Check version of profile, so that we are sure we do not use a mismatched structure */
		CHECK_VERSION(RMFP_PICTURE_TRANSFORM_RESOURCES_PROFILE_VERSION);


		pProfile->dram = VIDEO_DRAM_CONTROLLER;
		pProfile->engine_index = VIDEO_ENGINE_INDEX;

		ALLOCATE_RESOURCES(pProfile->data_memory_address, pProfile->dram, RUA_DRAM_UNCACHED, pProfile->data_memory_size);
		ALLOCATE_RESOURCES(pProfile->interface_memory_address, pProfile->dram, RUA_DRAM_UNCACHED, pProfile->interface_memory_size);

		RMDBGLOG((LOCALDBG, "returned profile\n"));
		print_picture_transform_resources_profile(pProfile);
	}

	return RM_OK;
}

/**************************************************************************************************/

RMstatus release_picture_transform_resources_handler(void *pContext, struct RMFPPictureTransformResourcesProfile *pProfile)
{
	struct rmfp_main_thread_context_type *pHandle = NULL;

	RMDBGLOG((LOCALDBG, "release_picture_transform_resources_handler()\n"));

	ASSERT_NULL_POINTER(pContext);
	ASSERT_NULL_POINTER(pProfile);

	pHandle = (struct rmfp_main_thread_context_type *)pContext;

	RMDBGLOG((LOCALDBG, "input profile\n"));
	print_picture_transform_resources_profile(pProfile);


	if (pHandle->AppOptions.Playback.test_external_resources_allocation) {
		/* Check version of profile, so that we are sure we do not use a mismatched structure */
		CHECK_VERSION(RMFP_PICTURE_TRANSFORM_RESOURCES_PROFILE_VERSION);

		FREE_RESOURCES(pProfile->data_memory_address);;
		FREE_RESOURCES(pProfile->interface_memory_address);

		RMDBGLOG((LOCALDBG, "returned profile\n"));
		print_picture_transform_resources_profile(pProfile);
	}

	return RM_OK;
}

/**************************************************************************************************/

RMstatus ppf_resources_handler(void *pContext, struct RMFPPPFResourcesProfile *pProfile)
{
	struct rmfp_main_thread_context_type *pHandle = NULL;

	RMDBGLOG((LOCALDBG, "ppf_resources_handler()\n"));

	ASSERT_NULL_POINTER(pContext);
	ASSERT_NULL_POINTER(pProfile);

	pHandle = (struct rmfp_main_thread_context_type *)pContext;

	RMDBGLOG((LOCALDBG, "input profile\n"));
	print_ppf_resources_profile(pProfile);


	if (pHandle->AppOptions.Playback.test_external_resources_allocation) {
		/* Check version of profile, so that we are sure we do not use a mismatched structure */
		CHECK_VERSION(RMFP_PPF_RESOURCES_PROFILE_VERSION);


		pProfile->dram = VIDEO_DRAM_CONTROLLER;
		pProfile->engine_index = VIDEO_ENGINE_INDEX;

		ALLOCATE_RESOURCES(pProfile->engine_memory_address, pProfile->dram, RUA_DRAM_UNCACHED, pProfile->engine_memory_size);
		ALLOCATE_RESOURCES(pProfile->input_memory_address, pProfile->dram, RUA_DRAM_UNCACHED, pProfile->input_memory_size);
		ALLOCATE_RESOURCES(pProfile->output_memory_address, pProfile->dram, RUA_DRAM_UNCACHED, pProfile->output_memory_size);
		ALLOCATE_RESOURCES(pProfile->data_memory_address, pProfile->dram, RUA_DRAM_UNCACHED, pProfile->data_memory_size);

		RMDBGLOG((LOCALDBG, "returned profile\n"));
		print_ppf_resources_profile(pProfile);
	}

	return RM_OK;
}

/**************************************************************************************************/

RMstatus release_ppf_resources_handler(void *pContext, struct RMFPPPFResourcesProfile *pProfile)
{
	struct rmfp_main_thread_context_type *pHandle = NULL;

	RMDBGLOG((LOCALDBG, "release_ppf_resources_handler()\n"));

	ASSERT_NULL_POINTER(pContext);
	ASSERT_NULL_POINTER(pProfile);

	pHandle = (struct rmfp_main_thread_context_type *)pContext;

	RMDBGLOG((LOCALDBG, "input profile\n"));
	print_ppf_resources_profile(pProfile);


	if (pHandle->AppOptions.Playback.test_external_resources_allocation) {
		/* Check version of profile, so that we are sure we do not use a mismatched structure */
		CHECK_VERSION(RMFP_PPF_RESOURCES_PROFILE_VERSION);

		FREE_RESOURCES(pProfile->engine_memory_address);
		FREE_RESOURCES(pProfile->input_memory_address);
		FREE_RESOURCES(pProfile->output_memory_address);
		FREE_RESOURCES(pProfile->data_memory_address);

		RMDBGLOG((LOCALDBG, "returned profile\n"));
		print_ppf_resources_profile(pProfile);
	}

	return RM_OK;
}

/**************************************************************************************************/

RMstatus audio_instances_handler(void *pContext, struct RMFPMultipleAudioInstancesProfile *pProfile)
{
	struct rmfp_main_thread_context_type *pHandle = NULL;
	RMuint32 cnt;

	RMDBGLOG((LOCALDBG, "audio_instances_handler()\n"));

	ASSERT_NULL_POINTER(pContext);
	ASSERT_NULL_POINTER(pProfile);

	pHandle = (struct rmfp_main_thread_context_type *)pContext;

	RMDBGLOG((LOCALDBG, "input profile\n"));
	print_audio_instances_profile(pProfile);

	/* Check version of profile, so that we are sure we do not use a mismatched structure */
	CHECK_VERSION(RMFP_AUDIO_INSTANCES_PROFILE_VERSION);

	/* No instance ? */
	if (!pProfile->number_of_instances)
		return RM_OK;

	/* Use the command line parameters */
	pProfile->instance[0].engine_index = pHandle->pOptions->audio_options.EngineIndex;
	pProfile->instance[0].decoder_index = pHandle->pOptions->audio_options.DecoderIndex;

	/* For all other instances, use app options */
	for (cnt=1; cnt<pProfile->number_of_instances && cnt<MAX_AUDIO_DECODER_INSTANCES; cnt++)
	{
		pProfile->instance[cnt].engine_index = pHandle->AppOptions.Audio.ExtraAudioEngine[cnt-1];
		pProfile->instance[cnt].decoder_index = pHandle->AppOptions.Audio.ExtraAudioDecoder[cnt-1];
	}

	RMDBGLOG((LOCALDBG, "returned profile\n"));
	print_audio_instances_profile(pProfile);

	return RM_OK;
}

/**************************************************************************************************/

RMstatus audio_resources_handler(void *pContext, struct RMFPMultipleAudioResourcesProfile *pProfile)
{
	struct rmfp_main_thread_context_type *pHandle = NULL;
	RMuint32 cnt;

	RMDBGLOG((LOCALDBG, "audio_resources_handler()\n"));

	ASSERT_NULL_POINTER(pContext);
	ASSERT_NULL_POINTER(pProfile);

	pHandle = (struct rmfp_main_thread_context_type *)pContext;

	RMDBGLOG((LOCALDBG, "input profile\n"));
	print_audio_resources_profile(pProfile);

	if (pHandle->AppOptions.Playback.test_external_resources_allocation) {
		/* Check version of profile, so that we are sure we do not use a mismatched structure */
		CHECK_VERSION(RMFP_AUDIO_RESOURCES_PROFILE_VERSION);

		for (cnt=0; cnt<pProfile->number_of_engines; cnt++) {
			pProfile->engine[cnt].dram = AUDIO_DRAM_CONTROLLER;
			ALLOCATE_RESOURCES(pProfile->engine[cnt].shared_memory_address, pProfile->engine[cnt].dram, RUA_DRAM_UNCACHED, pProfile->engine[cnt].shared_memory_size);
		}

		for (cnt=0; cnt<pProfile->number_of_instances; cnt++) {
			pProfile->instance[cnt].dram = AUDIO_DRAM_CONTROLLER;

			ALLOCATE_RESOURCES(pProfile->instance[cnt].protected_memory_address, pProfile->instance[cnt].dram, RUA_DRAM_CACHED, pProfile->instance[cnt].protected_memory_size);
			ALLOCATE_RESOURCES(pProfile->instance[cnt].unprotected_memory_address, pProfile->instance[cnt].dram, RUA_DRAM_UNCACHED, pProfile->instance[cnt].unprotected_memory_size);
		}

		RMDBGLOG((LOCALDBG, "returned profile\n"));
		print_audio_resources_profile(pProfile);
	}

	return RM_OK;
}

/**************************************************************************************************/

RMstatus release_audio_resources_handler(void *pContext, struct RMFPMultipleAudioResourcesProfile *pProfile)
{
	struct rmfp_main_thread_context_type *pHandle = NULL;
	RMuint32 cnt;

	RMDBGLOG((LOCALDBG, "release_audio_resources_handler()\n"));

	ASSERT_NULL_POINTER(pContext);
	ASSERT_NULL_POINTER(pProfile);

	pHandle = (struct rmfp_main_thread_context_type *)pContext;

	RMDBGLOG((LOCALDBG, "input profile\n"));
	print_audio_resources_profile(pProfile);

	if (pHandle->AppOptions.Playback.test_external_resources_allocation) {
		/* Check version of profile, so that we are sure we do not use a mismatched structure */
		CHECK_VERSION(RMFP_AUDIO_RESOURCES_PROFILE_VERSION);


		for (cnt=0; cnt<pProfile->number_of_engines; cnt++)
			FREE_RESOURCES(pProfile->engine[cnt].shared_memory_address);

		for (cnt=0; cnt<pProfile->number_of_instances; cnt++)
		{
			FREE_RESOURCES(pProfile->instance[cnt].protected_memory_address);
			FREE_RESOURCES(pProfile->instance[cnt].unprotected_memory_address);
		}

		RMDBGLOG((LOCALDBG, "returned profile\n"));
		print_audio_resources_profile(pProfile);


	}



	return RM_OK;
}

/**************************************************************************************************/

RMstatus demux_resources_handler(void *pContext, struct RMFPDemuxResourcesProfile *pProfile)
{
	struct rmfp_main_thread_context_type *pHandle = NULL;

	RMDBGLOG((LOCALDBG, "demux_resources_handler()\n"));

	ASSERT_NULL_POINTER(pContext);
	ASSERT_NULL_POINTER(pProfile);

	pHandle = (struct rmfp_main_thread_context_type *)pContext;

	RMDBGLOG((LOCALDBG, "input profile\n"));
	print_demux_resources_profile(pProfile);


	if (pHandle->AppOptions.Playback.test_external_resources_allocation) {
		/* Check version of profile, so that we are sure we do not use a mismatched structure */
		CHECK_VERSION(RMFP_DEMUX_RESOURCES_PROFILE_VERSION);

		pProfile->dram = OTHERS_DRAM_CONTROLLER;

		ALLOCATE_RESOURCES(pProfile->protected_memory_address, pProfile->dram, RUA_DRAM_CACHED, pProfile->protected_memory_size);
		ALLOCATE_RESOURCES(pProfile->unprotected_memory_address, pProfile->dram, RUA_DRAM_UNCACHED, pProfile->unprotected_memory_size);

		RMDBGLOG((LOCALDBG, "returned profile\n"));
		print_demux_resources_profile(pProfile);


	}



	return RM_OK;
}

/**************************************************************************************************/

RMstatus release_demux_resources_handler(void *pContext, struct RMFPDemuxResourcesProfile *pProfile)
{
	struct rmfp_main_thread_context_type *pHandle = NULL;

	RMDBGLOG((LOCALDBG, "release_demux_resources_handler()\n"));

	ASSERT_NULL_POINTER(pContext);
	ASSERT_NULL_POINTER(pProfile);

	pHandle = (struct rmfp_main_thread_context_type *)pContext;

	RMDBGLOG((LOCALDBG, "input profile\n"));
	print_demux_resources_profile(pProfile);

	if (pHandle->AppOptions.Playback.test_external_resources_allocation) {
		/* Check version of profile, so that we are sure we do not use a mismatched structure */
		CHECK_VERSION(RMFP_DEMUX_RESOURCES_PROFILE_VERSION);

		FREE_RESOURCES(pProfile->protected_memory_address);
		FREE_RESOURCES(pProfile->unprotected_memory_address);

		RMDBGLOG((LOCALDBG, "returned profile\n"));
		print_demux_resources_profile(pProfile);


	}



	return RM_OK;
}

/**************************************************************************************************/

RMstatus demux_output_resources_handler(void *pContext, struct RMFPDemuxOutputResourcesProfile *pProfile)
{
	struct rmfp_main_thread_context_type *pHandle = NULL;

	RMDBGLOG((LOCALDBG, "demux_output_resources_handler()\n"));

	ASSERT_NULL_POINTER(pContext);
	ASSERT_NULL_POINTER(pProfile);

	pHandle = (struct rmfp_main_thread_context_type *)pContext;

	RMDBGLOG((LOCALDBG, "input profile\n"));
	print_demux_output_resources_profile(pProfile);

	if (pHandle->AppOptions.Playback.test_external_resources_allocation) {
		/* Check version of profile, so that we are sure we do not use a mismatched structure */
		CHECK_VERSION(RMFP_DEMUX_OUTPUT_RESOURCES_PROFILE_VERSION);

		pProfile->dram = OTHERS_DRAM_CONTROLLER;

		ALLOCATE_RESOURCES(pProfile->protected_memory_address, pProfile->dram, RUA_DRAM_CACHED, pProfile->protected_memory_size);
		ALLOCATE_RESOURCES(pProfile->unprotected_memory_address, pProfile->dram, RUA_DRAM_UNCACHED, pProfile->unprotected_memory_size);

		RMDBGLOG((LOCALDBG, "returned profile\n"));
		print_demux_output_resources_profile(pProfile);


	}

	return RM_OK;
}

/**************************************************************************************************/

RMstatus release_demux_output_resources_handler(void *pContext, struct RMFPDemuxOutputResourcesProfile *pProfile)
{
	struct rmfp_main_thread_context_type *pHandle = NULL;

	RMDBGLOG((LOCALDBG, "release_demux_output_resources_handler()\n"));

	ASSERT_NULL_POINTER(pContext);
	ASSERT_NULL_POINTER(pProfile);

	pHandle = (struct rmfp_main_thread_context_type *)pContext;

	RMDBGLOG((LOCALDBG, "input profile\n"));
	print_demux_output_resources_profile(pProfile);

	if (pHandle->AppOptions.Playback.test_external_resources_allocation) {
		/* Check version of profile, so that we are sure we do not use a mismatched structure */
		CHECK_VERSION(RMFP_DEMUX_OUTPUT_RESOURCES_PROFILE_VERSION);

		FREE_RESOURCES(pProfile->protected_memory_address);
		FREE_RESOURCES(pProfile->unprotected_memory_address);

		RMDBGLOG((LOCALDBG, "returned profile\n"));
		print_demux_output_resources_profile(pProfile);
	}

	return RM_OK;
}

/**************************************************************************************************/

RMstatus spu_resources_handler(void *pContext, struct RMFPSPUResourcesProfile *pProfile)
{
	struct rmfp_main_thread_context_type *pHandle = NULL;

	RMDBGLOG((LOCALDBG, "spu_resources_handler()\n"));

	ASSERT_NULL_POINTER(pContext);
	ASSERT_NULL_POINTER(pProfile);

	pHandle = (struct rmfp_main_thread_context_type *)pContext;

	RMDBGLOG((LOCALDBG, "input profile\n"));
	print_spu_resources_profile(pProfile);

	if (pHandle->AppOptions.Playback.test_external_resources_allocation) {
		/* Check version of profile, so that we are sure we do not use a mismatched structure */
		CHECK_VERSION(RMFP_SPU_RESOURCES_PROFILE_VERSION);

		pProfile->dram = OTHERS_DRAM_CONTROLLER;
		pProfile->engine_index = VIDEO_ENGINE_INDEX;

		ALLOCATE_RESOURCES(pProfile->unprotected_memory_address, pProfile->dram, RUA_DRAM_UNCACHED, pProfile->unprotected_memory_size);

		RMDBGLOG((LOCALDBG, "returned profile\n"));
		print_spu_resources_profile(pProfile);

	}

	return RM_OK;
}
/**************************************************************************************************/

RMstatus release_spu_resources_handler(void *pContext, struct RMFPSPUResourcesProfile *pProfile)
{
	struct rmfp_main_thread_context_type *pHandle = NULL;

	RMDBGLOG((LOCALDBG, "release_spu_resources_handler()\n"));

	ASSERT_NULL_POINTER(pContext);
	ASSERT_NULL_POINTER(pProfile);

	pHandle = (struct rmfp_main_thread_context_type *)pContext;

	RMDBGLOG((LOCALDBG, "input profile\n"));
	print_spu_resources_profile(pProfile);

	if (pHandle->AppOptions.Playback.test_external_resources_allocation) {
		/* Check version of profile, so that we are sure we do not use a mismatched structure */
		CHECK_VERSION(RMFP_SPU_RESOURCES_PROFILE_VERSION);

		FREE_RESOURCES(pProfile->unprotected_memory_address);

		RMDBGLOG((LOCALDBG, "returned profile\n"));
		print_spu_resources_profile(pProfile);
	}

	return RM_OK;
}



/**************************************************************************************************/

RMstatus ccfifo_resources_handler(void *pContext, struct RMFPCCFIFOResourcesProfile *pProfile)
{
	struct rmfp_main_thread_context_type *pHandle = NULL;

	RMDBGLOG((LOCALDBG, "ccfifo_resources_handler()\n"));

	ASSERT_NULL_POINTER(pContext);
	ASSERT_NULL_POINTER(pProfile);

	pHandle = (struct rmfp_main_thread_context_type *)pContext;

	RMDBGLOG((LOCALDBG, "input profile\n"));
	print_ccfifo_resources_profile(pProfile);

	if (pHandle->AppOptions.Playback.test_external_resources_allocation) {
		/* Check version of profile, so that we are sure we do not use a mismatched structure */
		CHECK_VERSION(RMFP_CCFIFO_RESOURCES_PROFILE_VERSION);

		pProfile->dram = OTHERS_DRAM_CONTROLLER;

		ALLOCATE_RESOURCES(pProfile->unprotected_memory_address, pProfile->dram, RUA_DRAM_UNCACHED, pProfile->unprotected_memory_size);

		RMDBGLOG((LOCALDBG, "returned profile\n"));
		print_ccfifo_resources_profile(pProfile);

	}



	return RM_OK;
}

/**************************************************************************************************/

RMstatus release_ccfifo_resources_handler(void *pContext, struct RMFPCCFIFOResourcesProfile *pProfile)
{
	struct rmfp_main_thread_context_type *pHandle = NULL;

	RMDBGLOG((LOCALDBG, "release_ccfifo_resources_handler()\n"));

	ASSERT_NULL_POINTER(pContext);
	ASSERT_NULL_POINTER(pProfile);

	pHandle = (struct rmfp_main_thread_context_type *)pContext;

	RMDBGLOG((LOCALDBG, "input profile\n"));
	print_ccfifo_resources_profile(pProfile);

	if (pHandle->AppOptions.Playback.test_external_resources_allocation) {
		/* Check version of profile, so that we are sure we do not use a mismatched structure */
		CHECK_VERSION(RMFP_CCFIFO_RESOURCES_PROFILE_VERSION);

		FREE_RESOURCES(pProfile->unprotected_memory_address);

		RMDBGLOG((LOCALDBG, "returned profile\n"));
		print_ccfifo_resources_profile(pProfile);
	}



	return RM_OK;
}

/**************************************************************************************************/

RMstatus teletext_resources_handler(void *pContext, struct RMFPTTXResourcesProfile *pProfile)
{
	struct rmfp_main_thread_context_type *pHandle = NULL;

	RMDBGLOG((LOCALDBG, "teletext_resources_handler()\n"));

	ASSERT_NULL_POINTER(pContext);
	ASSERT_NULL_POINTER(pProfile);

	pHandle = (struct rmfp_main_thread_context_type *)pContext;

	RMDBGLOG((LOCALDBG, "input profile\n"));
	print_teletext_resources_profile(pProfile);


	if (pHandle->AppOptions.Playback.test_external_resources_allocation) {
		/* Check version of profile, so that we are sure we do not use a mismatched structure */
		CHECK_VERSION(RMFP_TELETEXT_PROFILE_VERSION);

		pProfile->dram = OTHERS_DRAM_CONTROLLER;

		ALLOCATE_RESOURCES(pProfile->unprotected_memory_address, pProfile->dram, RUA_DRAM_UNCACHED, pProfile->unprotected_memory_size);

		RMDBGLOG((LOCALDBG, "returned profile\n"));
		print_teletext_resources_profile(pProfile);
	}


	return RM_OK;
}
/**************************************************************************************************/

RMstatus release_teletext_resources_handler(void *pContext, struct RMFPTTXResourcesProfile *pProfile)
{
	struct rmfp_main_thread_context_type *pHandle = NULL;

	RMDBGLOG((LOCALDBG, "release_teletext_resources_handler()\n"));

	ASSERT_NULL_POINTER(pContext);
	ASSERT_NULL_POINTER(pProfile);

	pHandle = (struct rmfp_main_thread_context_type *)pContext;

	RMDBGLOG((LOCALDBG, "input profile\n"));
	print_teletext_resources_profile(pProfile);


	if (pHandle->AppOptions.Playback.test_external_resources_allocation) {
		/* Check version of profile, so that we are sure we do not use a mismatched structure */
		CHECK_VERSION(RMFP_TELETEXT_PROFILE_VERSION);

		FREE_RESOURCES(pProfile->unprotected_memory_address);

		RMDBGLOG((LOCALDBG, "returned profile\n"));
		print_teletext_resources_profile(pProfile);
	}


	return RM_OK;
}

/**************************************************************************************************/

RMstatus rmwmdrm_resources_handler(void *pContext, struct RMFPRMWMDRMResourcesProfile *pProfile)
{
	struct rmfp_main_thread_context_type *pHandle = NULL;

	RMDBGLOG((LOCALDBG, "rmwmdrm_resources_handler()\n"));

	ASSERT_NULL_POINTER(pContext);
	ASSERT_NULL_POINTER(pProfile);

	pHandle = (struct rmfp_main_thread_context_type *)pContext;

	RMDBGLOG((LOCALDBG, "input profile\n"));
	print_rmwmdrm_resources_profile(pProfile);

	if (pHandle->AppOptions.Playback.test_external_resources_allocation) {
		/* Check version of profile, so that we are sure we do not use a mismatched structure */
		CHECK_VERSION(RMFP_RMWMDRM_RESOURCES_PROFILE_VERSION);

		ALLOCATE_RESOURCES(pProfile->Address, OTHERS_DRAM_CONTROLLER, RUA_DRAM_UNCACHED, pProfile->Size);

		RMDBGLOG((LOCALDBG, "returned profile\n"));
		print_rmwmdrm_resources_profile(pProfile);
	}


	return RM_OK;
}

/**************************************************************************************************/

RMstatus release_rmwmdrm_resources_handler(void *pContext, struct RMFPRMWMDRMResourcesProfile *pProfile)
{
	struct rmfp_main_thread_context_type *pHandle = NULL;

	RMDBGLOG((LOCALDBG, "release_rmwmdrm_resources_handler()\n"));

	ASSERT_NULL_POINTER(pContext);
	ASSERT_NULL_POINTER(pProfile);

	pHandle = (struct rmfp_main_thread_context_type *)pContext;

	RMDBGLOG((LOCALDBG, "input profile\n"));
	print_rmwmdrm_resources_profile(pProfile);

	if (pHandle->AppOptions.Playback.test_external_resources_allocation) {
		/* Check version of profile, so that we are sure we do not use a mismatched structure */
		CHECK_VERSION(RMFP_RMWMDRM_RESOURCES_PROFILE_VERSION);

		FREE_RESOURCES(pProfile->Address);

		RMDBGLOG((LOCALDBG, "returned profile\n"));
		print_rmwmdrm_resources_profile(pProfile);
	}

	return RM_OK;
}

/**************************************************************************************************/

RMstatus rmwmdrm_profile(void *pContext, enum RMWMDRM_type Type, struct RMFPRMWMDRMProfile *pProfile)
{

	struct rmfp_main_thread_context_type *pHandle = NULL;

	RMDBGLOG((LOCALDBG, "rmwmdrm_profile()\n"));

	ASSERT_NULL_POINTER(pContext);
	ASSERT_NULL_POINTER(pProfile);

	pHandle = (struct rmfp_main_thread_context_type *)pContext;

	switch(Type) {
	case RMWMDRM_type_Janus:
	case RMWMDRM_type_PlayReady: //bug 32090: handle playready as janus for the time being

		if (pHandle->AppOptions.Playback.RMWMDRMUseHWDecryption)
			pProfile->Flags = RMWMDRM_flag_HW_decrypt;
		else
			pProfile->Flags = RMWMDRM_flag_SW_decrypt;

		pProfile->FlashSector         = -1;
		pProfile->Slot                = 0;
		pProfile->WithPreload         = FALSE;
		pProfile->pPathToCertificates = NULL;


		break;
	case RMWMDRM_type_Cardea:
		RMNOTIFY((NULL, RM_ERROR, "Not supported!\n"));
		break;
	};


	return RM_OK;

}



/**************************************************************************************************/
/**************************** Misc function like profiles print etc... ****************************/
/**************************************************************************************************/

static RMstatus print_video_resources_profile(struct RMFPVideoResourcesProfile *pProfile)
{

	RMDBGLOG((LOCALDBG, "video resources profile:\n"));
	RMDBGPRINT((LOCALDBG, "\tVersion             0x%lx\n", pProfile->Version));
	RMDBGPRINT((LOCALDBG, "\tdram                %lu\n", pProfile->dram));
	RMDBGPRINT((LOCALDBG, "\tstc                 %lu\n", pProfile->STC_index));
	RMDBGPRINT((LOCALDBG, "\tvideo engine index  %lu\n", pProfile->engine_index));
	RMDBGPRINT((LOCALDBG, "\tvideo decoder index %lu\n", pProfile->decoder_index));

	RMDBGPRINT((LOCALDBG, "\tscheduler address   %p size %lu\n", pProfile->scheduler_memory_address, pProfile->scheduler_memory_size));
	RMDBGPRINT((LOCALDBG, "\tshared    address   %p size %lu\n", pProfile->shared_memory_address, pProfile->shared_memory_size));
	RMDBGPRINT((LOCALDBG, "\tpicture   address   %p size %lu\n", pProfile->picture_memory_address, pProfile->picture_memory_size));
	RMDBGPRINT((LOCALDBG, "\tbitstream address   %p size %lu\n", pProfile->bitstream_memory_address, pProfile->bitstream_memory_size));
	RMDBGPRINT((LOCALDBG, "\tunprotected address %p size %lu\n", pProfile->unprotected_memory_address, pProfile->unprotected_memory_size));
	RMDBGPRINT((LOCALDBG, "\tpostprocess address  %p size %lu\n", pProfile->postprocessing_memory_address, pProfile->postprocessing_memory_size));

	return RM_OK;
}

/**************************************************************************************************/

static RMstatus print_picture_transform_resources_profile(struct RMFPPictureTransformResourcesProfile *pProfile)
{

	RMDBGLOG((LOCALDBG, "video resources profile:\n"));
	RMDBGPRINT((LOCALDBG, "\tVersion             0x%lx\n", pProfile->Version));
	RMDBGPRINT((LOCALDBG, "\tdram                %lu\n", pProfile->dram));
	RMDBGPRINT((LOCALDBG, "\tstc                 %lu\n", pProfile->STC_index));
	RMDBGPRINT((LOCALDBG, "\tvideo engine index  %lu\n", pProfile->engine_index));
	RMDBGPRINT((LOCALDBG, "\tvideo decoder index %lu\n", pProfile->decoder_index));

	RMDBGPRINT((LOCALDBG, "\tdata address   %p size %lu\n", pProfile->data_memory_address, pProfile->data_memory_size));
	RMDBGPRINT((LOCALDBG, "\tinterface    address   %p size %lu\n", pProfile->interface_memory_address, pProfile->interface_memory_size));

	return RM_OK;
}


/**************************************************************************************************/
static RMstatus print_ppf_resources_profile(struct RMFPPPFResourcesProfile *pProfile)
{

	RMDBGLOG((LOCALDBG, "video resources profile:\n"));
	RMDBGPRINT((LOCALDBG, "\tVersion             0x%lx\n", pProfile->Version));
	RMDBGPRINT((LOCALDBG, "\tdram                %lu\n", pProfile->dram));
	RMDBGPRINT((LOCALDBG, "\tstc                 %lu\n", pProfile->STC_index));
	RMDBGPRINT((LOCALDBG, "\tvideo engine index  %lu\n", pProfile->engine_index));
	RMDBGPRINT((LOCALDBG, "\tvideo decoder index %lu\n", pProfile->decoder_index));

	RMDBGPRINT((LOCALDBG, "\tinterface    address   %p size %lu\n", pProfile->engine_memory_address, pProfile->engine_memory_size));
	RMDBGPRINT((LOCALDBG, "\tinterface    address   %p size %lu\n", pProfile->input_memory_address, pProfile->input_memory_size));
	RMDBGPRINT((LOCALDBG, "\tinterface    address   %p size %lu\n", pProfile->output_memory_address, pProfile->output_memory_size));
	RMDBGPRINT((LOCALDBG, "\tdata address   %p size %lu\n", pProfile->data_memory_address, pProfile->data_memory_size));

	return RM_OK;
}


/**************************************************************************************************/

static RMstatus print_audio_instances_profile(struct RMFPMultipleAudioInstancesProfile *pProfile)
{
	RMuint32 i;

	RMDBGLOG((LOCALDBG, "audio instances profile:\n"));
	RMDBGPRINT((LOCALDBG, "\tVersion             0x%lx\n", pProfile->Version));

	RMDBGPRINT((LOCALDBG, "\tNumber of instance  %lu\n", pProfile->number_of_instances));
	for (i=0; i<pProfile->number_of_instances; i++)
	{
		RMDBGPRINT((LOCALDBG, "\t[%d]audio engine index  %lu\n", i, pProfile->instance[i].engine_index));
		RMDBGPRINT((LOCALDBG, "\t[%d]audio decoder index %lu\n", i, pProfile->instance[i].decoder_index));
	}

	return RM_OK;
}

/**************************************************************************************************/

static RMstatus print_audio_resources_profile(struct RMFPMultipleAudioResourcesProfile *pProfile)
{
	RMuint32 i;

	RMDBGLOG((LOCALDBG, "audio resources profile:\n"));
	RMDBGPRINT((LOCALDBG, "\tVersion             0x%lx\n", pProfile->Version));
	RMDBGPRINT((LOCALDBG, "\tstc                 %lu\n", pProfile->STC_index));

	RMDBGPRINT((LOCALDBG, "\tNumber of engines   %lu\n", pProfile->number_of_engines));
	for (i=0; i<pProfile->number_of_engines; i++)
	{
		RMDBGPRINT((LOCALDBG, "\t[%d]dram                %lu\n", i, pProfile->engine[i].dram));
		RMDBGPRINT((LOCALDBG, "\t[%d]shared    address   %p size %lu\n", i, pProfile->engine[i].shared_memory_address, pProfile->engine[i].shared_memory_size));
	}

	RMDBGPRINT((LOCALDBG, "\tNumber of instance  %lu\n", pProfile->number_of_instances));
	for (i=0; i<pProfile->number_of_instances; i++)
	{
		RMDBGPRINT((LOCALDBG, "\t[%d]dram                %lu\n", i, pProfile->instance[i].dram));
		RMDBGPRINT((LOCALDBG, "\t[%d]audio engine index  %lu\n", i, pProfile->instance[i].engine_index));
		RMDBGPRINT((LOCALDBG, "\t[%d]audio decoder index %lu\n", i, pProfile->instance[i].decoder_index));
		RMDBGPRINT((LOCALDBG, "\t[%d]protected address   %p size %lu\n",i, pProfile->instance[i].protected_memory_address, pProfile->instance[i].protected_memory_size));
		RMDBGPRINT((LOCALDBG, "\t[%d]unprotected address %p size %lu\n",i, pProfile->instance[i].unprotected_memory_address, pProfile->instance[i].unprotected_memory_size));
	}

	return RM_OK;
}

/**************************************************************************************************/

static RMstatus print_demux_resources_profile(struct RMFPDemuxResourcesProfile *pProfile)
{

	RMDBGLOG((LOCALDBG, "demux resources profile:\n"));
	RMDBGPRINT((LOCALDBG, "\tVersion             0x%lx\n", pProfile->Version));
	RMDBGPRINT((LOCALDBG, "\tdram                %lu\n", pProfile->dram));
	RMDBGPRINT((LOCALDBG, "\tstc index           %lu\n", pProfile->STC_index));
	RMDBGPRINT((LOCALDBG, "\tdemux engine index  %lu\n", pProfile->engine_index));
	RMDBGPRINT((LOCALDBG, "\tdemux task index    %lu\n", pProfile->task_index));

	RMDBGPRINT((LOCALDBG, "\tprotected address   %p size %lu\n", pProfile->protected_memory_address, pProfile->protected_memory_size));
	RMDBGPRINT((LOCALDBG, "\tunprotected address %p size %lu\n", pProfile->unprotected_memory_address, pProfile->unprotected_memory_size));

	return RM_OK;
}

/**************************************************************************************************/

static RMstatus print_demux_output_resources_profile(struct RMFPDemuxOutputResourcesProfile *pProfile)
{

	RMDBGLOG((LOCALDBG, "demux output resources profile:\n"));
	RMDBGPRINT((LOCALDBG, "\tVersion             0x%lx\n", pProfile->Version));
	RMDBGPRINT((LOCALDBG, "\tdram                %lu\n", pProfile->dram));
	RMDBGPRINT((LOCALDBG, "\tstc index           %lu\n", pProfile->STC_index));
	RMDBGPRINT((LOCALDBG, "\tdemux engine index  %lu\n", pProfile->engine_index));
	RMDBGPRINT((LOCALDBG, "\tdemux task index    %lu\n", pProfile->task_index));

	RMDBGPRINT((LOCALDBG, "\tprotected address   %p size %lu\n", pProfile->protected_memory_address, pProfile->protected_memory_size));
	RMDBGPRINT((LOCALDBG, "\tunprotected address %p size %lu\n", pProfile->unprotected_memory_address, pProfile->unprotected_memory_size));

	return RM_OK;
}

/**************************************************************************************************/

static RMstatus print_spu_resources_profile(struct RMFPSPUResourcesProfile *pProfile)
{

	RMDBGLOG((LOCALDBG, "spu resources profile:\n"));
	RMDBGPRINT((LOCALDBG, "\tVersion             0x%lx\n", pProfile->Version));
	RMDBGPRINT((LOCALDBG, "\tdram                %lu\n", pProfile->dram));
	RMDBGPRINT((LOCALDBG, "\tstc index           %lu\n", pProfile->STC_index));
	RMDBGPRINT((LOCALDBG, "\tvideo engine index  %lu\n", pProfile->engine_index));
	RMDBGPRINT((LOCALDBG, "\tspu decoder index   %lu\n", pProfile->decoder_index));

	RMDBGPRINT((LOCALDBG, "\tunprotected address %p size %lu\n", pProfile->unprotected_memory_address, pProfile->unprotected_memory_size));

	return RM_OK;
}


/**************************************************************************************************/

static RMstatus print_ccfifo_resources_profile(struct RMFPCCFIFOResourcesProfile *pProfile)
{

	RMDBGLOG((LOCALDBG, "ccfifo resources profile:\n"));
	RMDBGPRINT((LOCALDBG, "\tVersion             0x%lx\n", pProfile->Version));
	RMDBGPRINT((LOCALDBG, "\tdram                %lu\n", pProfile->dram));
	RMDBGPRINT((LOCALDBG, "\tstc index           %lu\n", pProfile->STC_index));
	RMDBGPRINT((LOCALDBG, "\tccfifo index        %lu\n", pProfile->fifo_index));

	RMDBGPRINT((LOCALDBG, "\tunprotected address %p size %lu\n", pProfile->unprotected_memory_address, pProfile->unprotected_memory_size));

	return RM_OK;

}

/**************************************************************************************************/

static RMstatus print_teletext_resources_profile(struct RMFPTTXResourcesProfile *pProfile)
{

	RMDBGLOG((LOCALDBG, "teletext resources profile:\n"));
	RMDBGPRINT((LOCALDBG, "\tVersion             0x%lx\n", pProfile->Version));
	RMDBGPRINT((LOCALDBG, "\tdram                %lu\n", pProfile->dram));
	RMDBGPRINT((LOCALDBG, "\tstc index           %lu\n", pProfile->STC_index));

	RMDBGPRINT((LOCALDBG, "\tunprotected address %p size %lu\n", pProfile->unprotected_memory_address, pProfile->unprotected_memory_size));

	return RM_OK;

}

/**************************************************************************************************/

static RMstatus print_rmwmdrm_resources_profile(struct RMFPRMWMDRMResourcesProfile *pProfile)
{

	RMDBGLOG((LOCALDBG, "RMWMDRM resources profile:\n"));
	RMDBGPRINT((LOCALDBG, "\tVersion             0x%lx\n", pProfile->Version));
	RMDBGPRINT((LOCALDBG, "\taddress             %p size %lu\n", pProfile->Address, pProfile->Size));

	return RM_OK;
}
