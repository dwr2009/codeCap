#ifndef __TESTRMFP_RESOURCES_H__
#define __TESTRMFP_RESOURCES_H__

#include <rmdef/rmdef.h>
#include "rmfp.h"
#include "test_rmfp.h"

RM_EXTERN_C_BLOCKSTART

RMstatus video_resources_handler(void *pContext, struct RMFPVideoResourcesProfile *pProfile);
RMstatus release_video_resources_handler(void *pContext, struct RMFPVideoResourcesProfile *pProfile);

RMstatus picture_transform_resources_handler(void *pContext, struct RMFPPictureTransformResourcesProfile *pProfile);
RMstatus release_picture_transform_resources_handler(void *pContext, struct RMFPPictureTransformResourcesProfile *pProfile);

RMstatus ppf_resources_handler(void *pContext, struct RMFPPPFResourcesProfile *pProfile);
RMstatus release_ppf_resources_handler(void *pContext, struct RMFPPPFResourcesProfile *pProfile);

RMstatus audio_instances_handler(void *pContext, struct RMFPMultipleAudioInstancesProfile *pProfile);
RMstatus audio_resources_handler(void *pContext, struct RMFPMultipleAudioResourcesProfile *pProfile);
RMstatus release_audio_resources_handler(void *pContext, struct RMFPMultipleAudioResourcesProfile *pProfile);

RMstatus demux_resources_handler(void *pContext, struct RMFPDemuxResourcesProfile *pProfile);
RMstatus release_demux_resources_handler(void *pContext, struct RMFPDemuxResourcesProfile *pProfile);

RMstatus demux_output_resources_handler(void *pContext, struct RMFPDemuxOutputResourcesProfile *pProfile);
RMstatus release_demux_output_resources_handler(void *pContext, struct RMFPDemuxOutputResourcesProfile *pProfile);

RMstatus spu_resources_handler(void *pContext, struct RMFPSPUResourcesProfile *pProfile);
RMstatus release_spu_resources_handler(void *pContext, struct RMFPSPUResourcesProfile *pProfile);

RMstatus ccfifo_resources_handler(void *pContext, struct RMFPCCFIFOResourcesProfile *pProfile);
RMstatus release_ccfifo_resources_handler(void *pContext, struct RMFPCCFIFOResourcesProfile *pProfile);

RMstatus teletext_resources_handler(void *pContext, struct RMFPTTXResourcesProfile *pProfile);
RMstatus release_teletext_resources_handler(void *pContext, struct RMFPTTXResourcesProfile *pProfile);

RMstatus rmwmdrm_profile(void *pContext, enum RMWMDRM_type Type, struct RMFPRMWMDRMProfile *pProfile);
RMstatus rmwmdrm_resources_handler(void *pContext, struct RMFPRMWMDRMResourcesProfile *pProfile);
RMstatus release_rmwmdrm_resources_handler(void *pContext, struct RMFPRMWMDRMResourcesProfile *pProfile);

RM_EXTERN_C_BLOCKEND

#endif // __TESTRMFP_RESOURCES_H__

