/*****************************************
 Copyright 2001-2007
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   rmfp_default_values.h
  @brief  

  Default values used to initialise some parameters

  
  @author Sebastian Frias Feltrer
  @date   2007-08-07
*/


#ifndef __RMFP_DEFAULT_VALUES_H__
#define __RMFP_DEFAULT_VALUES_H__




#define RMFP_DEFAULT_DRAM_CONTROLLER_INDEX 0

#define RMFP_DEFAULT_STC_INDEX 0
#define RMFP_DEFAULT_STC_ENGINE 0
#define RMFP_DEFAULT_STC_MODE Master_STC

#define RMFP_DEFAULT_VIDEO_ENGINE_INDEX 0
#define RMFP_DEFAULT_VIDEO_DECODER_INDEX 0

#define RMFP_DEFAULT_AUDIO_ENGINE_INDEX 0
#define RMFP_DEFAULT_AUDIO_DECODER_INDEX 0
#define RMFP_DEFAULT_CHANNEL_SERVICE_INDEX 0

#define RMFP_DEFAULT_SPU_DECODER_INDEX 0

#define RMFP_DEFAULT_DCC_DISPLAY_ROUTE DCCRoute_Main

#define RMFP_DEFAULT_SECTION_FILTER_MASK	3

#define RMFP_DEFAULT_MINIMUM_HDMI_SAMPLE_RATE 32000



#endif // __RMFP_DEFAULT_VALUES_H__
