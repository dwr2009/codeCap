/*****************************************
 Copyright 2001-2007
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   rmfp_resources_spu.c
  @brief


  @author Sebastian Frias Feltrer
  @date   2007-11-05
*/

#include "rmfp_internal.h"

#if 0
#define LOCALDBG ENABLE
#else
#define LOCALDBG DISABLE
#endif


static RMstatus rmfp_print_spu_decoder_profile(struct DCCSPUProfile *pSPUProfile);



RMstatus rmfp_internal_get_spu_decoder_handler(void *pContext,
					       struct RMLibPlaySPUSource *pSPUSource,
					       struct RMLibPlaySPUProfile *pSPUProfile)
{
	struct RMFPHandle *pHandle = NULL;
	struct RMFPSPUResourcesProfile rmfp_spu_resources_profile = { 0, };

	struct DCCSPUSource *pDCCSPUSource = NULL;
	struct DCCSPUProfile SPUProfile = { 0, };
	struct DCCSPUResources dcc_spu_resources = { 0, };

	struct RMFPVideoOptions *pVideoOptions = NULL;
	struct RMFPPlayOptions *pPlayOptions = NULL;

	struct DCC *pDCC = NULL;
	struct RUA *pRUA = NULL;

	RMuint32 VideoScalerModuleID;
	enum DCCRoute dcc_route;

	RMstatus status;

	RMDBGLOG((LOCALDBG, "rmfp_get_spu_decoder()\n"));
	
	ASSERT_NULL_POINTER(pContext);
	ASSERT_NULL_POINTER(pSPUSource);
	ASSERT_NULL_POINTER(pSPUProfile);

	pHandle = (struct RMFPHandle *)pContext;

	pRUA = pHandle->profile.pRUA;
	pDCC = pHandle->profile.pDCC;
	pVideoOptions = &(pHandle->video_options);
	pPlayOptions = &(pHandle->playback_options);

  // make a dcc spu profile
	// We only support DVD and Bluray here
	switch (pSPUProfile->Codec) {
	case RMLibPlaySPUCodec_DVD:
		SPUProfile.Codec = EMhwlibDVDSpuCodec;
		break;
	case RMLibPlaySPUCodec_Bluray:
		SPUProfile.Codec = EMhwlibBDRLECodec;
		break;
	default:
		RMNOTIFY((NULL, RM_ERROR, "Unsupported SPU codec %d\n", pSPUProfile->Codec));
		return RM_ERROR;
	}
	
	SPUProfile.STCID                   = pPlayOptions->STCIndex + pPlayOptions->STCEngine*3;
	SPUProfile.EngineIndex             = pVideoOptions->EngineIndex; //RMFP_DEFAULT_VIDEO_ENGINE_INDEX;
	SPUProfile.DecoderIndex            = RMFP_DEFAULT_SPU_DECODER_INDEX;
	SPUProfile.XtaskID                 = 0;
	SPUProfile.ProtectedFlags          = 0;
	SPUProfile.XtaskInbandFIFOCount    = 0;

	SPUProfile.XferFIFOCount           = pSPUProfile->XferFIFOCount;
	SPUProfile.BitstreamFIFOSize       = pSPUProfile->BitstreamFIFOSize;

	SPUProfile.PtsFIFOCount            = pSPUProfile->PtsFIFOCount;
	SPUProfile.InbandFIFOCount         = pSPUProfile->InbandFIFOCount;

	SPUProfile.Level                   = pSPUProfile->Level;
	SPUProfile.Profile                 = pSPUProfile->Profile;
	SPUProfile.MaxWidth                = pSPUProfile->MaxWidth;
	SPUProfile.MaxHeight               = pSPUProfile->MaxHeight;
	SPUProfile.ExtraPictureBufferCount = pSPUProfile->ExtraPictureBufferCount;



	rmfp_print_spu_decoder_profile(&SPUProfile);

	status = DCCGetSPUResourcesRequired(pDCC, &SPUProfile, &dcc_spu_resources);
	if (status != RM_OK) {
		RMNOTIFY((NULL, status, "Can't get required resources for SPU\n"));
		return status;
	}


  // take DCCSPUResources and SPUProfile to create a RMFPSPUResourcesProfile
	rmfp_spu_resources_profile.Version                    = GET_VERSION_FROM_MAGIC(RMFP_SPU_RESOURCES_PROFILE_VERSION);

	rmfp_spu_resources_profile.dram                       = pPlayOptions->DRAMIndex;

	rmfp_spu_resources_profile.unprotected_memory_address = dcc_spu_resources.UnprotectedMemoryAddress;
	rmfp_spu_resources_profile.unprotected_memory_size    = dcc_spu_resources.UnprotectedMemorySize;

	rmfp_spu_resources_profile.engine_index               = SPUProfile.EngineIndex;
	rmfp_spu_resources_profile.decoder_index              = SPUProfile.DecoderIndex;

	rmfp_spu_resources_profile.STC_index                  = SPUProfile.STCID;

  // then present the RMFPVideoResourcesProfile to the application if the callback was defined
	if (pHandle->profile.rmfp_spu_resources_callback) {
		status = pHandle->profile.rmfp_spu_resources_callback(pHandle->profile.callback_context, &rmfp_spu_resources_profile);
		if (status != RM_OK) {
			RMNOTIFY((NULL, status, "Failed to get resources from application\n"));
			return status;
		}
	}

// then allocate the resources and create a SPU source


	// unprotected
	if ((!rmfp_spu_resources_profile.unprotected_memory_address) &&
	    (rmfp_spu_resources_profile.unprotected_memory_size)) {
		pHandle->spu_resources.unprotected_memory_address = DCCMalloc(pDCC,
									      rmfp_spu_resources_profile.dram,
									      RUA_DRAM_UNCACHED,
									      rmfp_spu_resources_profile.unprotected_memory_size);

		if (!pHandle->spu_resources.unprotected_memory_address) {
			RMNOTIFY((NULL, RM_FATALOUTOFMEMORY, "Can't allocate %lu bytes in DRAM %lu\n",
				    rmfp_spu_resources_profile.unprotected_memory_size,
				    rmfp_spu_resources_profile.dram));
			return RM_FATALOUTOFMEMORY;
		}
		else
			RMDBGLOG((LOCALDBG, "allocated %lu bytes for unprotected memory\n", rmfp_spu_resources_profile.unprotected_memory_size));

		pHandle->spu_resources.free_unprotected = TRUE;
	}
	else
		pHandle->spu_resources.unprotected_memory_address = rmfp_spu_resources_profile.unprotected_memory_address;

	dcc_spu_resources.UnprotectedMemoryAddress = pHandle->spu_resources.unprotected_memory_address;
	dcc_spu_resources.UnprotectedMemorySize = rmfp_spu_resources_profile.unprotected_memory_size;

	RMDBGLOG((LOCALDBG, "UnProtected Memory: %lu bytes at %p\n",
		  dcc_spu_resources.UnprotectedMemorySize,
		  dcc_spu_resources.UnprotectedMemoryAddress));


// update module indexes
	pHandle->spu_resources.dram          = rmfp_spu_resources_profile.dram;

	SPUProfile.EngineIndex = rmfp_spu_resources_profile.engine_index;
	SPUProfile.DecoderIndex = rmfp_spu_resources_profile.decoder_index;

	pHandle->spu_resources.engine_index  = SPUProfile.EngineIndex;
	pHandle->spu_resources.decoder_index = SPUProfile.DecoderIndex;

  // open a dcc SPU source with the resources

	status = DCCOpenSPUDecoderSourceWithResources(pDCC, &SPUProfile, &dcc_spu_resources, &(pDCCSPUSource));
	if (status != RM_OK) {
		RMNOTIFY((NULL, status, "Cannot open SPU decoder source with resources\n"));
		return status;
	}

	status = DCCSetSPUDecoderSourceCodec(pDCCSPUSource, SPUProfile.Codec);
	if (status != RM_OK) {
		RMNOTIFY((NULL, status, "Cannot set video source codec\n"));
		return status;
	}


	RMDBGLOG((LOCALDBG, "get video scaler moduleID\n"));
	VideoScalerModuleID = pVideoOptions->VideoScalerID;

	RMDBGLOG((LOCALDBG, "connect SPU to scaler 0x%lx\n", VideoScalerModuleID));

	/* Get route from application */
	status = rmfp_internal_get_route(pHandle, &dcc_route);
	if (status != RM_OK)
		return status;
	
	status = DCCConnectSPUToScaler(pDCCSPUSource, dcc_route, 0, VideoScalerModuleID);
	if (status != RM_OK) {
		RMNOTIFY((NULL, status, "Cannot connect SPU to scaler\n"));
		return status;
	}

	pSPUSource->source = (void *)pDCCSPUSource;


	return RM_OK;




}


RMstatus rmfp_internal_release_spu_decoder_handler(void *pContext, struct RMLibPlaySPUSource *pSPUSource)
{
	struct RMFPHandle *pHandle = NULL;
	struct RMFPSPUResourcesProfile rmfp_spu_resources_profile = { 0, };
	struct DCCSPUSource *pDCCSPUSource = NULL;
	struct RUA *pRUA = NULL;
	struct DCC *pDCC = NULL;
	RMstatus status;

	struct RMFPVideoOptions *pVideoOptions = NULL;
	struct RMFPPlayOptions *pPlayOptions = NULL;
	RMuint32 VideoScalerModuleID;


	RMDBGLOG((LOCALDBG, "rmfp_release_spu_decoder()\n"));


	ASSERT_NULL_POINTER(pContext);
	ASSERT_NULL_POINTER(pSPUSource);

	pHandle = (struct RMFPHandle *)pContext;
	pDCCSPUSource = (struct DCCSPUSource *)pSPUSource->source;
	pRUA = pHandle->profile.pRUA;
	pDCC = pHandle->profile.pDCC;
	pVideoOptions = &(pHandle->video_options);
	pPlayOptions = &(pHandle->playback_options);

	RMDBGLOG((LOCALDBG, "get video scaler moduleID\n"));
	VideoScalerModuleID = pVideoOptions->VideoScalerID;

	RMDBGLOG((LOCALDBG, "disconnect SPU from scaler 0x%lx\n", VideoScalerModuleID));

	status = DCCDisconnectSPUFromScaler(pDCCSPUSource, VideoScalerModuleID);
	if (status != RM_OK) {
		RMNOTIFY((NULL, status, "Cannot disconnect SPU from scaler\n"));
		return status;
	}

	RMDBGLOG((LOCALDBG, "close SPU source\n"));

	status = DCCCloseSPUSource(pDCCSPUSource);
	if (status != RM_OK)
		RMNOTIFY((NULL, status, "Failed to close spu source but continue to release the resources\n"));


  // free everything we allocated internally

	if (pHandle->spu_resources.free_unprotected) {
		RMDBGLOG((LOCALDBG, "Free video unprotected memory at %p\n", pHandle->spu_resources.unprotected_memory_address));
		DCCFree(pDCC, pHandle->spu_resources.unprotected_memory_address);
		pHandle->spu_resources.unprotected_memory_address = 0;
	}


  // convert from RMFPSPUResources to RMFPSPUResourcesProfile

	rmfp_spu_resources_profile.Version                    = GET_VERSION_FROM_MAGIC(RMFP_SPU_RESOURCES_PROFILE_VERSION);

	rmfp_spu_resources_profile.dram                       = pHandle->spu_resources.dram;

	rmfp_spu_resources_profile.unprotected_memory_address = pHandle->spu_resources.unprotected_memory_address;
	rmfp_spu_resources_profile.unprotected_memory_size    = pHandle->spu_resources.unprotected_memory_size;

	rmfp_spu_resources_profile.engine_index               = pHandle->spu_resources.engine_index;
	rmfp_spu_resources_profile.decoder_index              = pHandle->spu_resources.decoder_index;

	rmfp_spu_resources_profile.STC_index                  = pPlayOptions->STCIndex + pPlayOptions->STCEngine*3;

  // then present the RMFPSPUResourcesProfile to the application if the callback was defined
	if (pHandle->profile.rmfp_release_spu_resources_callback) {
		status = pHandle->profile.rmfp_release_spu_resources_callback(pHandle->profile.callback_context, &rmfp_spu_resources_profile);
		if (status != RM_OK)
			RMNOTIFY((NULL, status, "The application failed to release the resources\n"));
	}

	return status;
}



static RMstatus rmfp_print_spu_decoder_profile(struct DCCSPUProfile *pSPUProfile)
{
	ASSERT_NULL_POINTER(pSPUProfile);

	RMDBGPRINT((LOCALDBG, "SPUProfile:\n"));
	RMDBGPRINT((LOCALDBG, "\tEngineIndex             0x%lx\n", pSPUProfile->EngineIndex));
	RMDBGPRINT((LOCALDBG, "\tDecoderIndex            0x%lx\n", pSPUProfile->DecoderIndex));
	RMDBGPRINT((LOCALDBG, "\tSTCID                   0x%lx\n", pSPUProfile->STCID));

	RMDBGPRINT((LOCALDBG, "\tCodec                   0x%lx\n", (RMuint32)pSPUProfile->Codec));
	RMDBGPRINT((LOCALDBG, "\tProfile                 %lu\n", pSPUProfile->Profile));
	RMDBGPRINT((LOCALDBG, "\tLevel                   %lu\n", pSPUProfile->Level));
	RMDBGPRINT((LOCALDBG, "\tMaxWidth                %lu\n", pSPUProfile->MaxWidth));
	RMDBGPRINT((LOCALDBG, "\tMaxHeight               %lu\n", pSPUProfile->MaxHeight));
	RMDBGPRINT((LOCALDBG, "\tExtraPictureBufferCount %lu\n", pSPUProfile->ExtraPictureBufferCount));

	RMDBGPRINT((LOCALDBG, "\tBitstreamFIFOSize       %lu\n", pSPUProfile->BitstreamFIFOSize));
	RMDBGPRINT((LOCALDBG, "\tXferFIFOCount           %lu\n", pSPUProfile->XferFIFOCount));
	RMDBGPRINT((LOCALDBG, "\tPtsFIFOCount            %lu\n", pSPUProfile->PtsFIFOCount));
	RMDBGPRINT((LOCALDBG, "\tInbandFIFOCount         %lu\n", pSPUProfile->InbandFIFOCount));

	RMDBGPRINT((LOCALDBG, "\tXtaskID                 0x%lx\n", pSPUProfile->XtaskID));
	RMDBGPRINT((LOCALDBG, "\tProtectedFlags          0x%lx\n", pSPUProfile->ProtectedFlags));
	RMDBGPRINT((LOCALDBG, "\tXtaskInbandFIFOCount    %lu\n", pSPUProfile->XtaskInbandFIFOCount));

	return RM_OK;

}
