/*
 *  tslib/src/ts_close.c
 *
 *  Copyright (C) 2001 Russell King.
 *
 * This file is placed under the LGPL.  Please see the file
 * COPYING for more details.
 *
 *
 * Close a touchscreen device.
 */
#include "config.h"
#include <stdlib.h>
#ifdef HAVE_UNISTD_H
#include <unistd.h>
#endif
#include <dlfcn.h>

#include "tslib-private.h"
#include <stdio.h>
#include <errno.h>

#ifdef	SRC_FILE_NAME
#undef	SRC_FILE_NAME
#endif	//SRC_FILE_NAME
#define	SRC_FILE_NAME			"ts_close.c"

int ts_close(struct tsdev *ts)
{
	int ret;
	int iRet;
	void *handle = NULL;
	struct tslib_module_info *info, *pNextTslibModuleInfo = NULL;

	for(info = ts->list ; info != NULL; info = pNextTslibModuleInfo) {
		//printf("[%s:%d]info=%p\n", SRC_FILE_NAME, __LINE__, info);
		pNextTslibModuleInfo = info->next;
		handle = info->handle;
		if(info->ops->fini)
		{
			iRet = info->ops->fini(info);
			if(0 != iRet)
			{
				printf("[%s:%d]Ret=%d\n", SRC_FILE_NAME, __LINE__, iRet);
			}
			info = NULL;
		}
		if (handle)
		{
			iRet = dlclose(handle);
			if(0 != iRet)
			{
				printf("[%s:%d]%s\n", SRC_FILE_NAME, __LINE__, strerror(errno));
			}
			handle = NULL;
		}
	}

	ret = close(ts->fd);
	
	free(ts);
	ts = NULL;

	return ret;
}

